# Security and authorization remediation candidate — NOT DEPLOYABLE

This archive preserves the original factory code and adds a source-level defense-in-depth patch to the G3 API and dashboard.

Implemented: restricted DOM rendering replacing 26 direct HTML assignments; dynamic allowed actions bound through JS listeners; CSP script hash and frame/object restrictions; nosniff/referrer/cache headers; constant-time token checks; nondevelopment audit identity no longer sourced from X-Identity; max 1 MiB JSON body and object-only validation; generic 500 errors.

**Not yet established:** comprehensive XSS safety, browser negative tests (including injected allowed tags/action impersonation), endpoint-by-endpoint authorization, rotating per-service identities, trusted reverse proxy, clean environment rebuild, real n8n integration, full six-station functionality and deployment readiness.

Remaining attack risk: allowed HTML markup from untrusted values could be interpreted as legitimate DOM elements, including action buttons with syntactically valid IDs. Replace mixed HTML interpolation with trusted templates + text nodes or escape all data interpolation, and test against hostile payloads before deployment. Production credentials and database setup are also deployment-blocking prerequisites.

**DO NOT DEPLOY to n8n.vomeb.com.**
