"""Gate D durable artifact storage (LOCK_GATE_D §2).

One interface, two backends, content-addressed throughout:

  put_candidate(bytes, content_type) -> {uri: store://candidates/<sha256>,
                                         sha256, size}
  promote(candidate_uri)             -> store://objects/<sha256>
  get(uri) -> bytes;  head(uri) -> {sha256, size, content_type?};
  delete(uri)

Backends:
  LocalStorage  — filesystem under a root: candidates/<sha256> staged
                  bytes, objects/<sha256> promoted (durable) bytes.
  S3Storage     — S3-compatible subset (PUT/GET/HEAD/DELETE) with stdlib
                  AWS SigV4 signing; endpoint/bucket/credentials come from
                  the environment only. Mechanics are proven against a
                  local stub endpoint in tests; a real object store is
                  NOT TESTED (deployment-time configuration, OD-A4).

factory_from_env() selects the backend:
  FACTORY_STORAGE_BACKEND  'local' (default) | 's3'
  FACTORY_STORAGE_ROOT     local root (default: this package's .store/)
  FACTORY_S3_ENDPOINT / FACTORY_S3_BUCKET / FACTORY_S3_ACCESS_KEY /
  FACTORY_S3_SECRET_KEY / FACTORY_S3_REGION (default 'us-east-1')
"""
import hashlib
import hmac
import os
import urllib.error
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

CANDIDATE_PREFIX = "store://candidates/"
OBJECT_PREFIX = "store://objects/"


def sha256_hex(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def final_uri(sha256: str) -> str:
    """The promoted URI is a pure function of the content hash, on every
    backend — callers can name the durable object before it is promoted."""
    return OBJECT_PREFIX + sha256


def _key_of(uri: str) -> str:
    for prefix, area in ((CANDIDATE_PREFIX, "candidates"), (OBJECT_PREFIX, "objects")):
        if uri.startswith(prefix):
            return f"{area}/{uri[len(prefix):]}"
    raise ValueError(f"not a store:// uri: {uri}")


def _sha_of(uri: str) -> str:
    return uri.rsplit("/", 1)[-1]


class StorageClient:
    """Interface every backend implements (see module docstring)."""

    def put_candidate(self, data: bytes, content_type=None):
        raise NotImplementedError

    def promote(self, candidate_uri: str) -> str:
        raise NotImplementedError

    def get(self, uri: str) -> bytes:
        raise NotImplementedError

    def head(self, uri: str):
        raise NotImplementedError

    def delete(self, uri: str):
        raise NotImplementedError


class LocalStorage(StorageClient):
    """Content-addressed filesystem storage (dev/default backend)."""

    def __init__(self, root):
        self.root = Path(root)
        (self.root / "candidates").mkdir(parents=True, exist_ok=True)
        (self.root / "objects").mkdir(parents=True, exist_ok=True)

    def _path(self, uri):
        return self.root / _key_of(uri)

    def put_candidate(self, data: bytes, content_type=None):
        sha = sha256_hex(data)
        path = self.root / "candidates" / sha
        if not path.exists():
            tmp = path.with_suffix(".tmp")
            tmp.write_bytes(data)
            tmp.replace(path)  # atomic publish of the staged bytes
        return {"uri": CANDIDATE_PREFIX + sha, "sha256": sha, "size": len(data)}

    def promote(self, candidate_uri: str) -> str:
        sha = _sha_of(candidate_uri)
        src = self.root / "candidates" / sha
        dst = self.root / "objects" / sha
        if not dst.exists():
            if not src.exists():
                raise FileNotFoundError(f"candidate bytes missing: {candidate_uri}")
            tmp = dst.with_suffix(".tmp")
            tmp.write_bytes(src.read_bytes())
            tmp.replace(dst)
        return OBJECT_PREFIX + sha

    def get(self, uri: str) -> bytes:
        return self._path(uri).read_bytes()

    def head(self, uri: str):
        path = self._path(uri)
        if not path.exists():
            return None
        return {"sha256": _sha_of(uri), "size": path.stat().st_size}

    def delete(self, uri: str):
        self._path(uri).unlink(missing_ok=True)


class S3Storage(StorageClient):
    """S3-compatible storage with stdlib SigV4 signing (subset:
    PUT/GET/HEAD/DELETE on keys candidates/<sha256> and objects/<sha256>).

    Path-style addressing (<endpoint>/<bucket>/<key>). Credentials are
    constructor arguments sourced from the environment by
    factory_from_env — never from code, config rows, or workflow JSON."""

    def __init__(self, endpoint, bucket, access_key, secret_key, region="us-east-1"):
        if not endpoint or not bucket:
            raise ValueError("S3Storage requires an endpoint and a bucket")
        self.endpoint = endpoint.rstrip("/")
        self.bucket = bucket
        self.access_key = access_key or ""
        self.secret_key = secret_key or ""
        self.region = region or "us-east-1"

    # ------------------------------------------------------------- SigV4
    def _sign(self, method, key, body: bytes, content_type=None):
        now = datetime.now(timezone.utc)
        amz_date = now.strftime("%Y%m%dT%H%M%SZ")
        date_stamp = now.strftime("%Y%m%d")
        payload_hash = hashlib.sha256(body).hexdigest()
        host = self.endpoint.split("://", 1)[-1]
        canonical_uri = f"/{self.bucket}/{key}"
        headers = {"host": host, "x-amz-content-sha256": payload_hash,
                   "x-amz-date": amz_date}
        if content_type:
            headers["content-type"] = content_type
        signed = ";".join(sorted(headers))
        canonical_headers = "".join(f"{k}:{headers[k]}\n" for k in sorted(headers))
        canonical = "\n".join([method, canonical_uri, "", canonical_headers,
                               signed, payload_hash])
        scope = f"{date_stamp}/{self.region}/s3/aws4_request"
        to_sign = "\n".join(["AWS4-HMAC-SHA256", amz_date, scope,
                             hashlib.sha256(canonical.encode()).hexdigest()])

        def hm(key_bytes, msg):
            return hmac.new(key_bytes, msg.encode(), hashlib.sha256).digest()

        k = hm(("AWS4" + self.secret_key).encode(), date_stamp)
        k = hm(k, self.region)
        k = hm(k, "s3")
        k = hm(k, "aws4_request")
        signature = hmac.new(k, to_sign.encode(), hashlib.sha256).hexdigest()
        headers["Authorization"] = (
            f"AWS4-HMAC-SHA256 Credential={self.access_key}/{scope}, "
            f"SignedHeaders={signed}, Signature={signature}")
        if content_type:
            headers["Content-Type"] = content_type
        headers["x-amz-content-sha256"] = payload_hash
        headers["x-amz-date"] = amz_date
        return headers

    def _request(self, method, key, body=b"", content_type=None):
        url = f"{self.endpoint}/{self.bucket}/{key}"
        req = urllib.request.Request(url, method=method, data=body if method == "PUT" else None)
        for k, v in self._sign(method, key, body, content_type).items():
            req.add_header(k, v)
        try:
            with urllib.request.urlopen(req, timeout=30) as r:
                return r.status, dict(r.headers), r.read()
        except urllib.error.HTTPError as e:
            if e.code == 404:
                return 404, {}, b""
            raise

    # ----------------------------------------------------------- interface
    def put_candidate(self, data: bytes, content_type=None):
        sha = sha256_hex(data)
        status, _, _ = self._request("PUT", f"candidates/{sha}", data,
                                     content_type or "application/octet-stream")
        if status not in (200, 201):
            raise IOError(f"S3 PUT candidate failed: HTTP {status}")
        return {"uri": CANDIDATE_PREFIX + sha, "sha256": sha, "size": len(data)}

    def promote(self, candidate_uri: str) -> str:
        sha = _sha_of(candidate_uri)
        data = self.get(candidate_uri)  # subset has no CopyObject; promote = read + PUT
        status, _, _ = self._request("PUT", f"objects/{sha}", data,
                                     "application/octet-stream")
        if status not in (200, 201):
            raise IOError(f"S3 PUT object failed: HTTP {status}")
        return OBJECT_PREFIX + sha

    def get(self, uri: str) -> bytes:
        status, _, body = self._request("GET", _key_of(uri))
        if status == 404:
            raise FileNotFoundError(f"object missing: {uri}")
        return body

    def head(self, uri: str):
        status, headers, _ = self._request("HEAD", _key_of(uri))
        if status == 404:
            return None
        size = headers.get("Content-Length") or headers.get("content-length")
        return {"sha256": _sha_of(uri), "size": int(size) if size is not None else None}

    def delete(self, uri: str):
        self._request("DELETE", _key_of(uri))


def factory_from_env(env=None) -> StorageClient:
    env = os.environ if env is None else env
    backend = (env.get("FACTORY_STORAGE_BACKEND") or "local").lower()
    if backend == "s3":
        return S3Storage(
            endpoint=env.get("FACTORY_S3_ENDPOINT"),
            bucket=env.get("FACTORY_S3_BUCKET"),
            access_key=env.get("FACTORY_S3_ACCESS_KEY"),
            secret_key=env.get("FACTORY_S3_SECRET_KEY"),
            region=env.get("FACTORY_S3_REGION", "us-east-1"))
    root = env.get("FACTORY_STORAGE_ROOT") or str(Path(__file__).resolve().parent / ".store")
    return LocalStorage(root)
