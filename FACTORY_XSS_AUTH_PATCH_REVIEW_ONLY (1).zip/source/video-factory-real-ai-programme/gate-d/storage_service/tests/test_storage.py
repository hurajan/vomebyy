"""Storage service tests (Gate D, LOCK_GATE_D §2).

Local backend: real round trips on a temp filesystem root.
S3 backend: STUB EVIDENCE ONLY — the S3 tests run S3Storage against a
tiny in-test HTTP server implementing the S3 subset over an in-memory
dict. They prove the client's request/signing mechanics, not any real
object store (a real endpoint is deployment-time configuration, OD-A4).
"""
import hashlib
import sys
import tempfile
import threading
import unittest
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

from storage_service import LocalStorage, S3Storage, factory_from_env  # noqa: E402
from storage_service.storage import CANDIDATE_PREFIX, OBJECT_PREFIX  # noqa: E402


class TestLocalStorage(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.store = LocalStorage(self.tmp.name)

    def tearDown(self):
        self.tmp.cleanup()

    def test_round_trip_stage_promote_get_head_delete(self):
        data = b'{"gate": "D", "payload": [1, 2, 3]}'
        ref = self.store.put_candidate(data, "application/json")
        sha = hashlib.sha256(data).hexdigest()
        self.assertEqual(ref["uri"], CANDIDATE_PREFIX + sha)
        self.assertEqual(ref["sha256"], sha)
        self.assertEqual(ref["size"], len(data))
        # staged bytes readable, head agrees
        self.assertEqual(self.store.get(ref["uri"]), data)
        head = self.store.head(ref["uri"])
        self.assertEqual(head["size"], len(data))
        self.assertEqual(head["sha256"], sha)
        # promote -> durable object URI, bytes identical, candidate kept
        final = self.store.promote(ref["uri"])
        self.assertEqual(final, OBJECT_PREFIX + sha)
        self.assertEqual(self.store.get(final), data)
        self.assertEqual(self.store.head(final)["size"], len(data))
        # delete removes; head then reports nothing
        self.store.delete(final)
        self.assertIsNone(self.store.head(final))
        self.store.delete(ref["uri"])
        self.assertIsNone(self.store.head(ref["uri"]))

    def test_put_candidate_is_content_addressed_and_idempotent(self):
        a = self.store.put_candidate(b"same bytes")
        b = self.store.put_candidate(b"same bytes")
        self.assertEqual(a, b)
        c = self.store.put_candidate(b"other bytes")
        self.assertNotEqual(a["uri"], c["uri"])

    def test_factory_defaults_to_local(self):
        with tempfile.TemporaryDirectory() as root:
            client = factory_from_env({"FACTORY_STORAGE_ROOT": root})
            self.assertIsInstance(client, LocalStorage)


# ------------------------------------------------------------ stub S3
class _StubS3Handler(BaseHTTPRequestHandler):
    """In-memory S3 subset: PUT/GET/HEAD/DELETE /<bucket>/<key>.
    STUB EVIDENCE ONLY (see module docstring)."""
    objects = {}
    saw_auth = []

    def log_message(self, *a):
        pass

    def _key(self):
        parts = [p for p in self.path.split("/") if p]
        return "/".join(parts[1:])  # drop bucket

    def _auth_ok(self):
        auth = self.headers.get("Authorization") or ""
        type(self).saw_auth.append(auth)
        return auth.startswith("AWS4-HMAC-SHA256 Credential=") \
            and "SignedHeaders=" in auth and "Signature=" in auth

    def do_PUT(self):
        if not self._auth_ok():
            return self.send_response(403) or self.end_headers()
        body = self.rfile.read(int(self.headers.get("Content-Length") or 0))
        type(self).objects[self._key()] = (
            body, self.headers.get("Content-Type") or "application/octet-stream")
        self.send_response(200)
        self.send_header("Content-Length", "0")
        self.end_headers()

    def do_GET(self):
        if not self._auth_ok():
            return self.send_response(403) or self.end_headers()
        item = type(self).objects.get(self._key())
        if item is None:
            self.send_response(404)
            self.end_headers()
            return
        self.send_response(200)
        self.send_header("Content-Length", str(len(item[0])))
        self.send_header("Content-Type", item[1])
        self.end_headers()
        self.wfile.write(item[0])

    def do_HEAD(self):
        if not self._auth_ok():
            return self.send_response(403) or self.end_headers()
        item = type(self).objects.get(self._key())
        if item is None:
            self.send_response(404)
            self.end_headers()
            return
        self.send_response(200)
        self.send_header("Content-Length", str(len(item[0])))
        self.end_headers()

    def do_DELETE(self):
        if not self._auth_ok():
            return self.send_response(403) or self.end_headers()
        type(self).objects.pop(self._key(), None)
        self.send_response(204)
        self.end_headers()


class TestS3StorageAgainstStub(unittest.TestCase):
    """STUB EVIDENCE: S3 client mechanics vs an in-test stub endpoint."""

    @classmethod
    def setUpClass(cls):
        _StubS3Handler.objects = {}
        _StubS3Handler.saw_auth = []
        cls.server = ThreadingHTTPServer(("127.0.0.1", 0), _StubS3Handler)
        cls.port = cls.server.server_address[1]
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()

    def setUp(self):
        _StubS3Handler.objects = {}
        _StubS3Handler.saw_auth = []
        self.store = S3Storage(f"http://127.0.0.1:{self.port}", "factory-bucket",
                               "test-access", "test-secret", "us-east-1")

    def test_stub_round_trip_promote_delete(self):
        data = b"s3-stub-payload"
        ref = self.store.put_candidate(data, "text/plain")
        sha = hashlib.sha256(data).hexdigest()
        self.assertEqual(ref["uri"], CANDIDATE_PREFIX + sha)
        self.assertIn(f"candidates/{sha}", _StubS3Handler.objects)
        self.assertEqual(self.store.get(ref["uri"]), data)
        self.assertEqual(self.store.head(ref["uri"])["size"], len(data))
        final = self.store.promote(ref["uri"])
        self.assertEqual(final, OBJECT_PREFIX + sha)
        self.assertIn(f"objects/{sha}", _StubS3Handler.objects)
        self.assertEqual(self.store.get(final), data)
        self.store.delete(final)
        self.assertIsNone(self.store.head(final))
        # every request carried a well-formed SigV4 Authorization header
        self.assertTrue(_StubS3Handler.saw_auth)
        self.assertTrue(all(a.startswith("AWS4-HMAC-SHA256 Credential=test-access/")
                            for a in _StubS3Handler.saw_auth))

    def test_stub_missing_object(self):
        missing = CANDIDATE_PREFIX + "0" * 64
        self.assertIsNone(self.store.head(missing))
        with self.assertRaises(FileNotFoundError):
            self.store.get(missing)


if __name__ == "__main__":
    unittest.main(verbosity=2)
