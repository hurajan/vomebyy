# GATE D REPORT — Durable storage, finance completion, D-C1 correction

**Status: GATE D COMPLETE + INDEPENDENTLY VERIFIED, defects NONE — ACCEPTED by Raj 2026-10-28, who also CONFIRMED the Gate E lock as planned.** Lock: LOCK_GATE_D.md (Gate C accepted + D-C1 correction ordered + Gate D lock confirmed by Raj 2026-10-28). Evidence: suite logs in `evidence/logs/`, `evidence/CHANGED_ASSERTIONS.md`, verifier report `evidence/GATE_D_VERIFIER_REPORT.md`.

## Results

**Suites (116 total, all green):** G1 9/9 · G2 58/58 · G3 14/14 · G4 2/2 · G5 1/1 · G6 3/3 · G7 2/2 · G8 1/1 · G9 9/9 · worker_service 11/11 · storage_service 5/5. Verifier read the final logs directly (earlier failed intermediate runs are preserved alongside as `*_first.log`, noted as transparency, not defects).

- **D-C1 correction — done as ordered.** API claims now enforce the resolved config estimate (verifier's own HTTP probes: body 100 against a 900 binding → 409 + exactly one `estimate_below_config` audit row; body 950 → reservation 900; no body estimate → 900). Library claim behavior unchanged (same probe at library level → 100), so unit tests keep their deliberate estimates.
- **Storage.** StorageClient interface with LocalStorage (content-addressed, atomic publish) and S3Storage (stdlib SigV4; mechanics proven against a local stub endpoint — real object storage NOT TESTED, endpoint remains deployment config). Coordinator stage → verify → promote: verifier staged bytes, completed by candidate, and read the exact bytes back from the promoted object; a hash mismatch refused completion with nothing registered; cleanup abandoned a backdated STAGED candidate and deleted its bytes while leaving the PROMOTED one untouched. Caller-supplied storage URIs remain the recorded URI with the staged bytes as the durable copy behind them — which is why every station suite and the G9 bridge stayed green untouched.
- **Finance.** Pricing rules (migration 012) drive CALCULATED evidence with exact arithmetic (verifier: 1000×0.5¢ + 500×1.0¢ = 1000¢ at pricing version pv1), and settlement now charges the FINALIZED amount, not the worker's assertion (that production settled 1000, not 90). Finalization rule verified in both directions: reported 1050 within 10% tolerance → FINALIZED 1050 (provider_reported); reported 1500 outside → FINALIZED falls back to the calculated 1000.
- **`settle_provider_charge`**: standalone CHARGE moves spent exactly once (verifier: three settles, +100 each, flags cleared, repeat settle refused). **Soft ceiling**: crossing produced exactly one audit event + one outbox notification; a further settle above the line added neither.
- **Contract**: 32 endpoints (stage, pricing-rules, financial-evidence list + settle added). Dashboard byte-identical to the Gate A manifest — still untouched by this programme.

## Changed pre-existing assertions

Exactly one (documented): `test_gatec.py`'s FINALIZED usage exact-equality became key-wise checks, forced by the lock's requirement to record the finalization basis inside the usage JSON. Plus a harness-only template normalization in the contract test.

## Honest limits

Real S3 NOT TESTED (stub mechanics only). The station workers still write their own per-tree stores on the n8n path — Gate D built and proved the durable path at coordinator/API/worker-service level; rewiring the stations onto it is Gate G, and removing the G9 copy bridge happens there too.

## Next gate as planned (Gate E — needs its own lock)

Independent evaluation: a validation service that (1) executes the 32 registry step-contract schemas as real input/output validation, (2) runs deterministic technical checks (hashes, sizes, formats, reference resolution), (3) runs continuity checks against the CURRENT input artifacts, and (4) can call the configured semantic adapter — with worker verdicts demoted to advisory evidence and `/validate` outcomes produced by the service, not the executor. The Golden Set arming rule stays exactly as-is (50+ EXPERT required; today 12 SEED / 0 EXPERT — Gate E builds the machinery and records the calibration limitation, it does not arm anything).
