# Gate D — pre-existing test changes

## Changed assertions (1)

1. **`video-factory-g2/tests/test_gatec.py::TestFinancialEvidence::test_estimated_and_finalized_rows`**
   — final assertion `ev[1]["usage"] == {"input_tokens": 10}` replaced by
   key-wise checks (`usage["input_tokens"] == 10` and
   `usage["_finalization_basis"] == "reported_actual"`).
   **Why forced:** LOCK_GATE_D §4 requires the FINALIZED evidence row to
   record its finalization basis inside the usage JSON
   (`_finalization_basis`, plus `_pricing_version` when a price book
   applied). The worker-supplied usage is still preserved verbatim; the
   exact-equality assertion on the whole JSON object is incompatible with
   the mandated extra key. No other part of the test changed.

## Harness extensions (no assertions changed)

2. **`video-factory-g3/tests/test_api_contract.py`** — the two template
   normalization chains (`contract_keys` and the coverage `want` set) also
   replace `{evidence_id}` with `{id}`, so the Gate D settle endpoint
   template resolves like the other id templates. Gate D endpoint hits
   were added inside `test_all_endpoints` (required by its
   every-contract-endpoint-exercised coverage assertion), plus a new
   `TestApiGateD` class (5 tests) in the same file.

## New test files (additive only)

- `video-factory-g2/tests/test_gated.py` — 16 tests (D-C1 API/library
  estimate modes, pricing/finalization, settle_provider_charge,
  soft-ceiling, candidate lifecycle).
- `video-factory-real-ai-programme/gate-d/storage_service/tests/test_storage.py`
  — 5 tests (Local round trip; S3 mechanics against an in-test stub
  endpoint, stub evidence only).

No station-suite (G4–G9), dashboard, walkthrough, or worker-service
assertions were changed.
