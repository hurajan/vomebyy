# GATE D VERIFIER REPORT — Independent verification

**Verdict: VERIFIED — all eight items CONFIRMED. Defects: NONE (no CRITICAL, MAJOR, or MINOR).**

Verifier method: builder's logs read from disk; all behavioral claims re-proven with the verifier's own probes against a self-built scratch DB (`gated_verify_scratch`, dropped-in place, left for inspection) — HTTP probes against the real G3 API (port 8731, stopped after) and library probes against the real coordinator. No product code was modified.

## 1. Logs — CONFIRMED

Final logs in `gate-d/evidence/logs/`: g1 "Ran 9, OK"; g2 "Ran 58, OK"; g3 "Ran 14, OK"; g4 "Ran 2, OK"; g5 "Ran 1, OK"; g6 "Ran 3, OK"; g7 "Ran 2, OK"; g8 "Ran 1, OK"; g9 "Ran 9, OK"; worker_service "Ran 11, OK"; storage_service "Ran 5, OK" — matching the claimed counts exactly. Transparency note (not a defect): the directory also preserves `*_first.log` files from earlier failed intermediate runs (g2_first FAILED failures=1, g2_gated_first FAILED errors=1, g3_contract_first SyntaxError); the final logs supersede them.

## 2. Migrations 011/012 — CONFIRMED

Scratch DB built via `g2/tools/setup_db.py gated_verify_scratch`: **33 public tables**; `artifact_candidates` and `pricing_rules` present. Both migration files read in full: purely additive — `CREATE TABLE IF NOT EXISTS` + `CREATE INDEX IF NOT EXISTS` only, no ALTER/DROP of existing objects, correct state vocabulary (STAGED/PROMOTED/ABANDONED) and unit_kind vocabulary incl. NUMERIC(12,4) prices. The FACTORY seed binding resolves as provider `mock`, model `deterministic-mock`, est 100¢, environment `test`.

## 3. D-C1 correction at the API path — CONFIRMED (all four probes)

With an OPERATION binding (05.12, provider `probe`, est 900) seeded via POST /configs:
- **(a)** POST claim `{estimated_cents: 100}` → **409** ("caller estimate 100 is below the resolved OPERATION binding estimate 900"); exactly **1** `audit_events` row of type `estimate_below_config`.
- **(b)** POST claim `{estimated_cents: 950}` → 200; budget shows **reserved_cents = 900** (the config estimate, not 950).
- **(c)** Second unit (new production), claim with **no** `estimated_cents` → reserved **900**.
- **Library mode unchanged:** coordinator-library claim with `estimated_cents=100` under the same 900 binding → `held_cents = 100` (caller wins in library mode, as ordered).

## 4. Durable storage — CONFIRMED (library + API)

Coordinator with injected `LocalStorage` on a temp root:
- `stage_content(b'hello-bytes')` → candidate **STAGED** at `store://candidates/<sha256>`; complete with `candidate_uri` → candidate row **PROMOTED** with `promoted_artifact_id` = the registered artifact, artifact `storage_uri = store://objects/<sha256>`, and `storage.get` of the promoted object returns exactly `b'hello-bytes'`.
- Hash mismatch: complete with `expected_sha256` of different bytes → **ArtifactHashMismatchError**, **0 artifacts** registered for the unit, unit remains **CLAIMED** (attempt not completed).
- Cleanup: a second STAGED candidate backdated 2 h (direct SQL) → `cleanup_candidates(3600)` returns `{abandoned: 1}`, row **ABANDONED**, `head()` returns None (bytes gone); the PROMOTED candidate (also backdated) is untouched and its bytes still read back.
- API path: `POST /artifacts/stage` (base64 body) → **201**, candidate row STAGED with matching sha256/size.

## 5. Finance: pricing + finalization — CONFIRMED (exact amounts)

Price book seeded for provider `mock`, model NULL: input_token @ 0.5¢, output_token @ 1.0¢, `pricing_version='pv1'`. Usage `{input_tokens:1000, output_tokens:500}`, worker actual 90:
- Unit 1 (no report): **CALCULATED = 1000** (1000×0.5 + 500×1.0, version pv1); **FINALIZED = 1000**, basis `calculated`; production settled = **1000, not 90**.
- Unit 2 (reported 1050, request `req-2`, within 10%): **FINALIZED = 1050**, basis `provider_reported`; settled total 2050.
- Unit 3 (reported 1500, request `req-3`, outside tolerance): **FINALIZED = 1000**, basis `calculated`; settled total 3050.

## 6. settle_provider_charge + soft-ceiling — CONFIRMED

Production hard 100000 / soft 150; three flagged PROVIDER_REPORTED evidence rows (100 each, direct insert):
- Settle #1 → settled 100, one standalone CHARGE (reservation_id NULL), **0** soft-ceiling audits/outbox (below soft).
- Settle #2 → settled 200 (crossing) → **exactly 1** `soft_ceiling_crossed` audit + **exactly 1** outbox `notification`.
- Settle #3 → settled 300 → still exactly 1 + 1 (no duplicates).
- All three evidence rows' `requires_reconciliation` cleared; re-settling the first → **ChargeSettlementError** ("not an unsettled provider-reported charge"). Each settle moved spent by exactly 300 in total across the three.

## 7. Contract + scope — CONFIRMED

- `api_contract.json` lists **32 endpoints**, including `/artifacts/stage`, `GET/POST /pricing-rules`, `GET /productions/{pid}/financial-evidence`, `POST /financial-evidence/{evidence_id}/settle`.
- `g3/dashboard/index.html` SHA-256 = `c60d9070…` — **byte-identical to the Gate A manifest** (not edited in Gate D).
- Gate C's claim-node fix present in **all five** station generators: the claim body line (`estimated_cents: 100`) builds `worker_id` as `'n8n-station-' + $('Execute Workflow Trigger').item.json.station` in g4–g8 `tools/gen_workflows.py`.
- No credential literals: grep for `sk-` across the storage package, coordinator, and API server returns nothing.

## 8. Changed assertions — CONFIRMED

`CHANGED_ASSERTIONS.md` lists exactly one pre-existing assertion change, and the code matches: `test_gatec.py` lines 167–168 now assert `usage["input_tokens"] == 10` and `usage["_finalization_basis"] == "reported_actual"` key-wise (the whole-object equality is gone), forced by LOCK §4's mandated basis key. The only other delta is the documented harness normalization — `{evidence_id}` → `{id}` replacements present in `test_api_contract.py` (lines 41, 301) — plus additive Gate D tests (`test_gated.py`, storage tests). No station-suite, dashboard, or worker-service assertions changed.

## Defects

**NONE.** No CRITICAL, MAJOR, or MINOR defects found. One process observation, recorded for honesty and not counted as a defect: a second unit for the same operation cannot be planned twice in one run (pre-existing coordinator unit-key behavior, present since G2); the verifier's no-estimate probe used a second production instead — behavior is unchanged from prior gates and out of Gate D's scope.
