# GATE A VERIFIER REPORT — Real AI Execution Integration (baseline audit)

**Verifier verdict: VERIFIED — all nine Gate A claims CONFIRMED. Defects: NONE.**
Method: independent read-only inspection of the live filesystem, code, logs, and database on 2026-10-28. No product code was modified; the full test suites were not re-run (the Gate A logs are the evidence for claim 7, per brief).

## Claim-by-claim results

### 1. No Git repository in any factory tree — CONFIRMED
Checked `~/workspace/video-factory-g1` … `g9`: none contains a `.git` directory, and `git rev-parse --verify HEAD` resolves in none of them. There is no commit available to pin the baseline; the baseline can only be identified by file contents/hashes.

### 2. Registry state — CONFIRMED
`python3 ~/workspace/video-factory-g1/tools/registry_tool.py validate` exits 0 with verdict PASS, errors [] and warnings []:
- operations 192, dependencies 191, steps 16
- station split: 1→24, 2→24, 3→48, 4→36, 5→36, 6→24
- definition_hash `ea4503f516fc4f7940f187f5cd9dac38c57f0d239726cac90e2d0a18a8bc9d73`
- source_sha256 `0f3f38711c9761a67c161862feacbc72b08e1c172935691431e2f0cbbc8b7a8d`; contracts_checked 32

### 3. API contract — CONFIRMED
`g3/contracts/api_contract.json` contains exactly 22 endpoints, including `POST /units/{uid}/retry` with response `[unit_id, state]` (alongside claim/events/complete/validate for units).

### 4. Five coordinator functions are library-only — CONFIRMED
Text search for `scheduler_claim`, `reap_expired_leases`, `reconcile_once`, `submit_provider_job`, `handle_callback` across `g3/api`, `g4`–`g8` `tools/`, `workflows/`, `driver/`, and `g9/tools` (tests excluded) returned zero hits for every one of the five names. The functions exist only in `g2/coordinator/coordinator.py` (definitions) and its tests; nothing in the running system calls them.

### 5. No external AI/provider/storage client in the execution code — CONFIRMED (with two recorded nuances)
- No Python runtime module imports any provider SDK (`openai`, `anthropic`, `boto3`, `replicate`, `elevenlabs`, Azure/Google AI, `httpx`, `requests`): zero matches. The only `package.json` dependency in the trees is `n8n 2.45.5` (g4).
- Every workflow generator's base constants are local only: `API = "http://127.0.0.1:8730"` and `WORKER = "http://127.0.0.1:8790"` … `:8794` (g4–g8 respectively). All URLs found in generated workflows, drivers, workers, and setup tools point at 127.0.0.1 ports 5678 (n8n itself), 8730, 8790–8794.
- Nuance A (not a defect): provider *names* do occur once in code — `g1/tools/registry_tool.py` lines 19–23 define `PROVIDER_BLOCKLIST` (openai, anthropic, elevenlabs, openrouter, aws bedrock, runway, …) used to keep the registry provider-neutral. This is a blocklist, not a client, credential, or endpoint.
- Nuance B (not a defect): the only non-localhost URL literals anywhere in the scanned code/contracts are `https://json-schema.org/draft/2020-12/schema` `$schema` identifiers in g1's generated step contract schemas. They are schema identifiers, never fetched endpoints.

### 6. Workers are mock-only; costs hardcoded — CONFIRMED
All five `workers/mock_workers.py` (g4–g8): on the success path the response is unconditionally `"verdict": "PASS"` with `actual_cost_cents` 90 — literal `90` in g4; `COST = 90` in g5–g8. The only other branch is the test hook `force_fail` → HTTP 500. Every station's `tools/gen_workflows.py` claim body hardcodes `estimated_cents: 100`, and the generated `workflows/unit-executor.json` files carry the same `estimated_cents: 100`.

### 7. Baseline logs — CONFIRMED
Every log in `~/workspace/video-factory-real-ai-programme/gate-a/logs/` ends with the claimed result:
g1-tests "Ran 7 tests / OK"; g2-tests "Ran 25 tests / OK"; g3-tests "Ran 5 tests / OK"; g4-tests "Ran 2 tests / OK"; g5-tests "Ran 1 test / OK"; g6-tests "Ran 3 tests / OK"; g7-tests "Ran 2 tests / OK"; g8-tests "Ran 1 test / OK"; g9-fullrun "Ran 1 test / OK"; g9-failures "Ran 8 tests / OK". The accompanying setup logs (g4–g8, g9) corroborate live environments: API/workers/n8n up, workflows synced + active, g9 setup pointing the API at `g9_fullrun_scratch`.

### 8. F-G9-01 and F-G9-02 still present in code — CONFIRMED
- F-G9-01: `g1/tools/registry_tool.py` line 198: `INSERT INTO dependency_templates VALUES ('1.0.0',%s,%s,%s)` — the workflow version is a hardcoded literal, so a non-1.0.0 seed's dependency templates would be stamped 1.0.0 / the loaded version gets none.
- F-G9-02: `g2/coordinator/coordinator.py` `create_gate` (line 553) performs an unconditional `INSERT INTO human_gates(...)` after only an artifact-existence check — no lookup for an existing gate on (production, kind, artifact) and no deduplication, before or after a decision.

### 9. Database state (setup-chain build) — CONFIRMED
PostgreSQL 16 cluster online. Queried `g9_fullrun_scratch` as role `factory`:
- public base tables: 29
- `operation_definitions`: 192
- `dependency_templates`: 191
- `capability_versions`: 29
- `gate_requirements`: `script→HG2`, `master_package→HG4`, `derivative_package→HG5` (exactly three rows)

## Additional material facts (not defects against the claims)

1. Claim 5's "no provider names" framing needs the blocklist nuance in §5 recorded wherever the baseline is cited: provider names exist in the registry tool as a neutrality blocklist only. Anyone grepping naively will hit them; they are not integrations.
2. The baseline has no version-control anchor at all (claim 1): Gate B+ changes cannot be diffed against a commit. The only baseline pins available are the registry definition_hash (claim 2) and per-file hashes, should the programme choose to record them.
3. The database corroborates claim 4 structurally: `provider_jobs`, `callback_deliveries`, and `outbox_events` tables exist in the 29-table schema while their coordinator functions have no runtime callers — implemented-but-unwired, exactly as the Gate A classification states.
4. The Gate A run leaves ten scratch databases on the cluster (g2, three g3 test DBs, g4–g8 station DBs, g9_fullrun); the shared API was last pointed at `g9_fullrun_scratch` by the g9 setup. Environment state, not product state — recorded so later gates do not mistake it for a deployment topology.

## Verdict

**VERIFIED.** All nine Gate A baseline claims are accurate against the filesystem, code, logs, and database as they stand. Defects: **NONE**. The two nuances in claim 5 are clarifications of wording, not counter-evidence: no external provider/storage client, endpoint, or credential exists in the execution path.
