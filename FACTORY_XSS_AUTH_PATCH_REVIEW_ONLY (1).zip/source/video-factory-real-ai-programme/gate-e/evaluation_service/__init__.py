"""Gate E evaluation service: registry-driven independent evaluation
(schema / technical / continuity / semantic layers), golden-case arming
registry, and the /evaluate submission service. See LOCK_GATE_E.md."""
