"""Gate E evaluation service.

Library entry: evaluate_unit(unit_id, loader, api_url, validator_token)
-> report dict. HTTP shell: POST /evaluate {unit_id}, GET /health.

The service evaluates a unit in VALIDATING using only coordinator data.
It never trusts the worker's verdict: any evaluation the worker recorded
for the artifact is quoted in the report as advisory evidence and is
never an input to the outcome. Layer evaluations are aggregated and
submitted in ONE POST /units/{uid}/validate call as the VALIDATOR role;
the coordinator's existing mapping decides the outcome (deterministic
FAIL -> BLOCKED, content FAIL -> REPAIR_REQUIRED, REVIEW_REQUIRED ->
AWAITING_HUMAN, all PASS -> ACCEPTED). If no layer could actually run,
nothing is submitted and the unit is left in VALIDATING.

Env: FACTORY_DSN, FACTORY_API_URL (default http://127.0.0.1:8730),
FACTORY_VALIDATOR_TOKEN, FACTORY_ENVIRONMENT (default test),
FACTORY_EVAL_PORT (default 8950), FACTORY_STORAGE_* (Gate D storage).
"""
import json
import os
import sys
import urllib.error
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import golden  # noqa: E402
import layers  # noqa: E402
from context import ContextLoader, UnitNotFound  # noqa: E402

def _default_dsn():
    """Dev-default DSN (scratch DB), sourced from the G3 test fixture so
    the local dev credential lives in exactly one place in the codebase."""
    g3_tests = str(Path.home() / "workspace/video-factory-g3/tests")
    if g3_tests not in sys.path:
        sys.path.insert(0, g3_tests)
    from server_fixture import make_dsn
    return make_dsn("g3_dashboard_scratch")


DSN = os.environ.get("FACTORY_DSN") or _default_dsn()
API_URL = os.environ.get("FACTORY_API_URL", "http://127.0.0.1:8730")
VALIDATOR_TOKEN = os.environ.get("FACTORY_VALIDATOR_TOKEN")
ENVIRONMENT = os.environ.get("FACTORY_ENVIRONMENT", "test")
PORT = int(os.environ.get("FACTORY_EVAL_PORT", "8950"))


def evaluate_unit(unit_id, loader, api_url, validator_token):
    ctx = loader.load(unit_id)
    unit = ctx["unit"]
    if unit["state"] != "VALIDATING":
        return {"unit_id": unit_id, "submitted": False,
                "reason": f"unit is {unit['state']}, not VALIDATING",
                "state": unit["state"]}
    artifact = ctx["output_artifact"]
    advisory = loader.advisory_evaluations(artifact["artifact_id"] if artifact else None)
    results = [
        layers.schema_layer(ctx),
        layers.technical_layer(ctx),
        layers.continuity_layer(ctx),
        layers.semantic_layer(ctx, golden),
    ]
    evaluations = [r["evaluation"] for r in results if r["evaluation"] is not None]
    any_applied = any(r["applied"] for r in results)
    report = {
        "unit_id": unit_id,
        "operation_id": unit["operation_id"],
        "output_artifact_id": artifact["artifact_id"] if artifact else None,
        "layers": [r["report"] for r in results],
        "advisory_worker_evaluations": advisory,
        "submitted": False,
    }
    if not evaluations or not any_applied:
        report["reason"] = "no_applicable_layers"
        report["state"] = unit["state"]
        return report
    body = json.dumps({"evaluations": evaluations}).encode()
    req = urllib.request.Request(f"{api_url}/units/{unit_id}/validate",
                                 data=body, method="POST")
    req.add_header("Content-Type", "application/json")
    req.add_header("X-Role", "VALIDATOR")
    if validator_token:
        req.add_header("X-Role-Token", validator_token)
    req.add_header("X-Identity", "evaluation-service")
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            out = json.loads(resp.read() or b"{}")
    except urllib.error.HTTPError as e:
        report["submission_error"] = {"status": e.code,
                                      "body": e.read().decode(errors="replace")[:400]}
        report["state"] = unit["state"]
        return report
    report["submitted"] = True
    report["resulting_state"] = out.get("state")
    return report


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, *a):  # quiet
        pass

    def _send(self, status, obj):
        body = json.dumps(obj, default=str).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if self.path == "/health":
            seed_n, expert_n = golden.counts()
            return self._send(200, {"status": "ok", "service": "evaluation",
                                    "armed": golden.armed(),
                                    "expert_cases": expert_n,
                                    "seed_cases": seed_n,
                                    "environment": ENVIRONMENT})
        return self._send(404, {"error": "no such route"})

    def do_POST(self):
        if self.path != "/evaluate":
            return self._send(404, {"error": "no such route"})
        try:
            n = int(self.headers.get("Content-Length") or 0)
            body = json.loads(self.rfile.read(n) or b"{}")
            unit_id = body.get("unit_id")
            if not unit_id:
                return self._send(400, {"error": "missing unit_id"})
            loader = ContextLoader(DSN, environment=ENVIRONMENT)
            try:
                report = evaluate_unit(unit_id, loader, API_URL, VALIDATOR_TOKEN)
            finally:
                loader.close()
            if report.get("reason", "").startswith("unit is "):
                return self._send(409, report)
            return self._send(200, report)
        except UnitNotFound as e:
            return self._send(404, {"error": str(e)})
        except Exception as e:  # noqa: BLE001
            return self._send(500, {"error": f"{type(e).__name__}: {e}"})


def main():
    server = ThreadingHTTPServer(("127.0.0.1", PORT), Handler)
    print(f"Gate E evaluation service on http://127.0.0.1:{PORT} "
          f"(POST /evaluate, GET /health; environment={ENVIRONMENT})")
    server.serve_forever()


if __name__ == "__main__":
    main()
