"""Subset JSON-Schema engine for the 32 factory step contracts.

Why a subset engine: the `jsonschema` package is importable in the system
python3 on this host but NOT in the g2/g3 virtualenvs the factory services
run under, and Gate E may not assume network access to install it. The lock
therefore sanctions a documented subset covering exactly the constructs the
32 contract files use.

Constructs enumerated across all 32 files in
~/workspace/video-factory-g1/contracts/ (machine-counted):
    type (object/string/array/integer only), required, properties,
    additionalProperties (boolean only), pattern, items (single schema
    dict only), minimum, enum, const, plus the annotation keywords
    $schema / $id / title (ignored semantically).

Any other keyword, `items` as a list, or `additionalProperties` as a schema
raises UnsupportedConstruct: the schema layer FAILS CLOSED on it (a
deterministic FAIL naming the construct), never a silent pass.

Semantics follow JSON Schema draft 2020-12 for the supported constructs:
`pattern` is an unanchored search; `integer` excludes booleans (Python's
bool is an int subclass, JSON's is not); enum/const use JSON equality
(1 != true).
"""
import re

ANNOTATION_KEYWORDS = {"$schema", "$id", "title"}
SUPPORTED_KEYWORDS = ANNOTATION_KEYWORDS | {
    "type", "required", "properties", "additionalProperties", "pattern",
    "items", "minimum", "enum", "const",
}


class UnsupportedConstruct(Exception):
    def __init__(self, keyword, path):
        super().__init__(f"unsupported schema construct {keyword!r} at {path}")
        self.keyword = keyword
        self.path = path


def _json_equal(a, b):
    if isinstance(a, bool) != isinstance(b, bool):
        return False
    if isinstance(a, (int, float)) and isinstance(b, (int, float)) \
            and not isinstance(a, bool) and not isinstance(b, bool):
        return a == b
    if type(a) is not type(b):
        return False
    if isinstance(a, dict):
        return a.keys() == b.keys() and all(_json_equal(a[k], b[k]) for k in a)
    if isinstance(a, list):
        return len(a) == len(b) and all(_json_equal(x, y) for x, y in zip(a, b))
    return a == b


def _type_ok(instance, type_name):
    if type_name == "object":
        return isinstance(instance, dict)
    if type_name == "array":
        return isinstance(instance, list)
    if type_name == "string":
        return isinstance(instance, str)
    if type_name == "integer":
        return isinstance(instance, int) and not isinstance(instance, bool)
    if type_name == "number":
        return isinstance(instance, (int, float)) and not isinstance(instance, bool)
    if type_name == "boolean":
        return isinstance(instance, bool)
    if type_name == "null":
        return instance is None
    raise UnsupportedConstruct(f"type:{type_name}", "$")


def check_schema_supported(schema, path="$"):
    """Return a list of unsupported-construct descriptions found anywhere in
    the schema (empty list = the subset engine fully covers this schema)."""
    problems = []
    if isinstance(schema, bool):
        return problems
    if not isinstance(schema, dict):
        return [f"schema at {path} is not an object"]
    for key, value in schema.items():
        if key not in SUPPORTED_KEYWORDS:
            problems.append(f"{key!r} at {path}")
        elif key == "additionalProperties" and not isinstance(value, bool):
            problems.append(f"'additionalProperties' as schema at {path}")
        elif key == "items" and not isinstance(value, (dict, bool)):
            problems.append(f"'items' as list at {path}")
        elif key == "pattern":
            try:
                re.compile(value)
            except Exception as e:  # noqa: BLE001
                problems.append(f"invalid 'pattern' at {path}: {e}")
        elif key in ("properties",) and isinstance(value, dict):
            for name, sub in value.items():
                problems.extend(check_schema_supported(sub, f"{path}.properties.{name}"))
        elif key == "items" and isinstance(value, dict):
            problems.extend(check_schema_supported(value, f"{path}.items"))
        elif key == "additionalProperties" and isinstance(value, dict):
            problems.extend(check_schema_supported(value, f"{path}.additionalProperties"))
    return problems


def validate(instance, schema, path="$"):
    """Return a list of violations [{path, message}]; empty = valid.
    Raises UnsupportedConstruct on any construct outside the subset."""
    violations = []
    if isinstance(schema, bool):
        if not schema:
            violations.append({"path": path, "message": "schema is false"})
        return violations
    for key in schema:
        if key not in SUPPORTED_KEYWORDS:
            raise UnsupportedConstruct(key, path)

    if "const" in schema and not _json_equal(instance, schema["const"]):
        violations.append({"path": path,
                           "message": f"expected const {schema['const']!r}"})
    if "enum" in schema and not any(_json_equal(instance, v) for v in schema["enum"]):
        violations.append({"path": path,
                           "message": f"value {instance!r} not in enum {schema['enum']!r}"})
    if "type" in schema:
        if not _type_ok(instance, schema["type"]):
            violations.append({"path": path,
                               "message": f"expected type {schema['type']}, "
                                          f"got {type(instance).__name__}"})
            return violations  # deeper checks are meaningless on a type miss
    if "minimum" in schema and isinstance(instance, (int, float)) \
            and not isinstance(instance, bool):
        if instance < schema["minimum"]:
            violations.append({"path": path,
                               "message": f"{instance} < minimum {schema['minimum']}"})
    if "pattern" in schema and isinstance(instance, str):
        if re.search(schema["pattern"], instance) is None:
            violations.append({"path": path,
                               "message": f"{instance!r} does not match "
                                          f"pattern {schema['pattern']!r}"})
    if isinstance(instance, dict):
        for req in schema.get("required", []):
            if req not in instance:
                violations.append({"path": path,
                                   "message": f"missing required property {req!r}"})
        props = schema.get("properties", {})
        for name, sub in props.items():
            if name in instance:
                violations.extend(validate(instance[name], sub, f"{path}.{name}"))
        ap = schema.get("additionalProperties", True)
        if ap is False:
            for name in instance:
                if name not in props:
                    violations.append({"path": f"{path}.{name}",
                                       "message": f"additional property {name!r} not allowed"})
        elif isinstance(ap, dict):
            raise UnsupportedConstruct("additionalProperties:schema", path)
    if isinstance(instance, list) and "items" in schema:
        items = schema["items"]
        if not isinstance(items, (dict, bool)):
            raise UnsupportedConstruct("items:list", path)
        for i, element in enumerate(instance):
            violations.extend(validate(element, items, f"{path}[{i}]"))
    return violations
