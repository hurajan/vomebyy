"""Evaluation context loading: coordinator data + Gate D storage bytes.

The service is a trusted internal service: it reads the coordinator's
tables directly (the coordinator remains the only writer; submission
goes back through the API as the VALIDATOR role). Artifact bytes are
loaded content-addressably from the Gate D store: Gate D stages every
completion's bytes under objects/<sha256>, so the object URI is derived
from the artifact's recorded sha256 — this works regardless of the
recorded storage_uri (mock-store://, local://, ...). When the object is
absent the bytes are reported unavailable and byte-dependent checks
record {applied: False, reason: 'bytes_unavailable'} instead of guessing.
"""
import json
import sys
import uuid
from pathlib import Path

import psycopg
from psycopg.rows import dict_row

GATE_D = Path.home() / "workspace/video-factory-real-ai-programme/gate-d"
if str(GATE_D) not in sys.path:
    sys.path.insert(0, str(GATE_D))
from storage_service import factory_from_env, final_uri  # noqa: E402


class UnitNotFound(Exception):
    pass


def _stringify(row):
    """psycopg returns uuid columns as UUID objects; the layers and the
    JSON report work with plain strings."""
    if row is None:
        return None
    return {k: (str(v) if isinstance(v, uuid.UUID) else v) for k, v in row.items()}


class ContextLoader:
    def __init__(self, dsn, environment="test", storage=None):
        self.conn = psycopg.connect(dsn, row_factory=dict_row, autocommit=True)
        self.environment = environment
        self._storage = storage

    @property
    def storage(self):
        if self._storage is None:
            self._storage = factory_from_env()
        return self._storage

    @storage.setter
    def storage(self, client):
        self._storage = client

    def close(self):
        self.conn.close()

    def _bytes_for(self, artifact_row):
        try:
            return self.storage.get(final_uri(artifact_row["sha256"]))
        except Exception:  # noqa: BLE001 — absent object = bytes unavailable
            return None

    def _bytes_for_sha(self, sha256):
        """Bytes for a store object by sha256 (MM-07: media bytes and
        id-declaring artifacts the coverage/reference checks resolve
        against). None when the object is absent."""
        if not sha256:
            return None
        try:
            return self.storage.get(final_uri(sha256))
        except Exception:  # noqa: BLE001 — absent object = bytes unavailable
            return None

    def load(self, unit_id):
        cur = self.conn.cursor()
        cur.execute("SELECT * FROM execution_units WHERE unit_id=%s", (unit_id,))
        unit = _stringify(cur.fetchone())
        if not unit:
            raise UnitNotFound(f"unknown unit {unit_id}")
        cur.execute(
            "SELECT * FROM operation_definitions WHERE workflow_version=%s AND operation_id=%s",
            (unit["workflow_version_ref"], unit["operation_id"]))
        operation = _stringify(cur.fetchone())
        if operation is not None and isinstance(operation.get("validator_policy"), str):
            operation["validator_policy"] = json.loads(operation["validator_policy"])
        cur.execute(
            "SELECT output_artifact_id FROM action_attempts WHERE unit_id=%s AND attempt_no=%s",
            (unit_id, unit["current_attempt"]))
        attempt = cur.fetchone()
        output_artifact = None
        if attempt and attempt["output_artifact_id"]:
            cur.execute("SELECT * FROM artifacts WHERE artifact_id=%s",
                        (attempt["output_artifact_id"],))
            output_artifact = _stringify(cur.fetchone())
        cur.execute(
            "SELECT a.* FROM unit_inputs ui JOIN artifacts a ON a.artifact_id=ui.artifact_id"
            " WHERE ui.unit_id=%s", (unit_id,))
        input_artifacts = [_stringify(r) for r in cur.fetchall()]
        cur.execute("SELECT * FROM artifacts WHERE production_id=%s",
                    (unit["production_id"],))
        all_rows = [_stringify(r) for r in cur.fetchall()]
        all_by_id = {r["artifact_id"]: r for r in all_rows}
        current_by_sha = {r["sha256"]: r for r in all_rows if r["state"] == "CURRENT"}
        for inp in input_artifacts:
            inp["content_bytes"] = self._bytes_for(inp)
        # Gate G: the 14.12 op-specific check falls back to the
        # production's CURRENT derivative_portfolio when the portfolio
        # was not a planned input; give those rows bytes too.
        for row in all_rows:
            if row["artifact_type"] == "derivative_portfolio" \
                    and "content_bytes" not in row:
                row["content_bytes"] = self._bytes_for(row)
        output_bytes = self._bytes_for(output_artifact) if output_artifact else None
        loader = self

        def resolve_qa_binding():
            """QA binding (semantic layer): CAPABILITY -> OPERATION ->
            FACTORY, active rows of this service's environment only."""
            probes = [
                ("scope='CAPABILITY' AND capability_slot=%s", (operation["capability_slot"],)),
                ("scope='OPERATION' AND operation_id=%s", (unit["operation_id"],)),
                ("scope='FACTORY'", ()),
            ]
            c2 = loader.conn.cursor()
            for where, params in probes:
                c2.execute(
                    f"SELECT * FROM provider_configs WHERE active AND environment=%s AND {where}"
                    " ORDER BY version DESC LIMIT 1",
                    (loader.environment, *params))
                row = c2.fetchone()
                if row:
                    return row
            return None

        return {
            "production_id": unit["production_id"],
            "unit": unit, "operation": operation,
            "output_artifact": output_artifact, "output_bytes": output_bytes,
            "input_artifacts": input_artifacts,
            "planned_input_ids": [r["artifact_id"] for r in input_artifacts],
            "all_by_id": all_by_id, "current_by_sha": current_by_sha,
            "environment": self.environment,
            "fetch_bytes_by_sha": loader._bytes_for_sha,
            "resolve_qa_binding": resolve_qa_binding,
        }

    def advisory_evaluations(self, artifact_id):
        """Quality evaluations already recorded for the artifact (e.g. a
        worker's self-assessment). Advisory only: quoted in the report,
        never an input to the service's outcome."""
        if not artifact_id:
            return []
        cur = self.conn.cursor()
        cur.execute(
            "SELECT validator_id, method, verdict, evaluator_identity, evidence, created_at"
            " FROM quality_evaluations WHERE artifact_id=%s ORDER BY created_at",
            (artifact_id,))
        out = []
        for row in cur.fetchall():
            row = dict(row)
            row["created_at"] = str(row["created_at"])
            out.append(row)
        return out
