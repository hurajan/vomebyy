"""MM-10 fix F-MM10-02 — references_resolve position rule.

Unit tests for the redefined extraction rule in refs.py: a string
counts as an artifact reference only in a reference position (id
keys, depends_on, paired pins); computed digests and store-object
shas in data positions are never extracted. Layer-level cases run
the technical layer on synthetic contexts (test_mm07_checks
pattern): digest-in-data-field PASSes, a dangling id in a ref field
FAILs naming the value, and a CURRENT artifact's sha in a paired
pin PASSes while a wrong pin FAILs sha_not_current.

No DB, no API, no network."""
import hashlib
import json
import sys
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
PKG = HERE.parent
sys.path.insert(0, str(PKG))
import layers  # noqa: E402
import refs as refs_mod  # noqa: E402

PID = "mm10-fix-production"
HEX_A = "a" * 64
HEX_B = "b" * 64
HEX_C = "c" * 64
UUID_IN = "11111111-1111-4111-8111-111111111111"
UUID_OUT = "22222222-2222-4222-8222-222222222222"
UUID_DANGLING = "99999999-9999-4999-8999-999999999999"


def _sha(data):
    return hashlib.sha256(data).hexdigest()


def _values(found, kind):
    return [r["value"] for r in found[kind]]


class TestExtractionPositions(unittest.TestCase):
    def test_digest_positions_extract_no_shas(self):
        doc = {
            "kind": "attested_record",
            "derived": {
                "records.attest": {
                    "algorithm": "sha256",
                    "attestation_sha256": HEX_A,
                    "input_sha256": [HEX_B, HEX_C],
                    "pinned_count": 2},
                "content.analyze": {
                    "analyses": [{"artifact_id": UUID_IN,
                                  "artifact_type": "script",
                                  "sha256": HEX_B, "kind": "json_object"}],
                    "count": 1},
                "media_generate": {
                    "media_output": {"sha256": HEX_C,
                                     "storage_uri":
                                         f"store://objects/{HEX_C}",
                                     "size": 12345}},
                "record.compose": {"content_sha256": HEX_A}},
            "source_sha256": [HEX_A, HEX_B],
            "asset_hashes": [HEX_B],
            "sha256": HEX_A,
        }
        found = refs_mod.extract_refs(doc)
        self.assertEqual(_values(found, "shas"), [])
        # The one genuine reference position in the doc — the analyzed
        # artifact's id — is still extracted as an id.
        self.assertEqual(_values(found, "artifact_ids"), [UUID_IN])

    def test_paired_pin_extracted(self):
        doc = {"kind": "master_package",
               "timeline_ref": UUID_IN, "timeline_sha256": HEX_A,
               "registry_ref": UUID_DANGLING, "registry_sha256": HEX_B}
        found = refs_mod.extract_refs(doc)
        self.assertEqual(sorted(_values(found, "shas")), [HEX_A, HEX_B])
        self.assertEqual(sorted(_values(found, "artifact_ids")),
                         [UUID_IN, UUID_DANGLING])

    def test_unpaired_sha_fields_not_extracted(self):
        self.assertEqual(_values(refs_mod.extract_refs(
            {"timeline_sha256": HEX_A}), "shas"), [])
        # A non-UUID story id under *_ref does not create a pin pair.
        self.assertEqual(_values(refs_mod.extract_refs(
            {"source_ref": "S1", "source_sha256": HEX_A}), "shas"), [])

    def test_ref_field_carrying_a_sha(self):
        found = refs_mod.extract_refs({"master_ref": HEX_A})
        self.assertEqual(_values(found, "shas"), [HEX_A])
        found = refs_mod.extract_refs({"depends_on": [HEX_B]})
        self.assertEqual(_values(found, "shas"), [HEX_B])

    def test_store_uri_only_in_reference_fields(self):
        found = refs_mod.extract_refs(
            {"master_ref": f"store://objects/{HEX_A}"})
        self.assertEqual(_values(found, "shas"), [HEX_A])
        found = refs_mod.extract_refs(
            {"storage_uri": f"store://objects/{HEX_A}",
             "media_output": {"storage_uri": f"store://objects/{HEX_B}"}})
        self.assertEqual(_values(found, "shas"), [])

    def test_null_refs_follow_positions(self):
        found = refs_mod.extract_refs({"canon_refs": [None]})
        self.assertEqual(found["null_refs"], 1)
        found = refs_mod.extract_refs(
            {"timeline_ref": UUID_IN, "timeline_sha256": None})
        self.assertEqual(found["null_refs"], 1)
        found = refs_mod.extract_refs({"attestation_sha256": None})
        self.assertEqual(found["null_refs"], 0)


def _art(aid, atype, content=None, state="CURRENT"):
    return {"artifact_id": aid, "artifact_type": atype, "version": 1,
            "state": state, "production_id": PID,
            "sha256": _sha(content) if content is not None else "0" * 64,
            "storage_uri": "mm10-fix://artifact",
            "content_bytes": content}


def _ctx(op, content, inputs=()):
    out = _art(UUID_OUT, "story_architecture", content)
    all_by_id = {out["artifact_id"]: out}
    for row in inputs:
        all_by_id[row["artifact_id"]] = row
    return {
        "production_id": PID,
        "unit": {"unit_id": "mm10-fix-unit", "operation_id": op,
                 "current_attempt": 1},
        "operation": {"operation_id": op, "step_id": op.split(".")[0],
                      "capability_slot": "mm10_fix",
                      "validator_policy": ["schema_validation",
                                           "dependency_integrity"]},
        "output_artifact": out, "output_bytes": content,
        "input_artifacts": list(inputs),
        "planned_input_ids": [r["artifact_id"] for r in inputs],
        "all_by_id": all_by_id,
        "current_by_sha": {r["sha256"]: r for r in all_by_id.values()
                           if r["state"] == "CURRENT"},
        "environment": "test",
        "resolve_qa_binding": lambda: None,
        "fetch_bytes_by_sha": lambda sha: None,
    }


def _refcheck(result):
    for c in result["report"]["checks"]:
        if c["check"] == "references_resolve":
            return c
    raise AssertionError("no references_resolve check recorded")


def _doc(payload):
    return json.dumps(payload, sort_keys=True).encode()


class TestTechnicalLayerPositions(unittest.TestCase):
    def test_digest_in_data_field_passes(self):
        content = _doc({
            "kind": "attested_record",
            "derived": {
                "records.attest": {"attestation_sha256": HEX_A,
                                   "input_sha256": [HEX_B]},
                "media_generate": {
                    "media_output": {"sha256": HEX_C,
                                     "storage_uri":
                                         f"store://objects/{HEX_C}"}}}})
        result = layers.technical_layer(_ctx("05.12", content))
        check = _refcheck(result)
        self.assertTrue(check["ok"], check)
        self.assertEqual(check["sha_refs"], 0)
        self.assertEqual(result["report"]["verdict"], "PASS")

    def test_dangling_id_in_ref_field_fails_naming_it(self):
        content = _doc({"kind": "story_architecture",
                        "canon_refs": [UUID_DANGLING]})
        result = layers.technical_layer(_ctx("05.12", content))
        check = _refcheck(result)
        self.assertFalse(check["ok"])
        self.assertEqual(
            [(f["value"], f["reason"]) for f in check["failures"]],
            [(UUID_DANGLING, "artifact_not_found")])
        self.assertEqual(result["report"]["verdict"], "FAIL")

    def test_current_artifact_sha_in_paired_pin_passes(self):
        inp = _art(UUID_IN, "edit_timeline", b'{"kind": "edit_timeline"}')
        content = _doc({"kind": "master_package",
                        "timeline_ref": UUID_IN,
                        "timeline_sha256": inp["sha256"]})
        result = layers.technical_layer(_ctx("05.12", content, (inp,)))
        check = _refcheck(result)
        self.assertTrue(check["ok"], check)
        self.assertEqual(check["sha_refs"], 1)

    def test_wrong_paired_pin_fails_sha_not_current(self):
        inp = _art(UUID_IN, "edit_timeline", b'{"kind": "edit_timeline"}')
        content = _doc({"kind": "master_package",
                        "timeline_ref": UUID_IN,
                        "timeline_sha256": HEX_A})
        result = layers.technical_layer(_ctx("05.12", content, (inp,)))
        check = _refcheck(result)
        self.assertFalse(check["ok"])
        self.assertEqual(
            [(f["value"], f["reason"]) for f in check["failures"]],
            [(HEX_A, "sha_not_current")])

    def test_sha_in_ref_field_resolves_and_dangles(self):
        inp = _art(UUID_IN, "edit_timeline", b'{"kind": "edit_timeline"}')
        ok_content = _doc({"kind": "x", "master_ref": inp["sha256"]})
        result = layers.technical_layer(_ctx("05.12", ok_content, (inp,)))
        self.assertTrue(_refcheck(result)["ok"])
        bad_content = _doc({"kind": "x", "master_ref": HEX_B})
        result = layers.technical_layer(_ctx("05.12", bad_content, (inp,)))
        check = _refcheck(result)
        self.assertFalse(check["ok"])
        self.assertEqual(check["failures"][0]["reason"], "sha_not_current")


if __name__ == "__main__":
    unittest.main()
