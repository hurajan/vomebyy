"""MM-07 unit tests for the three new deterministic technical-layer
checks (internal_reference_integrity, input_set_coverage,
media_technical_validation) and the Rule-of-Six QA-binding threshold.

Synthetic contexts (golden.py style — no DB, no API): each test builds
the ctx dict the layers consume and asserts on the technical layer's
check entries + verdict, so a failure here is a failure of the check
itself, not of the harness. Media fixtures are real files generated
with the environment's ffmpeg (the same tooling MM-06 validated)."""
import hashlib
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
PKG = HERE.parent
sys.path.insert(0, str(PKG))
import layers  # noqa: E402

PID = "mm07-unit-production"
CANON = "11111111-1111-4111-8111-111111111111"


def _sha(data):
    return hashlib.sha256(data).hexdigest()


def art(aid, atype, content=None, state="CURRENT"):
    row = {"artifact_id": aid, "artifact_type": atype, "version": 1,
           "state": state, "production_id": PID,
           "sha256": _sha(content) if content is not None else "0" * 64,
           "storage_uri": "mm07-unit://artifact"}
    if content is not None:
        row["content_bytes"] = content
    return row


def make_ctx(op, content, artifact_type, inputs=(), extras=(), fetch=None,
             policy=("schema_validation", "dependency_integrity", "named_check")):
    out = art("22222222-2222-4222-8222-222222222222", artifact_type, content)
    all_by_id = {out["artifact_id"]: out}
    input_rows = []
    for row in inputs:
        input_rows.append(row)
        all_by_id[row["artifact_id"]] = row
    for row in extras:
        all_by_id[row["artifact_id"]] = row
    current_by_sha = {r["sha256"]: r for r in all_by_id.values()
                      if r["state"] == "CURRENT"}
    return {
        "production_id": PID,
        "unit": {"unit_id": "mm07-unit", "operation_id": op,
                 "current_attempt": 1},
        "operation": {"operation_id": op, "step_id": op.split(".")[0],
                      "capability_slot": "mm07_unit",
                      "validator_policy": list(policy)},
        "output_artifact": out, "output_bytes": content,
        "input_artifacts": input_rows,
        "planned_input_ids": [r["artifact_id"] for r in input_rows],
        "all_by_id": all_by_id, "current_by_sha": current_by_sha,
        "environment": "test",
        "resolve_qa_binding": lambda: None,
        "fetch_bytes_by_sha": fetch or (lambda sha: None),
    }


def check_named(result, name):
    for c in result["report"]["checks"]:
        if c["check"] == name:
            return c
    return None


def script_doc(lines_scenes=("SC1", "SC2"), payoff_line="L3"):
    lines = [{"id": "L1", "scene_ref": "SC1", "beat_ref": "B1",
              "story_ref": "S1", "canon_refs": [CANON], "text": "one"},
             {"id": "L2", "scene_ref": "SC2", "beat_ref": "B2",
              "story_ref": "S2", "canon_refs": [CANON], "text": "two"},
             {"id": "L3", "scene_ref": "SC1", "beat_ref": "B1",
              "story_ref": "S1", "canon_refs": [CANON], "text": "three"}]
    if lines_scenes == ("SC1",):
        lines = [l for l in lines if l["scene_ref"] == "SC1"]
    doc = {"kind": "script", "lines": lines,
           "trace": {"clues": [{"id": "CL1", "planted": "L1",
                                "payoff": payoff_line}],
                     "knowledge": [{"character": "Mara", "learns": "CL1",
                                    "at": "L2"}],
                     "payoffs": [{"id": "PO1", "clue": "CL1",
                                  "line": payoff_line}]},
           "canon_refs": [CANON]}
    return json.dumps(doc, sort_keys=True).encode()


def chain_extras():
    scene_set = json.dumps(
        {"kind": "scene_set",
         "scenes": [{"id": "SC1", "beat_ref": "B1", "canon_refs": [CANON]},
                    {"id": "SC2", "beat_ref": "B2", "canon_refs": [CANON]}],
         "canon_refs": [CANON]}, sort_keys=True).encode()
    beat_graph = json.dumps(
        {"kind": "beat_graph",
         "beats": [{"id": "B1", "story_ref": "S1"},
                   {"id": "B2", "story_ref": "S2"}],
         "canon_refs": [CANON]}, sort_keys=True).encode()
    story = json.dumps(
        {"kind": "story_architecture",
         "story_nodes": [{"id": "S1", "summary": "n1"},
                         {"id": "S2", "summary": "n2"}],
         "canon_refs": [CANON]}, sort_keys=True).encode()
    return [art(CANON, "canon_manifest"),
            art("33333333-3333-4333-8333-333333333331", "scene_set", scene_set),
            art("33333333-3333-4333-8333-333333333332", "beat_graph", beat_graph),
            art("33333333-3333-4333-8333-333333333333", "story_architecture", story)]


class TestInternalReferences(unittest.TestCase):
    def test_valid_script_trace_resolves(self):
        ctx = make_ctx("08.12", script_doc(), "script", extras=chain_extras())
        res = layers.technical_layer(ctx)
        chk = check_named(res, "internal_reference_integrity")
        self.assertIsNotNone(chk)
        self.assertTrue(chk["ok"], chk)
        self.assertEqual(chk["dangling"], [])
        self.assertEqual(res["evaluation"]["verdict"], "PASS")

    def test_dangling_payoff_line_fails_and_names_id(self):
        ctx = make_ctx("08.12", script_doc(payoff_line="L99"), "script",
                       extras=chain_extras())
        res = layers.technical_layer(ctx)
        chk = check_named(res, "internal_reference_integrity")
        self.assertFalse(chk["ok"])
        self.assertEqual({d["value"] for d in chk["dangling"]}, {"L99"})
        self.assertEqual(res["evaluation"]["verdict"], "FAIL")
        self.assertTrue(res["evaluation"]["evidence"]["deterministic"])

    def test_universe_unavailable_skips_never_fails(self):
        script_row = art("44444444-4444-4444-8444-444444444444", "script")
        doc = {"kind": "direction_package",
               "script_ref": script_row["artifact_id"],
               "directions": [{"line_ref": "L1", "direction": "d"},
                              {"line_ref": "L2", "direction": "d"}]}
        ctx = make_ctx("09.12", json.dumps(doc).encode(), "direction_package",
                       extras=(script_row,))
        res = layers.technical_layer(ctx)
        chk = check_named(res, "internal_reference_integrity")
        self.assertIsNotNone(chk)
        self.assertTrue(chk["ok"])
        self.assertFalse(chk["applied"])
        self.assertEqual(len(chk["skipped"]), 2)
        self.assertEqual(res["evaluation"]["verdict"], "PASS")

    def test_direction_refs_resolve_against_script_input(self):
        script = art("44444444-4444-4444-8444-444444444444", "script",
                     script_doc())
        doc = {"kind": "direction_package", "script_ref": script["artifact_id"],
               "directions": [{"line_ref": "L1", "direction": "d"},
                              {"line_ref": "L7", "direction": "d"}]}
        ctx = make_ctx("09.12", json.dumps(doc).encode(), "direction_package",
                       inputs=(script,))
        res = layers.technical_layer(ctx)
        chk = check_named(res, "internal_reference_integrity")
        self.assertFalse(chk["ok"])
        self.assertEqual({d["value"] for d in chk["dangling"]}, {"L7"})

    def test_dangling_prediction_key_fails(self):
        doc = {"kind": "derivative_portfolio", "master_ref": CANON,
               "derivatives": [{"id": "D-1", "format": "9:16",
                                "platform": "shorts"}],
               "predictions": {"D-1": {"view_range": [1, 2],
                                       "ctr_band": "3-5%",
                                       "confidence": "LOW"},
                               "D-ghost": {"view_range": [1, 2],
                                           "ctr_band": "3-5%",
                                           "confidence": "LOW"}},
               "predictions_locked": True}
        ctx = make_ctx("14.01", json.dumps(doc).encode(),
                       "derivative_portfolio")
        res = layers.technical_layer(ctx)
        chk = check_named(res, "internal_reference_integrity")
        self.assertFalse(chk["ok"])
        self.assertEqual({d["value"] for d in chk["dangling"]}, {"D-ghost"})


class TestCoverage(unittest.TestCase):
    def test_script_covers_all_scenes(self):
        ctx = make_ctx("08.12", script_doc(), "script", extras=chain_extras())
        res = layers.technical_layer(ctx)
        chk = check_named(res, "input_set_coverage")
        self.assertIsNotNone(chk)
        self.assertTrue(chk["ok"], chk)
        self.assertEqual(chk["uncovered"], [])

    def test_script_missing_scene_fails_and_names_it(self):
        ctx = make_ctx("08.12", script_doc(lines_scenes=("SC1",)), "script",
                       extras=chain_extras())
        res = layers.technical_layer(ctx)
        chk = check_named(res, "input_set_coverage")
        self.assertFalse(chk["ok"])
        self.assertEqual(chk["uncovered"], ["SC2"])
        self.assertEqual(res["evaluation"]["verdict"], "FAIL")

    def test_coverage_universe_unavailable_is_not_applied(self):
        ctx = make_ctx("08.12", script_doc(), "script")
        res = layers.technical_layer(ctx)
        chk = check_named(res, "input_set_coverage")
        self.assertIsNotNone(chk)
        self.assertTrue(chk["ok"])
        self.assertFalse(chk["applied"])
        self.assertEqual(chk["reason"], "universe_unavailable")


class MediaFixtures(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.dir = Path(tempfile.mkdtemp(prefix="mm07-media-"))

        def gen(name, size, vcodec, audio=True, suffix="mp4", acodec="aac"):
            out = cls.dir / f"{name}.{suffix}"
            args = ["ffmpeg", "-nostdin", "-v", "error", "-y",
                    "-f", "lavfi", "-i",
                    f"testsrc2=size={size}:rate=10:duration=0.4"]
            if audio:
                args += ["-f", "lavfi", "-i",
                         "sine=frequency=440:duration=0.4"]
            args += ["-c:v", vcodec, "-pix_fmt", "yuv420p"]
            if audio:
                args += ["-c:a", acodec, "-ar", "48000"]
            args += ["-shortest", str(out)]
            subprocess.run(args, check=True, capture_output=True)
            return out.read_bytes()

        cls.good_720 = gen("good720", "1280x720", "libx264")
        cls.bad_720 = gen("bad720", "1280x720", "mpeg4")
        cls.small = gen("small", "320x240", "libx264")
        wav = cls.dir / "narration.wav"
        subprocess.run(["ffmpeg", "-nostdin", "-v", "error", "-y",
                        "-f", "lavfi", "-i", "sine=frequency=440:duration=0.4",
                        "-ar", "48000", "-ac", "1", "-c:a", "pcm_s16le",
                        str(wav)], check=True, capture_output=True)
        cls.wav = wav.read_bytes()


class TestMediaTechnical(MediaFixtures):
    RENDER_TYPE = "render_a_review_master_deterministically_where_possible"

    def test_raw_media_good_at_render_op_passes(self):
        ctx = make_ctx("13.03", self.good_720, self.RENDER_TYPE)
        res = layers.technical_layer(ctx)
        chk = check_named(res, "media_technical_validation")
        self.assertIsNotNone(chk)
        self.assertTrue(chk["ok"], chk)
        self.assertEqual(chk["failures"], [])
        self.assertEqual(res["evaluation"]["verdict"], "PASS")

    def test_raw_media_wrong_codec_fails_with_named_reason(self):
        ctx = make_ctx("13.03", self.bad_720, self.RENDER_TYPE)
        res = layers.technical_layer(ctx)
        chk = check_named(res, "media_technical_validation")
        self.assertFalse(chk["ok"])
        self.assertIn("VIDEO_CODEC_MISMATCH", chk["failures"])
        self.assertEqual(res["evaluation"]["verdict"], "FAIL")

    def test_raw_media_wrong_dimensions_fail(self):
        ctx = make_ctx("13.03", self.small, self.RENDER_TYPE)
        res = layers.technical_layer(ctx)
        chk = check_named(res, "media_technical_validation")
        self.assertFalse(chk["ok"])
        self.assertIn("WIDTH_MISMATCH", chk["failures"])
        self.assertIn("HEIGHT_MISMATCH", chk["failures"])

    def _media_doc_ctx(self, op, media_bytes, extra_doc=None, fetch_missing=False):
        sha = _sha(media_bytes) if media_bytes else "a" * 64
        doc = {"kind": "apply_motivated_cuts",
               "media_output": {"sha256": sha, "storage_uri": "store://x",
                                "size": len(media_bytes or b"")}}
        if extra_doc:
            doc.update(extra_doc)
        store = {} if fetch_missing else {sha: media_bytes}
        return make_ctx(op, json.dumps(doc).encode(), "apply_motivated_cuts",
                        fetch=lambda s: store.get(s))

    def test_media_output_doc_validates_referenced_bytes(self):
        ctx = self._media_doc_ctx("12.05", self.small)
        res = layers.technical_layer(ctx)
        chk = check_named(res, "media_technical_validation")
        self.assertIsNotNone(chk)
        self.assertEqual(chk["source"], "media_output")
        self.assertTrue(chk["ok"], chk)

    def test_media_output_wrong_codec_fails(self):
        ctx = self._media_doc_ctx("12.05", self.bad_720)
        res = layers.technical_layer(ctx)
        chk = check_named(res, "media_technical_validation")
        self.assertFalse(chk["ok"])
        self.assertIn("VIDEO_CODEC_MISMATCH", chk["failures"])

    def test_media_output_missing_bytes_is_integrity_fail(self):
        ctx = self._media_doc_ctx("12.05", self.small, fetch_missing=True)
        res = layers.technical_layer(ctx)
        chk = check_named(res, "media_technical_validation")
        self.assertFalse(chk["ok"])
        self.assertEqual(chk["failures"], ["MEDIA_BYTES_UNAVAILABLE"])

    def test_media_output_master_spec_dimensions_enforced(self):
        ctx = self._media_doc_ctx(
            "13.03", self.good_720,
            extra_doc={"master_spec": {"width": 640, "height": 360,
                                       "video_codec": "h264",
                                       "audio_codec": "aac",
                                       "sample_rate": 48000}})
        res = layers.technical_layer(ctx)
        chk = check_named(res, "media_technical_validation")
        self.assertFalse(chk["ok"])
        self.assertIn("WIDTH_MISMATCH", chk["failures"])
        self.assertIn("HEIGHT_MISMATCH", chk["failures"])

    def test_audio_only_wav_passes_audio_expectations(self):
        ctx = make_ctx("14.08", self.wav,
                       "adapt_narration_and_subtitles_only_with_authorized_script_tr")
        res = layers.technical_layer(ctx)
        chk = check_named(res, "media_technical_validation")
        self.assertIsNotNone(chk)
        self.assertTrue(chk["ok"], chk)

    def test_plain_text_artifact_has_no_media_entry(self):
        ctx = make_ctx("05.12", b"plain text artifact bytes",
                       "story_architecture")
        res = layers.technical_layer(ctx)
        self.assertIsNone(check_named(res, "media_technical_validation"))
        self.assertEqual(res["evaluation"]["verdict"], "PASS")


RULE_OF_SIX = [("Emotion", 51, 8.6), ("Story", 23, 8.2), ("Rhythm", 10, 7.4),
               ("Eye Trace", 7, 7.9), ("2D Plane", 5, 7.1), ("3D Space", 4, 6.8)]


def _ros_doc(score=8.0):
    dims = [{"name": n, "weight": w, "score": score} for n, w, _ in RULE_OF_SIX]
    return {"kind": "edit_timeline", "segments": [{"shot_ref": "SH1", "order": 1}],
            "rule_of_six": {"dimensions": dims, "weighted_total": score}}


class TestRuleOfSixThreshold(unittest.TestCase):
    def test_threshold_param_creates_a_bar(self):
        stats, problems = layers._rubric_rule_of_six(_ros_doc(2.0), 7.5)
        self.assertIsNone(stats)
        self.assertTrue(any("below threshold" in p for p in problems), problems)

    def test_no_param_no_bar(self):
        stats, problems = layers._rubric_rule_of_six(_ros_doc(2.0), None)
        self.assertEqual(problems, [])
        self.assertEqual(stats["weighted_total"], 2.0)

    def test_above_threshold_passes(self):
        stats, problems = layers._rubric_rule_of_six(_ros_doc(8.0), 7.5)
        self.assertEqual(problems, [])
        self.assertEqual(stats["weighted_total"], 8.0)

    def test_semantic_layer_threshold_fail(self):
        import golden
        ctx = make_ctx("12.12", json.dumps(_ros_doc(2.0)).encode(),
                       "edit_timeline",
                       policy=("schema_validation", "dependency_integrity",
                               "rule_of_six_rubric"))
        ctx["resolve_qa_binding"] = lambda: {
            "provider": "deterministic-local",
            "params": {"rule_of_six_min_weighted_total": 7.5}}
        res = layers.semantic_layer(ctx, golden)
        self.assertEqual(res["evaluation"]["verdict"], "FAIL")
        self.assertEqual(res["report"]["status"], "RUBRIC_FAIL")
        self.assertTrue(any("below threshold" in p
                            for p in res["report"]["problems"]))


if __name__ == "__main__":
    unittest.main(verbosity=2)
