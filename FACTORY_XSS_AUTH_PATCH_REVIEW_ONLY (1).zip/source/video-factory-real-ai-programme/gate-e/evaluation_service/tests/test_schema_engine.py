"""Subset schema-engine tests (no DB). Includes a cross-check against the
real `jsonschema` package when it is importable (system python3 has it;
the g2 venv does not — the cross-check shells out to system python3 and
skips cleanly if neither interpreter has the package)."""
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
import schema_engine  # noqa: E402

CONTRACTS = Path.home() / "workspace/video-factory-g1/contracts"


class TestSubsetEngine(unittest.TestCase):
    def test_required_and_additional_properties(self):
        schema = {"type": "object", "required": ["a"],
                  "properties": {"a": {"type": "string"}},
                  "additionalProperties": False}
        self.assertEqual(schema_engine.validate({"a": "x"}, schema), [])
        msgs = [v["message"] for v in schema_engine.validate({"b": 1}, schema)]
        self.assertTrue(any("missing required" in m for m in msgs))
        self.assertTrue(any("additional property" in m for m in msgs))

    def test_pattern_enum_const_minimum(self):
        schema = {"type": "object", "properties": {
            "op": {"type": "string", "pattern": r"^05\.\d{2}$"},
            "status": {"enum": ["CANDIDATE", "ACCEPTED"]},
            "kind": {"const": "script"},
            "version": {"type": "integer", "minimum": 1}}}
        good = {"op": "05.12", "status": "CANDIDATE", "kind": "script", "version": 2}
        self.assertEqual(schema_engine.validate(good, schema), [])
        bad = {"op": "5.12", "status": "NOPE", "kind": "other", "version": 0}
        self.assertEqual(len(schema_engine.validate(bad, schema)), 4)

    def test_integer_excludes_bool_and_items_nesting(self):
        schema = {"type": "array", "items": {"type": "integer"}}
        self.assertEqual(schema_engine.validate([1, 2], schema), [])
        self.assertEqual(len(schema_engine.validate([True], schema)), 1)
        self.assertEqual(len(schema_engine.validate(["x"], schema)), 1)

    def test_unsupported_construct_fails_closed(self):
        with self.assertRaises(schema_engine.UnsupportedConstruct):
            schema_engine.validate({"a": 1}, {"type": "object", "format": "email"})
        problems = schema_engine.check_schema_supported(
            {"type": "object", "properties": {"a": {"format": "email"}}})
        self.assertTrue(problems)

    def test_all_32_contracts_are_supported(self):
        files = sorted(CONTRACTS.glob("step-*/*.schema.json"))
        self.assertEqual(len(files), 32)
        for f in files:
            problems = schema_engine.check_schema_supported(json.loads(f.read_text()))
            self.assertEqual(problems, [], f"{f}: {problems}")

    def test_all_deliverable_schemas_are_supported(self):
        # Gate G (OD-E1 iii): the deliverable contract family must also
        # stay inside the subset the evaluation engine can execute.
        files = sorted((CONTRACTS / "deliverables").glob("*.schema.json"))
        self.assertEqual(len(files), 18)
        for f in files:
            problems = schema_engine.check_schema_supported(json.loads(f.read_text()))
            self.assertEqual(problems, [], f"{f}: {problems}")


class TestCrossCheckWithRealJsonschema(unittest.TestCase):
    """Run the same (schema, instance) pairs through the real jsonschema
    package in a system-python3 subprocess and require identical verdicts."""

    def test_verdicts_match_real_engine(self):
        probe = subprocess.run(["python3", "-c", "import jsonschema"],
                               capture_output=True)
        if probe.returncode != 0:
            self.skipTest("jsonschema not importable in system python3 either")
        instances = {
            "step-05/output": [
                {"production_id": "p", "operation_id": "05.12", "status": "CANDIDATE",
                 "step_deliverable": "Story Architecture + Experience Map",
                 "output_artifacts": [{"artifact_id": "x", "artifact_type": "t",
                                       "sha256": "a" * 64}], "evidence": []},
                {"production_id": "p", "operation_id": "05.12", "status": "CANDIDATE",
                 "output_artifacts": [], "evidence": []},  # missing step_deliverable? no: not required; sha bad below
                {"production_id": "p", "operation_id": "5.12", "status": "WRONG",
                 "output_artifacts": [{"artifact_id": "x", "artifact_type": "t",
                                       "sha256": "zz"}], "evidence": [], "extra": 1},
            ],
            "step-12/input": [
                {"production_id": "p", "operation_id": "12.01",
                 "input_artifacts": [{"artifact_id": "x", "artifact_type": "t",
                                      "sha256": "b" * 64, "version": 1}]},
                {"production_id": "p", "operation_id": "12.01", "input_artifacts": "nope"},
            ],
        }
        jobs = []
        for rel, insts in instances.items():
            schema = json.loads((CONTRACTS / f"{rel}.schema.json").read_text())
            for inst in insts:
                mine = schema_engine.validate(inst, schema)
                jobs.append({"schema": schema, "instance": inst,
                             "mine": not mine})
        with tempfile.NamedTemporaryFile("w", suffix=".json", delete=False) as fh:
            json.dump(jobs, fh)
            jobfile = fh.name
        script = (
            "import json, sys, jsonschema\n"
            "jobs = json.load(open(sys.argv[1]))\n"
            "out = []\n"
            "for j in jobs:\n"
            "    v = jsonschema.Draft202012Validator(j['schema'])\n"
            "    out.append(not list(v.iter_errors(j['instance'])))\n"
            "print(json.dumps(out))\n")
        with tempfile.NamedTemporaryFile("w", suffix=".py", delete=False) as fh:
            fh.write(script)
            scriptfile = fh.name
        r = subprocess.run(["python3", scriptfile, jobfile],
                           capture_output=True, text=True)
        self.assertEqual(r.returncode, 0, r.stderr)
        theirs = json.loads(r.stdout)
        self.assertEqual([j["mine"] for j in jobs], theirs)


if __name__ == "__main__":
    unittest.main(verbosity=2)
