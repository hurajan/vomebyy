"""Golden registry tests (no DB): SEED cases never arm; the runner scores
the deterministic layers at accuracy 1.0 against its own seed fixtures."""
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
import golden  # noqa: E402


class TestGoldenRegistry(unittest.TestCase):
    def test_seed_cases_never_arm(self):
        seed, expert = golden.counts()
        self.assertEqual(expert, 0)
        self.assertGreaterEqual(seed, 4)
        self.assertFalse(golden.armed())

    def test_arming_counts_only_expert(self):
        fake = [{"provenance": "EXPERT"}] * 49 + [{"provenance": "SEED"}] * 30
        self.assertFalse(golden.armed(fake))
        fake.append({"provenance": "EXPERT"})
        self.assertTrue(golden.armed(fake))

    def test_runner_accuracy_on_seed_cases(self):
        res = golden.run_cases()
        self.assertEqual(res["cases"], golden.counts()[0])
        for layer in ("schema_validation", "deterministic_checks", "continuity_checks"):
            bucket = res["per_layer"][layer]
            self.assertEqual(bucket["correct"], bucket["total"],
                             f"{layer}: {res['details']}")
            self.assertGreater(bucket["total"], 0)


if __name__ == "__main__":
    unittest.main(verbosity=2)
