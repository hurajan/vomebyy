"""Gate E evaluation-service tests: real API (VALIDATOR submission) + real
evaluation service subprocess + chain-built scratch DB + tmp Gate D store.

Scenarios: schema violation -> BLOCKED; dangling sha -> BLOCKED with the
hash check itself PASSing on genuine artifacts; superseded planned input
-> REPAIR_REQUIRED; semantic layer (unarmed rubric PASS, BLOCKED variants,
NO_RUBRIC, rubric FAIL); the repair loop REPAIR_REQUIRED -> repair_ready
-> corrected attempt -> layers PASS -> AWAITING_HUMAN (semantic unarmed)
-> human_approved -> ACCEPTED; worker-verdict independence.
"""
import json
import os
import subprocess
import sys
import tempfile
import time
import unittest
import urllib.error
import urllib.request
from pathlib import Path

import psycopg
from psycopg.rows import dict_row

HERE = Path(__file__).resolve().parent
PKG = HERE.parent
sys.path.insert(0, str(PKG))

G2 = Path.home() / "workspace/video-factory-g2"
G3 = Path.home() / "workspace/video-factory-g3"
GATE_D = Path.home() / "workspace/video-factory-real-ai-programme/gate-d"
for p in (str(G2), str(GATE_D), str(G3 / "tests")):
    sys.path.insert(0, p)
from coordinator.coordinator import Coordinator  # noqa: E402
from storage_service import LocalStorage, final_uri  # noqa: E402
from server_fixture import make_dsn, start_server, stop_server  # noqa: E402

DB = "gatee_eval_scratch"
DSN = make_dsn(DB)
API_PORT, EVAL_PORT = 8746, 8950
API_URL = f"http://127.0.0.1:{API_PORT}"
EVAL_URL = f"http://127.0.0.1:{EVAL_PORT}"
VALIDATOR_TOKEN = "gatee-validator-token"
G2_PY = str(G2 / ".venv" / "bin" / "python")
CONTRACTS = Path.home() / "workspace/video-factory-g1/contracts"
RULE_OF_SIX = [("Emotion", 51, 8.6), ("Story", 23, 8.2), ("Rhythm", 10, 7.4),
               ("Eye Trace", 7, 7.9), ("2D Plane", 5, 7.1), ("3D Space", 4, 6.8)]


def raw():
    return psycopg.connect(DSN, row_factory=dict_row, autocommit=True)


def deliverable(step):
    schema = json.loads((CONTRACTS / f"step-{step}" / "output.schema.json").read_text())
    return schema["properties"]["step_deliverable"]["const"]


def deliverable_content(op, artifact_type):
    """Minimal VALID deliverable for the layered contract (Gate G):
    the envelope fixtures carry real deliverable content now."""
    if op == "05.12":
        return {"kind": "story_architecture",
                "story_nodes": [{"id": "S1", "summary": "Story node S1"}],
                "canon_refs": []}
    if op == "12.12":
        dims = [{"name": n, "weight": w, "score": s} for n, w, s in RULE_OF_SIX]
        total = round(sum(w * s for _, w, s in RULE_OF_SIX) / 100.0, 3)
        return {"kind": "edit_timeline",
                "segments": [{"shot_ref": "SH1", "order": 1}],
                "rule_of_six": {"dimensions": dims, "weighted_total": total}}
    return {"kind": artifact_type}


def envelope(pid, op, artifact_type, extra_item=None, omit=(), content=None):
    item = {"artifact_id": "33333333-3333-4333-8333-333333333333",
            "artifact_type": artifact_type, "sha256": "a" * 64,
            "content": deliverable_content(op, artifact_type)
            if content is None else content}
    if extra_item:
        item.update(extra_item)
    doc = {"production_id": pid, "operation_id": op, "status": "CANDIDATE",
           "step_deliverable": deliverable(op.split(".")[0]),
           "output_artifacts": [item], "evidence": []}
    for key in omit:
        doc.pop(key, None)
    return json.dumps(doc, sort_keys=True).encode()


def input_envelope(pid, op):
    return json.dumps({"production_id": pid, "operation_id": op,
                       "input_artifacts": []}, sort_keys=True).encode()


class Base(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        subprocess.run(["fuser", "-k", f"{API_PORT}/tcp", f"{EVAL_PORT}/tcp"],
                       capture_output=True)
        cls.store_root = tempfile.mkdtemp(prefix="gatee-store-")
        cls.storage = LocalStorage(cls.store_root)
        cls.api_proc, _ = start_server(DB, API_PORT, env_extra={
            "FACTORY_VALIDATOR_TOKEN": VALIDATOR_TOKEN,
            "FACTORY_STORAGE_ROOT": cls.store_root})
        env = dict(os.environ, FACTORY_DSN=DSN, FACTORY_API_URL=API_URL,
                   FACTORY_VALIDATOR_TOKEN=VALIDATOR_TOKEN,
                   FACTORY_ENVIRONMENT="test",
                   FACTORY_STORAGE_ROOT=cls.store_root,
                   FACTORY_EVAL_PORT=str(EVAL_PORT))
        cls.eval_proc = subprocess.Popen(
            [G2_PY, str(PKG / "service.py")], env=env,
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        for _ in range(100):
            try:
                with urllib.request.urlopen(EVAL_URL + "/health", timeout=2) as r:
                    if r.status == 200:
                        break
            except Exception:  # noqa: BLE001
                time.sleep(0.1)
        else:
            raise RuntimeError("evaluation service did not come up")

    @classmethod
    def tearDownClass(cls):
        cls.eval_proc.terminate()
        stop_server(cls.api_proc)

    def setUp(self):
        self.c = Coordinator(DSN, storage=self.storage)
        self.pid = self.c.create_production("Gate E production", 100_00, 80_00, "gatee")
        self.run = self.c.start_run(self.pid, "FULL", "gatee")

    def tearDown(self):
        with raw() as conn:
            conn.execute("UPDATE provider_configs SET active=false"
                         " WHERE created_by='gatee-test'")
        self.c.close()

    # ------------------------------------------------------------ helpers
    def put_input(self, data: bytes, artifact_type):
        ref = self.storage.put_candidate(data)
        self.storage.promote(ref["uri"])
        return self.c.register_artifact(self.pid, artifact_type, data,
                                        final_uri(ref["sha256"]))

    def complete_unit(self, op, content: bytes, artifact_type, inputs=(), key="main"):
        uid = self.c.plan_unit(self.pid, self.run, op, key,
                               input_artifact_ids=tuple(inputs))
        claim = self.c.claim(uid, "gatee-worker", 100)
        art = self.c.complete_attempt(uid, "gatee-worker", claim["fencing_token"],
                                      artifact_type, content, None, 90)
        return uid, art["artifact_id"]

    def evaluate(self, uid):
        req = urllib.request.Request(
            EVAL_URL + "/evaluate", method="POST",
            data=json.dumps({"unit_id": uid}).encode(),
            headers={"Content-Type": "application/json"})
        try:
            with urllib.request.urlopen(req, timeout=20) as r:
                return r.status, json.loads(r.read())
        except urllib.error.HTTPError as e:
            return e.code, json.loads(e.read() or b"{}")

    def evaluations_of(self, artifact_id):
        with raw() as conn:
            rows = conn.execute(
                "SELECT validator_id, verdict, evidence FROM quality_evaluations"
                " WHERE artifact_id=%s", (artifact_id,)).fetchall()
        return {r["validator_id"]: r for r in rows}

    def add_binding(self, scope, provider, op=None, slot=None, est=0,
                    credential_ref=None, params=None):
        with raw() as conn:
            return conn.execute(
                "INSERT INTO provider_configs(scope, operation_id, capability_slot,"
                " environment, provider, est_cost_cents, credential_ref, params,"
                " created_by) VALUES (%s,%s,%s,'test',%s,%s,%s,%s,'gatee-test')"
                " RETURNING config_id",
                (scope, op, slot, provider, est, credential_ref,
                 json.dumps(params or {}))).fetchone()["config_id"]

    def unit_state(self, uid):
        return self.c.get_unit(uid)["state"]


class TestHealth(Base):
    def test_health_reports_unarmed(self):
        with urllib.request.urlopen(EVAL_URL + "/health", timeout=5) as r:
            health = json.loads(r.read())
        self.assertEqual(health["status"], "ok")
        self.assertFalse(health["armed"])
        self.assertEqual(health["expert_cases"], 0)
        self.assertEqual(health["seed_cases"], 7)


class TestSchemaAndTechnical(Base):
    def test_schema_violation_blocked(self):
        uid, art = self.complete_unit(
            "05.12", envelope(self.pid, "05.12", "story_architecture",
                              omit=("evidence",)), "story_architecture")
        status, report = self.evaluate(uid)
        self.assertEqual(status, 200)
        self.assertTrue(report["submitted"])
        self.assertEqual(report["resulting_state"], "BLOCKED")
        evs = self.evaluations_of(art)
        self.assertEqual(evs["schema_validation"]["verdict"], "FAIL")
        self.assertTrue(evs["schema_validation"]["evidence"]["deterministic"])
        msgs = [v["message"] for v in evs["schema_validation"]["evidence"]["violations"]]
        self.assertTrue(any("evidence" in m for m in msgs), msgs)
        self.assertEqual(self.unit_state(uid), "BLOCKED")

    def test_clean_unit_technical_pass_hash_evidence(self):
        uid, art = self.complete_unit(
            "05.12", envelope(self.pid, "05.12", "story_architecture"),
            "story_architecture")
        status, report = self.evaluate(uid)
        self.assertEqual(status, 200)
        evs = self.evaluations_of(art)
        self.assertEqual(evs["deterministic_checks"]["verdict"], "PASS")
        checks = {c["check"]: c for c in evs["deterministic_checks"]["evidence"]["checks"]}
        self.assertTrue(checks["sha256_match"]["ok"])
        self.assertEqual(checks["sha256_match"]["recorded"],
                         checks["sha256_match"]["recomputed"])
        # semantic layer: FACTORY seed binding is 'mock', which cannot judge
        self.assertEqual(report["resulting_state"], "AWAITING_HUMAN")
        self.assertEqual(evs["semantic_evaluation"]["evidence"]["status"], "BLOCKED")
        self.assertEqual(evs["semantic_evaluation"]["evidence"]["reason"],
                         "provider_cannot_judge")

    def test_dangling_sha_blocked(self):
        # MM-10 (F-MM10-02): a sha counts as an artifact reference only
        # in a reference position, so the dangling value rides a PAIRED
        # PIN (timeline_ref + timeline_sha256 — the 13.12 pattern)
        # instead of the digest field source_sha256. The property is
        # unchanged: the pin names no CURRENT artifact, so
        # references_resolve FAILs with sha_not_current and the unit
        # BLOCKs. Digest positions are covered in test_mm10_refs.py.
        x = self.put_input(input_envelope(self.pid, "05.12"),
                           "canon_manifest")
        uid, art = self.complete_unit(
            "05.12", envelope(self.pid, "05.12", "story_architecture",
                              extra_item={"timeline_ref": x["artifact_id"],
                                          "timeline_sha256": "f" * 64}),
            "story_architecture")
        status, report = self.evaluate(uid)
        self.assertEqual(report["resulting_state"], "BLOCKED")
        evs = self.evaluations_of(art)
        tech = evs["deterministic_checks"]
        self.assertEqual(tech["verdict"], "FAIL")
        refcheck = [c for c in tech["evidence"]["checks"]
                    if c["check"] == "references_resolve"][0]
        self.assertFalse(refcheck["ok"])
        self.assertEqual(refcheck["failures"][0]["reason"], "sha_not_current")

    def test_worker_verdict_is_advisory_only(self):
        # The blocking defect is a dangling PAIRED PIN (MM-10 position
        # rule — see test_dangling_sha_blocked); the property under
        # test here is that the worker's own PASS verdict changes
        # nothing about the outcome.
        x = self.put_input(input_envelope(self.pid, "05.12"),
                           "canon_manifest")
        uid, art = self.complete_unit(
            "05.12", envelope(self.pid, "05.12", "story_architecture",
                              extra_item={"timeline_ref": x["artifact_id"],
                                          "timeline_sha256": "f" * 64}),
            "story_architecture")
        with raw() as conn:  # a worker self-assessment recorded out of band
            conn.execute(
                "INSERT INTO quality_evaluations(artifact_id, validator_id, method,"
                " evidence, verdict, evaluator_identity) VALUES (%s,'worker_self',"
                " 'self_report', '{}', 'PASS', 'some-worker')", (art,))
        status, report = self.evaluate(uid)
        self.assertEqual(report["resulting_state"], "BLOCKED")
        advisory = report["advisory_worker_evaluations"]
        self.assertEqual(len(advisory), 1)
        self.assertEqual(advisory[0]["validator_id"], "worker_self")


class TestContinuity(Base):
    def test_superseded_planned_input_repair_required(self):
        x = self.put_input(input_envelope(self.pid, "05.12"), "canon_manifest")
        uid, art = self.complete_unit(
            "05.12", envelope(self.pid, "05.12", "story_architecture"),
            "story_architecture", inputs=(x["artifact_id"],))
        self.put_input(input_envelope(self.pid, "05.12"), "canon_manifest")  # v2 supersedes
        status, report = self.evaluate(uid)
        self.assertEqual(report["resulting_state"], "REPAIR_REQUIRED")
        evs = self.evaluations_of(art)
        cont = evs["continuity_checks"]
        self.assertEqual(cont["verdict"], "FAIL")
        self.assertFalse(cont["evidence"]["deterministic"])
        sup = cont["evidence"]["superseded_inputs"]
        self.assertEqual([s["artifact_id"] for s in sup], [x["artifact_id"]])
        self.assertEqual(sup[0]["state"], "SUPERSEDED")
        # the schema layer still passed: X's bytes are a valid input envelope
        self.assertEqual(evs["schema_validation"]["verdict"], "PASS")


class TestSemantic(Base):
    def _rule_of_six_content(self, weights=None):
        dims = [{"name": n, "weight": (weights[i] if weights else w), "score": s}
                for i, (n, w, s) in enumerate(RULE_OF_SIX)]
        total = round(sum(d["weight"] * d["score"] for d in dims) / 100.0, 3)
        return envelope(self.pid, "12.12", "edit_timeline",
                        content={"kind": "edit_timeline",
                                 "segments": [{"shot_ref": "SH1", "order": 1}],
                                 "rule_of_six": {"dimensions": dims,
                                                 "weighted_total": total}})

    def test_rubric_pass_unarmed_awaits_human(self):
        self.add_binding("OPERATION", "deterministic-local", op="12.12")
        uid, art = self.complete_unit("12.12", self._rule_of_six_content(),
                                      "edit_timeline")
        status, report = self.evaluate(uid)
        self.assertEqual(report["resulting_state"], "AWAITING_HUMAN")
        sem = self.evaluations_of(art)["semantic_evaluation"]
        self.assertEqual(sem["verdict"], "REVIEW_REQUIRED")
        self.assertEqual(sem["evidence"]["status"], "RUBRIC_PASS_UNARMED")
        self.assertEqual(sem["evidence"]["calibration"], "NOT_ARMED")
        self.assertEqual(sem["evidence"]["expert_cases"], 0)
        self.assertEqual(sem["evidence"]["rubric"], "rule_of_six")

    def test_credential_absent_blocked(self):
        self.add_binding("OPERATION", "openrouter-compatible", op="12.12",
                         credential_ref="GATEE_UNSET_KEY")
        uid, art = self.complete_unit("12.12", self._rule_of_six_content(),
                                      "edit_timeline")
        status, report = self.evaluate(uid)
        self.assertEqual(report["resulting_state"], "AWAITING_HUMAN")
        sem = self.evaluations_of(art)["semantic_evaluation"]
        self.assertEqual(sem["evidence"]["status"], "BLOCKED")
        self.assertEqual(sem["evidence"]["reason"], "credential_absent")
        self.assertEqual(sem["evidence"]["credential_ref"], "GATEE_UNSET_KEY")

    def test_no_rubric_for_operation(self):
        self.add_binding("OPERATION", "deterministic-local", op="05.12")
        uid, art = self.complete_unit(
            "05.12", envelope(self.pid, "05.12", "story_architecture"),
            "story_architecture")
        status, report = self.evaluate(uid)
        self.assertEqual(report["resulting_state"], "AWAITING_HUMAN")
        sem = self.evaluations_of(art)["semantic_evaluation"]
        self.assertEqual(sem["evidence"]["status"], "NO_RUBRIC")

    def test_rubric_fail_is_content_fail(self):
        self.add_binding("OPERATION", "deterministic-local", op="12.12")
        uid, art = self.complete_unit(
            "12.12", self._rule_of_six_content(weights=[41, 23, 10, 7, 5, 4]),
            "edit_timeline")
        status, report = self.evaluate(uid)
        self.assertEqual(report["resulting_state"], "REPAIR_REQUIRED")
        sem = self.evaluations_of(art)["semantic_evaluation"]
        self.assertEqual(sem["verdict"], "FAIL")
        self.assertTrue(any("sum to 90" in p for p in sem["evidence"]["problems"]))


class TestRepairLoop(Base):
    def test_repair_loop_to_accepted(self):
        x = self.put_input(input_envelope(self.pid, "05.12"), "canon_manifest")
        z = self.put_input(b"people manifest bytes", "people_manifest")
        bad = envelope(self.pid, "05.12", "story_architecture",
                       extra_item={"canon_refs": [x["artifact_id"], z["artifact_id"]]})
        uid, art1 = self.complete_unit("05.12", bad, "story_architecture",
                                       inputs=(x["artifact_id"],))
        status, report = self.evaluate(uid)
        self.assertEqual(report["resulting_state"], "REPAIR_REQUIRED")
        cont = self.evaluations_of(art1)["continuity_checks"]
        self.assertEqual(cont["evidence"]["extra_declared"], [z["artifact_id"]])
        # existing machinery: repair_ready transition -> claim attempt 2
        self.assertEqual(self.c.event(uid, "repair_ready"), "READY")
        claim = self.c.claim(uid, "gatee-worker", 100)
        good = envelope(self.pid, "05.12", "story_architecture",
                        extra_item={"canon_refs": [x["artifact_id"]]})
        art2 = self.c.complete_attempt(uid, "gatee-worker", claim["fencing_token"],
                                       "story_architecture", good, None, 90)
        self.assertEqual(self.unit_state(uid), "VALIDATING")
        status, report = self.evaluate(uid)
        evs = self.evaluations_of(art2["artifact_id"])
        self.assertEqual(evs["continuity_checks"]["verdict"], "PASS")
        self.assertEqual(evs["schema_validation"]["verdict"], "PASS")
        self.assertEqual(evs["deterministic_checks"]["verdict"], "PASS")
        # semantic layer is unarmed: evaluation tops out at AWAITING_HUMAN,
        # and the human decision (existing transition) is the acceptance path
        self.assertEqual(report["resulting_state"], "AWAITING_HUMAN")
        self.assertEqual(self.c.event(uid, "human_approved"), "ACCEPTED")
        self.assertEqual(self.unit_state(uid), "ACCEPTED")


class TestLayeredGateG(Base):
    """Gate G (OD-E1 iii): deliverable-schema validation, the 14.01
    deliverable schema, and the 13.12 payload-hash cross-check."""

    def test_deliverable_violation_blocked(self):
        bad = {"kind": "story_architecture", "canon_refs": []}  # no story_nodes
        uid, art = self.complete_unit(
            "05.12", envelope(self.pid, "05.12", "story_architecture",
                              content=bad), "story_architecture")
        status, report = self.evaluate(uid)
        self.assertEqual(report["resulting_state"], "BLOCKED")
        ev = self.evaluations_of(art)["schema_validation"]
        self.assertEqual(ev["verdict"], "FAIL")
        paths = [v["path"] for v in ev["evidence"]["violations"]]
        self.assertTrue(any("output_artifacts[0].content" in p for p in paths),
                        paths)
        self.assertIn("deliverable_schema", ev["evidence"])

    def test_1401_deliverable_schema_applies(self):
        master = self.put_input(b'{"kind": "master_package", "asset_hashes": []}',
                                "master_package")
        # 14.01 claims are HG4-gated on the master_package input
        gate = self.c.create_gate(self.pid, "HG4", master["artifact_id"])
        self.c.decide_gate(gate["gate_id"], "APPROVED", "gatee-test")
        good = {"kind": "derivative_portfolio", "master_ref": master["artifact_id"],
                "derivatives": [{"id": "D-1", "format": "9:16", "platform": "shorts"}],
                "predictions": {"D-1": {"view_range": [1, 2], "ctr_band": "3-5%",
                                        "confidence": "LOW"}},
                "predictions_locked": True}
        uid, art = self.complete_unit(
            "14.01", json.dumps(good, sort_keys=True).encode(),
            "derivative_portfolio", inputs=(master["artifact_id"],))
        status, report = self.evaluate(uid)
        evs = self.evaluations_of(art)
        self.assertEqual(evs["schema_validation"]["verdict"], "PASS")
        self.assertEqual(report["resulting_state"], "AWAITING_HUMAN")

        bad = dict(good, predictions_locked=False)
        uid2, art2 = self.complete_unit(
            "14.01", json.dumps(bad, sort_keys=True).encode(),
            "derivative_portfolio", inputs=(master["artifact_id"],), key="bad")
        status, report = self.evaluate(uid2)
        self.assertEqual(report["resulting_state"], "BLOCKED")
        self.assertEqual(self.evaluations_of(art2)["schema_validation"]["verdict"],
                         "FAIL")

    def test_1312_asset_hashes_match_registry_input(self):
        import hashlib as _h
        asset_sha = _h.sha256(b"payload-SH1").hexdigest()
        registry_doc = {"kind": "asset_registry", "assets": [
            {"id": "A-SH1", "shot_ref": "SH1", "payload": "payload-SH1",
             "sha256": asset_sha}]}
        timeline = self.put_input(b'{"kind": "edit_timeline", "segments": []}',
                                  "edit_timeline")
        registry = self.put_input(
            json.dumps(registry_doc, sort_keys=True).encode(), "asset_registry")

        def master_doc(hashes):
            return {"kind": "master_package",
                    "timeline_ref": timeline["artifact_id"],
                    "timeline_sha256": timeline["sha256"],
                    "registry_ref": registry["artifact_id"],
                    "registry_sha256": registry["sha256"],
                    "asset_hashes": hashes}

        uid, art = self.complete_unit(
            "13.12", envelope(self.pid, "13.12", "master_package",
                              content=master_doc([asset_sha])),
            "master_package",
            inputs=(timeline["artifact_id"], registry["artifact_id"]))
        status, report = self.evaluate(uid)
        evs = self.evaluations_of(art)
        self.assertEqual(evs["deterministic_checks"]["verdict"], "PASS")
        self.assertEqual(report["resulting_state"], "AWAITING_HUMAN")

        uid2, art2 = self.complete_unit(
            "13.12", envelope(self.pid, "13.12", "master_package",
                              content=master_doc(["0" * 64])),
            "master_package",
            inputs=(timeline["artifact_id"], registry["artifact_id"]), key="bad")
        status, report = self.evaluate(uid2)
        self.assertEqual(report["resulting_state"], "BLOCKED")
        tech = self.evaluations_of(art2)["deterministic_checks"]
        self.assertEqual(tech["verdict"], "FAIL")
        check = [c for c in tech["evidence"]["checks"]
                 if c["check"] == "master_asset_hashes_match_registry"][0]
        self.assertFalse(check["ok"])


class TestEvaluateGuards(Base):
    def test_evaluate_non_validating_unit_409(self):
        uid = self.c.plan_unit(self.pid, self.run, "05.12", "guard")
        status, report = self.evaluate(uid)
        self.assertEqual(status, 409)
        self.assertFalse(report["submitted"])


if __name__ == "__main__":
    unittest.main(verbosity=2)
