"""Evaluation layers for Gate E, driven by the registry validator_policy.

Policy vocabulary (enumerated from the seed: all 192 operations carry
['schema_validation', 'dependency_integrity', <2-4 step-specific names>];
16 distinct policies, one per step):

    policy entry            layer
    ----------------------  ------------------------------------------
    schema_validation       schema layer (step contract, exit ops)
    dependency_integrity    technical layer + continuity layer
    any further entry       semantic layer "named check" (cross_modal_qa,
                            canon_validation, rule_of_six_rubric, ...)

Each layer returns {"evaluation": dict|None, "applied": bool,
"report": {...}}. The evaluation dict uses the coordinator's format
{validator, method, verdict, evaluator, evidence} with
evidence["deterministic"] set for the deterministic layers (schema,
technical); continuity and semantic FAILs are content FAILs
(deterministic False). A layer whose checks could not run at all returns
evaluation=None with the reason in its report — it never fabricates a
verdict.
"""
import hashlib
import json
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
GATE_C_WS = Path.home() / "workspace/video-factory-real-ai-programme/gate-c/worker_service"
if str(GATE_C_WS) not in sys.path:
    sys.path.insert(0, str(GATE_C_WS))
import refs as refs_mod  # noqa: E402
import schema_engine  # noqa: E402

G1_CONTRACTS = Path.home() / "workspace/video-factory-g1/contracts"
BASE_POLICIES = {"schema_validation", "dependency_integrity"}
EVALUATOR = "evaluation-service"


def _ev(validator, method, verdict, evidence):
    return {"validator": validator, "method": method, "verdict": verdict,
            "evaluator": EVALUATOR, "evidence": evidence}


def _parse_json(data):
    if data is None:
        return None, False
    try:
        return json.loads(data.decode("utf-8")), True
    except Exception:  # noqa: BLE001
        return None, False


def _find_key(node, key):
    """First value found for `key` anywhere in a parsed JSON doc."""
    if isinstance(node, dict):
        if key in node:
            return node[key]
        for v in node.values():
            found = _find_key(v, key)
            if found is not None:
                return found
    elif isinstance(node, list):
        for element in node:
            found = _find_key(element, key)
            if found is not None:
                return found
    return None


DELIVERABLES = G1_CONTRACTS / "deliverables"


def _deliverable_of(parsed):
    """The deliverable value inside an envelope: the first
    output_artifacts entry's `content`. The value itself when the
    content is not an envelope (bare deliverables, fixtures)."""
    if isinstance(parsed, dict):
        entries = parsed.get("output_artifacts")
        if isinstance(entries, list) and entries \
                and isinstance(entries[0], dict) and "content" in entries[0]:
            return entries[0]["content"]
    return parsed


def _deliverable_schema_path(operation_id):
    if operation_id == "14.01":
        return DELIVERABLES / "op-14.01.schema.json"
    return DELIVERABLES / f"step-{operation_id.split('.')[0]}.schema.json"


def _prefix(violations, prefix):
    return [{"path": f"{prefix}{v['path'][1:]}" if v["path"].startswith("$")
              else v["path"], "message": v["message"]} for v in violations]


# --------------------------------------------------------------------- schema
def schema_layer(ctx):
    """Layered validation (OD-E1 iii, Gate G):
      * step exits (.12): the artifact content against the step's
        ENVELOPE schema (registry contract) AND each output_artifacts
        entry's content against the step's DELIVERABLE schema
        (contracts/deliverables/step-NN.schema.json). An entry without
        content, or a deliverable violation, is a deterministic FAIL
        with the deliverable path in the evidence.
      * 14.01: the bare payload against deliverables/op-14.01.schema.json.
      * other non-exits: applicability note only (unchanged).
      * inputs: an input whose bytes are a producer ENVELOPE is checked
        against its own step's envelope + deliverable schemas (the
        schemas describe what the producer emitted — a consumer's input
        schema describes the invocation envelope, not artifact bytes,
        so cross-step inputs can only be honestly checked this way).
        A legacy invocation envelope (input_artifacts, no
        output_artifacts) is checked against the consuming step's input
        schema, as before. Bare or non-JSON input content is recorded
        as skipped, never guessed at."""
    policy = ctx["operation"].get("validator_policy") or []
    if "schema_validation" not in policy:
        return {"evaluation": None, "applied": False,
                "report": {"layer": "schema_validation", "applied": False,
                           "reason": "not_in_policy"}}
    op = ctx["operation"]
    step = op["step_id"]
    op_id = op["operation_id"]
    artifact = ctx["output_artifact"]
    is_exit = op_id.endswith(".12")
    if not is_exit and op_id != "14.01":
        # The 16 step contracts describe step-level deliverables (the .12
        # exits) and step inputs. A mid-step operation has no contract of
        # its own.
        ev = _ev("schema_validation", "json_schema_subset", "PASS", {
            "layer": "schema_validation", "deterministic": True,
            "applied": False, "applicability": "step_exit_only",
            "artifact_type": artifact["artifact_type"], "step": step})
        return {"evaluation": ev, "applied": False,
                "report": {"layer": "schema_validation", "applied": False,
                           "applicability": "step_exit_only",
                           "artifact_type": artifact["artifact_type"]}}
    if ctx["output_bytes"] is None:
        return {"evaluation": None, "applied": False,
                "report": {"layer": "schema_validation", "applied": False,
                           "reason": "bytes_unavailable",
                           "storage_uri": artifact["storage_uri"]}}
    deliverable_schema = json.loads(_deliverable_schema_path(op_id).read_text())
    schemas = [deliverable_schema]
    out_schema = in_schema = None
    if is_exit:
        out_schema = json.loads(
            (G1_CONTRACTS / f"step-{step}" / "output.schema.json").read_text())
        in_schema = json.loads(
            (G1_CONTRACTS / f"step-{step}" / "input.schema.json").read_text())
        schemas += [out_schema, in_schema]
    unsupported = []
    for s in schemas:
        unsupported += schema_engine.check_schema_supported(s)
    if unsupported:
        ev = _ev("schema_validation", "json_schema_subset", "FAIL", {
            "layer": "schema_validation", "deterministic": True,
            "unsupported_schema_constructs": unsupported})
        return {"evaluation": ev, "applied": True,
                "report": {"layer": "schema_validation", "applied": True,
                           "unsupported_schema_constructs": unsupported}}
    violations = []
    parsed, ok = _parse_json(ctx["output_bytes"])
    if not ok:
        violations.append({"path": "$", "message": "output content is not valid "
                                                   "JSON; schema expects an object"})
    elif op_id == "14.01":
        violations.extend(_prefix(
            schema_engine.validate(parsed, deliverable_schema), "$"))
    else:
        violations.extend(schema_engine.validate(parsed, out_schema))
        entries = parsed.get("output_artifacts") if isinstance(parsed, dict) else None
        if isinstance(entries, list):
            for i, entry in enumerate(entries):
                if not isinstance(entry, dict) or "content" not in entry:
                    violations.append({
                        "path": f"$.output_artifacts[{i}].content",
                        "message": "output_artifacts entry carries no deliverable "
                                   "content (layered contract, OD-E1 iii)"})
                    continue
                violations.extend(_prefix(
                    schema_engine.validate(entry["content"], deliverable_schema),
                    f"$.output_artifacts[{i}].content"))
    inputs_checked, inputs_skipped = 0, []
    for inp in ctx["input_artifacts"]:
        if inp.get("content_bytes") is None:
            inputs_skipped.append({"artifact_id": inp["artifact_id"],
                                   "reason": "bytes_unavailable"})
            continue
        iparsed, iok = _parse_json(inp["content_bytes"])
        if not iok:
            inputs_skipped.append({"artifact_id": inp["artifact_id"],
                                   "reason": "non_json_content"})
            continue
        prefix = f"input[{inp['artifact_id']}]"
        if isinstance(iparsed, dict) and "output_artifacts" in iparsed:
            producer_op = iparsed.get("operation_id")
            if not isinstance(producer_op, str) or "." not in producer_op:
                inputs_skipped.append({"artifact_id": inp["artifact_id"],
                                       "reason": "envelope_without_operation_id"})
                continue
            p_step = producer_op.split(".")[0]
            p_env = json.loads(
                (G1_CONTRACTS / f"step-{p_step}" / "output.schema.json").read_text())
            p_del = json.loads(_deliverable_schema_path(producer_op).read_text())
            inputs_checked += 1
            violations.extend(_prefix(schema_engine.validate(iparsed, p_env), prefix))
            entries = iparsed.get("output_artifacts")
            if isinstance(entries, list):
                for i, entry in enumerate(entries):
                    if isinstance(entry, dict) and "content" in entry:
                        violations.extend(_prefix(
                            schema_engine.validate(entry["content"], p_del),
                            f"{prefix}.output_artifacts[{i}].content"))
        elif isinstance(iparsed, dict) and "input_artifacts" in iparsed \
                and in_schema is not None:
            inputs_checked += 1
            violations.extend(_prefix(
                schema_engine.validate(iparsed, in_schema), prefix))
        else:
            inputs_skipped.append({"artifact_id": inp["artifact_id"],
                                   "reason": "bare_content_not_envelope"})
    ev = _ev("schema_validation", "json_schema_subset",
             "FAIL" if violations else "PASS", {
                 "layer": "schema_validation", "deterministic": True,
                 "violations": violations, "inputs_checked": inputs_checked,
                 "inputs_skipped": inputs_skipped,
                 "output_schema": f"contracts/step-{step}/output.schema.json"
                 if is_exit else None,
                 "deliverable_schema": f"contracts/deliverables/"
                 f"{_deliverable_schema_path(op_id).name}",
                 "input_schema": f"contracts/step-{step}/input.schema.json"
                 if is_exit else None})
    return {"evaluation": ev, "applied": True,
            "report": {"layer": "schema_validation", "applied": True,
                       "verdict": ev["verdict"], "violations": violations}}


# ------------------------------------------------------------------ technical
def technical_layer(ctx):
    policy = ctx["operation"].get("validator_policy") or []
    if "dependency_integrity" not in policy:
        return {"evaluation": None, "applied": False,
                "report": {"layer": "deterministic_checks", "applied": False,
                           "reason": "not_in_policy"}}
    artifact = ctx["output_artifact"]
    data = ctx["output_bytes"]
    checks = []
    if data is None:
        return {"evaluation": None, "applied": False,
                "report": {"layer": "deterministic_checks", "applied": False,
                           "reason": "bytes_unavailable",
                           "storage_uri": artifact["storage_uri"],
                           "note": "hash check could use the recorded sha only; "
                                   "no byte-dependent check was run"}}
    digest = hashlib.sha256(data).hexdigest()
    checks.append({"check": "sha256_match", "ok": digest == artifact["sha256"],
                   "recorded": artifact["sha256"], "recomputed": digest})
    checks.append({"check": "size_positive", "ok": len(data) > 0, "size": len(data)})
    parsed, is_json = _parse_json(data)
    stripped = data.strip()
    json_shaped = stripped.startswith(b"{") or stripped.startswith(b"[")
    checks.append({"check": "content_parses", "ok": (is_json if json_shaped else True),
                   "json": is_json, "json_shaped": bool(json_shaped)})
    ref_failures = []
    if is_json:
        found = refs_mod.extract_refs(parsed)
        for ref in found["artifact_ids"]:
            target = ctx["all_by_id"].get(ref["value"])
            if target is None:
                ref_failures.append({**ref, "reason": "artifact_not_found"})
            elif target["state"] != "CURRENT":
                ref_failures.append({**ref, "reason": f"artifact_{target['state'].lower()}"})
            elif target["production_id"] != ctx["production_id"]:
                ref_failures.append({**ref, "reason": "other_production"})
        for ref in found["shas"]:
            if ref["value"] == artifact["sha256"]:
                continue  # self-reference
            if ref["value"] not in ctx["current_by_sha"]:
                ref_failures.append({**ref, "reason": "sha_not_current"})
        checks.append({"check": "references_resolve",
                       "ok": not ref_failures,
                       "id_refs": len(found["artifact_ids"]),
                       "sha_refs": len(found["shas"]),
                       "null_refs": found["null_refs"],
                       "failures": ref_failures})
        checks.extend(_op_specific_checks(ctx, parsed))
        external_docs = _external_docs(ctx)
        checks.extend(_id_graph_checks(ctx, parsed, external_docs))
        checks.extend(_coverage_check(ctx, parsed, external_docs))
    checks.extend(_media_technical_check(ctx, parsed if is_json else None))
    failed = [c for c in checks if not c["ok"]]
    ev = _ev("deterministic_checks", "technical_checks",
             "FAIL" if failed else "PASS", {
                 "layer": "deterministic_checks", "deterministic": True,
                 "checks": checks})
    return {"evaluation": ev, "applied": True,
            "report": {"layer": "deterministic_checks", "applied": True,
                       "verdict": ev["verdict"], "checks": checks}}


def _op_specific_checks(ctx, parsed):
    """Structural rules the factory payload shapes themselves define.
    Gate G: the checks read the DELIVERABLE (inside the envelope when
    the content is layered), never the envelope's own fields."""
    parsed = _deliverable_of(parsed)
    if not isinstance(parsed, dict):
        return []
    op = ctx["operation"]["operation_id"]
    out = []
    if op == "14.12":
        derivs = parsed.get("derivatives") or []
        package_ids = sorted(d.get("id") for d in derivs if isinstance(d, dict))
        manifest = ((parsed.get("upload_manifest") or {}).get("files")) or []
        problems = []
        if sorted(manifest) != package_ids:
            problems.append(f"upload_manifest {sorted(manifest)} != derivative set {package_ids}")
        portfolio = next((a for a in ctx["input_artifacts"]
                          if a["artifact_type"] == "derivative_portfolio"), None)
        portfolio_source = "planned_input"
        if portfolio is None:
            # Gate G: the real station chains plan 14.12 with the master
            # as its only input (the portfolio is the depended-on 14.01
            # unit's output, unplannable before it exists). Fall back to
            # the production's CURRENT portfolio — the same artifact the
            # payload builder fell back to — and record the source.
            portfolio = next((a for a in ctx["all_by_id"].values()
                              if a["artifact_type"] == "derivative_portfolio"
                              and a["state"] == "CURRENT"), None)
            portfolio_source = "current_in_production"
        if portfolio is None:
            problems.append("no derivative_portfolio input to compare against")
        else:
            pdoc_raw, pok = _parse_json(portfolio.get("content_bytes"))
            if not pok:
                out.append({"check": "derivative_set_matches_portfolio", "ok": False,
                            "problems": ["portfolio input bytes unavailable/unparseable"]})
                return out
            pdoc = _deliverable_of(pdoc_raw)
            portfolio_ids = sorted(d.get("id") for d in (pdoc.get("derivatives") or [])
                                   if isinstance(d, dict))
            if portfolio_ids != package_ids:
                problems.append(f"derivative set {package_ids} != portfolio set {portfolio_ids}")
        out.append({"check": "derivative_set_matches_portfolio",
                    "ok": not problems, "problems": problems,
                    "derivative_ids": package_ids,
                    "portfolio_source": portfolio_source})
    elif op == "14.01":
        derivs = parsed.get("derivatives") or []
        predictions = parsed.get("predictions") or {}
        problems = []
        for d in derivs:
            if not isinstance(d, dict) or "id" not in d:
                problems.append("derivative entry without id")
                continue
            pred = predictions.get(d["id"])
            if not isinstance(pred, dict):
                problems.append(f"no predictions entry for {d['id']}")
                continue
            for field in ("view_range", "ctr_band", "confidence"):
                if field not in pred:
                    problems.append(f"predictions[{d['id']}] missing {field}")
            if "view_range" in pred and not (isinstance(pred["view_range"], list)
                                             and len(pred["view_range"]) == 2):
                problems.append(f"predictions[{d['id']}].view_range is not a [lo, hi] pair")
        out.append({"check": "prediction_entries_complete",
                    "ok": not problems, "problems": problems})
    elif op == "13.12":
        # Gate G: asset_hashes are PAYLOAD hashes (sha256 of each asset's
        # payload string), not artifact hashes — the honest check is
        # cross-artifact consistency against the asset_registry input's
        # assets[].sha256 set, not presence in the artifact store.
        hashes = parsed.get("asset_hashes")
        problems = []
        if not isinstance(hashes, list) or not hashes:
            problems.append("master_package carries no asset_hashes")
        else:
            registry = next((a for a in ctx["input_artifacts"]
                             if a["artifact_type"] == "asset_registry"), None)
            if registry is None:
                problems.append("no asset_registry input to compare "
                                "asset_hashes against")
            else:
                rdoc_raw, rok = _parse_json(registry.get("content_bytes"))
                if not rok:
                    problems.append("asset_registry input bytes "
                                    "unavailable/unparseable")
                else:
                    rdoc = _deliverable_of(rdoc_raw)
                    registry_hashes = sorted(
                        a.get("sha256") for a in (rdoc.get("assets") or [])
                        if isinstance(a, dict))
                    if sorted(hashes) != registry_hashes:
                        problems.append(
                            f"asset_hashes {sorted(hashes)} != registry asset "
                            f"hashes {registry_hashes}")
        out.append({"check": "master_asset_hashes_match_registry",
                    "ok": not problems, "problems": problems})
    return out


# ------------------------------------------------------------- MM-07 checks
# Three deterministic checks added at Gate MM-07, shape-keyed like the
# op-specific checks above:
#   internal_reference_integrity — id-graph references inside a
#     deliverable resolve inside the deliverable or to ids declared by
#     loadable CURRENT artifacts of the production;
#   input_set_coverage — a deliverable enumerating units against a
#     CURRENT input set covers every id in that set;
#   media_technical_validation — media-bearing artifacts are
#     re-validated with MM-06's ffprobe validator (media_tools).
# A check whose shape or resolution universe is absent records itself
# not-applicable (or skips individual references) — it never guesses.

_ID_TOKEN = re.compile(r"^[A-Za-z][A-Za-z0-9_-]*$")
_ID_SOURCE_TYPES = {"story_architecture", "beat_graph", "scene_set", "script",
                    "shot_manifest", "asset_registry", "derivative_portfolio",
                    "derivative_package", "direction_package"}
_ID_COLLECTIONS = ("lines", "scenes", "beats", "story_nodes", "clues",
                   "shots", "derivatives")
_REF_FIELD_KINDS = {
    "scene_ref": "scenes", "beat_ref": "beats", "story_ref": "story_nodes",
    "line_ref": "lines", "line": "lines", "shot_ref": "shots",
    "clue": "clues", "learns": "clues", "derivative_id": "derivatives",
    "planted": "lines", "payoff": "lines", "at": "lines",
}


def _fetch_by_sha(ctx, sha256):
    fn = ctx.get("fetch_bytes_by_sha")
    if callable(fn):
        try:
            return fn(sha256)
        except Exception:  # noqa: BLE001 — absent bytes = unavailable
            return None
    return None


def _declared_ids(doc):
    """{kind: {ids}} declared by a deliverable-shaped doc: the `id`
    values of its named collections (plus asset shot_ref values, which
    are the ids other deliverables reference assets by)."""
    doc = _deliverable_of(doc)
    kinds = {}

    def add(kind, value):
        if isinstance(value, str) and value:
            kinds.setdefault(kind, set()).add(value)

    def scan(node):
        if isinstance(node, dict):
            for key, value in node.items():
                if key in _ID_COLLECTIONS and isinstance(value, list):
                    for entry in value:
                        if isinstance(entry, dict):
                            add(key, entry.get("id"))
                if key == "assets" and isinstance(value, list):
                    for entry in value:
                        if isinstance(entry, dict):
                            add("shots", entry.get("shot_ref"))
                scan(value)
        elif isinstance(node, list):
            for entry in node:
                scan(entry)

    if isinstance(doc, dict):
        scan(doc)
    return kinds


def _external_docs(ctx):
    """Parsed docs the reference/coverage universes may draw on: the
    unit's planned inputs (bytes already loaded) plus CURRENT artifacts
    of id-declaring types in the same production (bytes fetched by sha
    through the context's storage callable)."""
    docs = []
    for inp in ctx.get("input_artifacts") or []:
        data = inp.get("content_bytes")
        if data:
            doc, ok = _parse_json(data)
            if ok:
                docs.append((inp.get("artifact_type"), doc))
    for row in (ctx.get("all_by_id") or {}).values():
        if row.get("state") != "CURRENT" \
                or row.get("artifact_type") not in _ID_SOURCE_TYPES:
            continue
        data = row.get("content_bytes")
        if data is None and row.get("sha256"):
            data = _fetch_by_sha(ctx, row["sha256"])
        if data:
            doc, ok = _parse_json(data)
            if ok:
                docs.append((row.get("artifact_type"), doc))
    return docs


def _id_graph_checks(ctx, parsed, external_docs):
    doc = _deliverable_of(parsed)
    if not isinstance(doc, dict):
        return []
    own = _declared_ids(doc)
    external = {}
    for _atype, idoc in external_docs:
        for kind, ids in _declared_ids(idoc).items():
            external.setdefault(kind, set()).update(ids)

    def universe(kind):
        return own.get(kind, set()) | external.get(kind, set())

    found, skipped, dangling = [], [], []

    def consider(path, field, value, kind):
        if not isinstance(value, str) or not _ID_TOKEN.match(value) \
                or refs_mod.UUID_RE.match(value):
            return  # free text, or an artifact UUID (references_resolve's domain)
        found.append({"path": path, "field": field, "value": value, "kind": kind})
        ids = universe(kind)
        if not ids:
            skipped.append({"path": path, "field": field, "value": value,
                            "kind": kind,
                            "reason": "resolution_universe_unavailable"})
        elif value not in ids:
            dangling.append({"path": path, "field": field, "value": value,
                             "kind": kind})

    def walk(node, path):
        if isinstance(node, dict):
            for key, value in node.items():
                p = f"{path}.{key}"
                if key in _REF_FIELD_KINDS:
                    kind = _REF_FIELD_KINDS[key]
                    if isinstance(value, list):
                        for i, element in enumerate(value):
                            consider(f"{p}[{i}]", key, element, kind)
                    else:
                        consider(p, key, value, kind)
                if key in ("predictions", "comparison") and isinstance(value, dict):
                    for sub in value:
                        consider(f"{p}.{sub}", key, sub, "derivatives")
                if key == "upload_manifest" and isinstance(value, dict):
                    files = value.get("files")
                    if isinstance(files, list):
                        for i, element in enumerate(files):
                            consider(f"{p}.files[{i}]", "files", element,
                                     "derivatives")
                walk(value, p)
        elif isinstance(node, list):
            for i, element in enumerate(node):
                walk(element, f"{path}[{i}]", )

    walk(doc, "$")
    if not found and not skipped and not dangling:
        return []
    return [{"check": "internal_reference_integrity",
             "ok": not dangling,
             "applied": bool(dangling) or len(found) > len(skipped),
             "references": len(found), "skipped": skipped,
             "dangling": dangling}]


_COVERAGE_RULES = {
    "08.12": {"entries": "lines", "ref_field": "scene_ref",
              "source_type": "scene_set", "collection": "scenes"},
    "07.12": {"entries": "scenes", "ref_field": "beat_ref",
              "source_type": "beat_graph", "collection": "beats"},
    "06.12": {"entries": "beats", "ref_field": "story_ref",
              "source_type": "story_architecture", "collection": "story_nodes"},
}


def _coverage_check(ctx, parsed, external_docs):
    rule = _COVERAGE_RULES.get(ctx["operation"]["operation_id"])
    if rule is None:
        return []
    doc = _deliverable_of(parsed)
    if not isinstance(doc, dict):
        return []
    entries = doc.get(rule["entries"])
    if not isinstance(entries, list):
        return []
    universe = None
    for atype, idoc in external_docs:
        if atype != rule["source_type"]:
            continue
        ids = _declared_ids(idoc).get(rule["collection"])
        if ids:
            universe = ids
            break
    if universe is None:
        return [{"check": "input_set_coverage", "ok": True, "applied": False,
                 "reason": "universe_unavailable",
                 "universe_type": rule["source_type"]}]
    covered = {e.get(rule["ref_field"]) for e in entries if isinstance(e, dict)}
    uncovered = sorted(u for u in universe if u not in covered)
    return [{"check": "input_set_coverage", "ok": not uncovered,
             "universe_type": rule["source_type"],
             "universe_size": len(universe),
             "covered": sorted(c for c in covered if c in universe),
             "uncovered": uncovered}]


_RENDER_SPEC_CACHE = None


def _render_plan_spec():
    """Op 13.03's render dimensions from its pinned plan (seed file),
    falling back to the worker action's own defaults (1280x720)."""
    global _RENDER_SPEC_CACHE
    if _RENDER_SPEC_CACHE is None:
        spec = {"width": 1280, "height": 720}
        try:
            plans_doc = json.loads(
                (Path.home() / "workspace/video-factory-g1/seed-definitions"
                 / "workflow-1.0.0" / "plans.json").read_text())
            for plan in plans_doc["plans"]:
                if plan.get("operation_id") == "13.03":
                    for action in plan.get("actions") or []:
                        if action.get("implementation") == "media.ffmpeg_render":
                            s = action.get("spec") or {}
                            spec = {"width": s.get("width", 1280),
                                    "height": s.get("height", 720)}
        except Exception:  # noqa: BLE001 — defaults stand
            pass
        _RENDER_SPEC_CACHE = spec
    return _RENDER_SPEC_CACHE


def _media_expectations(mt, op, probe, doc):
    master = mt.MASTER
    video = mt.first_stream(probe, "video")
    audio = mt.first_stream(probe, "audio")
    fmt = probe.get("format_name") or ""
    ms = doc.get("master_spec") if isinstance(doc, dict) else None
    if isinstance(ms, dict):
        return {"require_video": True,
                "video_codec": ms.get("video_codec") or master["video_codec"],
                "width": ms.get("width"), "height": ms.get("height"),
                "require_audio": audio is not None,
                "audio_codec": (ms.get("audio_codec") or master["audio_codec"])
                if audio else None,
                "sample_rate": (ms.get("sample_rate") or master["sample_rate"])
                if audio else None}
    if op == "13.03":
        spec = _render_plan_spec()
        return {"require_video": True, "video_codec": master["video_codec"],
                "width": spec["width"], "height": spec["height"],
                "require_audio": audio is not None,
                "audio_codec": master["audio_codec"] if audio else None,
                "sample_rate": master["sample_rate"] if audio else None}
    if video is None and audio is not None:
        exp = {"require_video": False, "require_audio": True,
               "sample_rate": master["sample_rate"]}
        if "wav" in fmt:
            exp["audio_codec"] = "pcm_s16le"
        return exp
    return {"require_video": video is not None,
            "video_codec": master["video_codec"] if video else None,
            "require_audio": False,
            "audio_codec": master["audio_codec"] if audio else None,
            "sample_rate": master["sample_rate"] if audio else None}


def _validate_media_bytes(mt, op, data, source, doc):
    probe = mt.probe_bytes(data)
    if probe is None:
        return {"check": "media_technical_validation", "ok": False,
                "source": source, "failures": [mt.MEDIA_TRUNCATED_OR_CORRUPT],
                "probe": None}
    exp = _media_expectations(mt, op, probe, doc)
    with mt.workdir("mm07-eval-media-") as workdir:
        path = workdir / "media.bin"
        path.write_bytes(data)
        validation = mt.validate_media(path, exp)
    return {"check": "media_technical_validation",
            "ok": validation["ok"], "source": source,
            "expectations": {k: v for k, v in exp.items() if v is not None},
            "failures": validation["failures"],
            "probe": {"format_name": probe.get("format_name"),
                      "duration_s": probe.get("duration_s"),
                      "streams": [{"type": s.get("type"),
                                   "codec": s.get("codec"),
                                   "width": s.get("width"),
                                   "height": s.get("height"),
                                   "sample_rate": s.get("sample_rate")}
                                  for s in probe.get("streams") or []]}}


def _media_technical_check(ctx, parsed):
    """Media-bearing artifacts: (i) a deliverable carrying an MM-06
    `media_output` sha — the referenced media bytes are fetched from
    the store and validated; claimed media whose bytes are absent is
    an integrity FAIL; (ii) an output artifact whose own bytes are
    probe-able media. Anything else is not media-bearing: no entry."""
    data = ctx["output_bytes"]
    if data is None:
        return []
    try:
        import media_tools as mt
    except Exception:  # noqa: BLE001 — validator unavailable: do not guess
        return []
    op = ctx["operation"]["operation_id"]
    if isinstance(parsed, dict):
        doc = _deliverable_of(parsed)
        mo = doc.get("media_output") if isinstance(doc, dict) else None
        if isinstance(mo, dict) and isinstance(mo.get("sha256"), str) \
                and refs_mod.SHA_RE.match(mo["sha256"]):
            media_bytes = _fetch_by_sha(ctx, mo["sha256"])
            if media_bytes is None:
                return [{"check": "media_technical_validation", "ok": False,
                         "source": "media_output",
                         "media_sha256": mo["sha256"],
                         "failures": ["MEDIA_BYTES_UNAVAILABLE"],
                         "probe": None}]
            return [_validate_media_bytes(mt, op, media_bytes,
                                          "media_output", doc)]
        return []
    stripped = data.strip()
    if stripped.startswith(b"{") or stripped.startswith(b"["):
        return []
    if mt.probe_bytes(data) is None:
        return []  # not media at all (e.g. plain-text artifacts)
    return [_validate_media_bytes(mt, op, data, "artifact_bytes", None)]


# ----------------------------------------------------------------- continuity
def continuity_layer(ctx):
    policy = ctx["operation"].get("validator_policy") or []
    if "dependency_integrity" not in policy:
        return {"evaluation": None, "applied": False,
                "report": {"layer": "continuity_checks", "applied": False,
                           "reason": "not_in_policy"}}
    planned = list(ctx["planned_input_ids"])
    superseded, missing_rows = [], []
    for aid in planned:
        row = ctx["all_by_id"].get(aid)
        if row is None:
            missing_rows.append(aid)
        elif row["state"] != "CURRENT":
            superseded.append({"artifact_id": aid, "state": row["state"],
                               "artifact_type": row["artifact_type"]})
    parsed, is_json = _parse_json(ctx["output_bytes"])
    declared, extra, missing = None, [], []
    declared_applied = False
    if is_json:
        declared_applied = True
        found = refs_mod.extract_refs(parsed)
        declared = sorted({r["value"] for r in found["artifact_ids"]})
        missing = sorted(set(planned) - set(declared))
        extra = sorted(d for d in set(declared) - set(planned)
                       if d in ctx["all_by_id"])
    problems = []
    if superseded:
        problems.append("planned inputs no longer CURRENT")
    if missing_rows:
        problems.append("planned inputs missing from artifacts")
    if declared_applied and missing:
        problems.append("output does not declare all planned inputs")
    if declared_applied and extra:
        problems.append("output declares inputs that were not planned")
    ev = _ev("continuity_checks", "continuity",
             "FAIL" if problems else "PASS", {
                 "layer": "continuity_checks", "deterministic": False,
                 "planned_input_ids": planned, "declared_input_ids": declared,
                 "missing_declared": missing, "extra_declared": extra,
                 "superseded_inputs": superseded,
                 "missing_inputs": missing_rows,
                 "declared_check_applied": declared_applied,
                 "problems": problems})
    return {"evaluation": ev, "applied": True,
            "report": {"layer": "continuity_checks", "applied": True,
                       "verdict": ev["verdict"], "problems": problems,
                       "superseded_inputs": superseded, "extra_declared": extra,
                       "missing_declared": missing}}


# ------------------------------------------------------------------- semantic
def _rubric_rule_of_six(parsed, min_weighted_total=None):
    block = _find_key(parsed, "rule_of_six")
    if not isinstance(block, dict):
        return None, ["rule_of_six block missing from content"]
    dims = block.get("dimensions")
    if not isinstance(dims, list):
        return None, ["rule_of_six.dimensions missing"]
    problems = []
    if len(dims) != 6:
        problems.append(f"expected 6 dimensions, found {len(dims)}")
    total = 0
    weighted = 0.0
    for d in dims:
        if not isinstance(d, dict) or not isinstance(d.get("weight"), (int, float)):
            problems.append(f"dimension without numeric weight: {d!r}")
            continue
        total += d["weight"]
        if not isinstance(d.get("score"), (int, float)):
            problems.append(f"dimension {d.get('name')!r} without numeric score")
        else:
            weighted += d["weight"] * d["score"]
    if total != 100:
        problems.append(f"dimension weights sum to {total}, expected 100")
    weighted_total = round(weighted / 100.0, 3) if total else None
    # MM-07: a score bar exists only where evaluation policy sets one
    # (the QA binding's rule_of_six_min_weighted_total param, the same
    # mechanism as 08.12's canon_ref_threshold_pct). No param -> no
    # bar; no factory-wide threshold is invented here.
    if min_weighted_total is not None and weighted_total is not None \
            and weighted_total < min_weighted_total:
        problems.append(f"weighted total {weighted_total} below threshold "
                        f"{min_weighted_total}")
    return (None if problems else {"dimensions": len(dims), "weight_sum": total,
                                    "weighted_total": weighted_total}), problems


def _rubric_script_canon(parsed, threshold_pct):
    lines = _find_key(parsed, "lines")
    if not isinstance(lines, list) or not lines:
        return None, ["script lines missing from content"]
    covered = 0
    for line in lines:
        if isinstance(line, dict):
            crefs = [c for c in (line.get("canon_refs") or []) if c]
            if crefs:
                covered += 1
    pct = round(100.0 * covered / len(lines), 2)
    stats = {"lines": len(lines), "lines_with_canon_refs": covered,
             "coverage_pct": pct, "threshold_pct": threshold_pct}
    if pct < threshold_pct:
        return None, [f"canon_ref coverage {pct}% < threshold {threshold_pct}%"]
    return stats, []


RUBRICS = {"12.12": "rule_of_six", "08.12": "script_canon_coverage"}


def semantic_layer(ctx, golden):
    policy = ctx["operation"].get("validator_policy") or []
    named = [p for p in policy if p not in BASE_POLICIES]
    if not named:
        return {"evaluation": None, "applied": False,
                "report": {"layer": "semantic_evaluation", "applied": False,
                           "reason": "policy names no semantic checks"}}
    base = {"layer": "semantic_evaluation", "deterministic": False,
            "named_checks": named}

    def review(evidence):
        ev = _ev("semantic_evaluation", "qa_binding", "REVIEW_REQUIRED", evidence)
        return {"evaluation": ev, "applied": True,
                "report": {"layer": "semantic_evaluation", "applied": True,
                           "verdict": "REVIEW_REQUIRED", **evidence}}

    def fail(evidence):
        ev = _ev("semantic_evaluation", "qa_binding_rubric", "FAIL", evidence)
        return {"evaluation": ev, "applied": True,
                "report": {"layer": "semantic_evaluation", "applied": True,
                           "verdict": "FAIL", **evidence}}

    binding = ctx["resolve_qa_binding"]()
    if binding is None:
        return review({**base, "status": "BLOCKED", "reason": "no_qa_binding"})
    provider = binding.get("provider")
    if isinstance(binding.get("params"), str):
        try:
            binding = {**binding, "params": json.loads(binding["params"])}
        except Exception:  # noqa: BLE001
            binding = {**binding, "params": {}}
    from adapters import build_registry  # gate-c worker_service (path set above)
    registry = build_registry(ctx.get("environment", "test"))
    adapter = registry.get(provider)
    if provider == "deterministic-local" and adapter is not None:
        op = ctx["operation"]["operation_id"]
        rubric_name = RUBRICS.get(op)
        if rubric_name is None:
            return review({**base, "status": "NO_RUBRIC",
                           "reason": f"no deterministic rubric for operation {op}",
                           "provider": provider})
        parsed, is_json = _parse_json(ctx["output_bytes"])
        if not is_json:
            return fail({**base, "status": "RUBRIC_FAIL", "rubric": rubric_name,
                         "problems": ["content is not JSON; rubric cannot run"]})
        params = binding.get("params") or {}
        if rubric_name == "rule_of_six":
            stats, problems = _rubric_rule_of_six(
                parsed, params.get("rule_of_six_min_weighted_total"))
        else:
            stats, problems = _rubric_script_canon(
                parsed, params.get("canon_ref_threshold_pct", 100))
        if problems:
            return fail({**base, "status": "RUBRIC_FAIL", "rubric": rubric_name,
                         "problems": problems})
        seed_n, expert_n = golden.counts()
        if not golden.armed():
            return review({**base, "status": "RUBRIC_PASS_UNARMED",
                           "rubric": rubric_name, "rubric_stats": stats,
                           "calibration": "NOT_ARMED",
                           "expert_cases": expert_n, "seed_cases": seed_n})
        ev = _ev("semantic_evaluation", "qa_binding_rubric", "PASS",
                 {**base, "status": "RUBRIC_PASS", "rubric": rubric_name,
                  "rubric_stats": stats, "calibration": "ARMED",
                  "expert_cases": expert_n, "seed_cases": seed_n})
        return {"evaluation": ev, "applied": True,
                "report": {"layer": "semantic_evaluation", "applied": True,
                           "verdict": "PASS", "rubric": rubric_name}}
    if adapter is None:
        return review({**base, "status": "BLOCKED", "reason": "unknown_provider",
                       "provider": provider})
    if getattr(adapter, "credential_required", False):
        if adapter.credential_for(binding) is None:
            return review({**base, "status": "BLOCKED",
                           "reason": "credential_absent",
                           "provider": provider,
                           "credential_ref": binding.get("credential_ref")})
        return review({**base, "status": "BLOCKED",
                       "reason": "real_semantic_judging_not_in_scope_gate_e",
                       "provider": provider})
    # e.g. the 'mock' adapter: it builds payloads, it cannot judge content.
    return review({**base, "status": "BLOCKED", "reason": "provider_cannot_judge",
                   "provider": provider})
