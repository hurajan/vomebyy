"""Golden-case registry + runner (Gate E arming rule).

Arming mirrors the Studio framework's standing rule, enforced in code:
only cases with provenance 'EXPERT' count, and 50+ are required. SEED
cases are factory fixtures for the deterministic layers only and can
never arm the semantic layer. Current factory-local state: SEED cases
only -> NOT ARMED; while unarmed a semantic rubric PASS yields
REVIEW_REQUIRED (see layers.semantic_layer).

Case file format (one JSON object per file in golden_cases/):
    {"case_id": str, "provenance": "SEED"|"EXPERT",
     "operation_id": str, "artifact_type": str,
     "content": str,                          # output artifact content
     "inputs": [{"artifact_id", "artifact_type", "content", "state"}],
     "planned_input_ids": [artifact_id...],
     "extra_current_artifacts": [{"artifact_id", "sha256", "artifact_type"}],
     "expect": {"schema_validation": verdict,
                "deterministic_checks": verdict,
                "continuity_checks": verdict}}

The runner builds a synthetic evaluation context per case and scores the
three deterministic layers against `expect`. The semantic layer is never
scored here — it has no golden truth to score against until EXPERT cases
exist.
"""
import hashlib
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import layers  # noqa: E402

CASES_DIR = Path(__file__).resolve().parent / "golden_cases"
ARM_THRESHOLD = 50
PROVENANCES = ("SEED", "EXPERT")


def load_cases(cases_dir=None):
    cases = []
    for path in sorted((cases_dir or CASES_DIR).glob("*.json")):
        case = json.loads(path.read_text())
        if case.get("provenance") not in PROVENANCES:
            raise ValueError(f"{path.name}: provenance must be one of {PROVENANCES}")
        cases.append(case)
    return cases


def counts(cases=None):
    cases = load_cases() if cases is None else cases
    seed = sum(1 for c in cases if c["provenance"] == "SEED")
    expert = sum(1 for c in cases if c["provenance"] == "EXPERT")
    return seed, expert


def armed(cases=None):
    _, expert = counts(cases)
    return expert >= ARM_THRESHOLD


def _synthetic_ctx(case):
    production_id = "golden-case-production"
    content_bytes = case["content"].encode()
    output_artifact = {
        "artifact_id": case.get("artifact_id", "00000000-0000-4000-8000-0000000000aa"),
        "artifact_type": case["artifact_type"], "version": 1,
        "state": "CURRENT", "production_id": production_id,
        "sha256": hashlib.sha256(content_bytes).hexdigest(),
        "storage_uri": "golden-case://content"}
    input_artifacts, all_by_id = [], {output_artifact["artifact_id"]: output_artifact}
    for inp in case.get("inputs", []):
        ib = inp["content"].encode() if inp.get("content") is not None else None
        row = {"artifact_id": inp["artifact_id"],
               "artifact_type": inp["artifact_type"], "version": 1,
               "state": inp.get("state", "CURRENT"),
               "production_id": production_id,
               "sha256": hashlib.sha256(ib).hexdigest() if ib is not None else "0" * 64,
               "storage_uri": "golden-case://input",
               "content_bytes": ib}
        input_artifacts.append(row)
        all_by_id[row["artifact_id"]] = row
    current_by_sha = {}
    for row in all_by_id.values():
        if row["state"] == "CURRENT":
            current_by_sha[row["sha256"]] = row
    for extra in case.get("extra_current_artifacts", []):
        row = {"artifact_id": extra["artifact_id"], "artifact_type": extra["artifact_type"],
               "version": 1, "state": "CURRENT", "production_id": production_id,
               "sha256": extra["sha256"], "storage_uri": "golden-case://extra"}
        all_by_id[row["artifact_id"]] = row
        current_by_sha[row["sha256"]] = row
    op_id = case["operation_id"]
    return {
        "production_id": production_id,
        "unit": {"unit_id": "golden-case-unit", "operation_id": op_id,
                 "current_attempt": 1},
        "operation": {"operation_id": op_id, "step_id": op_id.split(".")[0],
                      "capability_slot": "golden_case",
                      "validator_policy": ["schema_validation", "dependency_integrity"]},
        "output_artifact": output_artifact, "output_bytes": content_bytes,
        "input_artifacts": input_artifacts,
        "planned_input_ids": list(case.get("planned_input_ids", [])),
        "all_by_id": all_by_id, "current_by_sha": current_by_sha,
        "environment": "test",
        "resolve_qa_binding": lambda: None,
    }


def run_cases(cases=None):
    """Score the deterministic layers against each case's expectations.
    -> {"cases": n, "per_layer": {layer: {"correct", "total"}}, "details": [...]}"""
    cases = load_cases() if cases is None else cases
    per_layer = {}
    details = []
    for case in cases:
        ctx = _synthetic_ctx(case)
        results = {"schema_validation": layers.schema_layer(ctx),
                   "deterministic_checks": layers.technical_layer(ctx),
                   "continuity_checks": layers.continuity_layer(ctx)}
        detail = {"case_id": case["case_id"], "provenance": case["provenance"],
                  "layers": {}}
        for name, res in results.items():
            expected = (case.get("expect") or {}).get(name)
            if expected is None:
                continue
            actual = res["evaluation"]["verdict"] if res["evaluation"] else None
            ok = actual == expected
            bucket = per_layer.setdefault(name, {"correct": 0, "total": 0})
            bucket["total"] += 1
            bucket["correct"] += 1 if ok else 0
            detail["layers"][name] = {"expected": expected, "actual": actual, "ok": ok}
        details.append(detail)
    return {"cases": len(cases), "per_layer": per_layer, "details": details}
