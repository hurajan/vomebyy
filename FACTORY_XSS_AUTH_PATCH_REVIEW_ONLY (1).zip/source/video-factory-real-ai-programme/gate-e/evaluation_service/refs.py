"""Artifact-reference extraction from factory payload content.

Shared by the technical layer (references_resolve: every extracted
reference must resolve to a CURRENT artifact of the production) and
the continuity layer (declared references vs the unit's planned
inputs).

What counts as a reference is decided by KEY/POSITION, never by the
value's shape (MM-10 fix F-MM10-02). The pre-fix extractor treated
every 64-hex string under a sha-named key as an artifact reference;
at full-chain scale that deterministic-FAILed legitimate outputs
whose payloads carry COMPUTED digests — hash attestations
(attestation_sha256, and content digests inside input_sha256 lists),
content-analysis digests (analyses[i].sha256), and store-object shas
(media_output.storage_uri) — none of which is, or can ever be, an
artifact's recorded sha256 (verified against the MM-10 battery DB:
46/46 failing values matched no artifact row in any state).

Reference positions, from the actual factory payload shapes
(gate-c payloads.py / actions.py, g5-g8 workers):

  * artifact ids: UUID string values under keys named 'artifact_id',
    ending in '_artifact_id', ending in '_ref' or '_refs' (e.g.
    script_ref, master_ref, timeline_ref, canon_refs), and under
    'depends_on'. Internal story ids under *_ref keys (S1, B1, SC1,
    L1) are not UUIDs and are never extracted.
  * artifact shas: a 64-hex string ONLY when it occupies a reference
    position, namely
      - as the value (or a list element) of one of the id keys above
        or of 'depends_on' — a reference field carrying a sha instead
        of a UUID; a store:// / mock-store:// URI in such a field
        contributes its embedded sha; or
      - as the value of a PAIRED PIN field: a '<stem>_sha256' (or
        '<stem>_sha') key whose containing object also carries
        '<stem>_ref' or '<stem>_artifact_id' with a UUID value. This
        is the 13.12 master_package pattern ('timeline_ref' +
        'timeline_sha256', 'registry_ref' + 'registry_sha256') —
        the one place factory payloads pin a referenced artifact
        by sha.
  * null references: a None under one of the reference keys above
    (payloads emit canon_refs: [None] when an input was absent) —
    counted and reported, never treated as a dangling reference.

Digest/data positions — never extracted as references:

  * bare 'sha256' keys in any object (inside deliverable content a
    'sha256' is a payload-internal hash — asset payload hashes in
    asset_registry / derivative_package, publication hashes in
    distribution_record, per-entry CONTENT digests in
    content-analysis results, whose artifact_id/artifact_type fields
    name the analyzed artifact while the sha digests its content);
  * '*_sha256' / '*_sha' / '*_hash' / '*_hashes' fields without the
    paired pin (attestation_sha256, input_sha256, source_sha256,
    content_sha256, asset_hashes) — computed digests and digest
    lists, cross-checked where the factory defines a check by the
    op-specific checks against their source data;
  * sha strings under any other key, and store-object shas embedded
    in URIs in data fields (media_output.storage_uri names a Gate D
    store OBJECT; those bytes are fetched and probe-validated by
    the media-technical check, not resolved as an artifact).

The step-contract envelopes describe themselves through manifest
arrays ('output_artifacts' / 'input_artifacts'); an entry's own
'artifact_id' and 'sha256' fields are manifest data (shape-checked
by the schema layer), not content references, so they are skipped
here — but any other key inside a manifest entry is walked normally
under the same position rules.
"""
import re

UUID_RE = re.compile(r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$")
SHA_RE = re.compile(r"^[0-9a-f]{64}$")
URI_SHA_RE = re.compile(r"(?:mock-store|store)://(?:objects/|candidates/)?([0-9a-f]{64})")
MANIFEST_KEYS = {"output_artifacts", "input_artifacts"}
MANIFEST_SELF_KEYS = {"artifact_id", "sha256"}


def _is_id_key(key):
    return key == "artifact_id" or key.endswith("_artifact_id") \
        or key.endswith("_ref") or key.endswith("_refs")


def _is_ref_key(key):
    """Keys whose values sit in reference positions (ids and shas)."""
    return _is_id_key(key) or key == "depends_on"


def _paired_stems(node, skip_keys=()):
    """Stems <stem> for which this object carries a '<stem>_ref' or
    '<stem>_artifact_id' key with a UUID value — the stems whose
    '<stem>_sha256'/'<stem>_sha' fields are paired pins."""
    stems = set()
    for key, value in node.items():
        if key in skip_keys or not isinstance(value, str) \
                or not UUID_RE.match(value):
            continue
        if key.endswith("_artifact_id"):
            stems.add(key[:-len("_artifact_id")])
        elif key.endswith("_ref"):
            stems.add(key[:-len("_ref")])
    return stems


def _is_sha_ref_key(key, paired_stems):
    """A sha-valued key is a reference position only as a paired pin."""
    if key.endswith("_sha256"):
        return key[:-len("_sha256")] in paired_stems
    if key.endswith("_sha"):
        return key[:-len("_sha")] in paired_stems
    return False


def extract_refs(node):
    """-> {"artifact_ids": [{"value", "path"}...], "shas": [...],
    "null_refs": int}. Occurrences are not deduplicated; callers dedupe."""
    out = {"artifact_ids": [], "shas": [], "null_refs": 0}
    _walk(node, "$", out, skip_keys=())
    return out


def _walk(node, path, out, skip_keys):
    if isinstance(node, dict):
        paired = _paired_stems(node, skip_keys)
        for key, value in node.items():
            if key in skip_keys:
                continue
            _walk_value(key, value, f"{path}.{key}", out, paired)
    elif isinstance(node, list):
        for i, element in enumerate(node):
            _walk(element, f"{path}[{i}]", out, skip_keys=())


def _walk_value(key, value, path, out, paired_stems):
    ref_key = _is_ref_key(key)
    sha_key = _is_sha_ref_key(key, paired_stems)
    # null references under reference-like keys
    if value is None:
        if ref_key or sha_key:
            out["null_refs"] += 1
        return
    if isinstance(value, str):
        if ref_key:
            for m in URI_SHA_RE.finditer(value):
                out["shas"].append({"value": m.group(1), "path": path})
            if UUID_RE.match(value):
                out["artifact_ids"].append({"value": value, "path": path})
            elif SHA_RE.match(value):
                out["shas"].append({"value": value, "path": path})
        elif sha_key and SHA_RE.match(value):
            out["shas"].append({"value": value, "path": path})
        return
    if isinstance(value, list):
        if ref_key or sha_key:
            for i, element in enumerate(value):
                if element is None:
                    out["null_refs"] += 1
                elif isinstance(element, str):
                    if ref_key and UUID_RE.match(element):
                        out["artifact_ids"].append(
                            {"value": element, "path": f"{path}[{i}]"})
                    elif SHA_RE.match(element) and (ref_key or sha_key):
                        out["shas"].append(
                            {"value": element, "path": f"{path}[{i}]"})
                    elif ref_key:
                        m = URI_SHA_RE.search(element)
                        if m:
                            out["shas"].append(
                                {"value": m.group(1), "path": f"{path}[{i}]"})
                    else:
                        _walk(element, f"{path}[{i}]", out, skip_keys=())
                else:
                    _walk(element, f"{path}[{i}]", out, skip_keys=())
            return
        if key in MANIFEST_KEYS:
            for i, element in enumerate(value):
                if isinstance(element, dict):
                    _walk(element, f"{path}[{i}]", out,
                          skip_keys=MANIFEST_SELF_KEYS)
                else:
                    _walk(element, f"{path}[{i}]", out, skip_keys=())
            return
        _walk(value, path, out, skip_keys=())
        return
    _walk(value, path, out, skip_keys=())
