# GATE E REPORT — Independent evaluation and repair evidence

**Status: GATE E COMPLETE + INDEPENDENTLY VERIFIED, defects NONE — ACCEPTED by Raj 2026-10-28, who also CONFIRMED the Gate F lock (OD-E1 explicitly deferred to before Gate G).** Lock: LOCK_GATE_E.md (Gate D accepted + Gate E lock confirmed by Raj 2026-10-28). Evidence: suite logs in `evidence/logs/`, verifier report `evidence/GATE_E_VERIFIER_REPORT.md`. No pre-existing test assertions were changed anywhere in this gate.

## Results

**Suites (143 total, all green):** evaluation_service 21/21 (new) · G1 9/9 · G2 58/58 · G3 20/20 · G4 2/2 · G5 1/1 · G6 3/3 · G7 2/2 · G8 1/1 · G9 9/9 · worker_service 11/11 · storage_service 5/5.

- **The evaluation service exists and is independent in fact** (verifier-read code + own probes): it loads only coordinator state, treats any worker verdict as an advisory report field that never enters the submitted evaluations, writes nothing to the database directly, and submits layer evaluations through the API as the VALIDATOR role. Layers are driven by each operation's registry `validator_policy` (vocabulary mapped: `schema_validation` → schema layer; `dependency_integrity` → technical + continuity; the step-specific names → semantic-layer checks).
- **Verified behaviors** (verifier's own end-to-end run): schema violation → BLOCKED with the violation recorded; dangling sha reference → BLOCKED (deterministic); superseded planned input → REPAIR_REQUIRED with the superseded artifact identified; Rule-of-Six rubric passing under a deterministic-local binding → **AWAITING_HUMAN, not ACCEPTED**, with `calibration: NOT_ARMED, expert_cases: 0` in evidence. The schema engine is a documented subset covering exactly the constructs the 32 contracts use (census-verified; cross-checked verdict-identical against the real `jsonschema` package; unsupported constructs fail closed).
- **Arming math proven**: only EXPERT provenance counts, threshold 50 (49 EXPERT → unarmed; 60 SEED → unarmed). Factory golden set: 6 SEED / 0 EXPERT → NOT ARMED, as designed.
- **Repair loop closes with existing machinery**: continuity FAIL → REPAIR_REQUIRED → `repair_ready` → corrected attempt → deterministic layers PASS → AWAITING_HUMAN → human approval → ACCEPTED. No coordinator changes were needed; the `/validate` endpoint learned the evaluations-array shape (contract 1.3.0) with the legacy body untouched.

## OD-E1 — the envelope decision (owner ruling needed before Gate G)

Confirmed factually by the verifier with the real `jsonschema` package: **the registry's 32 step contracts describe an envelope** (`{production_id, operation_id, status, output_artifacts[], evidence[]}`), and **the accepted stations' real payloads are not envelope-shaped** (a real G5 script artifact fails the step-08 output schema on all five envelope fields). The contracts were data nobody executed until this gate (Gate A finding GA-06). Until this is ruled, wiring the stations to the service (Gate G) would make every real output record schema violations. The options:

- **(i) Contracts are authoritative** — worker outputs become envelopes whose `output_artifacts` carry the deliverables. Payload producers (worker service + station workers) change at Gate G; the deliverable shapes survive inside the envelope.
- **(ii) Payloads are authoritative** — the 32 contracts are regenerated to describe the deliverable shapes the factory actually produces (a registry-content change: new contract files, definition-hash implications to handle under the §18 versioning protocol — the operations' schema references live in the seed, so this is a workflow-version change, not a quiet edit).
- **(iii) Layered** — envelope at step boundaries (`.12` exits carry the envelope as a wrapper artifact) and deliverable schemas for the artifacts inside it; contracts split accordingly.

No recommendation is smuggled in: (i) is the smallest change to data and the largest to producers; (ii) rewrites the registry's contract layer; (iii) is the most faithful to both and the most work. Gate F does not depend on this decision; Gate G does.

## Honest limits

Real semantic judging remains BLOCKED (no credentials/budget authority): the layer records BLOCKED and routes to human — which, combined with the unarmed golden set, means **no unit can be accepted by evaluation alone today**; every registry operation's policy names semantic checks, so evaluation-only acceptance is impossible until either EXPERT ground truth exists (50+) or a policy changes. That is the lock's intended posture, recorded so it is not mistaken for a defect.

## Next gate as planned (Gate F — needs its own lock)

Scheduling and recovery services: the scheduler service (config-priced claims, capacity lanes honored), the outbox dispatcher, the lease-reaper loop, the reconciler running as a service against the Gate C async path, bounded retries with backoff/jitter and attempt caps, dead-letter handling, and restart recovery — the machinery that makes the factory run unattended instead of being driven by test drivers.
