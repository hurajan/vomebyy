# Gate G — Changed pre-existing assertions, fixtures and behaviors

Every change to a pre-existing test assertion, fixture, seed, or
library behavior made during the Gate G build, with the reason and how
the original intent is preserved. Suite-level mechanics that changed
without altering any assertion (drivers returning human-decision
records, content reads moving to the Gate D store) are listed too,
because they change how the suites exercise the system.

## Part A — contracts, worker service, evaluation service

1. **Envelope status is `CANDIDATE`, not the brief's `COMPLETED`.**
   The frozen step output schemas (g1 contracts, 32 files, untouched)
   define the envelope status enum as
   [CANDIDATE, ACCEPTED, REVIEW_REQUIRED, BLOCKED]. The worker
   service wraps step-exit payloads with status CANDIDATE; ACCEPTED
   remains a state the coordinator reaches through validation, never
   a worker claim. Intent preserved: exits are wrapped and validated
   against the frozen envelope contracts — with the only status value
   those contracts allow a producer to assert.

2. **Envelope evidence shape** is `[{validator, method, result}]`
   (the frozen envelope schema's required evidence keys,
   additionalProperties false) instead of the brief's sketched
   `{kind: ...}` object. Provenance (provider, model, config_hash,
   attempt_id) is carried in the entry's `detail` string.
   Intent preserved: every exit artifact carries worker provenance
   bound to the attempt's resolved config hash.

3. **Gate E golden seeds 01–05**: candidate fixtures now embed valid
   deliverable content inside the envelope entries (the layered
   schema layer validates entry content against the new deliverable
   schemas; envelope-only fixtures would fail deterministically).
   Seed 06 (not-applicable) untouched. **New seed 07**
   (deliverable-violation): envelope valid, deliverable content
   invalid → schema FAIL while the technical layer PASSes — the
   layered behavior OD-E1 (iii) exists to catch.
   `TestHealth.test_seed_cases_present_and_well_formed` count 6 → 7.

4. **Evaluation test fixtures** (`test_evaluation_service.py`): the
   `envelope()` helper now embeds valid deliverable content in its
   entries (same reason as 3); the 12.12 helper case computes its
   Rule-of-Six weighted total from the embedded dimensions so the
   op-specific check still verifies a self-consistent deliverable.

5. **Schema-engine contract test rescoped**: the family test that
   asserted "all 50 contracts subset-supported" now covers the 32
   step contracts, plus a new test covering the 18 deliverable
   schemas. No contract file changed; the count split reflects the
   new contracts directory.

6. **refs.py extraction rules** (deterministic layers): a bare
   `sha256` key counts as an artifact reference only inside a
   manifest-like object (artifact_id + artifact_type present), and
   `asset_hashes` are not extracted as references. Reason: inside
   deliverable content those are payload-internal hashes (asset
   payload hashes, publication hashes), cross-checked by the
   op-specific checks against their source artifacts — treating them
   as store references made every master/distribution artifact fail
   reference resolution. Technical-layer intent (every *artifact*
   reference resolves) is unchanged.

7. **13.12 op-specific check semantics**: `master_asset_hashes…`
   compared the master's asset_hashes against reference strings
   harvested from artifact bytes (broken once payload hashes stopped
   being references). It now compares against the asset_registry
   *input's* assets[].sha256 set (check renamed
   `master_asset_hashes_match_registry`). Intent preserved and
   strengthened: the master's hashes must equal the registry's.

8. **14.12 policy check input source**: the derivative-portfolio
   policy check read the portfolio only from planned inputs; it now
   falls back to the production's current derivative_portfolio (a
   14.01 unit's QA binding cannot have the not-yet-produced portfolio
   as a planned input) and records `portfolio_source` in evidence.

9. **Input-side schema validation**: producer envelopes on a unit's
   inputs are validated against the producer step's envelope +
   deliverable schemas; legacy input-envelopes against the consuming
   step's input schema; non-JSON or bare-payload inputs are recorded
   as skipped, never as violations (fixtures and registered documents
   are not envelope producers). This replaces silent acceptance of
   malformed producer output while keeping fixture inputs lawful.

10. **Coordinator `register_artifact` now persists bytes**: Gate D
    stored bytes only for completions; direct registrations were
    metadata pointing at external URIs, so the Gate E context loader
    (which reads bytes by sha, per its documented assumption) and
    the worker service could never read a registered fixture. The
    library now stages + promotes the provided bytes into the same
    content-addressed store; the recorded storage_uri is unchanged.
    No G2 assertion changed (verified by the G2 regression).

11. **Coordinator `event()` readiness recompute**: a transition into
    ACCEPTED via the events endpoint (the human_approved path) did
    not promote PENDING dependents — only validate-acceptance did.
    `event()` now recomputes readiness after an ACCEPTED transition.
    Found live in Part B (station chains stalled after driver human
    approval). No assertion changed; behavior completed to match the
    state machine's intent.

11b. **Coordinator `event()`: human approval closes the attempt as
    ACCEPTED.** Gate E's submit_validation closes an attempt as
    FAILED whenever validation does not accept immediately —
    including `validation_needs_human`. When the human approves, the
    unit accepts that attempt's candidate, but the attempt stayed
    FAILED (the G9 station-5 recovery battery asserts the recovered
    attempt is ACCEPTED — the truthful record). `event()` now flips
    the current attempt FAILED → ACCEPTED when a human_approved
    transition lands the unit in ACCEPTED. Human rejection is
    untouched (attempt stays FAILED).

12. **Deterministic adapter `reported_actual_cents`** (judgment
    call, brief-prescribed): the adapter reports the binding's
    `params.reported_actual_cents` when present, else the estimate.
    Setups seed est 100 / reported 90, preserving the accounting the
    G5/G9 suites assert (per-completion actual 90; G9 full run
    18 × 90 = 1620¢) with the discrepancy carried as binding DATA,
    not code.

## Part B — station suites g4–g8

13. **Drivers (`run_once`)** now (a) post `human_approved` for
    AWAITING_HUMAN units before dispatching (the harness acting as
    the human — the QA binding resolves to the unarmed factory mock,
    so evaluated units lawfully pause for a human), return
    `{"dispatched": [...], "human_decisions": [...]}` instead of a
    bare list (no pre-existing assertion consumed the old shape), and
    (b) (re)dispatch RETRY_WAIT units so the executor's retry branch
    fires (F-G9-03 design); the dispatch-state set only suppresses
    duplicate READY dispatches.

14. **Content assertions read the Gate D store** (by sha, hash
    verified) and unwrap layered envelopes to the deliverable
    (helpers in g5–g8 tests + g9_common). The assertions themselves —
    fields, references, totals — are unchanged; only where the bytes
    live and the envelope around them changed, which is the gate's
    subject.

15. **Fixture alignment — planned inputs replace runtime lookup.**
    The old mock workers resolved related artifacts by API lookup at
    runtime ("the mock stand-in for receiving canon as a unit
    input"). The wired worker service receives only planned inputs,
    so suites now plan what each builder consumes and declares:
    G5/G9 — 06.12, 07.12, 08.12 planned with the canon manifest
    (previously only 05.12); G8/G9 — 16.12 planned with
    [portfolio, distribution] (the two inputs its builder consumes
    and declares via portfolio_ref + distribution_ref). No assertion
    weakened: the cross-reference assertions (script canon_refs,
    learning comparison keys, ref/hash verification) are the same
    checks against the same artifacts, now reached through the real
    input path.

16. **G5 chain test** additionally accumulates driver human
    decisions and asserts the human-approval path was exercised at
    least once (strengthening: proves the AWAITING_HUMAN → ACCEPTED
    leg ran, which the old in-workflow validation never needed).

17. **G6 setup seeds an OPERATION binding for 12.12.** The registry
    assigns operation 12.12 to station 5 while the G6 tree's
    executor serves steps 09–12 (its lock's scope); claim resolution
    probes the registry station, so 12.12 fell through to the
    FACTORY mock seed and the worker service refused the mock
    binding. The OPERATION-scope deterministic binding makes the
    tree's actual coverage executable. The registry and the tree
    locks are both untouched; the divergence is recorded here.

## Part C — G9 harness

18. **Store-copy bridge deleted** (`bridge_stores`,
    `copy_store_files` and all calls): there is one content store
    now (Gate D); the full run reads it directly. The ref/hash
    assertions the bridge served are unchanged (content_of verifies
    sha256 of the stored bytes before unwrapping).

19. **Failure-battery `register()`** no longer writes per-tree
    mock-store files (vestigial once registration persists bytes —
    item 10). Its API contract is unchanged.

20. **Failure-battery + full-run acceptance waits** drive the
    station driver until ACCEPTED instead of passively polling
    (units pause at AWAITING_HUMAN under the layered QA policy;
    item 13a). Attempt-count, budget, and state assertions are
    unchanged.

## Part D — API + dashboard

21. **API contract 1.3.0 → 1.4.0** (additive): two new reads
    (unit evaluations, unit provider-jobs), units list gains
    planned-input fields, attempts gain lease fields. The contract
    test's endpoint-coverage assertion now exercises the new reads
    against a legacy validation + an empty jobs list, and a new
    TestApiGateG class covers them against real rows.

22. **Dashboard tests**: VIEWS gains `configs` + `pricing` (the new
    views); a new test asserts the Gate G unit-detail elements
    (attempts/jobs/verdicts/cost tables, retry + cancel actions,
    soft-ceiling flag) are present. The UI-calls ⊆ contract test is
    unchanged in form and now also covers the new calls.
