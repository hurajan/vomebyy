# GATE G VERIFIER REPORT — Independent verification

**Verdict: VERIFIED — all eight items CONFIRMED. Defects: NONE (no CRITICAL, MAJOR, or MINOR findings).** One factual premise correction is recorded under item 8 (the task brief's expectation about items #10/#11's provenance was wrong; the builder's own record is accurate).

All evidence below was obtained independently: logs read from disk, registry and manifest hashes recomputed, hygiene grepped by hand, G9 facts queried from the persisted full-run database, and the layered-evaluation behavior exercised by my own probe against a chain-built scratch DB with the real API (port 8731) and evaluation service (port 8951). No product code was modified; the scratch DB was dropped and my services stopped.

## 1. Logs — CONFIRMED

Final canonical (partE) logs in `gate-g/evidence/logs/`, each read directly: G1 9 OK · G2 58 OK · G3 25 OK · G4 2 OK · G5 1 OK · G6 3 OK · G7 2 OK · G8 1 OK · G9 9 OK · worker_service 19 OK · storage_service 5 OK · evaluation_service 25 OK · runtime_services 10 OK. **Total 169, all OK** — exactly the builder's claim.

## 2. Registry integrity — CONFIRMED

- `registry_tool.py validate` (my run): verdict PASS, errors/warnings empty, 192 operations, definition_hash `ea4503f516fc4f7940f187f5cd9dac38c57f0d239726cac90e2d0a18a8bc9d73`, source_sha256 `0f3f3871…`.
- Seed `operations.json` SHA-256 recomputed and **identical** to the Gate A source-manifest entry.
- All **32 envelope contract files** listed in the Gate A manifest recomputed — zero modified, zero missing.
- **18 new files** exist under `g1/contracts/deliverables/`: `step-01…step-16.schema.json` + `op-14.01.schema.json` + `generic-fallback.schema.json`.

## 3. Workflow hygiene (own grep) — CONFIRMED

- Across every generated workflow JSON in g4–g8 `workflows/` dirs: **zero** occurrences of `127.0.0.1`, `localhost`, and `dev-operator-token`.
- Positive control: all five `unit-executor.json` files contain `$env.FACTORY_API_URL`, `$env.FACTORY_EVALUATION_URL`, `$env.FACTORY_WORKER_TOKEN`, `$env.FACTORY_SCHEDULER_TOKEN` expressions.
- The five `gen_workflows.py` sources contain **no** token credentials and **no** `estimated_cents` in claim bodies (zero hits); the only occurrences of the needle strings in the sources are the generation-time hygiene check's own search list (one line per tree) — the test, not a credential.

## 4. G9 facts — CONFIRMED

From the persisted `g9_fullrun_scratch` database (not the log alone):
- The "G9 full run" production has **18 units, 18 ACCEPTED**.
- Its budget transactions: CHARGE total **1620¢**; all 18 reservations in state SETTLED → held/reserved **0**.
- `human_gates`: HG2, HG4, HG5 each carry an APPROVED verdict; `audit_events` records **18 `human_approved`** events for the full-run production (21 across the DB) — the driver human-decision path was genuinely exercised.
- Bridge removal: `g9/tests/g9_common.py` contains no `bridge_stores`/`copy_store_files` definitions or copy/shutil logic — the only mention of the bridge is the header comment stating it is gone.

## 5. Layered evaluation (own probe) — CONFIRMED

On my own chain (`gateg_verify_scratch`, API on 8731 with a validator token, evaluation service on 8951, units built at library level):
- **(a) Envelope valid, deliverable invalid** (step-05 deliverable missing `canon_refs`): schema layer verdict **FAIL**, `deterministic: true`, violation at `$.output_artifacts[0].content` — "missing required property 'canon_refs'" — with `deliverable_schema: contracts/deliverables/step-05.schema.json` recorded; unit state **BLOCKED**.
- **(b) Fully layered-valid**: schema layer verdict **PASS** (both envelope and deliverable levels recorded as checked); the unit landed **AWAITING_HUMAN** via the semantic layer, exactly as expected while the golden set is unarmed. The assertion target (schema-layer verdicts in `quality_evaluations`) held in both cases.

## 6. The 12.12 divergence (factual) — CONFIRMED as recorded

- `operation_definitions` for **12.12: station = 5** (step 12), while the G6 tree (Station 4, steps 09–12) serves 12.12 in its suite — G6 suite log: 3/3 OK including 12.12 execution.
- The compensation exists exactly as CHANGED_ASSERTIONS #17 records: `g6/tools/setup_env.py` (lines ~121–132, with an explanatory comment) seeds an **OPERATION-scope deterministic-local binding for 12.12**, because claim resolution probes the registry station (5) and would otherwise fall through to the FACTORY mock seed, which the worker service refuses.
- Stated factually, without prescribing a fix: the registry's station assignment for 12.12 diverges from the G6 lock's station scope; Gate G bridged it with binding data, touching neither the registry nor the tree locks.

## 7. Dashboard / contract — CONFIRMED

- `g3/contracts/api_contract.json`: `contract_version` **1.4.0**, **34 endpoints**, including `GET /units/{uid}/evaluations` and `GET /units/{uid}/provider-jobs`.
- The G3 suite log (25/25 OK) includes the dashboard tests; the UI-calls-⊆-contract discipline passes against the grown contract.
- Dashboard `index.html` contains the new surface: `configs` and `pricing` views, `resolved_config_hash` in unit detail, `evaluations` and `provider-jobs` calls, and soft-ceiling display.

## 8. Changed assertions (23 entries) — CONFIRMED, with one premise correction

- Entry count re-counted: **23** (Part A: 1–12 + 11b = 13; Part B: 13–17 = 5; Part C: 18–20 = 3; Part D: 21–22 = 2).
- **#1 spot-check CONFIRMED**: the frozen step output schemas' envelope `status` enum is `[CANDIDATE, ACCEPTED, REVIEW_REQUIRED, BLOCKED]` (read directly from `step-05/output.schema.json`) — `COMPLETED` is indeed not a value a producer may assert; the builder's use of CANDIDATE is the only lawful choice.
- **#10/#11/#11b — behaviors CONFIRMED in code; premise of my brief corrected.** `coordinator.py` today does persist bytes on `register_artifact` (`storage.put_candidate` + `promote`, with a comment explaining the Gate E loader assumption), and `event()` does recompute readiness after an ACCEPTED transition and closes the current attempt FAILED → ACCEPTED on the `human_approved`-from-AWAITING_HUMAN path (both commented as Gate G behavior). However, these were **not** pre-existing Gate D/F-era code the builder merely relied on: the file's mtime (2026-10-29 01:02 UTC) falls inside Gate G's build window (Gate F report: 2026-10-29 00:14 UTC), and CHANGED_ASSERTIONS itself lists them as Gate G changes (items 10, 11, 11b). The builder's record is accurate; the expectation in my verification brief was not. This is recorded as a factual correction, not a defect: the changes are disclosed, commented, confined to the two behaviors, and the G2 suite stands at 58/58 with no assertion changed.
- **#17** is covered by item 6 above.

## Defects

None. Every builder claim I was asked to test held under independent re-derivation, including the two strongest ones: the generated workflows carry no loopback hosts or credential literals anywhere, and the full G9 run's acceptance now flows through evaluation plus recorded human decisions at exactly 1620¢.
