# GATE G REPORT — n8n regeneration, station rewiring, dashboard completion

**Status: GATE G COMPLETE + INDEPENDENTLY VERIFIED, defects NONE — ACCEPTED by Raj 2026-10-28 explicitly including the §3 coordinator scope note, who also CONFIRMED the Gate H lock.** Lock: LOCK_GATE_G.md (Gate F accepted + OD-E1 ruled (iii) layered + Gate G lock confirmed by Raj 2026-10-28). Evidence: suite logs in `evidence/logs/`, `evidence/CHANGED_ASSERTIONS.md` (23 entries), verifier report `evidence/GATE_G_VERIFIER_REPORT.md`.

## Results

**Suites (169 total, all green):** G1 9/9 · G2 58/58 · G3 25/25 · G4 2/2 · G5 1/1 · G6 3/3 · G7 2/2 · G8 1/1 · G9 9/9 · worker_service 19/19 · storage_service 5/5 · evaluation_service 25/25 · runtime_services 10/10.

- **OD-E1 (iii) is live.** 18 deliverable schemas authored from the real payloads sit alongside the untouched registry contracts (verifier: seed + all 32 envelope files byte-identical to the Gate A manifest; definition_hash still ea4503f5…). Step exits now produce the registry envelope with the deliverable inside; the evaluation service checks both levels — the verifier's own probe failed a unit whose envelope was valid but whose deliverable omitted a required field (BLOCKED, path named), and passed a fully layered-valid unit.
- **The full run runs on the new machinery.** G9's persisted production: 18 units, 18 ACCEPTED, charges exactly 1620¢, all reservations settled, HG2/HG4/HG5 approved en route, and 18 `human_approved` audit events — the evaluation service's unarmed semantic layer routed every unit to the human decision, which the driver performed as the recorded harness-human. The store-copy bridge is deleted; content moves through the Gate D store by hash.
- **Workflow hygiene verified independently**: zero `127.0.0.1`, `localhost`, or token values in any generated workflow JSON; all five executors carry `$env` expressions for URLs and role tokens; claims send no `estimated_cents` (config prices them); validation verdicts no longer come from executors at all.
- **Dashboard completed** (contract 1.4.0, 34 endpoints): unit detail with provider/model/config version/resolved hash/lease expiry, provider jobs, QA verdicts, per-unit FINALIZED cost, retry + cancel controls; Configs and Pricing views with create forms; soft-ceiling state wired. UI-calls-⊆-contract still enforced by test. Real-browser rendering remains NOT TESTED (standing limitation since G3).
- **Accounting honesty as data**: the deterministic adapter's reported actual (90¢ against a 100¢ estimate) is now `reported_actual_cents` in the seeded station bindings — a datum, not a code constant.

## Findings carried in the evidence

- **12.12 station divergence (pre-existing, factual)**: the registry assigns operation 12.12 to station 5; the G6 tree (Station 4, Steps 09–12) has served it since its build. Gate G worked around it with an OPERATION-scope binding in G6's setup, registry untouched. Reconciling it means either a registry correction (workflow-version change under §18) or a permanent note — an owner decision for Gate H's readiness assessment, not silently fixed here.
- **Envelope status**: the frozen envelope schema's status enum is `[CANDIDATE, ACCEPTED, REVIEW_REQUIRED, BLOCKED]` — envelopes carry CANDIDATE (the schema, not the brief, wins).

## §3 Scope note — coordinator changes inside Gate G

Three coordinator behaviors were introduced during this gate's window and are recorded in CHANGED_ASSERTIONS (#10, #11, #11b): `register_artifact` now persists content bytes through the storage layer; `event('human_approved')` closes the parked attempt as ACCEPTED; and the same event path promotes dependents. They were necessary for the rewired flows to close (units parked at AWAITING_HUMAN by the evaluation service needed the approval event to finish their attempts; direct artifact registrations needed durable bytes). The Gate G lock did not enumerate coordinator changes; the builder disclosed them in the assertions ledger, the verifier confirmed them in code with their Gate G comments, and every pre-existing suite — including the coordinator's own 58 — passes unchanged. They are additive (no existing behavior removed), but they are reported here as what they are: in-window coordinator work beyond the lock's letter, for the owner's acceptance to cover explicitly.

## Next gate (Gate H — needs its own lock)

End-to-end verification per the master prompt's T1–T12: coordinator authority, contract preservation, real-provider execution (**remains BLOCKED without credentials and a spend cap — T3 will be reported BLOCKED, not simulated**), financial integrity, validation independence, async recovery, configuration control, security, full-workflow, representative production, coverage, and regression evidence — closing with the production-readiness assessment and the final coverage matrix distinguishing individually verified paths from shared-handler inference.
