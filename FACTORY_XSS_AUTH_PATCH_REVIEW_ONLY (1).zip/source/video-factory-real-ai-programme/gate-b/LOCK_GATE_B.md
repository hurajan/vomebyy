# LOCK — GATE B: Coordinator compatibility & security design

- **Gate A:** COMPLETE + INDEPENDENTLY VERIFIED (defects NONE); **ACCEPTED by Raj 2026-10-28.**
- **Gate B lock CONFIRMED by Raj 2026-10-28** ("Accept Gate A and confirm the Gate B lock as planned").
- **Scope (as planned in GATE_A_REPORT §5):** design only — coordinator compatibility design for the GA-04 async conflicts, additive migration drafts (006+), provider-configuration data design, financial-evidence design, role-separated API security design, scheduler estimate redesign, and fix proposals (not applications) for F-G9-01 and F-G9-02 with compatibility impact.
- **Hard limit:** no product code, schema, workflow, or behavior changes in Gate B. All Gate B files live in this programme tree. Migration drafts may be *tested* on throwaway scratch databases only.
- **Still open (not decided by this lock):** OD-A1 (Git repository), OD-A3 (provider credentials/path), OD-A4 (storage backend). Gate B designs around all three without foreclosing them.
