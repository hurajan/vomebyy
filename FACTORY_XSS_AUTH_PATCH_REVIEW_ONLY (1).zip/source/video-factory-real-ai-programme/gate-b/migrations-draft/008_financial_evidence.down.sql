-- Rollback for DRAFT 008.
DROP TABLE IF EXISTS financial_evidence;
