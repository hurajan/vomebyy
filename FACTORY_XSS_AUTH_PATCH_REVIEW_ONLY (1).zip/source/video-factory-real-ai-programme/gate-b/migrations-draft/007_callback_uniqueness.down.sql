-- Rollback for DRAFT 007.
DROP INDEX IF EXISTS callback_deliveries_one_processed;
