-- DRAFT 009 (Gate B design; NOT applied to any product setup chain)
-- Provider configuration: versioned binding rows at five scopes with
-- whole-row resolution (ACTION > CAPABILITY > OPERATION > STATION >
-- FACTORY), plus the per-attempt snapshot columns the resolved binding is
-- pinned into at claim time (INV-006). Additive only: one new table, one
-- partial unique index, three nullable columns on action_attempts.
--
-- credential_ref is a REFERENCE NAME ONLY. Secret values never enter this
-- table, workflow JSON, artifacts, or audit payloads (design B4.4).
-- Compatibility: resolution is not consulted by any current code; the
-- implementation gate seeds one FACTORY-scope mock binding so the accepted
-- suites reproduce. Existing attempts keep NULL snapshot columns.
-- Rollback: 009_provider_configuration.down.sql.

CREATE TABLE IF NOT EXISTS provider_configs (
    config_id       UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    scope           TEXT NOT NULL CHECK (scope IN
        ('FACTORY','STATION','OPERATION','CAPABILITY','ACTION')),
    station         INT,
    operation_id    TEXT,
    capability_slot TEXT,
    action_key      TEXT,
    environment     TEXT NOT NULL DEFAULT 'production'
        CHECK (environment IN ('test','production')),
    provider        TEXT NOT NULL,
    model           TEXT,
    modality        TEXT,
    params          JSONB NOT NULL DEFAULT '{}'::jsonb,
    est_cost_cents  BIGINT,
    max_cost_cents  BIGINT,
    timeout_s       INT,
    retry_policy    JSONB NOT NULL DEFAULT '{}'::jsonb,
    concurrency_limit INT,
    credential_ref  TEXT,
    human_approval_required BOOLEAN NOT NULL DEFAULT false,
    version         INT NOT NULL DEFAULT 1,
    active          BOOLEAN NOT NULL DEFAULT true,
    created_by      TEXT,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    superseded_at   TIMESTAMPTZ
);

-- At most one ACTIVE binding per scope key.
CREATE UNIQUE INDEX IF NOT EXISTS provider_configs_one_active
    ON provider_configs (scope,
        COALESCE(station, -1),
        COALESCE(operation_id, ''),
        COALESCE(capability_slot, ''),
        COALESCE(action_key, ''),
        environment)
    WHERE active;

ALTER TABLE action_attempts
    ADD COLUMN IF NOT EXISTS config_id UUID REFERENCES provider_configs(config_id),
    ADD COLUMN IF NOT EXISTS resolved_config JSONB,
    ADD COLUMN IF NOT EXISTS resolved_config_hash TEXT;
