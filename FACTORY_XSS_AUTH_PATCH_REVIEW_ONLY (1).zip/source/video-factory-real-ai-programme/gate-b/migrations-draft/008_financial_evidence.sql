-- DRAFT 008 (Gate B design; NOT applied to any product setup chain)
-- Financial evidence: every monetary fact about an attempt gets its own
-- row with provenance and a charge class, so a worker-asserted integer is
-- never again the whole record (GA-07, INV-005). Additive only: one new
-- table + indexes. budget_transactions stays the ledger of record; this
-- table is the evidence the ledger entries cite.
--
-- Compatibility: nothing existing reads or writes this table until the
-- implementation gate; settlement behavior is unchanged by this draft.
-- Rollback: 008_financial_evidence.down.sql (drops the table).

CREATE TABLE IF NOT EXISTS financial_evidence (
    evidence_id        UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    production_id      UUID NOT NULL REFERENCES productions(production_id),
    unit_id            UUID NOT NULL REFERENCES execution_units(unit_id),
    attempt_id         UUID REFERENCES action_attempts(attempt_id),
    provider_job_id    UUID REFERENCES provider_jobs(job_id),
    provider           TEXT,
    provider_request_id TEXT,
    charge_class       TEXT NOT NULL CHECK (charge_class IN
        ('ESTIMATED','CALCULATED','PROVIDER_REPORTED','FINALIZED')),
    currency           TEXT NOT NULL DEFAULT 'USD',
    amount_cents       BIGINT NOT NULL,
    usage              JSONB NOT NULL DEFAULT '{}'::jsonb,
    pricing_version    TEXT,
    requires_reconciliation BOOLEAN NOT NULL DEFAULT false,
    created_at         TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS financial_evidence_attempt_idx
    ON financial_evidence (attempt_id);
CREATE INDEX IF NOT EXISTS financial_evidence_request_idx
    ON financial_evidence (provider, provider_request_id)
    WHERE provider_request_id IS NOT NULL;
