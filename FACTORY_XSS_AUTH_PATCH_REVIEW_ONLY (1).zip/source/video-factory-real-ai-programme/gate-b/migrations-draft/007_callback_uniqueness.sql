-- DRAFT 007 (Gate B design; NOT applied to any product setup chain)
-- Callback exactly-once at the schema level: at most one PROCESSED delivery
-- per idempotency key. Today exactly-once rests on the job-row lock plus a
-- processed-count check inside one transaction (sound single-instance);
-- this partial unique index makes it a schema guarantee (INV-004).
--
-- Pre-apply verification (must return 0 rows before applying):
--   SELECT idempotency_key, count(*) FROM callback_deliveries
--   WHERE processed GROUP BY 1 HAVING count(*) > 1;
-- Compatibility: duplicate (unprocessed) delivery rows remain allowed and
-- expected; only a second PROCESSED row is rejected.
-- Rollback: 007_callback_uniqueness.down.sql (drops the index).

CREATE UNIQUE INDEX IF NOT EXISTS callback_deliveries_one_processed
    ON callback_deliveries (idempotency_key) WHERE processed;
