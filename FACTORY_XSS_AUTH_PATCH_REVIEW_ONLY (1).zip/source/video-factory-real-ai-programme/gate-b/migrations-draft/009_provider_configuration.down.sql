-- Rollback for DRAFT 009.
ALTER TABLE action_attempts
    DROP COLUMN IF EXISTS resolved_config_hash,
    DROP COLUMN IF EXISTS resolved_config,
    DROP COLUMN IF EXISTS config_id;
DROP INDEX IF EXISTS provider_configs_one_active;
DROP TABLE IF EXISTS provider_configs;
