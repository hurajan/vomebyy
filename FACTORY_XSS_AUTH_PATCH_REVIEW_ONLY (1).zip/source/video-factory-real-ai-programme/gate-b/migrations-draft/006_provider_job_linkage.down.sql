-- Rollback for DRAFT 006.
DROP INDEX IF EXISTS outbox_unpublished_idx;
ALTER TABLE provider_jobs
    DROP COLUMN IF EXISTS resolved_config_hash,
    DROP COLUMN IF EXISTS fencing_token,
    DROP COLUMN IF EXISTS attempt_id;
