-- DRAFT 006 (Gate B design; NOT applied to any product setup chain)
-- Async provider-job linkage: bind every provider job to the coordinator
-- attempt that authorized it (INV-004/INV-005). Additive only: new nullable
-- columns + one index. Existing rows (test-only) keep NULL linkage and are
-- treated as legacy/unlinked by the reconciler design (never auto-completed).
--
-- Compatibility: no existing query changes shape; provider_jobs writers in
-- the current library do not set the new columns (NULL = legacy).
-- Rollback: 006_provider_job_linkage.down.sql (drops index + columns).

ALTER TABLE provider_jobs
    ADD COLUMN IF NOT EXISTS attempt_id UUID REFERENCES action_attempts(attempt_id),
    ADD COLUMN IF NOT EXISTS fencing_token BIGINT,
    ADD COLUMN IF NOT EXISTS resolved_config_hash TEXT;

-- Dispatcher scan support (B1.5): unpublished outbox rows in creation order.
CREATE INDEX IF NOT EXISTS outbox_unpublished_idx
    ON outbox_events (created_at) WHERE published_at IS NULL;

-- NOTE (deliberately excluded from this draft): widening the provider_jobs
-- status CHECK to add 'STALE'/'CANCELLED' is a constraint replacement, not
-- an additive change. It is drafted separately in the implementation gate
-- with its own compatibility note, so this draft stays purely additive.
