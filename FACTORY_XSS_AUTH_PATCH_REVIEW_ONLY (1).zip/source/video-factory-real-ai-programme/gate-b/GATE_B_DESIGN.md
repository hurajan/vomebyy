# GATE B DESIGN — Coordinator compatibility, async execution, configuration, finance, security

**Status: DESIGN — prepared under LOCK_GATE_B (design only; no product code, schema, or behavior changed).** Resolves the Gate A findings GA-03, GA-04, GA-07, GA-09 (design side), GA-10, GA-13 (config/approval side) and carries fix proposals for F-G9-01 / F-G9-02 (separate file). Migration drafts: `migrations-draft/006–009` (additive; apply/rollback evidence in `evidence/`).

## B1. Async provider execution — corrected design (resolves GA-04)

Principle: the async path must converge on the **same coordinator completion machinery** as the synchronous path. No code path may register a CURRENT artifact, settle money, or change unit state except through claim → completion → validation. The current `handle_callback` / `reconcile_once` implementations are therefore **replaced, not wired** (they have no runtime callers; only G2 tests exercise them, and those tests are rewritten in the implementation gate).

### B1.1 Job registration (replaces `submit_provider_job` semantics)

New coordinator operation `submit_provider_job_v2(unit_id, attempt_id, fencing_token, idempotency_key)`:
1. Load unit `FOR UPDATE`; require `current_attempt` == the attempt row identified by `attempt_id` and the unit in state RUNNING. A unit still in CLAIMED must first take the existing `start` transition (CLAIMED → RUNNING) — the transition table defines `await_provider` only from RUNNING, and this design adds no new entry for submission (clarified under verifier finding GBV-01).
2. Verify `fencing_token` equals the unit's current token and the attempt's reservation is HELD. Any mismatch → typed refusal, audit event committed, **no job row created** (a provider call must never be authorized by an unverifiable request — §9 of the master prompt).
3. Read the attempt's resolved-config snapshot (B2) — provider, model, caps, credential reference come from the snapshot, never from the caller's payload.
4. Insert `provider_jobs` (006 columns: `attempt_id`, `fencing_token`, `resolved_config_hash`, `provider`, `idempotency_key` UNIQUE already) and transition the unit `await_provider`. Duplicate idempotency key returns the existing job (exactly-once submission).

The worker service — not n8n, not the dashboard — calls this **after** claim and **before** any provider call, then calls the provider using the credential its own secrets reference resolves to. n8n keeps no connection open: the executor's job ends at submission; continuation is by callback or reconciler poll (Gate F).

### B1.2 Completion of an async job (replaces `handle_callback` / reconciler completion)

One internal coordinator routine, `_complete_provider_job(job, result_bytes_or_ref, usage_evidence)`, used by both the callback endpoint and the reconciler:
1. Lock the job row and the unit row. If the job is already COMPLETED/FAILED/STALE → record the delivery (007 uniqueness makes the duplicate a no-op) and return the recorded outcome.
2. **Fencing gate:** if `job.fencing_token` != unit's current token, or the job's attempt is no longer `current_attempt`, or the attempt's reservation is no longer HELD → mark the job FAILED with `failure_code='STALE_FENCING'`, write the provider-reported charge (if any) as PROVIDER_REPORTED financial evidence flagged `requires_reconciliation`, register **nothing**, settle **nothing**, transition **nothing**. A late result can never overwrite a current one (INV-004). (Job outcomes never widen the `provider_jobs.status` CHECK vocabulary: every terminal non-success outcome is FAILED + a `failure_code` — STALE_FENCING, STALE_INPUT, PROVIDER_ERROR, CANCELLED — per GBV-01.)
3. Verify every planned input artifact is still CURRENT (same check as claim). Stale input → job FAILED with `failure_code='STALE_INPUT'`; the unit leaves AWAITING_PROVIDER via the (AWAITING_PROVIDER, transient_error) transition that B1.3 adds deliberately → RETRY_WAIT — never a silent promotion.
4. Register the artifact through `_register_artifact_txn` (identical to the sync path), settle the attempt's reservation from **financial evidence** (B3), set the attempt VALIDATING with the output artifact + actual cost, delete the lease, transition `submit_candidate`. The unit then sits in VALIDATING exactly like a synchronous completion — **independent validation (Gate E) is the only road to ACCEPTED.**
5. Job → COMPLETED with `result_artifact_id`; delivery row inserted `processed=true` in the same transaction.

### B1.3 Failure, timeout, unknown

Provider-reported failure → job FAILED + unit `transient_error` (from AWAITING_PROVIDER via the existing transition set — note: the transition table has no (AWAITING_PROVIDER, transient_error); the design adds it in the implementation gate as a table entry, flagged here as a deliberate, reviewed addition) → RETRY_WAIT; the failed attempt's reservation is released by the existing `retry_unit` path only when an operator/scheduler retries (no silent money movement). Submission-outcome-unknown → job UNKNOWN + unit `provider_unknown` (existing transitions), owned by the reconciler. Charges reported for failed/unknown jobs are recorded as evidence with class PROVIDER_REPORTED and settled **only** by an explicit coordinator `settle_provider_charge` action that charges against the production with a CHARGE/ADJUSTMENT ledger entry referencing the evidence — never by mutating the released reservation. Duplicate reports of the same charge are deduplicated on (provider, provider_request_id).

### B1.4 Reconciler v2

`reconcile_once` keeps its poll loop shape but: polls only jobs with non-null `attempt_id` (legacy unlinked rows are reported, never auto-completed); completion goes through B1.2; failure/not-found transitions as today; poll backoff uses `poll_count` + `last_polled_at` with the Gate F service supplying cadence. The mock provider remains for tests behind the same interface.

### B1.5 Outbox dispatcher (contract for Gate F)

Claim already writes `outbox_events` (`dispatch:{unit}:{attempt}` idempotency). The dispatcher (Gate F service) reads unpublished rows in creation order, hands the unit to the scheduler/worker queue, and sets `published_at` **in the same transaction** as the handoff record; consumers dedupe on the idempotency key (at-least-once delivery, exactly-once effect via claim fencing). No new table is needed; 006 adds an index on `published_at` for the dispatcher scan.

### B1.6 Scheduler estimate redesign (resolves the 0¢ defect)

`scheduler_claim` must never invent or zero an estimate. Design: `scheduler_claim(estimate_for)` where `estimate_for(unit) -> int cents` is supplied by the caller from the resolved config (B2); the coordinator library ships a resolver-backed implementation in the scheduler service (Gate F). A zero estimate is legitimate **only** when the resolved binding's provider is `deterministic-local` with an explicit `est_cost_cents = 0` in its config row — auditable in the snapshot, not a code default. If no config resolves for a unit's operation, the scheduler **skips and reports** the unit (fail-closed) instead of claiming it. The existing library signature stays for tests; the zero-estimate docstring behavior is removed in the implementation gate.

## B2. Provider configuration (resolves GA-09 design side; schema draft 009)

### B2.1 Model

One table, `provider_configs`, holds versioned binding rows at five scopes: FACTORY, STATION (station no.), OPERATION (operation_id), CAPABILITY (capability_slot), ACTION (operation_id + action_key). Each row: provider, model, params JSONB (temperature, token limits, quality tier…), modality, est_cost_cents, max_cost_cents, timeout_s, retry_policy JSONB, concurrency_limit, credential_ref (**a reference name only — never a secret value**), human_approval_required flag, version, active flag, created_by/at, superseded_at. A partial unique index guarantees at most one ACTIVE row per scope key. Every change inserts a new version and supersedes the old — history is never edited.

### B2.2 Resolution

Order (master prompt §7): ACTION → CAPABILITY → OPERATION → STATION → FACTORY. **Whole-row selection**: the most specific scope with an active row supplies the entire binding (no field-level merging — merging makes the resolved hash depend on five rows' histories and invites silent drift; if field-level inheritance is ever wanted it is a new design, not a tweak). Resolution happens **inside claim's transaction** in the implementation design: the coordinator resolves the binding for (production's workflow_version, operation, capability_slot from the registry, action = the unit's exit action), writes the snapshot — full resolved row + `resolved_config_hash = sha256(canonical JSON)` — onto the `action_attempts` row (009 columns), and uses `est_cost_cents` as the claim estimate (the executor's hardcoded 100 disappears; the API claim body keeps `estimated_cents` only as a *ceiling assertion* the coordinator checks against the config estimate — a caller quoting less than the config estimate is refused).

### B2.3 Fail-closed + compatibility

- No active binding resolves → claim refuses with a typed `ConfigurationMissing` error (409), zero attempts, audit event — the same evidence pattern as gate refusals.
- Compatibility with the accepted mock system: the implementation gate seeds one FACTORY-scope binding (`provider='mock'`, `est_cost_cents=100`) so all existing suites reproduce unchanged; selecting the mock anywhere outside a test environment is prevented by the API role rules (B4) plus an environment flag on the binding row (`environment='test'|'production'`; production environments refuse test bindings at resolution).
- Changing a binding never affects in-flight attempts: they carry their snapshot (INV-006, §7's pinning rule).

## B3. Financial evidence (resolves GA-07; schema draft 008)

New table `financial_evidence`: one row per monetary fact — (production, unit, attempt, provider_job) references, provider, provider_request_id, charge_class ∈ {ESTIMATED, CALCULATED, PROVIDER_REPORTED, FINALIZED}, currency, amount_cents, usage JSONB (input/output/cached tokens, images, media seconds, compute units), pricing_version, created_at. Rules:
- Claim writes the ESTIMATED row (from the config snapshot) in the claim transaction.
- Completion computes CALCULATED from usage × pricing_version where a price book exists; where the provider reports a charge, PROVIDER_REPORTED is recorded verbatim — **the worker's bare integer is never again accepted as the actual**; the sync `/complete` contract gains a `usage` object and `provider_request_id` in the implementation gate (backward-compatible addition; mock workers report usage `{mock: true}` and class stays CALCULATED-from-config until a real price book exists — labeled honestly in evidence).
- Settlement (the existing SETTLED + CHARGE) references the FINALIZED evidence row; finalization = coordinator action that picks the authoritative class by rule: provider-reported wins when present and reconciled within tolerance of calculated, else calculated, else estimated — the rule and its tolerance live in config, and every override is an ADJUSTMENT ledger entry with an audit payload.
- Soft ceiling: `budget_position` gains a soft-threshold check in the scheduler/dispatcher layer — crossing it writes an audit event + outbox notification (no new authority; enforcement remains the hard ceiling).
- Failed-call charges: B1.3's explicit settle action; nothing is silently absorbed.

## B4. Security — role-separated API auth (resolves GA-10)

### B4.1 Roles

Five roles, five independent credentials (env-provided in dev; secrets-manager references in production — the API reads *references* from config, values from the environment/secret store, never from the DB or workflow JSON):

| Role | Holder | May call |
|---|---|---|
| OPERATOR | dashboard / human tooling | reads; productions/runs/units create; gates create/decide; invalidate (see B4.3); retry; config read |
| WORKER | a station's worker service (one identity per station) | claim (own station's units), heartbeat, complete — **bound to the claim's worker_id + fencing token (B4.2)** |
| SCHEDULER | scheduler/dispatcher service | claim (on behalf, with config estimates), retry, events (transient_error/cancel), reads |
| VALIDATOR | evaluation service | validate only; reads of units/artifacts |
| CALLBACK | a provider-facing endpoint identity per provider | provider-job callback for its own provider only, payload must carry the job idempotency key + provider request id |

Health stays unauthenticated (liveness only). The current single `X-Operator-Token` becomes OPERATOR during migration; old token accepted for OPERATOR only, and workflow JSON stops carrying any token at Gate G (n8n credential store references instead).

### B4.2 Worker binding check (gap found in Gate B)

`_complete_attempt_txn` today verifies **only the fencing token** — a completion naming a different `worker_id` than the claim's succeeds if the token matches. Design: completion (and heartbeat, which already checks both) must verify `worker_leases.worker_id == caller worker_id AND action_attempts.worker_id == caller worker_id` inside the completion transaction; mismatch → `StaleFencing`-class refusal with committed evidence (same pattern as stale-token evidence). Compatibility: the executor and dashboard already pass the claiming worker_id, so no accepted flow changes behavior; the mock-callback path is replaced by B1 anyway.

### B4.3 Master invalidation authority (gap found in Gate B)

Two defects in the current guard: (1) authority arrives as a **request-body boolean** (`master_authority`) that any token holder can assert; (2) the check compares `artifact_type == "master"`, but the factory's master artifact type is **`master_package`** — the guard never fires for the real master artifact. Design: remove the boolean; `invalidate_artifact` requires OPERATOR role at the API, and for artifact types in a new `gate_requirements`-sibling rule (artifact_type = master_package) additionally requires an APPROVED HG4 gate bound to that exact artifact **or** a second OPERATOR identity recorded as co-authorizer in the audit payload (four-eyes). The coordinator checks the rule from data, not a type-name literal. F-G9-02's proposal (separate file) follows the same "decisions are data + history" pattern.

### B4.4 Secrets & audit

Credentials are referenced by name (`credential_ref`) in config rows; values live only in the deployment's secret store. No secret, token, or provider key may appear in workflow JSON, artifacts, audit payloads, or logs — the implementation gate adds a redaction test that greps generated workflows and audit rows for configured secret values. Every config change, gate decision, invalidation, retry, and manual completion writes the acting role + identity into the existing `audit_events.actor` (the API stops hardcoding one actor string per endpoint class and records the authenticated identity).

## B5. What Gate B deliberately does NOT decide

- No provider, model, or price is named anywhere in this design (OD-A3 stands; bindings are data to be filled at deployment).
- No storage backend is chosen (OD-A4 stands; B1's completion takes bytes-or-reference so Gate D can substitute object storage without changing the coordinator contract).
- No Git repository is created (OD-A1 stands; baselines remain manifest-pinned).
- The 8 non-HG approval policies in the registry (GA-13) are **not** silently mapped to mechanisms: the design notes them as data the config layer can express (`human_approval_required` on a binding), and turning any of them into an enforced gate is an owner decision for a later gate.

## B6. Compatibility contract for the implementation gates

Every implementation gate must keep these green without editing their assertions: G1 7/7, G2 25/25 (plus new tests per change), G3 5/5, G4 2/2, G5 1/1, G6 3/3, G7 2/2, G8 1/1, G9 full run + battery 8/8 — against the FACTORY-scope mock binding seeded by migration, proving the new machinery reproduces the accepted behavior before any real provider is attached.
