# GATE B VERIFIER REPORT — Independent verification

**Verdict: VERIFIED WITH ONE MINOR DESIGN DEFECT.** All seven assigned verification areas were independently checked. Items 1–6 are CONFIRMED. Item 7 is CONFIRMED at the GA-04 coverage level, subject to the minor async-transition clarification recorded as defect GBV-01 below. No product code was modified by this verification.

## 1. Lock compliance — CONFIRMED

The Gate B lock limits Gate B to design files in the programme tree, additive migration drafts, and tests on throwaway databases only. I recomputed SHA-256 values for the requested key product sources and compared them with `gate-a/evidence/source_manifest.json`. **14 of 14 matched:**

| Product source | SHA-256 result |
|---|---|
| `video-factory-g2/coordinator/coordinator.py` | MATCH — `2ff3f910260a0e9bf99babaacebdb3aea6a73980dacca14af0b168ac6e077e4b` |
| `video-factory-g1/tools/registry_tool.py` | MATCH — `e9fc1b1c0de9e41f5ab3826b3dfc6b4984284a043d6f6409405edd8dd7402057` |
| `video-factory-g3/api/server.py` | MATCH — `ccbfeed4b16dca54430605239a920ee21ba93006f09e37f96b95d4062576cc4c` |
| `video-factory-g3/dashboard/index.html` | MATCH — `c60d90701736312679d8ab0159b82c40609b55f36a4c858ea3dc46d049662aaf` |
| `video-factory-g4/workers/mock_workers.py` | MATCH — `2bf3be41800246fb781c8cf3546c89a5f2bedace61a26ff6d7977f9b06262fb6` |
| `video-factory-g4/tools/gen_workflows.py` | MATCH — `5c7282e826d28c2dabfed39cc425bc46e1b39c541c8e9fa15f07bd944c278f0e` |
| `video-factory-g5/workers/mock_workers.py` | MATCH — `a4501b73430b751be8f70514cab3adeaa54d91feae4455416656bb6a2d786204` |
| `video-factory-g5/tools/gen_workflows.py` | MATCH — `12cb8cf5f56db64d5259c843f6557ea4ea9e35b3b5a2069ef4458ee6a5dddcad` |
| `video-factory-g6/workers/mock_workers.py` | MATCH — `76b06653987c5c0a86418c4fcfaef0ee2f44617933c6bcaa8c90da25d735daae` |
| `video-factory-g6/tools/gen_workflows.py` | MATCH — `1f7d3ba4edacfa1a207257f39bbe091853feda4d4f5e3e487512c8f77ecbc876` |
| `video-factory-g7/workers/mock_workers.py` | MATCH — `b34bb746d1b7db27c5f580e4f12d045716adb82b0dc89b754b26000bcd858699` |
| `video-factory-g7/tools/gen_workflows.py` | MATCH — `a76791a2ebb2e9f6f4f8b85bc954dec4e6f1020e83f0538385cb54627cc7dbc2` |
| `video-factory-g8/workers/mock_workers.py` | MATCH — `953ad6a910ba3b0fb70ce6cf8185e629f5d2bcb0d3fcae37539dd49c912bd299` |
| `video-factory-g8/tools/gen_workflows.py` | MATCH — `5d7e83d12fd6df91f2dbc08d0afb7e3be97ced043da074394a53b7a3080f25ea` |

This confirms the specified key sources are byte-identical to the Gate A baseline.

## 2. GB-SEC-01 — CONFIRMED

In `g2/coordinator/coordinator.py`:

- `_complete_attempt_txn` at lines 459–487 checks state and then verifies the unit's current fencing token by attempting `UPDATE execution_units ... WHERE unit_id=%s AND fencing_token=%s`.
- It then uses the caller-supplied `worker_id` only as the value passed onward for stale-failure evidence in the wrapper; inside the successful completion transaction it does **not** compare `worker_id` with `worker_leases.worker_id` or `action_attempts.worker_id`.
- It selects the current attempt's reservation by `(unit_id, current_attempt)` and updates/deletes the attempt and lease by unit/attempt identifiers, not by caller worker identity.

By contrast, `heartbeat` at lines 422–431 **does** bind all three values in one predicate: `unit_id`, `worker_id`, and `fencing_token` must match `worker_leases`. The design's asymmetry claim is therefore correct: heartbeat checks worker + token; completion checks token only.

## 3. GB-SEC-02 — CONFIRMED, all three parts

1. `Coordinator.invalidate_artifact` defines `master_authority=False` and, at line 731, applies the extra guard only when `source["artifact_type"] == "master"`.
2. Station 5's worker for operation 13.12 in `g7/workers/mock_workers.py` returns artifact type `"master_package"` at lines 57–64. Therefore the literal `"master"` comparison does not match the actual master artifact type.
3. The G3 API invalidate route at `g3/api/server.py` lines 249–252 passes `master_authority=bool(b.get("master_authority", False))`, i.e. the authority bit is taken directly from the request body.

The Gate B claim that the guard is doubly ineffective—wrong source of authority and wrong artifact-type literal—is correct.

## 4. FP-01 / F-G9-01 — CONFIRMED

In `g1/tools/registry_tool.py::build_load_sql`:

- Workflow-version and operation inserts use `seed["workflow_version"]` / `o["workflow_version"]` (lines 178–196).
- The dependency-template loop at lines 197–200 instead inserts the literal `'1.0.0'`.
- The current seed's top-level `workflow_version` is exactly `'1.0.0'`, and every operation in that seed also has version `'1.0.0'`.

Therefore substituting the literal with `sql_str(seed["workflow_version"])`, as proposed, produces the same dependency-template SQL values for the current seed. The proposal's byte-identical compatibility statement is supported for the current seed.

## 5. FP-02 / F-G9-02 — CONFIRMED

`Coordinator.create_gate` at lines 553–565:

- reads the artifact hash;
- generates a new UUID;
- unconditionally executes `INSERT INTO human_gates(...)`;
- returns the new gate ID.

There is no preceding existence lookup for `(production_id, gate_kind, artifact_id)`, no conflict handling, and no return of an existing gate. The claim is correct.

## 6. Migration drafts 006–009 — CONFIRMED

I created a fresh throwaway database with:

```text
cd ~/workspace/video-factory-g2
.venv/bin/python tools/setup_db.py gateb_verify_scratch
```

Result: `scratch DB ready: gateb_verify_scratch`.

### Apply and catalog verification

I applied 006, 007, 008, and 009 in order by piping each file through standard input to `psql` as the `postgres` owner, with `ON_ERROR_STOP=1`. Results:

- Baseline public-table count: **29**.
- After all four drafts: **31** public tables.
- `provider_jobs` gained: `attempt_id`, `fencing_token`, `resolved_config_hash`.
- `action_attempts` gained: `config_id`, `resolved_config`, `resolved_config_hash`.
- Required indexes existed:
  - `callback_deliveries_one_processed`
  - `provider_configs_one_active`
  - `outbox_unpublished_idx`

Catalog checks were performed as `postgres` using `pg_tables` / `pg_indexes` and owner-visible `information_schema` results.

### Rollback and re-apply

I applied the rollbacks in reverse order (009, 008, 007, 006):

- Public-table count returned to **29**.
- The three new Gate B indexes were absent (count 0).

I then re-applied 006–009 in forward order:

- Public-table count returned to **31**.
- All three required indexes were present again.

Finally I dropped the throwaway database and confirmed `pg_database` count for `gateb_verify_scratch` was **0**.

### Additive-only inspection

The four up drafts contain only:

- `ALTER TABLE ... ADD COLUMN IF NOT EXISTS` for new nullable columns;
- `CREATE TABLE IF NOT EXISTS` for new tables;
- `CREATE INDEX` / `CREATE UNIQUE INDEX` for new indexes.

A targeted scan of the up files found no `DROP`, `DELETE`, `UPDATE`, `INSERT`, `TRUNCATE`, `CREATE OR REPLACE`, column alteration, or column drop statements. The drafts are additive-only as claimed. Draft 007's own pre-apply duplicate check remains an operational precondition for production data, but it does not alter the additive classification.

## 7. Design coverage of GA-04 — CONFIRMED, with GBV-01 clarification

| GA-04 conflict | Gate B treatment | Result |
|---|---|---|
| `provider_jobs` has no attempt/fencing/configuration linkage | B1.1 requires the job to be created against the current attempt; draft 006 adds `attempt_id`, `fencing_token`, `resolved_config_hash`; draft 009 pins the full resolved config and its hash on the attempt | Addressed |
| Callback registers CURRENT without fencing, settlement, input-freshness, or validation | B1.2 imposes a fencing gate, current-attempt and HELD-reservation checks, input-currency verification, registration through `_register_artifact_txn`, evidence-based settlement, transition to VALIDATING, and independent validation as the only route to ACCEPTED | Addressed |
| `submit_provider_job` needs no claim/attempt/budget authorization | B1.1 requires CLAIMED/RUNNING state, exact current attempt, matching fencing token, and a HELD reservation before a job row can be created; provider/model/credential reference come from the attempt snapshot, not caller payload | Addressed, subject to GBV-01 transition detail |
| Reconciler trusts provider output/cost and registers artifacts directly | B1.4 restricts automatic completion to linked jobs and routes completion through B1.2; B3 replaces a bare reported integer with classified financial evidence and a finalization rule | Addressed |
| Callback exactly-once is not a schema guarantee | Draft 007 adds the partial unique index for one processed delivery per idempotency key; B1.2 also records duplicate deliveries as no-ops | Addressed |
| `scheduler_claim` uses a zero-cent estimate | B1.6 requires caller/resolver-supplied estimates from resolved config, permits audited zero only for an explicitly configured deterministic-local binding, and skips/reports unresolvable units | Addressed |

I found **no GA-04 bullet wholly unaddressed**.

### Provider/model and credential check

Gate B's design and draft schemas name no specific commercial provider or model as a binding and contain no credential value. They use generic provider/model fields and a `credential_ref` reference name. The Gate B report's later-gate phrase “OpenRouter-compatible” describes an adapter category, not a selected binding, default, model, or credential. No credential was created by the design or drafts.

## Defect found

### GBV-01 — MINOR: async state-transition specification is incomplete in two places

This does not negate the GA-04 coverage above, but the implementation gate should correct or explicitly rule on it before coding B1:

1. **CLAIMED → AWAITING_PROVIDER is not specified.** B1.1 allows `submit_provider_job_v2` from either CLAIMED or RUNNING and then says the unit transitions by `await_provider`. The current transition table defines only `(RUNNING, "await_provider") -> AWAITING_PROVIDER`; it does not define `(CLAIMED, "await_provider")`. The design does not say whether the new operation must first apply the existing `start` transition (CLAIMED → RUNNING) or whether a new CLAIMED → AWAITING_PROVIDER table entry is intended. This contrasts with B1.3, where a different missing transition is expressly flagged as a deliberate addition.
2. **Stale-input routing invokes an undefined event/state pair.** B1.2 says a stale-input job is `STALE_INPUT` and the unit remains AWAITING_PROVIDER for the reaper/reconciler to route it to RETRY_WAIT via `reconciled_failed` semantics. The current table defines `reconciled_failed` only from UNKNOWN, not from AWAITING_PROVIDER. The design also does not reconcile the `STALE_INPUT` label with the existing `provider_jobs.status` CHECK vocabulary or draft 006's separate note deferring status widening for `STALE`/`CANCELLED`.

**Required clarification before implementation:** state the exact reviewed transition additions or intermediate transitions for (a) provider submission from CLAIMED, (b) stale-input exit from AWAITING_PROVIDER, and (c) whether `STALE_INPUT` is a persisted `provider_jobs.status` requiring a CHECK widening or only an outcome classification stored elsewhere.

## Non-defect observations

- GB-SEC-01 and GB-SEC-02 are builder-disclosed design inputs, independently confirmed above; they are current-product security findings carried into the Gate B design, not defects introduced by Gate B.
- Draft 007 should retain its documented pre-apply duplicate check when eventually used on a database with historical callback deliveries. The throwaway database had no such conflict.

## Final verifier statement

Gate B satisfies its design-only lock for the checked scope: no checked product source changed, the four migration drafts behave additively and reversibly on a throwaway database, both fix proposals rest on accurate code claims, both newly reported security claims are real, and every GA-04 conflict has a corresponding design treatment. GBV-01 should be closed as a design clarification before B1 is implemented.
