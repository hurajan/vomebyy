# FIX PROPOSALS — F-G9-01 and F-G9-02 (Gate B; proposals only, NOT applied)

Per the master prompt §20: no change that alters approved semantics is applied without a presented proposal + compatibility impact. Both fixes are proposed for a future implementation lock.

## FP-01 — F-G9-01: G1 loader hardcodes the workflow version for dependency templates

**Defect (verified in code):** `g1/tools/registry_tool.py`, `build_load_sql`: operation INSERTs use each operation's own `workflow_version`, but the dependency-template INSERT is built with the literal `'1.0.0'`. The seed's `dependency_templates` entries carry no version field (`{from_operation, to_operation, kind}`), and the top-level seed object does carry `workflow_version`. Consequence (proven in the G9 §18 rehearsal): loading a 1.1.0 variant seed writes its 191 templates under 1.0.0; the 1.1.0 registry record is silently incomplete. Runtime impact today: none — claims resolve dependencies from instance-level `unit_dependencies`, not templates. Risk is to any future version load and to registry truthfulness.

**Proposed fix (one line + one parameter):**
1. In `build_load_sql`, replace the literal with the seed's own version: `sql_str(seed["workflow_version"])`.
2. Let `load()` accept a seed directory (default: the existing `workflow-1.0.0` dir) instead of the module-level `SEED_DIR` constant the G9 rehearsal had to monkeypatch — the version then always comes from the seed file actually being loaded.

**Compatibility impact:** for the current 1.0.0 seed the generated SQL is **byte-identical** (the literal equals the seed's version), so: definition hash unchanged (ea4503f5…), existing databases unchanged, G1 suite expectations unchanged. The only behavior change is for non-1.0.0 seeds — currently broken by definition. No migration, no schema change, no rollback beyond reverting the tool edit. Verification at implementation: re-run the G9 rehearsal procedure — load a variant seed into a throwaway DB and assert 191 templates under the variant version + 191 under 1.0.0 + the pinned 1.0.0 production untouched; G1 suite green.

## FP-02 — F-G9-02: gate creation is not deduplicated

**Defect (verified in code):** `Coordinator.create_gate` is an unconditional INSERT. Re-dispatching a station exit after its gate was decided creates a second gate for the same (production, gate_kind, artifact_id) — observed live in G9 as an APPROVED HG5 shadowed by a dangling PENDING duplicate. The duplicate is inert (`require_gate` and claim enforcement look for an APPROVED gate bound to the exact hash) but it pollutes the operator's pending queue and the audit picture. The station workflows partially compensate: their create-gate error branch treats a conflict as "already pending" — but no conflict ever occurs, because nothing enforces uniqueness, and a *decided* gate is not detected at all.

**Proposed fix (coordinator-level idempotent create; no schema change):**
1. `create_gate` first selects an existing gate for (production_id, gate_kind, artifact_id) — any verdict. If one exists, return its gate_id without inserting (the API response gains `existing: true`; the 201/200 distinction is documented in the contract update).
2. Decision history is untouched: a REJECTED gate stays the record for that artifact; a revised artifact is a *new* artifact_id and gets its own gate — which is exactly the HG2 revision behavior already verified in G5. There is no legitimate flow that needs two gates on one artifact.
3. The station workflows' "already pending" branches become the normal path's no-op twin (harmless); Gate G regeneration may simplify them but is not required for correctness.

**Compatibility impact:** behavior changes only where duplicates were previously created: station suites G5/G7/G8 assert gate counts in places — at implementation, any assertion that counted a duplicate as expected must be reviewed (the G9 full-run evidence counted the duplicate as a *finding*, not a feature). Dashboard manual double-submits become safe. `human_gates` rows already written are untouched. Optional belt-and-braces (NOT proposed for the same change): a partial unique index `ON human_gates(production_id, gate_kind, artifact_id) WHERE verdict='PENDING'` — deferred because the coordinator fix makes it redundant and an index alone would convert the duplicate into an error path the workflows misread.

**Verification at implementation:** G9-style probe — dispatch a gated exit, decide the gate, redispatch, assert exactly one gate row for the artifact and the unit proceeds; G5/G7/G8 suites + G9 battery green; a duplicate-create API call returns the original gate_id with `existing: true`.
