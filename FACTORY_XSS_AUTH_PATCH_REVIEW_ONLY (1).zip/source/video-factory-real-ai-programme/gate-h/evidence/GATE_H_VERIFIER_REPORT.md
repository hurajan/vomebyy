# GATE H — INDEPENDENT VERIFIER REPORT

**Overall verdict: VERIFIED — the executor's results stand**, including T9 FAIL with defect D-H1 (CRITICAL) and T3 BLOCKED by design. One new MINOR defect found (V-H1) and one MINOR process observation recorded (§7). Verification was performed independently: the D-H1 deadlock was reproduced from scratch on the verifier's own g5 setup, and all other items were checked against the evidence files and logs on disk, not the executor's summaries.

Executor's headline results, as verified: T1/T2/T4/T5/T6/T7/T8/T10/T11/T12 PASS (T12 via the supplement, §4), T3 BLOCKED, T9 FAIL (D-H1).

## 1. D-H1 independent reproduction — CONFIRMED (CRITICAL defect is real, not a harness artifact)

Verifier's own run (fresh `g5 setup_env.py`; script `/tmp/verify_dh1.py`, output `/tmp/dh1_out.json`):

**Phase 1 (deadlock path).** Planned production `4b5c112a…` with a single READY 05.12 unit `577bdb24…` (canon input registered via the API). Called the Gate F `SchedulerService.run_once` directly:
- Unit → CLAIMED; lease worker_id = **`sched-text`**, fencing_token 1; attempt 1 worker_id = `sched-text`, status RUNNING.
- Called the Gate F `DispatcherService.run_once` against `http://127.0.0.1:5678/webhook/dispatch-g5`: report `dispatched: 1` (handoff delivered).
- The resulting n8n unit-executor execution (**id 5105**, attributed by unit_id in its data) contains the **"Claim refused" branch**, a **409**, and the text **"claim requires READY"**.
- After the execution: unit still **CLAIMED**; attempts still exactly one (the scheduler's); **zero** `story_architecture` artifacts — no worker-service execution ever occurred.

**Phase 2 (control).** Fresh production `93f49d63…` / unit `95f46bc0…`; the identical dispatch payload POSTed to the same webhook **with no scheduler claim**: webhook 200, the executor claimed and executed the unit (attempt by the n8n executor, `story_architecture` artifact registered), unit → AWAITING_HUMAN (the designed outcome while the semantic layer is unarmed), and after a verifier-posted `human_approved` event → **ACCEPTED**.

Conclusion: the deadlock is specifically the scheduler-claim/executor-claim collision. The scheduler claims the unit for itself (worker `sched-<lane>`); the only execution path (the Gate G executor) must claim for itself and is refused with 409 because the unit is no longer READY; the handoff therefore never leads to execution, and the lease-expiry/reaper/retry loop returns the unit to the scheduler, not to a worker — exactly as D-H1 states, and consistent with the executor's two T9 runs (t9.json phase 1/2 timelines, leases held by `sched-text`, `t9_n8n_executions.json` executions 4670/4673 both taking the claim-refused branch on 409).

## 2. T4 spot-check — CONFIRMED

t4.json records the invariant assertion **after each sub-battery** (6 invariant lines: after duplicate completion, after duplicate callback, after the claim race, for the ceiling production, after stale-charge settlement, and at end of T4), each with `settled == ΣFINALIZED`, `held == ΣHELD`, `available >= 0` and concrete figures (e.g. settled=3867 fin=3867 held=5100/5100 at close). The claim race produced **exactly one HELD reservation** (`held=1`) with the loser receiving a typed `UnauthorizedTransition` refusal.

## 3. T6 part B facts — CONFIRMED (evidenced, not merely asserted)

t6.json carries the sequence with concrete identifiers: mid-flight states at kill time (1 ACCEPTED, 1 AWAITING_HUMAN, 2 PENDING, unit IDs recorded), an explicit "stack is down after the kill (API unreachable)" check, and the final state — **4 units ACCEPTED, 4 charges, 360¢ settled, HG2 APPROVED, zero duplicate CURRENT artifacts** (per-type CURRENT counts all 1). Corroborated by the runner logs on disk: `runner_t06.log` (pre-kill, 21 structured cycle lines) and `runner_t06_restarted.log` (650 lines of scheduler/dispatcher/reaper/retry/reconciler cycles after restart, including recorded claims and dispatches). Part A (UNKNOWN → reconciler → VALIDATING, settled exactly once at 450¢) is likewise itemised in t6.json.

## 4. T12 regression — CONFIRMED (169/169 via the supplement; parser-artifact explanation matches the files)

The raw t12.json records FAIL with total 167 because g5 and g8 were parsed as `ran: 0`. The suite logs on disk show why: `t12_suite_g5.log` and `t12_suite_g8.log` end with **"Ran 1 test … OK"** (singular "test", which the harness parser's pattern missed). `t12-supplement.json` records the rerun of exactly those two suites at **1/1 each, rc=0**. 167 + 2 = **169/169**, all 13 suites green. Note for the record: the correction rests on the supplement file; t12.json itself still carries the FAIL verdict.

## 5. T2 / T7 / T8 spot evidence — CONFIRMED

- **T2**: variant load evidenced — 192 definitions + 191 templates present under workflow 1.1.0 (variant hash `1794f039…`), 1.0.0 rows untouched (192), the production remains pinned to 1.0.0 with `definition_hash` still `ea4503f5…`, and a unit planned on the pinned production binds 1.0.0 definitions. TRANSITIONS enumerated at exactly 30, including both Gate F/C additions.
- **T7**: two distinct resolved-config hashes across the binding change (attempt 1 `b409dbcb…`, attempt 2 `9e42c661…`); attempt 1's snapshot and its ESTIMATED evidence (111¢) unchanged after v2 superseded v1; audit trail contains **both** `provider_config_changed` events (v1 and v2); production-environment resolution refuses the test bindings fail-closed with a committed `configuration_missing` audit.
- **T8**: by path inspection of `secret_hits`, every hit is confined to (a) vendored n8n runtime cache assets under `video-factory-g4/n8n-data/.cache/…` (UI example strings and a credentials-type template, not credentials) and (b) self-referential copies of those same excerpts inside `t8.json` itself, classified "evidence/docs" in the file. **No hit is in product code.** Negative role matrix (8× 403) and 401s are itemised with response bodies.

## 6. Coverage matrix sanity — CONFIRMED

Counted from `COVERAGE_MATRIX.md` directly: **192 unique operation rows**; the YES set counts **20** and matches `executed_union.json` exactly (set-equal, including 03.02 and 11.06). The §5–§17 table carries all 13 sections, each with a status label from the programme vocabulary; §14 is honestly downgraded to IMPLEMENTED_UNVERIFIED citing D-H1, and no label upgrades beyond its cited evidence (e.g. §10 S3 remains IMPLEMENTED_UNVERIFIED, §12 golden framework NOT ARMED, §16 real-browser rendering NOT TESTED).

## 7. Scope (no product changes by the executor) — CONFIRMED on content; MINOR process observation on mtimes

The Gate H harness writes only inside the gate-h tree (verified by inspection: its file writes target `evidence/results`, `evidence/logs`, and the T2 variant-seed copy). Content integrity was checked against the Gate A source manifest (126 pinned SHA-256s): **67 files match**, and the 59 mismatches are precisely the files Gates C–G were locked to change (coordinator, API, dashboard, station workflows/generators, g9 harness). Critically, every file no gate was authorised to change — the registry seed, the 32 step contracts, the migrations — **matches its pinned hash exactly**, and all 13 suites pass on the current content (§4).

Observation (MINOR, process): whole-package **mtime clusters** fall inside the Gate H execution window (e.g. gate-f `runtime_services/*.py` all at 2026-10-29T01:26:31Z; g1 contracts at 01:41:59Z; `g3/api/server.py` 01:54:06Z; `g3/tests/test_api.py` 01:54:36Z; `gate-c/worker_service/envelope.py` 02:12:49Z). The identical-second, whole-package pattern is consistent with content-preserving rewrites (tree setups regenerating workflows during the T12 battery, environment file-sync on this unstable VM) rather than edits, and no content change is detectable anywhere a baseline or behavioural suite exists — but the clusters cannot be fully explained from the harness code alone, and for files legitimately changed by Gates C–G there is no Gate-G-era hash baseline to compare against. Recorded so the acceptance decision is made with it visible; it does not change any T-verdict.

## New defect

**V-H1 (MINOR) — executor worker identity degrades to `n8n-station-undefined` on the service-dispatch path.** The unit-executor's claim body is `worker_id: 'n8n-station-' + trigger.station` (g5 `workflows/unit-executor.json`, Claim unit node), but the Gate F dispatcher's payload (`dispatcher_service.py`) carries only `{idempotency_key, unit_id, production_id, operation_id, attempt_no}` — no `station` field. Evidence: the verifier's Phase-2 control attempt was recorded with worker_id **`n8n-station-undefined`** (execution itself completed correctly). This is the same field-source family as the executor bug Gate C fixed in-lock for the redispatch path; on the dispatcher path the field simply does not exist. Impact: execution is unaffected, but all dispatcher-driven claims share one literal worker identity, weakening the worker-binding audit granularity that GB-SEC-01 was fixed to provide. Remediation is a payload/generator change and requires its own lock; none applied here.

## Defect register (Gate H, as verified)

| ID | Severity | Status |
|---|---|---|
| D-H1 — scheduler-claim/executor-claim composition deadlock; unattended (services-only) execution cannot proceed | CRITICAL | Independently reproduced (§1); stands |
| V-H1 — executor worker identity `n8n-station-undefined` on the dispatcher path | MINOR | New, verifier-found (above) |
| Scope mtime clusters (§7) | MINOR (process observation) | No content change detectable |

**Overall: VERIFIED.** The executor's per-T results stand as reported: T9 FAIL / D-H1 CRITICAL, T3 BLOCKED by design, all other items PASS, corrected regression total 169/169. Production-readiness blockers remain as the lock and matrix state them (D-H1 remediation, OD-A3 credentials/provider, G0.6/cloud deployment, OD-A4 storage endpoint, EXPERT golden set, 12.12 reconciliation, OD-A1) — none were touched in this gate, correctly for a verification-only lock.
