# FIX D-H1 — CHANGED ASSERTIONS + BUILD RECORD

Fix: D-H1 (design b) + V-H1, per `gate-h/LOCK_FIX_DH1.md` (ruled + confirmed by Raj 2026-10-28).
Evidence root: `gate-h/evidence/logs/fix-dh1/`, results `gate-h/evidence/results/fix-dh1/`.

## Changed assertions: NONE pre-existing

No pre-existing test or assertion was modified, weakened, or removed anywhere.
The only test-side changes are **additive**:

| # | Change | Reason |
|---|--------|--------|
| A1 | NEW file `video-factory-g2/tests/test_fix_dh1.py` (4 tests) | Lock §acceptance: coordinator-level proof that `scheduler_claim` pre-stages the executor identity per step (incl. 12.12 → g6 by step, not registry station), claim audit actor stays the scheduler's, the step→identity mapping's boundaries, and the coordinator↔generator cross-check against the five generated `unit-executor.json` files. |
| A2 | ONE new method `test_attempts_carry_fencing_token_for_resume` in `video-factory-g3/tests/test_api_contract.py` | Lock item 4: `GET /units/{uid}/attempts` now exposes `fencing_token` on the current attempt; the test asserts it equals the claim's token and that the resolved-config snapshot rides along. The file's existing shape assertions pin only top-level response keys, so nothing else needed extending. |
| A3 | Gate F runtime-services tests: **no changes** | The brief anticipated identity assertions on scheduler claims here; inspection found none (the suites assert claim counts, reservations and recovery, never the claim's worker_id). The suite passes unmodified against the pre-staging scheduler — see counts below. |

## Suite counts (read from the logs in `logs/fix-dh1/`)

Green, clean runs:

| Suite | Count | Run |
|-------|-------|-----|
| G1 | 9/9 OK | battery 2 (`suite_g1.log`) |
| G2 | **62/62 OK** (58 + 4 new, A1) | battery 2 (`suite_g2.log`); new tests also standalone (`g2_fix_dh1_tests.log`) |
| G3 | **26/26 OK** (25 + 1 new, A2) | battery 2 (`suite_g3.log`) |
| G4 | 2/2 OK | supplement (`suite2_g4.log`) |
| G5 | 1/1 OK | battery 2 (`suite_g5.log`) |
| G7 | 2/2 OK | supplement (`suite2_g7.log`) |
| worker_service | 19/19 OK | battery 2 (`suite_worker_service.log`) |
| storage_service | 5/5 OK | battery 2 (`suite_storage_service.log`) |
| evaluation_service | 25/25 OK | supplement (`suite2_evaluation_service.log`) |
| runtime_services | 10/10 OK | supplement (`suite2_runtime_services.log`) |

**Not yet green — environment-blocked, not assertion failures: G6 (3), G8 (1), G9 (9).**
Every attempt since ~03:05 UTC carries an infrastructure signature only —
connection-refused mid-suite, `Address already in use` at API bind
(`/tmp/g4-api.log`, `/tmp/g6-api.log`), a same-named scratch DB dropped
mid-build — caused by a **concurrent workload on this shared VM** (the
parent's master execution programme) running the same setups against the
same ports (8730/8795/8796) and the same scratch-DB names, fuser-killing
services this battery was using. Direct evidence: `logs/fix-dh1/
interference_snapshot.log` (a foreign `video-factory-g5/tools/setup_env.py`
respawning the shared services at 03:23 UTC during this fix's final pass)
and `logs/fix-dh1/regression_final.json` (g6's ports never freed in 45 s;
g8's verified API gone minutes later; g9's environment verified good at
setup, then connection-refused mid-suite). Battery 1 had already shown
G4 2/2 and G5 1/1 green on the fixed code before a VM replacement killed
it mid-G6 (`regression_console_interrupted.log`). These three suites must
be re-run when the VM is exclusive; nothing in their failures touches
product behavior, and no result is claimed for them here.

## Acceptance evidence (lock criteria i + ii)

`results/fix-dh1/t9_rerun.json` — Gate H T9 scenario re-run on the fixed
code: **PASS 12/12** (harness `gate-h/harness/fix_dh1_t09.py`, console
`logs/fix-dh1/t9_rerun_console.log`): unattended Station-3 chain completes;
exactly one attempt per unit, all under `n8n-executor-g5`; claim audit
actor `scheduler-service` ×4; budget settled 4 × 90 = 360 ¢, nothing held;
one handoff per unit; zero claim-refused executor executions; Claim
context `resumed=true` ×4; HG2 created + decided. Negatives: N1
wrong-identity claim (`someone-else`) not adopted (claim-refused branch,
unit CLAIMED, 1 attempt, 0 artifacts); N2 started attempt not adopted
(same refusals, unit RUNNING).

## Build notes (judgment calls + incidents, disclosed)

1. **Executor identity values**: `n8n-executor-g4` … `n8n-executor-g8`
   (per-tree constants in each `tools/gen_workflows.py`; mirrored as
   `EXECUTOR_WORKER_IDS` + step ranges in the coordinator, cross-checked
   by test A1). Step-based mapping per the lock: 01–04→g4, 05–08→g5,
   09–12→g6, 13–14→g7, 15–16→g8.
2. **"Unstarted" determination**: attempt rows carry `status='RUNNING'`
   and `started_at=now()` from the claim itself (migration 002 defaults),
   so neither marks a start. The resume branch therefore keys on the
   signals that do: unit state `CLAIMED` (the `start` transition is what
   moves a unit out of CLAIMED), the attempts snapshot's lease-marked
   current attempt (the only row carrying `fencing_token`), that
   attempt's `worker_id` equal to the executor constant, `finished_at`
   and `output_artifact_id` null, and no provider job for the attempt
   (checked via `GET /units/{uid}/provider-jobs`).
3. **API change surface**: `fencing_token` is populated on the current
   attempt only, from `worker_leases`, exactly like the Gate G lease
   fields; non-current attempts carry null. Contract 1.4.0 → **1.5.0**
   with the change noted in `contracts/api_contract.json` (top-level
   notes + the attempts endpoint note). No endpoint added or removed;
   `resolved_config` was already exposed.
4. **`scheduler_claim` signature**: `worker_prefix` is retained for call
   compatibility but no longer shapes the identity (documented in the
   docstring). Reservation, config resolution, lane gating and the
   dispatch outbox event are byte-for-byte the pre-fix behavior; only
   the `worker_id` argument to `claim()` changed.
5. **Builder defect found by the fix's own first acceptance attempt**
   (fixed before any green claim): the new `Fetch provider jobs (resume
   check)` node read `{{$json.unit_id}}` from the attempts *response*
   (which has no `unit_id`) → 404 `NodeApiError`, execution 5112; and
   `Fetch attempt snapshot`'s predecessor changed from the claim response
   to Claim context, which initially dropped `unit_id`. Remedies: the
   provider-jobs URL takes the id from the trigger item (the existing
   submit-candidate idiom), and Claim context now passes `unit_id`
   through on both branches. The failed first run's results JSON was
   overwritten by the passing re-run; the failure is recorded here and
   in the builder's summary.
6. **Credential-literal redaction trap (recurring, Gates D/E)**: the DSN
   literal written into the new g2 test file was mangled by the write
   path into a placeholder (auth failures). Remedied the established
   way — the test sources its DSN from the shared G3 fixture
   (`server_fixture.make_dsn`), embedding no credential literal.
7. **VM replacement mid-regression**: battery 1 was killed by a runtime
   restart after G1–G5 went green; the platform's package-intent replay
   restored PostgreSQL 16.15 (cluster started by hand), /tmp was wiped,
   and the battery was re-run from scratch (battery 2). No product code
   was affected; all trees live under `~/workspace` and survived.

---

# ADDENDUM — Master Execution Programme Gate 02 alignment (owner programme
# received mid-fix; parent scope-alignment message supersedes where noted)

The programme's Gate 02 task/test list is fuller than LOCK_FIX_DH1. The
following scope elaborations were implemented under it (design (b) itself
unchanged):

A1. **Adoption endpoint added (programme tasks 4–6)** — supersedes the
    snapshot-only resume of LOCK_FIX_DH1 §3/§4:
    * Migration 014 (additive): action_attempts.adopted_at / adopted_by /
      adoption_key; chained in g2/tools/setup_db.py.
    * Coordinator.adopt_attempt(unit_id, worker_id, attempt_id,
      idempotency_key, fencing_token=None) + AdoptRefused (machine-readable
      .reason). Atomic single-winner via the conditional
      UPDATE ... WHERE adopted_at IS NULL on the attempt row (unit row
      FOR UPDATE serializes against claim/complete). Idempotent per
      (worker, idempotency_key): the winner's key replays return the same
      adoption with fresh=false and NO second start; any other
      post-adoption call is refused already_adopted. Refusals (committed
      adopt_refused audit evidence): attempt_not_found, unit_not_claimed
      (covers cancelled/BLOCKED), superseded, identity_mismatch,
      already_started (finished/output/provider-job), no_lease,
      lease_expired, stale_fencing. Adoption is NOT a start: unit stays
      CLAIMED; claim-time budgets/capacity untouched (task 9).
    * API: POST /units/{uid}/adopt (roles OPERATOR + WORKER — parity with
      /claim, which likewise takes a body worker_id; the credential gate
      is the coordinator's identity match). Contract 1.5.0 now denotes
      THIS change (the endpoint addition); endpoint count 34 -> 35.
    * The executor resume branch now: finds the candidate attempt id
      from the attempts read (ids are not credentials), builds an
      adoption request with an idempotency key unique per n8n execution
      ('adopt:<attempt_id>:<$execution.id>'), calls the adopt endpoint,
      and proceeds from the adopt response; on refusal it falls through
      to the existing claim path (409 -> claim-refused handling).
      'Fetch provider jobs (resume check)' removed from the executors
      (the endpoint validates started-ness authoritatively). Unit
      executors now have 22 nodes.
A2. **REVERTED — attempts-read fencing exposure.** Per the programme
    guardrail ("do not broaden fencing-token visibility"), the
    fencing_token field added to GET /units/{uid}/attempts in the first
    pass of this fix was REMOVED again (lease_expires_at /
    lease_worker_id from Gate G remain). The adopt response is the only
    fencing disclosure, gated on identity match. The G3 test
    test_attempts_carry_fencing_token_for_resume was REPLACED by
    test_adopt_endpoint_issues_credentials (see A3), which also asserts
    the attempts read carries NO fencing_token.
A3. **Changed/added tests under the alignment:**
    * g3 test_api_contract.py: (i) TestApiGateG.
      test_attempts_carry_fencing_token_for_resume REPLACED by
      test_adopt_endpoint_issues_credentials (suite count unchanged:
      26); (ii) TestApiContract.test_all_endpoints EXTENDED in place to
      exercise POST /units/{id}/adopt (the class asserts every contract
      endpoint is exercised): wrong identity 409, adopt 200 with the
      claim's fencing, same-key replay fresh=false, different key 409.
      No pre-existing assertion was removed or weakened in either edit;
      the exercised flow is additive within the narrative (the unit is
      adopted between its claim and its completion; completion is
      unaffected because adoption is not a start).
    * g2 tests/test_fix_dh1.py: +6 adoption tests (TestAdoption: success
      + idempotent replay, wrong-identity-then-rightful, stale fencing +
      superseded, expired lease + reaper intact, started attempt,
      concurrent single-winner at the coordinator level). File total 10.
      G2 suite total now 68 (was 62 after the D-H1 pass).
    * Programme mandatory tests recorded as JSON in
      evidence/results/fix-dh1/t02{a..i}.json; harnesses
      harness/fix_dh1_t02.py (A/B/C/D/F/G at API level, own API instance
      on port 8731) and harness/fix_dh1_t02e.py (E, duplicate dispatch on
      the G5 stack); T02-H is the re-run of harness/fix_dh1_t09.py.
A4. **Self-incident (builder), disclosed:** the first API-level adopt
    implementation silently failed to persist: the API route's
    get_unit() existence check left a read transaction open on the
    per-request connection, so adopt_attempt's transaction() block
    nested as a savepoint and rolled back on close (the D1 defect class
    documented in Coordinator._flush_reads). The coordinator library
    tests passed because their connections were clean. Caught by the G3
    contract/GateG tests (replay returned fresh=true) and by a
    cross-connection probe; fixed by calling self._flush_reads() at the
    top of adopt_attempt (the established pattern in claim/complete/
    reap); re-verified cross-connection (adoption persists; replay
    returns fresh=false). Also in this pass: the migration file was
    initially written to a stray g2/ subdirectory of the G2 tree and
    moved to database/migrations/ (setup_db failure made it visible
    immediately; no other effect), and the T02 harness's raw() helper
    needed a no-result guard for UPDATEs.

A5. **Stack-bound evidence still owed (environment, not product):** at
    the close of this alignment pass, T02-E (duplicate dispatch),
    T02-H (the fix_dh1_t09 re-run on the adopt-path executors) and the
    G4/G5/G6/G7/G8/G9 station suites (18 tests) could NOT be re-run:
    the parent programme's own G5 stack (API pid 34907, n8n, started
    2026-10-29T03:23Z) held ports 8730/8795/8796/5678 continuously for
    22+ minutes with ~zero CPU (snapshots in logs/fix-dh1/
    interference_snapshot.log and interference_snapshot2.log). Killing
    another workload's services would corrupt its evidence
    symmetrically, so the builder did not compete. All other Gate 02
    evidence is complete: T02-A/B/C/D/F/G PASS at API level, G1 9 +
    G2 68 + G3 26 + worker 19 + storage 5 + evaluation 25 + runtime 10
    = 162 regression tests green on the final code, hygiene clean.
    Re-run on an exclusive VM: harness/fix_dh1_t02e.py, then
    harness/fix_dh1_t09.py, then the six station suites, then
    harness/fix_dh1_t02hi.py (writes t02h.json + t02i.json).
