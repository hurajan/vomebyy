"""T02-E: duplicate dispatch cannot cause duplicate billable execution.

On the G5 stack (no runner): scheduler-prestage one 05.12 unit, then
POST the SAME dispatch payload to the g5 dispatch webhook TWICE.
Expected: the first dispatch's executor ADOPTS the prestaged attempt
and executes once (one attempt, one artifact, one FINALIZED settlement
of 90c, one attempt_adopted audit); the duplicate dispatch's executor
finds nothing adoptable, is refused at claim, and produces nothing.

Result: gate-h/evidence/results/fix-dh1/t02e.json
"""
import json
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import fix_dh1_t09 as fx  # noqa: E402  (helpers: run_g5_setup via common, n8n access)
from common import *  # noqa: E402,F403

sys.path.insert(0, str(G2))
from coordinator.coordinator import Coordinator  # noqa: E402

OUT = RESULTS / "fix-dh1" / "t02e.json"
CHECKS = []


def check(name, ok, detail=""):
    CHECKS.append({"name": name, "ok": bool(ok), "detail": str(detail)[:1200]})
    print(("PASS " if ok else "FAIL ") + name)
    return bool(ok)


def main():
    fx.run_g5_setup(log_name="fix_dh1_t02e_g5_setup.log")
    cookie = fx.n8n_cookie()
    api = fx.g5_api()
    pid, uid = fx.plan_single(api, "T02-E duplicate dispatch")

    sched = Coordinator(G5_DSN, actor="scheduler-service")
    claimed = sched.scheduler_claim()
    mine = [c for c in claimed if c["unit_id"] == uid]
    # claim() return dicts carry no worker_id (by design); the prestaged
    # identity lives on the attempt/lease rows — assert it there.
    with raw(G5_DSN) as conn:
        att = conn.execute(
            "SELECT worker_id FROM action_attempts WHERE unit_id=%s"
            " ORDER BY attempt_no", (uid,)).fetchall()
    check("prestaged under the g5 executor identity",
          len(mine) == 1 and len(att) == 1
          and att[0]["worker_id"] == "n8n-executor-g5",
          f"claimed={mine} attempts={[dict(a) for a in att]}")
    sched.close()

    payload = {"idempotency_key": f"dispatch:{uid}:1", "unit_id": uid,
               "production_id": pid, "operation_id": "05.12", "attempt_no": 1}
    marker = fx.max_execution_id(cookie)
    fx.dispatch(payload)

    state = None
    deadline = time.time() + 150
    while time.time() < deadline:
        st, out = api.call("GET", f"/productions/{pid}/units",
                           role="OPERATOR", identity="harness")
        row = [u for u in out["units"] if u["unit_id"] == uid]
        state = row[0]["state"] if row else None
        if state in ("AWAITING_HUMAN", "ACCEPTED"):
            break
        time.sleep(3)
    check("first dispatch executed the unit (evaluation reached)",
          state in ("AWAITING_HUMAN", "ACCEPTED"), f"state={state}")

    fx.dispatch(payload)  # the duplicate
    execs = fx.wait_executions(cookie, marker, at_least=2, timeout=90)
    second_refused = False
    adopted_contexts = 0
    for e in execs:
        names = set(fx.run_data(e).keys())
        if "Claim refused or duplicate dispatch" in names:
            second_refused = True
        for cj in fx.node_json(e, "Claim context"):
            if cj.get("adopted") is True:
                adopted_contexts += 1

    unit, attempts, arts = fx.unit_db(uid)
    with raw(G5_DSN) as conn:
        fin = conn.execute(
            "SELECT count(*) AS n FROM financial_evidence WHERE unit_id=%s"
            " AND charge_class='FINALIZED'", (uid,)).fetchone()["n"]
        charge = conn.execute(
            "SELECT COALESCE(SUM(amount_cents),0) AS s FROM budget_transactions"
            " WHERE production_id=%s AND kind='CHARGE'", (pid,)).fetchone()["s"]
        adopted = conn.execute(
            "SELECT count(*) AS n FROM audit_events WHERE unit_id=%s"
            " AND event_type='attempt_adopted'", (uid,)).fetchone()["n"]
    check("exactly one attempt after duplicate dispatch",
          len(attempts) == 1, f"attempts={attempts}")
    check("exactly one artifact produced", arts == 1, f"artifacts={arts}")
    check("exactly one FINALIZED settlement (90c)",
          fin == 1 and int(charge) == 90, f"finalized={fin} charge={charge}")
    check("exactly one adoption", adopted == 1, f"adopted_audits={adopted}")
    check("one executor execution adopted via Claim context",
          adopted_contexts == 1, f"adopted_contexts={adopted_contexts}")
    check("duplicate dispatch refused at claim", second_refused,
          f"executions={len(execs)}")

    verdict = "PASS" if all(c["ok"] for c in CHECKS) else "FAIL"
    OUT.write_text(json.dumps(
        {"test": "T02-E", "verdict": verdict, "checks": CHECKS,
         "unit_state": state}, indent=1, default=str))
    print("T02-E verdict:", verdict)


if __name__ == "__main__":
    main()
