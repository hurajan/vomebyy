"""Fix D-H1 acceptance run — Gate H T9 scenario re-run on the FIXED code
(LOCK_FIX_DH1 acceptance criteria i + ii).

Positive: the unattended Station-3 chain driven only by services
(Gate F runner: scheduler pre-stages claims under the executor identity
-> dispatcher hands off -> Gate G executor RESUMES -> worker service ->
evaluation service -> harness human approvals + HG2 decision). Asserts:
exactly one attempt per unit under 'n8n-executor-g5', claim audit actor
is the scheduler, budget settled exactly once per unit, and no n8n
unit-executor execution in the window took the claim-refused branch
(every execution resumed: Claim context resumed=true).

Negatives (runner stopped, dispatcher-shaped payloads POSTed directly
to the station webhook):
  N1 a claim pre-staged under a WRONG identity ('someone-else') must
     NOT be adopted — execution ends at claim-refused, unit stays
     CLAIMED, no artifacts, still exactly one attempt;
  N2 a STARTED attempt (claim by the executor identity + start event,
     unit RUNNING) must NOT be adopted — same refusals.

Writes results/fix-dh1/t9_rerun.json. No product code touched.
"""
import json
import sys
import time
import urllib.request

sys.path.insert(0, str(__file__).rsplit("/harness/", 1)[0] + "/harness")
from common import *  # noqa: E402,F403
import t09_unattended as t09  # noqa: E402

sys.path.insert(0, str(G5 / "tools"))
import setup_env as g5setup  # noqa: E402  (rest() + OWNER for the n8n REST API)

EXECUTOR_WF = "G5UnitExecutor01"
IDENTITY = "n8n-executor-g5"
OUT = RESULTS / "fix-dh1" / "t9_rerun.json"

CHECKS = []
DATA = {}


def check(name, ok, detail=""):
    CHECKS.append({"name": name, "ok": bool(ok), "detail": str(detail)[:1500]})
    print(("PASS " if ok else "FAIL ") + name)
    return bool(ok)


# ---------------------------------------------------------------- n8n REST
def n8n_cookie():
    for _ in range(60):
        g5setup.rest("POST", "/rest/owner/setup", g5setup.OWNER)
        _, h, _ = g5setup.rest(
            "POST", "/rest/login",
            {"emailOrLdapLoginId": g5setup.OWNER["email"],
             "password": g5setup.OWNER["password"]})
        if h.get("Set-Cookie"):
            return h.get("Set-Cookie").split(";")[0]
        time.sleep(2)
    raise RuntimeError("n8n login never became ready")


def _exec_items(out):
    data = out.get("data", {}) if isinstance(out, dict) else {}
    return data.get("results", []) if isinstance(data, dict) else []


def executor_executions(cookie, marker_id):
    """Full execution records for the unit-executor workflow newer than
    marker_id (numeric n8n execution ids are monotonic). Each record
    carries '_arr': the parsed flatted slot array of its execution data
    (n8n stores execution data flatted: object/array values appear as
    digit-string references into the slot array)."""
    _, _, out = g5setup.rest(
        "GET", "/rest/executions?limit=100", cookie=cookie)
    full = []
    for e in _exec_items(out):
        try:
            eid = int(e.get("id", 0))
        except (TypeError, ValueError):
            continue
        if eid <= marker_id or e.get("workflowId") != EXECUTOR_WF:
            continue
        _, _, det = g5setup.rest("GET", f"/rest/executions/{eid}", cookie=cookie)
        d = det.get("data", det)
        rec = dict(d)
        try:
            rec["_arr"] = json.loads(d.get("data") or "[]")
        except (TypeError, json.JSONDecodeError):
            rec["_arr"] = []
        full.append(rec)
    return full


def max_execution_id(cookie):
    _, _, out = g5setup.rest("GET", "/rest/executions?limit=100", cookie=cookie)
    ids = []
    for e in _exec_items(out):
        try:
            ids.append(int(e.get("id", 0)))
        except (TypeError, ValueError):
            pass
    return max(ids, default=0)


def _nav(arr, v):
    """Follow flatted digit-string references at structural hops."""
    seen = 0
    while isinstance(v, str) and v.isdigit() and int(v) < len(arr) and seen < 12:
        v = arr[int(v)]
        seen += 1
    return v


def run_data(execution):
    arr = execution.get("_arr") or []
    if not arr:
        return {}
    result = _nav(arr, arr[0].get("resultData"))
    if not isinstance(result, dict):
        return {}
    rd = _nav(arr, result.get("runData"))
    return rd if isinstance(rd, dict) else {}


def node_json(execution, node_name):
    arr = execution.get("_arr") or []
    entries = _nav(arr, run_data(execution).get(node_name)) or []
    out = []
    for ent in entries:
        ent = _nav(arr, ent)
        if not isinstance(ent, dict):
            continue
        data = _nav(arr, ent.get("data")) or {}
        for branch in _nav(arr, data.get("main")) or []:
            for item in _nav(arr, branch) or []:
                item = _nav(arr, item)
                if isinstance(item, dict):
                    j = _nav(arr, item.get("json"))
                    if isinstance(j, dict):
                        out.append(j)
    return out


def wait_executions(cookie, marker_id, at_least=1, timeout=60):
    deadline = time.time() + timeout
    found = []
    while time.time() < deadline:
        found = executor_executions(cookie, marker_id)
        if len(found) >= at_least:
            return found
        time.sleep(3)
    return found


# -------------------------------------------------------------------- util
def dispatch(payload):
    req = urllib.request.Request(
        "http://127.0.0.1:5678/webhook/dispatch-g5",
        data=json.dumps(payload).encode(), method="POST",
        headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=15) as r:
        return r.status


def plan_single(api, title):
    st, prod = api.call("POST", "/productions",
                        {"title": title, "hard_ceiling_cents": 1000000,
                         "soft_ceiling_cents": 900000},
                        role="OPERATOR", identity="harness")
    pid = prod["production_id"]
    st, r = api.call("POST", f"/productions/{pid}/runs", {"kind": "FULL"},
                     role="OPERATOR", identity="harness")
    st, canon = api.call("POST", f"/productions/{pid}/artifacts",
                         {"artifact_type": "canon_manifest",
                          "content": "canon fixture",
                          "storage_uri": "local://canon-fixture"},
                         role="OPERATOR", identity="harness")
    st, u = api.call("POST", f"/productions/{pid}/units",
                     {"operation_id": "05.12", "run_id": r["run_id"],
                      "unit_key": "main", "depends_on": [],
                      "input_artifact_ids": [canon["artifact_id"]]},
                     role="OPERATOR", identity="harness")
    return pid, u["unit_id"]


def unit_db(uid):
    with raw(G5_DSN) as conn:
        unit = conn.execute("SELECT * FROM execution_units WHERE unit_id=%s",
                            (uid,)).fetchone()
        attempts = conn.execute(
            "SELECT attempt_no, worker_id, status FROM action_attempts"
            " WHERE unit_id=%s ORDER BY attempt_no", (uid,)).fetchall()
        arts = conn.execute(
            "SELECT count(*) AS n FROM artifacts WHERE produced_by_unit=%s",
            (uid,)).fetchone()["n"]
    return dict(unit), [dict(a) for a in attempts], arts


# -------------------------------------------------------------------- main
def main():
    run_g5_setup(log_name="fix_dh1_g5_setup.log")
    cookie = n8n_cookie()
    api = g5_api()

    # ============================ POSITIVE ============================
    runner = start_runner(G5_DSN, "http://127.0.0.1:5678/webhook/dispatch-g5",
                          log_name="fix_dh1_runner.log")
    try:
        marker = max_execution_id(cookie)
        pid, run_id, canon_id, units = plan_station3(
            api, "Fix D-H1 T9 re-run production")
        units_rev = {v: k for k, v in units.items()}
        rec = Recorder("FIXT9", "scratch")  # only .data is borrowed
        states = t09.observe(api, pid, units, units_rev, 300, rec, "fixdh1")
        DATA["final_states"] = {units_rev[k]: v for k, v in states.items()}
        completed = len(states) == 4 and all(
            s == "ACCEPTED" for s in states.values())
        check("positive: unattended chain completes (05.12-08.12 ACCEPTED)",
              completed, f"states={DATA['final_states']}")

        # HG2 (harness human act, as in T9)
        st, gates = api.call("GET", f"/productions/{pid}/gates",
                             role="OPERATOR", identity="harness")
        hg2 = [g for g in gates["gates"] if g["gate_kind"] == "HG2"]
        if hg2 and hg2[0]["verdict"] == "PENDING":
            api.call("POST", f"/gates/{hg2[0]['gate_id']}/decide",
                     {"decision": "APPROVED"}, role="OPERATOR",
                     identity="harness")
            st, gates = api.call("GET", f"/productions/{pid}/gates",
                                 role="OPERATOR", identity="harness")
            hg2 = [g for g in gates["gates"] if g["gate_kind"] == "HG2"]
        check("positive: HG2 created by the station flow and decided APPROVED",
              bool(hg2) and hg2[0]["verdict"] == "APPROVED",
              f"gates={gates['gates']}")

        # exactly one attempt per unit, under the executor identity
        ok_attempts, detail = True, {}
        with raw(G5_DSN) as conn:
            for op, uid in units.items():
                rows = conn.execute(
                    "SELECT attempt_no, worker_id, status FROM action_attempts"
                    " WHERE unit_id=%s ORDER BY attempt_no", (uid,)).fetchall()
                detail[op] = [dict(r) for r in rows]
                if len(rows) != 1 or rows[0]["worker_id"] != IDENTITY:
                    ok_attempts = False
            claim_audit = conn.execute(
                "SELECT unit_id, actor, payload FROM audit_events"
                " WHERE production_id=%s AND event_type='claim'", (pid,)).fetchall()
            settled = conn.execute(
                "SELECT COALESCE(SUM(amount_cents),0) AS s FROM"
                " budget_transactions WHERE production_id=%s AND kind='CHARGE'",
                (pid,)).fetchone()["s"]
            held = conn.execute(
                "SELECT count(*) AS n FROM budget_reservations"
                " WHERE production_id=%s AND state='HELD'", (pid,)).fetchone()["n"]
        DATA["attempts"] = detail
        check("positive: exactly one attempt per unit, worker_id = executor "
              "identity (resumed, not duplicated)", ok_attempts,
              f"attempts={detail}")
        audit_ok = len(claim_audit) == 4 and all(
            r["actor"] == "scheduler-service"
            and (r["payload"].get("worker_id") == IDENTITY
                 if isinstance(r["payload"], dict)
                 else IDENTITY in str(r["payload"]))
            for r in claim_audit)
        check("positive: claim audit actor is the scheduler for all 4 units",
              audit_ok, f"claim_audit={[(r['actor'], str(r['payload'])[:80]) for r in claim_audit]}")
        check("positive: budget settled exactly once per unit (4 x 90 = 360, "
              "nothing held)", settled == 360 and held == 0,
              f"settled={settled} held_reservations={held}")
        check("positive: one dispatch handoff per unit",
              t09.handoffs(pid) == 4, f"handoffs={t09.handoffs(pid)}")

        # n8n evidence: executions resumed, none claim-refused
        execs = wait_executions(cookie, marker, at_least=4, timeout=60)
        refused = [e.get("id") for e in execs
                   if "Claim refused or duplicate dispatch" in run_data(e)]
        resumed_flags = []
        for e in execs:
            for j in node_json(e, "Claim context"):
                resumed_flags.append(j.get("resumed"))
        DATA["executor_executions"] = [e.get("id") for e in execs]
        DATA["resumed_flags"] = resumed_flags
        check("positive: no executor execution took the claim-refused branch",
              len(execs) >= 4 and not refused,
              f"executions={DATA['executor_executions']} refused={refused}")
        check("positive: executor executions resumed the pre-staged claims "
              "(Claim context resumed=true x4)",
              resumed_flags.count(True) >= 4,
              f"resumed_flags={resumed_flags}")
    finally:
        stop_proc(runner)

    # ============================ NEGATIVES ===========================
    time.sleep(3)  # runner fully stopped; scheduler can no longer claim
    # ---- N1: wrong-identity pre-staged claim must not be adopted
    pid1, u1 = plan_single(api, "Fix D-H1 negative N1 (wrong identity)")
    st, claim = api.call("POST", f"/units/{u1}/claim",
                         {"worker_id": "someone-else"}, role="WORKER")
    assert st == 200, f"N1 manual claim failed: {st} {claim}"
    marker = max_execution_id(cookie)
    dispatch({"idempotency_key": f"dispatch:{u1}:1", "unit_id": u1,
              "production_id": pid1, "operation_id": "05.12", "attempt_no": 1})
    execs = wait_executions(cookie, marker, at_least=1, timeout=60)
    time.sleep(3)
    unit1, attempts1, arts1 = unit_db(u1)
    refused1 = any("Claim refused or duplicate dispatch" in run_data(e)
                   for e in execs)
    check("N1: wrong-identity claim not adopted (claim-refused branch taken)",
          refused1 and len(execs) >= 1,
          f"executions={[e.get('id') for e in execs]} refused={refused1}")
    check("N1: unit still CLAIMED, one attempt, no artifacts",
          unit1["state"] == "CLAIMED" and len(attempts1) == 1 and arts1 == 0,
          f"state={unit1['state']} attempts={attempts1} artifacts={arts1}")

    # ---- N2: started attempt must not be adopted
    pid2, u2 = plan_single(api, "Fix D-H1 negative N2 (started attempt)")
    st, claim = api.call("POST", f"/units/{u2}/claim",
                         {"worker_id": IDENTITY}, role="WORKER")
    assert st == 200, f"N2 manual claim failed: {st} {claim}"
    # Gate 05 (G01-D07): start is a WORKER-class event — fired as the
    # claiming worker with its identity in the body (was: OPERATOR token,
    # which the per-event matrix now refuses; the probe's intent — a
    # started attempt must not be adopted — is unchanged).
    st, out = api.call("POST", f"/units/{u2}/events",
                       {"event": "start", "worker_id": IDENTITY},
                       role="WORKER")
    assert st == 200, f"N2 start event failed: {st} {out}"
    marker = max_execution_id(cookie)
    dispatch({"idempotency_key": f"dispatch:{u2}:1", "unit_id": u2,
              "production_id": pid2, "operation_id": "05.12", "attempt_no": 1})
    execs = wait_executions(cookie, marker, at_least=1, timeout=60)
    time.sleep(3)
    unit2, attempts2, arts2 = unit_db(u2)
    refused2 = any("Claim refused or duplicate dispatch" in run_data(e)
                   for e in execs)
    check("N2: started attempt not adopted (claim-refused branch taken)",
          refused2 and len(execs) >= 1,
          f"executions={[e.get('id') for e in execs]} refused={refused2}")
    check("N2: unit still RUNNING, one attempt, no artifacts",
          unit2["state"] == "RUNNING" and len(attempts2) == 1 and arts2 == 0,
          f"state={unit2['state']} attempts={attempts2} artifacts={arts2}")

    verdict = "PASS" if all(c["ok"] for c in CHECKS) else "FAIL"
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(json.dumps(
        {"t": "FIX-DH1-T9", "title": "Gate H T9 re-run on fixed code (design b)",
         "verdict": verdict, "checks": CHECKS, "data": DATA},
        indent=2, default=str))
    print(f"FIX-DH1-T9: {verdict} "
          f"({sum(c['ok'] for c in CHECKS)}/{len(CHECKS)}) -> {OUT}")


if __name__ == "__main__":
    main()
