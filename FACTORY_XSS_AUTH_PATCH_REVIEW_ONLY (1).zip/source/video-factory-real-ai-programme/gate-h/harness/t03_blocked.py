"""T3 — Real provider execution: BLOCKED (OD-A3) (LOCK_GATE_H §T3).

No provider credential exists and none may be invented, so no real-provider
execution is attempted. This module verifies the negative space only:
credential-requiring adapters report BLOCKED on /health, refuse /work with
a typed BLOCKED error, raise BlockedError at the adapter layer, and no code
path fabricates a result when a credential is absent. The mock adapter is
fenced to test-only bindings in the test environment.
"""
import json
import re
import sys
import urllib.request

sys.path.insert(0, str(__file__).rsplit("/harness/", 1)[0] + "/harness")
from common import *  # noqa: E402,F403

WORKER_PORT = 8797
CRED_ADAPTERS = ["openrouter-compatible", "direct-http-text", "http-image",
                 "http-video", "http-speech", "http-transcription", "http-stock"]


def http(method, url, body=None):
    req = urllib.request.Request(url, method=method)
    data = None
    if body is not None:
        data = json.dumps(body).encode()
        req.add_header("Content-Type", "application/json")
    try:
        with urllib.request.urlopen(req, data=data, timeout=10) as r:
            return r.status, json.loads(r.read() or b"{}")
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read() or b"{}")


def main():
    rec = Recorder("T3", "Real provider execution — BLOCKED (OD-A3)")
    rec.note("No real-provider execution attempted: OD-A3 (provider selection "
             "and credentials) is an open owner decision; inventing or "
             "borrowing a credential is prohibited by the lock.")
    rec.note("Unblocks with: one provider credential delivered through the "
             "secure vault + a recorded per-provider spend cap + a provider "
             "binding row naming that provider/model for the target "
             "operations (Gate C config machinery), after which this item "
             "re-runs as a live execution check.")

    proc = start_worker_service(WORKER_PORT, DSN, log_name="worker_t03.log")
    try:
        st, health = http("GET", f"http://127.0.0.1:{WORKER_PORT}/health")
        adapters = health.get("adapters", {})
        rec.data["health_adapters"] = adapters
        for name in CRED_ADAPTERS:
            rec.check(f"/health: {name} is BLOCKED without credentials",
                      adapters.get(name, {}).get("status") == "BLOCKED",
                      f"{name}={adapters.get(name)}")
        rec.check("/health: deterministic-local is READY (sanctioned local path)",
                  adapters.get("deterministic-local", {}).get("status") == "READY",
                  f"{adapters.get('deterministic-local')}")

        # /work refusal for a credential-requiring provider
        st, out = http("POST", f"http://127.0.0.1:{WORKER_PORT}/work", {
            "unit_id": "00000000-0000-0000-0000-000000000000",
            "attempt_id": "00000000-0000-0000-0000-000000000000",
            "fencing_token": 1, "operation_id": "07.07",
            "provider_binding": {"provider": "openrouter-compatible",
                                 "model": "any/model",
                                 "credential_ref": "GATEH_ABSENT_CREDENTIAL",
                                 "est_cost_cents": 100},
            "input_artifact_refs": []})
        rec.check("/work with a credential-requiring binding and no credential "
                  "refuses 409 BLOCKED (no fabricated result)",
                  st == 409 and out.get("error_class") == "BLOCKED",
                  f"status={st} out={str(out)[:200]}")

        # /work refusal for the mock adapter without the test-only fence
        st, out = http("POST", f"http://127.0.0.1:{WORKER_PORT}/work", {
            "unit_id": "00000000-0000-0000-0000-000000000000",
            "attempt_id": "00000000-0000-0000-0000-000000000000",
            "fencing_token": 1, "operation_id": "07.07",
            "provider_binding": {"provider": "mock", "est_cost_cents": 100,
                                 "params": {}},
            "input_artifact_refs": []})
        rec.check("/work with mock provider but no params.test_only fence "
                  "refuses BLOCKED", st == 409 and out.get("error_class") == "BLOCKED",
                  f"status={st} out={str(out)[:200]}")
    finally:
        stop_proc(proc)

    # adapter-layer refusals (direct, no HTTP)
    sys.path.insert(0, str(GATE_C / "worker_service"))
    import adapters as adapters_mod
    reg = adapters_mod.build_registry("test")
    for name in ("openrouter-compatible", "direct-http-text"):
        adapter = reg[name]
        err = None
        try:
            adapter.execute({"provider": name, "credential_ref": "GATEH_ABSENT",
                             "params": {}}, {"operation_id": "07.07"})
        except Exception as e:  # noqa: BLE001
            err = e
        rec.check(f"adapter {name}.execute raises BlockedError without credential",
                  isinstance(err, adapters_mod.BlockedError),
                  f"{type(err).__name__}: {err}")

    # no fabricated-result path: source sweep of the worker service
    sweep_files = ["adapters.py", "service.py", "envelope.py", "payloads.py"]
    suspicious = []
    for fname in sweep_files:
        text = (GATE_C / "worker_service" / fname).read_text()
        for i, line in enumerate(text.splitlines(), 1):
            if re.search(r"except[^:]*:\s*$|except.*:\s*pass|fallback|simulate", line) \
                    and "BlockedError" not in line:
                suspicious.append(f"{fname}:{i}: {line.strip()[:110]}")
    rec.data["sweep_candidates"] = suspicious
    # every credential adapter's execute path must route through
    # require_credential / BlockedError — verify textually per adapter class
    src = (GATE_C / "worker_service" / "adapters.py").read_text()
    rec.check("adapters.py: credential enforcement present "
              "(require_credential raises BlockedError)",
              "raise BlockedError" in src and "def require_credential" in src)
    rec.check("no silent except/pass fallback in worker service sources",
              not any("pass" == s.rsplit(":", 1)[-1].strip() for s in suspicious),
              f"candidates={suspicious}")
    rec.note("Deterministic-local and the fenced mock are the only "
             "credential-free execution paths; both are local/test-scoped "
             "by design and neither impersonates a real provider.")
    rec.write(verdict="BLOCKED" if all(x["ok"] for x in rec.checks) else "FAIL")


if __name__ == "__main__":
    main()
