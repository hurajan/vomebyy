"""T7 — Configuration control (LOCK_GATE_H §T7).

A provider binding changed between two attempts of one operation:
attempt 1's snapshot/hash (and its claim-time ESTIMATED evidence) stay
pinned to version 1; attempt 2 resolves version 2; the audit trail shows
both versions and the change. Plus the environment rule: a
production-environment coordinator cannot resolve test bindings
(fails closed with a configuration_missing audit event).
"""
import sys
import tempfile

sys.path.insert(0, str(__file__).rsplit("/harness/", 1)[0] + "/harness")
from common import *  # noqa: E402,F403
from coordinator.coordinator import (  # noqa: E402
    Coordinator, ConfigurationMissingError)
from storage_service import LocalStorage  # noqa: E402

API_PORT = 8745


def attempt_row(unit_id, attempt_no=1):
    with raw() as conn:
        return conn.execute(
            "SELECT * FROM action_attempts WHERE unit_id=%s AND attempt_no=%s",
            (unit_id, attempt_no)).fetchone()


def main():
    rec = Recorder("T7", "Configuration control")
    build_db()
    store = LocalStorage(tempfile.mkdtemp(prefix="gateh-t7-store-"))
    proc = start_api(DB, API_PORT, log_name="api_t07.log")
    try:
        api = Api(API_PORT)
        st, cfg1 = api.call("POST", "/configs",
                            {"scope": "OPERATION", "operation_id": "12.12",
                             "provider": "mock", "est_cost_cents": 111,
                             "params": {"marker": "v1"}},
                            role="OPERATOR", identity="harness-t07")
        rec.check("binding v1 created via API", st == 201, f"status={st}")

        c = Coordinator(DSN, actor="harness-t07", storage=store)
        pid = c.create_production("T7 config", 1_000_000, 900_000, "harness-t07")
        run = c.start_run(pid, "FULL", "harness-t07")
        u = c.plan_unit(pid, run, "12.12", unit_key="t7-main", lane="text")
        claim1 = c.claim(u, "w-t07", None)
        a1 = attempt_row(u, 1)
        rec.check("attempt 1 pins binding v1 (est 111, marker v1)",
                  a1["resolved_config"]["est_cost_cents"] == 111
                  and a1["resolved_config"]["params"].get("marker") == "v1",
                  f"snapshot={a1['resolved_config']}")
        hash1 = a1["resolved_config_hash"]
        c.event(u, "start")
        c.complete_attempt(u, "w-t07", claim1["fencing_token"], "edit_timeline",
                           envelope(pid, "12.12", "edit_timeline"), None, 111)
        with raw() as conn:
            est_ev = conn.execute(
                "SELECT amount_cents FROM financial_evidence WHERE unit_id=%s"
                " AND charge_class='ESTIMATED'", (u,)).fetchall()

        # change the binding (v2) while attempt 1 is mid-flight history
        st, cfg2 = api.call("POST", "/configs",
                            {"scope": "OPERATION", "operation_id": "12.12",
                             "provider": "mock", "est_cost_cents": 222,
                             "params": {"marker": "v2"}},
                            role="OPERATOR", identity="harness-t07")
        rec.check("binding v2 created via API (supersedes v1)", st == 201,
                  f"status={st}")

        # drive attempt 1 to a repairable failure, then re-claim
        state = c.validate(u, [{"validator": "content_review", "method": "review",
                                "verdict": "FAIL", "evaluator": "harness-t07",
                                "evidence": {"deterministic": False}}])
        rec.check("attempt 1 lands REPAIR_REQUIRED", state == "REPAIR_REQUIRED",
                  f"state={state}")
        c.event(u, "repair_ready")
        claim2 = c.claim(u, "w-t07", None)
        a2 = attempt_row(u, 2)
        rec.check("attempt 2 resolves binding v2 (est 222, marker v2)",
                  a2["resolved_config"]["est_cost_cents"] == 222
                  and a2["resolved_config"]["params"].get("marker") == "v2",
                  f"snapshot={a2['resolved_config']}")
        rec.check("attempt snapshots/hashes differ across the change",
                  a2["resolved_config_hash"] != hash1,
                  f"hash1={hash1} hash2={a2['resolved_config_hash']}")
        a1_after = attempt_row(u, 1)
        rec.check("attempt 1 snapshot + hash unchanged after the change",
                  a1_after["resolved_config_hash"] == hash1
                  and a1_after["resolved_config"]["est_cost_cents"] == 111,
                  f"snapshot={a1_after['resolved_config']}")
        rec.check("attempt 1 ESTIMATED evidence stayed at the v1 price (111)",
                  len(est_ev) == 1 and est_ev[0]["amount_cents"] == 111,
                  f"estimated={est_ev}")
        with raw() as conn:
            versions = conn.execute(
                "SELECT version, active, est_cost_cents FROM provider_configs"
                " WHERE scope='OPERATION' AND operation_id='12.12'"
                " ORDER BY version").fetchall()
            audits = conn.execute(
                "SELECT event_type, actor, payload FROM audit_events"
                " WHERE event_type='provider_config_changed'"
                " ORDER BY created_at").fetchall()
        rec.check("config history retains both versions (v1 superseded, v2 active)",
                  len(versions) == 2 and versions[0]["active"] is False
                  and versions[1]["active"] is True
                  and versions[0]["est_cost_cents"] == 111
                  and versions[1]["est_cost_cents"] == 222,
                  f"versions={versions}")
        audit_versions = sorted(a["payload"].get("version") for a in audits
                                if a["payload"].get("operation_id") == "12.12"
                                or a["payload"].get("scope") == "OPERATION")
        rec.check("audit trail records both config versions + the change "
                  "(provider_config_changed v1 and v2)",
                  audit_versions == [1, 2],
                  f"audits={[(a['event_type'], a['payload']) for a in audits]}")
        rec.data["config_audits"] = [dict(a) for a in audits]

        # -- environment separation -------------------------------------------
        pid2 = c.create_production("T7 env", 100_000, 90_000, "harness-t07")
        run2 = c.start_run(pid2, "FULL", "harness-t07")
        u2 = c.plan_unit(pid2, run2, "07.07", unit_key="t7-env", lane="text")
        prod_coord = Coordinator(DSN, actor="harness-t07-prod",
                                 environment="production", storage=store)
        err = None
        try:
            prod_coord.claim(u2, "w-prod", None)
        except Exception as e:  # noqa: BLE001
            err = e
        with raw() as conn:
            audit = conn.execute(
                "SELECT count(*) AS n FROM audit_events WHERE unit_id=%s"
                " AND event_type='configuration_missing'", (u2,)).fetchone()["n"]
        rec.check("production-environment claim refuses the test bindings "
                  "(fail closed)", isinstance(err, ConfigurationMissingError),
                  f"{type(err).__name__}: {err}")
        rec.check("environment refusal commits configuration_missing audit evidence",
                  audit == 1, f"audit={audit}")
        rec.check("unit untouched by the refused production claim",
                  c.get_unit(u2)["state"] == "READY",
                  f"state={c.get_unit(u2)['state']}")
        prod_coord.close()
        c.close()
    finally:
        stop_proc(proc)
    rec.write()


if __name__ == "__main__":
    main()
