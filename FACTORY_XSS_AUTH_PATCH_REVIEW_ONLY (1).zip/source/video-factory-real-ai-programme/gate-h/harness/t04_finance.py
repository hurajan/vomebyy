"""T4 — Financial integrity battery (LOCK_GATE_H §T4).

Duplicate completion, duplicate callback, two-worker claim race, hard
ceiling breach, stale-fencing callback carrying a charge, duplicate
settle_provider_charge, API-mode claim below the config estimate — with
end-of-check invariants: settled == sum(FINALIZED), held == sum(HELD
reservations), no negative availability.
"""
import sys
import tempfile
import threading

sys.path.insert(0, str(__file__).rsplit("/harness/", 1)[0] + "/harness")
from common import *  # noqa: E402,F403
from coordinator.coordinator import (  # noqa: E402
    Coordinator, BudgetExceeded, ChargeSettlementError, CoordinatorError)
from storage_service import LocalStorage  # noqa: E402

API_PORT = 8742


def main():
    rec = Recorder("T4", "Financial integrity")
    build_db()
    store = LocalStorage(tempfile.mkdtemp(prefix="gateh-t4-store-"))
    c = Coordinator(DSN, actor="harness-t04", storage=store)

    with raw() as conn:
        # OPERATION binding for the async operation + a pricing rule so the
        # callback path produces CALCULATED evidence (Gate D machinery).
        add_config(conn, "OPERATION", provider="mock", est=5000,
                   operation_id="11.06", model="mock-model", created_by="gateh-t04")
        conn.execute(
            "INSERT INTO pricing_rules(provider, model, unit_kind, unit_price_cents,"
            " pricing_version, created_by) VALUES ('mock','mock-model','input_token',"
            " 1, 't4-v1', 'gateh-t04')")

    def invariants(pid, label):
        pos = c.budget_position(pid)
        with raw() as conn:
            fin = conn.execute(
                "SELECT COALESCE(SUM(amount_cents),0) AS s FROM financial_evidence"
                " WHERE production_id=%s AND charge_class='FINALIZED'",
                (pid,)).fetchone()["s"]
            held = conn.execute(
                "SELECT COALESCE(SUM(estimated_cents),0) AS s FROM budget_reservations"
                " WHERE production_id=%s AND state='HELD'", (pid,)).fetchone()["s"]
        available = pos["hard_ceiling_cents"] - pos["projected_cents"]
        ok = (pos["settled_cents"] == fin and pos["held_cents"] == held
              and available >= 0)
        rec.check(f"invariants hold ({label}): settled==ΣFINALIZED, "
                  f"held==ΣHELD, available>=0", ok,
                  f"settled={pos['settled_cents']} fin={fin} held={pos['held_cents']}"
                  f"/{held} available={available}")
        return pos

    pid = c.create_production("T4 finance", 1_000_000, 1_000_000, "harness-t04")
    run = c.start_run(pid, "FULL", "harness-t04")

    def plan(op, key):
        return c.plan_unit(pid, run, op, unit_key=key, lane="text")

    # -- 1. duplicate completion ---------------------------------------------
    u = plan("05.12", "t4-dup-complete")
    claim = c.claim(u, "w1", None)
    c.event(u, "start")
    c.complete_attempt(u, "w1", claim["fencing_token"], "script",
                       envelope(pid, "05.12", "script"), None, 90)
    err = None
    try:
        c.complete_attempt(u, "w1", claim["fencing_token"], "script",
                           envelope(pid, "05.12", "script"), None, 90)
    except Exception as e:  # noqa: BLE001
        err = e
    rec.check("duplicate completion refused", isinstance(err, CoordinatorError),
              f"{type(err).__name__}: {err}")
    state = c.validate(u, [{"validator": "schema_validation", "method": "contract",
                            "verdict": "PASS", "evaluator": "harness-t04",
                            "evidence": {"deterministic": True}}])
    if state == "AWAITING_HUMAN":
        state = c.event(u, "human_approved")
    pos = invariants(pid, "after duplicate completion")
    rec.check("unit ACCEPTED, settled exactly once (90)",
              state == "ACCEPTED" and pos["settled_cents"] == 90,
              f"state={state} settled={pos['settled_cents']}")

    # -- 2. duplicate callback ------------------------------------------------
    u2 = plan("11.06", "t4-dup-callback")
    claim2 = c.claim(u2, "w1", None)
    c.event(u2, "start")
    job = c.submit_provider_job_v2(u2, claim2["attempt_id"],
                                   claim2["fencing_token"], "t4-cb")
    out = c.handle_callback("t4-cb", "media", b"clip", "local://clip", 4500,
                            usage={"input_tokens": 3000},
                            reported_cost_cents=4500, provider_request_id="prov-t4")
    rec.check("first callback completes the job",
              out["result"]["outcome"] == "completed" and not out["duplicate"],
              f"out={out['result']}")
    with raw() as conn:
        ev_before = conn.execute(
            "SELECT charge_class, amount_cents FROM financial_evidence"
            " WHERE unit_id=%s ORDER BY created_at", (u2,)).fetchall()
    dup = c.handle_callback("t4-cb", "media", b"clip", "local://clip", 4500,
                            usage={"input_tokens": 3000},
                            reported_cost_cents=4500, provider_request_id="prov-t4")
    with raw() as conn:
        ev_after = conn.execute(
            "SELECT charge_class, amount_cents FROM financial_evidence"
            " WHERE unit_id=%s ORDER BY created_at", (u2,)).fetchall()
        charges = conn.execute(
            "SELECT count(*) AS n FROM budget_transactions WHERE production_id=%s"
            " AND kind='CHARGE'", (pid,)).fetchone()["n"]
    rec.check("duplicate callback flagged duplicate, books nothing twice",
              dup["duplicate"] and ev_before == ev_after and charges == 2,
              f"dup={dup['duplicate']} evidence {len(ev_before)}->{len(ev_after)} "
              f"charges={charges}")
    fin_rows = [e for e in ev_after if e["charge_class"] == "FINALIZED"]
    rec.check("FINALIZED = CALCULATED 3000 (reported 4500 outside 10% tolerance)",
              len(fin_rows) == 1 and fin_rows[0]["amount_cents"] == 3000,
              f"finalized={fin_rows}")
    state = c.validate(u2, [{"validator": "schema_validation", "method": "contract",
                             "verdict": "PASS", "evaluator": "harness-t04",
                             "evidence": {"deterministic": True}}])
    if state == "AWAITING_HUMAN":
        state = c.event(u2, "human_approved")
    invariants(pid, "after duplicate callback")

    # -- 3. two workers racing one claim ---------------------------------------
    u3 = plan("07.07", "t4-race")
    results = {}

    def racer(name):
        cc = Coordinator(DSN, actor=f"harness-t04-{name}", storage=store)
        try:
            results[name] = ("ok", cc.claim(u3, name, None))
        except Exception as e:  # noqa: BLE001
            results[name] = ("err", f"{type(e).__name__}")
        finally:
            cc.close()

    t_a = threading.Thread(target=racer, args=("racer-a",))
    t_b = threading.Thread(target=racer, args=("racer-b",))
    t_a.start(); t_b.start(); t_a.join(); t_b.join()
    winners = [k for k, v in results.items() if v[0] == "ok"]
    losers = [k for k, v in results.items() if v[0] == "err"]
    with raw() as conn:
        held = conn.execute(
            "SELECT count(*) AS n FROM budget_reservations WHERE unit_id=%s"
            " AND state='HELD'", (u3,)).fetchone()["n"]
    rec.check("claim race: exactly one winner, loser gets a typed refusal",
              len(winners) == 1 and len(losers) == 1
              and "UnauthorizedTransition" in results[losers[0]][1],
              f"results={results}")
    rec.check("claim race: exactly one HELD reservation for the unit", held == 1,
              f"held={held}")
    invariants(pid, "after claim race")

    # -- 4. hard-ceiling breach -------------------------------------------------
    pid_b = c.create_production("T4 ceiling", 150, 150, "harness-t04")
    run_b = c.start_run(pid_b, "FULL", "harness-t04")
    ub1 = c.plan_unit(pid_b, run_b, "05.12", unit_key="t4-ceil-1", lane="text")
    c.claim(ub1, "w1", None)  # FACTORY binding est 100
    ub2 = c.plan_unit(pid_b, run_b, "05.12", unit_key="t4-ceil-2", lane="text")
    err = None
    try:
        c.claim(ub2, "w1", None)
    except Exception as e:  # noqa: BLE001
        err = e
    with raw() as conn:
        audit_rows = conn.execute(
            "SELECT event_type FROM audit_events WHERE unit_id=%s", (ub2,)).fetchall()
    rec.check("claim breaching the hard ceiling refused (BudgetExceeded)",
              isinstance(err, BudgetExceeded), f"{type(err).__name__}: {err}")
    rec.check("breaching unit BLOCKED with committed audit evidence",
              c.get_unit(ub2)["state"] == "BLOCKED" and len(audit_rows) >= 1,
              f"state={c.get_unit(ub2)['state']} audit={[r['event_type'] for r in audit_rows]}")
    invariants(pid_b, "ceiling production")

    # -- 5. stale-fencing callback carrying a charge + duplicate settle --------
    u5 = plan("11.06", "t4-stale")
    claim5 = c.claim(u5, "w1", None)
    c.event(u5, "start")
    c.submit_provider_job_v2(u5, claim5["attempt_id"], claim5["fencing_token"],
                             "t4-stale")
    c.event(u5, "transient_error")  # AWAITING_PROVIDER -> RETRY_WAIT
    c.retry_unit(u5)
    claim5b = c.claim(u5, "w1", None)
    settled_before = c.budget_position(pid)["settled_cents"]
    out = c.handle_callback("t4-stale", "media", b"late", "local://late", 777,
                            reported_cost_cents=777, provider_request_id="prov-late")
    rec.check("stale callback outcome is stale_fencing (nothing registered/settled)",
              out["result"]["outcome"] == "stale_fencing", f"out={out['result']}")
    with raw() as conn:
        flagged = conn.execute(
            "SELECT * FROM financial_evidence WHERE unit_id=%s"
            " AND charge_class='PROVIDER_REPORTED'", (u5,)).fetchall()
        arts = conn.execute(
            "SELECT count(*) AS n FROM artifacts WHERE produced_by_unit=%s",
            (u5,)).fetchone()["n"]
    rec.check("stale charge recorded as flagged PROVIDER_REPORTED evidence (777)",
              len(flagged) == 1 and flagged[0]["amount_cents"] == 777
              and flagged[0]["requires_reconciliation"] and arts == 0,
              f"flagged={[(f['amount_cents'], f['requires_reconciliation']) for f in flagged]} arts={arts}")
    rec.check("settled unchanged by the stale callback",
              c.budget_position(pid)["settled_cents"] == settled_before,
              f"settled={c.budget_position(pid)['settled_cents']} before={settled_before}")
    ev_id = str(flagged[0]["evidence_id"])
    settled_out = c.settle_provider_charge(ev_id, actor="harness-t04")
    rec.check("flagged charge settles exactly once via settle_provider_charge",
              c.budget_position(pid)["settled_cents"] == settled_before + 777,
              f"out={settled_out} settled={c.budget_position(pid)['settled_cents']}")
    err = None
    try:
        c.settle_provider_charge(ev_id, actor="harness-t04")
    except Exception as e:  # noqa: BLE001
        err = e
    rec.check("duplicate settle_provider_charge refused (ChargeSettlementError)",
              isinstance(err, ChargeSettlementError), f"{type(err).__name__}: {err}")
    invariants(pid, "after stale-charge settlement")

    # -- 6. API-mode claim below the config estimate ----------------------------
    proc = start_api(DB, API_PORT, log_name="api_t04.log")
    try:
        api = Api(API_PORT)
        st, cfg = api.call("POST", "/configs",
                           {"scope": "OPERATION", "operation_id": "07.07",
                            "provider": "mock", "est_cost_cents": 2000},
                           role="OPERATOR", identity="harness-t04")
        rec.check("OPERATION binding created via API (est 2000)", st == 201,
                  f"status={st} cfg={str(cfg)[:150]}")
        st, prod = api.call("POST", "/productions",
                            {"title": "T4 api", "hard_ceiling_cents": 1000000},
                            role="OPERATOR", identity="harness-t04")
        pid3 = prod["production_id"]
        st, r = api.call("POST", f"/productions/{pid3}/runs", {"kind": "FULL"},
                         role="OPERATOR", identity="harness-t04")
        st, u_resp = api.call("POST", f"/productions/{pid3}/units",
                              {"operation_id": "07.07", "run_id": r["run_id"]},
                              role="OPERATOR", identity="harness-t04")
        uid3 = u_resp["unit_id"]
        st, out = api.call("POST", f"/units/{uid3}/claim",
                           {"worker_id": "w-api", "estimated_cents": 100},
                           role="WORKER", identity="w-api")
        with raw() as conn:
            audit = conn.execute(
                "SELECT count(*) AS n FROM audit_events WHERE unit_id=%s"
                " AND event_type='estimate_below_config'", (uid3,)).fetchone()["n"]
            held3 = conn.execute(
                "SELECT count(*) AS n FROM budget_reservations WHERE unit_id=%s"
                " AND state='HELD'", (uid3,)).fetchone()["n"]
        rec.check("API claim below the config estimate refused (409)",
                  st == 409, f"status={st} out={str(out)[:150]}")
        rec.check("below-config refusal commits estimate_below_config audit, "
                  "reserves nothing", audit == 1 and held3 == 0,
                  f"audit={audit} held={held3}")
    finally:
        stop_proc(proc)
    invariants(pid, "end of T4")
    c.close()
    rec.write()


if __name__ == "__main__":
    main()
