"""T1 — Coordinator authority (LOCK_GATE_H §T1).

Bypass attempts against the coordinator and the API: unclaimed completion,
stale fencing, non-claiming worker, callback for a never-submitted job,
direct artifact registration substituting for a unit's validated output,
gate decision by a non-OPERATOR role. Every refusal must leave the unit
state unchanged and (where the design commits evidence) committed evidence.
"""
import sys
import tempfile

sys.path.insert(0, str(__file__).rsplit("/harness/", 1)[0] + "/harness")
from common import *  # noqa: E402,F403
from coordinator.coordinator import (  # noqa: E402
    Coordinator, UnauthorizedTransition, StaleFencing, CoordinatorError)
from storage_service import LocalStorage  # noqa: E402

API_PORT = 8741


def main():
    rec = Recorder("T1", "Coordinator authority")
    build_db()
    store = LocalStorage(tempfile.mkdtemp(prefix="gateh-t1-store-"))
    c = Coordinator(DSN, actor="harness-t01", storage=store)
    pid = c.create_production("T1 authority", 1_000_000, 900_000, "harness-t01")
    run = c.start_run(pid, "FULL", "harness-t01")

    def plan(op, key, deps=(), inputs=()):
        return c.plan_unit(pid, run, op, unit_key=key, lane="text",
                           depends_on=tuple(deps), input_artifact_ids=tuple(inputs))

    def audit_count(unit_id, event_type=None):
        with raw() as conn:
            if event_type:
                return conn.execute(
                    "SELECT count(*) AS n FROM audit_events WHERE unit_id=%s"
                    " AND event_type=%s", (unit_id, event_type)).fetchone()["n"]
            return conn.execute(
                "SELECT count(*) AS n FROM audit_events WHERE unit_id=%s",
                (unit_id,)).fetchone()["n"]

    # -- 1. completion without any claim ------------------------------------
    u = plan("05.12", "t1-unclaimed")
    err = None
    try:
        c.complete_attempt(u, "w-nobody", 1, "script", b"x", None, 10)
    except Exception as e:  # noqa: BLE001
        err = e
    rec.check("unclaimed completion refused",
              isinstance(err, (UnauthorizedTransition, StaleFencing, CoordinatorError)),
              f"{type(err).__name__}: {err}")
    rec.check("unclaimed completion: unit unchanged, no attempt",
              c.get_unit(u)["state"] == "READY" and audit_count(u) >= 0
              and raw().execute("SELECT count(*) AS n FROM action_attempts WHERE unit_id=%s",
                                (u,)).fetchone()["n"] == 0,
              f"state={c.get_unit(u)['state']}")

    # -- 2. stale fencing token ---------------------------------------------
    u2 = plan("05.12", "t1-stale")
    claim = c.claim(u2, "w1", None)
    c.event(u2, "start")
    err = None
    try:
        c.complete_attempt(u2, "w1", claim["fencing_token"] + 9, "script", b"x", None, 10)
    except Exception as e:  # noqa: BLE001
        err = e
    rec.check("stale fencing token refused on completion",
              isinstance(err, StaleFencing), f"{type(err).__name__}: {err}")
    rec.check("stale fencing: unit still RUNNING, no artifact registered",
              c.get_unit(u2)["state"] == "RUNNING"
              and raw().execute("SELECT count(*) AS n FROM artifacts WHERE produced_by_unit=%s",
                                (u2,)).fetchone()["n"] == 0,
              f"state={c.get_unit(u2)['state']}")
    # correct fencing still works afterwards (refusal did not corrupt state)
    art = c.complete_attempt(u2, "w1", claim["fencing_token"], "script",
                             envelope(pid, "05.12", "script"), None, 90)
    rec.check("legitimate completion succeeds after stale refusal",
              c.get_unit(u2)["state"] == "VALIDATING" and bool(art.get("artifact_id")),
              f"state={c.get_unit(u2)['state']}")

    # -- 3. completion by a worker that does not hold the claim -------------
    u3 = plan("05.12", "t1-foreign")
    claim3 = c.claim(u3, "w-owner", None)
    c.event(u3, "start")
    err = None
    try:
        c.complete_attempt(u3, "w-intruder", claim3["fencing_token"], "script",
                           b"x", None, 10)
    except Exception as e:  # noqa: BLE001
        err = e
    rec.check("completion by non-claiming worker refused (GB-SEC-01)",
              isinstance(err, StaleFencing), f"{type(err).__name__}: {err}")
    rec.check("foreign completion: unit still RUNNING, nothing settled",
              c.get_unit(u3)["state"] == "RUNNING"
              and c.budget_position(pid)["held_cents"] >= 100,
              f"state={c.get_unit(u3)['state']}")

    # -- 4. callback for a job that was never submitted ----------------------
    err = None
    try:
        c.handle_callback("gateh-no-such-key", "media", b"x", "local://x", 10)
    except Exception as e:  # noqa: BLE001
        err = e
    rec.check("callback for never-submitted job refused",
              isinstance(err, CoordinatorError), f"{type(err).__name__}: {err}")
    rec.check("phantom callback created no job/artifact/evidence rows",
              raw().execute("SELECT count(*) AS n FROM provider_jobs WHERE idempotency_key='gateh-no-such-key'").fetchone()["n"] == 0)

    # -- 5. directly registered artifact cannot substitute for a unit output -
    canon = c.register_artifact(pid, "canon_manifest", b'{"canon": "t1"}',
                                "fixture://canon-t1")
    upstream = plan("05.12", "t1-upstream", inputs=(canon["artifact_id"],))
    substitute = c.register_artifact(pid, "script", b'{"planted": true}',
                                     "fixture://planted-script")
    downstream = plan("06.12", "t1-downstream", deps=(upstream,),
                      inputs=(substitute["artifact_id"],))
    rec.check("downstream unit NOT ready while its producing unit is unaccepted",
              c.get_unit(downstream)["state"] != "READY",
              f"state={c.get_unit(downstream)['state']}")
    err = None
    try:
        c.claim(downstream, "w1", None)
    except Exception as e:  # noqa: BLE001
        err = e
    rec.check("claim of dependency-blocked unit refused despite a same-type "
              "artifact existing in the registry",
              isinstance(err, (UnauthorizedTransition, CoordinatorError)),
              f"{type(err).__name__}: {err}")
    # the genuine path: complete + validate the upstream unit
    drive_unit_to_validating(c, upstream, "script", envelope(pid, "05.12", "script"))
    state = c.validate(upstream, [{"validator": "schema_validation",
                                   "method": "contract", "verdict": "PASS",
                                   "evaluator": "harness-t01",
                                   "evidence": {"deterministic": True}}])
    if state == "AWAITING_HUMAN":
        state = c.event(upstream, "human_approved")
    rec.check("upstream unit accepted through the validated path",
              state == "ACCEPTED", f"state={state}")
    rec.check("downstream becomes ready only after the producing unit accepted",
              c.get_unit(downstream)["state"] == "READY",
              f"state={c.get_unit(downstream)['state']}")

    # -- 6. gate decision by a non-OPERATOR role (API) -----------------------
    proc = start_api(DB, API_PORT, log_name="api_t01.log")
    try:
        api = Api(API_PORT)
        st, prod = api.call("POST", "/productions",
                            {"title": "T1 api", "hard_ceiling_cents": 100000},
                            role="OPERATOR", identity="harness-t01")
        pid2 = prod["production_id"]
        st, r = api.call("POST", f"/productions/{pid2}/runs", {"kind": "FULL"},
                         role="OPERATOR", identity="harness-t01")
        st, u_resp = api.call("POST", f"/productions/{pid2}/units",
                              {"operation_id": "05.12", "run_id": r["run_id"]},
                              role="OPERATOR", identity="harness-t01")
        uid2 = u_resp["unit_id"]
        st, art_resp = api.call("POST", f"/productions/{pid2}/artifacts",
                                {"artifact_type": "script", "content": "{}",
                                 "storage_uri": "fixture://t1-api-script"},
                                role="OPERATOR", identity="harness-t01")
        st, gate = api.call("POST", f"/productions/{pid2}/gates",
                            {"gate_kind": "HG2", "artifact_id": art_resp["artifact_id"]},
                            role="OPERATOR", identity="harness-t01")
        gid = gate["gate_id"]
        st_w, _ = api.call("POST", f"/gates/{gid}/decide",
                           {"decision": "APPROVED"}, role="WORKER",
                           identity="harness-t01")
        st_none, _ = api.call("POST", f"/gates/{gid}/decide",
                              {"decision": "APPROVED"}, token=None)
        st_v, _ = api.call("POST", f"/gates/{gid}/decide",
                           {"decision": "APPROVED"}, role="VALIDATOR",
                           identity="harness-t01")
        with raw() as conn:
            verdict = conn.execute("SELECT verdict FROM human_gates WHERE gate_id=%s",
                                   (gid,)).fetchone()["verdict"]
        rec.check("gate decide as WORKER refused (403)", st_w == 403, f"status={st_w}")
        rec.check("gate decide as VALIDATOR refused (403)", st_v == 403, f"status={st_v}")
        rec.check("gate decide without credentials refused (401)", st_none == 401,
                  f"status={st_none}")
        rec.check("gate still PENDING after refused decisions", verdict == "PENDING",
                  f"verdict={verdict}")
    finally:
        stop_proc(proc)
    c.close()
    rec.write()


if __name__ == "__main__":
    main()
