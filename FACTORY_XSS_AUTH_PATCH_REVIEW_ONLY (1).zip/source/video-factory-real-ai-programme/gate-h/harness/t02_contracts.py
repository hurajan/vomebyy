"""T2 — Contract preservation (LOCK_GATE_H §T2).

Registry validate + hash, gate_requirements exact set, a 1.0.0-pinned
production unaffected while a 1.1.0 variant registry loads in the same DB,
and the audited TRANSITIONS count (30).
"""
import hashlib
import json
import shutil
import subprocess
import sys

sys.path.insert(0, str(__file__).rsplit("/harness/", 1)[0] + "/harness")
from common import *  # noqa: E402,F403

EXPECTED_GATES = {"script": "HG2", "master_package": "HG4",
                  "derivative_package": "HG5"}
EXPECTED_HASH = "ea4503f516fc4f7940f187f5cd9dac38c57f0d239726cac90e2d0a18a8bc9d73"


def main():
    rec = Recorder("T2", "Contract preservation")
    build_db()
    tool = G1 / "tools" / "registry_tool.py"

    # -- registry validate (seed-level, the tool's own verdict) --------------
    log = LOGS / "t02_registry_validate.log"
    with open(log, "w") as fh:
        r = subprocess.run([G2_PY, str(tool), "validate"],
                           stdout=fh, stderr=subprocess.STDOUT, text=True)
    try:
        report = json.loads(log.read_text())
    except json.JSONDecodeError:
        report = {}
    rec.check("registry validate verdict PASS", r.returncode == 0
              and report.get("verdict") == "PASS",
              f"rc={r.returncode} verdict={report.get('verdict')} "
              f"errors={report.get('errors')}")
    rec.check("validate reports 192 operations / 191 dependencies / 16 steps",
              report.get("operations") == 192 and report.get("dependencies") == 191
              and report.get("steps") == 16,
              f"ops={report.get('operations')} deps={report.get('dependencies')} "
              f"steps={report.get('steps')}")
    rec.check("validate definition_hash is the pinned ea4503f5...",
              report.get("definition_hash") == EXPECTED_HASH,
              f"hash={report.get('definition_hash')}")

    with raw() as conn:
        ops = conn.execute(
            "SELECT count(*) AS n FROM operation_definitions"
            " WHERE workflow_version='1.0.0'").fetchone()["n"]
        deps = conn.execute(
            "SELECT count(*) AS n FROM dependency_templates"
            " WHERE workflow_version='1.0.0'").fetchone()["n"]
        wv = conn.execute(
            "SELECT definition_hash FROM workflow_versions"
            " WHERE workflow_version='1.0.0'").fetchone()
        gates = {row["artifact_type"]: row["gate_kind"] for row in conn.execute(
            "SELECT artifact_type, gate_kind FROM gate_requirements").fetchall()}
    rec.check("DB holds 192 operation definitions (1.0.0)", ops == 192, f"ops={ops}")
    rec.check("DB holds 191 dependency templates (1.0.0)", deps == 191, f"deps={deps}")
    rec.check("DB definition_hash intact",
              bool(wv) and wv["definition_hash"] == EXPECTED_HASH,
              f"hash={wv['definition_hash'] if wv else None}")
    rec.check("gate_requirements exactly {script:HG2, master_package:HG4, "
              "derivative_package:HG5}", gates == EXPECTED_GATES, f"gates={gates}")

    # -- TRANSITIONS audited count -------------------------------------------
    sys.path.insert(0, str(G2))
    from coordinator.coordinator import TRANSITIONS
    rec.check("TRANSITIONS has exactly 30 entries", len(TRANSITIONS) == 30,
              f"count={len(TRANSITIONS)}")
    rec.check("Gate F entries present ((RETRY_WAIT, block), "
              "(AWAITING_PROVIDER, transient_error))",
              TRANSITIONS.get(("RETRY_WAIT", "block")) == "BLOCKED"
              and TRANSITIONS.get(("AWAITING_PROVIDER", "transient_error")) == "RETRY_WAIT")
    rec.data["transitions"] = sorted(f"{a}|{b}->{c}" for (a, b), c in TRANSITIONS.items())

    # -- 1.1.0 variant loads alongside; 1.0.0 production unaffected ----------
    from coordinator.coordinator import Coordinator
    c = Coordinator(DSN, actor="harness-t02")
    pid = c.create_production("T2 pinned", 100_000, 90_000, "harness-t02")
    run = c.start_run(pid, "FULL", "harness-t02")

    seed_dir_src = G1 / "seed-definitions" / "workflow-1.0.0"
    variant_dir = GATE_H / "evidence" / "variant-seed"
    if variant_dir.exists():
        shutil.rmtree(variant_dir)
    shutil.copytree(seed_dir_src, variant_dir)
    vops_path = variant_dir / "operations.json"
    vseed = json.loads(vops_path.read_text())
    vseed["workflow_version"] = "1.1.0"
    for op in vseed["operations"]:  # the seed carries the version per operation
        op["workflow_version"] = "1.1.0"
    stripped = {k: v for k, v in vseed.items() if k != "definition_hash"}
    canonical = json.dumps(stripped, ensure_ascii=False, sort_keys=True,
                           separators=(",", ":"))
    vseed["definition_hash"] = hashlib.sha256(canonical.encode("utf-8")).hexdigest()
    vops_path.write_text(json.dumps(vseed, ensure_ascii=False, indent=1))
    rec.data["variant_definition_hash"] = vseed["definition_hash"]

    sys.path.insert(0, str(G1 / "tools"))
    import registry_tool
    sql = registry_tool.build_load_sql(str(variant_dir))
    sql_path = GATE_H / "evidence" / "variant_load.sql"
    sql_path.write_text(sql)
    try:
        registry_tool.psql(DB, sql_file=str(sql_path))
        loaded = True
        load_err = ""
    except Exception as e:  # noqa: BLE001
        loaded, load_err = False, str(e)[:400]
    rec.check("1.1.0 variant registry loads into the same DB", loaded, load_err)
    with raw() as conn:
        vcount = conn.execute(
            "SELECT count(*) AS n FROM operation_definitions"
            " WHERE workflow_version='1.1.0'").fetchone()["n"]
        vdeps = conn.execute(
            "SELECT count(*) AS n FROM dependency_templates"
            " WHERE workflow_version='1.1.0'").fetchone()["n"]
        ocount = conn.execute(
            "SELECT count(*) AS n FROM operation_definitions"
            " WHERE workflow_version='1.0.0'").fetchone()["n"]
        prod = conn.execute("SELECT workflow_version FROM productions"
                            " WHERE production_id=%s", (pid,)).fetchone()
        h1 = conn.execute("SELECT definition_hash FROM workflow_versions"
                          " WHERE workflow_version='1.0.0'").fetchone()["definition_hash"]
    rec.check("variant carries its own 192 definitions + 191 templates "
              "under 1.1.0 (FP-01)", vcount == 192 and vdeps == 191,
              f"variant ops={vcount} deps={vdeps}")
    rec.check("1.0.0 definitions untouched by the variant load", ocount == 192,
              f"1.0.0 ops={ocount}")
    rec.check("production remains pinned to 1.0.0",
              prod["workflow_version"] == "1.0.0", f"version={prod['workflow_version']}")
    rec.check("1.0.0 definition_hash unchanged by the variant load",
              h1 == EXPECTED_HASH, f"hash={h1}")
    unit = c.plan_unit(pid, run, "05.12", unit_key="t2-pin", lane="text")
    with raw() as conn:
        urow = conn.execute("SELECT workflow_version_ref FROM execution_units"
                            " WHERE unit_id=%s", (unit,)).fetchone()
    rec.check("unit planned on the pinned production binds 1.0.0 definitions",
              urow["workflow_version_ref"] == "1.0.0",
              f"ref={urow['workflow_version_ref']}")
    c.close()
    rec.write()


if __name__ == "__main__":
    main()
