"""T6 — Async + recovery (LOCK_GATE_H §T6).

Part A: a provider job submitted through the worker-service async path
(local stub provider) whose submission outcome is hidden from the
coordinator (provider_timeout) lands UNKNOWN; the Gate F reconciler
service resolves it to VALIDATING, settling exactly once.

Part B: the full runtime stack (API + worker service + evaluation service
+ Gate F runner) is killed mid-production on the Station-3 chain and
restarted; the production still completes, with zero duplicate charges
and zero duplicate CURRENT artifacts.
"""
import json
import sys
import tempfile
import threading
import time
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

sys.path.insert(0, str(__file__).rsplit("/harness/", 1)[0] + "/harness")
from common import *  # noqa: E402,F403
from coordinator.coordinator import Coordinator  # noqa: E402
from storage_service import LocalStorage  # noqa: E402

STUB_PORT = 8891
WORKER_PORT = 8795
CRED_ENV = "GATEH_STUB_CREDENTIAL"


# --------------------------------------------------------------------------
# Part A stub provider: accepts async submissions, completes on poll.
# --------------------------------------------------------------------------
class StubHandler(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _send(self, code, obj):
        body = json.dumps(obj).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_POST(self):
        n = int(self.headers.get("Content-Length") or 0)
        self.rfile.read(n)
        if self.path == "/submit":
            return self._send(200, {"job_id": "stub-unk-1"})
        return self._send(404, {"error": "no route"})

    def do_GET(self):
        if self.path.startswith("/poll/"):
            return self._send(200, {
                "status": "COMPLETED", "content": "reconciled media bytes",
                "cost_cents": 450, "usage": {},
                "provider_request_id": "stub-req-1"})
        return self._send(404, {"error": "no route"})


def http_json(method, url, body=None):
    req = urllib.request.Request(url, method=method)
    data = None
    if body is not None:
        data = json.dumps(body).encode()
        req.add_header("Content-Type", "application/json")
    try:
        with urllib.request.urlopen(req, data=data, timeout=15) as r:
            return r.status, json.loads(r.read() or b"{}")
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read() or b"{}")


def part_a(rec):
    build_db()
    store = LocalStorage(tempfile.mkdtemp(prefix="gateh-t6-store-"))
    stub = ThreadingHTTPServer(("127.0.0.1", STUB_PORT), StubHandler)
    threading.Thread(target=stub.serve_forever, daemon=True).start()
    import os
    os.environ[CRED_ENV] = "stub-credential-value"
    worker = start_worker_service(
        WORKER_PORT, DSN, log_name="worker_t06.log",
        env_extra={CRED_ENV: "stub-credential-value", "WORKER_ENVIRONMENT": "test"})
    try:
        c = Coordinator(DSN, actor="harness-t06", storage=store)
        with raw() as conn:
            add_config(conn, "OPERATION", provider="direct-http-text", est=5000,
                       operation_id="11.06", credential_ref=CRED_ENV,
                       params={"endpoint": f"http://127.0.0.1:{STUB_PORT}/submit",
                               "poll_endpoint": f"http://127.0.0.1:{STUB_PORT}/poll/{{job_id}}",
                               "mode": "async"},
                       created_by="gateh-t06")
        pid = c.create_production("T6 async", 1_000_000, 900_000, "harness-t06")
        run = c.start_run(pid, "FULL", "harness-t06")
        u = c.plan_unit(pid, run, "11.06", unit_key="t6-async", lane="video")
        claim = c.claim(u, "w-t06", None)
        c.event(u, "start")
        job = c.submit_provider_job_v2(u, claim["attempt_id"],
                                       claim["fencing_token"], "t6-async-job")
        # the worker service performs the provider submission against the stub
        with raw() as conn:
            attempt = conn.execute(
                "SELECT resolved_config FROM action_attempts WHERE attempt_id=%s",
                (claim["attempt_id"],)).fetchone()
        st, submitted = http_json("POST", f"http://127.0.0.1:{WORKER_PORT}/jobs", {
            "unit_id": u, "attempt_id": claim["attempt_id"],
            "fencing_token": claim["fencing_token"], "operation_id": "11.06",
            "production_id": pid,
            "provider_binding": attempt["resolved_config"],
            "input_artifact_refs": []})
        rec.check("worker service submits the job to the stub provider (202)",
                  st == 202 and submitted.get("provider_job_id") == "stub-unk-1",
                  f"status={st} out={str(submitted)[:200]}")
        c.attach_provider_job_id(job, submitted["provider_job_id"])

        # submission outcome hidden from the coordinator -> UNKNOWN
        c.provider_timeout(u, job)
        rec.check("hidden submission outcome lands the unit + job UNKNOWN",
                  c.get_unit(u)["state"] == "UNKNOWN"
                  and c.get_provider_job(job)["status"] == "UNKNOWN",
                  f"unit={c.get_unit(u)['state']} job={c.get_provider_job(job)['status']}")

        # the reconciler service resolves it through the worker-service seam
        # (separate process: the runtime services import the coordinator as
        # a top-level module — their own convention, and how they run in
        # production under the Gate F runner)
        probe = subprocess.run(
            [G2_PY, str(Path(__file__).parent / "t06_reconciler_probe.py"),
             DSN, str(WORKER_PORT), str(store.root)],
            capture_output=True, text=True, timeout=120)
        (LOGS / "t06_reconciler_probe.log").write_text(
            probe.stdout + "\n" + probe.stderr)
        try:
            report = json.loads(probe.stdout.strip().splitlines()[-1])
        except Exception:  # noqa: BLE001
            report = {}
        rec.check("reconciler resolves the UNKNOWN job (completed=1)",
                  report.get("completed") == 1,
                  f"report={report} rc={probe.returncode}")
        rec.check("unit lands VALIDATING after reconciliation",
                  c.get_unit(u)["state"] == "VALIDATING",
                  f"state={c.get_unit(u)['state']}")
        state = c.validate(u, [{"validator": "schema_validation",
                                "method": "contract", "verdict": "PASS",
                                "evaluator": "harness-t06",
                                "evidence": {"deterministic": True}}])
        if state == "AWAITING_HUMAN":
            state = c.event(u, "human_approved")
        pos = c.budget_position(pid)
        with raw() as conn:
            charges = conn.execute(
                "SELECT count(*) AS n FROM budget_transactions"
                " WHERE production_id=%s AND kind='CHARGE'", (pid,)).fetchone()["n"]
            arts = conn.execute(
                "SELECT count(*) AS n FROM artifacts WHERE produced_by_unit=%s",
                (u,)).fetchone()["n"]
        rec.check("reconciled production settles exactly once (450) with one artifact",
                  state == "ACCEPTED" and pos["settled_cents"] == 450
                  and charges == 1 and arts == 1,
                  f"state={state} settled={pos['settled_cents']} charges={charges} arts={arts}")
        rec.data.setdefault("executed_operations", []).append("11.06")
        c.close()
    finally:
        stop_proc(worker)
        stub.shutdown()


# --------------------------------------------------------------------------
# Part B: kill + restart the full stack mid-production.
# --------------------------------------------------------------------------
def part_b(rec):
    run_g5_setup(log_name="g5_setup_t06.log")
    api = g5_api()
    pid, run_id, canon_id, units = plan_station3(api, "T6 kill/restart production")
    sys.path.insert(0, str(G5 / "driver"))
    import importlib
    import dispatch as g5_driver
    importlib.reload(g5_driver)
    if g5_driver.STATE.exists():
        g5_driver.STATE.unlink()

    def drive(seconds):
        end = time.time() + seconds
        while time.time() < end:
            try:
                g5_driver.run_once(pid, inputs_by_unit={units["05.12"]: [canon_id]})
            except Exception:
                pass  # API may be down mid-kill; the loop is the harness driver
            time.sleep(1)

    # Phase 1: drive until the production is genuinely mid-flight.
    mid = {}

    def mid_flight():
        states = unit_states(api, pid)
        mid.update(states)
        accepted = [u for u, s in states.items() if s == "ACCEPTED"]
        inflight = [u for u, s in states.items()
                    if s in ("CLAIMED", "RUNNING", "VALIDATING", "AWAITING_HUMAN",
                             "AWAITING_PROVIDER")]
        return len(accepted) >= 1 and len(inflight) >= 1

    deadline = time.time() + 600
    while time.time() < deadline and not mid_flight():
        drive(3)
    rec.check("production reached a mid-flight state (>=1 ACCEPTED, >=1 in-flight)",
              bool(mid) and any(s == "ACCEPTED" for s in mid.values())
              and any(s in ("CLAIMED", "RUNNING", "VALIDATING", "AWAITING_HUMAN",
                            "AWAITING_PROVIDER") for s in mid.values()),
              f"states={mid}")
    # Bring the Gate F runner into the running stack mid-production (it is
    # part of the stack that gets killed; starting it here keeps this item
    # about kill/restart recovery — the scheduler-claims composition is
    # T9's subject).
    runner = start_runner(G5_DSN, "http://127.0.0.1:5678/webhook/dispatch-g5",
                          log_name="runner_t06.log")
    time.sleep(15)
    mid = unit_states(api, pid)
    rec.data["states_at_kill"] = {k: v for k, v in mid.items()}

    # KILL: API + worker + evaluation + runner (n8n is not in the lock's list).
    kill_port(8730)
    kill_port(8795)
    kill_port(8796)
    stop_proc(runner)
    time.sleep(3)
    down = not wait_http("http://127.0.0.1:8730/health", timeout=4)
    rec.check("stack is down after the kill (API unreachable)", down)

    # RESTART on the same DB; resume driving to completion.
    api_proc, worker_proc, eval_proc = restart_g5_services(log_prefix="t06")
    runner2 = start_runner(G5_DSN, "http://127.0.0.1:5678/webhook/dispatch-g5",
                           log_name="runner_t06_restarted.log")
    try:
        deadline = time.time() + 1800
        states = {}
        while time.time() < deadline:
            drive(5)
            states = unit_states(api, pid)
            if all(s == "ACCEPTED" for s in states.values()) and len(states) == 4:
                break
        rec.check("production completes after the restart (all 4 units ACCEPTED)",
                  len(states) == 4 and all(s == "ACCEPTED" for s in states.values()),
                  f"states={states}")
        if len(states) == 4 and all(s == "ACCEPTED" for s in states.values()):
            rec.data.setdefault("executed_operations", []).extend(
                ["05.12", "06.12", "07.12", "08.12"])
        # HG2 gate: created by the station flow on the script; harness decides.
        st, gates = api.call("GET", f"/productions/{pid}/gates", role="OPERATOR",
                             identity="harness-t06")
        hg2 = [g for g in gates["gates"] if g["gate_kind"] == "HG2"]
        if hg2 and hg2[0]["verdict"] == "PENDING":
            api.call("POST", f"/gates/{hg2[0]['gate_id']}/decide",
                     {"decision": "APPROVED"}, role="OPERATOR",
                     identity="harness-t06")
            st, gates = api.call("GET", f"/productions/{pid}/gates",
                                 role="OPERATOR", identity="harness-t06")
            hg2 = [g for g in gates["gates"] if g["gate_kind"] == "HG2"]
        rec.check("HG2 gate exists and is APPROVED after the restart",
                  bool(hg2) and hg2[0]["verdict"] == "APPROVED",
                  f"gates={gates['gates'] if gates else None}")
        with raw(make_dsn(G5_DB)) as conn:
            charges = conn.execute(
                "SELECT count(*) AS n FROM budget_transactions"
                " WHERE production_id=%s AND kind='CHARGE'", (pid,)).fetchone()["n"]
            settled = conn.execute(
                "SELECT COALESCE(SUM(amount_cents),0) AS s FROM budget_transactions"
                " WHERE production_id=%s AND kind='CHARGE'", (pid,)).fetchone()["s"]
            currents = conn.execute(
                "SELECT artifact_type, count(*) AS n FROM artifacts"
                " WHERE production_id=%s AND state='CURRENT'"
                " GROUP BY artifact_type", (pid,)).fetchall()
        dup_currents = [r for r in currents if r["n"] > 1]
        rec.check("no duplicate charges after kill/restart (4 charges, 360 settled)",
                  charges == 4 and settled == 360,
                  f"charges={charges} settled={settled}")
        rec.check("no duplicate CURRENT artifacts after kill/restart",
                  not dup_currents,
                  f"currents={[(r['artifact_type'], r['n']) for r in currents]}")
    finally:
        stop_proc(runner2)
        stop_proc(eval_proc)
        stop_proc(worker_proc)
        stop_proc(api_proc)


def main():
    rec = Recorder("T6", "Async + recovery")
    part_a(rec)
    part_b(rec)
    rec.write()


if __name__ == "__main__":
    main()
