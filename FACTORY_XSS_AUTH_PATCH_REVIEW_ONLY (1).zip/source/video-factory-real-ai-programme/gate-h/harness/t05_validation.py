"""T5 — Validation independence (LOCK_GATE_H §T5).

The Gate E evaluation service's layer verdicts decide; a worker verdict is
advisory data only:
  1. worker PASS advisory + schema-invalid deliverable -> BLOCKED.
  2. worker FAIL advisory + layer-valid output -> layers decide (the unit
     is NOT blocked by the advisory; it reaches the human-approval state).
  3. a unit with no worker verdict at all still evaluates.

Fixtures mirror the evaluation service's own integration tests: the
advisory channel is a quality_evaluations row (validator_id 'worker_self')
recorded against the produced artifact before /evaluate is called.
"""
import json
import sys
import tempfile
import urllib.request

sys.path.insert(0, str(__file__).rsplit("/harness/", 1)[0] + "/harness")
from common import *  # noqa: E402,F403
from coordinator.coordinator import Coordinator  # noqa: E402
from storage_service import LocalStorage  # noqa: E402

API_PORT, EVAL_PORT, WORKER_PORT = 8743, 8799, 8798


def evaluate(unit_id):
    req = urllib.request.Request(f"http://127.0.0.1:{EVAL_PORT}/evaluate",
                                 method="POST",
                                 data=json.dumps({"unit_id": unit_id}).encode())
    req.add_header("Content-Type", "application/json")
    with urllib.request.urlopen(req, timeout=30) as r:
        return json.loads(r.read() or b"{}")


def advisory(artifact_id, verdict):
    with raw() as conn:
        conn.execute(
            "INSERT INTO quality_evaluations(artifact_id, validator_id, method,"
            " evidence, verdict, evaluator_identity) VALUES (%s,'worker_self',"
            " 'worker_self_assessment', %s, %s, 'worker-service')",
            (artifact_id, json.dumps({"deterministic": False, "advisory": True}),
             verdict))


def evaluations_of(unit_id):
    with raw() as conn:
        return conn.execute(
            "SELECT qe.validator_id, qe.verdict FROM quality_evaluations qe"
            " JOIN artifacts a ON a.artifact_id=qe.artifact_id"
            " WHERE a.produced_by_unit=%s ORDER BY qe.created_at",
            (unit_id,)).fetchall()


def main():
    rec = Recorder("T5", "Validation independence")
    build_db()
    store_root = tempfile.mkdtemp(prefix="gateh-t5-store-")
    store = LocalStorage(store_root)
    c = Coordinator(DSN, actor="harness-t05", storage=store)
    with raw() as conn:
        add_config(conn, "OPERATION", provider="deterministic-local", est=100,
                   operation_id="05.12", params={"reported_actual_cents": 90},
                   created_by="gateh-t05")
    pid = c.create_production("T5 validation", 1_000_000, 900_000, "harness-t05")
    run = c.start_run(pid, "FULL", "harness-t05")
    canon = c.register_artifact(pid, "canon_manifest", b'{"canon": "t5"}',
                                "fixture://canon-t5")

    api_proc = start_api(DB, API_PORT, env_extra={"FACTORY_STORAGE_ROOT": store_root},
                         log_name="api_t05.log")
    eval_proc = start_eval_service(EVAL_PORT, DSN, f"http://127.0.0.1:{API_PORT}",
                                   log_name="eval_t05.log",
                                   env_extra={"FACTORY_STORAGE_ROOT": store_root})
    try:
        def make_unit(key, content, advisory_verdict=None):
            u = c.plan_unit(pid, run, "05.12", unit_key=key, lane="text",
                            input_artifact_ids=(canon["artifact_id"],))
            claim = c.claim(u, "w-t05", None)
            c.event(u, "start")
            art = c.complete_attempt(u, "w-t05", claim["fencing_token"], "script",
                                     content, None, 90)
            if advisory_verdict:
                advisory(art["artifact_id"], advisory_verdict)
            return u

        # -- 1. worker PASS advisory + schema-invalid deliverable ------------
        bad = envelope(pid, "05.12", "script",
                       content={"kind": "story_architecture"})  # no story_nodes
        u1 = make_unit("t5-pass-invalid", bad, advisory_verdict="PASS")
        out1 = evaluate(u1)
        evs1 = evaluations_of(u1)
        rec.check("advisory PASS does not rescue a schema-invalid deliverable: "
                  "unit BLOCKED",
                  c.get_unit(u1)["state"] == "BLOCKED",
                  f"state={c.get_unit(u1)['state']} eval_out={str(out1)[:200]}")
        rec.check("the BLOCK came from a deterministic layer FAIL, not the advisory",
                  any(e["verdict"] == "FAIL" and e["validator_id"] != "worker_self"
                      for e in evs1)
                  and any(e["validator_id"] == "worker_self" and e["verdict"] == "PASS"
                          for e in evs1),
                  f"evaluations={[(e['validator_id'], e['verdict']) for e in evs1]}")

        # -- 2. worker FAIL advisory + layer-valid output ---------------------
        # layer-valid: the deliverable declares the planned canon input in
        # canon_refs, as the continuity layer requires.
        valid = envelope(pid, "05.12", "script", content={
            "kind": "story_architecture",
            "story_nodes": [{"id": "S1", "summary": "Story node S1"}],
            "canon_refs": [canon["artifact_id"]]})
        u2 = make_unit("t5-fail-valid", valid, advisory_verdict="FAIL")
        out2 = evaluate(u2)
        state2 = c.get_unit(u2)["state"]
        evs2 = evaluations_of(u2)
        rec.check("advisory FAIL does not block a layer-valid output: layers "
                  "decide and the unit reaches AWAITING_HUMAN",
                  state2 == "AWAITING_HUMAN",
                  f"state={state2} eval_out={str(out2)[:200]} "
                  f"evaluations={[(e['validator_id'], e['verdict']) for e in evs2]}")
        rec.check("no layer FAIL was recorded against the valid output",
                  not any(e["verdict"] == "FAIL" and e["validator_id"] != "worker_self"
                          for e in evs2),
                  f"evaluations={[(e['validator_id'], e['verdict']) for e in evs2]}")

        # -- 3. no worker verdict at all ---------------------------------------
        u3 = make_unit("t5-no-verdict", valid)
        out3 = evaluate(u3)
        state3 = c.get_unit(u3)["state"]
        evs3 = evaluations_of(u3)
        rec.check("unit with no worker verdict still evaluates to the same "
                  "layer-decided state",
                  state3 == "AWAITING_HUMAN" and len(evs3) >= 1
                  and not any(e["validator_id"] == "worker_self" for e in evs3),
                  f"state={state3} evaluations={[(e['validator_id'], e['verdict']) for e in evs3]}")
    finally:
        stop_proc(eval_proc)
        stop_proc(api_proc)
    c.close()
    rec.write()


if __name__ == "__main__":
    main()
