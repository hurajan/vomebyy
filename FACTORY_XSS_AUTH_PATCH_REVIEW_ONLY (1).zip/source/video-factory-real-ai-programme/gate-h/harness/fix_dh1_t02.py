"""Master Execution Programme Gate 02 mandatory tests T02-A..G at the
API/coordinator level (T02-H is the unattended run in fix_dh1_t09.py;
T02-E needs the n8n stack and lives in the same file, section E).

A: scheduler claim -> executor adopt succeeds (credentials issued only
   to the identity-matched worker; attempts read exposes no fencing).
B: two CONCURRENT adopts (different keys) -> exactly one adoption +
   one refusal; winner-key replay idempotent; one execution/settlement.
C: wrong worker identity -> refusal (adopt_refused evidence), and the
   refusal consumes nothing — the rightful executor still adopts.
D: stale fencing / superseded attempt -> refusal.
F: crash between claim and adoption -> lease expiry -> reaper ->
   RETRY_WAIT -> retry -> re-claim -> adopt succeeds (task 10).
G: crash AFTER adoption -> lease expiry path -> recoverable, attempt 1
   closed FAILED, no second RUNNING attempt, exactly one settlement.

Runs its own API instance on port 8731 against g02_adopt_scratch.
Results: gate-h/evidence/results/fix-dh1/t02{a,b,c,d,f,g}.json
"""
import json
import os
import sys
import threading
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
GATEH = HERE.parent
sys.path.insert(0, str(GATEH.parent.parent / "video-factory-g3" / "tests"))
sys.path.insert(0, str(GATEH.parent.parent / "video-factory-g2"))

from server_fixture import start_server, stop_server, make_dsn  # noqa: E402
import psycopg  # noqa: E402
from psycopg.rows import dict_row  # noqa: E402
from coordinator.coordinator import Coordinator  # noqa: E402

DB = "g02_adopt_scratch"
PORT = 8731
DSN = make_dsn(DB)
RESULTS = GATEH / "evidence" / "results" / "fix-dh1"
WORKER_HDR = {"X-Role": "WORKER", "X-Role-Token": "test-worker-token"}
ENV = {"FACTORY_WORKER_TOKEN": "test-worker-token",
       "FACTORY_SCHEDULER_TOKEN": "test-scheduler-token",
       "FACTORY_VALIDATOR_TOKEN": "test-validator-token",
       "FACTORY_CALLBACK_TOKEN": "test-callback-token"}
G5 = "n8n-executor-g5"


def raw(sql, params=()):
    with psycopg.connect(DSN, row_factory=dict_row, autocommit=True) as conn:
        cur = conn.execute(sql, params)
        return cur.fetchall() if cur.description else []


def write(name, payload):
    RESULTS.mkdir(parents=True, exist_ok=True)
    (RESULTS / name).write_text(json.dumps(payload, indent=1, default=str))
    print(name, "->", payload["verdict"])


class Fixture:
    def __init__(self, api):
        self.api = api
        self.sched = Coordinator(DSN, actor="scheduler-service")
        _, out = api.call("POST", "/productions",
                          {"title": "Gate 02 T02", "hard_ceiling_cents": 1000000,
                           "soft_ceiling_cents": 900000})
        self.pid = out["production_id"]
        _, out = api.call("POST", f"/productions/{self.pid}/runs",
                          {"kind": "FULL"})
        self.run = out["run_id"]
        self.coord = Coordinator(DSN, actor="t02-harness")

    def prestage(self, op="05.01", lane="text"):
        uid = self.coord.plan_unit(self.pid, self.run, op, lane=lane)
        claimed = self.sched.scheduler_claim()
        mine = [c for c in claimed if c["unit_id"] == uid]
        assert len(mine) == 1, f"scheduler did not claim {op}"
        return uid, mine[0]

    def adopt(self, uid, worker, attempt_id, key, fencing=None):
        body = {"worker_id": worker, "attempt_id": attempt_id,
                "idempotency_key": key}
        if fencing is not None:
            body["fencing_token"] = fencing
        return self.api.call("POST", f"/units/{uid}/adopt", body,
                             token=None, headers=WORKER_HDR)

    def expire_lease(self, uid):
        raw("UPDATE worker_leases SET expires_at=now() - interval '1 hour'"
            " WHERE unit_id=%s", (uid,))

    def complete_and_accept(self, uid, creds, artifact_type="research_notes"):
        s, out = self.api.call("POST", f"/units/{uid}/complete",
                               {"worker_id": creds["worker_id"],
                                "fencing_token": creds["fencing_token"],
                                "artifact_type": artifact_type,
                                "content": "t02 output",
                                "actual_cost_cents": 90},
                               token=None, headers=WORKER_HDR)
        assert s == 200, out
        s, out = self.api.call("POST", f"/units/{uid}/validate",
                               {"evaluations": [
                                   {"validator": "schema_validation",
                                    "method": "m", "verdict": "PASS",
                                    "evaluator": "evaluation-service",
                                    "evidence": {}}]})
        assert s == 200, out
        return out


def t02a(api):
    fx = Fixture(api)
    uid, claim = fx.prestage()
    s, out = fx.adopt(uid, G5, claim["attempt_id"], "t02a-1")
    _, attempts = api.call("GET", f"/units/{uid}/attempts")
    att = attempts["attempts"][0]
    adopted_events = raw("SELECT count(*) AS n FROM audit_events WHERE"
                         " unit_id=%s AND event_type='attempt_adopted'", (uid,))
    checks = {
        "adopt_status_200": s == 200,
        "fencing_matches_claim": out.get("fencing_token") == claim["fencing_token"],
        "config_hash_matches_attempt": out.get("resolved_config_hash") == att["resolved_config_hash"],
        "fresh_true": out.get("fresh") is True,
        "attempts_read_has_no_fencing": "fencing_token" not in att,
        "one_adopted_audit": adopted_events[0]["n"] == 1,
        "unit_still_claimed": fx.coord.get_unit(uid)["state"] == "CLAIMED",
    }
    write("t02a.json", {"test": "T02-A", "checks": checks,
                        "verdict": "PASS" if all(checks.values()) else "FAIL"})


def t02b(api):
    fx = Fixture(api)
    uid, claim = fx.prestage(lane="voice")
    results = {}

    def call(tag, key):
        results[tag] = fx.adopt(uid, G5, claim["attempt_id"], key)

    barrier = threading.Barrier(2)

    def run(tag, key):
        barrier.wait(timeout=10)
        call(tag, key)

    ts = [threading.Thread(target=run, args=("a", "t02b-a")),
          threading.Thread(target=run, args=("b", "t02b-b"))]
    for t in ts:
        t.start()
    for t in ts:
        t.join(timeout=30)
    statuses = sorted(v[0] for v in results.values())
    winner_key = "t02b-a" if results["a"][0] == 200 else "t02b-b"
    winner = results["a"][1] if results["a"][0] == 200 else results["b"][1]
    s3, replay = fx.adopt(uid, G5, claim["attempt_id"], winner_key)
    adopted_events = raw("SELECT count(*) AS n FROM audit_events WHERE"
                         " unit_id=%s AND event_type='attempt_adopted'", (uid,))
    fx.complete_and_accept(uid, winner)
    fin = raw("SELECT count(*) AS n FROM financial_evidence WHERE unit_id=%s"
              " AND charge_class='FINALIZED'", (uid,))
    attempts = raw("SELECT count(*) AS n FROM action_attempts WHERE unit_id=%s",
                   (uid,))
    checks = {
        "exactly_one_200_one_409": statuses == [200, 409],
        "winner_replay_idempotent": s3 == 200 and replay.get("fresh") is False,
        "one_adopted_audit": adopted_events[0]["n"] == 1,
        "one_attempt": attempts[0]["n"] == 1,
        "one_finalized_settlement": fin[0]["n"] == 1,
        "unit_accepted": fx.coord.get_unit(uid)["state"] == "ACCEPTED",
    }
    write("t02b.json", {"test": "T02-B", "checks": checks,
                        "verdict": "PASS" if all(checks.values()) else "FAIL"})


def t02c(api):
    fx = Fixture(api)
    uid, claim = fx.prestage(lane="image")
    s, _ = fx.adopt(uid, "n8n-executor-g4", claim["attempt_id"], "t02c-1")
    refused = raw("SELECT payload FROM audit_events WHERE unit_id=%s"
                  " AND event_type='adopt_refused'", (uid,))
    reasons = [r["payload"].get("reason") if isinstance(r["payload"], dict)
               else json.loads(r["payload"]).get("reason") for r in refused]
    s2, out = fx.adopt(uid, G5, claim["attempt_id"], "t02c-1")
    checks = {
        "wrong_identity_409": s == 409,
        "refusal_reason_recorded": "identity_mismatch" in reasons,
        "rightful_adopt_after_refusal": s2 == 200 and out.get("fresh") is True,
    }
    write("t02c.json", {"test": "T02-C", "checks": checks,
                        "verdict": "PASS" if all(checks.values()) else "FAIL"})


def t02d(api):
    fx = Fixture(api)
    uid, claim = fx.prestage(lane="qa")
    fx.expire_lease(uid)
    fx.sched.reap_expired_leases()
    fx.coord.retry_unit(uid)
    claimed = fx.sched.scheduler_claim()
    claim2 = [c for c in claimed if c["unit_id"] == uid][0]
    s1, _ = fx.adopt(uid, G5, claim["attempt_id"], "t02d-1",
                     fencing=claim["fencing_token"])
    s2, _ = fx.adopt(uid, G5, claim["attempt_id"], "t02d-1")
    s3, _ = fx.adopt(uid, G5, claim2["attempt_id"], "t02d-1",
                     fencing=claim["fencing_token"])
    s4, out = fx.adopt(uid, G5, claim2["attempt_id"], "t02d-1")
    checks = {
        "fencing_bumped": claim2["fencing_token"] > claim["fencing_token"],
        "superseded_with_old_fencing_refused": s1 == 409,
        "superseded_attempt_refused": s2 == 409,
        "current_attempt_old_fencing_refused": s3 == 409,
        "current_attempt_adopts": s4 == 200 and out.get("fresh") is True,
    }
    write("t02d.json", {"test": "T02-D", "checks": checks,
                        "verdict": "PASS" if all(checks.values()) else "FAIL"})


def t02f(api):
    fx = Fixture(api)
    uid, claim = fx.prestage(lane="render-cpu")
    fx.expire_lease(uid)  # crash between claim and adoption: never adopted
    fx.sched.reap_expired_leases()
    mid = fx.coord.get_unit(uid)["state"]
    fx.coord.retry_unit(uid)
    ready = fx.coord.get_unit(uid)["state"]
    claimed = fx.sched.scheduler_claim()
    claim2 = [c for c in claimed if c["unit_id"] == uid][0]
    s, out = fx.adopt(uid, G5, claim2["attempt_id"], "t02f-1")
    checks = {
        "reaped_to_retry_wait": mid == "RETRY_WAIT",
        "retry_restored_ready": ready == "READY",
        "reclaim_new_attempt": claim2["attempt_no"] == 2,
        "adopt_after_recovery": s == 200 and out.get("fresh") is True,
    }
    write("t02f.json", {"test": "T02-F", "checks": checks,
                        "verdict": "PASS" if all(checks.values()) else "FAIL"})


def t02g(api):
    fx = Fixture(api)
    uid, claim = fx.prestage(lane="render-gpu")
    s, creds = fx.adopt(uid, G5, claim["attempt_id"], "t02g-1")
    assert s == 200
    fx.expire_lease(uid)  # executor dies after adoption, before worker call
    fx.sched.reap_expired_leases()
    mid = fx.coord.get_unit(uid)["state"]
    fx.coord.retry_unit(uid)
    claimed = fx.sched.scheduler_claim()
    claim2 = [c for c in claimed if c["unit_id"] == uid][0]
    s2, creds2 = fx.adopt(uid, G5, claim2["attempt_id"], "t02g-2")
    fx.complete_and_accept(uid, creds2)
    attempts = raw("SELECT attempt_no, status FROM action_attempts"
                   " WHERE unit_id=%s ORDER BY attempt_no", (uid,))
    fin = raw("SELECT count(*) AS n FROM financial_evidence WHERE unit_id=%s"
              " AND charge_class='FINALIZED'", (uid,))
    running = raw("SELECT count(*) AS n FROM action_attempts WHERE unit_id=%s"
                  " AND status='RUNNING'", (uid,))
    checks = {
        "adopted_before_crash": s == 200,
        "reaped_to_retry_wait": mid == "RETRY_WAIT",
        "attempt1_closed_failed": attempts[0]["status"] == "FAILED",
        "exactly_two_attempts": len(attempts) == 2,
        "no_running_attempts_left": running[0]["n"] == 0,
        "second_adopt_succeeds": s2 == 200,
        "one_finalized_settlement": fin[0]["n"] == 1,
        "unit_accepted": fx.coord.get_unit(uid)["state"] == "ACCEPTED",
    }
    write("t02g.json", {"test": "T02-G", "checks": checks,
                        "verdict": "PASS" if all(checks.values()) else "FAIL"})


def main():
    proc, api = start_server(DB, PORT, env_extra=ENV)
    try:
        for fn in (t02a, t02b, t02c, t02d, t02f, t02g):
            fn(api)
    finally:
        stop_server(proc)
    print("T02 API-level battery done")


if __name__ == "__main__":
    main()
