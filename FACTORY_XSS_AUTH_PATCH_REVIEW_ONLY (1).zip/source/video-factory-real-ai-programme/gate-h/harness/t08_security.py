"""T8 — Security (LOCK_GATE_H §T8).

Negative role matrix against the API (each non-operator role attempts one
out-of-matrix endpoint -> 403; no credentials -> 401; wrong token -> 401),
workflow JSON hygiene re-grep, and a secrets sweep across the factory and
programme trees with every hit listed and classified.
"""
import re
import sys

sys.path.insert(0, str(__file__).rsplit("/harness/", 1)[0] + "/harness")
from common import *  # noqa: E402,F403

API_PORT = 8744

SECRET_PATTERNS = [
    ("openai-style key", re.compile(r"sk-[A-Za-z0-9_-]{16,}")),
    ("aws access key", re.compile(r"AKIA[0-9A-Z]{16}")),
    ("github token", re.compile(r"gh[pousr]_[A-Za-z0-9]{20,}")),
    ("slack token", re.compile(r"xox[baprs]-[A-Za-z0-9-]{10,}")),
    ("private key block", re.compile(r"-----BEGIN (RSA |EC |OPENSSH )?PRIVATE KEY-----")),
    ("bearer literal", re.compile(r"[Bb]earer\s+[A-Za-z0-9._-]{16,}")),
    ("password assignment", re.compile(r"(?i)(password|passwd|pwd)\s*[:=]\s*['\"][^'\"]{4,}['\"]")),
    ("api-key assignment", re.compile(r"(?i)(api[_-]?key|secret[_-]?key|access[_-]?token)\s*[:=]\s*['\"][^'\"]{8,}['\"]")),
]
DEV_VALUES = ("dev-operator-token", "dev-worker-token", "dev-scheduler-token",
              "dev-validator-token", "dev-callback-token", "factory_dev_local",
              "Dev-owner-password-1", "dev@local.invalid")


def classify(path):
    if "n8n-data" in Path(path).parts:
        return "vendored third-party runtime asset (n8n installation data)"
    parts = set(Path(path).parts)
    if "tests" in parts or "test" in Path(path).name:
        return "test code (documented dev values)"
    if "tools" in parts or "driver" in parts or "setup" in Path(path).name:
        return "setup/driver code (documented dev values)"
    if Path(path).suffix in (".md", ".log", ".json") and "evidence" in parts:
        return "evidence/docs"
    return "REVIEW"


def main():
    rec = Recorder("T8", "Security")
    build_db()
    proc = start_api(DB, API_PORT, log_name="api_t08.log")
    try:
        api = Api(API_PORT)
        st, prod = api.call("POST", "/productions",
                            {"title": "T8", "hard_ceiling_cents": 100000},
                            role="OPERATOR", identity="harness-t08")
        pid = prod["production_id"]
        st, r = api.call("POST", f"/productions/{pid}/runs", {"kind": "FULL"},
                         role="OPERATOR", identity="harness-t08")
        st, u_resp = api.call("POST", f"/productions/{pid}/units",
                              {"operation_id": "05.12", "run_id": r["run_id"]},
                              role="OPERATOR", identity="harness-t08")
        uid = u_resp["unit_id"]

        cases = [
            ("WORKER creates a unit", "POST", f"/productions/{pid}/units",
             {"operation_id": "06.12", "run_id": r["run_id"]}, "WORKER"),
            ("VALIDATOR claims a unit", "POST", f"/units/{uid}/claim",
             {"worker_id": "w"}, "VALIDATOR"),
            ("WORKER validates a unit", "POST", f"/units/{uid}/validate",
             {"verdict": "PASS"}, "WORKER"),
            ("SCHEDULER submits a provider job", "POST", "/provider-jobs",
             {"unit_id": uid, "attempt_id": uid, "fencing_token": 1,
              "idempotency_key": "t8"}, "SCHEDULER"),
            ("WORKER calls the provider callback", "POST",
             f"/provider-jobs/{uid}/callback", {"status": "COMPLETED"}, "WORKER"),
            ("SCHEDULER creates a config", "POST", "/configs",
             {"scope": "FACTORY", "provider": "mock"}, "SCHEDULER"),
            ("CALLBACK reads artifacts", "GET", f"/productions/{pid}/artifacts",
             None, "CALLBACK"),
            ("VALIDATOR stages an artifact", "POST", "/artifacts/stage",
             {"production_id": pid, "content_base64": "eA=="}, "VALIDATOR"),
        ]
        for name, method, path, body, role in cases:
            st, out = api.call(method, path, body, role=role, identity="harness-t08")
            rec.check(f"negative matrix: {name} -> 403", st == 403,
                      f"status={st} out={str(out)[:120]}")
        st, _ = api.call("GET", "/productions", token=None)
        rec.check("no credentials -> 401", st == 401, f"status={st}")
        st, _ = api.call("GET", "/productions", token="wrong-token-value")
        rec.check("wrong operator token -> 401", st == 401, f"status={st}")
        st, _ = api.call("GET", "/productions", role="WORKER",
                         extra_headers={"X-Role-Token": "wrong-token-value"})
        rec.check("wrong role token -> 401", st == 401, f"status={st}")
        with raw() as conn:
            units = conn.execute("SELECT count(*) AS n FROM execution_units"
                                 " WHERE production_id=%s", (pid,)).fetchone()["n"]
            jobs = conn.execute("SELECT count(*) AS n FROM provider_jobs").fetchone()["n"]
        rec.check("refused calls changed nothing (1 unit, 0 provider jobs)",
                  units == 1 and jobs == 0, f"units={units} jobs={jobs}")
    finally:
        stop_proc(proc)

    # -- workflow JSON hygiene --------------------------------------------------
    wf_files = []
    for tree in ("video-factory-g4", "video-factory-g5", "video-factory-g6",
                 "video-factory-g7", "video-factory-g8"):
        wf_files += sorted((WS / tree / "workflows").glob("*.json"))
    bad_hits = []
    for f in wf_files:
        text = f.read_text()
        for needle in ("127.0.0.1", "localhost", "dev-operator-token",
                       "dev-worker-token", "dev-scheduler-token",
                       "dev-validator-token", "dev-callback-token"):
            if needle in text:
                bad_hits.append(f"{f.name}: contains {needle!r}")
    rec.check(f"workflow hygiene: {len(wf_files)} generated workflow JSONs carry "
              "no localhost or token literals", not bad_hits, f"hits={bad_hits}")
    rec.data["workflow_files_scanned"] = [str(f) for f in wf_files]

    # -- secrets sweep ------------------------------------------------------------
    roots = [WS / d for d in ("video-factory-g1", "video-factory-g2",
                              "video-factory-g3", "video-factory-g4",
                              "video-factory-g5", "video-factory-g6",
                              "video-factory-g7", "video-factory-g8",
                              "video-factory-g9")]
    roots.append(PROG)
    hits = []
    skip_dirs = {".venv", "node_modules", "__pycache__", ".n8n", ".git"}
    for root in roots:
        for f in root.rglob("*"):
            if not f.is_file() or any(p in skip_dirs for p in f.parts):
                continue
            if f.suffix not in (".py", ".js", ".json", ".md", ".sh", ".txt",
                                ".html", ".yaml", ".yml", ".toml"):
                continue
            if f.stat().st_size > 2_000_000:
                continue
            try:
                text = f.read_text(errors="replace")
            except Exception:
                continue
            for label, pat in SECRET_PATTERNS:
                for m in pat.finditer(text):
                    value = m.group(0)
                    is_dev = any(dv in value or dv in text[max(0, m.start()-40):m.end()+40]
                                 for dv in DEV_VALUES)
                    hits.append({"file": str(f), "pattern": label,
                                 "classification": "documented dev/test value"
                                 if is_dev else classify(str(f)),
                                 "excerpt": value[:60]})
    review = [h for h in hits if h["classification"] == "REVIEW"]
    rec.data["secret_hits"] = hits
    rec.check(f"secrets sweep: {len(hits)} pattern hits, every one classified; "
              "none is an undocumented credential in product code",
              not review, f"review={review[:5]}")
    rec.note("Documented dev values are the local test tokens/passwords used "
             "by every gate's fixtures (dev-*-token, the local scratch-DB "
             "password, the local n8n dev owner). No production credential "
             "exists anywhere in the trees — real providers are BLOCKED "
             "(OD-A3) and no vault credential has been issued.")
    rec.write()


if __name__ == "__main__":
    main()
