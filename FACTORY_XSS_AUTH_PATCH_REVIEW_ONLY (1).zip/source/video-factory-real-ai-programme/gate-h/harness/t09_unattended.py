"""T9 — Unattended workflow (LOCK_GATE_H §T9).

The Station-3 chain (05.12 -> 08.12 + HG2) driven ONLY by services: the
Gate F runner (scheduler claims, dispatcher hands off to the n8n dispatch
webhook), the Gate G workflows execute, the evaluation service validates.
The harness performs operator data-setup only (production, run, canon
input, unit planning) and the recorded human acts (approving
AWAITING_HUMAN units, deciding HG2 via the API). No harness code claims,
completes, or validates any unit.

Phase 1 is a pure services-only observation — it is the T9 criterion.
Phase 2 is a disclosed clock simulation (the stalled unit's lease expiry
is backdated, the technique the Gate F reaper tests use) so the recovery
loop — reaper, retry driver, scheduler — is observable without waiting
out the real 600s lease; it is diagnostic evidence for the phase-1
outcome, not a second chance at the criterion.
"""
import sys
import time

sys.path.insert(0, str(__file__).rsplit("/harness/", 1)[0] + "/harness")
from common import *  # noqa: E402,F403

SERVICE_ACTORS = {"scheduler-service", "dispatcher-service", "reaper-service",
                  "retry-driver", "reconciler-service"}
# Transitions the harness may legitimately author: planning-time readiness
# marking (deps_met, part of unit planning = operator data-setup) and the
# recorded human acts. Everything else must be a service/worker/validator
# actor's work.
HUMAN_EVENTS = {"human_approved", "human_rejected", "deps_met"}


def audit_snapshot(pid):
    with raw(G5_DSN) as conn:
        return conn.execute(
            "SELECT unit_id, event_type, old_state, new_state, actor, payload,"
            " created_at FROM audit_events WHERE production_id=%s"
            " ORDER BY created_at", (pid,)).fetchall()


def leases():
    with raw(G5_DSN) as conn:
        return conn.execute(
            "SELECT unit_id, worker_id, fencing_token, expires_at"
            " FROM worker_leases").fetchall()


def handoffs(pid):
    with raw(G5_DSN) as conn:
        return conn.execute(
            "SELECT count(*) AS n FROM dispatch_handoffs dh"
            " JOIN execution_units u ON u.unit_id=dh.unit_id"
            " WHERE u.production_id=%s", (pid,)).fetchone()["n"]


def observe(api, pid, units, units_rev, seconds, rec, phase):
    """Poll states; perform ONLY the recorded human acts (approvals).
    Returns the last state map (unit_id -> state)."""
    timeline = []
    start = time.time()
    last = {}
    while time.time() - start < seconds:
        states = unit_states(api, pid)
        last = states
        timeline.append({"t": round(time.time() - start, 1),
                         "states": {units_rev[u]: s for u, s in states.items()}})
        for uid, s in states.items():
            if s == "AWAITING_HUMAN":
                api.call("POST", f"/units/{uid}/events",
                         {"event": "human_approved"}, role="OPERATOR",
                         identity="harness")
        if len(states) == 4 and all(s == "ACCEPTED" for s in states.values()):
            break
        time.sleep(5)
    rec.data[f"timeline_{phase}"] = timeline
    return last


def main():
    rec = Recorder("T9", "Unattended workflow")
    run_g5_setup(log_name="g5_setup_t09.log")
    runner = start_runner(G5_DSN, "http://127.0.0.1:5678/webhook/dispatch-g5",
                          log_name="runner_t09.log")
    api = g5_api()
    completed = False
    try:
        pid, run_id, canon_id, units = plan_station3(
            api, "T9 unattended production")
        units_rev = {v: k for k, v in units.items()}
        u05 = units["05.12"]

        # ---------------- Phase 1: pure services-only observation ----------
        states = observe(api, pid, units, units_rev, 240, rec, "phase1")
        rec.data["phase1_final_states"] = {units_rev[k]: v for k, v in states.items()}
        rec.data["phase1_leases"] = [dict(r) for r in leases()]
        rec.data["phase1_handoffs"] = handoffs(pid)
        completed = len(states) == 4 and all(s == "ACCEPTED" for s in states.values())
        rec.check("phase 1 (services only): the chain completes unattended",
                  completed, f"states={rec.data['phase1_final_states']} "
                  f"leases={rec.data['phase1_leases']} "
                  f"handoffs={rec.data['phase1_handoffs']}")

        # ---------------- Phase 2: disclosed clock simulation --------------
        if not completed:
            with raw(G5_DSN) as conn:
                n = conn.execute(
                    "UPDATE worker_leases SET expires_at = now() - interval '1 minute'"
                    " WHERE unit_id=%s", (u05,)).rowcount
            rec.note(f"phase 2 clock simulation: backdated the lease of the "
                     f"stalled unit ({n} row) so the reaper/retry/scheduler "
                     "recovery loop is observable without the real 600s wait")
            states2 = observe(api, pid, units, units_rev, 300, rec, "phase2")
            rec.data["phase2_final_states"] = {units_rev[k]: v for k, v in states2.items()}
            rec.data["phase2_leases"] = [dict(r) for r in leases()]
            rec.data["phase2_handoffs"] = handoffs(pid)
            with raw(G5_DSN) as conn:
                attempts = conn.execute(
                    "SELECT attempt_no, worker_id, status FROM action_attempts"
                    " WHERE unit_id=%s ORDER BY attempt_no", (u05,)).fetchall()
            rec.data["u05_attempts"] = [dict(a) for a in attempts]
            completed2 = len(states2) == 4 and all(
                s == "ACCEPTED" for s in states2.values())
            rec.check("phase 2 diagnostic: after lease-expiry simulation the "
                      "recovery loop completes the chain", completed2,
                      f"states={rec.data['phase2_final_states']} "
                      f"attempts={rec.data['u05_attempts']}")
            if not completed2:
                rec.defect(
                    "D-H1", "CRITICAL",
                    "Unattended composition deadlock: the Gate F scheduler "
                    "claims READY units itself (worker 'sched-<lane>'), and "
                    "the Gate G n8n executor — the only execution path — "
                    "refuses to execute a unit it did not claim (its claim "
                    "call is refused as a duplicate and the execution stops "
                    "at the 'Claim refused or duplicate dispatch' branch). "
                    "The dispatch handoff therefore never leads to "
                    "execution: the unit parks CLAIMED under the scheduler "
                    "until lease expiry, and the reaper/retry/scheduler "
                    "loop hands it back to the scheduler instead of to a "
                    "worker. The Station-3 chain does not complete when "
                    "driven only by the Gate F runner + Gate G workflows.",
                    "gate-h/evidence/results/t9.json: phase1/phase2 state "
                    "timelines; leases held by sched-* workers; "
                    "dispatch_handoffs >= 1 (handoff delivered); u05 "
                    "attempts all recorded under scheduler workers with "
                    "zero executor (n8n) attempts. gate-h/evidence/"
                    "t9_n8n_executions.json: both unit-executor executions "
                    "following the handoffs took the 'Claim refused or "
                    "duplicate dispatch' branch on a 409 'claim requires "
                    "READY, unit is CLAIMED'.",
                    affected=["T9", "T6"])

        # ---------------- HG2 ----------------------------------------------
        st, gates = api.call("GET", f"/productions/{pid}/gates", role="OPERATOR",
                             identity="harness")
        hg2 = [g for g in gates["gates"] if g["gate_kind"] == "HG2"]
        if hg2 and hg2[0]["verdict"] == "PENDING":
            api.call("POST", f"/gates/{hg2[0]['gate_id']}/decide",
                     {"decision": "APPROVED"}, role="OPERATOR", identity="harness")
            st, gates = api.call("GET", f"/productions/{pid}/gates",
                                 role="OPERATOR", identity="harness")
            hg2 = [g for g in gates["gates"] if g["gate_kind"] == "HG2"]
        rec.check("HG2 gate created by the station flow and decided by the human",
                  bool(hg2) and hg2[0]["verdict"] == "APPROVED",
                  f"gates={gates['gates']}")

        # ---------------- actor attribution ----------------------------------
        rows = audit_snapshot(pid)
        transitions = [r for r in rows
                       if r["old_state"] is not None
                       and r["old_state"] != r["new_state"]
                       and str(r["unit_id"]) in set(units.values())]
        bad = [r for r in transitions
               if r["actor"] == "operator:harness"
               and r["event_type"] not in HUMAN_EVENTS]
        service_driven = [r for r in transitions
                          if r["actor"] in SERVICE_ACTORS
                          or r["actor"].startswith(("worker:", "validator:"))]
        rec.data["transition_actors"] = sorted(
            {(r["actor"], r["event_type"]) for r in transitions})
        rec.check("every state transition was performed by a service actor "
                  "(human acts are approvals + the gate decision only)",
                  not bad and len(service_driven) >= 1,
                  f"bad={[(r['actor'], r['event_type']) for r in bad]} "
                  f"actors={rec.data['transition_actors']}")
    finally:
        stop_proc(runner)
    rec.write()


if __name__ == "__main__":
    main()
