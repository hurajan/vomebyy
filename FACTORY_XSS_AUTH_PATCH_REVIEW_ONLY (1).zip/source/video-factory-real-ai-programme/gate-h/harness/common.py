"""Gate H harness — shared fixtures (LOCK_GATE_H, verification only).

Everything here is test scaffolding: chain-built scratch DBs, API clients,
service process management, and a check recorder that writes one
machine-readable JSON result per T-item into gate-h/evidence/results/.
No product code is imported for modification; coordinator / services are
exercised through their public surfaces only.
"""
import json
import os
import subprocess
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path

WS = Path.home() / "workspace"
G1 = WS / "video-factory-g1"
G2 = WS / "video-factory-g2"
G3 = WS / "video-factory-g3"
PROG = WS / "video-factory-real-ai-programme"
GATE_C = PROG / "gate-c"
GATE_D = PROG / "gate-d"
GATE_E = PROG / "gate-e"
GATE_F = PROG / "gate-f"
GATE_H = PROG / "gate-h"
RESULTS = GATE_H / "evidence" / "results"
LOGS = GATE_H / "evidence" / "logs"
G2_PY = str(G2 / ".venv" / "bin" / "python")
G3_PY = str(G3 / ".venv" / "bin" / "python")

DB = "gateh_scratch"

for p in (str(G2), str(G3 / "tests"), str(GATE_D), str(GATE_C), str(GATE_F),
          str(GATE_E)):
    if p not in sys.path:
        sys.path.insert(0, p)

from server_fixture import make_dsn, start_server, stop_server, Client  # noqa: E402

DSN = make_dsn(DB)

# dev role tokens (test-only values used across every prior gate's setups)
TOKENS = {"OPERATOR": "dev-operator-token", "WORKER": "dev-worker-token",
          "SCHEDULER": "dev-scheduler-token", "VALIDATOR": "dev-validator-token",
          "CALLBACK": "dev-callback-token"}
ROLE_ENV = {"FACTORY_API_TOKEN": TOKENS["OPERATOR"],
            "FACTORY_WORKER_TOKEN": TOKENS["WORKER"],
            "FACTORY_SCHEDULER_TOKEN": TOKENS["SCHEDULER"],
            "FACTORY_VALIDATOR_TOKEN": TOKENS["VALIDATOR"],
            "FACTORY_CALLBACK_TOKEN": TOKENS["CALLBACK"]}


def build_db(name=DB, log_name=None):
    """Chain-build a scratch DB via the G2 setup (registry + migrations
    002-013 + FACTORY/test mock binding). Full output to a log file."""
    LOGS.mkdir(parents=True, exist_ok=True)
    log = LOGS / (log_name or f"build_{name}.log")
    with open(log, "w") as fh:
        r = subprocess.run([G2_PY, str(G2 / "tools" / "setup_db.py"), name],
                           stdout=fh, stderr=subprocess.STDOUT, text=True)
    if r.returncode != 0:
        raise RuntimeError(f"setup_db({name}) failed; see {log}")
    return name


def raw(dsn=DSN):
    import psycopg
    from psycopg.rows import dict_row
    return psycopg.connect(dsn, row_factory=dict_row, autocommit=True)


def kill_port(port):
    subprocess.run(["fuser", "-k", f"{port}/tcp"], capture_output=True)


def wait_http(url, timeout=30, want=200):
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            with urllib.request.urlopen(url, timeout=3) as r:
                if r.status == want:
                    return True
        except Exception:
            pass
        time.sleep(0.25)
    return False


def wait_for(pred, timeout=60, interval=1.0, desc="condition"):
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            if pred():
                return True
        except Exception:
            pass
        time.sleep(interval)
    raise TimeoutError(f"timed out waiting for {desc}")


class Api:
    """Role-aware client for the G3 API."""

    def __init__(self, port):
        self.base = f"http://127.0.0.1:{port}"

    def call(self, method, path, body=None, role=None, identity=None,
             token="__role__", extra_headers=None):
        req = urllib.request.Request(self.base + path, method=method)
        if token == "__role__":
            if role == "OPERATOR":
                # OPERATOR authenticates via the legacy operator token only.
                req.add_header("X-Operator-Token", TOKENS["OPERATOR"])
                if identity:
                    req.add_header("X-Identity", identity)
            elif role is not None:
                req.add_header("X-Role", role)
                req.add_header("X-Role-Token", TOKENS[role])
                if identity:
                    req.add_header("X-Identity", identity)
        elif token is not None:
            req.add_header("X-Operator-Token", token)
        for k, v in (extra_headers or {}).items():
            req.add_header(k, v)
        data = None
        if body is not None:
            data = json.dumps(body).encode()
            req.add_header("Content-Type", "application/json")
        try:
            with urllib.request.urlopen(req, data=data, timeout=15) as r:
                return r.status, json.loads(r.read() or b"{}")
        except urllib.error.HTTPError as e:
            rawb = e.read()
            try:
                return e.code, json.loads(rawb or b"{}")
            except json.JSONDecodeError:
                return e.code, {"raw": rawb.decode(errors="replace")}
        except Exception as e:  # connection errors etc.
            return None, {"error": f"{type(e).__name__}: {e}"}


def start_api(db, port, env_extra=None, log_name=None):
    """Start the G3 API on an already-built DB (does NOT rebuild it)."""
    kill_port(port)
    env = dict(os.environ, FACTORY_DSN=make_dsn(db), FACTORY_PORT=str(port),
               HOME=str(Path.home()), **ROLE_ENV, **(env_extra or {}))
    LOGS.mkdir(parents=True, exist_ok=True)
    fh = open(LOGS / (log_name or f"api_{port}.log"), "w")
    proc = subprocess.Popen([G3_PY, str(G3 / "api" / "server.py")], env=env,
                            stdout=fh, stderr=subprocess.STDOUT)
    if not wait_http(f"http://127.0.0.1:{port}/health", timeout=30):
        raise RuntimeError(f"API on {port} did not come up")
    return proc


def start_worker_service(port, dsn, env_extra=None, log_name=None):
    kill_port(port)
    env = dict(os.environ, FACTORY_DSN=dsn, WORKER_SERVICE_PORT=str(port),
               HOME=str(Path.home()), **(env_extra or {}))
    fh = open(LOGS / (log_name or f"worker_{port}.log"), "w")
    proc = subprocess.Popen([G2_PY, str(GATE_C / "worker_service" / "service.py")],
                            env=env, stdout=fh, stderr=subprocess.STDOUT)
    if not wait_http(f"http://127.0.0.1:{port}/health", timeout=30):
        raise RuntimeError(f"worker service on {port} did not come up")
    return proc


def start_eval_service(port, dsn, api_url, log_name=None, env_extra=None):
    kill_port(port)
    env = dict(os.environ, FACTORY_DSN=dsn, FACTORY_API_URL=api_url,
               FACTORY_VALIDATOR_TOKEN=TOKENS["VALIDATOR"],
               FACTORY_ENVIRONMENT="test", FACTORY_EVAL_PORT=str(port),
               HOME=str(Path.home()), **(env_extra or {}))
    fh = open(LOGS / (log_name or f"eval_{port}.log"), "w")
    proc = subprocess.Popen(
        [G2_PY, str(GATE_E / "evaluation_service" / "service.py")],
        env=env, stdout=fh, stderr=subprocess.STDOUT)
    if not wait_http(f"http://127.0.0.1:{port}/health", timeout=30):
        raise RuntimeError(f"evaluation service on {port} did not come up")
    return proc


def stop_proc(proc):
    if proc is None:
        return
    proc.terminate()
    try:
        proc.wait(timeout=8)
    except subprocess.TimeoutExpired:
        proc.kill()


class Recorder:
    """Collects checks/defects for one T-item and writes its JSON result."""

    def __init__(self, t, title):
        self.t = t
        self.title = title
        self.checks = []
        self.defects = []
        self.notes = []
        self.data = {}

    def check(self, name, ok, detail=""):
        self.checks.append({"name": name, "ok": bool(ok),
                            "detail": str(detail)[:1200]})
        return bool(ok)

    def defect(self, defect_id, severity, description, evidence, affected=None):
        self.defects.append({"id": defect_id, "severity": severity,
                             "description": description, "evidence": evidence,
                             "affected": affected or [self.t]})

    def note(self, text):
        self.notes.append(str(text))

    def verdict(self, forced=None):
        if forced:
            return forced
        return "PASS" if all(c["ok"] for c in self.checks) else "FAIL"

    def write(self, verdict=None):
        RESULTS.mkdir(parents=True, exist_ok=True)
        out = {"t": self.t, "title": self.title,
               "verdict": verdict or self.verdict(),
               "checks": self.checks, "defects": self.defects,
               "notes": self.notes, "data": self.data}
        path = RESULTS / f"{self.t.lower()}.json"
        path.write_text(json.dumps(out, indent=2, default=str))
        print(f"{self.t}: {out['verdict']} "
              f"({sum(c['ok'] for c in self.checks)}/{len(self.checks)} checks) "
              f"-> {path}")
        return out


# ---- Gate G station stack (g5) + Gate F runner helpers ----------------------
G5_DB = "g5_station_scratch"
G5_DSN = make_dsn(G5_DB)
G5 = WS / "video-factory-g5"


def run_g5_setup(log_name="g5_setup.log"):
    """Run the g5 tree's own setup: rebuilds g5_station_scratch, restarts
    the API on 8730 + worker service 8795 + evaluation service 8796 onto
    it, seeds STATION bindings, syncs + activates the station-3 n8n
    workflows. Full output to a log file."""
    LOGS.mkdir(parents=True, exist_ok=True)
    with open(LOGS / log_name, "w") as fh:
        r = subprocess.run(["python3", str(G5 / "tools" / "setup_env.py")],
                           stdout=fh, stderr=subprocess.STDOUT, text=True,
                           timeout=900)
    if r.returncode != 0:
        raise RuntimeError(f"g5 setup failed; see {LOGS / log_name}")
    return True


def start_runner(dsn, dispatch_url, log_name="runner.log", intervals=None):
    """Start the Gate F runtime-services runner against a scratch DB."""
    env = dict(os.environ, FACTORY_DSN=dsn, HOME=str(Path.home()),
               FACTORY_DISPATCH_URL=dispatch_url, **(intervals or {}))
    fh = open(LOGS / log_name, "w")
    proc = subprocess.Popen(
        [G2_PY, str(GATE_F / "runtime_services" / "runner.py")],
        env=env, stdout=fh, stderr=subprocess.STDOUT)
    time.sleep(2)
    if proc.poll() is not None:
        raise RuntimeError(f"runner exited immediately; see {LOGS / log_name}")
    return proc


def restart_g5_services(log_prefix="restart"):
    """Restart API + worker service + evaluation service onto the EXISTING
    g5_station_scratch DB (no rebuild), replicating g5 setup_env's launch
    env exactly. Returns (api_proc, worker_proc, eval_proc)."""
    api = start_api(G5_DB, 8730, log_name=f"{log_prefix}_api.log")
    worker = start_worker_service(8795, G5_DSN, log_name=f"{log_prefix}_worker.log",
                                  env_extra={"WORKER_ENVIRONMENT": "test"})
    evalp = start_eval_service(8796, G5_DSN, "http://127.0.0.1:8730",
                               log_name=f"{log_prefix}_eval.log")
    return api, worker, evalp


def g5_api():
    return Api(8730)


def plan_station3(api, title="Gate H station-3 production"):
    """Create a production + run + canon input + the four chained units
    exactly as the g5 suite does. Returns (pid, run_id, canon_id, units)."""
    st, prod = api.call("POST", "/productions",
                        {"title": title, "hard_ceiling_cents": 1000000,
                         "soft_ceiling_cents": 900000},
                        role="OPERATOR", identity="harness")
    pid = prod["production_id"]
    st, r = api.call("POST", f"/productions/{pid}/runs", {"kind": "FULL"},
                     role="OPERATOR", identity="harness")
    run = r["run_id"]
    st, canon = api.call("POST", f"/productions/{pid}/artifacts",
                         {"artifact_type": "canon_manifest",
                          "content": "canon fixture",
                          "storage_uri": "local://canon-fixture"},
                         role="OPERATOR", identity="harness")
    canon_id = canon["artifact_id"]

    def plan(op, deps=()):
        st, u = api.call("POST", f"/productions/{pid}/units",
                         {"operation_id": op, "run_id": run, "unit_key": "main",
                          "depends_on": list(deps),
                          "input_artifact_ids": [canon_id]},
                         role="OPERATOR", identity="harness")
        return u["unit_id"]

    u05 = plan("05.12")
    u06 = plan("06.12", deps=(u05,))
    u07 = plan("07.12", deps=(u06,))
    u08 = plan("08.12", deps=(u07,))
    return pid, run, canon_id, {"05.12": u05, "06.12": u06, "07.12": u07,
                                "08.12": u08}


def unit_states(api, pid):
    st, out = api.call("GET", f"/productions/{pid}/units", role="OPERATOR",
                       identity="harness")
    return {u["unit_id"]: u["state"] for u in out["units"]}


# ---- deliverable / envelope fixtures (mirrors gate-e integration tests) ----
CONTRACTS = G1 / "contracts"
RULE_OF_SIX = [("Emotion", 51, 8.6), ("Story", 23, 8.2), ("Rhythm", 10, 7.4),
               ("Eye Trace", 7, 7.9), ("2D Plane", 5, 7.1), ("3D Space", 4, 6.8)]


def deliverable(step):
    schema = json.loads(
        (CONTRACTS / f"step-{step}" / "output.schema.json").read_text())
    return schema["properties"]["step_deliverable"]["const"]


def deliverable_content(op, artifact_type):
    if op == "05.12":
        return {"kind": "story_architecture",
                "story_nodes": [{"id": "S1", "summary": "Story node S1"}],
                "canon_refs": []}
    if op == "12.12":
        dims = [{"name": n, "weight": w, "score": s} for n, w, s in RULE_OF_SIX]
        total = round(sum(w * s for _, w, s in RULE_OF_SIX) / 100.0, 3)
        return {"kind": "edit_timeline",
                "segments": [{"shot_ref": "SH1", "order": 1}],
                "rule_of_six": {"dimensions": dims, "weighted_total": total}}
    return {"kind": artifact_type}


def envelope(pid, op, artifact_type, content=None):
    item = {"artifact_id": "33333333-3333-4333-8333-333333333333",
            "artifact_type": artifact_type, "sha256": "a" * 64,
            "content": deliverable_content(op, artifact_type)
            if content is None else content}
    doc = {"production_id": pid, "operation_id": op, "status": "CANDIDATE",
           "step_deliverable": deliverable(op.split(".")[0]),
           "output_artifacts": [item], "evidence": []}
    return json.dumps(doc, sort_keys=True).encode()


def add_config(conn, scope, provider="mock", est=100, operation_id=None,
               station=None, capability_slot=None, action_key=None,
               environment="test", params=None, credential_ref=None,
               created_by="gateh", modality=None, model=None):
    """Insert a provider binding directly (fixture seeding, mirrors the
    g2 gate tests). Returns config_id."""
    import uuid
    cid = str(uuid.uuid4())
    conn.execute(
        "INSERT INTO provider_configs(config_id, scope, station, operation_id,"
        " capability_slot, action_key, environment, provider, model, modality,"
        " params, est_cost_cents, credential_ref, created_by)"
        " VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)",
        (cid, scope, station, operation_id, capability_slot, action_key,
         environment, provider, model, modality, json.dumps(params or {}),
         est, credential_ref, created_by))
    return cid


def drive_unit_to_validating(c, unit_id, artifact_type, content,
                             worker="w-test", actual=90):
    """claim -> start -> complete; returns claim dict. Coordinator-level
    fixture driver used by several T-items."""
    claim = c.claim(unit_id, worker, None)
    c.event(unit_id, "start")
    c.complete_attempt(unit_id, worker, claim["fencing_token"], artifact_type,
                       content, None, actual)
    return claim
