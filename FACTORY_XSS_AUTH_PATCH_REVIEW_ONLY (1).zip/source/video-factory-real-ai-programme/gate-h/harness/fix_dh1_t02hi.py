"""Write t02h.json (from the fix_dh1_t09 re-run) and t02i.json (from the
pass-2 regression logs) once the stack battery has run."""
import json
import re
from pathlib import Path

GATEH = Path(__file__).resolve().parent.parent
RES = GATEH / "evidence" / "results" / "fix-dh1"
LOGS = GATEH / "evidence" / "logs" / "fix-dh1"

t9 = json.loads((RES / "t9_rerun.json").read_text())
# fix_dh1_t09.py writes checks[] but no passed/total keys; derive them.
t9_passed = t9.get("passed", sum(1 for c in t9["checks"] if c["ok"]))
t9_total = t9.get("total", len(t9["checks"]))
(RES / "t02h.json").write_text(json.dumps(
    {"test": "T02-H", "verdict": t9["verdict"],
     "source": "harness/fix_dh1_t09.py re-run (results/fix-dh1/t9_rerun.json)",
     "passed": t9_passed, "total": t9_total}, indent=1))
print("t02h.json ->", t9["verdict"])

SUITES = [("g1", "g1_suite_pass2.log"), ("g2", "g2_suite_pass2.log"),
          ("g3", "g3_suite_pass2.log"), ("g4", "g4_suite_pass2.log"),
          ("g5", "g5_suite_pass2.log"), ("g6", "g6_suite_pass2.log"),
          ("g7", "g7_suite_pass2.log"), ("g8", "g8_suite_pass2.log"),
          ("g9", "g9_suite_pass2.log"), ("worker", "worker_suite_pass2.log"),
          ("storage", "storage_suite_pass2.log"),
          ("evaluation", "evaluation_suite_pass2.log"),
          ("runtime", "runtime_suite_pass2.log")]
suites, total, ok_all = {}, 0, True
for name, fname in SUITES:
    p = LOGS / fname
    if not p.exists():
        suites[name] = {"status": "NOT RUN (stack contention)"}
        ok_all = False
        continue
    text = p.read_text()
    m = re.search(r"Ran (\d+) tests?", text)
    ok = bool(re.search(r"^OK$", text, re.M))
    suites[name] = {"ran": int(m.group(1)) if m else None, "ok": ok}
    total += int(m.group(1)) if m else 0
    ok_all = ok_all and ok
(RES / "t02i.json").write_text(json.dumps(
    {"test": "T02-I", "verdict": "PASS" if ok_all else "INCOMPLETE",
     "total_tests": total, "suites": suites}, indent=1))
print("t02i.json ->", "PASS" if ok_all else "INCOMPLETE", total)
