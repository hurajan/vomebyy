"""T6 part A probe (subprocess): run ONE Gate F ReconcilerService pass
against the worker service's job view of the stub provider, and print the
report as JSON. Runs as its own process because the runtime services
import the coordinator as a top-level module (their own path convention),
which cannot coexist in-process with this harness's package imports.

Usage: t06_reconciler_probe.py <dsn> <worker_port> <storage_root>
"""
import json
import sys
import urllib.request
import urllib.error
from pathlib import Path

WS = Path.home() / "workspace"
sys.path.insert(0, str(WS / "video-factory-real-ai-programme" / "gate-f"))
sys.path.insert(0, str(WS / "video-factory-real-ai-programme" / "gate-d"))

from runtime_services.reconciler_service import ReconcilerService  # noqa: E402
from coordinator import Coordinator  # noqa: E402  (module-style, gate-f convention)
from storage_service import LocalStorage  # noqa: E402

DSN, WORKER_PORT, STORE_ROOT = sys.argv[1], int(sys.argv[2]), sys.argv[3]


def http_json(method, url):
    req = urllib.request.Request(url, method=method)
    try:
        with urllib.request.urlopen(req, timeout=15) as r:
            return r.status, json.loads(r.read() or b"{}")
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read() or b"{}")


class WorkerServicePoller:
    def poll(self, provider_job_id):
        st, out = http_json(
            "GET", f"http://127.0.0.1:{WORKER_PORT}/jobs/{provider_job_id}")
        if st == 200 and out.get("status") == "COMPLETED":
            content = out.get("content")
            data = content if isinstance(content, bytes) else str(content).encode()
            return {"state": "completed", "data": data,
                    "storage_uri": f"worker-service://jobs/{provider_job_id}",
                    "cost_cents": out.get("actual_cost_cents", 0),
                    "artifact_type": out.get("artifact_type")}
        if st == 404:
            return {"state": "not_found"}
        return {"state": "processing"}


def main():
    storage = LocalStorage(STORE_ROOT)
    report = ReconcilerService(
        lambda: Coordinator(DSN, actor="reconciler-service",
                            storage=storage)).run_once(WorkerServicePoller())
    print(json.dumps(report, default=str))


if __name__ == "__main__":
    main()
