"""T12 — Regression (LOCK_GATE_H §T12).

All 13 suites, serial, each with its own setup, full logs to files:
G1 9, G2 58, G3 25, G4 2, G5 1, G6 3, G7 2, G8 1, G9 9, worker service 19,
storage service 5, evaluation service 25, runtime services 10 = 169.
"""
import re
import subprocess
import sys

sys.path.insert(0, str(__file__).rsplit("/harness/", 1)[0] + "/harness")
from common import *  # noqa: E402,F403

TREES = {n: WS / f"video-factory-{n}" for n in
         ("g4", "g5", "g6", "g7", "g8", "g9")}

SUITES = [
    # (name, expected, cwd, test_cmd, setup_cmd or None)
    ("g1", 9, G1, [G2_PY, "-m", "unittest", "discover", "-s", "tests"], None),
    ("g2", 58, G2, [G2_PY, "-m", "unittest", "discover", "-s", "tests"], None),
    ("g3", 25, G3, [G3_PY, "-m", "unittest", "discover", "-s", "tests"], None),
    ("g4", 2, TREES["g4"], [G2_PY, "-m", "unittest", "discover", "-s", "tests"],
     ["python3", str(TREES["g4"] / "tools" / "setup_env.py")]),
    ("g5", 1, TREES["g5"], [G2_PY, "-m", "unittest", "discover", "-s", "tests"],
     ["python3", str(TREES["g5"] / "tools" / "setup_env.py")]),
    ("g6", 3, TREES["g6"], [G2_PY, "-m", "unittest", "discover", "-s", "tests"],
     ["python3", str(TREES["g6"] / "tools" / "setup_env.py")]),
    ("g7", 2, TREES["g7"], [G2_PY, "-m", "unittest", "discover", "-s", "tests"],
     ["python3", str(TREES["g7"] / "tools" / "setup_env.py")]),
    ("g8", 1, TREES["g8"], [G2_PY, "-m", "unittest", "discover", "-s", "tests"],
     ["python3", str(TREES["g8"] / "tools" / "setup_env.py")]),
    ("g9", 9, TREES["g9"], [G2_PY, "-m", "unittest", "discover", "-s", "tests"],
     ["python3", str(TREES["g9"] / "tools" / "setup_fullrun.py")]),
    ("worker_service", 19, GATE_C,
     [G2_PY, "-m", "unittest", "discover", "-s", "worker_service/tests"], None),
    ("storage_service", 5, GATE_D,
     [G2_PY, "-m", "unittest", "discover", "-s", "storage_service/tests"], None),
    ("evaluation_service", 25, GATE_E,
     [G2_PY, "-m", "unittest", "discover", "-s", "evaluation_service/tests"], None),
    ("runtime_services", 10, GATE_F,
     [G2_PY, "-m", "unittest", "discover", "-s", "runtime_services/tests"], None),
]


def run(cmd, cwd, log_name, timeout=1800):
    with open(LOGS / log_name, "w") as fh:
        r = subprocess.run(cmd, cwd=str(cwd), stdout=fh,
                           stderr=subprocess.STDOUT, text=True, timeout=timeout)
    return r.returncode, (LOGS / log_name).read_text()


def main():
    # Optional subset filter: `t12_regression.py g5 g8` re-runs only those
    # suites and writes t12_supplement.json (used once to correct a
    # result-parser miss on the singular 'Ran 1 test' wording; the first
    # full run's logs remain the primary evidence for the other suites).
    subset = sys.argv[1:]
    suites = [s for s in SUITES if not subset or s[0] in subset]
    rec = Recorder("T12" if not subset else "T12-supplement",
                   "Regression — all 13 suites" if not subset else
                   f"Regression supplement — suites {subset}")
    total_ran = 0
    counts = {}
    for name, expected, cwd, cmd, setup in suites:
        for port in (8730, 8795, 8796):
            kill_port(port)
        if setup:
            rc_s, _ = run(setup, cwd, f"t12_setup_{name}.log", timeout=1200)
            if rc_s != 0:
                rec.check(f"suite {name}: setup", False, f"setup rc={rc_s}")
                counts[name] = {"setup_failed": True}
                continue
        rc, out = run(cmd, cwd, f"t12_suite_{name}.log")
        m = re.search(r"Ran (\d+) tests?", out)
        ran = int(m.group(1)) if m else 0
        ok = bool(re.search(r"^OK\s*$", out, re.M)) and rc == 0
        counts[name] = {"ran": ran, "expected": expected, "ok": ok, "rc": rc}
        total_ran += ran
        rec.check(f"suite {name}: {ran}/{expected} tests, {'OK' if ok else 'FAILED'}",
                  ok and ran == expected, f"rc={rc}; log t12_suite_{name}.log")
    rec.data["suite_counts"] = counts
    rec.data["total_ran"] = total_ran
    if not subset:
        rec.check("total across suites == 169", total_ran == 169,
                  f"total={total_ran}")
    rec.write()


if __name__ == "__main__":
    main()
