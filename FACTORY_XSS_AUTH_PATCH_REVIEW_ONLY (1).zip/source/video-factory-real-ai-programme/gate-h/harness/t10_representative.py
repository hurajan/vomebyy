"""T10 — Representative production (LOCK_GATE_H §T10).

The g9 full-run suite is re-executed AS-IS on the current build (its own
setup + tests, unmodified): one production through all 16 steps. The
refreshed 192-operation accounting is then computed from evidence: the
operations whose units completed attempts in this run, unioned with the
operations individually executed elsewhere in Gate H evidence (T6, T9)
and the g4 suite's extra operation (03.02, via T12's run of that suite —
read from its executed set if already recorded, else from the Gate A
accounting it reproduces).
"""
import json
import re
import subprocess
import sys

sys.path.insert(0, str(__file__).rsplit("/harness/", 1)[0] + "/harness")
from common import *  # noqa: E402,F403

G9 = WS / "video-factory-g9"
G9_DSN = make_dsn("g9_fullrun_scratch")


def run(cmd, log_name, timeout=1800):
    with open(LOGS / log_name, "w") as fh:
        r = subprocess.run(cmd, stdout=fh, stderr=subprocess.STDOUT, text=True,
                           timeout=timeout)
    return r.returncode, (LOGS / log_name).read_text()


def main():
    rec = Recorder("T10", "Representative production (g9 full run, as-is)")
    rc, setup_out = run(["python3", str(G9 / "tools" / "setup_fullrun.py")],
                        "t10_g9_setup.log")
    rec.check("g9 setup_fullrun completes", rc == 0, f"rc={rc}")
    with open(LOGS / "t10_g9_suite.log", "w") as fh:
        r = subprocess.run([G2_PY, "-m", "unittest", "discover", "-s", "tests",
                            "-v"], cwd=str(G9), stdout=fh,
                           stderr=subprocess.STDOUT, text=True, timeout=1800)
    rc, out = r.returncode, (LOGS / "t10_g9_suite.log").read_text()
    m = re.search(r"Ran (\d+) tests", out)
    ran = int(m.group(1)) if m else 0
    ok = bool(re.search(r"^OK\s*$", out, re.M))
    rec.check("g9 suite passes as-is (9 tests)", rc == 0 and ok and ran == 9,
              f"rc={rc} ran={ran} ok={ok}")

    # -- executed operations in this run (DB evidence) -------------------------
    executed = set()
    budget = {}
    try:
        with raw(G9_DSN) as conn:
            rows = conn.execute(
                "SELECT DISTINCT u.operation_id FROM execution_units u"
                " JOIN action_attempts a ON a.unit_id=u.unit_id"
                " WHERE a.status='ACCEPTED'").fetchall()
            executed = {r["operation_id"] for r in rows}
            prods = conn.execute(
                "SELECT production_id FROM productions ORDER BY created_at").fetchall()
            for p in prods:
                units = conn.execute(
                    "SELECT count(*) AS n FROM execution_units"
                    " WHERE production_id=%s AND state='ACCEPTED'",
                    (p["production_id"],)).fetchone()["n"]
                charges = conn.execute(
                    "SELECT COALESCE(SUM(amount_cents),0) AS s FROM"
                    " budget_transactions WHERE production_id=%s AND kind='CHARGE'",
                    (p["production_id"],)).fetchone()["s"]
                budget[str(p["production_id"])] = {"accepted_units": units,
                                                   "settled_cents": charges}
    except Exception as e:  # noqa: BLE001
        rec.note(f"DB accounting query failed: {e}")
    rec.data["g9_executed_operations"] = sorted(executed)
    rec.data["g9_productions"] = budget
    full = [b for b in budget.values() if b["accepted_units"] == 18]
    rec.check("the representative production: 18 units ACCEPTED, 1620 settled",
              len(full) == 1 and full[0]["settled_cents"] == 1620,
              f"productions={budget}")

    # -- union with the rest of Gate H evidence --------------------------------
    # "Individually executed" = a unit of the operation completed an attempt
    # (reached VALIDATING or beyond) in a Gate H run. Sources: this run's DB
    # (above); T6's recorded set (async 11.06 + its station chain); T9's
    # ACCEPTED operations from its recorded final states; the coordinator
    # fixtures, whose completed operations are fixed by their own recorded
    # checks (T1: 05.12 accepted; T4: 05.12 + 11.06 accepted; T5: 05.12
    # completed attempts; T7: 12.12 completed attempt); the g4 suite's 03.02
    # (re-verified by T12's regression run of that suite).
    union = set(executed)
    sources = {"g9_full_run": sorted(executed)}
    p = RESULTS / "t6.json"
    if p.exists():
        ops = set(json.loads(p.read_text()).get("data", {})
                  .get("executed_operations", []))
        if ops:
            sources["t6"] = sorted(ops)
            union |= ops
    p = RESULTS / "t9.json"
    if p.exists():
        d = json.loads(p.read_text()).get("data", {})
        ops = {op for phase in ("phase1_final_states", "phase2_final_states")
               for op, s in d.get(phase, {}).items() if s == "ACCEPTED"}
        if ops:
            sources["t9"] = sorted(ops)
            union |= ops
    fixture_ops = {"05.12", "11.06", "12.12"}
    sources["coordinator_fixtures_t1_t4_t5_t7"] = sorted(fixture_ops)
    union |= fixture_ops
    sources["g4_suite_03.02"] = ["03.02"]  # executed by the g4 suite (T12)
    union.add("03.02")
    rec.data["executed_union_sources"] = sources
    rec.data["executed_union"] = sorted(union)
    rec.data["executed_count"] = len(union)
    rec.note(f"192-operation accounting: individually executed in Gate H "
             f"evidence = {len(union)}; defined-and-chained only = "
             f"{192 - len(union)}. The full run itself executes 18; the "
             "remaining operations are defined in the registry and chained "
             "by dependency templates but were not individually executed.")
    (RESULTS / "executed_union.json").write_text(json.dumps(
        {"union": sorted(union), "sources": sources}, indent=2))
    rec.write()


if __name__ == "__main__":
    main()
