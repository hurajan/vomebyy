# GATE H REPORT — End-to-end verification (T1–T12) + production-readiness assessment

**Status: GATE H EXECUTED; results INDEPENDENTLY VERIFIED (the audit stands). 10 of 12 items PASS, T3 BLOCKED by design, T9 FAILS on one CRITICAL defect (D-H1, independently reproduced). Raj RULED 2026-10-28: D-H1 fix design (b) — scheduler pre-stages claims for the executor — with the fix lock confirmed (LOCK_FIX_DH1.md, covering V-H1). Gate H acceptance follows the fix's independent verification + T9 re-run.** Evidence: per-T results `evidence/results/t1–t12.json` (+ `t12-supplement.json`), `evidence/COVERAGE_MATRIX.md`, `evidence/GATE_H_VERIFIER_REPORT.md`, full logs in `evidence/logs/`, harness in `harness/`. Verification-only gate: no product code was changed (verifier scope check: every Gate-A-manifest file matches its pinned SHA-256; all suites pass on current content; unexplained content-preserving mtime clusters in the window are recorded in the verifier report as a MINOR process observation).

## Per-T verdicts

| T | Verdict | Evidence headline |
|---|---|---|
| T1 Coordinator authority | **PASS** (17/17) | Unclaimed/stale/non-claiming-worker completions, phantom callback, role violations on gate decisions — all refused, state unchanged, refusals audited |
| T2 Contract preservation | **PASS** (15/15) | Registry hash ea4503f5… intact; 1.1.0 variant coexists with an untouched 1.0.0 production; gate map exactly HG2/HG4/HG5; TRANSITIONS = 30 |
| T3 Real provider execution | **BLOCKED** (OD-A3) | No execution attempted; negative space verified (14/14): adapters report BLOCKED, refuse unfenced/credential-less work, no fabricated-result path exists |
| T4 Financial integrity | **PASS** (23/23) | Duplicates book nothing twice; claim race → one winner + one HELD reservation; hard-ceiling breach refused + BLOCKED; stale-callback charge flagged, settled once, duplicate settle refused; invariants held after every check |
| T5 Validation independence | **PASS** (5/5) | Worker PASS + invalid deliverable → BLOCKED; worker FAIL advisory + valid output → layers decide (AWAITING_HUMAN); verdict-less units evaluate identically |
| T6 Async + recovery | **PASS** (11/11) | UNKNOWN job reconciled to ACCEPTED, settled once (450¢); full stack killed mid-production and restarted → chain completes, 4 charges / 360¢, zero duplicate CURRENT artifacts |
| T7 Configuration control | **PASS** (13/13) | Mid-flight binding change: attempt 1's snapshot/hash/pricing frozen, attempt 2 resolves v2, audit shows both; production environment fails closed on test bindings |
| T8 Security | **PASS** (14/14) | Negative role matrix 8/8 → 403; no/wrong credentials → 401; workflow JSON hygiene clean; secrets sweep hits confined to vendored n8n cache assets — none in factory code |
| T9 Unattended workflow | **FAIL** (1/4) | **D-H1** below. The passing check: actor attribution was correct for every transition that occurred |
| T10 Representative production | **PASS** (3/3) | Full 16-step production on current machinery: 18 units ACCEPTED, 1620¢ settled |
| T11 Coverage analysis | **PASS** (4/4) | Matrix: 192 operation rows + §5–§17 status table (below) |
| T12 Regression | **PASS** (169/169) | All 13 suites green serially (the t12.json raw FAIL is a parser artifact — singular "Ran 1 test" — corrected by the supplement rerun, verified against the on-disk logs) |

**Operation accounting (exact):** individually executed across the whole programme's evidence = **20** operations (the full run's 18 + 11.06 + 03.02); **172 are defined-and-chained only**. Worker behavior: 19 operations have operation-specific payload builders; the rest run the generic builder. Neither figure is inflated anywhere in this report.

## D-H1 — CRITICAL: unattended composition deadlock (affects §14 scheduling)

The Gate F scheduler claims each READY unit itself (attempt under worker `sched-text`, budget reserved, dispatch event emitted). The Gate G n8n executor — the only execution path — begins by claiming, receives 409 "claim requires READY, unit is CLAIMED", and stops at its claim-refused branch. The unit parks CLAIMED; after lease expiry the reaper/retry loop returns it to the scheduler, which claims it again. Reproduced by the executor in two runs and independently by the verifier, whose control run (identical dispatch, no scheduler claim → normal execution to ACCEPTED) proves the collision is specifically **claim ownership**: Gate F's design says the scheduler claims; Gate G's says the executor claims. Each is internally consistent; they were never composed until T9. The driver-mediated path used by every station suite, T6-B, and T10 is unaffected.

**Companion defect V-H1 (MINOR, verifier-found):** on the dispatcher path the executor's worker identity degrades to the literal `n8n-station-undefined` — it builds `worker_id` from `trigger.station`, which the Gate F dispatcher payload doesn't carry (the Gate G driver payload does). Execution is unaffected; GB-SEC-01's audit granularity is weakened for dispatcher-driven claims. Same seam as D-H1; any fix lock should cover both.

### Fix designs (owner rules; nothing applied)

- **Design (a) — executors own claims.** The scheduler stops claiming: it detects claimable READY units (lane-capacity gated) and emits dispatch events without claiming; the executor claims as today. *Preserves:* Gate G executors unchanged; GB-SEC-01 semantics pristine. *Costs:* the outbox trigger point moves (dispatch_required is currently a claim side effect); lane caps become dispatch-time gating rather than claim-time enforcement; duplicate dispatches are absorbed by claim atomicity (already proven harmless).
- **Design (b) — scheduler pre-stages the claim for the executor.** `scheduler_claim` claims under the executor identity for the unit's station; the attempts snapshot exposes the attempt's fencing token to the WORKER role; the executor gains a resume branch (a CLAIMED attempt under its own identity → proceed from the snapshot instead of claiming); the executor derives its identity from unit/attempt data, not the trigger (fixes V-H1). *Preserves:* Gate F's claim+dispatch atomicity, claim-time lane caps, budget-at-claim. *Costs:* fencing tokens become readable via the attempts endpoint (within the existing role-token trust model — the same token the executor already holds); one new executor branch in five workflows.

## Production-readiness assessment — what stands between this build and real production

1. **D-H1 fix + T9 re-verification** (this report's ruling) — the unattended path is the production path.
2. **OD-A3**: one provider selected + credential via the vault + a recorded spend cap + a binding row → T3 executes. Until then every real-provider path is BLOCKED by design.
3. **EXPERT golden set (50+)**: the semantic layer stays unarmed and every unit routes to a human decision until editorial supplies it.
4. **Deployment**: G0.6 host verification (founder-side), OD-A4 storage endpoint at deployment (S3 mechanics are stub-tested only), and service packaging — the stack currently runs as loose local processes (no systemd/container units, no supervision).
5. **12.12 registry reconciliation**: registry says station 5, the G6 tree serves it — a workflow-version correction or a permanent recorded note; owner decision.
6. **OD-A1**: the trees are still not under version control; baselines are manifest-pinned only.
7. **Real-browser dashboard verification** — still NOT TESTED (headless environment); all dashboard evidence is contract-level.
8. **Production identity**: role tokens work; per-operator identity and audit attribution remain the local model.

## Programme state on acceptance

Gates A–H will then stand: A–G accepted, H's findings accepted with its defect either fixed under a ruled lock or carried open by ruling. §14 (scheduling) is the one requirement area whose status is **implemented but not composed-verified** until D-H1 closes; T3-dependent areas remain BLOCKED on OD-A3.
