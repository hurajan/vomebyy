# Gate C — pre-existing test assertions changed, and why

Rule (LOCK_GATE_C): existing assertions may change ONLY where a fixed
defect requires it. Everything else reproduces unchanged. Suite totals
after Gate C: G1 9 (was 7), G2 42 (was 25), G3 9 (was 5), G4 2, G5 1,
G6 3, G7 2, G8 1, G9 1 + 8, worker_service 11 (new).

## Changed

1. **g2/tests/test_coordinator.py — `TestCascade.test_master_invalidation_needs_authority`** (rewritten)
   - Before: registered an artifact of type `"master"` and asserted
     `invalidate_artifact(...)` raises without `master_authority=True` and
     succeeds with it.
   - After: registers type `"master_package"`; asserts PermissionError
     with no authority and with a self-co-authorizer; success with a
     distinct co-authorizer; success with an APPROVED HG4 gate bound to
     the exact artifact.
   - Why: GB-SEC-02. The old test asserted the defective behavior itself —
     the guard compared against the dead literal `"master"` (the real
     master type is `"master_package"`, so it never fired) and authority
     was a request-body boolean any token holder could assert. Both are
     removed by the lock; the test now asserts the data rule.
   - Also in the same file: `TestCallbacks` and `TestReconciler` were NOT
     rewritten. Their assertions (exactly-once callback effects, reconcile
     to VALIDATING / RETRY_WAIT, poll counts, job statuses) still hold
     verbatim against the rewired B1.2 machinery, because the legacy
     `submit_provider_job` now links the unit's current attempt
     (migration 006) and `handle_callback`/`reconcile_once` converge on
     `_complete_provider_job`. What changed is the mechanism they exercise,
     not what they assert: the callback now also settles the claim's
     reservation and leaves the attempt VALIDATING instead of inserting a
     synthetic 'provider-callback' attempt row (no assertion covered that
     row).

2. **g3/tests/test_api_contract.py — template normalization only** (no
   assertion changed)
   - `contract_keys()` and the final coverage set now also map
     `{job_id}` -> `{id}`, so the new `/provider-jobs/{job_id}/callback`
     contract entry can be matched like every other id parameter. All
     pre-existing assertions, including the full-endpoint-coverage
     assertion, are unchanged and now also cover the five new endpoints.

3. **g3/tests/server_fixture.py — harness extension** (no assertion changed)
   - `Client.call()` gained an optional `headers` argument and
     `start_server()` an optional `env_extra` argument, so the new role
     tests can present X-Role/X-Role-Token credentials and configure
     per-role env tokens. Existing call sites are untouched.

## Explicitly NOT changed (verified green with original assertions)

- G2 `TestBudget` (parallel-claim ceiling, settle/release accounting,
  RESERVE/CHARGE amounts): passes because a caller-supplied estimate
  still wins in claim(); the config estimate applies when the caller
  passes none (design B2.2's "ceiling assertion" reading — see the Gate C
  builder summary for the judgment call).
- G2 `TestScheduler.test_lane_caps_and_fairness` and
  `test_gate_claim.test_scheduler_skips_gated_unit`: scheduler_claim's
  return contract (list of claim dicts) is preserved; the estimate source
  changed from the hardcoded 0 to the resolved binding (FACTORY test
  binding, 100) via the new optional `estimate_for` parameter / config
  resolution, with unresolvable candidates reported in
  `coordinator.last_scheduler_report['skipped_no_config']`.
- G3 dashboard tests: the dashboard never sent `master_authority` (its
  invalidate call sends only `reason`), so removing the field from the
  API required no dashboard edit; the three dashboard tests pass
  unchanged.
- G4–G9 suites: no test file in those trees was modified.

## Workflow payload repair found by the G9 regression (no test assertion changed)

3. **g4–g8 `tools/gen_workflows.py` — unit-executor "Claim unit" node worker_id derivation** (generated `workflows/*.json` regenerated)
   - Before: claim body used `'n8n-station-' + $json.station`. On the
     RETRY_WAIT recovery path, the preceding node is the "Retry unit" HTTP
     call, whose output is the retry API response (no `station` field), so
     the recovery claim went out as worker `n8n-station-undefined`.
   - After: the claim body derives worker_id from the Execute Workflow
     Trigger payload — the exact expression the "submit-candidate"
     (complete) node already used — so claim and completion always present
     the same worker identity on every path.
   - Why: GB-SEC-01 (Gate B finding, implemented in this gate) makes
     completion verify lease/attempt worker binding. The G9 failure
     battery exposed the latent executor inconsistency: recovery claim by
     `n8n-station-undefined`, completion by `n8n-station-3` -> coordinator
     `stale_commit_rejected` -> unit looped in RETRY_WAIT
     (`test_worker_failure_recovers`, `test_worker_failure_recovers_station5`).
     Pre-Gate-C this was invisible because completion checked only the
     fencing token. The security check was NOT weakened; the executor was
     made self-consistent. Gate B's compatibility assumption ("executors
     already pass the claiming worker_id") held on first dispatch and was
     false on redispatch; the evidence is the audit trail of the stuck
     units (claim fencing 2 by n8n-station-undefined, stale_commit_rejected
     for n8n-station-3, attempt 1002 STALE_FENCED).
   - This is a payload bugfix in the workflow generators, not a Gate G
     regeneration: no endpoints, auth, or contract shapes changed; on the
     first-dispatch path the produced worker_id is byte-identical to
     before.
