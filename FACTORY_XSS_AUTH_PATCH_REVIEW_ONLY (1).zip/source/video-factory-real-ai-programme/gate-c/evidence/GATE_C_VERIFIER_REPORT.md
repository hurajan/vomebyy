# GATE C VERIFIER REPORT — Independent verification

**Verifier:** independent (read-only on product trees; own scratch DBs/services only, all dropped/stopped after).
**Scope read first:** gate-c/LOCK_GATE_C.md, gate-c/evidence/CHANGED_ASSERTIONS.md, gate-b/GATE_B_DESIGN.md, gate-b/FIX_PROPOSALS.md.
**Builder's claimed totals:** G1 9, G2 42, G3 9, G4 2, G5 1, G6 3, G7 2, G8 1, G9 9, worker_service 11 = 89.

## Verdict

**VERIFIED WITH ONE MAJOR DEVIATION (item 4f) — no CRITICAL defects; two MINOR notes.**
Every builder claim checked below is CONFIRMED except the estimate-precedence behaviour in item 4f, where the code factually implements the opposite of design B2.2 as written (the builder discloses this choice in CHANGED_ASSERTIONS.md; the ruling on it is the owner's, not this report's).

## Item-by-item findings

### 1. Suite logs — CONFIRMED
Read the full log files on disk in `gate-c/evidence/logs/` (not summaries):
g1.log `Ran 9 tests … OK`; g2.log `Ran 42 tests … OK`; g3.log `Ran 9 tests … OK`;
g4.log `Ran 2 … OK`; g5.log `Ran 1 … OK`; g6.log `Ran 3 … OK`; g7.log `Ran 2 … OK`;
g8.log `Ran 1 … OK`; g9.log `Ran 9 tests … OK`; worker_service.log `Ran 11 tests … OK`.
Total = 89, matching the builder's claim exactly. (Logs are in unittest dot format; the G9 file's 9 = 1 full-run + 8 failure-battery tests — see item 7.)

### 2. FP-01 — CONFIRMED
- `fp01_load_sql_before.sql` and `fp01_load_sql_after.sql` have identical SHA-256:
  `8181e22e514c4fc645963460d27624d0070c93dc7950ca785dd98cbf1cee5628` (both).
- `registry_tool.py validate` run by this verifier: verdict **PASS**, errors/warnings empty,
  `definition_hash = ea4503f516fc4f7940f187f5cd9dac38c57f0d239726cac90e2d0a18a8bc9d73`
  (192 operations, 191 dependencies, stations 24/24/48/36/36/24).
- Code: `build_load_sql(seed_dir=None)` now inserts dependency templates with
  `sql_str(seed["workflow_version"])` (comment cites FP-01/F-G9-01), and `load(db_name, seed_dir=None)`
  accepts a seed directory. The hardcoded `'1.0.0'` template literal is gone.

### 3. Migrations on a chain-built DB — CONFIRMED
Built `gatec_verify_scratch` via `g2/tools/setup_db.py` (dropped after):
- **31 public tables** (29 baseline + `provider_configs` + `financial_evidence`).
- Seed row present and active: `scope=FACTORY, environment=test, provider=mock,
  model=deterministic-mock, est_cost_cents=100, active=t` (inserted idempotently by setup_db).
- `provider_jobs` carries the 006 columns: `attempt_id`, `fencing_token`, `resolved_config_hash`.
- Transitions are **code-resident** (there is no transitions table in the DB — confirmed by full
  table listing): `coordinator.py` `TRANSITIONS` includes
  `("AWAITING_PROVIDER", "transient_error"): "RETRY_WAIT"` (line 33).
  Migration `010_async_transitions.sql` is a documented no-op marker (`SELECT 1;`) recording that
  fact — see MINOR note N2.

### 4. Own coordinator probes (chain-built `gatec_probe_scratch`, dropped after) — CONFIRMED except 4f

**4a Config precedence — CONFIRMED.** Inserted STATION binding (station 3, est 700) and OPERATION
binding (05.12, est 900) into a fresh production:
- claim 05.12 with `estimated_cents=None` → reservation **900** (OPERATION wins);
  the attempt's `resolved_config_hash` equals `sha256(json.dumps(resolved_config, sort_keys=True, default=str))`
  recomputed by this verifier (`543502cb…16e3d05baaf0`, stored == computed); snapshot provider `op-prov`.
- claim 06.12 (station 3, no operation binding) → reservation **700** (STATION wins over FACTORY 100).

**4b GB-SEC-01 worker binding — CONFIRMED.** Claim as `alice`; `complete_attempt` as `bob` with the
**correct** fencing token → `StaleFencing` ("worker binding mismatch … completion by 'bob' refused"),
unit remained `CLAIMED` (uncompleted); completion as `alice` with the same token then succeeded → `VALIDATING`.

**4c FP-02 idempotent gates — CONFIRMED.** Two `create_gate` calls for the same
(production, HG2, artifact) → same `gate_id` (`14a37107…`), first `existing=False`, second
`existing=True`, and exactly **1 row** in `human_gates`.

**4d GB-SEC-02 master rule — CONFIRMED.** Registered a `master_package` artifact:
`invalidate_artifact` with no HG4 → `PermissionError` ("requires an APPROVED HG4 gate bound to the
artifact or a co-authorizer distinct from the actor"); after creating + approving an HG4 gate bound
to that exact artifact → invalidation succeeded (affected list contains the artifact).

**4e Async v2 end-to-end — CONFIRMED.** With an OPERATION binding for 11.06 (est 100) seeded:
claim with no caller estimate → reservation 100 from config; `start`;
`submit_provider_job_v2` with a wrong fencing token → `StaleFencing`, **0 job rows created**;
correct token → unit `AWAITING_PROVIDER`; `handle_callback` (same call pattern as g2's
test_gatec harness) → unit `VALIDATING`, budget settled **90, held 0, exactly 1 CHARGE transaction**;
duplicate callback → `duplicate=True`, settled still 90, CHARGE count still 1.
Stale case (separate production): job submitted, unit parked via `transient_error` → `RETRY_WAIT`,
`retry_unit`, second claim with a strictly greater fencing token; delivery of the **first** job's
callback → outcome `stale_fencing`, job `FAILED` with `raw_response.failure_code = STALE_FENCING`,
**0 artifacts** registered in that production, and the live second attempt untouched (unit `CLAIMED`).

**4f ESTIMATE PRECEDENCE — DEVIATION (see Defect D-C1).** With the OPERATION binding for 05.12
(est **900**) active, a claim passing `estimated_cents=100` produced a reservation of **100**.
Factually: **the caller-supplied estimate wins whenever one is given**; the config estimate is
used only when the caller passes none. Design B2.2 as written says the opposite — the config
`est_cost_cents` is the claim estimate and a caller value is only a *ceiling assertion* that must
be **refused when below** the config estimate. The code contains no such refusal. (The builder
discloses this reading in CHANGED_ASSERTIONS.md under the G2 `TestBudget` note; this report
states the fact and the classification only.)

**4g scheduler_claim — CONFIRMED.** On a fresh chain-built DB (`gatec_sched_scratch`, dropped
after), a READY 11.01 unit was claimed by `scheduler_claim()` with reservation **100** (the FACTORY
config estimate), not 0; unit → `CLAIMED`; `last_scheduler_report` lists it under `claimed`.
Note on method: a first attempt against the shared probe DB returned no claims because
`scheduler_claim` enforces the global per-lane capacity policies (text lane cap 4, already
saturated by earlier probes' in-flight units) — the per-class DB rebuild in the builder's harness
isolates this the same way. Not a defect.

### 5. API role separation — CONFIRMED
Contract JSON lists exactly **27 endpoints** (22 pre-Gate-C + GET/POST /configs,
GET /units/{uid}/attempts, POST /provider-jobs, POST /provider-jobs/{job_id}/callback).
Live probes against the G3 API started by this verifier against the probe DB
(FACTORY_VALIDATOR_TOKEN / FACTORY_WORKER_TOKEN / FACTORY_SCHEDULER_TOKEN /
FACTORY_CALLBACK_TOKEN set; run on port **8731** because port 8730 was already held by a
pre-existing API process, pid 25732, which was left undisturbed — the server code and behaviour
verified are identical; only the listen port differed):
- no credentials → **401**; wrong role token → **401**.
- legacy `X-Operator-Token` → OPERATOR works (GET /productions **200**, GET /configs **200**).
- VALIDATOR + its token → POST claim → **403** ("role VALIDATOR may not call this endpoint");
  POST validate → **404** unknown unit (role accepted, existence reached — as specified).
- WORKER + its token → POST claim → **404** unknown unit (role accepted);
  POST /configs → **403**. VALIDATOR GET /configs → **403** (matrix: OPERATOR/SCHEDULER only).

### 6. Worker service — CONFIRMED
- This verifier re-ran the suite (`g2` venv python, no credential env set):
  **11/11 OK**, including the blocked-adapter tests and the stub-provider async loop.
- `adapters.py`: OpenRouter-compatible, direct-HTTP, and all five HTTP media adapters
  (image/video/speech/transcription/stock) raise `BlockedError` from `execute()`/`submit()` when
  the binding's `credential_ref` env var is unset — they never fabricate a result.
  `service.adapter_health()` reports **BLOCKED** for every credential-requiring adapter with no
  refs configured, READY for deterministic-local; the mock adapter additionally refuses unless
  `params.test_only=true` **and** environment is test.
- No credential values exist in the package: grep for `sk-` literals and `Bearer <value>` across
  adapters.py / service.py / payloads.py (and the g2 coordinator / g3 server) finds **none**; the
  only `Bearer` occurrence is the header construction `f"Bearer {credential}"` fed from the
  environment at call time.
- No commercial-provider binding is hardcoded as a station default anywhere: the only
  `provider_configs` seed in any tree is setup_db's FACTORY/**test** `mock` row; the only
  provider-specific constant in the package is `OpenRouterCompatibleAdapter.DEFAULT_BASE_URL =
  "https://openrouter.ai/api/v1"`, which is used **only** when a binding selects the
  `openrouter-compatible` adapter (and can be overridden per binding via `params.base_url`).
  No provider name appears in the g2 coordinator or g3 API code.

### 7. Changed assertions & workflow repair — CONFIRMED
- CHANGED_ASSERTIONS.md lists exactly **one rewritten pre-existing test**
  (`TestCascade.test_master_invalidation_needs_authority` in g2/tests/test_coordinator.py), plus
  a template-normalization-only change in g3's contract test and a harness extension in
  server_fixture (both explicitly no-assertion-changed). The rewritten test's current form was
  spot-checked in the file: it registers `master_package`, asserts PermissionError with no
  authority and with a self-co-authorizer, and success with a distinct co-authorizer / APPROVED HG4.
- Executor payload fix: all five generators (g4–g8 `tools/gen_workflows.py`) derive the Claim
  node's `worker_id` as `'n8n-station-' + $('Execute Workflow Trigger').item.json.station`
  (trigger-payload expression, identical to the complete node's), and the generated
  `workflows/unit-executor.json` in all five trees contains the same expression in both the claim
  and complete node bodies — JSON was regenerated consistently with the generators.
- The G9 log (item 1) shows 9/9 OK; the failure battery in g9/tests/test_g9_failures.py includes
  `test_worker_failure_recovers` and `test_worker_failure_recovers_station5`, which exercise
  exactly this redispatch path, so both passed in the builder's run.

### 8. Scope discipline — CONFIRMED
- `settle_provider_charge`: **absent** — grep across g2, g3, and the worker service finds no such
  symbol (builder declares it not built; consistent with the Gate C lock, which does not list it).
- Soft-ceiling notification: **absent** — `soft_ceiling_cents` appears only as a stored production
  field and a read-only budget-report field in the API; no crossing check, audit event, or outbox
  notification exists in the coordinator.
- Migrations live in `g2/database/migrations/` as **006_provider_job_linkage.sql,
  007_callback_uniqueness.sql, 008_financial_evidence.sql, 009_provider_configuration.sql,
  010_async_transitions.sql**, all applied by `tools/setup_db.py` in order.
- Dashboard **not rebuilt**: `g3/dashboard/index.html` SHA-256
  `c60d90701736312679d8ab0159b82c40609b55f36a4c858ea3dc46d049662aaf` is **identical** to the
  Gate A source-manifest entry (no edit at all — the API's removal of `master_authority` required
  no dashboard change, consistent with CHANGED_ASSERTIONS.md).

## Defects

- **D-C1 — MAJOR — Estimate precedence contradicts design B2.2 as written (item 4f).**
  Code: a caller-supplied `estimated_cents` always wins; there is no ceiling-assertion refusal
  when the caller value is below the resolved binding's `est_cost_cents` (verified: config 900 +
  caller 100 → reservation 100). Consequences within the code as built: reservations can be made
  below the configured estimate for an operation, so held-budget accounting reflects the caller's
  number rather than the pinned binding's (the hard production ceiling is still enforced at claim,
  the snapshot/hash pinning is unaffected, and settlement uses actual costs). The builder chose
  and disclosed this reading for pre-Gate-C compatibility (CHANGED_ASSERTIONS.md, `TestBudget`
  note; also encoded in test_gatec `test_caller_estimate_still_wins_when_given`). Whether the
  design text or the code reading stands is an owner ruling; this report prescribes neither.

- **N1 — MINOR (method note, not a product defect).** API role probes ran on port 8731 because
  8730 was occupied by a pre-existing API process; and the first scheduler probe needed a fresh
  DB due to global lane-capacity saturation. Neither affects any conclusion.

- **N2 — MINOR (documentation precision).** Migration 010 is a no-op marker (`SELECT 1;`); the
  (AWAITING_PROVIDER, transient_error) entry it "adds" lives in the code-resident TRANSITIONS
  table, as the file's own header states. The lock's phrase "data migration 010 adding the
  transition entry" is therefore satisfied in effect (the entry exists and is exercised —
  item 4e's stale path uses it) but not literally as a schema/data change.

## What was NOT verified
Real-provider execution of any kind (no credentials exist; adapters correctly BLOCKED),
n8n end-to-end regeneration (Gate G scope), dashboard behaviour (unchanged bytes), and the
builder's intermediate/run-1 logs (only the final suite logs were audited).
