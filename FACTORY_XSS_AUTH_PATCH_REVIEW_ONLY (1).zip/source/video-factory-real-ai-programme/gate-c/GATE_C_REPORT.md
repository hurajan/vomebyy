# GATE C REPORT — Provider configuration, adapters, FP-01/FP-02, Gate B implementation bundle

**Status: GATE C COMPLETE + INDEPENDENTLY VERIFIED WITH ONE MAJOR DEVIATION (D-C1, owner ruling required) and one MINOR note — ACCEPTED by Raj 2026-10-28, who ORDERED the D-C1 correction at the API path inside Gate D's lock and thereby CONFIRMED the Gate D lock.** Lock: LOCK_GATE_C.md (Gate B accepted + Gate C lock incl. FP-01/FP-02 confirmed by Raj 2026-10-28). Evidence: full suite logs in `evidence/logs/`, `evidence/CHANGED_ASSERTIONS.md`, verifier report `evidence/GATE_C_VERIFIER_REPORT.md`.

## Results

**Suites (89 total, all green, full logs on disk):** G1 9/9 · G2 42/42 · G3 9/9 · G4 2/2 · G5 1/1 · G6 3/3 · G7 2/2 · G8 1/1 · G9 9/9 · worker_service 11/11. The verifier read the logs directly and re-ran the worker-service suite itself.

**Delivered:**
- **Migrations 006–010 applied for real** (g2/database/migrations, applied by setup_db; chain-built DB = 31 tables) + FACTORY/test mock binding seeded (est 100¢) so resolution always succeeds on chain-built DBs and every accepted suite reproduces.
- **Config resolution in claim**: whole-row ACTION→CAPABILITY→OPERATION→STATION→FACTORY (verifier's own probes: OPERATION 900 beat STATION 700 beat FACTORY 100; snapshot hash recomputed and matching). ESTIMATED evidence at claim, FINALIZED at completion.
- **Async v2** per design B1: claim-bound `submit_provider_job_v2` (wrong fencing → refused, zero job rows), fencing-gated `_complete_provider_job` (callback → VALIDATING, settled exactly once, duplicate callback a no-op; stale callback → FAILED/STALE_FENCING, nothing registered, live attempt untouched), reconciler polls only attempt-linked jobs and reports legacy ones.
- **GB-SEC-01** worker-binding completion check (verifier: completion by a different worker with the *correct* token refused; the claimer completes). **GB-SEC-02** master invalidation by data rule (refused without HG4; succeeds with an APPROVED HG4 on the exact artifact; body boolean gone).
- **FP-01**: loader uses the seed's own version; pre/post load SQL **byte-identical** (SHA-256 8181e22e…), registry hash unchanged; variant-seed test proves 191 templates load under 1.1.0. **FP-02**: duplicate gate creation returns the existing gate (`existing=True`, one row — verifier-confirmed).
- **API**: 27 contract endpoints; five roles with per-endpoint matrix (verifier's live probes: 401 without token, VALIDATOR claim → 403, WORKER configs → 403, legacy operator token unaffected); config CRUD with supersede + audit; provider-job submit/callback endpoints.
- **Worker service** (new package): 8 adapters behind the §8 contract; credential-requiring adapters raise BlockedError with no credential configured and report BLOCKED on /health (verifier re-ran); no credential values anywhere in code; full async loop proven against a local stub provider endpoint through the real coordinator (settled 90¢ once, evidence rows present). Real providers: **BLOCKED / NOT TESTED** (OD-A3 unchanged).

## Defects and deviations

- **D-C1 — MAJOR DEVIATION (ruling required).** Design B2.2 made the config estimate authoritative (caller estimate = ceiling assertion, refused when below config). The code implements the opposite: a caller-supplied estimate always wins (verifier probe: binding est 900 + caller 100 → reservation 100). The builder's rationale is recorded in CHANGED_ASSERTIONS.md: the coordinator budget tests claim with deliberate estimates that a binding would override. Snapshot pinning, hard-ceiling enforcement, and settlement-from-actuals are unaffected. Two clean rulings exist: **(a) ratify caller-wins** as the standing rule and amend the design text; **(b) order the correction at the production path only** — the API claim endpoint resolves config and enforces it (body estimate refused when below config; executors stop sending estimates at Gate G), while the library keeps explicit estimates for unit tests. The builder disclosed the deviation; it was not hidden.
- **N2 — MINOR.** Migration 010 is a no-op marker (`SELECT 1`); the (AWAITING_PROVIDER, transient_error) entry lives in the code-resident TRANSITIONS table, as 010's own header states. Satisfied in effect.
- **Cross-gate defect found and fixed during the build (disclosed by the builder):** GB-SEC-01 exposed that all five station executors claimed with worker_id `n8n-station-undefined` on the redispatch path (claim node read `station` from the retry API response, which has no such field). Pre-Gate-C this was invisible (token-only completion). Fix: claim bodies in all five generators now read the trigger payload, identical to the complete node; workflows regenerated; G9's recovery tests (which exercise exactly this path) pass. The builder also disclosed an earlier premature "G9 green" claim caused by its own mid-run port kill; the final totals above are from clean reruns read off the logs.
- **Not built (recorded, in Gate D's natural scope):** `settle_provider_charge` (failed/stale job charges are recorded as flagged PROVIDER_REPORTED evidence; nothing settles them) and soft-ceiling notifications.

## Changed pre-existing assertions

Exactly one: `test_coordinator.py::TestCascade.test_master_invalidation_needs_authority`, rewritten for GB-SEC-02 (the old test asserted the dead `"master"` literal + body boolean). Everything else is additive, plus the executor payload fix above. Full record: `evidence/CHANGED_ASSERTIONS.md`.

## Next gate as planned (Gate D — needs its own lock)

Durable storage (S3-compatible adapter behind env-configured endpoint — OD-A4 direction still open; local filesystem adapter for dev), candidate staging + coordinator-promoted CURRENT replacing the per-tree stores and the G9 copy bridge, hash/size/type verification, abandoned-candidate cleanup; finance completion: pricing/usage evidence already landing since Gate C — Gate D adds the price-book resolution, `settle_provider_charge`, and soft-ceiling notifications. If ruling (b) is chosen on D-C1, the API estimate enforcement folds into Gate D's lock or a short preceding correction — owner's call.
