"""Lean Phase 3 — op.generate_script (op 08.12 provider-aware seq-2).

STUB_TESTED evidence only: the provider path is exercised against a
LOCAL stub implementing the OpenRouter chat-completions shape. No real
provider request is made anywhere in this file (no credential exists);
the real-provider acceptance stays BLOCKED_EXTERNAL.

Covered:
- dispatch on the pinned binding: deterministic-local / no binding run
  the proven payload builder BYTE-IDENTICAL; openrouter-compatible
  generates inside plan execution; other providers fail explicitly;
- credential absent under a provider binding -> ActionRefused at the
  action, BlockedError out of plan_exec, REFUSED action record, and
  NEVER a deterministic fallback;
- worker-side shaping: canon_refs SET from the actual canon input ref
  (model-supplied values are not trusted), beat/story refs derived
  from the scene/beat inputs when the model omits them, scene coverage
  enforced, unparseable/incomplete output fails explicitly;
- provider evidence: token usage + provider_request_id land in the
  generation action's record output_summary and the plan summary;
- service routing: run_work sends a provider binding for 08.12 through
  plan execution (pin + records + envelope), reports usage and a null
  actual cost (the estimate never poses as measured).
"""
import json
import os
import sys
import threading
import unittest
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from unittest import mock

WS = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(WS))
import actions as actions_mod  # noqa: E402
import adapters as adapters_mod  # noqa: E402
import payloads  # noqa: E402
import plan_exec  # noqa: E402
import plans as plans_mod  # noqa: E402
import service as service_mod  # noqa: E402

CANON_ID = "canon-art-0001"
REFS = [
    {"artifact_type": "canon_manifest", "artifact_id": CANON_ID,
     "sha256": "sha-canon",
     "content": "CANON MANIFEST v1 — universe, chronology, world rules, "
                "knowledge boundaries released."},
    {"artifact_type": "story_architecture", "artifact_id": "story-1",
     "sha256": "sha-story",
     "content": {"kind": "story_architecture",
                 "story_nodes": [{"id": "S1", "summary": "Story node S1"},
                                 {"id": "S2", "summary": "Story node S2"}],
                 "canon_refs": [CANON_ID]}},
    {"artifact_type": "beat_graph", "artifact_id": "beats-1",
     "sha256": "sha-beats",
     "content": {"kind": "beat_graph",
                 "beats": [{"id": "B1", "story_ref": "S1"},
                           {"id": "B2", "story_ref": "S2"}],
                 "canon_refs": [CANON_ID]}},
    {"artifact_type": "scene_set", "artifact_id": "scenes-1",
     "sha256": "sha-scenes",
     "content": {"kind": "scene_set",
                 "scenes": [{"id": "SC1", "beat_ref": "B1",
                             "canon_refs": [CANON_ID]},
                            {"id": "SC2", "beat_ref": "B2",
                             "canon_refs": [CANON_ID]}],
                 "canon_refs": [CANON_ID]}},
]

# The stub model's scripted completion. Deliberate stub authoring:
# line L2 carries a WRONG canon_ref (worker-side shaping must replace
# it with the actual canon artifact id) and line L3 omits beat_ref /
# story_ref (shaping must derive them from the scene/beat inputs).
CANNED_SCRIPT = {
    "kind": "script",
    "lines": [
        {"id": "L1", "scene_ref": "SC1", "beat_ref": "B1",
         "story_ref": "S1", "canon_refs": [CANON_ID],
         "text": "Mara turns the brass key; the clock case swings open."},
        {"id": "L2", "scene_ref": "SC2", "beat_ref": "B2",
         "story_ref": "S2", "canon_refs": ["model-invented-ref"],
         "text": "Tobin bars the archive door and pockets the ledger."},
        {"id": "L3", "scene_ref": "SC1",
         "text": "The ledger is gone; only dust where it lay."},
    ],
    "trace": {
        "clues": [{"id": "CL1", "planted": "L1", "payoff": "L3"}],
        "knowledge": [{"character": "Mara", "learns": "CL1", "at": "L2"}],
        "payoffs": [{"id": "PO1", "clue": "CL1", "line": "L3"}]},
    "canon_refs": [CANON_ID],
}
CANNED_USAGE = {"prompt_tokens": 1500, "completion_tokens": 700,
                "total_tokens": 2200}


class _StubHandler(BaseHTTPRequestHandler):
    mode = "ok"          # ok | error500 | garbage | uncovered
    seen = []

    def log_message(self, *a):
        pass

    def do_POST(self):
        body = json.loads(self.rfile.read(
            int(self.headers.get("Content-Length") or 0)) or b"{}")
        type(self).seen.append(body)
        if type(self).mode == "error500":
            self.send_response(500)
            self.end_headers()
            self.wfile.write(b'{"error": "stub failure"}')
            return
        if type(self).mode == "garbage":
            content = "this is not json at all"
        elif type(self).mode == "uncovered":
            content = json.dumps({**CANNED_SCRIPT, "lines": [
                line for line in CANNED_SCRIPT["lines"]
                if line["scene_ref"] == "SC1"]})
        else:
            content = json.dumps(CANNED_SCRIPT)
        payload = {"id": "chatcmpl-stub-1",
                   "choices": [{"message": {"role": "assistant",
                                            "content": content}}],
                   "usage": CANNED_USAGE}
        raw = json.dumps(payload).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)


class GenerateScriptTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server = ThreadingHTTPServer(("127.0.0.1", 0), _StubHandler)
        cls.port = cls.server.server_address[1]
        cls.thread = threading.Thread(target=cls.server.serve_forever,
                                      daemon=True)
        cls.thread.start()

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()

    def setUp(self):
        _StubHandler.mode = "ok"
        _StubHandler.seen = []
        self._saved_key = os.environ.pop("OPENROUTER_API_KEY", None)

    def tearDown(self):
        os.environ.pop("OPENROUTER_API_KEY", None)
        if self._saved_key is not None:
            os.environ["OPENROUTER_API_KEY"] = self._saved_key

    # ------------------------------------------------------------ helpers
    def binding(self, provider="openrouter-compatible"):
        return {"provider": provider, "model": "anthropic/claude-haiku-4.5",
                "credential_ref": "OPENROUTER_API_KEY",
                "est_cost_cents": 25, "timeout_s": 120,
                "params": {"base_url": f"http://127.0.0.1:{self.port}",
                           "temperature": 0.7, "max_tokens": 2000}}

    def ctx(self, binding):
        plan = plans_mod.get_plan("08.12")
        return actions_mod.ActionContext(
            "08.12", "prod-1", "unit-1", "att-1",
            [dict(r) for r in REFS], plan, binding=binding)

    def deterministic_result(self):
        return payloads.build("08.12", "prod-1", "unit-1",
                              [dict(r) for r in REFS])

    # ------------------------------------------------------------- tests
    def test_deterministic_dispatch_byte_identical(self):
        ctx = self.ctx({"provider": "deterministic-local",
                        "params": {"reported_actual_cents": 90}})
        out = actions_mod.generate_script(ctx, {})
        artifact_type, content = self.deterministic_result()
        self.assertEqual(ctx.result, (artifact_type, content))
        self.assertEqual(out["artifact_type"], "script")
        self.assertIsNone(ctx.provider_evidence)

    def test_no_binding_dispatch_deterministic(self):
        ctx = self.ctx(None)
        actions_mod.generate_script(ctx, {})
        self.assertEqual(ctx.result, self.deterministic_result())

    def test_mock_dispatch_deterministic(self):
        ctx = self.ctx({"provider": "mock"})
        actions_mod.generate_script(ctx, {})
        self.assertEqual(ctx.result, self.deterministic_result())

    def test_unsupported_provider_fails_explicitly(self):
        ctx = self.ctx({"provider": "direct-http-text"})
        with self.assertRaises(actions_mod.ActionFailed):
            actions_mod.generate_script(ctx, {})

    def test_provider_no_credential_refused(self):
        ctx = self.ctx(self.binding())
        with self.assertRaises(actions_mod.ActionRefused):
            actions_mod.generate_script(ctx, {})
        self.assertIsNone(ctx.result)

    def test_provider_stub_generation_and_shaping(self):
        with mock.patch.dict(os.environ,
                             {"OPENROUTER_API_KEY": "stub-local-key"}):
            ctx = self.ctx(self.binding())
            out = actions_mod.generate_script(ctx, {})
        self.assertEqual(out["provider_request_id"], "chatcmpl-stub-1")
        self.assertEqual(out["usage"]["input_tokens"], 1500)
        self.assertEqual(out["usage"]["output_tokens"], 700)
        artifact_type, content = ctx.result
        self.assertEqual(artifact_type, "script")
        script = json.loads(content)
        self.assertEqual(script["kind"], "script")
        self.assertEqual(script["canon_refs"], [CANON_ID])
        self.assertEqual({line["scene_ref"] for line in script["lines"]},
                         {"SC1", "SC2"})
        for line in script["lines"]:
            # canon_refs SET worker-side, never trusted from the model
            self.assertEqual(line["canon_refs"], [CANON_ID])
        derived = [line for line in script["lines"] if line["id"] == "L3"][0]
        self.assertEqual(derived["beat_ref"], "B1")
        self.assertEqual(derived["story_ref"], "S1")
        self.assertEqual(ctx.provider_evidence["provider_request_id"],
                         "chatcmpl-stub-1")
        # the stub received a prompt assembled from the CURRENT inputs
        self.assertEqual(len(_StubHandler.seen), 1)
        prompt = _StubHandler.seen[0]["messages"][0]["content"]
        self.assertIn(CANON_ID, prompt)
        self.assertIn("CANON MANIFEST v1", prompt)
        self.assertIn("SC1", prompt)
        self.assertIn("SC2", prompt)
        self.assertEqual(_StubHandler.seen[0]["model"],
                         "anthropic/claude-haiku-4.5")

    def test_provider_stub_garbage_fails(self):
        _StubHandler.mode = "garbage"
        with mock.patch.dict(os.environ,
                             {"OPENROUTER_API_KEY": "stub-local-key"}):
            ctx = self.ctx(self.binding())
            with self.assertRaises(actions_mod.ActionFailed):
                actions_mod.generate_script(ctx, {})
        self.assertIsNone(ctx.result)

    def test_provider_stub_uncovered_scene_fails(self):
        _StubHandler.mode = "uncovered"
        with mock.patch.dict(os.environ,
                             {"OPENROUTER_API_KEY": "stub-local-key"}):
            ctx = self.ctx(self.binding())
            with self.assertRaises(actions_mod.ActionFailed):
                actions_mod.generate_script(ctx, {})
        self.assertIsNone(ctx.result)

    def test_provider_stub_http500_typed_failure(self):
        _StubHandler.mode = "error500"
        with mock.patch.dict(os.environ,
                             {"OPENROUTER_API_KEY": "stub-local-key"}):
            ctx = self.ctx(self.binding())
            with self.assertRaises(adapters_mod.ProviderError) as caught:
                actions_mod.generate_script(ctx, {})
        self.assertEqual(caught.exception.error_class, "PROVIDER_HTTP_500")
        self.assertIsNone(ctx.result)

    # ------------------------------------------------- plan_exec routing
    def request(self, binding):
        return {"operation_id": "08.12", "production_id": "prod-1",
                "unit_id": "unit-1", "attempt_id": "att-1",
                "provider_binding": binding,
                "input_artifact_refs": [dict(r) for r in REFS]}

    def test_plan_exec_provider_path_records_evidence(self):
        with mock.patch.dict(os.environ,
                             {"OPENROUTER_API_KEY": "stub-local-key"}):
            artifact_type, content, summary = plan_exec.execute_operation(
                self.request(self.binding()))
        self.assertEqual(artifact_type, "script")
        self.assertEqual(summary["usage"]["input_tokens"], 1500)
        self.assertEqual(summary["provider_request_id"], "chatcmpl-stub-1")
        self.assertEqual(summary["plan_hash"],
                         plans_mod.get_plan("08.12")["plan_hash"])
        records = {r["action_key"]: r for r in summary["records"]}
        self.assertEqual(records["op.build"]["status"], "SUCCEEDED")
        gen_summary = records["op.build"]["output_summary"]
        self.assertEqual(gen_summary["provider_request_id"],
                         "chatcmpl-stub-1")
        self.assertEqual(gen_summary["usage"]["output_tokens"], 700)
        self.assertEqual(records["output.emit"]["status"], "SUCCEEDED")
        emit = records["output.emit"]
        self.assertEqual(emit["output_summary"]["keys"],
                         ["artifact_type", "content_sha256",
                          "deliverable_schema", "schema_violations"])
        script = json.loads(content)
        self.assertEqual(script["canon_refs"], [CANON_ID])

    def test_plan_exec_no_credential_blocked_with_refused_record(self):
        sink_records = []

        class Sink:
            def __call__(self, record):
                sink_records.append(record)
        with self.assertRaises(adapters_mod.BlockedError):
            plan_exec.execute_operation(self.request(self.binding()),
                                        sink=Sink())
        by_key = {r["action_key"]: r for r in sink_records}
        self.assertEqual(by_key["inputs.manifest"]["status"], "SUCCEEDED")
        self.assertEqual(by_key["op.build"]["status"], "REFUSED")
        self.assertNotIn("output.emit", by_key)

    def test_plan_exec_deterministic_still_byte_identical(self):
        artifact_type, content, summary = plan_exec.execute_operation(
            self.request({"provider": "deterministic-local"}))
        self.assertEqual((artifact_type, content), self.deterministic_result())
        self.assertNotIn("usage", summary)

    def test_dispatch_detection(self):
        self.assertTrue(plan_exec.plan_uses_provider_dispatch(
            plans_mod.get_plan("08.12")))
        self.assertFalse(plan_exec.plan_uses_provider_dispatch(
            plans_mod.get_plan("05.12")))
        self.assertFalse(plan_exec.plan_uses_provider_dispatch(None))

    # ------------------------------------------------- service routing
    def work_request(self, binding):
        req = self.request(binding)
        req["fencing_token"] = 1
        return req

    def test_service_routes_provider_binding_through_plan(self):
        with mock.patch.dict(os.environ,
                             {"OPENROUTER_API_KEY": "stub-local-key"}):
            code, out = service_mod.run_work(self.binding(),
                                             self.work_request(self.binding()))
        self.assertEqual(code, 200)
        self.assertEqual(out["status"], "COMPLETED")
        self.assertEqual(out["usage"]["input_tokens"], 1500)
        self.assertEqual(out["provider_request_id"], "chatcmpl-stub-1")
        # shipped Gate C convention: cost_cents None falls back to the
        # binding estimate in this field (/complete requires an integer
        # actual); cost honesty is enforced at the evidence layer —
        # the harness asserts FINALIZED settles from CALCULATED
        # pricing evidence, not from this estimate.
        self.assertEqual(out["actual_cost_cents"], 25)
        self.assertEqual(out["plan_execution"]["binding_status"],
                         "FULLY_BOUND")
        envelope = json.loads(out["content"])
        self.assertEqual(envelope["status"], "CANDIDATE")
        self.assertEqual(envelope["step_deliverable"],
                         "Versioned Script + Line IDs")
        entry = envelope["output_artifacts"][0]
        self.assertEqual(entry["artifact_type"], "script")
        self.assertEqual(entry["content"]["kind"], "script")
        self.assertEqual(envelope["evidence"][0]["method"],
                         "openrouter-compatible")

    def test_service_no_credential_blocked(self):
        with self.assertRaises(adapters_mod.BlockedError):
            service_mod.run_work(self.binding(),
                                 self.work_request(self.binding()))


if __name__ == "__main__":
    unittest.main()
