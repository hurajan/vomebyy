"""MM-04 provider gateway tests (STUB_TESTED throughout).

Covers, against LOCAL STUBS only (no real provider contact, no real
credentials):
- context-limit check + MODEL_UNKNOWN (armed registry; refusal before
  any HTTP call);
- bounded retries (500,500 -> 200; usage evidence summed across calls;
  non-decreasing backoff offsets; 400 -> immediate failure);
- authorized fallback (assignment-pinned only; context refusal never
  falls back; no assignment -> failure naming the primary only);
- correlation ids (one chain id in the stub-seen header + every usage
  line; per-call indexes);
- per-provider limiter (max_concurrency observable at the stub;
  min_interval spacing);
- cancellation probe (a cancelled chain stops before the next retry);
- provider_health writes (success / failure / refusal);
- no-bypass surface (/work refuses without a claim binding; the
  service exposes no other adapter entry point).

The gateway's registry checks arm only when a DSN is configured AND
the models table is seeded (LOCK_MM04 arming rule); the scratch DB
here is seeded with fixture model rows.
"""
import json
import os
import re
import subprocess
import sys
import threading
import time
import unittest
import urllib.error
import urllib.request
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

HERE = Path(__file__).resolve().parent
WS_ROOT = HERE.parents[3]
sys.path.insert(0, str(WS_ROOT / "video-factory-real-ai-programme" / "gate-c"))
sys.path.insert(0, str(WS_ROOT / "video-factory-g2"))
sys.path.insert(0, str(HERE.parent))  # worker_service package dir

import psycopg  # noqa: E402

import adapters as adapters_mod  # noqa: E402
import gateway as gateway_mod  # noqa: E402
import service as service_mod  # noqa: E402
from adapters import ProviderError  # noqa: E402

DB = "mm04_worker_scratch"
_setup_src = (WS_ROOT / "video-factory-g2" / "tools" / "setup_db.py").read_text()
_PW = re.search(r"PASSWORD\s+'([^']+)'", _setup_src).group(1)
DSN = f"host=127.0.0.1 dbname={DB} user=factory password={_PW}"
os.environ.setdefault("MM04_STUB_KEY", "mm04-stub-key-not-a-credential")
CRED = os.environ["MM04_STUB_KEY"]
ADAPTER = adapters_mod.OpenRouterCompatibleAdapter()


def setup_scratch_db():
    subprocess.run(
        ["python3", str(WS_ROOT / "video-factory-g3" / "tools" / "setup_db.py"), DB],
        check=True, capture_output=True, text=True)


def seed_models():
    with psycopg.connect(DSN, autocommit=True) as conn:
        conn.execute("DELETE FROM models")
        conn.execute("DELETE FROM provider_health")
        for mid, ctx in (("acme/primary", 100000), ("acme/fallback", 100000),
                         ("acme/tiny", 10)):
            conn.execute(
                "INSERT INTO models(model_id, provider, context_length)"
                " VALUES (%s, 'acme', %s)", (mid, ctx))


# ------------------------------------------------------------------ stub
class Stub:
    """Programmable OpenAI-shaped stub; behavior(model, call_no) ->
    (status, body_dict, latency_s). Records calls, headers, in-flight."""

    def __init__(self, behavior):
        self.behavior = behavior
        self.calls = []          # (model, headers, at)
        self.inflight = 0
        self.max_inflight = 0
        self.lock = threading.Lock()
        stub = self

        class H(BaseHTTPRequestHandler):
            def log_message(self, *a):
                pass

            def do_POST(self):
                n = int(self.headers.get("Content-Length") or 0)
                body = json.loads(self.rfile.read(n) or b"{}")
                model = body.get("model")
                with stub.lock:
                    stub.inflight += 1
                    stub.max_inflight = max(stub.max_inflight, stub.inflight)
                    stub.calls.append((model, dict(self.headers), time.time()))
                    call_no = len([c for c in stub.calls if c[0] == model])
                try:
                    status, payload, latency = stub.behavior(model, call_no)
                    if latency:
                        time.sleep(latency)
                    raw = json.dumps(payload).encode()
                    self.send_response(status)
                    self.send_header("Content-Type", "application/json")
                    self.send_header("Content-Length", str(len(raw)))
                    self.end_headers()
                    self.wfile.write(raw)
                finally:
                    with stub.lock:
                        stub.inflight -= 1

        self.httpd = ThreadingHTTPServer(("127.0.0.1", 0), H)
        self.port = self.httpd.server_address[1]
        threading.Thread(target=self.httpd.serve_forever, daemon=True).start()

    @property
    def url(self):
        return f"http://127.0.0.1:{self.port}"

    def count(self, model=None):
        with self.lock:
            return len([c for c in self.calls
                        if model is None or c[0] == model])

    def stop(self):
        self.httpd.shutdown()


def ok_body(text, usage=None, rid="req-ok"):
    return {"id": rid, "choices": [{"message": {"content": text}}],
            "usage": usage or {"prompt_tokens": 10, "completion_tokens": 20}}


def binding(model="acme/primary", stub=None, assignment=None, **params):
    p = {"base_url": stub.url if stub else "http://127.0.0.1:1"}
    p.update(params)
    b = {"provider": "openrouter-compatible", "model": model,
         "credential_ref": "MM04_STUB_KEY", "timeout_s": 30,
         "retry_policy": {"base_s": 0.05, "max_s": 0.2}, "params": p}
    if assignment is not None:
        b["model_assignment"] = assignment
    return b


def request(prompt="write a short script", **kw):
    req = {"operation_id": "08.12", "production_id": "p", "unit_id": "u",
           "attempt_id": "a", "fencing_token": 1, "prompt": prompt,
           "input_refs": [], "deadline_s": 60}
    req.update(kw)
    return req


def chain(b, req, ctx):
    return gateway_mod.execute_chain(ADAPTER, b, req, CRED, ctx)


def setUpModule():
    setup_scratch_db()
    seed_models()


class GatewayChainTests(unittest.TestCase):
    def setUp(self):
        gateway_mod.reset_limiters()
        self.ctx = gateway_mod.GatewayContext(dsn=DSN)
        self.assertTrue(gateway_mod.registry_armed(DSN))

    def tearDown(self):
        gateway_mod.reset_limiters()

    def test_context_limit_refusal_before_http(self):
        stub = Stub(lambda m, n: (200, ok_body("x"), 0))
        self.addCleanup(stub.stop)
        with self.assertRaises(ProviderError) as cm:
            chain(binding("acme/tiny", stub), request("x" * 400), self.ctx)
        self.assertEqual(cm.exception.error_class, "CONTEXT_LIMIT")
        self.assertEqual(stub.count(), 0)  # refusal before any HTTP call
        lines = cm.exception.gateway["usage_lines"]
        self.assertEqual(lines[0]["outcome"], "refused")
        self.assertEqual(lines[0]["error_class"], "CONTEXT_LIMIT")
        self.assertGreater(lines[0]["estimated_prompt_tokens"], 10)

    def test_model_unknown_refusal(self):
        stub = Stub(lambda m, n: (200, ok_body("x"), 0))
        self.addCleanup(stub.stop)
        with self.assertRaises(ProviderError) as cm:
            chain(binding("acme/ghost", stub), request(), self.ctx)
        self.assertEqual(cm.exception.error_class, "MODEL_UNKNOWN")
        self.assertEqual(stub.count(), 0)

    def test_retry_500_500_200_usage_summed(self):
        def behavior(model, n):
            if n < 3:
                return 500, {"error": {"message": "boom"},
                             "usage": {"prompt_tokens": 3,
                                       "completion_tokens": 1}}, 0
            return 200, ok_body("done", {"prompt_tokens": 10,
                                         "completion_tokens": 20}), 0
        stub = Stub(behavior)
        self.addCleanup(stub.stop)
        result = chain(binding(stub=stub), request(), self.ctx)
        self.assertEqual(result["content"], "done")
        self.assertEqual(stub.count(), 3)
        # usage summed across ALL calls incl. provider-reported error usage
        self.assertEqual(result["usage"], {"input_tokens": 16, "output_tokens": 22})
        lines = result["gateway"]["usage_lines"]
        self.assertEqual([l["call_index"] for l in lines], [0, 1, 2])
        self.assertEqual([l["outcome"] for l in lines],
                         ["error", "error", "success"])
        offsets = [l["started_offset_s"] for l in lines]
        self.assertEqual(offsets, sorted(offsets))  # backoff non-decreasing
        cids = {l["correlation_id"] for l in lines}
        self.assertEqual(len(cids), 1)
        seen = {next((v for k, v in c[1].items()
                      if k.lower() == "x-correlation-id"), None)
                for c in stub.calls}
        self.assertEqual(seen, cids)  # header carried the chain id

    def test_non_retryable_400_immediate(self):
        stub = Stub(lambda m, n: (400, {"error": {"message": "bad"}}, 0))
        self.addCleanup(stub.stop)
        with self.assertRaises(ProviderError) as cm:
            chain(binding(stub=stub), request(), self.ctx)
        self.assertEqual(cm.exception.error_class, "PROVIDER_HTTP_400")
        self.assertEqual(stub.count(), 1)

    def test_fallback_success_after_primary_500s(self):
        def behavior(model, n):
            if model == "acme/primary":
                return 500, {"error": {"message": "down"}}, 0
            return 200, ok_body("fallback text",
                                {"prompt_tokens": 7, "completion_tokens": 8},
                                rid="req-fb"), 0
        stub = Stub(behavior)
        self.addCleanup(stub.stop)
        b = binding(stub=stub, assignment={
            "primary_model": "acme/primary", "fallback_model": "acme/fallback"})
        result = chain(b, request(), self.ctx)
        self.assertEqual(result["content"], "fallback text")
        self.assertEqual(stub.count("acme/primary"), 3)   # 1 + 2 retries
        self.assertEqual(stub.count("acme/fallback"), 1)  # executed once
        gw = result["gateway"]
        self.assertEqual(gw["model"], "acme/fallback")    # executed model
        self.assertEqual(gw["fallback_event"]["primary_model"], "acme/primary")
        self.assertEqual(gw["fallback_event"]["fallback_model"], "acme/fallback")
        self.assertEqual(gw["fallback_event"]["trigger_class"], "PROVIDER_HTTP_500")
        self.assertEqual(result["provider_request_id"], "req-fb")

    def test_no_assignment_failure_names_primary_only(self):
        stub = Stub(lambda m, n: (500, {"error": {"message": "down"}}, 0))
        self.addCleanup(stub.stop)
        with self.assertRaises(ProviderError) as cm:
            chain(binding(stub=stub), request(), self.ctx)
        self.assertEqual(cm.exception.error_class, "PROVIDER_HTTP_500")
        self.assertEqual(stub.count(), 3)
        self.assertEqual({c[0] for c in stub.calls}, {"acme/primary"})
        self.assertIsNone(cm.exception.gateway["fallback_event"])

    def test_assignment_without_fallback_no_swap(self):
        stub = Stub(lambda m, n: (500, {"error": {"message": "down"}}, 0))
        self.addCleanup(stub.stop)
        b = binding(stub=stub, assignment={
            "primary_model": "acme/primary", "fallback_model": None})
        with self.assertRaises(ProviderError):
            chain(b, request(), self.ctx)
        self.assertEqual({c[0] for c in stub.calls}, {"acme/primary"})

    def test_context_refusal_never_falls_back(self):
        stub = Stub(lambda m, n: (200, ok_body("x"), 0))
        self.addCleanup(stub.stop)
        b = binding("acme/tiny", stub, assignment={
            "primary_model": "acme/tiny", "fallback_model": "acme/fallback"})
        with self.assertRaises(ProviderError) as cm:
            chain(b, request("y" * 400), self.ctx)
        self.assertEqual(cm.exception.error_class, "CONTEXT_LIMIT")
        self.assertEqual(stub.count(), 0)  # neither primary nor fallback called

    def test_cancel_probe_stops_chain_before_next_retry(self):
        stub = Stub(lambda m, n: (500, {"error": {"message": "down"}}, 0))
        self.addCleanup(stub.stop)
        checks = {"n": 0}

        def probe():
            checks["n"] += 1
            return checks["n"] >= 2  # cancel lands after the 2nd call
        ctx = gateway_mod.GatewayContext(dsn=DSN, cancel_check=probe)
        with self.assertRaises(ProviderError) as cm:
            chain(binding(stub=stub), request(), ctx)
        self.assertEqual(cm.exception.error_class, "CANCELLED")
        self.assertEqual(stub.count(), 2)  # the queued 3rd call never fired

    def test_min_interval_spacing(self):
        stub = Stub(lambda m, n: (200, ok_body("x"), 0))
        self.addCleanup(stub.stop)
        b = binding(stub=stub, min_interval_ms=300)
        t0 = time.time()
        for _ in range(3):
            chain(b, request(), self.ctx)
        self.assertGreaterEqual(time.time() - t0, 0.55)

    def test_health_rows_written(self):
        ok_stub = Stub(lambda m, n: (200, ok_body("x"), 0))
        bad_stub = Stub(lambda m, n: (500, {"error": {"message": "d"}}, 0))
        self.addCleanup(ok_stub.stop)
        self.addCleanup(bad_stub.stop)
        with psycopg.connect(DSN, autocommit=True) as conn:
            conn.execute("DELETE FROM provider_health")
        chain(binding(stub=ok_stub), request(), self.ctx)
        with self.assertRaises(ProviderError):
            chain(binding(stub=bad_stub), request(), self.ctx)
        with self.assertRaises(ProviderError):
            chain(binding("acme/tiny", ok_stub), request("z" * 400), self.ctx)
        with psycopg.connect(DSN, autocommit=True) as conn:
            rows = conn.execute(
                "SELECT status, detail FROM provider_health"
                " WHERE provider='openrouter-compatible' ORDER BY checked_at"
            ).fetchall()
        statuses = [r[0] for r in rows]
        self.assertIn("ok", statuses)
        self.assertIn("error", statuses)
        self.assertIn("refused", statuses)
        for _, detail in rows:
            self.assertNotIn("MM04_STUB_KEY", detail or "")
            self.assertNotIn("write a short script", detail or "")


def http(method, port, path, body=None):
    req = urllib.request.Request(f"http://127.0.0.1:{port}{path}", method=method)
    data = None
    if body is not None:
        data = json.dumps(body).encode()
        req.add_header("Content-Type", "application/json")
    try:
        with urllib.request.urlopen(req, data=data, timeout=30) as r:
            return r.status, json.loads(r.read() or b"{}")
    except urllib.error.HTTPError as e:
        raw = e.read()
        try:
            return e.code, json.loads(raw or b"{}")
        except json.JSONDecodeError:
            return e.code, {"raw": raw.decode(errors="replace")}


def _serve(handler):
    srv = ThreadingHTTPServer(("127.0.0.1", 0), handler)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return srv, srv.server_address[1]


class ServiceSurfaceTests(unittest.TestCase):
    """Concurrency through the real service + the no-bypass surface."""

    @classmethod
    def setUpClass(cls):
        cls.proc, cls.port = _serve(service_mod.Handler)

    @classmethod
    def tearDownClass(cls):
        cls.proc.shutdown()

    def setUp(self):
        gateway_mod.reset_limiters()

    def tearDown(self):
        gateway_mod.reset_limiters()

    def test_concurrency_capped_at_binding_limit(self):
        stub = Stub(lambda m, n: (200, ok_body("slow"), 0.4))
        self.addCleanup(stub.stop)
        b = binding(stub=stub, max_concurrency=3)
        results = {}

        def call(i):
            results[i] = http("POST", self.port, "/work", {
                "operation_id": "01.01", "production_id": "p",
                "unit_id": str(uuid.uuid4()), "attempt_id": str(uuid.uuid4()),
                "fencing_token": 1, "provider_binding": b,
                "input_refs": [{"kind": "text", "text": "hi"}],
                "idempotency_key": f"conc-{i}", "deadline_s": 60})
        threads = [threading.Thread(target=call, args=(i,)) for i in range(8)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()
        self.assertEqual(len(results), 8)
        for i, (status, _) in results.items():
            self.assertEqual(status, 200, (i, results[i]))
        self.assertLessEqual(stub.max_inflight, 3)
        self.assertGreaterEqual(stub.max_inflight, 2)  # calls did overlap

    def test_work_refuses_without_claim_context(self):
        # no provider_binding at all
        status, out = http("POST", self.port, "/work",
                           {"operation_id": "01.01", "unit_id": "u"})
        self.assertEqual(status, 400)
        self.assertIn("provider_binding", out["error"])
        # binding present but claim fields missing
        status, out = http("POST", self.port, "/work", {
            "provider_binding": {"provider": "deterministic-local"}})
        self.assertEqual(status, 400)
        self.assertIn("operation_id and unit_id", out["error"])

    def test_no_other_adapter_entry_points(self):
        for path in ("/execute", "/adapters", "/adapters/openrouter-compatible",
                     "/invoke", "/chat/completions"):
            status, _ = http("POST", self.port, path, {})
            self.assertEqual(status, 404, path)
        status, _ = http("GET", self.port, "/work")
        self.assertEqual(status, 404)


if __name__ == "__main__":
    unittest.main()
