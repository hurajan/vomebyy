"""Gate G worker-service tests: OD-E1 (iii) envelope production, input
unwrapping from the Gate D store, the force_fail test hook, and the
reported_actual_cents binding param.

Envelope/deliverable validity is checked with the Gate E subset schema
engine against the real contract files (the same engine + schemas the
evaluation service will apply downstream).
"""
import hashlib
import json
import sys
import tempfile
import unittest
from pathlib import Path

WS = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(WS))
import adapters as adapters_mod  # noqa: E402
import envelope as envelope_mod  # noqa: E402
import service as service_mod  # noqa: E402

GATE_D = Path.home() / "workspace/video-factory-real-ai-programme/gate-d"
sys.path.insert(0, str(GATE_D))
from storage_service import LocalStorage  # noqa: E402

GATE_E = Path.home() / "workspace/video-factory-real-ai-programme/gate-e/evaluation_service"
sys.path.insert(0, str(GATE_E))
import schema_engine  # noqa: E402

G1 = Path.home() / "workspace/video-factory-g1/contracts"
BINDING = {"provider": "deterministic-local", "model": "det-v1",
           "est_cost_cents": 100, "params": {}}


def work(op, refs=(), binding=None, **extra):
    req = {"operation_id": op, "production_id": "prod-g", "unit_id": "unit-g",
           "attempt_id": "attempt-g", "config_hash": "c" * 64,
           "input_artifact_refs": list(refs), **extra}
    return service_mod.run_work(binding or dict(BINDING), req)


class EnvelopeBase(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.mkdtemp(prefix="gate-g-worker-store-")
        cls.store = LocalStorage(cls.tmp)
        service_mod._STORAGE = cls.store

    def put(self, data: bytes):
        cand = self.store.put_candidate(data)
        return self.store.promote(cand["uri"]), cand["sha256"]


class TestEnvelopeProduction(EnvelopeBase):
    def test_exit_wrapped_and_valid(self):
        code, out = work("05.12", refs=[{"artifact_id": "canon-1",
                                         "artifact_type": "canon_manifest",
                                         "content": {"kind": "canon_manifest"}}])
        self.assertEqual(code, 200)
        env = json.loads(out["content"])
        out_schema = json.loads((G1 / "step-05/output.schema.json").read_text())
        self.assertEqual(schema_engine.validate(env, out_schema), [])
        self.assertEqual(env["status"], "CANDIDATE")
        self.assertEqual(env["step_deliverable"],
                         "Story Architecture + Experience Map")
        entry = env["output_artifacts"][0]
        self.assertEqual(entry["artifact_type"], "story_architecture")
        deliverable = json.loads(
            (G1 / "deliverables/step-05.schema.json").read_text())
        self.assertEqual(schema_engine.validate(entry["content"], deliverable), [])
        self.assertEqual(entry["sha256"],
                         envelope_mod.canonical_sha(entry["content"]))
        self.assertEqual(env["evidence"][0]["validator"], "worker_provenance")
        self.assertIn("attempt-g", env["evidence"][0]["detail"])

    def test_string_payload_exit_wrapped(self):
        code, out = work("03.12")
        env = json.loads(out["content"])
        self.assertIsInstance(env["output_artifacts"][0]["content"], str)
        self.assertTrue(env["output_artifacts"][0]["content"]
                        .startswith("CANON MANIFEST v1"))
        self.assertEqual(env["step_deliverable"], "Canon Manifest")

    def test_non_exit_and_1401_stay_bare(self):
        _, out = work("03.02")
        self.assertTrue(out["content"].startswith("SOURCE REGISTRATION"))
        _, out = work("14.01", refs=[{"artifact_id": "m-1",
                                      "artifact_type": "master_package",
                                      "content": {"kind": "master_package",
                                                  "asset_hashes": ["a" * 64]}}])
        doc = json.loads(out["content"])
        self.assertEqual(doc["kind"], "derivative_portfolio")
        self.assertNotIn("output_artifacts", doc)

    def test_force_fail_hook(self):
        with self.assertRaises(adapters_mod.ProviderError) as cm:
            work("05.12", force_fail=True)
        self.assertEqual(cm.exception.error_class, "FORCED_FAILURE")


class TestInputUnwrapping(EnvelopeBase):
    def test_envelope_input_unwrapped_for_builder(self):
        # a script produced upstream arrives as envelope bytes in the store
        code, script_out = work("08.12", refs=[
            {"artifact_id": "canon-9", "artifact_type": "canon_manifest",
             "content": {"kind": "canon_manifest"}}])
        self.assertEqual(code, 200)
        _, sha = self.put(script_out["content"].encode())
        code, out = work("09.12", refs=[
            {"artifact_id": "script-9", "artifact_type": "script",
             "sha256": sha, "storage_uri": "store://objects/" + sha}])
        self.assertEqual(code, 200)
        env = json.loads(out["content"])
        deliverable = env["output_artifacts"][0]["content"]
        self.assertEqual(deliverable["script_ref"], "script-9")
        self.assertEqual({d["line_ref"] for d in deliverable["directions"]},
                         {"L1", "L2", "L3"})

    def test_missing_bytes_degrade_to_none_content(self):
        code, out = work("05.12", refs=[
            {"artifact_id": "canon-x", "artifact_type": "canon_manifest",
             "sha256": "f" * 64, "storage_uri": "store://objects/" + "f" * 64}])
        self.assertEqual(code, 200)  # builder fallback, never a crash
        env = json.loads(out["content"])
        self.assertEqual(env["output_artifacts"][0]["content"]["canon_refs"],
                         ["canon-x"])


class TestReportedActual(unittest.TestCase):
    def test_param_wins(self):
        binding = {"provider": "deterministic-local", "est_cost_cents": 100,
                   "params": {"reported_actual_cents": 90}}
        _, out = work("01.01", binding=binding)
        self.assertEqual(out["actual_cost_cents"], 90)

    def test_default_is_estimate(self):
        _, out = work("01.01")
        self.assertEqual(out["actual_cost_cents"], 100)


if __name__ == "__main__":
    unittest.main(verbosity=2)
