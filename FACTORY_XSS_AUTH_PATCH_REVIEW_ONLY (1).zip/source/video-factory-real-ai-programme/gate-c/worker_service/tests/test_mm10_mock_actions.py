"""MM-10 tests — explicitly simulated mock action implementations.

The four action classes Gate 04 left UNBOUND (creative.generate,
media.generate, external.platform, external.provider) are bound to
mock.* implementations for the MM-10 full mock end-to-end acceptance:

- they execute ONLY under a pinned 'mock' binding and produce
  deterministic fixture outputs that carry simulated: true + the
  generator name in-band;
- under any other binding (deterministic-local, a credentialed
  provider, or none) they REFUSE (ActionRefused -> BlockedError):
  BLOCKED evidence, never a silent fallback, never a simulated
  result under a non-mock label;
- media.generate produces REAL lavfi media bytes (stored +
  probe-validated) labeled SIMULATED_MEDIA — real bytes, simulated
  content;
- the plan accounting is pinned: 137 FULLY_BOUND = 79 genuinely
  bound + 58 executable only via simulation; human.decision (28) and
  semantic.evaluate (27) stay UNBOUND.

No network, no credentials, no database.
"""
import atexit
import json
import os
import shutil
import sys
import tempfile
import unittest
from pathlib import Path

WS = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(WS))
import actions as actions_mod  # noqa: E402
import adapters as adapters_mod  # noqa: E402
import media_tools as mt  # noqa: E402
import plan_exec  # noqa: E402
import plans as plans_mod  # noqa: E402

TMP = Path(tempfile.mkdtemp(prefix="mm10-tests-"))
atexit.register(shutil.rmtree, TMP, ignore_errors=True)
# setdefault, per the suite convention (test_worker_service.py):
# test_mm06_media stores its source media at import time under the
# root in force then; a hard override here would strand those bytes
# when the suites run together under unittest discover.
os.environ.setdefault("FACTORY_STORAGE_ROOT", str(TMP / "store"))
os.environ.setdefault("FACTORY_STORAGE_BACKEND", "local")

MOCK = {"provider": "mock", "params": {"test_only": True}}
DET = {"provider": "deterministic-local"}
ORC = {"provider": "openrouter-compatible", "model": "x/y",
       "credential_ref": "OPENROUTER_API_KEY"}

RECORDS_REF = {"artifact_type": "research_notes", "artifact_id": "rn-1",
               "sha256": "s1",
               "content": {"items": [{"id": "N1", "topic": "harbour"},
                                     {"id": "N2", "topic": "ledger"}]}}


def _req(op, refs=(), binding=MOCK):
    req = {"operation_id": op, "production_id": "p", "unit_id": "u",
           "input_artifact_refs": list(refs)}
    if binding is not None:
        req["provider_binding"] = binding
    return req


def _derived(content, key):
    return json.loads(content)["derived"][key]


class TestDispatchDiscipline(unittest.TestCase):
    """The mock implementations are fail-closed on the pinned binding."""

    def test_creative_executes_under_mock_binding(self):
        atype, content, summary = plan_exec.execute_operation(
            _req("01.04", [RECORDS_REF]))
        self.assertEqual(atype, plans_mod.get_plan("01.04")
                         ["output_artifact_type"])
        gen = _derived(content, "creative_generate")
        self.assertTrue(gen["simulated"])
        self.assertEqual(gen["generator"], "mock.creative.generate")
        self.assertEqual(gen["count"], 2)
        self.assertEqual([r["derived_from"] for r in gen["records"]],
                         ["input:research_notes"] * 2)
        self.assertTrue(all(r["simulated"] for r in gen["records"]))
        self.assertIn("SIMULATED", gen["records"][0]["fixture_text"])
        self.assertEqual([a["status"] for a in summary["actions"]],
                         ["SUCCEEDED"] * len(summary["actions"]))

    def test_creative_output_is_input_sensitive(self):
        _, c1, _ = plan_exec.execute_operation(_req("01.04", [RECORDS_REF]))
        other = {"artifact_type": "research_notes", "artifact_id": "rn-2",
                 "sha256": "s2",
                 "content": {"items": [{"id": "N9", "topic": "archive"}]}}
        _, c2, _ = plan_exec.execute_operation(_req("01.04", [other]))
        self.assertNotEqual(c1, c2)
        self.assertEqual(_derived(c2, "creative_generate")["count"], 1)

    def test_refused_under_deterministic_binding(self):
        records = []
        with self.assertRaises(adapters_mod.BlockedError):
            plan_exec.execute_operation(_req("01.04", [RECORDS_REF], DET),
                                        sink=records.append)
        refused = [r for r in records if r["status"] == "REFUSED"]
        self.assertEqual(len(refused), 1)
        self.assertEqual(refused[0]["action_key"], "creative_generate")
        self.assertIn("only under a pinned 'mock' binding",
                      refused[0]["error"])

    def test_refused_under_credentialed_binding(self):
        with self.assertRaises(adapters_mod.BlockedError):
            plan_exec.execute_operation(_req("01.04", [RECORDS_REF], ORC))

    def test_refused_without_binding(self):
        with self.assertRaises(adapters_mod.BlockedError):
            plan_exec.execute_operation(_req("01.04", [RECORDS_REF], None))

    def test_refusal_propagates_through_deterministic_adapter(self):
        # The service overwrites request["provider_binding"] with the
        # dispatched binding before calling the adapter; mirror that.
        adapter = adapters_mod.DeterministicLocalAdapter()
        with self.assertRaises(adapters_mod.BlockedError):
            adapter.execute(DET, _req("01.04", [RECORDS_REF], DET))

    def test_mock_adapter_requires_test_only(self):
        adapter = adapters_mod.MockAdapter()
        adapter.environment = "test"
        with self.assertRaises(adapters_mod.BlockedError):
            adapter.execute({"provider": "mock", "params": {}},
                            _req("01.04", [RECORDS_REF]))
        out = adapter.execute(MOCK, _req("01.04", [RECORDS_REF]))
        self.assertEqual(out["usage"], {"mock": True})
        self.assertTrue(_derived(out["content"], "creative_generate")
                        ["simulated"])


class TestSimulatedImplementations(unittest.TestCase):
    def test_media_generate_real_bytes_labeled_simulated(self):
        _atype, content, _summary = plan_exec.execute_operation(
            _req("11.06", []))
        gen = _derived(content, "media_generate")
        self.assertTrue(gen["simulated"])
        self.assertEqual(gen["label"], "SIMULATED_MEDIA")
        media = gen["media_output"]
        data = mt.fetch_media_bytes(media["sha256"])
        self.assertIsNotNone(data)
        probe = mt.probe_bytes(data)
        self.assertEqual(mt.first_stream(probe, "video")["codec"], "h264")
        self.assertEqual(mt.first_stream(probe, "audio")["codec"], "aac")
        self.assertAlmostEqual(probe["duration_s"], 2.0, delta=0.4)

    def test_platform_receipt_labeling_and_determinism(self):
        _a1, c1, _s1 = plan_exec.execute_operation(_req("15.07", []))
        _a2, c2, _s2 = plan_exec.execute_operation(_req("15.07", []))
        r1 = _derived(c1, "external_platform")["receipt"]
        r2 = _derived(c2, "external_platform")["receipt"]
        self.assertTrue(r1["simulated"])
        self.assertEqual(r1["status"], "SIMULATED")
        self.assertEqual(r1["provider"], "mock-platform-publisher")
        self.assertEqual(r1["receipt_id"], r2["receipt_id"])

    def test_provider_records_derived_from_text(self):
        ref = {"artifact_type": "source_text", "artifact_id": "st-1",
               "sha256": "s9",
               "content": "The door was locked. The ledger was missing. "
                          "A key was found behind the clock."}
        _atype, content, _s = plan_exec.execute_operation(
            _req("03.03", [ref]))
        gen = _derived(content, "external_provider")
        self.assertTrue(gen["simulated"])
        self.assertEqual(gen["interaction"]["contacted"], False)
        self.assertGreaterEqual(gen["count"], 2)
        self.assertTrue(all(r["simulated"] for r in gen["records"]))

    def test_mixed_plan_structural_actions_stay_real(self):
        # 08.11: extract + metrics are genuine deterministic actions;
        # only the creative core is simulated, and the composed
        # document shows both provenances side by side.
        ref = {"artifact_type": "script", "artifact_id": "sc-1",
               "sha256": "s7",
               "content": {"lines": [{"id": "L1", "duration_s": 30},
                                     {"id": "L2", "duration_s": 45}]}}
        _atype, content, summary = plan_exec.execute_operation(
            _req("08.11", [ref]))
        doc = json.loads(content)
        self.assertEqual(doc["derived"]["records.metrics"]["metrics"]
                         ["duration_s"]["sum"], 75)
        self.assertTrue(doc["derived"]["creative_generate"]["simulated"])
        self.assertEqual([a["status"] for a in summary["actions"]],
                         ["SUCCEEDED"] * len(summary["actions"]))


class TestPlanAccounting(unittest.TestCase):
    def test_counts_and_partition(self):
        doc = plans_mod.load_plans()
        plans = {p["operation_id"]: p for p in doc["plans"]}
        fully = [op for op, p in plans.items()
                 if p["binding_status"] == "FULLY_BOUND"]
        mockexec = [op for op in fully
                    if any((a.get("implementation") or "")
                           .startswith("mock.")
                           for a in plans[op]["actions"])]
        self.assertEqual(len(fully), 137)
        self.assertEqual(len(mockexec), 58)
        self.assertEqual(len(fully) - len(mockexec), 79)
        unbound_kinds = {}
        for op, p in plans.items():
            for a in p["actions"]:
                if a["binding_status"] == "UNBOUND":
                    unbound_kinds.setdefault(
                        a["declared_implementation"], []).append(op)
        self.assertEqual({k: len(v) for k, v in unbound_kinds.items()},
                         {"human.decision": 28, "semantic.evaluate": 27})

    def test_mock_actions_carry_no_declared_unbound_fields(self):
        doc = plans_mod.load_plans()
        for p in doc["plans"]:
            for a in p["actions"]:
                if (a.get("implementation") or "").startswith("mock."):
                    self.assertEqual(a["binding_status"], "BOUND")
                    self.assertNotIn("unbound_reason", a)


if __name__ == "__main__":
    unittest.main()
