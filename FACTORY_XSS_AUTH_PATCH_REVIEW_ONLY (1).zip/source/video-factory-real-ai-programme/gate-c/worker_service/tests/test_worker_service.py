"""Gate C worker-service tests.

- Credential discipline: credential-requiring adapters REFUSE (BlockedError)
  without a credential; they never simulate a result.
- Deterministic-local payload equivalence with the accepted G5/G7 worker
  shapes (key fields).
- Full async loop against a LOCAL STUB provider (adapter-mechanics evidence
  only — real providers remain BLOCKED / NOT TESTED): claim with an
  OPERATION binding -> submit_provider_job_v2 -> worker service submit/poll
  -> coordinator callback -> VALIDATING -> ACCEPTED, settled exactly once.
"""
import json
import os
import subprocess
import sys
import threading
import unittest
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

WS = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(WS))
import adapters as adapters_mod  # noqa: E402
import payloads  # noqa: E402
import plan_exec  # noqa: E402
import plans as plans_mod  # noqa: E402
import service as service_mod  # noqa: E402

G2 = Path.home() / "workspace/video-factory-g2"
sys.path.insert(0, str(G2))
from coordinator.coordinator import Coordinator  # noqa: E402
import psycopg  # noqa: E402
from psycopg.rows import dict_row  # noqa: E402

DB = "gatec_worker_scratch"
DSN = f"host=127.0.0.1 dbname={DB} user=factory password=factory_dev_local"
STUB_CONTENT = "stub generated text"


# --------------------------------------------------------------------- stub
class StubProvider(BaseHTTPRequestHandler):
    seen_auth = []

    def log_message(self, *a):
        pass

    def _send(self, obj):
        body = json.dumps(obj).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_POST(self):
        if self.path == "/submit":
            n = int(self.headers.get("Content-Length") or 0)
            self.rfile.read(n)
            StubProvider.seen_auth.append(self.headers.get("Authorization"))
            return self._send({"job_id": "stub-1"})
        return self._send({"error": "no route"})

    def do_GET(self):
        if self.path == "/poll/stub-1":
            return self._send({"status": "COMPLETED", "content": STUB_CONTENT,
                               "usage": {"input_tokens": 5, "output_tokens": 7},
                               "request_id": "stub-req-1", "cost_cents": 90})
        return self._send({"status": "PROCESSING"})


def serve(handler):
    srv = ThreadingHTTPServer(("127.0.0.1", 0), handler)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return srv, srv.server_address[1]


def http_json(method, url, body=None):
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(url, data=data, method=method)
    if data:
        req.add_header("Content-Type", "application/json")
    with urllib.request.urlopen(req, timeout=10) as r:
        return r.status, json.loads(r.read() or b"{}")


class TestBlockedAdapters(unittest.TestCase):
    def test_openrouter_refuses_without_credential(self):
        a = adapters_mod.OpenRouterCompatibleAdapter()
        binding = {"provider": "openrouter-compatible", "model": "some/model",
                   "credential_ref": "GATEC_DEFINITELY_MISSING_ENV", "params": {}}
        os.environ.pop("GATEC_DEFINITELY_MISSING_ENV", None)
        with self.assertRaises(adapters_mod.BlockedError):
            a.execute(binding, {"operation_id": "01.01"})
        self.assertIn("credential_ref", a.validate_config(
            {"provider": "openrouter-compatible"})[0])

    def test_direct_http_refuses_without_credential(self):
        a = adapters_mod.DirectHttpTextAdapter()
        binding = {"provider": "direct-http-text", "credential_ref": "GATEC_MISSING_2",
                   "params": {"endpoint": "http://127.0.0.1:1/x"}}
        os.environ.pop("GATEC_MISSING_2", None)
        with self.assertRaises(adapters_mod.BlockedError):
            a.execute(binding, {"operation_id": "01.01"})
        with self.assertRaises(adapters_mod.BlockedError):
            a.submit(binding, {"operation_id": "01.01"})

    def test_media_adapter_refuses_without_credential(self):
        a = adapters_mod.HttpMediaAdapter("image")
        with self.assertRaises(adapters_mod.BlockedError):
            a.execute({"provider": "http-image", "credential_ref": "GATEC_MISSING_3",
                       "params": {"endpoint": "http://127.0.0.1:1/x"}},
                      {"operation_id": "11.12"})

    def test_mock_adapter_fencing(self):
        a = adapters_mod.MockAdapter()
        req = {"operation_id": "01.01", "production_id": "p", "unit_id": "u"}
        with self.assertRaises(adapters_mod.BlockedError):
            a.execute({"provider": "mock", "params": {}}, req)         # not test-only
        out = a.execute({"provider": "mock", "params": {"test_only": True},
                         "est_cost_cents": 100}, req)                  # test env: allowed
        self.assertEqual(out["artifact_type"], "premise_record")
        a.environment = "production"
        with self.assertRaises(adapters_mod.BlockedError):
            a.execute({"provider": "mock", "params": {"test_only": True}}, req)

    def test_health_marks_credential_adapters_blocked(self):
        os.environ.pop("WORKER_CREDENTIAL_REFS", None)
        health = service_mod.adapter_health()
        self.assertEqual(health["openrouter-compatible"]["status"], "BLOCKED")
        self.assertEqual(health["direct-http-text"]["status"], "BLOCKED")
        self.assertEqual(health["http-video"]["status"], "BLOCKED")
        self.assertEqual(health["deterministic-local"]["status"], "READY")


class TestDeterministicPayloads(unittest.TestCase):
    def test_specific_ops_count(self):
        self.assertEqual(len(payloads.SPECIFIC_OPS), 19)

    def test_story_architecture_shape_matches_g5(self):
        atype, content = payloads.build(
            "05.12", "prod-1", "unit-1",
            [{"artifact_type": "canon_manifest", "artifact_id": "canon-9"}])
        doc = json.loads(content)
        self.assertEqual(atype, "story_architecture")
        self.assertEqual([n["id"] for n in doc["story_nodes"]], ["S1", "S2"])
        self.assertEqual(doc["canon_refs"], ["canon-9"])

    def test_master_package_shape_matches_g7(self):
        refs = [{"artifact_type": "edit_timeline", "artifact_id": "tl-1", "sha256": "sha-tl"},
                {"artifact_type": "asset_registry", "artifact_id": "reg-1", "sha256": "sha-reg",
                 "content": {"assets": [{"sha256": "a1"}, {"sha256": "a2"}]}}]
        atype, content = payloads.build("13.12", "prod-1", "unit-1", refs)
        doc = json.loads(content)
        self.assertEqual(atype, "master_package")
        self.assertEqual(doc["timeline_ref"], "tl-1")
        self.assertEqual(doc["timeline_sha256"], "sha-tl")
        self.assertEqual(doc["registry_ref"], "reg-1")
        self.assertEqual(doc["asset_hashes"], ["a1", "a2"])

    def test_g4_text_shape_and_fallback(self):
        atype, content = payloads.build("01.01", "prod-1", "unit-1", [])
        self.assertEqual(atype, "premise_record")
        self.assertTrue(content.startswith("PREMISE captured"))
        self.assertIn("[production=prod-1 op=01.01 unit=unit-1]", content)
        # Gate 04 (G01-D01): the generic branch is GONE as a success
        # path. A non-specific operation has no builder; execution goes
        # through its execution plan (plan_exec), never a synthesized
        # step_output. payloads.build itself now refuses explicitly.
        with self.assertRaises(payloads.UnboundOperationError):
            payloads.build("02.05", "prod-1", "unit-1", [])

    def test_adapter_execute_matches_payloads(self):
        a = adapters_mod.DeterministicLocalAdapter()
        out = a.execute({"provider": "deterministic-local", "est_cost_cents": 100},
                        {"operation_id": "05.12", "production_id": "p", "unit_id": "u",
                         "input_artifact_refs": []})
        self.assertEqual(out["artifact_type"], "story_architecture")
        self.assertEqual(out["cost_cents"], 100)
        self.assertEqual(out["usage"], {"deterministic": True})


class TestAsyncLoopThroughCoordinator(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        subprocess.run([str(G2 / ".venv" / "bin" / "python"),
                        str(G2 / "tools" / "setup_db.py"), DB],
                       check=True, capture_output=True)
        cls.stub, cls.stub_port = serve(StubProvider)
        cls.svc, cls.svc_port = serve(service_mod.Handler)

    @classmethod
    def tearDownClass(cls):
        cls.stub.shutdown()
        cls.svc.shutdown()

    def setUp(self):
        os.environ["STUB_CRED"] = "stub-secret"
        self.c = Coordinator(DSN)
        self.pid = self.c.create_production("Worker-service e2e", 100_00, 80_00, "tester")
        self.run = self.c.start_run(self.pid, "FULL", "tester")
        with psycopg.connect(DSN, row_factory=dict_row, autocommit=True) as conn:
            conn.execute(
                "INSERT INTO provider_configs(scope, operation_id, environment, provider,"
                " credential_ref, est_cost_cents, params, created_by) VALUES"
                " ('OPERATION', '11.06', 'test', 'direct-http-text', 'STUB_CRED', 100, %s,"
                "  'gatec-worker-test')",
                (json.dumps({
                    "endpoint": f"http://127.0.0.1:{self.stub_port}/submit",
                    "poll_endpoint": f"http://127.0.0.1:{self.stub_port}/poll/{{job_id}}",
                    "mode": "async", "id_path": "request_id"}),))

    def tearDown(self):
        with psycopg.connect(DSN, autocommit=True) as conn:
            conn.execute("UPDATE provider_configs SET active=false"
                         " WHERE created_by='gatec-worker-test'")
        self.c.close()

    def test_full_async_loop(self):
        c = self.c
        u = c.plan_unit(self.pid, self.run, "11.06")
        claim = c.claim(u, "worker-service")  # estimate + snapshot from the binding
        self.assertEqual(claim["attempt_no"], 1)
        with psycopg.connect(DSN, row_factory=dict_row, autocommit=True) as conn:
            attempt = conn.execute(
                "SELECT * FROM action_attempts WHERE attempt_id=%s",
                (claim["attempt_id"],)).fetchone()
        snapshot = attempt["resolved_config"]
        self.assertEqual(snapshot["provider"], "direct-http-text")
        c.event(u, "start")
        job_id = c.submit_provider_job_v2(u, claim["attempt_id"], claim["fencing_token"],
                                          "e2e-job-1")
        # worker service: async submit + poll against the stub provider
        status, out = http_json("POST", f"http://127.0.0.1:{self.svc_port}/jobs", {
            "unit_id": u, "attempt_id": claim["attempt_id"],
            "fencing_token": claim["fencing_token"], "operation_id": "11.06",
            "production_id": self.pid, "idempotency_key": "e2e-job-1",
            "provider_binding": snapshot, "input_artifact_refs": [], "deadline_s": 30})
        self.assertEqual(status, 202)
        self.assertEqual(out["provider_job_id"], "stub-1")
        self.assertIn("Bearer stub-secret", StubProvider.seen_auth)
        status, done = http_json("GET", f"http://127.0.0.1:{self.svc_port}/jobs/stub-1")
        self.assertEqual(status, 200)
        self.assertEqual(done["status"], "COMPLETED")
        self.assertEqual(done["content"], STUB_CONTENT)
        self.assertEqual(done["provider_request_id"], "stub-req-1")
        self.assertEqual(done["actual_cost_cents"], 90)
        # coordinator callback: convergent completion (B1.2)
        out = c.handle_callback("e2e-job-1", done["artifact_type"],
                                done["content"].encode(), "stub://result/1",
                                done["actual_cost_cents"], usage=done["usage"],
                                provider_request_id=done["provider_request_id"])
        self.assertFalse(out["duplicate"])
        self.assertEqual(out["result"]["outcome"], "completed")
        self.assertEqual(c.get_unit(u)["state"], "VALIDATING")
        state = c.validate(u, [{"validator": "schema_validation", "method": "contract",
                                "verdict": "PASS", "evaluator": "test", "evidence": {}}])
        self.assertEqual(state, "ACCEPTED")
        pos = c.budget_position(self.pid)
        self.assertEqual(pos["settled_cents"], 90)
        self.assertEqual(pos["held_cents"], 0)
        with psycopg.connect(DSN, row_factory=dict_row, autocommit=True) as conn:
            charges = conn.execute(
                "SELECT count(*) AS n FROM budget_transactions WHERE production_id=%s"
                " AND kind='CHARGE'", (self.pid,)).fetchone()["n"]
            classes = [r["charge_class"] for r in conn.execute(
                "SELECT charge_class FROM financial_evidence WHERE unit_id=%s"
                " ORDER BY created_at, charge_class", (u,)).fetchall()]
            job = conn.execute("SELECT * FROM provider_jobs WHERE job_id=%s",
                               (job_id,)).fetchone()
        self.assertEqual(charges, 1)  # settled exactly once
        self.assertEqual(classes, ["ESTIMATED", "FINALIZED"])
        self.assertEqual(job["status"], "COMPLETED")
        self.assertEqual(str(job["attempt_id"]), claim["attempt_id"])
        # duplicate callback is a no-op
        dup = c.handle_callback("e2e-job-1", "text_output", b"x", "stub://result/1", 90)
        self.assertTrue(dup["duplicate"])
        self.assertEqual(c.budget_position(self.pid)["settled_cents"], 90)


class TestGate04Plans(unittest.TestCase):
    """Gate 04: plan-driven execution. Bound plans execute their
    actions in order and produce input-derived output; plans containing
    UNBOUND actions refuse explicitly; no path returns a generic
    success."""

    def _req(self, op, refs):
        return {"operation_id": op, "production_id": "p", "unit_id": "u",
                "input_artifact_refs": refs}

    def test_all_192_plans_resolve(self):
        doc = plans_mod.load_plans()
        self.assertEqual(len(doc["plans"]), 192)
        for plan in doc["plans"]:
            self.assertEqual(plans_mod.plan_hash(plan), plan["plan_hash"])
            self.assertTrue(plan["actions"])
        fully = [p for p in doc["plans"]
                 if p["binding_status"] == "FULLY_BOUND"]
        # MM-06: the 10 local-FFmpeg media plans (media.process x9 +
        # media.render x1) bound -> 69 + 10 = 79.
        # MM-10: the 58 plans whose single unbound action class is
        # served by an explicitly simulated mock implementation
        # (creative.generate 43, external.platform 9, media.generate
        # 4, external.provider 2) bound -> 79 + 58 = 137. The 58 are
        # executable ONLY under a pinned 'mock' binding (the mock
        # implementations refuse under any other); genuinely bound
        # stays 79. Recorded in mm-gate-10 CHANGED_ASSERTIONS.
        self.assertEqual(len(fully), 137)

    def test_bound_generic_plan_executes_from_inputs(self):
        refs = [{"artifact_type": "beat_draft", "artifact_id": "a1",
                 "sha256": "x",
                 "content": {"changes": [{"summary": "one"},
                                         {"summary": "two", "id": "B9"}]}}]
        atype, content, summary = plan_exec.execute_operation(
            self._req("06.01", refs))
        doc = json.loads(content)
        records = doc["derived"]["records.assign_ids"]["records"]
        self.assertEqual([r["id"] for r in records], ["B-001", "B9"])
        self.assertEqual([a["status"] for a in summary["actions"]],
                         ["SUCCEEDED"] * 5)
        # input-sensitivity: different inputs -> different output
        refs2 = [{"artifact_type": "beat_draft", "artifact_id": "a2",
                  "sha256": "y", "content": {"changes": [{"summary": "z"}]}}]
        _, content2, _ = plan_exec.execute_operation(self._req("06.01", refs2))
        self.assertNotEqual(content, content2)

    def test_unbound_plan_refuses_without_artifact(self):
        # MM-10: the subject op moves from 08.05 (creative.generate —
        # bound since MM-10 to the explicitly simulated mock
        # implementation; its refusal discipline is asserted in
        # test_mm10_mock_actions.py) to 01.02, whose semantic.evaluate
        # action remains UNBOUND. Same assertion shape, still-unbound
        # subject. Recorded in mm-gate-10 CHANGED_ASSERTIONS.
        records = []
        with self.assertRaises(plan_exec.UnboundOperation) as ctx:
            plan_exec.execute_operation(self._req("01.02", []),
                                        sink=records.append)
        self.assertEqual(ctx.exception.error_class, "UNBOUND_OPERATION")
        refused = [r for r in records if r["status"] == "REFUSED"]
        self.assertEqual(len(refused), 1)
        self.assertEqual(refused[0]["action_key"], "semantic_evaluate")

    def test_specific_plan_output_unchanged(self):
        atype, content, summary = plan_exec.execute_operation(
            self._req("05.12", [{"artifact_type": "canon_manifest",
                                 "artifact_id": "c1", "sha256": "s"}]))
        self.assertEqual(atype, "story_architecture")
        self.assertEqual(json.loads(content)["story_nodes"][0]["id"], "S1")
        self.assertEqual([a["status"] for a in summary["actions"]],
                         ["SUCCEEDED"] * 3)

    def test_missing_input_fails_explicitly(self):
        with self.assertRaises(adapters_mod.ProviderError):
            plan_exec.execute_operation(self._req("06.01", []))

    def test_corrupt_plan_file_refused(self):
        import tempfile
        doc = plans_mod.load_plans()
        plan0 = json.loads(json.dumps(doc["plans"][0]))
        # (a) a tampered plan body fails its own hash — explicit refusal
        tampered = json.loads(json.dumps(doc))
        tampered["plans"][0]["actions"][0]["implementation"] = "engine.nonexistent"
        fd, path = tempfile.mkstemp(suffix=".json")
        with os.fdopen(fd, "w") as fh:
            json.dump(tampered, fh)
        old = os.environ.get("WORKER_PLANS_FILE")
        os.environ["WORKER_PLANS_FILE"] = path
        try:
            with self.assertRaises(plan_exec.PlanPinMismatch):
                plan_exec.execute_operation(self._req(plan0["operation_id"], []))
            # (b) with the hash recomputed, the unknown implementation
            # itself is refused at execution — never silently skipped
            fixed = json.loads(json.dumps(tampered))
            fixed["plans"][0]["plan_hash"] = plans_mod.plan_hash(fixed["plans"][0])
            with open(path, "w") as fh:
                json.dump(fixed, fh)
            with self.assertRaises(plan_exec.UnboundOperation):
                plan_exec.execute_operation(self._req(plan0["operation_id"], []))
        finally:
            if old is None:
                os.environ.pop("WORKER_PLANS_FILE", None)
            else:
                os.environ["WORKER_PLANS_FILE"] = old
            os.unlink(path)


if __name__ == "__main__":
    unittest.main(verbosity=2)
