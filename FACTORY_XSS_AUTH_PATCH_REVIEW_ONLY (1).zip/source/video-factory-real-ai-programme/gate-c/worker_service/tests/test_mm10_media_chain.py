"""MM-10 fix F-MM10-01 — the media data plane across operations.

The defect: media actions resolved input media by ARTIFACT sha, but
a worker-produced artifact's recorded sha covers its composed JSON
bytes — the media bytes live in the store under their own sha, which
no artifact row carried, so every media operation downstream of a
worker artifact refused with "no input artifact resolves to media
bytes".

The fix, proven here through the worker path (adapters -> plan_exec):
- compose_document hoists the terminal media action's store
  reference into the composed document's top-level `media_ref`
  field (the completion's stable media metadata);
- _media_inputs resolves an input artifact as (1) direct media
  bytes, else (2) a declared media reference (media_ref /
  media_output / derived media_output / store reference) whose
  store bytes probe as media.

No network, no credentials, no database. Media is lavfi-synthesized
in a temp Gate D store (MM-06 conventions)."""
import atexit
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

WS = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(WS))
import adapters as adapters_mod  # noqa: E402
import media_tools as mt  # noqa: E402
import plan_exec  # noqa: E402

TMP = Path(tempfile.mkdtemp(prefix="mm10-chain-tests-"))
atexit.register(shutil.rmtree, TMP, ignore_errors=True)
os.environ.setdefault("FACTORY_STORAGE_ROOT", str(TMP / "store"))
os.environ.setdefault("FACTORY_STORAGE_BACKEND", "local")

MOCK = {"provider": "mock", "params": {"test_only": True}}
DET = {"provider": "deterministic-local", "est_cost_cents": 100,
       "params": {}}
SHOT_REF = {"artifact_type": "shot_manifest", "artifact_id": "sm-1",
            "sha256": "unused",
            "content": {"shots": [{"id": "SH1"}, {"id": "SH2"}]}}


def _store_bytes(data):
    from storage_service import factory_from_env
    store = factory_from_env()
    staged = store.put_candidate(data)
    store.promote(staged["uri"])
    return staged["sha256"]


def _run(adapter_binding, op, refs, adapter_cls=None):
    adapter = (adapter_cls or adapters_mod.DeterministicLocalAdapter)()
    result = adapter.execute(adapter_binding, {
        "operation_id": op, "production_id": "mm10-chain-prod",
        "unit_id": f"u-{op}", "attempt_id": None,
        "provider_binding": adapter_binding,
        "input_artifact_refs": refs})
    summary = result["plan_execution"]
    assert [a["status"] for a in summary["actions"]] == \
        ["SUCCEEDED"] * len(summary["actions"]), summary
    return json.loads(result["content"]), summary


def _generate_media_doc():
    """Run 11.04 (mock media.generate) and register its composed
    document the way the coordinator does: the artifact's recorded
    sha covers the composed bytes, which are in the store."""
    doc, _ = _run(MOCK, "11.04", [SHOT_REF],
                  adapters_mod.MockAdapter)
    raw = json.dumps(doc, sort_keys=True).encode()
    artifact_sha = _store_bytes(raw)
    assert artifact_sha == hashlib.sha256(raw).hexdigest()
    return doc, artifact_sha


def _ref_for(doc, artifact_sha, artifact_id="chain-1"):
    return {"artifact_type": doc["kind"], "artifact_id": artifact_id,
            "sha256": artifact_sha, "content": doc}


class TestMediaRefHoist(unittest.TestCase):
    def test_generate_completion_records_media_ref(self):
        doc, artifact_sha = _generate_media_doc()
        gen = doc["derived"]["media_generate"]["media_output"]
        ref = doc["media_ref"]
        self.assertEqual(ref["sha256"], gen["sha256"])
        self.assertEqual(ref["storage_uri"], gen["storage_uri"])
        self.assertEqual(ref["source_action"], "media_generate")
        # The whole point: the media sha is NOT the artifact sha.
        self.assertNotEqual(ref["sha256"], artifact_sha)

    def test_process_completion_records_media_ref(self):
        doc, _ = _generate_media_doc()
        out, _ = _run(DET, "13.08", [_ref_for(doc, _store_bytes(
            json.dumps(doc, sort_keys=True).encode()))])
        proc = out["derived"]["media_process"]
        self.assertEqual(out["media_ref"]["sha256"],
                         proc["media_output"]["sha256"])
        self.assertEqual(out["media_ref"]["source_action"],
                         "media_process")


class TestMediaChainResolution(unittest.TestCase):
    def test_generate_then_process_via_media_ref(self):
        doc, artifact_sha = _generate_media_doc()
        out, _ = _run(DET, "13.08", [_ref_for(doc, artifact_sha)])
        proc = out["derived"]["media_process"]
        self.assertEqual(proc["media_input"]["resolved_via"], "media_ref")
        self.assertEqual(proc["media_input"]["media_sha256"],
                         doc["media_ref"]["sha256"])
        self.assertEqual(proc["media_input"]["sha256"], artifact_sha)
        probe = mt.probe_bytes(mt.fetch_media_bytes(
            proc["media_output"]["sha256"]))
        video = mt.first_stream(probe, "video")
        self.assertEqual(video["codec"], "h264")

    def test_generate_then_render_via_media_ref(self):
        doc, artifact_sha = _generate_media_doc()
        out, _ = _run(DET, "13.03", [_ref_for(doc, artifact_sha)])
        render = out["derived"]["media_render"]
        self.assertEqual(render["media_input"]["resolved_via"],
                         ["media_ref"])
        self.assertEqual(render["media_input"]["count"], 1)
        probe = mt.probe_bytes(mt.fetch_media_bytes(
            render["media_output"]["sha256"]))
        video = mt.first_stream(probe, "video")
        self.assertEqual((video["width"], video["height"]), (1280, 720))

    def test_legacy_derived_position_resolves(self):
        """Artifacts composed BEFORE the fix carry media_output only
        under derived.<action> — the preserved MM-10 battery DB is
        full of them, and the repair re-run consumes them as-is."""
        doc, _ = _generate_media_doc()
        legacy = {k: v for k, v in doc.items() if k != "media_ref"}
        raw = json.dumps(legacy, sort_keys=True).encode()
        artifact_sha = _store_bytes(raw)
        out, _ = _run(DET, "13.08", [_ref_for(legacy, artifact_sha)])
        proc = out["derived"]["media_process"]
        self.assertEqual(proc["media_input"]["resolved_via"],
                         "derived.media_output")
        self.assertEqual(proc["media_input"]["media_sha256"],
                         doc["media_ref"]["sha256"])

    def test_direct_media_artifact_still_resolves(self):
        src = TMP / "direct.mp4"
        subprocess.run(
            ["ffmpeg", "-nostdin", "-v", "error", "-y",
             "-f", "lavfi", "-i", "testsrc2=duration=2:size=640x360:rate=30",
             "-f", "lavfi", "-i", "sine=frequency=440:duration=2",
             "-c:v", "libx264", "-pix_fmt", "yuv420p",
             "-c:a", "aac", "-ar", "48000", "-shortest", str(src)],
            check=True, capture_output=True)
        media_sha = _store_bytes(src.read_bytes())
        ref = {"artifact_type": "media_asset", "artifact_id": "direct-1",
               "sha256": media_sha}
        out, _ = _run(DET, "13.08", [ref])
        proc = out["derived"]["media_process"]
        self.assertEqual(proc["media_input"]["resolved_via"], "direct")
        self.assertEqual(proc["media_input"]["media_sha256"], media_sha)

    def test_non_media_artifact_fails_with_named_reason(self):
        raw = json.dumps({"kind": "script", "lines": []},
                         sort_keys=True).encode()
        sha = _store_bytes(raw)
        ref = {"artifact_type": "script", "artifact_id": "text-1",
               "sha256": sha,
               "content": {"kind": "script", "lines": []}}
        records = []
        with self.assertRaises(adapters_mod.ProviderError):
            plan_exec.execute_operation(
                {"operation_id": "13.08", "production_id": "p",
                 "unit_id": "u", "input_artifact_refs": [ref],
                 "provider_binding": DET},
                sink=records.append)
        failed = [r for r in records if r["status"] == "FAILED"]
        self.assertEqual([r["action_key"] for r in failed],
                         ["media_process"])
        self.assertIn("no input artifact resolves to media bytes",
                      failed[0]["error"])


if __name__ == "__main__":
    unittest.main()
