"""MM-06 tests — specialized non-LLM providers.

- Media validator (media_tools.validate_media): named failure reasons
  for valid / truncated / wrong-codec / missing-audio / missing-file.
- The 10 newly bound media plans (9x media.process + 13.03
  media.render) execute REAL local FFmpeg work through the worker
  path (DeterministicLocalAdapter -> plan_exec) over lavfi-synthesized
  media bytes held in a temp Gate D store, and every produced output
  is validated with ffprobe. Label: LOCAL_TOOL_EXECUTION — local
  tooling over synthetic media, not provider output.
- Local TTS (ffmpeg flite): adapter + action produce real WAVs.
- Simulation labeling: the 15.12 mock publication receipts carry
  machine-visible marking that survives plan/envelope/store paths.

No network, no credentials, no database."""
import atexit
import json
import os
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

WS = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(WS))
import actions as actions_mod  # noqa: E402
import adapters as adapters_mod  # noqa: E402
import envelope as envelope_mod  # noqa: E402
import media_tools as mt  # noqa: E402
import payloads  # noqa: E402
import plan_exec  # noqa: E402
import plans as plans_mod  # noqa: E402

TMP = Path(tempfile.mkdtemp(prefix="mm06-tests-"))
# D-1: the suite's own scratch root is removed at process exit, so a
# test run leaves nothing behind in the temp root.
atexit.register(shutil.rmtree, TMP, ignore_errors=True)
STORE_ROOT = TMP / "store"
os.environ["FACTORY_STORAGE_ROOT"] = str(STORE_ROOT)
os.environ["FACTORY_STORAGE_BACKEND"] = "local"


def _ffmpeg(args):
    proc = subprocess.run(["ffmpeg", "-nostdin", "-v", "error", *args],
                          capture_output=True, text=True,
                          stdin=subprocess.DEVNULL)
    assert proc.returncode == 0, proc.stderr[-500:]


def _synth(name, video_dur=6, audio_dur=6, volume=None, size="1280x720",
           with_subtitles=False):
    path = TMP / name
    args = ["-f", "lavfi", "-i",
            f"testsrc2=duration={video_dur}:size={size}:rate=30"]
    if audio_dur:
        args += ["-f", "lavfi", "-i",
                 f"sine=frequency=440:duration={audio_dur}"]
    if with_subtitles:
        srt = TMP / "subs.srt"
        srt.write_text("1\n00:00:00,500 --> 00:00:02,000\n"
                       "The ledger is gone.\n\n"
                       "2\n00:00:03,000 --> 00:00:05,500\n"
                       "It was locked from inside.\n")
        args += ["-i", str(srt)]
    args += ["-c:v", "libx264", "-pix_fmt", "yuv420p"]
    if audio_dur:
        af = f"volume={volume}" if volume else None
        if af:
            args += ["-af", af]
        args += ["-c:a", "aac", "-ar", "48000"]
    if with_subtitles:
        args += ["-c:s", "mov_text"]
    if video_dur and audio_dur and video_dur == audio_dur \
            and not with_subtitles:
        args += ["-shortest"]
    args += [str(path), "-y"]
    _ffmpeg(args)
    return path


def _store(path):
    from storage_service import factory_from_env
    store = factory_from_env()
    staged = store.put_candidate(Path(path).read_bytes())
    store.promote(staged["uri"])
    return staged["sha256"]


SRC = _synth("src_av.mp4")                      # 6s A/V master-shaped
SRC_SHORT_AUDIO = _synth("src_short_audio.mp4", audio_dur=2)
SRC_QUIET = _synth("src_quiet.mp4", volume=0.1)
SRC_SUBS = _synth("src_subs.mp4", with_subtitles=True)
SRC_SHA = _store(SRC)
SHORT_AUDIO_SHA = _store(SRC_SHORT_AUDIO)
QUIET_SHA = _store(SRC_QUIET)
SUBS_SHA = _store(SRC_SUBS)

MEDIA_REF = {"artifact_type": "media_asset", "artifact_id": "mm06-src",
             "sha256": SRC_SHA}
BINDING = {"provider": "deterministic-local", "est_cost_cents": 100,
           "params": {}}


def _run_op(operation_id, refs):
    adapter = adapters_mod.DeterministicLocalAdapter()
    result = adapter.execute(BINDING, {
        "operation_id": operation_id, "production_id": "mm06-prod",
        "unit_id": f"u-{operation_id}", "attempt_id": None,
        "input_artifact_refs": refs})
    doc = json.loads(result["content"])
    summary = result["plan_execution"]
    assert [a["status"] for a in summary["actions"]] == \
        ["SUCCEEDED"] * len(summary["actions"]), summary
    return doc, summary


def _media_output(doc):
    for key in ("media_process", "media_render"):
        if key in doc.get("derived", {}):
            return doc["derived"][key]["media_output"]
    raise AssertionError(f"no media action output in {list(doc['derived'])}")


def _probe_of_output(media_output):
    data = mt.fetch_media_bytes(media_output["sha256"])
    assert data is not None
    return mt.probe_bytes(data)


class TestMediaValidator(unittest.TestCase):
    MASTER_EXP = {"video_codec": "h264", "audio_codec": "aac",
                  "sample_rate": 48000, "require_video": True,
                  "require_audio": True}

    def test_valid_file_passes(self):
        out = mt.validate_media(SRC, self.MASTER_EXP)
        self.assertTrue(out["ok"], out["failures"])
        self.assertEqual(out["failures"], [])

    def test_truncated_file_fails_named(self):
        broken = TMP / "truncated.mp4"
        broken.write_bytes(SRC.read_bytes()[:4096])
        out = mt.validate_media(broken, self.MASTER_EXP)
        self.assertFalse(out["ok"])
        self.assertIn(mt.MEDIA_TRUNCATED_OR_CORRUPT, out["failures"])

    def test_wrong_codec_fails_named(self):
        other = TMP / "mpeg4.mp4"
        _ffmpeg(["-i", str(SRC), "-c:v", "mpeg4", "-c:a", "aac",
                 str(other), "-y"])
        out = mt.validate_media(other, self.MASTER_EXP)
        self.assertFalse(out["ok"])
        self.assertIn(mt.VIDEO_CODEC_MISMATCH, out["failures"])

    def test_missing_audio_fails_named(self):
        vonly = TMP / "video_only.mp4"
        _ffmpeg(["-f", "lavfi", "-i",
                 "testsrc2=duration=3:size=640x360:rate=30",
                 "-c:v", "libx264", "-pix_fmt", "yuv420p",
                 str(vonly), "-y"])
        out = mt.validate_media(vonly, self.MASTER_EXP)
        self.assertFalse(out["ok"])
        self.assertIn(mt.AUDIO_STREAM_MISSING, out["failures"])

    def test_missing_file_named(self):
        out = mt.validate_media(TMP / "nope.mp4", self.MASTER_EXP)
        self.assertEqual(out["failures"], [mt.FILE_MISSING])

    def test_duration_bounds_named(self):
        out = mt.validate_media(SRC, {"min_duration_s": 30})
        self.assertIn(mt.DURATION_TOO_SHORT, out["failures"])
        out = mt.validate_media(SRC, {"max_duration_s": 1})
        self.assertIn(mt.DURATION_TOO_LONG, out["failures"])


class TestBoundMediaPlans(unittest.TestCase):
    def test_the_ten_plans_are_fully_bound(self):
        for op in ("12.05", "12.06", "12.07", "12.08", "13.03", "13.05",
                   "13.08", "14.06", "14.07", "14.08"):
            plan = plans_mod.get_plan(op)
            self.assertEqual(plan["binding_status"], "FULLY_BOUND", op)
            impls = [a["implementation"] for a in plan["actions"]]
            self.assertIn("media.ffmpeg_render" if op == "13.03"
                          else "media.ffmpeg_process", impls, op)

    def test_1205_cuts_applies_declared_segments(self):
        edl = {"artifact_type": "edit_decision_list",
               "artifact_id": "edl-1", "sha256": "unused",
               "content": {"segments": [{"start_s": 0, "end_s": 2},
                                        {"start_s": 3, "end_s": 5}]}}
        doc, _ = _run_op("12.05", [MEDIA_REF, edl])
        action = doc["derived"]["media_process"]
        self.assertEqual(len(action["segments_applied"]), 2)
        probe = _probe_of_output(action["media_output"])
        self.assertAlmostEqual(probe["duration_s"], 4.0, delta=0.4)
        video = mt.first_stream(probe, "video")
        audio = mt.first_stream(probe, "audio")
        self.assertEqual((video["codec"], audio["codec"],
                          audio["sample_rate"]), ("h264", "aac", 48000))

    def test_1206_sync_shifts_audio_by_declared_offset(self):
        rec = {"artifact_type": "sync_record", "artifact_id": "sync-1",
               "sha256": "unused", "content": {"audio_offset_ms": 500}}
        doc, _ = _run_op("12.06", [MEDIA_REF, rec])
        action = doc["derived"]["media_process"]
        self.assertEqual(action["audio_offset_ms_applied"], 500)
        probe = _probe_of_output(action["media_output"])
        audio = mt.first_stream(probe, "audio")
        self.assertAlmostEqual(audio["start_time_s"], 0.5, delta=0.15)

    def test_1207_ambience_pads_audio_bed_to_picture(self):
        ref = {"artifact_type": "media_asset", "artifact_id": "mm06-short",
               "sha256": SHORT_AUDIO_SHA}
        doc, _ = _run_op("12.07", [ref])
        probe = _probe_of_output(_media_output(doc))
        audio = mt.first_stream(probe, "audio")
        self.assertAlmostEqual(audio["duration_s"], 6.0, delta=0.4)

    def test_1208_mix_normalizes_loudness(self):
        ref = {"artifact_type": "media_asset", "artifact_id": "mm06-quiet",
               "sha256": QUIET_SHA}
        doc, _ = _run_op("12.08", [ref])
        action = doc["derived"]["media_process"]
        before = action["loudness_before"]["input_i"]
        after = action["loudness_after"]["input_i"]
        self.assertLess(before, -25.0)
        self.assertAlmostEqual(after, -16.0, delta=2.0)
        self.assertGreater(after, before + 8)

    def test_1303_render_produces_review_master(self):
        doc, _ = _run_op("13.03", [MEDIA_REF])
        probe = _probe_of_output(_media_output(doc))
        video = mt.first_stream(probe, "video")
        audio = mt.first_stream(probe, "audio")
        self.assertEqual((video["width"], video["height"]), (1280, 720))
        self.assertEqual((video["codec"], audio["codec"]), ("h264", "aac"))

    def test_1303_render_concatenates_inputs_in_order(self):
        clip = _synth("clip2.mp4", video_dur=2, audio_dur=2)
        clip_sha = _store(clip)
        ref2 = {"artifact_type": "media_asset", "artifact_id": "mm06-clip",
                "sha256": clip_sha}
        doc, _ = _run_op("13.03", [MEDIA_REF, ref2])
        probe = _probe_of_output(_media_output(doc))
        self.assertAlmostEqual(probe["duration_s"], 8.0, delta=0.5)

    def test_1305_color_check_measures_without_output_media(self):
        doc, _ = _run_op("13.05", [MEDIA_REF])
        action = doc["derived"]["media_process"]
        self.assertIsNone(action["media_output"])
        stats = action["measurements"]["signalstats"]
        self.assertGreaterEqual(stats["frames"], 1)
        self.assertIsInstance(stats["yavg_mean"], float)
        self.assertIsNotNone(action["measurements"]["loudnorm"])

    def test_1308_fix_errors_reencodes_to_master(self):
        doc, _ = _run_op("13.08", [MEDIA_REF])
        probe = _probe_of_output(_media_output(doc))
        video = mt.first_stream(probe, "video")
        self.assertEqual(video["codec"], "h264")
        self.assertAlmostEqual(probe["duration_s"], 6.0, delta=0.4)

    def test_1406_reedit_applies_declared_segments(self):
        edl = {"artifact_type": "edit_decision_list",
               "artifact_id": "edl-2", "sha256": "unused",
               "content": {"segments": [{"start_s": 1, "end_s": 2},
                                        {"start_s": 4, "end_s": 5}]}}
        doc, _ = _run_op("14.06", [MEDIA_REF, edl])
        probe = _probe_of_output(_media_output(doc))
        self.assertAlmostEqual(probe["duration_s"], 2.0, delta=0.4)

    def test_1407_reframe_to_portrait(self):
        doc, _ = _run_op("14.07", [MEDIA_REF])
        probe = _probe_of_output(_media_output(doc))
        video = mt.first_stream(probe, "video")
        self.assertEqual((video["width"], video["height"]), (720, 1280))

    def test_1408_narration_extracts_normalized_audio(self):
        doc, _ = _run_op("14.08", [MEDIA_REF])
        action = doc["derived"]["media_process"]
        self.assertIsNone(action["subtitles"])
        probe = _probe_of_output(action["media_output"])
        self.assertIn("wav", probe["format_name"])
        audio = mt.first_stream(probe, "audio")
        self.assertEqual(audio["codec"], "pcm_s16le")
        self.assertAlmostEqual(probe["duration_s"], 6.0, delta=0.5)

    def test_1408_extracts_subtitle_stream_when_present(self):
        ref = {"artifact_type": "media_asset", "artifact_id": "mm06-subs",
               "sha256": SUBS_SHA}
        doc, _ = _run_op("14.08", [ref])
        action = doc["derived"]["media_process"]
        self.assertEqual(action["subtitles"]["format"], "srt")
        data = mt.fetch_media_bytes(action["subtitles"]["sha256"])
        self.assertIn(b"ledger", data)

    def test_media_plan_without_media_fails_explicitly(self):
        records = []
        with self.assertRaises(adapters_mod.ProviderError):
            plan_exec.execute_operation(
                {"operation_id": "12.05", "production_id": "p",
                 "unit_id": "u", "input_artifact_refs": []},
                sink=records.append)
        failed = [r for r in records if r["status"] == "FAILED"]
        self.assertEqual([r["action_key"] for r in failed],
                         ["media_process"])

    def test_cuts_without_declared_segments_fails(self):
        with self.assertRaises(adapters_mod.ProviderError):
            plan_exec.execute_operation(
                {"operation_id": "12.05", "production_id": "p",
                 "unit_id": "u", "input_artifact_refs": [MEDIA_REF]},
                sink=lambda r: None)


class TestLocalTTS(unittest.TestCase):
    def test_flite_adapter_registered_and_executes(self):
        registry = adapters_mod.build_registry("test")
        self.assertIn("ffmpeg-flite-local", registry)
        adapter = registry["ffmpeg-flite-local"]
        self.assertFalse(adapter.credential_required)
        result = adapter.execute(
            {"provider": "ffmpeg-flite-local", "params": {}},
            {"prompt": "The archive door was locked from inside.",
             "operation_id": "tts-test", "production_id": "p"})
        content = result["content"]
        self.assertEqual(content["engine"], "ffmpeg-flite-local")
        self.assertFalse(content["simulated"])
        self.assertEqual(content["label"], "LOCAL_TOOL")
        self.assertGreater(content["duration_s"], 0.5)
        data = mt.fetch_media_bytes(content["sha256"])
        probe = mt.probe_bytes(data)
        self.assertIn("wav", probe["format_name"])
        self.assertAlmostEqual(probe["duration_s"],
                               content["duration_s"], delta=0.1)

    def test_synthesize_speech_action(self):
        ctx = actions_mod.ActionContext(
            "tts-op", "p", "u", None, [], {},
            binding={"provider": "deterministic-local"})
        out = actions_mod.synthesize_speech(
            ctx, {"text": "Mara finds the brass key.", "voice": "slt"})
        self.assertGreater(out["duration_s"], 0.3)
        self.assertFalse(out["simulated"])
        data = mt.fetch_media_bytes(out["media_output"]["sha256"])
        self.assertIsNotNone(mt.probe_bytes(data))


class TestSimulationLabeling(unittest.TestCase):
    PKG_REF = {"artifact_type": "derivative_package",
               "artifact_id": "pkg-1", "sha256": "s",
               "content": {"kind": "derivative_package",
                           "derivatives": [
                               {"id": "D-vertical", "format": "9:16",
                                "platform": "shorts", "payload": "x",
                                "sha256": "a" * 64},
                               {"id": "D-square", "format": "1:1",
                                "platform": "feed", "payload": "y",
                                "sha256": "b" * 64}]}}

    def _marked(self, doc):
        return doc.get("simulated") is True \
            and "mock" in (doc.get("provider") or "") \
            and all(p.get("status") == "SIMULATED"
                    for p in doc.get("publications", []))

    def test_distribution_record_is_marked(self):
        _atype, content = payloads.build("15.12", "p", "u",
                                         [self.PKG_REF])
        doc = json.loads(content)
        self.assertTrue(self._marked(doc), doc)
        self.assertTrue(all(p["platform_post_id"].startswith("mock-")
                            for p in doc["publications"]))

    def test_distinguishable_from_real_shaped_record(self):
        real_shaped = {"kind": "distribution_record",
                       "package_ref": "pkg-1",
                       "publications": [
                           {"derivative_id": "D-vertical",
                            "platform": "shorts",
                            "platform_post_id": "real-post-123",
                            "sha256": "a" * 64,
                            "status": "PUBLISHED"}]}
        self.assertFalse(self._marked(real_shaped))

    def test_marking_survives_plan_envelope_and_store(self):
        adapter = adapters_mod.DeterministicLocalAdapter()
        result = adapter.execute(BINDING, {
            "operation_id": "15.12", "production_id": "p",
            "unit_id": "u-15.12", "attempt_id": None,
            "input_artifact_refs": [self.PKG_REF]})
        wrapped = envelope_mod.wrap(
            BINDING, {"operation_id": "15.12", "production_id": "p",
                      "attempt_id": "a1"},
            result["artifact_type"], result["content"])
        self.assertIsNotNone(wrapped)
        envelope_doc = json.loads(wrapped)
        deliverable = envelope_doc["output_artifacts"][0]["content"]
        self.assertTrue(self._marked(deliverable))
        stored = mt.store_media_bytes(wrapped.encode(), "application/json")
        fetched = mt.fetch_media_bytes(stored["sha256"])
        unwrapped = envelope_mod.unwrap_entry(fetched,
                                              "distribution_record")
        self.assertTrue(self._marked(unwrapped))

    def test_marking_survives_mock_adapter(self):
        adapter = adapters_mod.MockAdapter()
        adapter.environment = "test"
        result = adapter.execute(
            {"provider": "mock", "params": {"test_only": True},
             "est_cost_cents": 5},
            {"operation_id": "15.12", "production_id": "p",
             "unit_id": "u-15.12", "attempt_id": None,
             "input_artifact_refs": [self.PKG_REF]})
        self.assertTrue(self._marked(json.loads(result["content"])))


class TestWorkdirCleanup(unittest.TestCase):
    """MM-06 defect D-1: a media action must remove the scratch
    workdir it creates on EVERY exit path — success, ActionFailed,
    and unexpected exceptions — so the set of media workdirs under
    the temp root is unchanged after a run."""

    PREFIXES = ("mm06-media-", "mm06-render-", "mm06-tts-",
                "mm06-flite-")

    def _workdirs(self):
        root = Path(tempfile.gettempdir())
        return {p.name for p in root.iterdir()
                if p.is_dir() and p.name.startswith(self.PREFIXES)}

    def _ctx(self, refs):
        return actions_mod.ActionContext(
            "d1-op", "p", "u", None, refs, {},
            binding={"provider": "deterministic-local"})

    def test_success_paths_leave_no_workdirs(self):
        before = self._workdirs()
        actions_mod.ffmpeg_process(self._ctx([MEDIA_REF]),
                                   {"transform": "mix"})
        actions_mod.ffmpeg_render(self._ctx([MEDIA_REF]), {})
        actions_mod.synthesize_speech(
            self._ctx([]), {"text": "The workdir is cleaned."})
        registry = adapters_mod.build_registry("test")
        registry["ffmpeg-flite-local"].execute(
            {"provider": "ffmpeg-flite-local", "params": {}},
            {"prompt": "The workdir is cleaned.",
             "operation_id": "d1-tts", "production_id": "p"})
        self.assertEqual(self._workdirs(), before)

    def test_action_failed_paths_leave_no_workdirs(self):
        before = self._workdirs()
        with self.assertRaises(actions_mod.ActionFailed):
            # cuts with media but no declared segments: fails AFTER
            # the workdir is created.
            actions_mod.ffmpeg_process(self._ctx([MEDIA_REF]),
                                       {"transform": "cuts"})
        with self.assertRaises(actions_mod.ActionFailed):
            # unknown transform: fails at the end of the dispatch.
            actions_mod.ffmpeg_process(self._ctx([MEDIA_REF]),
                                       {"transform": "bogus"})
        self.assertEqual(self._workdirs(), before)

    def test_unexpected_exception_paths_leave_no_workdirs(self):
        before = self._workdirs()
        with mock.patch.object(mt, "ffmpeg",
                               side_effect=mt.MediaToolError("boom")):
            with self.assertRaises(mt.MediaToolError):
                actions_mod.ffmpeg_render(self._ctx([MEDIA_REF]), {})
        registry = adapters_mod.build_registry("test")
        with mock.patch.object(mt, "synthesize_speech_wav",
                               side_effect=RuntimeError("surprise")):
            with self.assertRaises(RuntimeError):
                registry["ffmpeg-flite-local"].execute(
                    {"provider": "ffmpeg-flite-local", "params": {}},
                    {"prompt": "Boom.", "operation_id": "d1-tts",
                     "production_id": "p"})
        self.assertEqual(self._workdirs(), before)

    def test_workdir_context_manager_removes_on_raise_and_success(self):
        with mt.workdir("mm06-media-") as created:
            self.assertTrue(created.is_dir())
        self.assertFalse(created.exists())
        with self.assertRaises(RuntimeError):
            with mt.workdir("mm06-media-") as created2:
                raise RuntimeError("inside the workdir")
        self.assertFalse(created2.exists())


if __name__ == "__main__":
    unittest.main()
