"""Gate 04 — deterministic-engine atomic action implementations.

Every implementation is a pure function of (ctx, spec): it reads the
operation's resolved input artifacts and the outputs of earlier actions
in the same plan, and produces a typed output derived from those inputs.
An implementation NEVER invents content: when its typed output cannot be
produced from the given inputs it raises ActionFailed, and the plan
executor turns that into an explicit unit failure with evidence — the
Gate 04 replacement for the old generic success fallthrough (G01-D01).

ActionContext fields:
  operation_id, production_id, unit_id, attempt_id
  refs   — resolved input refs [{artifact_type, artifact_id, sha256,
           content}] (content is a parsed JSON value, a string, or None
           when the bytes were unavailable)
  plan   — the operation's execution plan dict
  binding — the attempt's pinned provider binding snapshot (Lean
           Phase 3; provider-aware implementations dispatch on it)
  prior  — {action_key: output} of earlier actions in this plan
  result — None, or (artifact_type, content_str) once a producing action
           (op.build_payload / engine.compose_document) has run

Specs (INPUT_SPECS / OUTPUT_SPECS) are the typed contracts the Gate 04
plan generator copies into every plan; plans-validate checks the plans
against these, and a worker-service test pins this module's registry to
the shipped action_implementations.json manifest.
"""
import hashlib
import json
import os
import re


class ActionFailed(Exception):
    """The action cannot produce its typed output from the given inputs."""


class ActionRefused(Exception):
    """The action refuses to run at all (Lean Phase 3): e.g. the attempt's
    pinned binding names a credentialed provider whose credential is
    absent. A refusal is a BLOCKED outcome — the plan executor records
    the action REFUSED and the service answers BLOCKED. It is NEVER a
    silent fallback to another implementation."""


def _canon(value):
    return json.dumps(value, sort_keys=True, default=str)


def _sha_text(text):
    return hashlib.sha256(text.encode()).hexdigest()


def _content_sha(content):
    if content is None:
        return None
    if isinstance(content, str):
        return _sha_text(content)
    return _sha_text(_canon(content))


def _parse(content):
    """Content as a JSON value when it parses, else the raw value."""
    if isinstance(content, str):
        try:
            return json.loads(content)
        except (json.JSONDecodeError, ValueError):
            return content
    return content


class ActionContext:
    def __init__(self, operation_id, production_id, unit_id, attempt_id,
                 refs, plan, binding=None, gateway=None):
        self.operation_id = operation_id
        self.production_id = production_id
        self.unit_id = unit_id
        self.attempt_id = attempt_id
        self.refs = list(refs or [])
        self.plan = plan or {}
        self.prior = {}
        self.result = None
        # Lean Phase 3: the attempt's PINNED provider binding snapshot
        # (from the /work request). Provider-aware implementations
        # dispatch on this and nothing else.
        self.binding = binding
        # MM-04: the worker's gateway context for this request (DB
        # access + cancellation probe), when the service provided one.
        # Provider-backed actions route their provider calls through
        # the gateway; without a context the gateway runs unarmed.
        self.gateway = gateway
        # Set by a provider-backed producing action: {provider, model,
        # usage, provider_request_id} — the plan executor copies it
        # into the action's record and the execution summary.
        self.provider_evidence = None

    def json_refs(self):
        """[(ref, parsed_value)] for refs whose content is available."""
        out = []
        for ref in self.refs:
            content = ref.get("content")
            if content is None:
                continue
            out.append((ref, _parse(content)))
        return out

    def prior_records(self, spec):
        """The record list produced by an earlier action (spec.from_action)."""
        key = (spec or {}).get("from_action")
        if not key or key not in self.prior:
            raise ActionFailed(f"spec references unknown prior action {key!r}")
        out = self.prior[key]
        records = out.get("records") if isinstance(out, dict) else None
        if records is None:
            raise ActionFailed(f"prior action {key!r} produced no records")
        return records


def _records_of(value):
    """Deterministic record extraction from a parsed JSON value:
    a list is itself; a dict contributes its single list-valued field,
    or itself as a single record when it has none."""
    if isinstance(value, list):
        return value, "."
    if isinstance(value, dict):
        list_fields = [k for k, v in value.items() if isinstance(v, list)]
        if len(list_fields) == 1:
            return value[list_fields[0]], list_fields[0]
        if not list_fields:
            return [value], "."
    return None, None


# --------------------------------------------------------------------- impls
def manifest_inputs(ctx, spec):
    inputs = [{"artifact_type": r.get("artifact_type"),
               "artifact_id": r.get("artifact_id"),
               "sha256": r.get("sha256")} for r in ctx.refs]
    return {"inputs": inputs, "count": len(inputs),
            "input_sha256": [i["sha256"] for i in inputs]}


def analyze_content(ctx, spec):
    analyses = []
    for ref, value in ctx.json_refs():
        entry = {"artifact_type": ref.get("artifact_type"),
                 "artifact_id": ref.get("artifact_id"),
                 "sha256": _content_sha(value)}
        if isinstance(value, dict):
            entry["kind"] = "json_object"
            entry["keys"] = sorted(value.keys())
            entry["record_counts"] = {
                k: len(v) for k, v in sorted(value.items())
                if isinstance(v, list)}
        elif isinstance(value, list):
            entry["kind"] = "json_array"
            entry["record_counts"] = {".": len(value)}
        elif isinstance(value, str):
            entry["kind"] = "text"
            entry["line_count"] = value.count("\n") + 1 if value else 0
            entry["word_count"] = len(value.split())
        else:
            entry["kind"] = "json_scalar"
        analyses.append(entry)
    if not analyses:
        raise ActionFailed("no input content available to analyze")
    return {"analyses": analyses, "count": len(analyses)}


def extract_records(ctx, spec):
    spec = spec or {}
    want_type = spec.get("artifact_type")
    want_field = spec.get("field")
    for ref, value in ctx.json_refs():
        if want_type and ref.get("artifact_type") != want_type:
            continue
        if want_field:
            if isinstance(value, dict) and isinstance(value.get(want_field), list):
                return {"records": value[want_field],
                        "source_artifact_type": ref.get("artifact_type"),
                        "field": want_field, "count": len(value[want_field])}
            continue
        records, field = _records_of(value)
        if records is not None:
            return {"records": records,
                    "source_artifact_type": ref.get("artifact_type"),
                    "field": field, "count": len(records)}
    raise ActionFailed(
        "no input artifact yields records"
        + (f" (wanted field {want_field!r})" if want_field else ""))


def index_records(ctx, spec):
    spec = spec or {}
    key = spec.get("key", "id")
    records = ctx.prior_records(spec)
    index = {}
    for i, rec in enumerate(records):
        if not isinstance(rec, dict) or key not in rec:
            raise ActionFailed(f"record {i} has no {key!r} field to index by")
        index[str(rec[key])] = rec
    return {"index": index, "key": key, "count": len(index),
            "records": records}


def project_records(ctx, spec):
    spec = spec or {}
    fields = spec.get("fields")
    if not fields:
        raise ActionFailed("project_records requires spec.fields")
    records = ctx.prior_records(spec)
    out = []
    for rec in records:
        if not isinstance(rec, dict):
            raise ActionFailed("cannot project a non-object record")
        out.append({f: rec.get(f) for f in fields})
    return {"records": out, "fields": fields, "count": len(out)}


def group_records(ctx, spec):
    spec = spec or {}
    field = spec.get("group_field")
    if not field:
        raise ActionFailed("group_records requires spec.group_field")
    records = ctx.prior_records(spec)
    groups, ungrouped = {}, []
    for rec in records:
        if isinstance(rec, dict) and rec.get(field) is not None:
            groups.setdefault(str(rec[field]), []).append(rec)
        else:
            ungrouped.append(rec)
    return {"groups": groups, "group_field": field,
            "group_count": len(groups), "ungrouped": ungrouped,
            "count": len(records), "records": records}


def assign_stable_ids(ctx, spec):
    spec = spec or {}
    prefix = spec.get("prefix") or ctx.operation_id.replace(".", "")
    field = spec.get("field", "id")
    records = ctx.prior_records(spec)
    out, assigned = [], 0
    for i, rec in enumerate(records):
        if not isinstance(rec, dict):
            raise ActionFailed("cannot assign ids to a non-object record")
        rec = dict(rec)
        if rec.get(field) is None:
            rec[field] = f"{prefix}-{i + 1:03d}"
            assigned += 1
        out.append(rec)
    return {"records": out, "field": field, "assigned": assigned,
            "count": len(out)}


def cross_check_refs(ctx, spec):
    spec = spec or {}
    id_field = spec.get("id_field", "id")
    record_sets = []
    for action_key, out in sorted(ctx.prior.items()):
        if isinstance(out, dict) and isinstance(out.get("records"), list):
            record_sets.append((action_key, out["records"]))
    for ref, value in ctx.json_refs():
        records, _ = _records_of(value)
        if records:
            record_sets.append((f"input:{ref.get('artifact_type')}", records))
    if not record_sets:
        raise ActionFailed("no records available to cross-check")
    known_ids = set()
    for _, records in record_sets:
        for rec in records:
            if isinstance(rec, dict) and rec.get(id_field) is not None:
                known_ids.add(str(rec[id_field]))
    dangling, checked = [], 0
    for source, records in record_sets:
        for i, rec in enumerate(records):
            if not isinstance(rec, dict):
                continue
            for field, val in sorted(rec.items()):
                if (field.endswith("_ref") or field.endswith("_id")) \
                        and field != id_field and isinstance(val, str):
                    checked += 1
                    if val not in known_ids:
                        dangling.append({"source": source, "record_index": i,
                                         "field": field, "value": val})
    return {"checked_refs": checked, "known_ids": len(known_ids),
            "dangling": dangling,
            "verdict": "CLEAN" if not dangling else "DANGLING_FOUND",
            "records": [r for _, rs in record_sets for r in rs]}


def verify_fields(ctx, spec):
    spec = spec or {}
    required = spec.get("required_fields")
    if not required:
        raise ActionFailed("verify_fields requires spec.required_fields")
    records = ctx.prior_records(spec)
    violations = []
    for i, rec in enumerate(records):
        if not isinstance(rec, dict):
            violations.append({"record_index": i, "missing": list(required),
                               "reason": "record is not an object"})
            continue
        missing = [f for f in required if rec.get(f) is None]
        if missing:
            violations.append({"record_index": i, "missing": missing})
    return {"checked": len(records), "required_fields": list(required),
            "violations": violations,
            "verdict": "COMPLETE" if not violations else "INCOMPLETE",
            "records": records}


def sort_chronology(ctx, spec):
    spec = spec or {}
    field = spec.get("date_field", "date")
    records = ctx.prior_records(spec)
    dated, undated = [], []
    for i, rec in enumerate(records):
        val = rec.get(field) if isinstance(rec, dict) else None
        if isinstance(val, str) and re.search(r"\d{4}", val):
            dated.append((val, i, rec))
        else:
            undated.append(i)
    if not dated:
        raise ActionFailed(f"no records carry a datable {field!r} field")
    ordered = sorted(dated, key=lambda t: (t[0], t[1]))
    inversions = sum(1 for a in range(len(dated)) for b in range(a + 1, len(dated))
                     if dated[a][0] > dated[b][0])
    return {"records": [r for _, _, r in ordered],
            "date_field": field, "dated": len(dated),
            "undated_indices": undated, "inversions": inversions,
            "first": ordered[0][0], "last": ordered[-1][0]}


def aggregate_metrics(ctx, spec):
    spec = spec or {}
    records = ctx.prior_records(spec)
    fields = spec.get("numeric_fields")
    sums, counts = {}, {}
    for rec in records:
        if not isinstance(rec, dict):
            continue
        for k, v in rec.items():
            if fields and k not in fields:
                continue
            if isinstance(v, (int, float)) and not isinstance(v, bool):
                sums[k] = sums.get(k, 0) + v
                counts[k] = counts.get(k, 0) + 1
    if not sums:
        raise ActionFailed("no numeric values available to aggregate")
    return {"metrics": {k: {"sum": sums[k], "count": counts[k],
                            "mean": sums[k] / counts[k]} for k in sorted(sums)},
            "record_count": len(records), "records": records}


def hash_attest(ctx, spec):
    shas = []
    for ref in ctx.refs:
        if ref.get("sha256"):
            shas.append(ref["sha256"])
    for ref, value in ctx.json_refs():
        sha = _content_sha(value)
        if sha and sha not in shas:
            shas.append(sha)
    return {"algorithm": "sha256",
            "input_sha256": sorted(shas),
            "attestation_sha256": _sha_text("|".join(sorted(shas))),
            "pinned_count": len(shas)}


MEDIA_REF_FIELD = "media_ref"


def _media_ref_of_prior(prior):
    """The stable media reference for a composed document
    (MM-10 fix F-MM10-01): when any earlier action of the plan
    produced media (mock.media.generate, media.ffmpeg_process,
    media.ffmpeg_render, media.synthesize_speech — all return a
    media_output {sha256, storage_uri, size} naming the media bytes
    in the Gate D store), the LAST such output is the operation's
    terminal media product, and its store reference is hoisted into
    the composed document's top-level `media_ref` field:
    {sha256, storage_uri, size, source_action}. Media consumers
    resolve inputs through this field (see _media_inputs): an
    artifact's recorded sha covers its composed JSON bytes, never
    the media bytes themselves, so without a declared reference the
    media data plane is unreachable from downstream operations."""
    found = None
    for key, out in prior.items():
        if isinstance(out, dict):
            mo = out.get("media_output")
            if isinstance(mo, dict) and mo.get("sha256"):
                found = {"sha256": mo["sha256"],
                         "storage_uri": mo.get("storage_uri"),
                         "size": mo.get("size"),
                         "source_action": key}
    return found


def compose_document(ctx, spec):
    plan = ctx.plan
    doc = {"kind": plan.get("output_artifact_type"),
           "operation_id": ctx.operation_id,
           "title": plan.get("operation_title"),
           "step_deliverable": plan.get("step_deliverable"),
           "derived": {k: v for k, v in ctx.prior.items()},
           "source_sha256": [r.get("sha256") for r in ctx.refs]}
    media_ref = _media_ref_of_prior(ctx.prior)
    if media_ref is not None:
        doc[MEDIA_REF_FIELD] = media_ref
    ctx.result = (plan.get("output_artifact_type"),
                  json.dumps(doc, sort_keys=True))
    return {"composed": True, "kind": doc["kind"],
            "sections": sorted(doc["derived"].keys())}


def build_payload(ctx, spec):
    import payloads  # deferred: payloads is the proven builder module
    try:
        artifact_type, content = payloads.build(
            ctx.operation_id, ctx.production_id, ctx.unit_id,
            [{"artifact_type": r.get("artifact_type"),
              "artifact_id": r.get("artifact_id"),
              "sha256": r.get("sha256"),
              "content": r.get("content")} for r in ctx.refs])
    except payloads.UnboundOperationError as exc:
        raise ActionFailed(str(exc)) from None
    ctx.result = (artifact_type, content)
    return {"artifact_type": artifact_type,
            "content_sha256": _content_sha(content)}


def emit_output(ctx, spec):
    spec = spec or {}
    if ctx.result is None:
        raise ActionFailed("no producing action ran before emit_output")
    artifact_type, content = ctx.result
    expected_type = spec.get("artifact_type") or ctx.plan.get("output_artifact_type")
    if expected_type and artifact_type != expected_type:
        raise ActionFailed(
            f"produced artifact_type {artifact_type!r} != plan output {expected_type!r}")
    schema_name = spec.get("deliverable_schema")
    violations = []
    if schema_name:
        violations = _validate_deliverable(schema_name, content)
    return {"artifact_type": artifact_type,
            "content_sha256": _content_sha(content),
            "deliverable_schema": schema_name,
            "schema_violations": violations}


def _validate_deliverable(schema_name, content):
    """Check an exit payload against its Gate G deliverable schema,
    reusing the Gate E subset schema engine. Returns the violation
    list (possibly empty). Violations are REPORTED in the emit
    action's record, not raised: deliverable-schema verdicts belong to
    the evaluation service (Gate E) — pre-Gate-04 execution tolerated
    e.g. null upstream refs in builder output, and Gate 04
    decomposition must not change the 19 specific operations'
    execution behavior. (Judgment call, flagged in the gate report.)"""
    import sys
    from pathlib import Path
    gate_e = Path.home() / "workspace/video-factory-real-ai-programme/gate-e"
    if str(gate_e) not in sys.path:
        sys.path.insert(0, str(gate_e))
    from evaluation_service import schema_engine  # noqa: E402
    g1 = Path.home() / "workspace/video-factory-g1/contracts/deliverables"
    schema = json.loads((g1 / schema_name).read_text())
    value = content
    if isinstance(content, str):
        try:
            value = json.loads(content)
        except (json.JSONDecodeError, ValueError):
            value = content
    return schema_engine.validate(value, schema)


# ------------------------------------- Lean Phase 3: op 08.12 generation
def _ref_and_content(ctx, artifact_type):
    for ref in ctx.refs:
        if ref.get("artifact_type") == artifact_type:
            return ref, _parse(ref.get("content"))
    return None, None


def _script_inputs(ctx):
    """Resolve the generation inputs from the operation's CURRENT input
    artifacts. Returns (canon_id, canon_content, scenes, beat_story,
    context) where scenes is [{id, beat_ref}], beat_story maps beat id
    -> story node id, and context carries the parsed upstream
    deliverables for the prompt. Missing canon or scene data is an
    explicit failure: generation without them cannot be shaped."""
    canon_ref, canon_content = _ref_and_content(ctx, "canon_manifest")
    canon_id = (canon_ref or {}).get("artifact_id")
    if not canon_id:
        raise ActionFailed(
            "op.generate_script: no canon_manifest input ref — the canon "
            "artifact id must land in every script line's canon_refs")
    _, scene_content = _ref_and_content(ctx, "scene_set")
    scenes = []
    if isinstance(scene_content, dict):
        scenes = [s for s in (scene_content.get("scenes") or [])
                  if isinstance(s, dict) and s.get("id")]
    if not scenes:
        raise ActionFailed(
            "op.generate_script: scene_set input yields no scenes — "
            "scene coverage cannot be established")
    _, beat_content = _ref_and_content(ctx, "beat_graph")
    beat_story = {}
    if isinstance(beat_content, dict):
        for b in beat_content.get("beats") or []:
            if isinstance(b, dict) and b.get("id") and b.get("story_ref"):
                beat_story[b["id"]] = b["story_ref"]
    _, story_content = _ref_and_content(ctx, "story_architecture")
    context = {"canon_manifest": canon_content,
               "story_architecture": story_content,
               "beat_graph": beat_content,
               "scene_set": scene_content}
    return canon_id, scenes, beat_story, context


def _script_prompt(canon_id, scenes, context):
    def dump(value):
        if value is None:
            return "(unavailable)"
        if isinstance(value, str):
            return value
        return json.dumps(value, sort_keys=True, indent=1)
    scene_ids = ", ".join(s["id"] for s in scenes)
    return (
        "You are operation 08.12 \"Run text-fidelity\" of an automated "
        "video production factory. Write the versioned script for the "
        "scenes below, faithful to the canon manifest.\n\n"
        f"CANON MANIFEST (artifact id: {canon_id})\n"
        f"{dump(context['canon_manifest'])}\n\n"
        "STORY ARCHITECTURE (operation 05.12)\n"
        f"{dump(context['story_architecture'])}\n\n"
        "BEAT GRAPH (operation 06.12)\n"
        f"{dump(context['beat_graph'])}\n\n"
        "SCENE SET (operation 07.12)\n"
        f"{dump(context['scene_set'])}\n\n"
        "Respond with ONLY a JSON object (no markdown fences, no "
        "commentary) of exactly this shape:\n"
        '{"kind": "script", "lines": [{"id": "L1", "scene_ref": '
        '"<scene id>", "beat_ref": "<beat id>", "story_ref": '
        '"<story node id>", "canon_refs": ["' + canon_id + '"], '
        '"text": "<one line of script>"}], "trace": {"clues": '
        '[{"id": "CL1", "planted": "<line id>", "payoff": "<line id>"}], '
        '"knowledge": [{"character": "<name>", "learns": "<clue id>", '
        '"at": "<line id>"}], "payoffs": [{"id": "PO1", "clue": '
        '"<clue id>", "line": "<line id>"}]}, "canon_refs": ["'
        + canon_id + '"]}\n\n'
        f"Rules: every scene in the scene set ({scene_ids}) must be "
        "covered by at least one line; every line must carry the canon "
        "manifest artifact id in canon_refs; line text must be "
        "substantive script content grounded in the canon, beats and "
        "scenes above.")


def _extract_json_object(text):
    """The model's completion as a JSON object: tolerate markdown
    fences / surrounding prose by extracting the outermost object.
    Anything else is an explicit failure — no placeholder substitution."""
    if not isinstance(text, str):
        raise ActionFailed("provider completion is not text")
    candidate = text.strip()
    if candidate.startswith("```"):
        candidate = candidate.strip("`")
        if candidate.lower().startswith("json"):
            candidate = candidate[4:]
        candidate = candidate.strip()
    try:
        value = json.loads(candidate)
        if isinstance(value, dict):
            return value
    except (json.JSONDecodeError, ValueError):
        pass
    start, end = candidate.find("{"), candidate.rfind("}")
    if start >= 0 and end > start:
        try:
            value = json.loads(candidate[start:end + 1])
            if isinstance(value, dict):
                return value
        except (json.JSONDecodeError, ValueError):
            pass
    raise ActionFailed("provider completion is not a parseable JSON object")


_TRACE_FIELDS = {"clues": ("id", "planted", "payoff"),
                 "knowledge": ("character", "learns", "at"),
                 "payoffs": ("id", "clue", "line")}


def _shape_script(raw_text, canon_id, scenes, beat_story):
    """Shape a provider completion into the step-08 script deliverable.
    canon_refs values are SET from the actual canon input ref — never
    trusted from the model. Unparseable, incomplete or scene-uncovering
    output fails the action explicitly."""
    data = _extract_json_object(raw_text)
    raw_lines = data.get("lines")
    if not isinstance(raw_lines, list) or not raw_lines:
        raise ActionFailed("provider script has no lines")
    scene_beat = {s["id"]: s.get("beat_ref") for s in scenes}
    lines = []
    for i, raw in enumerate(raw_lines):
        if not isinstance(raw, dict):
            raise ActionFailed(f"provider script line {i} is not an object")
        text = raw.get("text")
        if not isinstance(text, str) or not text.strip():
            raise ActionFailed(f"provider script line {i} has no text")
        scene_ref = raw.get("scene_ref")
        if scene_ref not in scene_beat:
            raise ActionFailed(
                f"provider script line {i} references unknown scene "
                f"{scene_ref!r}")
        beat_ref = raw.get("beat_ref") or scene_beat[scene_ref]
        story_ref = raw.get("story_ref") or beat_story.get(beat_ref)
        if not beat_ref or not story_ref:
            raise ActionFailed(
                f"provider script line {i} lacks beat/story references "
                "and they cannot be derived from the scene/beat inputs")
        lines.append({"id": raw.get("id") or f"L{i + 1}",
                      "scene_ref": scene_ref, "beat_ref": beat_ref,
                      "story_ref": story_ref, "canon_refs": [canon_id],
                      "text": text})
    covered = {line["scene_ref"] for line in lines}
    missing = [s["id"] for s in scenes if s["id"] not in covered]
    if missing:
        raise ActionFailed(
            f"provider script does not cover scenes: {', '.join(missing)}")
    trace = data.get("trace")
    if not isinstance(trace, dict):
        raise ActionFailed("provider script has no trace object")
    shaped_trace = {}
    for key, fields in _TRACE_FIELDS.items():
        entries = trace.get(key)
        if not isinstance(entries, list):
            raise ActionFailed(f"provider script trace.{key} is not a list")
        for j, entry in enumerate(entries):
            if not isinstance(entry, dict) or any(
                    not isinstance(entry.get(f), str) or not entry.get(f)
                    for f in fields):
                raise ActionFailed(
                    f"provider script trace.{key}[{j}] lacks required "
                    f"fields {list(fields)}")
        shaped_trace[key] = entries
    return {"kind": "script", "lines": lines, "trace": shaped_trace,
            "canon_refs": [canon_id]}


# ------------------------------------- MM-06: local media tool actions
def _media_declaration(doc):
    """A media store reference declared by a payload document, as
    (sha256, via) or None. Declaration positions, in order:
      media_ref        — the stable field hoisted by compose_document
                         (MM-10 fix F-MM10-01);
      media_output     — a document that IS a media action's output
                         (or a direct adapter's media result);
      derived.*.media_output — the composed-document position of
                         pre-fix artifacts (the last media-bearing
                         derived section wins, mirroring the hoist);
      store_reference  — a document whose own storage_uri is a store
                         URI naming its sha256 field (the flite
                         adapter's speech_audio content shape)."""
    if not isinstance(doc, dict):
        return None
    ref = doc.get(MEDIA_REF_FIELD)
    if isinstance(ref, dict) and ref.get("sha256"):
        return ref["sha256"], "media_ref"
    mo = doc.get("media_output")
    if isinstance(mo, dict) and mo.get("sha256"):
        return mo["sha256"], "media_output"
    derived = doc.get("derived")
    if isinstance(derived, dict):
        found = None
        for out in derived.values():
            if isinstance(out, dict):
                mo = out.get("media_output")
                if isinstance(mo, dict) and mo.get("sha256"):
                    found = (mo["sha256"], "derived.media_output")
        if found:
            return found
    uri, sha = doc.get("storage_uri"), doc.get("sha256")
    if isinstance(uri, str) and isinstance(sha, str) \
            and uri.rsplit("/", 1)[-1] == sha:
        return sha, "store_reference"
    return None


def _declared_media(ref, artifact_bytes):
    """All media declarations an input artifact carries, in search
    order: the ref's resolved content first (the deliverable the
    worker service unwrapped), then the artifact bytes themselves
    (the raw document, and the envelope entry's content when the
    bytes are a step envelope). Returns [(sha256, via)]."""
    docs = []
    content = ref.get("content")
    if isinstance(content, dict):
        docs.append(content)
    elif isinstance(content, str):
        try:
            parsed = json.loads(content)
        except Exception:  # noqa: BLE001 — non-JSON content declares nothing
            parsed = None
        if isinstance(parsed, dict):
            docs.append(parsed)
    if artifact_bytes:
        try:
            parsed = json.loads(artifact_bytes)
        except Exception:  # noqa: BLE001
            parsed = None
        if isinstance(parsed, dict):
            docs.append(parsed)
            entries = parsed.get("output_artifacts")
            if isinstance(entries, list):
                for entry in entries:
                    if isinstance(entry, dict) \
                            and isinstance(entry.get("content"), dict):
                        docs.append(entry["content"])
    out, seen = [], set()
    for doc in docs:
        decl = _media_declaration(doc)
        if decl and decl[0] not in seen:
            seen.add(decl[0])
            out.append(decl)
    return out


def _media_inputs(ctx):
    """The operation's media inputs, in ref order. Returns
    [(ref, probe, data, media_sha256, via)].

    Resolution order per input ref (MM-10 fix F-MM10-01 — an
    artifact's recorded sha covers its composed JSON bytes, so media
    produced by an upstream operation is NOT reachable by artifact
    sha alone):
      1. direct — the artifact's own bytes (fetched by its recorded
         sha from the store) probe as media: a direct media artifact
         (e.g. raw media registered as an artifact);
      2. declared — the artifact's payload declares a media
         reference (see _media_declaration: media_ref / media_output
         / derived media_output / store reference) whose store bytes
         probe as media.
    A ref that resolves neither way is not a media input; the media
    actions keep failing explicitly when NO input resolves."""
    import media_tools
    found = []
    for ref in ctx.refs:
        sha = ref.get("sha256")
        if not sha:
            continue
        data = media_tools.fetch_media_bytes(sha)
        if data is not None:
            probe = media_tools.probe_bytes(data)
            if probe and probe.get("streams"):
                found.append((ref, probe, data, sha, "direct"))
                continue
        for media_sha, via in _declared_media(ref, data):
            if media_sha == sha:
                continue
            mdata = media_tools.fetch_media_bytes(media_sha)
            if mdata is None:
                continue
            probe = media_tools.probe_bytes(mdata)
            if probe and probe.get("streams"):
                found.append((ref, probe, mdata, media_sha, via))
                break
    return found


def _segment_records(ctx):
    """Cut segments declared by the operation's inputs: a list under
    segments/cuts/clips (or a single record) of {start_s, end_s}
    numeric-second ranges (start/end accepted). Editorial decisions
    live in the inputs; the tool only applies them."""
    segments = []
    for _ref, value in ctx.json_refs():
        candidates = []
        if isinstance(value, dict):
            for key in ("segments", "cuts", "clips"):
                if isinstance(value.get(key), list):
                    candidates = value[key]
                    break
            else:
                if "start_s" in value or "start" in value:
                    candidates = [value]
        elif isinstance(value, list):
            candidates = value
        for item in candidates:
            if not isinstance(item, dict):
                continue
            start = item.get("start_s", item.get("start"))
            end = item.get("end_s", item.get("end"))
            if isinstance(start, (int, float)) \
                    and isinstance(end, (int, float)) and end > start:
                segments.append((float(start), float(end)))
    return segments


def _declared_offset_ms(ctx, spec):
    if spec and isinstance(spec.get("audio_offset_ms"), (int, float)):
        return int(spec["audio_offset_ms"])
    for _ref, value in ctx.json_refs():
        if isinstance(value, dict):
            for key in ("audio_offset_ms", "sync_offset_ms"):
                if isinstance(value.get(key), (int, float)):
                    return int(value[key])
    return None


def _read_bytes(path):
    with open(path, "rb") as fh:
        return fh.read()


def _store_and_validate(out_path, expectations, content_type="video/mp4"):
    """Validate a produced media file with the MM-06 validator and
    promote its bytes into the artifact store. A file that fails its
    own validation fails the action — the tool checks its work."""
    import media_tools
    validation = media_tools.validate_media(out_path, expectations)
    if not validation["ok"]:
        raise ActionFailed(
            f"produced media failed self-validation: "
            f"{validation['failures']}")
    stored = media_tools.store_media_bytes(
        _read_bytes(out_path), content_type)
    return {**stored, "probe": validation["probe"]}, validation


def ffmpeg_process(ctx, spec):
    """MM-06 — media.process bound to the local FFmpeg tool.

    spec.transform selects the deterministic tool operation:
      cuts / reedit  — cut + concat the segments the inputs declare
      sync           — shift the audio by the declared offset
      ambience       — pad/trim the audio bed to the picture duration
      mix            — two-pass EBU R128 loudnorm (measured in/out)
      color_check    — signalstats + loudness MEASUREMENT (no output
                       media; the measurements are the product)
      fix_errors     — full re-encode repair to the master spec
      reframe        — scale/pad to the spec's target frame
      narration_adapt— extract + normalize the narration audio (WAV),
                       extracting a subtitle stream when present

    The source is the first input artifact that resolves to media
    bytes in the store; with none, the action fails explicitly —
    there is no fabricated media output."""

    import media_tools as mt

    spec = spec or {}
    transform = spec.get("transform")
    media = _media_inputs(ctx)
    if not media:
        raise ActionFailed(
            "media.ffmpeg_process: no input artifact resolves to media "
            "bytes in the artifact store — nothing to process")
    ref, probe_before, data, media_sha, media_via = media[0]
    has_audio = mt.first_stream(probe_before, "audio") is not None
    has_video = mt.first_stream(probe_before, "video") is not None
    base = {"transform": transform,
            "media_input": {"artifact_id": ref.get("artifact_id"),
                            "artifact_type": ref.get("artifact_type"),
                            "sha256": ref.get("sha256"),
                            "media_sha256": media_sha,
                            "resolved_via": media_via},
            "probe_before": probe_before}
    with mt.workdir("mm06-media-") as workdir:
        src = workdir / "input.media"
        src.write_bytes(data)
        out = workdir / "output.mp4"
        master_exp = {"video_codec": mt.MASTER["video_codec"],
                      "audio_codec": mt.MASTER["audio_codec"],
                      "sample_rate": mt.MASTER["sample_rate"],
                      "require_video": True, "require_audio": has_audio}

        if transform == "color_check":
            if not has_video:
                raise ActionFailed("color_check: input has no video stream")
            validation = mt.validate_media(src, {"require_video": True})
            if not validation["ok"]:
                raise ActionFailed(
                    f"color_check: input media invalid: {validation['failures']}")
            result = {**base, "media_output": None,
                      "validation": {"ok": True, "failures": []},
                      "measurements": {
                          "signalstats": mt.measure_signalstats(src),
                          "loudnorm": mt.measure_loudnorm(src) if has_audio
                          else None}}
            return result

        if transform in ("cuts", "reedit"):
            segments = _segment_records(ctx)
            if not segments:
                raise ActionFailed(
                    f"{transform}: inputs declare no cut segments "
                    "(segments[] with start_s/end_s) — the tool applies "
                    "declared edits, it does not invent them")
            filt = []
            for i, (start, end) in enumerate(segments):
                filt.append(f"[0:v]trim=start={start}:end={end},"
                            f"setpts=PTS-STARTPTS[v{i}]")
                if has_audio:
                    filt.append(f"[0:a]atrim=start={start}:end={end},"
                                f"asetpts=PTS-STARTPTS[a{i}]")
            labels = "".join(f"[v{i}]" + (f"[a{i}]" if has_audio else "")
                             for i in range(len(segments)))
            filt.append(f"{labels}concat=n={len(segments)}:v=1:"
                        f"a={1 if has_audio else 0}[v]"
                        + ("[a]" if has_audio else ""))
            args = ["-i", str(src), "-filter_complex", ";".join(filt),
                    "-map", "[v]"]
            if has_audio:
                args += ["-map", "[a]"]
            args += mt.master_encode_args() + [str(out), "-y"]
            mt.ffmpeg(args)
            if not has_audio:
                silent = workdir / "with-audio.mp4"
                mt.ffmpeg(["-i", str(out), "-f", "lavfi", "-i",
                           "anullsrc=r=48000:cl=stereo", "-shortest",
                           "-c:v", "copy", "-c:a", "aac", str(silent), "-y"])
                out = silent
            stored, validation = _store_and_validate(out, master_exp)
            return {**base, "media_output": stored,
                    "validation": {"ok": True, "failures": []},
                    "segments_applied": [{"start_s": s, "end_s": e}
                                         for s, e in segments]}

        if transform == "sync":
            offset_ms = _declared_offset_ms(ctx, spec)
            if offset_ms is None:
                raise ActionFailed(
                    "sync: no audio offset declared (spec.audio_offset_ms "
                    "or an input's audio_offset_ms/sync_offset_ms) — the "
                    "tool applies a declared offset, it does not guess one")
            if not has_audio:
                raise ActionFailed("sync: input has no audio stream to shift")
            args = ["-i", str(src), "-itsoffset", f"{offset_ms / 1000:.3f}",
                    "-i", str(src), "-map", "0:v", "-map", "1:a"]
            args += mt.master_encode_args() + [str(out), "-y"]
            mt.ffmpeg(args)
            stored, validation = _store_and_validate(out, master_exp)
            return {**base, "media_output": stored,
                    "validation": {"ok": True, "failures": []},
                    "audio_offset_ms_applied": offset_ms}

        if transform == "ambience":
            if not has_audio or not has_video:
                raise ActionFailed(
                    "ambience: input needs both audio and video streams")
            duration = probe_before["duration_s"]
            video = mt.first_stream(probe_before, "video")
            target = video.get("duration_s") or duration
            args = ["-i", str(src), "-filter_complex",
                    f"[0:a]apad=whole_dur={target},atrim=end={target},"
                    f"aresample=48000[a]", "-map", "0:v", "-map", "[a]"]
            args += mt.master_encode_args() + ["-t", str(target),
                                               str(out), "-y"]
            mt.ffmpeg(args)
            stored, validation = _store_and_validate(out, master_exp)
            return {**base, "media_output": stored,
                    "validation": {"ok": True, "failures": []},
                    "audio_bed_duration_s": target}

        if transform == "mix":
            if not has_audio:
                raise ActionFailed("mix: input has no audio stream")
            measured = mt.measure_loudnorm(src)
            loud = (f"loudnorm=I=-16:TP=-1.5:LRA=11:"
                    f"measured_I={measured['input_i']}:"
                    f"measured_TP={measured['input_tp']}:"
                    f"measured_LRA={measured['input_lra']}:"
                    f"measured_thresh={measured['input_thresh']}:linear=true")
            args = ["-i", str(src), "-af", loud]
            args += mt.master_encode_args() + [str(out), "-y"]
            mt.ffmpeg(args)
            stored, validation = _store_and_validate(out, master_exp)
            after = mt.measure_loudnorm(out)
            return {**base, "media_output": stored,
                    "validation": {"ok": True, "failures": []},
                    "loudness_before": measured,
                    "loudness_after": after,
                    "target_lufs": -16.0}

        if transform == "fix_errors":
            args = ["-err_detect", "ignore_err", "-i", str(src)]
            args += mt.master_encode_args() + [str(out), "-y"]
            mt.ffmpeg(args)
            stored, validation = _store_and_validate(out, master_exp)
            return {**base, "media_output": stored,
                    "validation": {"ok": True, "failures": []},
                    "repair": "full re-encode to master spec"}

        if transform == "reframe":
            target = spec.get("target") or {}
            width, height = target.get("width"), target.get("height")
            if not width or not height:
                raise ActionFailed(
                    "reframe: spec.target {width, height} is required")
            args = ["-i", str(src)]
            args += mt.master_encode_args(width, height) + [str(out), "-y"]
            mt.ffmpeg(args)
            exp = {**master_exp, "width": width, "height": height}
            stored, validation = _store_and_validate(out, exp)
            return {**base, "media_output": stored,
                    "validation": {"ok": True, "failures": []},
                    "target": {"width": width, "height": height}}

        if transform == "narration_adapt":
            if not has_audio:
                raise ActionFailed(
                    "narration_adapt: input has no audio (narration) stream")
            wav = workdir / "narration.wav"
            mt.ffmpeg(["-i", str(src), "-vn", "-af",
                       "loudnorm=I=-16:TP=-1.5:LRA=11", "-ar", "48000",
                       "-ac", "1", "-c:a", "pcm_s16le", str(wav), "-y"])
            validation = mt.validate_media(
                wav, {"require_video": False, "require_audio": True,
                      "audio_codec": "pcm_s16le", "sample_rate": 48000})
            if not validation["ok"]:
                raise ActionFailed(
                    f"narration_adapt: produced audio failed validation: "
                    f"{validation['failures']}")
            stored = mt.store_media_bytes(wav.read_bytes(), "audio/wav")
            stored = {**stored, "probe": validation["probe"]}
            subtitles = None
            sub_stream = mt.first_stream(probe_before, "subtitle")
            if sub_stream is not None:
                srt = workdir / "subtitles.srt"
                try:
                    mt.ffmpeg(["-i", str(src), "-map", "0:s:0", "-c:s", "srt",
                               str(srt), "-y"])
                    sub_stored = mt.store_media_bytes(
                        srt.read_bytes(), "application/x-subrip")
                    subtitles = {**sub_stored, "format": "srt"}
                except mt.MediaToolError:
                    subtitles = {"extraction_failed": True}
            return {**base, "media_output": stored,
                    "validation": {"ok": True, "failures": []},
                    "subtitles": subtitles}

        raise ActionFailed(
            f"media.ffmpeg_process: unknown transform {transform!r}")


def ffmpeg_render(ctx, spec):
    """MM-06 — media.render (op 13.03) bound to the local FFmpeg
    tool: render the review master deterministically. All media
    inputs are concatenated in input order (single input = itself)
    and encoded to the review-master spec from the plan spec
    (default 1280x720, CRF 18, H.264 + AAC 48 kHz, faststart)."""

    import media_tools as mt

    spec = spec or {}
    width = spec.get("width", 1280)
    height = spec.get("height", 720)
    crf = spec.get("crf", 18)
    media = _media_inputs(ctx)
    if not media:
        raise ActionFailed(
            "media.ffmpeg_render: no input artifact resolves to media "
            "bytes in the artifact store — nothing to render")
    with mt.workdir("mm06-render-") as workdir:
        paths = []
        any_audio = False
        for i, (ref, probe, data, _msha, _via) in enumerate(media):
            path = workdir / f"input-{i}.media"
            path.write_bytes(data)
            paths.append(path)
            if mt.first_stream(probe, "audio") is not None:
                any_audio = True
        out = workdir / "review-master.mp4"
        if len(paths) == 1:
            args = ["-i", str(paths[0])]
        else:
            listfile = workdir / "concat.txt"
            listfile.write_text("".join(f"file '{p}'\n" for p in paths))
            args = ["-f", "concat", "-safe", "0", "-i", str(listfile)]
        args += mt.master_encode_args(width, height, crf=crf)
        args += ["-movflags", "+faststart", str(out), "-y"]
        mt.ffmpeg(args)
        stored, validation = _store_and_validate(
            out, {"video_codec": mt.MASTER["video_codec"],
                  "audio_codec": mt.MASTER["audio_codec"],
                  "sample_rate": mt.MASTER["sample_rate"],
                  "width": width, "height": height,
                  "require_video": True, "require_audio": any_audio})
        return {"transform": "render",
                "media_input": {"count": len(media),
                                "sha256": [r.get("sha256") for r, *_ in media],
                                "media_sha256": [m[3] for m in media],
                                "resolved_via": [m[4] for m in media]},
                "media_output": stored,
                "validation": {"ok": True, "failures": []},
                "master_spec": {"width": width, "height": height, "crf": crf,
                                "video_codec": mt.MASTER["video_codec"],
                                "audio_codec": mt.MASTER["audio_codec"],
                                "sample_rate": mt.MASTER["sample_rate"]}}


def synthesize_speech(ctx, spec):
    """MM-06 — local text-to-speech (LOCAL_TOOL) via the ffmpeg
    flite source (libflite). Text comes from spec.text or the first
    text-bearing input. The synthesized WAV is stored and probe-
    validated; the output is labeled with its engine and
    simulated=False (it is a real, if robotic, synthesis — not a
    mock and not a production voice)."""

    import media_tools as mt

    spec = spec or {}
    text = spec.get("text")
    if not text:
        for _ref, value in ctx.json_refs():
            if isinstance(value, str) and value.strip():
                text = value
                break
            if isinstance(value, dict) and isinstance(
                    value.get("text"), str) and value["text"].strip():
                text = value["text"]
                break
    if not text:
        raise ActionFailed(
            "media.synthesize_speech: no text available (spec.text or "
            "a text input is required)")
    voice = spec.get("voice", "slt")
    with mt.workdir("mm06-tts-") as workdir:
        wav = workdir / "speech.wav"
        probe = mt.synthesize_speech_wav(text, wav, voice=voice)
        validation = mt.validate_media(
            wav, {"require_video": False, "require_audio": True,
                  "min_duration_s": 0.1})
        if not validation["ok"]:
            raise ActionFailed(
                f"media.synthesize_speech: output failed validation: "
                f"{validation['failures']}")
        stored = mt.store_media_bytes(wav.read_bytes(), "audio/wav")
        return {"media_output": {**stored, "probe": probe},
                "duration_s": probe["duration_s"],
                "engine": "ffmpeg-flite-local",
                "voice": voice, "characters": len(text),
                "simulated": False, "label": "LOCAL_TOOL"}


def generate_script(ctx, spec):
    """Lean Phase 3 (op 08.12) — provider-aware script generation,
    dispatched STRICTLY on the attempt's pinned binding:

    - deterministic-local / mock / unbound: the proven deterministic
      payload builder, byte-identical output (build_payload path);
    - openrouter-compatible: genuine provider generation executed
      INSIDE plan execution — prompt assembled from the resolved
      current inputs, completion shaped worker-side into the step-08
      deliverable, usage + provider_request_id recorded as provider
      evidence. A missing credential is a REFUSAL (ActionRefused ->
      BLOCKED), never a deterministic fallback;
    - any other provider: explicit failure (this implementation does
      not serve it)."""
    binding = ctx.binding or {}
    provider = binding.get("provider")
    if provider in (None, "deterministic-local", "mock"):
        return build_payload(ctx, spec)
    if provider != "openrouter-compatible":
        raise ActionFailed(
            f"op.generate_script does not serve provider {provider!r}")
    import adapters as adapters_mod  # deferred: adapters imports payloads
    import gateway as gateway_mod  # deferred: gateway imports adapters
    adapter = adapters_mod.OpenRouterCompatibleAdapter()
    try:
        credential = adapter.require_credential(binding)
    except adapters_mod.BlockedError as exc:
        raise ActionRefused(str(exc)) from None
    canon_id, scenes, beat_story, context = _script_inputs(ctx)
    prompt = _script_prompt(canon_id, scenes, context)
    # MM-04: the provider call runs through the gateway (context-limit
    # check, bounded retries, assignment-authorized fallback,
    # correlation id, limiter, health). The gateway dispatches on the
    # same pinned binding; a credential refusal already happened above
    # and a provider failure re-raises typed — never a fallback to the
    # deterministic builder.
    gw_ctx = ctx.gateway or gateway_mod.GatewayContext(
        dsn=os.environ.get("WORKER_DSN"))
    try:
        result = gateway_mod.execute_chain(
            adapter, binding,
            {"prompt": prompt, "operation_id": ctx.operation_id,
             "production_id": ctx.production_id, "unit_id": ctx.unit_id,
             "attempt_id": ctx.attempt_id},
            credential, gw_ctx)
    except adapters_mod.ProviderError as exc:
        meta = getattr(exc, "gateway", None) or {}
        ctx.provider_evidence = {
            "provider": provider,
            "model": meta.get("model") or binding.get("model"),
            "usage": {}, "provider_request_id": None,
            "correlation_id": meta.get("correlation_id"),
            "usage_lines": meta.get("usage_lines"),
            "fallback_event": meta.get("fallback_event")}
        raise
    script = _shape_script(result.get("content"), canon_id, scenes,
                           beat_story)
    content = json.dumps(script, sort_keys=True)
    ctx.result = ("script", content)
    meta = result.get("gateway") or {}
    ctx.provider_evidence = {
        "provider": provider,
        "model": meta.get("model") or binding.get("model"),
        "usage": result.get("usage") or {},
        "provider_request_id": result.get("provider_request_id"),
        "correlation_id": meta.get("correlation_id"),
        "usage_lines": meta.get("usage_lines"),
        "fallback_event": meta.get("fallback_event")}
    return {"artifact_type": "script",
            "content_sha256": _content_sha(content),
            "provider": provider,
            "model": meta.get("model") or binding.get("model"),
            "usage": result.get("usage") or {},
            "provider_request_id": result.get("provider_request_id"),
            "correlation_id": meta.get("correlation_id"),
            "fallback_event": meta.get("fallback_event")}


# ------------------------------------- MM-10: simulated implementations
# The four action classes Gate 04 left UNBOUND (creative.generate,
# media.generate, external.platform, external.provider) gain EXPLICITLY
# SIMULATED implementations for the MM-10 full mock end-to-end
# acceptance. The discipline is fail-closed, mirroring op.generate_
# script's binding dispatch (Lean Phase 3): an implementation runs
# ONLY when the attempt's pinned binding provider is 'mock' — the one
# binding under which simulation is the declared, labeled behavior.
# Under any other binding (deterministic-local, a credentialed
# provider, or no binding at all) it raises ActionRefused: BLOCKED
# evidence, never a silent fallback and never a simulated result
# wearing a non-mock label. Every output carries simulated: true and
# its generator name, in-band, so the simulation marking survives
# into the composed artifact bytes themselves.

def _require_mock_binding(ctx, impl_name):
    provider = (ctx.binding or {}).get("provider")
    if provider != "mock":
        raise ActionRefused(
            f"{impl_name} is an explicitly simulated implementation "
            f"and runs only under a pinned 'mock' binding; the "
            f"attempt's pinned provider is {provider!r} — refusing "
            f"rather than producing simulated output under a "
            f"non-mock label (no genuine implementation of this "
            f"action class is bound in this build)")


def _source_records(ctx):
    """Records available to ground a simulated generation: outputs of
    earlier records-producing actions first, then record-shaped input
    contents. Returns (records, source_description)."""
    for key in sorted(ctx.prior):
        out = ctx.prior[key]
        if isinstance(out, dict) and isinstance(out.get("records"), list) \
                and out["records"]:
            return out["records"], f"prior:{key}"
    for ref, value in ctx.json_refs():
        records, _field = _records_of(value)
        if records:
            return records, f"input:{ref.get('artifact_type')}"
    return [], "none"


def _scalar_snapshot(record):
    """JSON-safe scalar fields of a source record (structure grounding
    for a simulated derivative record)."""
    if not isinstance(record, dict):
        return {"value": str(record)[:120]}
    out = {}
    for key, val in sorted(record.items()):
        if isinstance(val, (str, int, float, bool)) or val is None:
            out[key] = val
    return out


def mock_creative_generate(ctx, spec):
    """MM-10 — creative.generate, explicitly simulated. Produces
    deterministic fixture authoring DERIVED FROM the operation's
    inputs: one generated record per source record, each carrying the
    source's scalar structure plus fixture text that names itself
    simulated in-band. With no source records, a single fixture
    record is derived from the operation's own plan context (a
    provider could author from the brief alone; the fixture says so).
    """
    _require_mock_binding(ctx, "mock.creative.generate")
    records, source = _source_records(ctx)
    title = ctx.plan.get("operation_title") or ctx.operation_id
    generated = []
    basis = records if records else [None]
    for i, record in enumerate(basis):
        entry = {"id": f"SIM-{ctx.operation_id.replace('.', '')}-{i + 1:03d}",
                 "simulated": True,
                 "generator": "mock.creative.generate",
                 "derived_from": source}
        entry.update(_scalar_snapshot(record) if record is not None else {})
        entry["fixture_text"] = (
            f"[SIMULATED {ctx.operation_id}] fixture authoring for "
            f"'{title}' derived from {source} record {i + 1} — mock "
            f"content for end-to-end pipeline acceptance, not "
            f"creative work product.")
        generated.append(entry)
    return {"records": generated, "count": len(generated),
            "simulated": True, "generator": "mock.creative.generate",
            "grounding": {"source": source,
                          "input_refs": [r.get("artifact_id")
                                         for r in ctx.refs]}}


def mock_media_generate(ctx, spec):
    """MM-10 — media.generate, explicitly simulated. Produces REAL
    media bytes with the MM-06 local tooling (lavfi test source +
    sine tone, master encode), stored in the artifact store and
    probe-validated before the action succeeds — the bytes are real,
    the content is a labeled test pattern: simulated generation, not
    production media. Self-validation failure fails the action."""
    _require_mock_binding(ctx, "mock.media.generate")
    import media_tools as mt
    with mt.workdir("mm10-mediagen-") as workdir:
        out = workdir / "generated.mp4"
        mt.ffmpeg(["-f", "lavfi", "-i",
                   "testsrc2=duration=2:size=640x360:rate=30",
                   "-f", "lavfi", "-i", "sine=frequency=440:duration=2"]
                  + mt.master_encode_args() + [str(out), "-y"])
        validation = mt.validate_media(
            out, {"video_codec": mt.MASTER["video_codec"],
                  "audio_codec": mt.MASTER["audio_codec"],
                  "sample_rate": mt.MASTER["sample_rate"],
                  "require_video": True, "require_audio": True})
        if not validation["ok"]:
            raise ActionFailed(
                f"mock.media.generate: produced media failed "
                f"self-validation: {validation['failures']}")
        stored = mt.store_media_bytes(_read_bytes(out), "video/mp4")
    return {"media_output": {**stored, "probe": validation["probe"]},
            "validation": {"ok": True, "failures": []},
            "simulated": True, "generator": "mock.media.generate",
            "label": "SIMULATED_MEDIA",
            "content_description": "lavfi testsrc2 + 440Hz sine, 2s, "
                                   "640x360 — a test pattern, not "
                                   "production media"}


def mock_external_platform(ctx, spec):
    """MM-10 — external.platform, explicitly simulated. Produces a
    platform-interaction receipt in the MM-06 15.12 labeling style:
    simulated: true, provider mock-platform, status SIMULATED. The
    receipt id is a deterministic hash of the operation, production
    and input references — an idempotency-shaped fixture, not a
    platform-issued identifier."""
    _require_mock_binding(ctx, "mock.external.platform")
    material = {"operation_id": ctx.operation_id,
                "production_id": ctx.production_id,
                "unit_id": ctx.unit_id,
                "inputs": [r.get("sha256") for r in ctx.refs]}
    receipt = {"receipt_id": "sim-" + _sha_text(_canon(material))[:24],
               "platform": "mock-platform",
               "operation_id": ctx.operation_id,
               "action": ctx.plan.get("operation_title"),
               "status": "SIMULATED",
               "simulated": True,
               "provider": "mock-platform-publisher",
               "note": "no platform was contacted; this receipt is a "
                       "fixture of the MM-10 mock acceptance run"}
    return {"receipt": receipt, "records": [receipt],
            "simulated": True, "generator": "mock.external.platform"}


def mock_external_provider(ctx, spec):
    """MM-10 — external.provider, explicitly simulated. Produces a
    provider-interaction record set derived from the operation's
    inputs (text inputs are segmented into fixture claim records;
    other inputs are echoed as record structure), every record
    carrying the simulated marker. No provider is contacted."""
    _require_mock_binding(ctx, "mock.external.provider")
    records, source = _source_records(ctx)
    generated = []
    text_chunks = []
    for _ref, value in ctx.json_refs():
        if isinstance(value, str) and value.strip():
            text_chunks.extend(
                s.strip() for s in value.replace("\n", " ").split(". ")
                if s.strip())
    if text_chunks:
        for i, chunk in enumerate(text_chunks):
            generated.append({
                "id": f"SIM-{ctx.operation_id.replace('.', '')}-{i + 1:03d}",
                "simulated": True, "generator": "mock.external.provider",
                "derived_from": source, "text": chunk[:300]})
    else:
        basis = records if records else [None]
        for i, record in enumerate(basis):
            entry = {"id": f"SIM-{ctx.operation_id.replace('.', '')}-{i + 1:03d}",
                     "simulated": True,
                     "generator": "mock.external.provider",
                     "derived_from": source}
            entry.update(_scalar_snapshot(record) if record is not None
                         else {})
            generated.append(entry)
    return {"records": generated, "count": len(generated),
            "simulated": True, "generator": "mock.external.provider",
            "interaction": {"provider": "mock-provider",
                            "contacted": False,
                            "kind": "fixture_interaction"},
            "grounding": {"source": source,
                          "input_refs": [r.get("artifact_id")
                                         for r in ctx.refs]}}


# ------------------------------------------------------------- registry
def _spec(required=(), properties=None):
    return {"type": "object", "required": list(required),
            "properties": properties or {}}


ACTION_IMPLEMENTATIONS = {
    "engine.manifest_inputs": manifest_inputs,
    "engine.analyze_content": analyze_content,
    "engine.extract_records": extract_records,
    "engine.index_records": index_records,
    "engine.project_records": project_records,
    "engine.group_records": group_records,
    "engine.assign_stable_ids": assign_stable_ids,
    "engine.cross_check_refs": cross_check_refs,
    "engine.verify_fields": verify_fields,
    "engine.sort_chronology": sort_chronology,
    "engine.aggregate_metrics": aggregate_metrics,
    "engine.hash_attest": hash_attest,
    "engine.compose_document": compose_document,
    "engine.emit_output": emit_output,
    "op.build_payload": build_payload,
    "op.generate_script": generate_script,
    "media.ffmpeg_process": ffmpeg_process,
    "media.ffmpeg_render": ffmpeg_render,
    "media.synthesize_speech": synthesize_speech,
    "mock.creative.generate": mock_creative_generate,
    "mock.media.generate": mock_media_generate,
    "mock.external.platform": mock_external_platform,
    "mock.external.provider": mock_external_provider,
}

INPUT_SPECS = {
    "engine.manifest_inputs": _spec(),
    "engine.analyze_content": _spec(),
    "engine.extract_records": _spec(properties={
        "artifact_type": {"type": "string"}, "field": {"type": "string"}}),
    "engine.index_records": _spec(properties={
        "from_action": {"type": "string"}, "key": {"type": "string"}}),
    "engine.project_records": _spec(required=("from_action", "fields")),
    "engine.group_records": _spec(required=("from_action", "group_field")),
    "engine.assign_stable_ids": _spec(required=("from_action",), properties={
        "prefix": {"type": "string"}, "field": {"type": "string"}}),
    "engine.cross_check_refs": _spec(properties={
        "id_field": {"type": "string"}}),
    "engine.verify_fields": _spec(required=("from_action", "required_fields")),
    "engine.sort_chronology": _spec(required=("from_action",), properties={
        "date_field": {"type": "string"}}),
    "engine.aggregate_metrics": _spec(required=("from_action",), properties={
        "numeric_fields": {"type": "array"}}),
    "engine.hash_attest": _spec(),
    "engine.compose_document": _spec(),
    "engine.emit_output": _spec(properties={
        "artifact_type": {"type": "string"},
        "deliverable_schema": {"type": "string"}}),
    "op.build_payload": _spec(),
    "op.generate_script": _spec(),
    "media.ffmpeg_process": _spec(required=("transform",), properties={
        "transform": {"type": "string"},
        "audio_offset_ms": {"type": "number"},
        "target": {"type": "object"}}),
    "media.ffmpeg_render": _spec(properties={
        "width": {"type": "integer"}, "height": {"type": "integer"},
        "crf": {"type": "integer"}}),
    "media.synthesize_speech": _spec(properties={
        "text": {"type": "string"}, "voice": {"type": "string"}}),
    "mock.creative.generate": _spec(),
    "mock.media.generate": _spec(),
    "mock.external.platform": _spec(),
    "mock.external.provider": _spec(),
}

OUTPUT_SPECS = {
    "engine.manifest_inputs": _spec(("inputs", "count")),
    "engine.analyze_content": _spec(("analyses", "count")),
    "engine.extract_records": _spec(("records", "count")),
    "engine.index_records": _spec(("index", "count")),
    "engine.project_records": _spec(("records", "count")),
    "engine.group_records": _spec(("groups", "count")),
    "engine.assign_stable_ids": _spec(("records", "assigned")),
    "engine.cross_check_refs": _spec(("checked_refs", "dangling", "verdict")),
    "engine.verify_fields": _spec(("checked", "violations", "verdict")),
    "engine.sort_chronology": _spec(("records", "inversions")),
    "engine.aggregate_metrics": _spec(("metrics", "record_count")),
    "engine.hash_attest": _spec(("attestation_sha256", "input_sha256")),
    "engine.compose_document": _spec(("composed", "kind")),
    "engine.emit_output": _spec(("artifact_type", "content_sha256",
                                 "schema_violations")),
    "op.build_payload": _spec(("artifact_type", "content_sha256")),
    "op.generate_script": _spec(("artifact_type", "content_sha256")),
    "media.ffmpeg_process": _spec(("transform", "media_input",
                                   "media_output", "validation")),
    "media.ffmpeg_render": _spec(("transform", "media_input",
                                  "media_output", "validation")),
    "media.synthesize_speech": _spec(("media_output", "duration_s",
                                      "engine")),
    "mock.creative.generate": _spec(("records", "count", "simulated",
                                     "generator")),
    "mock.media.generate": _spec(("media_output", "simulated",
                                  "generator", "validation")),
    "mock.external.platform": _spec(("receipt", "simulated", "generator")),
    "mock.external.provider": _spec(("records", "count", "simulated",
                                     "generator")),
}
