#!/usr/bin/env python3
"""Gate C worker service — the production worker contract (master prompt §8).

Stateless HTTP front-end over the adapter layer. The COORDINATOR remains
the only durable record and the only authority: jobs held here are an
in-memory continuation map for async providers (provider_job_id ->
adapter + binding snapshot), never a state store. A restart loses the
map, not the truth — the coordinator's reconciler owns recovery (B1.4).

POST /work   §8 request: {unit_id, attempt_id, fencing_token,
             operation_id, production_id, idempotency_key,
             provider_binding (the attempt's resolved config snapshot),
             input_artifact_refs, deadline_s, budget_authorization,
             prompt?}. Sync bindings execute inline; bindings whose
             params.mode == 'async' submit and return the provider job id.
POST /jobs   same as /work with async forced.
GET  /jobs/{provider_job_id}   poll an async job submitted via this service.
GET  /health adapter readiness: credential adapters are BLOCKED unless a
             credential named in WORKER_CREDENTIAL_REFS (comma-separated
             env-var names) is present in the environment.

Env: WORKER_SERVICE_PORT (default 8799), WORKER_ENVIRONMENT (test|
production, default test), WORKER_CREDENTIAL_REFS, FACTORY_STORAGE_*
(Gate D store, for input-artifact content resolution).

Gate G additions:
  * Input resolution: a /work request's input_artifact_refs may carry
    wire refs {artifact_id, artifact_type, sha256, storage_uri} without
    content. The service fetches the bytes from the Gate D store by sha
    (content-addressed) and hands the payload builders the DELIVERABLE:
    for envelope bytes, the matching output_artifacts entry's content;
    for bare JSON, the parsed value; for plain text, the text. Refs
    that already carry `content` pass through untouched (Gate C shape).
  * Envelope production (OD-E1 iii): step-exit results from the
    payload-backed adapters are wrapped by envelope.py; the /work
    response `content` is the envelope JSON for exits, the bare payload
    otherwise.
  * force_fail: the retired per-station mock workers honored a
    `force_fail` flag in the /work body (the G9 failure battery depends
    on it). The deterministic path honors it here: a forced failure is
    a ProviderError, never a fabricated result.
"""
import json
import os
import sys
import threading
import urllib.error
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

import adapters as adapters_mod
import envelope as envelope_mod
import gateway as gateway_mod
import plan_exec as plan_exec_mod
import plans as plans_mod

GATE_D = Path.home() / "workspace/video-factory-real-ai-programme/gate-d"
if str(GATE_D) not in sys.path:
    sys.path.insert(0, str(GATE_D))

ENVIRONMENT = os.environ.get("WORKER_ENVIRONMENT", "test")
REGISTRY = adapters_mod.build_registry(ENVIRONMENT)
_JOBS = {}
_JOBS_LOCK = threading.Lock()
_STORAGE = None


def _storage():
    global _STORAGE
    if _STORAGE is None:
        from storage_service import factory_from_env
        _STORAGE = factory_from_env()
    return _STORAGE


def _resolve_input_refs(request):
    """Wire refs -> builder refs (see module docstring). Returns a new
    request dict; the caller's dict is not mutated."""
    refs = request.get("input_artifact_refs") or []
    if not refs or all(isinstance(r, dict) and "content" in r for r in refs):
        return request
    from storage_service import final_uri
    out = []
    for ref in refs:
        if not isinstance(ref, dict) or "content" in ref:
            out.append(ref)
            continue
        content = None
        sha = ref.get("sha256")
        if sha:
            try:
                raw = _storage().get(final_uri(sha))
            except Exception:  # noqa: BLE001 — absent bytes = content unavailable
                raw = None
            if raw is not None:
                unwrapped = envelope_mod.unwrap_entry(raw, ref.get("artifact_type"))
                if unwrapped is not None:
                    content = unwrapped
                else:
                    try:
                        content = json.loads(raw)
                    except Exception:  # noqa: BLE001 — plain-text payload
                        content = raw.decode("utf-8", errors="replace")
        out.append({**ref, "content": content})
    return {**request, "input_artifact_refs": out}


def adapter_health():
    refs = [r.strip() for r in os.environ.get("WORKER_CREDENTIAL_REFS", "").split(",")
            if r.strip()]
    out = {}
    for name, a in REGISTRY.items():
        if not a.credential_required:
            status = "READY"
            if name == "mock" and ENVIRONMENT != "test":
                status = "BLOCKED"
        else:
            status = "READY" if any(os.environ.get(r) for r in refs) else "BLOCKED"
        out[name] = {"status": status, "modality": a.modality,
                     "credential_required": a.credential_required}
    return out


def _adapter_for(binding):
    name = (binding or {}).get("provider")
    adapter = REGISTRY.get(name)
    if adapter is None:
        raise adapters_mod.ProviderError(f"no adapter registered for provider {name!r}",
                                         error_class="UNKNOWN_PROVIDER")
    return adapter


def _result_payload(binding, result, request=None, plan_executed=False):
    cost = result.get("cost_cents")
    if cost is None:
        cost = binding.get("est_cost_cents")
    # Cost honesty on the provider path (Lean Phase 3, spec C-3) is
    # enforced at the coordinator's evidence layer, not here: the
    # adapter reported cost_cents None, the binding carries NO
    # reported_actual_cents param, and the completion's FINALIZED
    # amount comes from CALCULATED evidence (seeded pricing rules x
    # the recorded token usage) — the estimate fallback above remains
    # the shipped Gate C convention because /complete requires an
    # integer actual_cost_cents and executors pass this value through.
    content = result.get("content")
    wrapped = envelope_mod.wrap(binding, request or {}, result.get("artifact_type"),
                                content, plan_executed=plan_executed)
    if wrapped is not None:
        content = wrapped
    payload = {"status": "COMPLETED",
               "artifact_type": result.get("artifact_type"),
               "content": content,
               "usage": result.get("usage") or {},
               "provider_request_id": result.get("provider_request_id"),
               "actual_cost_cents": cost,
               "plan_execution": result.get("plan_execution")}
    # MM-04: gateway metadata rides the response so the completion can
    # carry the EXECUTED model (fallback pricing), the chain's
    # correlation id and its per-call usage-evidence lines. Absent for
    # every non-gateway path (payload adapters, plan executions whose
    # evidence travels in the plan summary instead).
    gw = result.get("gateway")
    if gw:
        payload["model"] = gw.get("model")
        payload["correlation_id"] = gw.get("correlation_id")
        payload["usage_lines"] = gw.get("usage_lines")
        if gw.get("fallback_event"):
            payload["fallback_event"] = gw["fallback_event"]
    return payload


# ------------------------------------------------------- Gate 04: plan pin
def _verify_plan_pin(request):
    """When WORKER_DSN is configured and the request names an attempt,
    the plan this service is about to execute (from the Gate 04 plan
    source file) must be exactly the plan the coordinator pinned on the
    attempt at claim time (plan_id + plan_hash). A mismatch is an
    explicit failure — the worker never silently executes a different
    plan version than the attempt was authorized under. Without a DSN
    or an attempt id (direct adapter tests), there is no pin to check."""
    dsn = os.environ.get("WORKER_DSN")
    attempt_id = request.get("attempt_id")
    if not dsn or not attempt_id:
        return None
    import psycopg
    with psycopg.connect(dsn, autocommit=True) as conn:
        row = conn.execute(
            "SELECT plan_id, plan_hash FROM action_attempts WHERE attempt_id=%s",
            (attempt_id,)).fetchone()
    if not row or row[0] is None:
        return {"pinned": False}
    plan = plans_mod.get_plan(request.get("operation_id"))
    if plan is None or plan["plan_id"] != row[0] or plan["plan_hash"] != row[1]:
        raise plan_exec_mod.PlanPinMismatch(
            f"attempt {attempt_id} pins plan {row[0]} ({row[1]}) but this "
            f"service resolves plan "
            f"{plan['plan_id'] if plan else None} "
            f"({plan['plan_hash'] if plan else None})")
    return {"pinned": True, "plan_id": row[0], "plan_hash": row[1]}


class _ApiActionSink:
    """Persists action-attempt records through the coordinator API
    (POST /units/{unit_id}/actions, WORKER role) as plan actions finish.
    A persistence failure aborts the execution: a success without its
    evidence records must not be claimable (Gate 04 evidence rule).
    Gate 05: the body carries worker_id (the /work request's worker_id,
    filled by the station executors with their claim identity) — the
    API binds it to the attempt's claim identity and refuses a
    mismatch with 403."""

    def __init__(self, request):
        self.api = os.environ["FACTORY_API_URL"].rstrip("/")
        self.token = os.environ["FACTORY_WORKER_TOKEN"]
        self.unit_id = request.get("unit_id")
        self.attempt_id = request.get("attempt_id")
        self.fencing_token = request.get("fencing_token")
        self.worker_id = request.get("worker_id")
        self.posted = 0

    def __call__(self, record):
        body = {"attempt_id": self.attempt_id,
                "fencing_token": self.fencing_token,
                "worker_id": self.worker_id,
                "action_key": record["action_key"], "seq": record["seq"],
                "status": record["status"],
                "inputs_hash": record.get("inputs_hash"),
                "output_summary": record.get("output_summary"),
                "cost_cents": record.get("cost_cents", 0),
                "error": record.get("error")}
        req = urllib.request.Request(
            f"{self.api}/units/{self.unit_id}/actions",
            data=json.dumps(body).encode(), method="POST")
        req.add_header("Content-Type", "application/json")
        req.add_header("X-Role", "WORKER")
        req.add_header("X-Role-Token", self.token)
        req.add_header("X-Identity", "worker-service")
        try:
            with urllib.request.urlopen(req, timeout=15) as r:
                r.read()
        except Exception as exc:  # noqa: BLE001 — any failure = no evidence
            raise adapters_mod.ProviderError(
                f"action record persistence failed for "
                f"{record['action_key']}: {exc}",
                error_class="ACTION_RECORD_FAILED") from None
        self.posted += 1


def _build_action_sink(request):
    if not (os.environ.get("FACTORY_API_URL")
            and os.environ.get("FACTORY_WORKER_TOKEN")):
        return None
    if not (request.get("unit_id") and request.get("attempt_id")
            and request.get("fencing_token") is not None):
        return None
    return _ApiActionSink(request)


def _api_cancel_check(request):
    """MM-04: the gateway's cancellation probe for a /work chain. When
    the Coordinator API is configured (the production wiring), the
    chain's provider job is looked up by the request's attempt: a
    CANCELLED job stops the chain before its next retry/fallback step.
    Without the API wiring there is no external cancel signal and the
    probe is absent. Probe failures read as 'not cancelled' inside the
    gateway — a telemetry outage must not fabricate a cancellation."""
    api = os.environ.get("FACTORY_API_URL")
    token = os.environ.get("FACTORY_WORKER_TOKEN")
    unit_id, attempt_id = request.get("unit_id"), request.get("attempt_id")
    if not (api and token and unit_id and attempt_id):
        return None

    def check():
        req = urllib.request.Request(
            f"{api.rstrip('/')}/units/{unit_id}/provider-jobs")
        req.add_header("X-Role", "WORKER")
        req.add_header("X-Role-Token", token)
        req.add_header("X-Identity", "worker-service")
        with urllib.request.urlopen(req, timeout=10) as r:
            out = json.loads(r.read() or b"{}")
        return any(j.get("attempt_id") == attempt_id
                   and j.get("status") == "CANCELLED"
                   for j in out.get("provider_jobs", []))

    return check


def _gateway_context(request):
    return gateway_mod.GatewayContext(
        dsn=os.environ.get("WORKER_DSN"),
        cancel_check=_api_cancel_check(request))


def submit_job(binding, request):
    adapter = _adapter_for(binding)
    credential = adapter.credential_for(binding)
    provider_job_id, gw = gateway_mod.submit_chain(
        adapter, binding, request, credential, _gateway_context(request))
    with _JOBS_LOCK:
        _JOBS[provider_job_id] = {"adapter": adapter.name, "binding": binding,
                                  "credential": credential, "request": request,
                                  "gateway": gw}
    return provider_job_id, gw


def poll_job(provider_job_id):
    with _JOBS_LOCK:
        ctx = _JOBS.get(provider_job_id)
    if ctx is None:
        return None
    adapter = REGISTRY[ctx["adapter"]]
    out = adapter.poll(ctx["binding"], provider_job_id, ctx["credential"])
    if out.get("status") == "COMPLETED":
        result = _result_payload(ctx["binding"], out, ctx.get("request"))
        gw = ctx.get("gateway") or {}
        if gw.get("correlation_id"):
            result["correlation_id"] = gw["correlation_id"]
        return result
    return out


def run_work(binding, request, force_async=False):
    adapter = _adapter_for(binding)
    request = _resolve_input_refs(request)
    # MM-04: every provider chain in this request runs under one
    # gateway context (registry DB access + the cancellation probe);
    # plan executions receive it through the request, the direct and
    # submit paths use it directly.
    gw = _gateway_context(request)
    request = {**request, "_gateway": gw}
    if request.get("force_fail") and adapter.name in envelope_mod.PAYLOAD_PROVIDERS:
        raise adapters_mod.ProviderError(
            "forced failure (test hook, Gate G — replaces the retired mock "
            "workers' force_fail flag)", error_class="FORCED_FAILURE")
    params = binding.get("params") or {}
    if force_async or params.get("mode") == "async":
        provider_job_id, job_gw = submit_job(binding, request)
        return 202, {"status": "SUBMITTED", "provider_job_id": provider_job_id,
                     "adapter": adapter.name,
                     "correlation_id": job_gw.get("correlation_id")}
    sink = None
    if adapter.name in envelope_mod.PAYLOAD_PROVIDERS:
        # Gate 04: payload-backed adapters execute the operation's
        # execution plan. Verify the attempt's plan pin first, then run
        # with an action-record sink when the API is configured.
        _verify_plan_pin(request)
        sink = _build_action_sink(request)
        if sink is not None:
            request = {**request, "_action_record_sink": sink}
    elif plan_exec_mod.plan_uses_provider_dispatch(
            plans_mod.get_plan(request.get("operation_id"))):
        # Lean Phase 3 (spec constraint C-1): the operation's plan
        # contains a provider-dispatch implementation (op 08.12). A
        # provider binding must NOT bypass plan execution — route
        # through the plan executor with the same pin verification and
        # action-record sink as the payload-backed path. The plan's
        # generation action dispatches on the pinned binding and calls
        # the provider adapter itself; BlockedError (credential
        # refusal) and ProviderError propagate to the handler as
        # 409 BLOCKED / 502 typed failure.
        _verify_plan_pin(request)
        sink = _build_action_sink(request)
        artifact_type, content, summary = plan_exec_mod.execute_operation(
            request, sink)
        if sink is not None:
            summary["records_posted"] = sink.posted
        result = {"artifact_type": artifact_type, "content": content,
                  "usage": summary.get("usage") or {},
                  "provider_request_id": summary.get("provider_request_id"),
                  "cost_cents": None, "plan_execution": summary,
                  # MM-05 (D-MM05-01): the plan summary already carries
                  # the gateway chain's executed model + correlation +
                  # usage lines + fallback event (plan_exec). Surface
                  # them as the result's gateway block so
                  # _result_payload emits the EXECUTED model on the
                  # /work response — without it, a fallback completion
                  # through n8n is priced at the pinned primary model.
                  "gateway": {"model": summary.get("model"),
                              "correlation_id": summary.get("correlation_id"),
                              "usage_lines": summary.get("usage_lines"),
                              "fallback_event": summary.get("fallback_event")}}
        return 200, _result_payload(binding, result, request,
                                    plan_executed=True)
    credential = adapter.credential_for(binding)
    # MM-04: direct provider executions run through the gateway
    # (context check, bounded retries, authorized fallback,
    # correlation, limiter, health). Payload-backed adapters and
    # provider-dispatch plans returned above and never reach here.
    result = gateway_mod.execute_chain(adapter, binding, request,
                                       credential, gw)
    if sink is not None and isinstance(result.get("plan_execution"), dict):
        result["plan_execution"]["records_posted"] = sink.posted
    return 200, _result_payload(binding, result, request)


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _send(self, code, obj):
        body = json.dumps(obj, default=str).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _body(self):
        n = int(self.headers.get("Content-Length") or 0)
        return json.loads(self.rfile.read(n) or b"{}")

    def do_GET(self):
        if self.path == "/health":
            return self._send(200, {"status": "ok", "environment": ENVIRONMENT,
                                    "adapters": adapter_health()})
        if self.path.startswith("/jobs/"):
            provider_job_id = self.path[len("/jobs/"):]
            try:
                out = poll_job(provider_job_id)
            except adapters_mod.BlockedError as e:
                return self._send(409, {"error": str(e), "error_class": "BLOCKED"})
            except adapters_mod.ProviderError as e:
                return self._send(502, {"error": str(e), "error_class": e.error_class})
            if out is None:
                return self._send(404, {"error": "unknown provider job for this service"})
            return self._send(200, out)
        return self._send(404, {"error": "no route"})

    def do_POST(self):
        if self.path not in ("/work", "/jobs"):
            return self._send(404, {"error": "no route"})
        try:
            req = self._body()
        except json.JSONDecodeError:
            return self._send(400, {"error": "invalid JSON"})
        binding = req.get("provider_binding")
        if not binding or not binding.get("provider"):
            return self._send(400, {"error": "provider_binding with a provider is required"})
        if not req.get("operation_id") or not req.get("unit_id"):
            return self._send(400, {"error": "operation_id and unit_id are required"})
        try:
            code, out = run_work(binding, req, force_async=(self.path == "/jobs"))
        except adapters_mod.BlockedError as e:
            return self._send(409, {"error": str(e), "error_class": "BLOCKED"})
        except adapters_mod.ProviderError as e:
            body = {"error": str(e), "error_class": e.error_class}
            gw = getattr(e, "gateway", None)
            if gw:  # MM-04: the failed chain's evidence rides the error
                body["correlation_id"] = gw.get("correlation_id")
                body["usage_lines"] = gw.get("usage_lines")
                if gw.get("fallback_event"):
                    body["fallback_event"] = gw["fallback_event"]
            return self._send(502, body)
        return self._send(code, out)


def main():
    port = int(os.environ.get("WORKER_SERVICE_PORT", "8799"))
    server = ThreadingHTTPServer(("127.0.0.1", port), Handler)
    print(f"worker service on http://127.0.0.1:{port} (environment={ENVIRONMENT})")
    server.serve_forever()


if __name__ == "__main__":
    main()
