"""Deterministic payload builders for the 19 operations that have
operation-specific behavior in the accepted factory (G4-G8 mock workers).

Copied minimally from the station workers' build() functions and adapted
to the Gate C worker contract: cross-artifact references arrive as
input_artifact_refs (a list of {artifact_type, artifact_id, sha256,
content?}) instead of being looked up through the API / content store.

build(operation_id, production_id, unit_id, input_refs) ->
    (artifact_type, content_str)
Operations without a specific builder raise UnboundOperationError
(Gate 04: no generic fallthrough — see plan_exec.py).
"""
import hashlib
import json


class UnboundOperationError(Exception):
    """No operation-specific builder exists for this operation.

    Gate 04 (G01-D01): the pre-Gate-04 fallthrough returned a generic
    step_output success for every unlisted operation. That is removed:
    execution goes through the Gate 04 plan executor (plan_exec.py),
    and a direct build() call for an unlisted operation is an explicit
    refusal, never a semantically empty success."""


# ---- G4 (stations 1-2): plain-text outputs -------------------------------
G4_OUTPUTS = {
    "01.01": ("premise_record", "PREMISE captured: a lighthouse keeper who trades memories for light."),
    "01.12": ("production_charter",
              "PRODUCTION CHARTER v1 — premise locked; audience, language, acceptance benchmarks committed."),
    "02.12": ("rights_register",
              "RIGHTS & SAFEGUARDING REGISTER v1 — contributors mapped; decisions per asset recorded."),
    "03.02": ("source_registration",
              "SOURCE REGISTRATION — primary/secondary sources registered with provenance + hashes."),
    "03.12": ("canon_manifest",
              "CANON MANIFEST v1 — universe, chronology, world rules, knowledge boundaries released."),
    "04.12": ("people_manifest",
              "PEOPLE MANIFEST v1 — person IDs, biographies, relationships, agency, knowledge states."),
}

# ---- G5 (station 3) -------------------------------------------------------
STORY_NODES = ["S1", "S2"]
BEATS = {"B1": "S1", "B2": "S2"}
SCENES = {"SC1": "B1", "SC2": "B2"}

# ---- G6 (station 4) -------------------------------------------------------
LINES = ["L1", "L2", "L3"]
SHOTS = {"SH1": "L1", "SH2": "L2", "SH3": "L3"}
RULE_OF_SIX = [("Emotion", 51, 8.6), ("Story", 23, 8.2), ("Rhythm", 10, 7.4),
               ("Eye Trace", 7, 7.9), ("2D Plane", 5, 7.1), ("3D Space", 4, 6.8)]

# ---- G7 (station 5) -------------------------------------------------------
DERIVATIVES = [
    {"id": "D-vertical", "format": "9:16", "platform": "shorts"},
    {"id": "D-square", "format": "1:1", "platform": "feed"},
    {"id": "D-thumb", "format": "16:9", "platform": "thumbnail"}]
PREDICTIONS = {d["id"]: {"view_range": [8000, 20000], "ctr_band": "3-5%",
                         "confidence": "LOW — mock prediction record"}
               for d in DERIVATIVES}


def _ref(refs, artifact_type):
    return refs.get(artifact_type) or {}


def _ref_id(refs, artifact_type):
    return _ref(refs, artifact_type).get("artifact_id")


def _ref_sha(refs, artifact_type):
    return _ref(refs, artifact_type).get("sha256")


def _ref_content(refs, artifact_type):
    return _ref(refs, artifact_type).get("content") or {}


def _json(obj):
    return json.dumps(obj, sort_keys=True)


def build(operation_id, production_id, unit_id, input_refs=()):
    refs = {r.get("artifact_type"): r for r in (input_refs or ())}
    if operation_id in G4_OUTPUTS:
        artifact_type, base = G4_OUTPUTS[operation_id]
        return artifact_type, f"{base} [production={production_id} op={operation_id} unit={unit_id}]"

    canon = _ref_id(refs, "canon_manifest")
    if operation_id == "05.12":
        return "story_architecture", _json({
            "kind": "story_architecture",
            "story_nodes": [{"id": s, "summary": f"Story node {s}"} for s in STORY_NODES],
            "canon_refs": [canon]})
    if operation_id == "06.12":
        return "beat_graph", _json({
            "kind": "beat_graph",
            "beats": [{"id": b, "story_ref": s} for b, s in BEATS.items()],
            "canon_refs": [canon]})
    if operation_id == "07.12":
        return "scene_set", _json({
            "kind": "scene_set",
            "scenes": [{"id": sc, "beat_ref": b, "canon_refs": [canon]}
                       for sc, b in SCENES.items()],
            "canon_refs": [canon]})
    if operation_id == "08.12":
        lines = [
            {"id": "L1", "scene_ref": "SC1", "beat_ref": "B1",
             "story_ref": "S1", "canon_refs": [canon],
             "text": "Mara finds the brass key behind the clock."},
            {"id": "L2", "scene_ref": "SC2", "beat_ref": "B2",
             "story_ref": "S2", "canon_refs": [canon],
             "text": "Tobin admits the archive door was locked from inside."},
            {"id": "L3", "scene_ref": "SC1", "beat_ref": "B1",
             "story_ref": "S1", "canon_refs": [canon],
             "text": "The brass key opens the archive; the ledger is gone."},
        ]
        return "script", _json({
            "kind": "script", "lines": lines,
            "trace": {
                "clues": [{"id": "CL1", "planted": "L1", "payoff": "L3"}],
                "knowledge": [{"character": "Mara", "learns": "CL1", "at": "L2"}],
                "payoffs": [{"id": "PO1", "clue": "CL1", "line": "L3"}]},
            "canon_refs": [canon]})

    script_id = _ref_id(refs, "script")
    if operation_id == "09.12":
        return "direction_package", _json({
            "kind": "direction_package", "script_ref": script_id,
            "directions": [{"line_ref": ln, "direction": f"Direction for {ln}"}
                           for ln in LINES]})
    if operation_id == "10.12":
        return "shot_manifest", _json({
            "kind": "shot_manifest", "script_ref": script_id,
            "shots": [{"id": sh, "line_ref": ln, "framing": "MS"}
                      for sh, ln in SHOTS.items()],
            "sound_design": {
                "voice_plan": [{"line_ref": ln, "voice": "lead",
                                "delivery": "measured"} for ln in LINES],
                "music": "single piano motif"}})
    if operation_id == "11.12":
        assets = []
        for sh in SHOTS:
            payload = f"g6-asset-payload-{sh}"
            assets.append({"id": f"A-{sh}", "shot_ref": sh, "payload": payload,
                           "sha256": hashlib.sha256(payload.encode()).hexdigest()})
        return "asset_registry", _json({"kind": "asset_registry", "assets": assets})
    if operation_id == "12.12":
        dims = [{"name": n, "weight": w, "score": s} for n, w, s in RULE_OF_SIX]
        total = round(sum(w * s for _, w, s in RULE_OF_SIX) / 100.0, 3)
        return "edit_timeline", _json({
            "kind": "edit_timeline",
            "segments": [{"shot_ref": sh, "order": i + 1}
                         for i, sh in enumerate(SHOTS)],
            "rule_of_six": {"dimensions": dims, "weighted_total": total}})

    if operation_id == "13.12":
        registry_doc = _ref_content(refs, "asset_registry")
        asset_hashes = [a["sha256"] for a in registry_doc.get("assets", [])]
        return "master_package", _json({
            "kind": "master_package",
            "timeline_ref": _ref_id(refs, "edit_timeline"),
            "timeline_sha256": _ref_sha(refs, "edit_timeline"),
            "registry_ref": _ref_id(refs, "asset_registry"),
            "registry_sha256": _ref_sha(refs, "asset_registry"),
            "asset_hashes": asset_hashes})
    if operation_id == "14.01":
        return "derivative_portfolio", _json({
            "kind": "derivative_portfolio",
            "master_ref": _ref_id(refs, "master_package"),
            "derivatives": DERIVATIVES,
            "predictions": PREDICTIONS,
            "predictions_locked": True})
    if operation_id == "14.12":
        master_id = _ref_id(refs, "master_package")
        derivs = []
        for d in DERIVATIVES:
            payload = f"g7-derivative-payload-{d['id']}"
            derivs.append({**d, "payload": payload,
                           "sha256": hashlib.sha256(payload.encode()).hexdigest()})
        return "derivative_package", _json({
            "kind": "derivative_package",
            "master_ref": master_id,
            "derivatives": derivs,
            "upload_manifest": {
                "files": [d["id"] for d in DERIVATIVES],
                "master_ref": master_id,
                "metadata": {"title": "Mock upload package",
                             "visibility": "unlisted"}}})

    if operation_id == "15.12":
        package = _ref(refs, "derivative_package")
        doc = package.get("content") or {}
        # MM-06 simulation labeling standard: these publication
        # receipts are SIMULATED (no platform is contacted; the post
        # ids are fabricated by this deterministic builder). The
        # marking is machine-visible in the stored record itself —
        # simulated flag, a provider name carrying the mock
        # designation, and a SIMULATED status on every receipt — so
        # a simulated record is distinguishable from a real one by
        # its stored fields alone.
        records = [{"derivative_id": d["id"], "sha256": d["sha256"],
                    "platform": d["platform"],
                    "platform_post_id": f"mock-{d['id']}-001",
                    "status": "SIMULATED"}
                   for d in doc.get("derivatives", [])]
        return "distribution_record", _json({
            "kind": "distribution_record",
            "simulated": True,
            "provider": "mock-platform-publisher",
            "package_ref": package.get("artifact_id"),
            "publications": records})
    if operation_id == "16.12":
        portfolio = _ref(refs, "derivative_portfolio")
        pdoc = portfolio.get("content") or {}
        comparison = {}
        for deriv_id, pred in sorted(pdoc.get("predictions", {}).items()):
            lo, hi = pred["view_range"]
            actual_views = (lo + hi) // 2 + 500
            comparison[deriv_id] = {
                "predicted_range": [lo, hi],
                "actual_views": actual_views,
                "within_range": lo <= actual_views <= hi,
                "delta_vs_midpoint": actual_views - (lo + hi) // 2}
        return "learning_record", _json({
            "kind": "learning_record",
            "portfolio_ref": portfolio.get("artifact_id"),
            "distribution_ref": _ref_id(refs, "distribution_record"),
            "comparison": comparison,
            "confidence_limitations":
                "Mock actuals; comparison structure verified, accuracy not claimed."})

    raise UnboundOperationError(
        f"no operation-specific builder for operation {operation_id}; "
        "execution must resolve through its Gate 04 execution plan")


SPECIFIC_OPS = sorted(set(G4_OUTPUTS) | {
    "05.12", "06.12", "07.12", "08.12", "09.12", "10.12", "11.12", "12.12",
    "13.12", "14.01", "14.12", "15.12", "16.12"})
