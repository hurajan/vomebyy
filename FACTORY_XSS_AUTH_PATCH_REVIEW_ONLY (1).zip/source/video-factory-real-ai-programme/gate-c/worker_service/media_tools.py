"""MM-06 — local media tooling for the worker service.

Deterministic LOCAL tools over real media bytes, built on the
environment's ffmpeg/ffprobe (probed at MM-06 Step 0: ffmpeg 8.1.2,
libx264 + aac encoders, libflite compiled in). Nothing here talks to a
network or a provider: inputs are media bytes fetched from the Gate D
content-addressed artifact store by SHA-256, outputs are written back
to the same store and validated with the ffprobe validator below
before the action that produced them may report success.

The validator's failure reasons are NAMED constants — callers (and
MM-07 evaluation policies) can match on them mechanically.
"""
import contextlib
import json
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

GATE_D = Path.home() / "workspace/video-factory-real-ai-programme/gate-d"
if str(GATE_D) not in sys.path:
    sys.path.insert(0, str(GATE_D))

FFMPEG = "ffmpeg"
FFPROBE = "ffprobe"

# The factory master spec (MM-06): processed/rendered masters are
# H.264 (yuv420p) + AAC at 48 kHz in MP4 unless an operation's plan
# spec says otherwise.
MASTER = {"video_codec": "h264", "audio_codec": "aac",
          "sample_rate": 48000, "pix_fmt": "yuv420p", "container": "mp4"}

# Named validation failure reasons.
FILE_MISSING = "FILE_MISSING"
MEDIA_TRUNCATED_OR_CORRUPT = "MEDIA_TRUNCATED_OR_CORRUPT"
VIDEO_STREAM_MISSING = "VIDEO_STREAM_MISSING"
AUDIO_STREAM_MISSING = "AUDIO_STREAM_MISSING"
VIDEO_CODEC_MISMATCH = "VIDEO_CODEC_MISMATCH"
AUDIO_CODEC_MISMATCH = "AUDIO_CODEC_MISMATCH"
WIDTH_MISMATCH = "WIDTH_MISMATCH"
HEIGHT_MISMATCH = "HEIGHT_MISMATCH"
DURATION_MISSING = "DURATION_MISSING"
DURATION_TOO_SHORT = "DURATION_TOO_SHORT"
DURATION_TOO_LONG = "DURATION_TOO_LONG"
SAMPLE_RATE_MISMATCH = "SAMPLE_RATE_MISMATCH"


class MediaToolError(Exception):
    """A local media tool invocation failed (typed, with stderr tail)."""


@contextlib.contextmanager
def workdir(prefix):
    """A self-cleaning scratch directory for one media action run.

    Created fresh with mkdtemp and removed in a finally block — on
    success, on typed failure (ActionFailed / MediaToolError), and on
    unexpected exceptions alike — so media executions never leak
    scratch copies of media bytes into the temp root (MM-06 defect
    D-1: leaked workdirs filled a 512 MB tmpfs and broke unrelated
    suites with ENOSPC). Only the directory created here is removed;
    caller-owned paths are never touched."""
    path = Path(tempfile.mkdtemp(prefix=prefix))
    try:
        yield path
    finally:
        shutil.rmtree(path, ignore_errors=True)


def _run(args, timeout=280):
    try:
        proc = subprocess.run(args, capture_output=True, text=True,
                              timeout=timeout, stdin=subprocess.DEVNULL)
    except subprocess.TimeoutExpired:
        raise MediaToolError(
            f"tool timed out after {timeout}s: {args[0]}") from None
    if proc.returncode != 0:
        tail = (proc.stderr or "").strip().splitlines()[-3:]
        raise MediaToolError(
            f"{args[0]} exited {proc.returncode}: {' | '.join(tail)}")
    return proc


def _storage():
    from storage_service import factory_from_env
    return factory_from_env()


def fetch_media_bytes(sha256):
    """Raw bytes for a store object by sha, or None when absent."""
    if not sha256:
        return None
    from storage_service import final_uri
    try:
        return _storage().get(final_uri(sha256))
    except Exception:  # noqa: BLE001 — absent bytes = unavailable input
        return None


def store_media_bytes(data, content_type=None):
    """Stage + promote media bytes; returns {sha256, storage_uri, size}."""
    from storage_service import final_uri, sha256_hex
    store = _storage()
    staged = store.put_candidate(data, content_type)
    uri = store.promote(staged["uri"])
    return {"sha256": sha256_hex(data), "storage_uri": uri,
            "size": len(data)}


def probe_bytes(data):
    """Probe in-memory media bytes (written to a temp file for ffprobe).
    Returns the probe dict, or None when the bytes are not probe-able
    media at all."""
    with tempfile.NamedTemporaryFile(suffix=".bin", delete=False) as fh:
        fh.write(data)
        path = fh.name
    try:
        return probe_media(path)
    except MediaToolError:
        return None
    finally:
        Path(path).unlink(missing_ok=True)


def probe_media(path):
    """ffprobe a file into a compact, JSON-safe probe dict:
    {format_name, duration_s, size_bytes, streams: [{index, type,
    codec, width?, height?, sample_rate?, channels?, duration_s,
    start_time_s}]}. Raises MediaToolError when ffprobe cannot parse
    the file (missing/corrupt/truncated)."""
    path = str(path)
    if not Path(path).exists():
        raise MediaToolError(f"probe target does not exist: {path}")
    proc = subprocess.run(
        [FFPROBE, "-v", "error", "-show_streams", "-show_format",
         "-of", "json", path],
        capture_output=True, text=True, stdin=subprocess.DEVNULL)
    if proc.returncode != 0:
        raise MediaToolError(
            f"ffprobe cannot parse {path}: "
            f"{(proc.stderr or '').strip().splitlines()[-1:]}")
    try:
        raw = json.loads(proc.stdout or "{}")
    except json.JSONDecodeError:
        raise MediaToolError(f"ffprobe returned non-JSON for {path}") from None
    streams = []
    for s in raw.get("streams") or []:
        entry = {"index": s.get("index"), "type": s.get("codec_type"),
                 "codec": s.get("codec_name"),
                 "start_time_s": _f(s.get("start_time")),
                 "duration_s": _f(s.get("duration"))}
        if s.get("codec_type") == "video":
            entry["width"] = s.get("width")
            entry["height"] = s.get("height")
            entry["pix_fmt"] = s.get("pix_fmt")
        if s.get("codec_type") == "audio":
            entry["sample_rate"] = _i(s.get("sample_rate"))
            entry["channels"] = s.get("channels")
        streams.append(entry)
    fmt = raw.get("format") or {}
    return {"format_name": fmt.get("format_name"),
            "duration_s": _f(fmt.get("duration")),
            "size_bytes": _i(fmt.get("size")),
            "streams": streams}


def _f(value):
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _i(value):
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def first_stream(probe, kind):
    for s in probe.get("streams") or []:
        if s.get("type") == kind:
            return s
    return None


def validate_media(path, expectations=None):
    """Validate a media file against expectations; returns
    {ok, failures: [NAMED reasons], probe}. Expectation keys (all
    optional): video_codec, audio_codec, width, height, sample_rate,
    require_video (default True), require_audio (default False),
    min_duration_s, max_duration_s, duration_tolerance_s (default
    0.25, applied to min/max comparisons)."""
    exp = expectations or {}
    tol = exp.get("duration_tolerance_s", 0.25)
    failures = []
    if not Path(str(path)).exists():
        return {"ok": False, "failures": [FILE_MISSING], "probe": None}
    try:
        probe = probe_media(path)
    except MediaToolError:
        return {"ok": False, "failures": [MEDIA_TRUNCATED_OR_CORRUPT],
                "probe": None}
    if not probe["streams"]:
        return {"ok": False, "failures": [MEDIA_TRUNCATED_OR_CORRUPT],
                "probe": probe}
    video = first_stream(probe, "video")
    audio = first_stream(probe, "audio")
    if exp.get("require_video", True) and video is None:
        failures.append(VIDEO_STREAM_MISSING)
    if exp.get("require_audio", False) and audio is None:
        failures.append(AUDIO_STREAM_MISSING)
    if video is not None and exp.get("video_codec") \
            and video["codec"] != exp["video_codec"]:
        failures.append(VIDEO_CODEC_MISMATCH)
    if audio is not None and exp.get("audio_codec") \
            and audio["codec"] != exp["audio_codec"]:
        failures.append(AUDIO_CODEC_MISMATCH)
    if video is not None and exp.get("width") \
            and video.get("width") != exp["width"]:
        failures.append(WIDTH_MISMATCH)
    if video is not None and exp.get("height") \
            and video.get("height") != exp["height"]:
        failures.append(HEIGHT_MISMATCH)
    if audio is not None and exp.get("sample_rate") \
            and audio.get("sample_rate") != exp["sample_rate"]:
        failures.append(SAMPLE_RATE_MISMATCH)
    duration = probe.get("duration_s")
    if duration is None and (exp.get("min_duration_s") is not None
                             or exp.get("max_duration_s") is not None):
        failures.append(DURATION_MISSING)
    if duration is not None:
        if exp.get("min_duration_s") is not None \
                and duration < exp["min_duration_s"] - tol:
            failures.append(DURATION_TOO_SHORT)
        if exp.get("max_duration_s") is not None \
                and duration > exp["max_duration_s"] + tol:
            failures.append(DURATION_TOO_LONG)
    return {"ok": not failures, "failures": failures, "probe": probe}


def ffmpeg(args, timeout=280):
    """Run ffmpeg with the factory's non-interactive discipline."""
    return _run([FFMPEG, "-nostdin", "-v", "error", *args], timeout=timeout)


def master_encode_args(width=None, height=None, crf=20):
    """Encode args for the master spec, optionally scaling/padding to
    an exact frame (aspect preserved, black pad)."""
    args = []
    if width and height:
        args += ["-vf",
                 f"scale={width}:{height}:force_original_aspect_ratio=decrease,"
                 f"pad={width}:{height}:(ow-iw)/2:(oh-ih)/2,setsar=1"]
    args += ["-c:v", "libx264", "-pix_fmt", MASTER["pix_fmt"], "-crf", str(crf),
             "-c:a", "aac", "-ar", str(MASTER["sample_rate"]), "-b:a", "160k"]
    return args


def measure_loudnorm(path):
    """Integrated loudness measurement (EBU R128) of the first audio
    stream: returns the loudnorm analysis dict {input_i, input_tp,
    input_lra, input_thresh, ...} as floats where parseable."""
    proc = subprocess.run(
        [FFMPEG, "-nostdin", "-i", str(path), "-vn",
         "-af", "loudnorm=print_format=json", "-f", "null", "-"],
        capture_output=True, text=True, stdin=subprocess.DEVNULL)
    match = re.search(r"\{\s*\"input_i\".*?\}", proc.stderr or "", re.S)
    if not match:
        raise MediaToolError(f"loudnorm measurement failed for {path}")
    raw = json.loads(match.group(0))
    return {k: _f(v) if k != "normalization_type" else v
            for k, v in raw.items()}


def measure_signalstats(path, sample_frames=30):
    """Mean luma/chroma statistics over the first `sample_frames`
    frames (signalstats): {frames, yavg_mean, ylow_min, yhigh_max,
    uavg_mean, vavg_mean}. Deterministic measurement, no judgment."""
    proc = subprocess.run(
        [FFMPEG, "-nostdin", "-i", str(path),
         "-vf", "signalstats,metadata=print", "-frames:v",
         str(sample_frames), "-f", "null", "-"],
        capture_output=True, text=True, stdin=subprocess.DEVNULL)
    keys = ("YAVG", "YLOW", "YHIGH", "UAVG", "VAVG")
    values = {k: [] for k in keys}
    for line in (proc.stderr or "").splitlines():
        m = re.search(r"lavfi\.signalstats\.(YAVG|YLOW|YHIGH|UAVG|VAVG)"
                      r"=([0-9.]+)", line)
        if m:
            values[m.group(1)].append(float(m.group(2)))
    if not values["YAVG"]:
        raise MediaToolError(f"signalstats produced no frames for {path}")

    def mean(xs):
        return round(sum(xs) / len(xs), 3) if xs else None
    return {"frames": len(values["YAVG"]),
            "yavg_mean": mean(values["YAVG"]),
            "ylow_min": min(values["YLOW"]) if values["YLOW"] else None,
            "yhigh_max": max(values["YHIGH"]) if values["YHIGH"] else None,
            "uavg_mean": mean(values["UAVG"]),
            "vavg_mean": mean(values["VAVG"])}


def synthesize_speech_wav(text, out_path, voice="slt"):
    """Genuine local text-to-speech via the ffmpeg `flite` source
    (libflite, compiled into this environment's ffmpeg — MM-06 probe).
    Writes a real WAV of the synthesized speech and returns its probe.
    This is a LOCAL TOOL path: robotic flite voices, honestly labeled;
    it is not a provider voice and claims no quality."""
    if not text or not str(text).strip():
        raise MediaToolError("synthesize_speech: empty text")
    safe = str(text).replace("'", "’")  # flite filter arg quoting
    ffmpeg(["-f", "lavfi", "-i", f"flite=text='{safe}':voice={voice}",
            "-ar", "48000", "-ac", "1", str(out_path), "-y"], timeout=120)
    probe = probe_media(out_path)
    if not probe.get("duration_s"):
        raise MediaToolError("synthesize_speech: produced no audio duration")
    return probe
