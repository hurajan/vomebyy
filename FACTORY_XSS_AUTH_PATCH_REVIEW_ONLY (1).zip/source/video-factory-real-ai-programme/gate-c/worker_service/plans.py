"""Gate 04 — execution-plan loading for the worker service.

Plans are DATA: the Gate 04 plan source file lives beside the registry
seed (video-factory-g1/seed-definitions/workflow-1.0.0/plans.json) and
is loaded into the runtime DB by the registry loader (operation_
execution_plans). The coordinator pins plan_id + plan_version +
plan_hash on every attempt at claim time; this module loads the same
source file so the worker executes exactly the pinned plan (the service
verifies the pin against the attempt row when WORKER_DSN is set).

plan_hash canonicalization (shared with the generator and the loader):
sha256 of the canonical JSON (sorted keys, compact separators) of the
plan object WITHOUT its plan_hash field.
"""
import hashlib
import json
import os
from pathlib import Path

DEFAULT_PLANS_FILE = (Path.home() / "workspace/video-factory-g1"
                      / "seed-definitions" / "workflow-1.0.0" / "plans.json")

_cache = {"path": None, "doc": None}


def plan_hash(plan):
    body = {k: v for k, v in plan.items() if k != "plan_hash"}
    canonical = json.dumps(body, ensure_ascii=False, sort_keys=True,
                           separators=(",", ":"))
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


def plans_file_path():
    return Path(os.environ.get("WORKER_PLANS_FILE", str(DEFAULT_PLANS_FILE)))


def load_plans():
    path = plans_file_path()
    stat = path.stat()
    key = (str(path), stat.st_mtime_ns, stat.st_size)
    if _cache["path"] != key:
        doc = json.loads(path.read_text(encoding="utf-8"))
        _cache["path"] = key
        _cache["doc"] = doc
    return _cache["doc"]


def get_plan(operation_id):
    """The plan dict for an operation, or None when none resolves."""
    doc = load_plans()
    for plan in doc.get("plans", []):
        if plan.get("operation_id") == operation_id:
            return plan
    return None


def verify_file_hashes():
    """Recompute every plan hash from the loaded file; returns a list of
    operation_ids whose stored plan_hash does not recompute ([] = sound)."""
    doc = load_plans()
    return [p["operation_id"] for p in doc.get("plans", [])
            if p.get("plan_hash") != plan_hash(p)]
