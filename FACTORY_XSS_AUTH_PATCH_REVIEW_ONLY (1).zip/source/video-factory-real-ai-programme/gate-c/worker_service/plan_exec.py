"""Gate 04 — plan executor: replaces the generic success fallthrough.

execute_operation(request, sink) resolves the operation's Gate 04
execution plan and runs its atomic actions IN ORDER through
actions.ACTION_IMPLEMENTATIONS. Every finished action is reported to
the sink (the service's sink persists an action-attempt record through
the coordinator API; the default sink keeps them in memory for tests).

Failure discipline (G01-D01 fix): there is no generic success. An
operation with no plan, a plan whose action is UNBOUND, an action whose
implementation is missing, or an action that cannot produce its typed
output from the given inputs fails EXPLICITLY — UnboundOperation /
ProviderError with a machine-readable error_class — after recording the
actions that did run. The coordinator's failure path (transient_error ->
RETRY_WAIT -> dead-letter) carries the evidence; nothing is fabricated.
"""
import hashlib
import json

import actions as actions_mod
import plans as plans_mod
from adapters import BlockedError, ProviderError


# Lean Phase 3: implementations that dispatch on the attempt's pinned
# provider binding and may therefore execute a REAL provider call from
# inside plan execution. The worker service routes such plans through
# execute_operation even when the resolved adapter is not one of the
# payload-backed local adapters — otherwise a provider binding would
# bypass plan execution, the envelope, the action records and the
# plan pin entirely (spec constraint C-1).
PROVIDER_DISPATCH_IMPLEMENTATIONS = {"op.generate_script"}


def plan_uses_provider_dispatch(plan):
    if not plan:
        return False
    return any(a.get("implementation") in PROVIDER_DISPATCH_IMPLEMENTATIONS
               for a in plan.get("actions", []))


class UnboundOperation(ProviderError):
    """No honest execution path exists for this operation/action."""

    def __init__(self, message):
        super().__init__(message, error_class="UNBOUND_OPERATION")


class PlanPinMismatch(ProviderError):
    def __init__(self, message):
        super().__init__(message, error_class="PLAN_PIN_MISMATCH")


def _canon(value):
    return json.dumps(value, sort_keys=True, default=str)


def _inputs_hash(ctx):
    material = {
        "refs": [{"artifact_type": r.get("artifact_type"),
                  "artifact_id": r.get("artifact_id"),
                  "sha256": r.get("sha256")} for r in ctx.refs],
        "prior": {k: hashlib.sha256(_canon(v).encode()).hexdigest()
                  for k, v in sorted(ctx.prior.items())},
    }
    return hashlib.sha256(_canon(material).encode()).hexdigest()


def _output_summary(output):
    if output is None:
        return None
    return {"sha256": hashlib.sha256(_canon(output).encode()).hexdigest(),
            "kind": type(output).__name__,
            "keys": sorted(output.keys()) if isinstance(output, dict) else None}


class _LocalSink:
    def __init__(self):
        self.records = []

    def __call__(self, record):
        self.records.append(record)


def execute_operation(request, sink=None):
    """Run the plan for request['operation_id'].

    Returns (artifact_type, content_str, summary) where summary carries
    the plan identity and the per-action outcomes. Raises
    UnboundOperation / ProviderError on any explicit failure."""
    operation_id = request.get("operation_id")
    plan = plans_mod.get_plan(operation_id)
    if plan is None:
        raise UnboundOperation(
            f"no execution plan resolves for operation {operation_id}")
    if plan.get("plan_hash") != plans_mod.plan_hash(plan):
        raise PlanPinMismatch(
            f"plan file hash does not recompute for operation {operation_id}")
    sink = sink or _LocalSink()
    ctx = actions_mod.ActionContext(
        operation_id, request.get("production_id"), request.get("unit_id"),
        request.get("attempt_id"), request.get("input_artifact_refs") or [],
        plan, binding=request.get("provider_binding"),
        gateway=request.get("_gateway"))
    outcomes = []
    for action in plan.get("actions", []):
        record = {"plan_id": plan["plan_id"], "plan_hash": plan["plan_hash"],
                  "action_key": action["action_key"], "seq": action["seq"],
                  "inputs_hash": _inputs_hash(ctx), "cost_cents": 0}
        if action.get("binding_status") == "UNBOUND":
            record.update(status="REFUSED",
                          error=action.get("unbound_reason")
                          or "action is UNBOUND in the plan")
            sink(record)
            outcomes.append({"action_key": action["action_key"],
                             "status": "REFUSED"})
            raise UnboundOperation(
                f"operation {operation_id}: action {action['action_key']} is "
                f"UNBOUND ({record['error']})")
        impl = actions_mod.ACTION_IMPLEMENTATIONS.get(action.get("implementation"))
        if impl is None:
            record.update(status="REFUSED",
                          error=f"implementation {action.get('implementation')!r} "
                                "is not registered")
            sink(record)
            outcomes.append({"action_key": action["action_key"],
                             "status": "REFUSED"})
            raise UnboundOperation(
                f"operation {operation_id}: action {action['action_key']} "
                f"implementation {action.get('implementation')!r} not registered")
        evidence_before = getattr(ctx, "provider_evidence", None)
        try:
            output = impl(ctx, action.get("spec") or {})
        except actions_mod.ActionRefused as exc:
            # Lean Phase 3: a refusal (e.g. credential absent under a
            # provider binding) is recorded REFUSED and surfaces as
            # BLOCKED — never as a fallback to another implementation.
            record.update(status="REFUSED", error=str(exc))
            sink(record)
            outcomes.append({"action_key": action["action_key"],
                             "status": "REFUSED"})
            raise BlockedError(
                f"operation {operation_id}: action {action['action_key']} "
                f"refused: {exc}") from None
        except ProviderError as exc:
            # A provider-backed action's typed provider failure (HTTP
            # status, unreachable, bad response) is recorded FAILED and
            # re-raised with its error_class intact. MM-04: when the
            # gateway ran, the FAILED record also carries the chain's
            # evidence summary (correlation id + per-call usage lines)
            # — a failed chain's usage is still usage evidence.
            record.update(status="FAILED", error=str(exc))
            evidence = getattr(ctx, "provider_evidence", None)
            if evidence is not None and evidence is not evidence_before:
                record["output_summary"] = {
                    "provider": evidence.get("provider"),
                    "model": evidence.get("model"),
                    "error_class": exc.error_class,
                    "correlation_id": evidence.get("correlation_id"),
                    "usage_lines": evidence.get("usage_lines"),
                    "fallback_event": evidence.get("fallback_event")}
            sink(record)
            outcomes.append({"action_key": action["action_key"],
                             "status": "FAILED"})
            raise
        except actions_mod.ActionFailed as exc:
            record.update(status="FAILED", error=str(exc))
            sink(record)
            outcomes.append({"action_key": action["action_key"],
                             "status": "FAILED"})
            raise ProviderError(
                f"operation {operation_id}: action {action['action_key']} "
                f"failed: {exc}", error_class="ACTION_FAILED") from None
        ctx.prior[action["action_key"]] = output
        output_summary = _output_summary(output)
        evidence = getattr(ctx, "provider_evidence", None)
        if evidence is not None and evidence is evidence_before:
            evidence = None  # set by an earlier action, not this one
        if evidence:
            # Lean Phase 3 (spec C-3): the generation action's record
            # carries the provider's token usage + request id, so the
            # coordinator's CALCULATED evidence can be priced from the
            # seeded pricing rules — the binding estimate never poses
            # as a measured cost. MM-04: the gateway chain's correlation
            # id, per-call usage lines and any fallback event ride the
            # same evidence channel; the model is the EXECUTED model.
            output_summary = {**(output_summary or {}),
                              "provider": evidence.get("provider"),
                              "model": evidence.get("model"),
                              "usage": evidence.get("usage"),
                              "provider_request_id":
                                  evidence.get("provider_request_id")}
            for key in ("correlation_id", "usage_lines", "fallback_event"):
                if evidence.get(key) is not None:
                    output_summary[key] = evidence[key]
        record.update(status="SUCCEEDED", output_summary=output_summary)
        sink(record)
        outcomes.append({"action_key": action["action_key"],
                         "status": "SUCCEEDED"})
    if ctx.result is None:
        raise ProviderError(
            f"operation {operation_id}: plan produced no output artifact",
            error_class="ACTION_FAILED")
    artifact_type, content = ctx.result
    summary = {"plan_id": plan["plan_id"], "plan_version": plan["plan_version"],
               "plan_hash": plan["plan_hash"],
               "binding_status": plan.get("binding_status"),
               "actions": outcomes,
               "records": getattr(sink, "records", None)}
    evidence = getattr(ctx, "provider_evidence", None)
    if evidence:
        summary["usage"] = evidence.get("usage") or {}
        summary["provider_request_id"] = evidence.get("provider_request_id")
        summary["provider"] = evidence.get("provider")
        summary["model"] = evidence.get("model")
        for key in ("correlation_id", "usage_lines", "fallback_event"):
            if evidence.get(key) is not None:
                summary[key] = evidence[key]
    return artifact_type, content, summary
