"""MM-04 — the provider gateway (Multi-Model programme, Gate MM-04).

The gateway is the single execution wrapper for credentialed HTTP
provider adapters inside the worker service. It sits strictly BEHIND
the Coordinator-authorized path: it is only ever invoked with the
attempt's pinned binding snapshot for a unit the Coordinator claimed —
it authorizes nothing itself, holds no durable state (limiters and
chain metadata are process-local), and never substitutes its own
judgment for a binding (no silent model swaps: fallback exists only
where the attempt's pinned MM-03 assignment names one).

Responsibilities (LOCK_MM04):
  * context-limit check against the MM-03 models table before any
    provider call (chars/4 estimate, recorded as an estimate);
  * bounded in-attempt retries for provider-side failure classes
    (HTTP 429 / 5xx / connection / timeout) with backoff from the
    binding's retry_policy, all inside the binding's timeout budget;
  * authorized fallback to the assignment's fallback model — one call,
    provider-side trigger classes only, never for context refusals;
  * one correlation id per call-chain (X-Correlation-Id header, action
    records, usage-evidence lines, async provider job);
  * per-provider rate/concurrency limiting;
  * cancellation checks before each retry / fallback step;
  * provider_health outcome writes (MM-03 registry table).

Arming rule (LOCK_MM04 §1): the models-table features (context check,
MODEL_UNKNOWN) arm only when the worker has DB access (WORKER_DSN —
the same condition that arms plan-pin verification) AND the MM-03
registry is seeded in that database. An unseeded registry is the
feature-not-engaged state, so pre-MM-04 databases behave exactly as
before; where the registry is seeded, an unknown model refuses rather
than guessing a limit. Health writes follow the same arming (writes
are best-effort telemetry and never fail an execution).
"""
import math
import re
import sys
import threading
import time
import uuid

from adapters import ProviderError

MAX_RETRIES = 2
_DEFAULT_BASE_S = 1.0
_DEFAULT_MAX_S = 30.0
_DEFAULT_CONCURRENCY = 4
_USAGE_KEYS = ("input_tokens", "output_tokens", "total_tokens",
               "cached_tokens", "images", "media_seconds", "requests")


class ContextLimitError(ProviderError):
    def __init__(self, message):
        super().__init__(message, error_class="CONTEXT_LIMIT")


class ModelUnknownError(ProviderError):
    def __init__(self, message):
        super().__init__(message, error_class="MODEL_UNKNOWN")


class CancelledError(ProviderError):
    def __init__(self, message):
        super().__init__(message, error_class="CANCELLED")


def is_retryable(error_class):
    """Provider-side failure classes: rate limiting, server errors,
    connection failures and timeouts (urllib surfaces timeouts as
    PROVIDER_UNREACHABLE). Everything else — other 4xx, malformed
    responses, config errors, refusals — is task/request-shaped and
    neither retries nor triggers fallback."""
    if error_class in ("PROVIDER_UNREACHABLE", "PROVIDER_HTTP_429"):
        return True
    return bool(re.fullmatch(r"PROVIDER_HTTP_5\d\d", error_class or ""))


class GatewayContext:
    """Per-chain services the worker injects: DB access for the models
    table + health writes, and a cancellation probe (returns True when
    the chain's Coordinator provider job has been CANCELLED). Either
    may be absent — an absent probe means no external cancel signal
    exists for this chain, an absent DSN disarms the registry
    features (see module docstring)."""

    def __init__(self, dsn=None, cancel_check=None):
        self.dsn = dsn
        self.cancel_check = cancel_check

    def cancelled(self):
        if self.cancel_check is None:
            return False
        try:
            return bool(self.cancel_check())
        except Exception:  # noqa: BLE001 — a failed probe is not a cancel
            return False


# ------------------------------------------------------------ registry (DB)
def _connect(dsn):
    import psycopg
    from psycopg.rows import dict_row
    return psycopg.connect(dsn, row_factory=dict_row, autocommit=True)


def registry_armed(dsn):
    """True when the MM-03 models registry exists AND is seeded in the
    worker's database. Any DB problem (no DSN, table absent — a
    pre-016 database) reads as unarmed: the feature is not engaged."""
    if not dsn:
        return False
    try:
        with _connect(dsn) as conn:
            row = conn.execute("SELECT count(*) AS n FROM models").fetchone()
            return bool(row and row["n"])
    except Exception:  # noqa: BLE001 — unarmed, never a failure
        return False


def model_context_length(dsn, model):
    """(found, context_length|None) for a catalog model id."""
    with _connect(dsn) as conn:
        row = conn.execute(
            "SELECT context_length FROM models WHERE model_id=%s",
            (model,)).fetchone()
    if row is None:
        return False, None
    return True, row["context_length"]


def write_health(dsn, provider, status, detail):
    """One provider_health row per chain outcome. Best-effort: a
    telemetry failure is reported on stderr, never raised."""
    if not dsn:
        return
    try:
        with _connect(dsn) as conn:
            conn.execute(
                "INSERT INTO provider_health(provider, status, detail)"
                " VALUES (%s,%s,%s)", (provider, status, detail))
    except Exception as exc:  # noqa: BLE001
        print(f"gateway: provider_health write failed: {exc}",
              file=sys.stderr)


# ---------------------------------------------------------------- limiters
class _Limiter:
    def __init__(self, max_concurrency, min_interval_ms):
        self._sem = threading.Semaphore(max(1, int(max_concurrency)))
        self._interval = max(0.0, float(min_interval_ms) / 1000.0)
        self._last_start = 0.0
        self._lock = threading.Lock()

    def __enter__(self):
        with self._lock:
            wait = self._last_start + self._interval - time.monotonic()
            if wait > 0:
                time.sleep(wait)
            self._last_start = time.monotonic()
        self._sem.acquire()
        return self

    def __exit__(self, *exc):
        self._sem.release()
        return False


_LIMITERS = {}
_LIMITERS_LOCK = threading.Lock()


def limiter_for(binding):
    """Per-provider limiter; parameters come from the FIRST binding
    seen for the provider in this process (params.max_concurrency,
    else the binding's concurrency_limit column, else 4;
    params.min_interval_ms, else 0)."""
    provider = binding.get("provider")
    with _LIMITERS_LOCK:
        lim = _LIMITERS.get(provider)
        if lim is None:
            params = binding.get("params") or {}
            max_c = params.get("max_concurrency")
            if max_c is None:
                max_c = binding.get("concurrency_limit")
            if max_c is None:
                max_c = _DEFAULT_CONCURRENCY
            lim = _Limiter(max_c, params.get("min_interval_ms") or 0)
            _LIMITERS[provider] = lim
        return lim


def reset_limiters():
    """Test support: forget all per-provider limiters."""
    with _LIMITERS_LOCK:
        _LIMITERS.clear()


# ------------------------------------------------------------------- usage
def _normalize_usage(raw):
    """Provider usage dict -> coordinator usage keys. Accepts both the
    OpenRouter shape (prompt_tokens/completion_tokens) and already-
    normalized dicts (the direct-http adapter's usage passthrough)."""
    if not isinstance(raw, dict):
        return {}
    out = {}
    if "prompt_tokens" in raw:
        out["input_tokens"] = raw.get("prompt_tokens")
    if "completion_tokens" in raw:
        out["output_tokens"] = raw.get("completion_tokens")
    for k in _USAGE_KEYS:
        if k in raw:
            out[k] = raw[k]
    return {k: v for k, v in out.items()
            if isinstance(v, (int, float)) and not isinstance(v, bool)}


def _error_usage(exc):
    body = getattr(exc, "response_body", None)
    if isinstance(body, dict):
        usage = _normalize_usage(body.get("usage"))
        req_id = body.get("id") or body.get("request_id")
        return usage, req_id
    return {}, None


def _sum_usage(lines):
    total = {}
    for line in lines:
        for k, v in (line.get("usage") or {}).items():
            total[k] = total.get(k, 0) + v
    return total


def _retry_policy(binding):
    rp = binding.get("retry_policy")
    if not isinstance(rp, dict) or not rp:
        rp = (binding.get("params") or {}).get("retry_policy")
    if not isinstance(rp, dict):
        rp = {}
    base = rp.get("base_s")
    max_s = rp.get("max_s")
    return (float(base) if base is not None else _DEFAULT_BASE_S,
            float(max_s) if max_s is not None else _DEFAULT_MAX_S)


def _prompt_of(request):
    if request.get("prompt"):
        return request["prompt"]
    refs = request.get("input_artifact_refs") or []
    return (f"Execute operation {request.get('operation_id')} for production "
            f"{request.get('production_id')} with {len(refs)} input artifact(s).")


def estimate_prompt_tokens(request):
    """The recorded prompt-size estimate: chars/4, rounded up. An
    estimate — the context check compares it against the catalog
    context_length; the value is carried in evidence as
    estimated_prompt_tokens, never presented as provider usage."""
    return math.ceil(len(_prompt_of(request)) / 4)


# ------------------------------------------------------------------- chain
class _Chain:
    def __init__(self, binding, request, ctx):
        self.binding = binding
        self.request = request
        self.ctx = ctx or GatewayContext()
        self.correlation_id = str(uuid.uuid4())
        self.lines = []
        budget = min(binding.get("timeout_s") or 120,
                     request.get("deadline_s") or 120)
        self.started = time.monotonic()
        self.deadline = self.started + float(budget)
        self.armed = registry_armed(self.ctx.dsn)

    # -- evidence ------------------------------------------------------
    def _line(self, kind, model, outcome, usage=None, provider_request_id=None,
              error_class=None):
        line = {"call_index": len(self.lines),
                "kind": kind,
                "model": model,
                "outcome": outcome,
                "usage": usage or {},
                "provider_request_id": provider_request_id,
                "error_class": error_class,
                "correlation_id": self.correlation_id,
                "started_offset_s": round(time.monotonic() - self.started, 3)}
        self.lines.append(line)
        return line

    def metadata(self, executed_model, fallback_event=None):
        return {"correlation_id": self.correlation_id,
                "model": executed_model,
                "usage_lines": list(self.lines),
                "fallback_event": fallback_event,
                "calls": len(self.lines)}

    def _health(self, status, detail):
        write_health(self.ctx.dsn, self.binding.get("provider"), status,
                     detail)

    # -- checks ---------------------------------------------------------
    def check_context(self, model, kind):
        """Pre-call context gate for one chain segment. Unarmed
        registry -> not engaged. Armed -> the model must be known
        with a recorded context_length, and the estimate must fit."""
        if not self.armed or not model:
            return None
        found, limit = model_context_length(self.ctx.dsn, model)
        estimate = estimate_prompt_tokens(self.request)
        if not found or limit is None:
            line = self._line(kind, model, "refused",
                              error_class="MODEL_UNKNOWN")
            line["estimated_prompt_tokens"] = estimate
            self._health("refused",
                         f"model={model} class=MODEL_UNKNOWN calls=0")
            raise ModelUnknownError(
                f"model {model!r} is not in the MM-03 models registry "
                f"with a recorded context_length — refusing rather than "
                f"guessing a limit (correlation {self.correlation_id})")
        if estimate > limit:
            line = self._line(kind, model, "refused",
                              error_class="CONTEXT_LIMIT")
            line["estimated_prompt_tokens"] = estimate
            self._health("refused",
                         f"model={model} class=CONTEXT_LIMIT calls=0")
            raise ContextLimitError(
                f"estimated prompt {estimate} tokens exceeds model "
                f"{model!r} context_length {limit} "
                f"(correlation {self.correlation_id})")
        return estimate

    def _check_cancel(self, where):
        if self.ctx.cancelled():
            raise CancelledError(
                f"provider chain cancelled by the Coordinator before "
                f"{where} (correlation {self.correlation_id})")

    def _call(self, adapter, binding, model, kind, credential):
        """One provider HTTP call under the limiter, with the chain's
        correlation header and the remaining deadline budget."""
        remaining = self.deadline - time.monotonic()
        if remaining <= 0:
            raise ProviderError(
                "provider chain deadline exhausted before call "
                f"(correlation {self.correlation_id})",
                error_class="PROVIDER_UNREACHABLE")
        req = dict(self.request)
        req["deadline_s"] = max(1, int(remaining))
        req["_gateway_headers"] = {"X-Correlation-Id": self.correlation_id}
        with limiter_for(binding):
            return adapter.execute(binding, req, credential)

    def _segment(self, adapter, binding, model, kind, credential, retries):
        """One model segment: the initial call plus up to `retries`
        bounded retries on provider-side classes. Returns the adapter
        result; raises the last ProviderError when the segment fails."""
        attempt = 0
        base_s, max_s = _retry_policy(binding)
        while True:
            try:
                result = self._call(adapter, binding, model, kind, credential)
            except ProviderError as exc:
                usage, req_id = _error_usage(exc)
                self._line(kind, model, "error", usage=usage,
                           provider_request_id=req_id,
                           error_class=exc.error_class)
                if not is_retryable(exc.error_class) or attempt >= retries:
                    raise
                attempt += 1
                delay = min(base_s * (2 ** (attempt - 1)), max_s)
                if time.monotonic() + delay > self.deadline:
                    raise  # the timeout budget covers all tries
                self._check_cancel(f"retry {attempt}")
                time.sleep(delay)
                continue
            usage = _normalize_usage(result.get("usage"))
            self._line(kind, model, "success", usage=usage,
                       provider_request_id=result.get("provider_request_id"))
            return result


def execute_chain(adapter, binding, request, credential=None, ctx=None):
    """Run one provider call-chain for a sync adapter execution:
    context check -> primary segment (<= 1 + MAX_RETRIES calls) ->
    authorized fallback segment (exactly one call) when the pinned
    assignment names a fallback and the primary failed provider-side.

    Returns the adapter result augmented with the summed usage, the
    executed call's provider_request_id, and a 'gateway' metadata dict
    (correlation_id, model, usage_lines, fallback_event, calls,
    estimated_prompt_tokens). On failure raises the terminal
    ProviderError with '.gateway' metadata attached."""
    chain = _Chain(binding, request, ctx)
    primary_model = binding.get("model")
    try:
        chain.check_context(primary_model, "primary")
        result = chain._segment(adapter, binding, primary_model,
                                "primary", credential, MAX_RETRIES)
        executed_model = primary_model
        fallback_event = None
    except (ContextLimitError, ModelUnknownError) as exc:
        # refusals are terminal; fallback never rescues them. The
        # chain evidence rides the exception so the caller's action
        # record carries the refusal line + estimate + correlation id.
        exc.gateway = chain.metadata(primary_model)
        raise
    except ProviderError as exc:
        assignment = binding.get("model_assignment") or {}
        fallback_model = assignment.get("fallback_model")
        if not fallback_model or not is_retryable(exc.error_class):
            exc.gateway = chain.metadata(primary_model)
            chain._health("refused" if isinstance(exc, CancelledError)
                          else "error",
                          f"model={primary_model} "
                          f"class={exc.error_class} "
                          f"calls={len(chain.lines)}")
            raise
        try:
            chain._check_cancel("fallback")
        except CancelledError as cexc:
            cexc.gateway = chain.metadata(primary_model)
            chain._health("refused", f"model={primary_model} "
                                     f"class=CANCELLED "
                                     f"calls={len(chain.lines)}")
            raise
        fallback_binding = dict(binding)
        fallback_binding["model"] = fallback_model
        try:
            chain.check_context(fallback_model, "fallback")
            result = chain._segment(adapter, fallback_binding,
                                    fallback_model, "fallback",
                                    credential, 0)
        except ProviderError as fb_exc:
            fb_exc.gateway = chain.metadata(primary_model)
            chain._health("error", f"model={fallback_model} "
                                   f"class={fb_exc.error_class} "
                                   f"calls={len(chain.lines)}")
            raise
        executed_model = fallback_model
        fallback_event = {"primary_model": primary_model,
                          "fallback_model": fallback_model,
                          "trigger_class": exc.error_class,
                          "correlation_id": chain.correlation_id}
    meta = chain.metadata(executed_model, fallback_event)
    meta["estimated_prompt_tokens"] = estimate_prompt_tokens(request)
    result = dict(result)
    summed = _sum_usage(chain.lines)
    if summed:
        result["usage"] = summed
    result["gateway"] = meta
    chain._health("ok", f"model={executed_model} "
                        f"calls={len(chain.lines)}")
    return result


def submit_chain(adapter, binding, request, credential=None, ctx=None):
    """The async twin of execute_chain for adapter.submit: context
    check + bounded retries + authorized fallback (model swap on the
    submit body). Returns (provider_job_id, gateway_metadata). Polling
    is NOT gateway-wrapped — the Coordinator's reconciler owns it —
    but the job context carries the chain's correlation id."""
    chain = _Chain(binding, request, ctx)
    primary_model = binding.get("model")
    base_s, max_s = _retry_policy(binding)
    seg_binding, seg_model, kind = binding, primary_model, "primary"
    fallback_event = None
    retries_left = MAX_RETRIES
    try:
        chain.check_context(primary_model, "primary")
        while True:
            req = dict(request)
            remaining = chain.deadline - time.monotonic()
            if remaining <= 0:
                raise ProviderError(
                    "provider chain deadline exhausted before submit "
                    f"(correlation {chain.correlation_id})",
                    error_class="PROVIDER_UNREACHABLE")
            req["deadline_s"] = max(1, int(remaining))
            req["_gateway_headers"] = {
                "X-Correlation-Id": chain.correlation_id}
            try:
                with limiter_for(seg_binding):
                    job_id = adapter.submit(seg_binding, req, credential)
            except ProviderError as exc:
                chain._line(kind, seg_model, "error",
                            error_class=exc.error_class)
                if kind == "primary" and retries_left > 0 \
                        and is_retryable(exc.error_class):
                    retries_left -= 1
                    delay = min(base_s * (2 ** (MAX_RETRIES - retries_left - 1)),
                                max_s)
                    if time.monotonic() + delay > chain.deadline:
                        raise
                    chain._check_cancel("submit retry")
                    time.sleep(delay)
                    continue
                assignment = binding.get("model_assignment") or {}
                fb_model = assignment.get("fallback_model")
                if kind == "primary" and fb_model \
                        and is_retryable(exc.error_class):
                    chain._check_cancel("fallback submit")
                    fallback_event = {
                        "primary_model": primary_model,
                        "fallback_model": fb_model,
                        "trigger_class": exc.error_class,
                        "correlation_id": chain.correlation_id}
                    seg_binding = dict(binding)
                    seg_binding["model"] = fb_model
                    seg_model, kind = fb_model, "fallback"
                    chain.check_context(fb_model, "fallback")
                    continue
                raise
            chain._line(kind, seg_model, "success")
            meta = chain.metadata(seg_model, fallback_event)
            meta["estimated_prompt_tokens"] = estimate_prompt_tokens(request)
            chain._health("ok", f"model={seg_model} "
                                f"calls={len(chain.lines)}")
            return job_id, meta
    except (ContextLimitError, ModelUnknownError) as exc:
        exc.gateway = chain.metadata(seg_model, fallback_event)
        raise
    except ProviderError as exc:
        exc.gateway = chain.metadata(seg_model, fallback_event)
        chain._health("refused" if isinstance(exc, CancelledError)
                      else "error",
                      f"model={seg_model} "
                      f"class={exc.error_class} "
                      f"calls={len(chain.lines)}")
        raise
