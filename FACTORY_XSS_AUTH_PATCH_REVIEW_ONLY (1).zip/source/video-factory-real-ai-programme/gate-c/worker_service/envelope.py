"""OD-E1 (iii) layered contracts — envelope production (Gate G, Part A).

Two layers, per Raj's OD-E1 ruling (LAYERED):
  * envelope — the registry step contract
    (g1/contracts/step-NN/output.schema.json): {production_id,
    operation_id, status, step_deliverable, output_artifacts, evidence}.
  * deliverable — the operation's payload itself, carried as
    output_artifacts[0].content and validated by the evaluation service
    against g1/contracts/deliverables/step-NN.schema.json (14.01 against
    deliverables/op-14.01.schema.json).

Deviations from the Gate G brief's draft shapes, forced by the FROZEN
envelope schemas (the schemas are authoritative):
  * status is "CANDIDATE" — the envelope status enum is
    [CANDIDATE, ACCEPTED, REVIEW_REQUIRED, BLOCKED]; there is no
    "COMPLETED" value.
  * evidence entries are {validator, method, result, detail?} with
    additionalProperties false — worker provenance (provider, model,
    config hash, attempt id) is recorded in `detail`, with
    validator="worker_provenance" and method=<provider name>.
  * output_artifacts[].artifact_id is required by the schema but the
    coordinator assigns the real id only at completion; the worker emits
    the placeholder below (the evaluation layers treat an entry's own
    artifact_id/sha256 as manifest data, never as content references).

Only step exits (.12) are wrapped, and only for the payload-backed
local adapters (deterministic-local / mock) whose results ARE factory
deliverables. Provider adapters return provider content verbatim.
14.01 and other non-exit operations return the bare payload.
"""
import hashlib
import json
from pathlib import Path

G1_CONTRACTS = Path.home() / "workspace/video-factory-g1/contracts"
PLACEHOLDER_ARTIFACT_ID = "00000000-0000-4000-8000-0000000000e0"
PAYLOAD_PROVIDERS = ("deterministic-local", "mock")
_const_cache = {}


def is_step_exit(operation_id):
    return bool(operation_id) and operation_id.endswith(".12")


def step_deliverable_const(step_id):
    if step_id not in _const_cache:
        schema = json.loads(
            (G1_CONTRACTS / f"step-{step_id}" / "output.schema.json").read_text())
        _const_cache[step_id] = schema["properties"]["step_deliverable"]["const"]
    return _const_cache[step_id]


def payload_value(content):
    """The deliverable as a JSON value: parsed object/array when the
    payload is JSON, the raw string for the plain-text payloads."""
    if not isinstance(content, str):
        return content
    try:
        return json.loads(content)
    except (json.JSONDecodeError, ValueError):
        return content


def canonical_sha(value):
    """SHA-256 of the payload's canonical bytes: the text itself for
    string payloads, canonical JSON (sorted keys) for JSON payloads."""
    data = value.encode() if isinstance(value, str) else \
        json.dumps(value, sort_keys=True).encode()
    return hashlib.sha256(data).hexdigest()


def wrap(binding, request, artifact_type, content, plan_executed=False):
    """Envelope JSON string for a step-exit payload, or None when this
    result must stay bare (non-exit op or non-payload provider).

    Lean Phase 3: plan_executed=True marks a result produced by plan
    execution under a provider binding (the op 08.12 slice): the
    deliverable came out of the plan, so it is wrapped exactly like a
    payload-backed result — the envelope's evidence records the real
    provider/model from the binding. Direct (non-plan) provider
    adapter results still return provider content verbatim."""
    operation_id = request.get("operation_id") or ""
    if (binding or {}).get("provider") not in PAYLOAD_PROVIDERS \
            and not plan_executed:
        return None
    if not is_step_exit(operation_id):
        return None
    step_id = operation_id.split(".")[0]
    value = payload_value(content)
    detail = (f"provider={binding.get('provider')} model={binding.get('model')} "
              f"config_hash={request.get('config_hash')} "
              f"attempt_id={request.get('attempt_id')}")
    envelope = {
        "production_id": request.get("production_id"),
        "operation_id": operation_id,
        "status": "CANDIDATE",
        "step_deliverable": step_deliverable_const(step_id),
        "output_artifacts": [{
            "artifact_id": PLACEHOLDER_ARTIFACT_ID,
            "artifact_type": artifact_type,
            "content": value,
            "sha256": canonical_sha(value),
        }],
        "evidence": [{
            "validator": "worker_provenance",
            "method": binding.get("provider"),
            "result": "PASS",
            "detail": detail,
        }],
    }
    return json.dumps(envelope, sort_keys=True)


def unwrap_entry(content_bytes, artifact_type):
    """Deliverable value inside an envelope's bytes: the output_artifacts
    entry whose artifact_type matches (else the first entry). Returns
    None when the bytes are not an envelope."""
    try:
        parsed = json.loads(content_bytes)
    except Exception:  # noqa: BLE001
        return None
    if not isinstance(parsed, dict) or "output_artifacts" not in parsed:
        return None
    entries = parsed.get("output_artifacts") or []
    for entry in entries:
        if isinstance(entry, dict) and entry.get("artifact_type") == artifact_type:
            return entry.get("content")
    if entries and isinstance(entries[0], dict):
        return entries[0].get("content")
    return None
