"""Provider adapters (Gate C, master prompt §6).

One interface, eight adapters. Credential rule (hard): an adapter that
needs a credential raises BlockedError from execute()/submit() when the
credential named by the binding's credential_ref is not present in the
environment. It NEVER fabricates a result instead — BLOCKED is a state,
not a simulation. Credentials are resolved by the service from the
environment variable NAMED by credential_ref; secret values never appear
in bindings, requests, or this package's data structures beyond the HTTP
Authorization header they are used in.
"""
import json
import os
import urllib.error
import urllib.request

import payloads


class BlockedError(Exception):
    """No credential (or no test-only authorization) — execution refused."""


class ProviderError(Exception):
    """Normalized provider failure; error_class is machine-readable.

    MM-04: ``response_body`` carries the provider's parsed error body
    when one was returned (an error response may still report usage —
    the gateway records it as a usage-evidence line instead of dropping
    it). It never carries credentials: error bodies come from the
    provider, and the request's Authorization header is not echoed."""

    def __init__(self, message, error_class="PROVIDER_ERROR", response_body=None):
        super().__init__(message)
        self.error_class = error_class
        self.response_body = response_body


def _dig(obj, path):
    cur = obj
    for part in (path or "").split("."):
        if not part:
            continue
        if not isinstance(cur, dict):
            return None
        cur = cur.get(part)
    return cur


def _http_json(method, url, credential=None, body=None, timeout=30, headers=None):
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(url, data=data, method=method)
    req.add_header("Content-Type", "application/json")
    if credential:
        req.add_header("Authorization", f"Bearer {credential}")
    for k, v in (headers or {}).items():
        req.add_header(k, v)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.loads(r.read() or b"{}")
    except urllib.error.HTTPError as e:
        raw = None
        try:
            raw = e.read()
        except Exception:  # noqa: BLE001 — body unavailable; class suffices
            raw = None
        parsed = None
        if raw:
            try:
                parsed = json.loads(raw)
            except Exception:  # noqa: BLE001 — non-JSON error body
                parsed = None
        raise ProviderError(f"provider HTTP {e.code} from {url}",
                            error_class=f"PROVIDER_HTTP_{e.code}",
                            response_body=parsed) from None
    except urllib.error.URLError as e:
        raise ProviderError(f"provider unreachable at {url}: {e.reason}",
                            error_class="PROVIDER_UNREACHABLE") from None


class Adapter:
    name = "base"
    modality = None
    credential_required = False
    environment = "test"  # set by the service

    def capabilities(self):
        return {"name": self.name, "modality": self.modality,
                "credential_required": self.credential_required,
                "async": False}

    def validate_config(self, binding):
        """List of human-readable binding problems ([] = usable)."""
        problems = []
        if self.credential_required and not binding.get("credential_ref"):
            problems.append("binding has no credential_ref")
        return problems

    def estimate(self, binding, inputs=None):
        return binding.get("est_cost_cents")

    def credential_for(self, binding):
        ref = binding.get("credential_ref")
        return os.environ.get(ref) if ref else None

    def require_credential(self, binding):
        cred = self.credential_for(binding)
        if not cred:
            raise BlockedError(
                f"adapter {self.name}: credential "
                f"{binding.get('credential_ref')!r} is not set in the environment")
        return cred

    def execute(self, binding, request, credential=None):
        raise NotImplementedError

    def submit(self, binding, request, credential=None):
        raise ProviderError(f"adapter {self.name} does not support async submission",
                            error_class="ASYNC_UNSUPPORTED")

    def poll(self, binding, provider_job_id, credential=None):
        raise ProviderError(f"adapter {self.name} does not support async polling",
                            error_class="ASYNC_UNSUPPORTED")


def _prompt_of(request):
    if request.get("prompt"):
        return request["prompt"]
    refs = request.get("input_artifact_refs") or []
    return (f"Execute operation {request.get('operation_id')} for production "
            f"{request.get('production_id')} with {len(refs)} input artifact(s).")


class OpenRouterCompatibleAdapter(Adapter):
    """Chat-completions over an OpenRouter-compatible HTTP API. The base
    URL constant lives HERE, inside the adapter (a provider fact), never
    in workflow JSON or coordinator code; a binding may override it via
    params.base_url."""
    name = "openrouter-compatible"
    modality = "text"
    credential_required = True
    DEFAULT_BASE_URL = "https://openrouter.ai/api/v1"

    def execute(self, binding, request, credential=None):
        credential = credential or self.require_credential(binding)
        params = binding.get("params") or {}
        base = params.get("base_url", self.DEFAULT_BASE_URL).rstrip("/")
        body = {"model": binding.get("model"),
                "messages": [{"role": "user", "content": _prompt_of(request)}]}
        for k in ("temperature", "max_tokens"):
            if k in params:
                body[k] = params[k]
        resp = _http_json("POST", f"{base}/chat/completions", credential, body,
                          timeout=min(binding.get("timeout_s") or 120,
                                      request.get("deadline_s") or 120),
                          headers=request.get("_gateway_headers"))
        try:
            content = resp["choices"][0]["message"]["content"]
        except (KeyError, IndexError, TypeError):
            raise ProviderError("provider response has no completion content",
                                error_class="PROVIDER_BAD_RESPONSE") from None
        usage = resp.get("usage") or {}
        return {"artifact_type": "text_output", "content": content,
                "usage": {"input_tokens": usage.get("prompt_tokens"),
                          "output_tokens": usage.get("completion_tokens"),
                          "total_tokens": usage.get("total_tokens")},
                "provider_request_id": resp.get("id"),
                "cost_cents": None}


class DirectHttpTextAdapter(Adapter):
    """Generic JSON-over-HTTP provider: POST params.endpoint with a JSON
    body built from params.request_template ("{prompt}" / "{model}"
    placeholders), or submit+poll when params.mode == 'async'
    (params.poll_endpoint with a {job_id} placeholder). Response fields
    are extracted by dotted paths (params.content_path etc.)."""
    name = "direct-http-text"
    modality = "text"
    credential_required = True

    def capabilities(self):
        caps = super().capabilities()
        caps["async"] = True
        return caps

    def validate_config(self, binding):
        problems = super().validate_config(binding)
        if not (binding.get("params") or {}).get("endpoint"):
            problems.append("params.endpoint is required")
        return problems

    def _body(self, binding, request):
        params = binding.get("params") or {}
        template = params.get("request_template") or {"prompt": "{prompt}", "model": "{model}"}
        out = {}
        for k, v in template.items():
            if isinstance(v, str):
                v = v.replace("{prompt}", _prompt_of(request)) \
                     .replace("{model}", binding.get("model") or "")
            out[k] = v
        return out

    def _extract(self, binding, resp):
        params = binding.get("params") or {}
        return {"artifact_type": params.get("artifact_type", "text_output"),
                "content": _dig(resp, params.get("content_path", "content")),
                "usage": _dig(resp, params.get("usage_path", "usage")) or {},
                "provider_request_id": _dig(resp, params.get("id_path", "id")),
                "cost_cents": _dig(resp, params.get("cost_path", "cost_cents"))}

    def execute(self, binding, request, credential=None):
        credential = credential or self.require_credential(binding)
        params = binding.get("params") or {}
        resp = _http_json("POST", params["endpoint"], credential,
                          self._body(binding, request),
                          timeout=min(binding.get("timeout_s") or 120,
                                      request.get("deadline_s") or 120),
                          headers=request.get("_gateway_headers"))
        return self._extract(binding, resp)

    def submit(self, binding, request, credential=None):
        credential = credential or self.require_credential(binding)
        params = binding.get("params") or {}
        resp = _http_json("POST", params.get("submit_endpoint", params.get("endpoint")),
                          credential, self._body(binding, request),
                          timeout=min(binding.get("timeout_s") or 120,
                                      request.get("deadline_s") or 120),
                          headers=request.get("_gateway_headers"))
        job_id = _dig(resp, params.get("job_id_path", "job_id"))
        if job_id is None:
            raise ProviderError("async submit response has no job id",
                                error_class="PROVIDER_BAD_RESPONSE")
        return str(job_id)

    def poll(self, binding, provider_job_id, credential=None):
        credential = credential or self.require_credential(binding)
        params = binding.get("params") or {}
        url = (params.get("poll_endpoint") or "").replace("{job_id}", provider_job_id)
        if not url:
            raise ProviderError("params.poll_endpoint is required for async polling",
                                error_class="CONFIG_INVALID")
        resp = _http_json("GET", url, credential, None,
                          timeout=binding.get("timeout_s") or 60)
        state = str(_dig(resp, params.get("status_path", "status")) or "").upper()
        done = {s.upper() for s in params.get("done_states", ["COMPLETED", "SUCCEEDED", "DONE"])}
        failed = {s.upper() for s in params.get("failed_states", ["FAILED", "ERROR", "CANCELLED"])}
        if state in done:
            out = self._extract(binding, resp)
            out["status"] = "COMPLETED"
            return out
        if state in failed:
            return {"status": "FAILED",
                    "error": _dig(resp, params.get("error_path", "error")) or state}
        return {"status": state or "PROCESSING"}


class HttpMediaAdapter(DirectHttpTextAdapter):
    """Image / video / speech / transcription / stock media over the same
    generic HTTP mechanics; the result content is the provider's media
    reference (URL) rather than inline text."""

    def __init__(self, modality):
        self.modality = modality
        self.name = f"http-{modality}"

    def _extract(self, binding, resp):
        params = binding.get("params") or {}
        return {"artifact_type": params.get("artifact_type", f"{self.modality}_output"),
                "content": _dig(resp, params.get("content_path", "url")),
                "usage": _dig(resp, params.get("usage_path", "usage")) or {},
                "provider_request_id": _dig(resp, params.get("id_path", "id")),
                "cost_cents": _dig(resp, params.get("cost_path", "cost_cents"))}


class DeterministicLocalAdapter(Adapter):
    """No network, no credential: executes the operation's Gate 04
    execution plan through the deterministic engine (plan_exec.py) —
    the 19 proven builders decomposed as op.build_payload actions, the
    remaining operations through their plan's engine actions, and any
    operation whose plan carries an UNBOUND action refused explicitly.
    This is the accepted factory behavior, packaged behind the
    production worker contract."""
    name = "deterministic-local"
    modality = "any"
    credential_required = False

    def execute(self, binding, request, credential=None):
        import plan_exec  # deferred: plan_exec imports adapters (cycle)
        sink = request.pop("_action_record_sink", None)
        artifact_type, content, summary = plan_exec.execute_operation(
            request, sink=sink)
        # Gate G judgment call (recorded in the Gate G builder summary):
        # the retired mock workers reported an ACTUAL of 90 against a
        # binding estimate of 100, and the G5/G9 budget assertions
        # (4x90, 18x90=1620) encode that measured cost. The reported
        # actual is DATA, not code: binding params.reported_actual_cents
        # when the setup seeded it, the estimate otherwise.
        params = binding.get("params") or {}
        reported = params.get("reported_actual_cents")
        return {"artifact_type": artifact_type, "content": content,
                "usage": {"deterministic": True},
                "provider_request_id": None,
                "cost_cents": reported if reported is not None
                else binding.get("est_cost_cents"),
                "plan_execution": summary}


class MockAdapter(Adapter):
    """The pre-Gate-C mock behavior, fenced: refuses unless the binding is
    explicitly test-only (params.test_only is true) AND the service runs in
    the test environment. In production it is indistinguishable from a
    blocked adapter."""
    name = "mock"
    modality = "any"
    credential_required = False

    def execute(self, binding, request, credential=None):
        params = binding.get("params") or {}
        if not params.get("test_only") or self.environment != "test":
            raise BlockedError(
                "mock adapter requires params.test_only=true and a test environment")
        import plan_exec  # deferred: plan_exec imports adapters (cycle)
        sink = request.pop("_action_record_sink", None)
        artifact_type, content, summary = plan_exec.execute_operation(
            request, sink=sink)
        return {"artifact_type": artifact_type, "content": content,
                "usage": {"mock": True},
                "provider_request_id": None,
                "cost_cents": binding.get("est_cost_cents"),
                "plan_execution": summary}


class FliteLocalAdapter(Adapter):
    """MM-06 — genuine LOCAL text-to-speech via the ffmpeg `flite`
    source (libflite, compiled into this environment's ffmpeg and
    probe-verified at MM-06 Step 0). No network, no credential: the
    synthesized WAV is written to the Gate D artifact store and the
    result content names its store URI + SHA-256 + probed duration.

    Honestly labeled LOCAL_TOOL: flite voices are robotic formant
    synthesis — a functional local path, NOT production voice
    quality. `simulated` is False in the result metadata: the audio
    is really synthesized; it is the quality that is limited, and
    the production-TTS upgrade path stays the credential-gated
    http-speech adapter under an owner provider decision."""
    name = "ffmpeg-flite-local"
    modality = "speech"
    credential_required = False

    def capabilities(self):
        caps = super().capabilities()
        caps.update({"local_tool": True, "engine": "ffmpeg libflite",
                     "voices": ["slt", "kal", "awb", "rms"]})
        return caps

    def execute(self, binding, request, credential=None):

        import media_tools
        params = (binding or {}).get("params") or {}
        text = request.get("prompt") or params.get("text") \
            or _prompt_of(request)
        voice = params.get("voice", "slt")
        with media_tools.workdir("mm06-flite-") as workdir:
            wav = workdir / "speech.wav"
            try:
                probe = media_tools.synthesize_speech_wav(text, wav,
                                                          voice=voice)
            except media_tools.MediaToolError as exc:
                raise ProviderError(f"local TTS failed: {exc}",
                                    error_class="LOCAL_TOOL_FAILED") from None
            stored = media_tools.store_media_bytes(wav.read_bytes(),
                                                   "audio/wav")
            return {"artifact_type": "speech_audio",
                    "content": {"storage_uri": stored["storage_uri"],
                                "sha256": stored["sha256"],
                                "format": "wav",
                                "duration_s": probe["duration_s"],
                                "engine": self.name, "voice": voice,
                                "simulated": False,
                                "label": "LOCAL_TOOL"},
                    "usage": {"characters": len(text), "local_tool": True},
                    "provider_request_id": None,
                    "cost_cents": 0}


def build_registry(environment="test"):
    adapters = [OpenRouterCompatibleAdapter(), DirectHttpTextAdapter(),
                HttpMediaAdapter("image"), HttpMediaAdapter("video"),
                HttpMediaAdapter("speech"), HttpMediaAdapter("transcription"),
                HttpMediaAdapter("stock"), DeterministicLocalAdapter(), MockAdapter(),
                FliteLocalAdapter()]
    registry = {}
    for a in adapters:
        a.environment = environment
        registry[a.name] = a
    return registry
