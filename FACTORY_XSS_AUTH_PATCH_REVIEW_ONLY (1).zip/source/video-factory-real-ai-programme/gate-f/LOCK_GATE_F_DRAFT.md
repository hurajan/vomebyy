# LOCK DRAFT — GATE F: Scheduling, recovery, and asynchronous execution

**STATUS: DRAFT — NOT CONFIRMED. Prepared proactively 2026-10-28 after Gate E completed; takes effect only on Raj's confirmation. Gate E acceptance is a separate call and is not assumed by this draft.**

- **Predecessor:** Gate E COMPLETE + INDEPENDENTLY VERIFIED, defects NONE, zero pre-existing assertions changed, 143 tests green (report `../gate-e/GATE_E_REPORT.md`). Acceptance by Raj: PENDING at draft time.
- **Scope sources:** Gate E report §"Next gate as planned"; Master Implementation Prompt §13 (reliable autonomous dispatch and recovery) and §20 (GATE F: Scheduling, recovery, and asynchronous execution); Gate A findings GA-03/GA-04 (library-only async/scheduler functions); 2026-10-28 code audit (outbox written but never drained; `scheduler_claim`, `reap_expired_leases`, `reconcile_once` never invoked by any running process).

## Scope (as planned — no additions)

1. **Scheduler service** — a running service (new package in this gate's tree) that claims READY units through the Coordinator only, using Gate C/D config-priced estimates (D-C1 rule: config estimate authoritative at the API/service path, caller value is a ceiling assertion only), honoring the registry `capacity_policies` lanes. It issues no state changes except via Coordinator claim machinery (INV-001).
2. **Outbox dispatcher** — drains `outbox_events` durably and idempotently; a dispatched event is marked only after its handler succeeds; duplicate delivery must not cause duplicate provider spending or duplicate claims.
3. **Lease-reaper loop** — runs `reap_expired_leases` as a service loop: expired leases are reaped through Coordinator transitions only, with audit evidence; a live lease is never reaped.
4. **Reconciler as a service** — `reconcile_once` running against the Gate C async path (claim-bound provider-job registration, fencing-gated completion): UNKNOWN / stale provider outcomes reconcile exactly once; a stale callback registers nothing, settles nothing, transitions nothing (Gate B design, Gate C implementation).
5. **Bounded automatic retries** — transient failures retry with exponential backoff + jitter, subject to a maximum-attempt cap; exhaustion lands in a dead-letter / intervention state that requires a human or an explicit redispatch — never an infinite loop, never a silent park indistinguishable from RETRY_WAIT today. Provider failure classification (transient vs deterministic vs rate-limit) recorded in evidence; rate-limit responses back off rather than hammer.
6. **Restart recovery** — API, worker, scheduler, or host restart mid-flight: on restart the services reconcile in-flight attempts, leases, and provider jobs before claiming new work; no attempt is double-claimed and no reservation is double-spent across a restart (T7 recovery test group).
7. **Concurrency control** — simultaneous execution of the same authorized attempt is prevented by Coordinator transactional locking / fencing, not by n8n execution history (Master Prompt §13).

## OPEN lock-time parameters (Raj's to set — NOT pre-filled in this draft)

- **Retry cap:** maximum attempts per unit before dead-letter/intervention. No source specifies a number.
- **Backoff shape:** base delay and maximum delay for the exponential backoff + jitter. No source specifies values.
- **Dead-letter disposition:** named intervention state / queue and who clears it (operator-only presumed, to confirm).
- **Service cadence:** scheduler / reaper / reconciler loop intervals. No source specifies values.

A confirmation of the form "Accept Gate E; confirm Gate F lock as drafted; retry cap = [n], backoff = [base/max], dead-letter = [disposition], cadence = [interval]" settles all of it in one line. Any parameter left unset stays OPEN and the build does not invent it.

## Compatibility contract

- All existing suites stay green at their Gate E counts (143 total: evaluation_service 21, G1 9, G2 58, G3 20, G4 2, G5 1, G6 3, G7 2, G8 1, G9 9, worker_service 11, storage_service 5) plus new Gate F service tests.
- Any pre-existing assertion that must move because of a fixed defect is listed explicitly in the Gate F evidence (Gate C/D precedent).
- Station executors and dashboard are NOT rewired in this gate — that is Gate G. Gate F proves the services standalone against real Coordinator state (Gate E precedent).

## Explicitly NOT in scope / dependencies

- **OD-E1 (envelope vs payload contracts): NOT a Gate F dependency.** It blocks Gate G only and may be ruled any time before Gate G's lock. Options as recorded in the Gate E report: (i) contracts authoritative — workers emit envelopes; (ii) payloads authoritative — 32 contracts regenerated under the §18 workflow-version protocol; (iii) layered — envelope at `.12` step exits, deliverable schemas inside.
- Real provider execution: BLOCKED on credentials / selection (OD-A3, Raj's standing directive — bindings stay open and configurable after cloud deployment). Failure-injection uses simulated provider responses, labeled as such, per Master Prompt §18.
- Cloud deployment / G0: still blocked on G0.6 (OVHcloud host verification, founder-side). Gate F services run locally; no deployment claim is made.
- OD-A1 (create a Git repository for the factory trees vs manifest-pinned baselines): still open, untouched by this gate.

## PASS evidence required (per programme governance)

Execution log + source state + test evidence + regression of all prior gates, then independent verification (builder ≠ verifier) before Gate F is submitted for Raj's acceptance. T7 (recovery) is the headline test group: process crashes, expired leases, duplicate dispatch, stale callbacks, restart reconciliation.
