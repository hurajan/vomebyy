"""Lease reaper loop: a thin, report-preserving wrapper over the
coordinator's existing reap_expired_leases semantics."""
from __future__ import annotations

import random

from .common import borrow_coordinator, utc_now


class ReaperService:
    actor = "reaper-service"

    def __init__(self, coordinator_factory=None, *, dsn=None,
                 environment="test", now_fn=None, rng=None):
        self.coordinator_factory = coordinator_factory
        self.dsn = dsn
        self.environment = environment
        self.now_fn = now_fn or utc_now
        self.rng = rng or random.Random()

    def run_once(self) -> dict:
        with borrow_coordinator(
                self.coordinator_factory, dsn=self.dsn, actor=self.actor,
                environment=self.environment) as coord:
            moved = coord.reap_expired_leases()
        verbatim = [(str(unit_id), state) for unit_id, state in moved]
        return {"reaped": verbatim, "moved": verbatim, "count": len(verbatim)}


def run_once(**kwargs) -> dict:
    return ReaperService(**kwargs).run_once()
