"""Scheduler service: claim READY units through Coordinator.scheduler_claim.

The coordinator's scheduler remains the claiming machinery.  This service
adds the Gate F concerns around it:

* resolve every candidate's binding and derive its lane from modality;
* gate ``scheduler_claim``'s estimate callback so a candidate whose
  *derived* lane is already at capacity (including AWAITING_PROVIDER) is
  not claimed merely because its historically recorded lane had room;
* distinguish no-config skips from lane-full and cycle-limit skips; and
* return claim records enriched with production, derived lane and the
  reservation estimate actually used.
"""
from __future__ import annotations

import random
from datetime import datetime

from .common import borrow_coordinator, plain, utc_now
from .lanes import capacity_limits, in_flight_counts, lane_for


class SchedulerService:
    actor = "scheduler-service"

    def __init__(self, coordinator_factory=None, *, dsn=None,
                 environment="test", now_fn=None, rng=None):
        self.coordinator_factory = coordinator_factory
        self.dsn = dsn
        self.environment = environment
        self.now_fn = now_fn or utc_now
        self.rng = rng or random.Random()

    def run_once(self, limit: int | None = None) -> dict:
        with borrow_coordinator(
                self.coordinator_factory, dsn=self.dsn, actor=self.actor,
                environment=self.environment) as coord:
            cur = coord.conn.cursor()
            cur.execute(
                "SELECT * FROM execution_units WHERE state='READY'"
                " ORDER BY created_at, unit_id")
            ready_before = {str(r["unit_id"]): dict(r) for r in cur.fetchall()}
            coord.conn.commit()

            no_config: set[str] = set()
            lane_full: set[str] = set()
            limit_reached: set[str] = set()
            approved = 0

            def estimate_for(unit_id: str):
                nonlocal approved
                unit_id = str(unit_id)
                if limit is not None and approved >= int(limit):
                    limit_reached.add(unit_id)
                    return None
                binding = coord.resolve_config_for_unit(unit_id)
                # Resolution is a read; claim() will flush/commit it.  End
                # the snapshot here so capacity sees the previous claim.
                coord.conn.commit()
                unit = ready_before.get(unit_id) or coord.get_unit(unit_id)
                if binding is None or binding.get("est_cost_cents") is None:
                    no_config.add(unit_id)
                    return None
                lane = lane_for(unit, binding)
                ccur = coord.conn.cursor()
                counts = in_flight_counts(ccur)
                caps = capacity_limits(ccur)
                coord.conn.commit()
                if counts.get(lane, 0) >= caps.get(lane, 0):
                    lane_full.add(unit_id)
                    return None
                approved += 1
                return int(binding["est_cost_cents"])

            claimed_raw = coord.scheduler_claim(estimate_for=estimate_for)
            claimed_ids = [str(c["unit_id"]) for c in claimed_raw]

            # scheduler_claim only calls estimate_for for candidates that
            # pass its recorded-lane pre-check.  Classify still-READY units
            # it skipped before the callback as lane-full when their
            # derived lane is in fact saturated.
            cur = coord.conn.cursor()
            cur.execute(
                "SELECT * FROM execution_units WHERE state='READY'"
                " ORDER BY created_at, unit_id")
            ready_after = {str(r["unit_id"]): dict(r) for r in cur.fetchall()}
            coord.conn.commit()
            counts_after = None
            caps_after = None
            for unit_id, unit in ready_after.items():
                if unit_id in no_config or unit_id in lane_full or unit_id in limit_reached:
                    continue
                binding = coord.resolve_config_for_unit(unit_id)
                coord.conn.commit()
                if binding is None or binding.get("est_cost_cents") is None:
                    no_config.add(unit_id)
                    continue
                if counts_after is None:
                    ccur = coord.conn.cursor()
                    counts_after = in_flight_counts(ccur)
                    caps_after = capacity_limits(ccur)
                    coord.conn.commit()
                lane = lane_for(unit, binding)
                if counts_after.get(lane, 0) >= caps_after.get(lane, 0):
                    lane_full.add(unit_id)

            claimed = []
            cur = coord.conn.cursor()
            for result in claimed_raw:
                unit_id = str(result["unit_id"])
                unit = coord.get_unit(unit_id)
                cur.execute(
                    "SELECT a.resolved_config, b.estimated_cents"
                    " FROM action_attempts a"
                    " JOIN budget_reservations b"
                    "   ON b.reservation_id = a.reservation_id"
                    " WHERE a.attempt_id = %s",
                    (result["attempt_id"],))
                row = cur.fetchone() or {}
                binding = row.get("resolved_config") or {}
                claimed.append({
                    "unit_id": unit_id,
                    "production_id": str(unit["production_id"]),
                    "operation_id": unit["operation_id"],
                    "lane": lane_for(unit, binding),
                    "recorded_lane": unit["lane"],
                    "estimate": row.get("estimated_cents"),
                    "attempt_no": result["attempt_no"],
                    "attempt_id": str(result["attempt_id"]),
                })
            coord.conn.commit()

            skipped_no_config = [
                uid for uid in coord.last_scheduler_report.get("skipped_no_config", [])
                if str(uid) in no_config]
            # If the coordinator saw a candidate our callback classified
            # in another bucket, do not leak it into no-config.
            for uid in no_config:
                if uid not in skipped_no_config and uid in ready_before:
                    skipped_no_config.append(uid)

            return {
                "claimed": claimed,
                "claimed_unit_ids": claimed_ids,
                "skipped_no_config": sorted(skipped_no_config),
                "skipped_lane_full": sorted(lane_full),
                "skipped_limit": sorted(limit_reached),
                "ready_before": len(ready_before),
                "ready_after": len(ready_after),
                "at": plain(self.now_fn()),
            }


def run_once(coordinator_factory=None, limit: int | None = None, **kwargs) -> dict:
    """Functional entry point used by the runner and tests."""
    return SchedulerService(coordinator_factory, **kwargs).run_once(limit=limit)
