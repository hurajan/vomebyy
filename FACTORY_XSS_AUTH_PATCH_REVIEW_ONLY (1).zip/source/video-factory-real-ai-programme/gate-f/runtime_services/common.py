"""Shared plumbing for the Gate F runtime services.

The services are deliberately stateless: every cycle opens (or borrows) a
coordinator connection, asks the coordinator/its tables for the current
facts, performs one bounded unit of work, and returns a plain report.
"""
from __future__ import annotations

import os
import sys
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path

G2 = Path.home() / "workspace/video-factory-g2"
G2_COORDINATOR = G2 / "coordinator"
if str(G2_COORDINATOR) not in sys.path:
    sys.path.insert(0, str(G2_COORDINATOR))

from coordinator import Coordinator  # noqa: E402

DEFAULT_DSN = (
    "host=127.0.0.1 dbname=g2_coordinator_scratch "
    "user=factory password=factory_dev_local"
)


def dsn_from_env(dsn: str | None = None) -> str:
    return dsn or os.environ.get("FACTORY_DSN") or DEFAULT_DSN


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


def ensure_aware(value: datetime | None) -> datetime | None:
    if value is None:
        return None
    if value.tzinfo is None:
        return value.replace(tzinfo=timezone.utc)
    return value.astimezone(timezone.utc)


def _call_factory(factory, dsn: str, actor: str):
    """Call a coordinator factory in the shapes callers naturally use.

    Supported: ``factory()``, ``factory(dsn)``, ``factory(dsn, actor=...)``
    and the Coordinator class itself.  A pre-built Coordinator instance is
    also accepted by :func:`borrow_coordinator`.
    """
    try:
        return factory()
    except TypeError:
        pass
    try:
        return factory(dsn)
    except TypeError:
        return factory(dsn, actor=actor)


@contextmanager
def borrow_coordinator(factory=None, *, dsn: str | None = None,
                       actor: str = "runtime-service", environment: str = "test"):
    """Yield a Coordinator, closing it only when this call created it.

    A caller-supplied instance remains owned by the caller (important for
    tests and for a runner that intentionally shares one connection).  A
    factory-created/default coordinator is closed at the end of the cycle.
    """
    if isinstance(factory, Coordinator):
        yield factory
        return
    resolved_dsn = dsn_from_env(dsn)
    if factory is None:
        coord = Coordinator(resolved_dsn, actor=actor, environment=environment)
    else:
        coord = _call_factory(factory, resolved_dsn, actor)
    try:
        yield coord
    finally:
        coord.close()


def plain(value):
    """Best-effort conversion of DB values to JSON/report-friendly data."""
    if isinstance(value, dict):
        return {str(k): plain(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [plain(v) for v in value]
    if isinstance(value, datetime):
        return ensure_aware(value).isoformat()
    return str(value) if value is not None and not isinstance(
        value, (str, int, float, bool)) else value
