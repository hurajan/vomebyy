#!/usr/bin/env python3
"""Thin multi-interval runner for the Gate F runtime services.

All behavior lives in each service's ``run_once``.  This process owns no
state: intervals are scheduling details, every fact is read from and
written to coordinator-owned tables by the services themselves, and a
restart simply resumes from those tables.
"""
from __future__ import annotations

import json
import os
import signal
import sys
import time
from pathlib import Path

if __package__ in (None, ""):
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
    from runtime_services.dispatcher_service import DispatcherService
    from runtime_services.reaper_service import ReaperService
    from runtime_services.reconciler_service import ReconcilerService
    from runtime_services.retry_driver import RetryDriver
    from runtime_services.scheduler_service import SchedulerService
else:
    from .dispatcher_service import DispatcherService
    from .reaper_service import ReaperService
    from .reconciler_service import ReconcilerService
    from .retry_driver import RetryDriver
    from .scheduler_service import SchedulerService


def _interval(name: str, default: float) -> float:
    return float(os.environ.get(name, default))


def main() -> int:
    stopping = False

    def handle_signal(signum, frame):  # noqa: ARG001
        nonlocal stopping
        stopping = True

    signal.signal(signal.SIGTERM, handle_signal)
    signal.signal(signal.SIGINT, handle_signal)

    services = [
        ("scheduler", SchedulerService(), _interval("FACTORY_SCHEDULER_INTERVAL_S", 5)),
        ("dispatcher", DispatcherService(), _interval("FACTORY_DISPATCHER_INTERVAL_S", 2)),
        ("reaper", ReaperService(), _interval("FACTORY_REAPER_INTERVAL_S", 10)),
        ("retry", RetryDriver(), _interval("FACTORY_RETRY_INTERVAL_S", 5)),
        ("reconciler", ReconcilerService(), _interval("FACTORY_RECONCILER_INTERVAL_S", 15)),
    ]
    next_due = {name: 0.0 for name, _, _ in services}

    while not stopping:
        now = time.monotonic()
        for name, service, interval in services:
            if stopping:
                break
            if now < next_due[name]:
                continue
            try:
                report = service.run_once()
                print(json.dumps({"service": name, "report": report},
                                  default=str), flush=True)
            except Exception as exc:  # noqa: BLE001 - keep other loops alive
                print(json.dumps({
                    "service": name,
                    "error": f"{type(exc).__name__}: {exc}",
                }), flush=True)
            next_due[name] = time.monotonic() + interval
        time.sleep(0.1)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
