"""Reconciler loop over Coordinator.reconcile_once.

In the test environment the poll object is the coordinator tree's
MockProvider.  Gate C's reconciler only polls attempt-linked jobs; legacy
unlinked rows are counted and left untouched.  An unregistered mock job
polls as ``not_found``—the mock's honest answer—not as a fabricated state.
"""
from __future__ import annotations

import random
import sys
from pathlib import Path

from .common import borrow_coordinator, utc_now

G2_COORDINATOR = Path.home() / "workspace/video-factory-g2/coordinator"
if str(G2_COORDINATOR) not in sys.path:
    sys.path.insert(0, str(G2_COORDINATOR))

from mock_provider import MockProvider  # noqa: E402


class ReconcilerService:
    actor = "reconciler-service"

    def __init__(self, coordinator_factory=None, *, dsn=None,
                 environment="test", now_fn=None, rng=None, provider=None,
                 unresolved_threshold_s=3600):
        self.coordinator_factory = coordinator_factory
        self.dsn = dsn
        self.environment = environment
        self.now_fn = now_fn or utc_now
        self.rng = rng or random.Random()
        self.provider = provider
        # MM-08: unresolved (missing-usage) charges older than this are
        # surfaced in the cycle output. Detection surface only.
        self.unresolved_threshold_s = unresolved_threshold_s

    def run_once(self, provider=None) -> dict:
        poller = provider or self.provider or MockProvider()
        with borrow_coordinator(
                self.coordinator_factory, dsn=self.dsn, actor=self.actor,
                environment=self.environment) as coord:
            outcomes = coord.reconcile_once(
                poller, unresolved_threshold_s=self.unresolved_threshold_s)
            report = getattr(coord, "last_reconcile_report", {})
            legacy = int(report.get("legacy_unlinked", 0))
            unresolved = report.get("unresolved_charges", [])
        normalized = [(str(job_id), str(outcome)) for job_id, outcome in outcomes]
        actionable = [o for _, o in normalized if o != "legacy_unlinked"]
        return {
            "polled": len(actionable),
            "completed": sum(o == "completed" for o in actionable),
            "failed": sum(o in {"failed", "not_found", "stale_fencing",
                                "stale_input"} for o in actionable),
            "unknown": sum(o in {"processing", "unknown"} for o in actionable),
            "legacy_unlinked": legacy,
            "unresolved_charges": unresolved,
            "unresolved_charge_count": len(unresolved),
            "outcomes": normalized,
        }


def run_once(provider=None, **kwargs) -> dict:
    return ReconcilerService(**kwargs).run_once(provider=provider)
