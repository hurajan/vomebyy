"""Lane derivation and in-flight accounting.

The authoritative capacity table in the current coordinator schema calls
its limit column ``max_concurrency`` (not ``max_in_flight``).  Reports use
both names where useful so callers do not have to guess which schema
vintage produced a value.
"""
from __future__ import annotations

MODALITY_TO_LANE = {
    "text": "text",
    "speech": "voice",
    "image": "image",
    "video": "video",
    "render": "render-cpu",
    "transcription": "text",
}

IN_FLIGHT_STATES = ("CLAIMED", "RUNNING", "AWAITING_PROVIDER")


def lane_for(unit, resolved_binding=None) -> str:
    """Derive a unit's lane from a resolved binding's modality.

    Unmapped or absent modalities retain the unit's recorded lane, exactly
    as the Gate F lock specifies.
    """
    unit = unit or {}
    binding = resolved_binding or {}
    modality = binding.get("modality") if isinstance(binding, dict) else None
    if modality:
        mapped = MODALITY_TO_LANE.get(str(modality).strip().lower())
        if mapped:
            return mapped
    return str(unit.get("lane") or unit.get("recorded_lane") or "text")


def in_flight_counts(cur, states=IN_FLIGHT_STATES) -> dict[str, int]:
    """Count in-flight units by *derived* lane.

    A unit's current attempt snapshot supplies modality once it has been
    claimed.  Before/without a snapshot, its recorded lane is the honest
    fallback.  CLAIMED, RUNNING and AWAITING_PROVIDER all consume capacity.
    """
    cur.execute(
        "SELECT u.lane AS recorded_lane,"
        "       a.resolved_config->>'modality' AS modality"
        " FROM execution_units u"
        " LEFT JOIN action_attempts a"
        "   ON a.unit_id = u.unit_id AND a.attempt_no = u.current_attempt"
        " WHERE u.state = ANY(%s)",
        (list(states),))
    counts: dict[str, int] = {}
    for row in cur.fetchall():
        lane = lane_for(row, {"modality": row.get("modality")})
        counts[lane] = counts.get(lane, 0) + 1
    return counts


def capacity_limits(cur) -> dict[str, int]:
    """Enabled lane capacities from capacity_policies.max_concurrency."""
    cur.execute(
        "SELECT lane, max_concurrency FROM capacity_policies WHERE enabled")
    return {row["lane"]: int(row["max_concurrency"]) for row in cur.fetchall()}


# Descriptive alias matching the language of the Gate F brief.
def capacity_max_in_flight(cur) -> dict[str, int]:
    return capacity_limits(cur)
