"""Gate F runtime-services tests against a chain-built scratch DB.

Every test class rebuilds its own coordinator database through the G2
setup chain (which now includes migration 013).  HTTP dispatch is tested
against an in-process stub receiver that deduplicates by idempotency key,
exactly as a real consumer is required to do.
"""
import json
import os
import subprocess
import sys
import threading
import unittest
import urllib.request
from collections import Counter
from datetime import datetime, timedelta, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

import psycopg
from psycopg.rows import dict_row

HERE = Path(__file__).resolve()
GATE_F = HERE.parents[2]
G2 = Path.home() / "workspace/video-factory-g2"
sys.path.insert(0, str(GATE_F))
sys.path.insert(0, str(G2 / "coordinator"))

from coordinator import Coordinator  # noqa: E402
from mock_provider import MockProvider  # noqa: E402
from runtime_services.dispatcher_service import DispatcherService  # noqa: E402
from runtime_services.lanes import in_flight_counts  # noqa: E402
from runtime_services.reaper_service import ReaperService  # noqa: E402
from runtime_services.reconciler_service import ReconcilerService  # noqa: E402
from runtime_services.retry_driver import RetryDriver  # noqa: E402
from runtime_services.scheduler_service import SchedulerService  # noqa: E402

DB = os.environ.get("GATEF_TEST_DB", "gatef_runtime_scratch")
DSN = f"host=127.0.0.1 dbname={DB} user=factory password=factory_dev_local"
G2_PY = str(G2 / ".venv" / "bin" / "python")


def raw():
    return psycopg.connect(DSN, row_factory=dict_row, autocommit=True)


def build_db():
    subprocess.run([G2_PY, str(G2 / "tools" / "setup_db.py"), DB],
                   check=True, capture_output=True)


class ZeroRng:
    """Deterministic jitter source: always the centre of the range."""

    @staticmethod
    def uniform(a, b):
        return 0.0


class Base(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        build_db()

    def setUp(self):
        self.c = Coordinator(DSN)
        self.pid = self.c.create_production(
            f"Gate F {self.__class__.__name__}", 1_000_000, 900_000, "tester")
        self.run = self.c.start_run(self.pid, "FULL", "tester")

    def tearDown(self):
        self.c.close()

    def plan(self, op="05.12", key="main", lane="text"):
        return self.c.plan_unit(self.pid, self.run, op, key, lane)

    def state(self, unit_id):
        return self.c.get_unit(unit_id)["state"]


class TestScheduler(Base):
    def test_lane_cap_and_in_flight_never_exceeds_it(self):
        with raw() as conn:
            conn.execute(
                "UPDATE capacity_policies SET max_concurrency=2 WHERE lane='text'")
        units = [self.plan("01.01", key=f"cap-{i}") for i in range(3)]
        service = SchedulerService(lambda: Coordinator(DSN, actor="scheduler-test"))
        report = service.run_once()
        claimed_ids = {c["unit_id"] for c in report["claimed"]}
        self.assertEqual(len(claimed_ids), 2)
        self.assertTrue(claimed_ids.issubset({str(u) for u in units}))
        remaining = [u for u in units if str(u) not in claimed_ids]
        self.assertEqual(len(remaining), 1)
        self.assertEqual(self.state(remaining[0]), "READY")
        self.assertIn(str(remaining[0]), report["skipped_lane_full"])
        with raw() as conn:
            counts = in_flight_counts(conn.cursor())
        self.assertEqual(counts.get("text"), 2)
        for claim in report["claimed"]:
            self.assertEqual(claim["lane"], "text")
            self.assertEqual(claim["estimate"], 100)

    def test_unresolvable_binding_is_skipped_never_claimed(self):
        u = self.plan("01.01", key="no-config")
        service = SchedulerService(
            lambda: Coordinator(DSN, actor="scheduler-test",
                                environment="production"),
            environment="production")
        report = service.run_once()
        self.assertEqual(report["claimed"], [])
        self.assertIn(str(u), report["skipped_no_config"])
        self.assertEqual(self.state(u), "READY")
        self.assertEqual(self.c.get_unit(u)["current_attempt"], 0)


class StubReceiver:
    def __init__(self):
        self.status = 200
        self.deliveries = Counter()
        self.payloads = {}
        outer = self

        class Handler(BaseHTTPRequestHandler):
            def do_POST(self):  # noqa: N802
                length = int(self.headers.get("Content-Length") or 0)
                payload = json.loads(self.rfile.read(length) or b"{}")
                if outer.status < 300:
                    key = payload["idempotency_key"]
                    outer.deliveries[key] += 1
                    outer.payloads[key] = payload
                body = b"{}"
                self.send_response(outer.status)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)

            def log_message(self, *args):
                pass

        self.server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        self.thread = threading.Thread(target=self.server.serve_forever,
                                       daemon=True)
        self.thread.start()
        self.url = f"http://127.0.0.1:{self.server.server_port}/dispatch"

    def close(self):
        self.server.shutdown()
        self.server.server_close()
        self.thread.join(timeout=5)


class TestDispatcher(Base):
    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        cls.stub = StubReceiver()

    @classmethod
    def tearDownClass(cls):
        cls.stub.close()

    def outbox(self, unit_id):
        with raw() as conn:
            return conn.execute(
                "SELECT * FROM outbox_events WHERE aggregate_id=%s"
                " AND event_type='dispatch'", (unit_id,)).fetchone()

    def test_dispatch_exactly_once_failure_retry_and_notification(self):
        service = DispatcherService(lambda: Coordinator(DSN, actor="dispatcher-test"))
        u1 = self.plan(key="dispatch-1")
        self.c.claim(u1, "w1", 100)
        event1 = self.outbox(u1)
        report = service.run_once(endpoint=self.stub.url)
        self.assertEqual(report["dispatched"], 1)
        key = event1["idempotency_key"]
        self.assertEqual(self.stub.deliveries[key], 1)
        self.assertEqual(self.stub.payloads[key]["unit_id"], str(u1))
        self.assertEqual(self.stub.payloads[key]["operation_id"], "05.12")
        with raw() as conn:
            handoff = conn.execute(
                "SELECT * FROM dispatch_handoffs WHERE outbox_event_id=%s",
                (event1["event_id"],)).fetchone()
            published = conn.execute(
                "SELECT published_at FROM outbox_events WHERE event_id=%s",
                (event1["event_id"],)).fetchone()["published_at"]
        self.assertIsNotNone(handoff)
        self.assertEqual(str(handoff["unit_id"]), str(u1))
        self.assertEqual(handoff["http_status"], 200)
        self.assertIsNotNone(published)

        report = service.run_once(endpoint=self.stub.url)
        self.assertEqual(report["dispatched"], 0)
        self.assertEqual(self.stub.deliveries[key], 1)

        u2 = self.plan("06.12", key="dispatch-2")
        self.c.claim(u2, "w1", 100)
        event2 = self.outbox(u2)
        self.stub.status = 500
        report = service.run_once(endpoint=self.stub.url)
        self.assertEqual(report["failed"], 1)
        self.assertIsNone(self.outbox(u2)["published_at"])
        self.stub.status = 200
        report = service.run_once(endpoint=self.stub.url)
        self.assertEqual(report["dispatched"], 1)
        self.assertIsNotNone(self.outbox(u2)["published_at"])
        self.assertEqual(event2["idempotency_key"],
                         self.stub.payloads[event2["idempotency_key"]]
                         ["idempotency_key"])

        deliveries_before = sum(self.stub.deliveries.values())
        with raw() as conn:
            conn.execute(
                "INSERT INTO outbox_events(aggregate_type, aggregate_id,"
                " event_type, payload, idempotency_key)"
                " VALUES ('production',%s,'notification',%s,%s)",
                (self.pid, json.dumps({"kind": "soft_ceiling_crossed"}),
                 f"gatef-notification-{self.pid}"))
        report = service.run_once(endpoint=self.stub.url)
        self.assertEqual(report["notifications_published"], 1)
        self.assertEqual(sum(self.stub.deliveries.values()), deliveries_before)
        with raw() as conn:
            row = conn.execute(
                "SELECT published_at FROM outbox_events"
                " WHERE idempotency_key=%s",
                (f"gatef-notification-{self.pid}",)).fetchone()
        self.assertIsNotNone(row["published_at"])


class TestReaper(Base):
    def test_expired_lease_parks_unit_and_retry_driver_consumes_it(self):
        u = self.plan(key="reap-1")
        self.c.claim(u, "w1", 100, lease_ttl_s=1)
        with raw() as conn:
            conn.execute(
                "UPDATE worker_leases SET expires_at=now() - interval '1 second'"
                " WHERE unit_id=%s", (u,))
        report = ReaperService(
            lambda: Coordinator(DSN, actor="reaper-test")).run_once()
        self.assertEqual(report["count"], 1)
        self.assertEqual(report["reaped"], [(str(u), "RETRY_WAIT")])
        self.assertEqual(self.state(u), "RETRY_WAIT")

        retry_report = RetryDriver(
            lambda: Coordinator(DSN, actor="retry-test"), rng=ZeroRng()
        ).run_once(now=datetime.now(timezone.utc) + timedelta(days=1))
        self.assertIn(str(u), [r["unit_id"] for r in retry_report["retried"]])
        self.assertEqual(self.state(u), "READY")


class TestRetryDriver(Base):
    # Each method gets a pristine DB: RETRY_WAIT is a global queue, and
    # leftover waiting candidates would otherwise couple the scenarios.
    def setUp(self):
        build_db()
        super().setUp()

    def fail_once(self, unit_id):
        claim = self.c.claim(unit_id, "w1", 100)
        self.c.event(unit_id, "transient_error")
        return claim

    def test_due_retries_and_not_yet_due_waits(self):
        due = self.plan(key="due")
        self.fail_once(due)
        waiting = self.plan("06.12", key="waiting")
        self.fail_once(waiting)
        with raw() as conn:
            failed_at = conn.execute(
                "SELECT created_at FROM audit_events WHERE unit_id=%s"
                " AND new_state='RETRY_WAIT' ORDER BY created_at DESC LIMIT 1",
                (due,)).fetchone()["created_at"]
            conn.execute(
                "UPDATE audit_events SET created_at=%s WHERE unit_id=%s"
                " AND new_state='RETRY_WAIT'",
                (failed_at - timedelta(minutes=10), due))
        driver = RetryDriver(lambda: Coordinator(DSN, actor="retry-test"),
                             rng=ZeroRng())
        report = driver.run_once(now=datetime.now(timezone.utc))
        self.assertIn(str(due), [r["unit_id"] for r in report["retried"]])
        self.assertEqual(self.state(due), "READY")
        waiting_entries = [w for w in report["waiting"]
                           if w["unit_id"] == str(waiting)]
        self.assertEqual(len(waiting_entries), 1)
        due_at = datetime.fromisoformat(waiting_entries[0]["due_at"])
        self.assertGreater(due_at, datetime.now(timezone.utc))
        self.assertEqual(self.state(waiting), "RETRY_WAIT")
        with raw() as conn:
            reservation = conn.execute(
                "SELECT b.state FROM budget_reservations b"
                " JOIN action_attempts a ON a.reservation_id=b.reservation_id"
                " WHERE a.unit_id=%s AND a.attempt_no=1", (due,)).fetchone()
        self.assertEqual(reservation["state"], "RELEASED")

    def test_attempt_cap_dead_letters_once(self):
        u = self.plan(key="cap")
        for cycle in range(3):
            self.fail_once(u)
            if cycle < 2:
                self.c.retry_unit(u)
        self.assertEqual(self.c.get_unit(u)["current_attempt"], 3)
        driver = RetryDriver(lambda: Coordinator(DSN, actor="retry-test"),
                             rng=ZeroRng())
        report = driver.run_once(now=datetime.now(timezone.utc))
        self.assertIn(str(u), [d["unit_id"] for d in report["dead_lettered"]])
        unit = self.c.get_unit(u)
        self.assertEqual(unit["state"], "BLOCKED")
        self.assertEqual(unit["block_reason"], "dead_letter:transient_error")
        with raw() as conn:
            audits = conn.execute(
                "SELECT count(*) AS n FROM audit_events WHERE unit_id=%s"
                " AND event_type='dead_lettered'", (u,)).fetchone()["n"]
            notices = conn.execute(
                "SELECT count(*) AS n FROM outbox_events WHERE event_type="
                "'notification' AND payload->>'unit_id'=%s", (str(u),)
            ).fetchone()["n"]
        self.assertEqual(audits, 1)
        self.assertEqual(notices, 1)
        driver.run_once(now=datetime.now(timezone.utc) + timedelta(days=1))
        with raw() as conn:
            audits = conn.execute(
                "SELECT count(*) AS n FROM audit_events WHERE unit_id=%s"
                " AND event_type='dead_lettered'", (u,)).fetchone()["n"]
        self.assertEqual(audits, 1)
        self.assertEqual(self.state(u), "BLOCKED")

    def test_non_retryable_provider_failure_code_dead_letters_immediately(self):
        u = self.plan("11.06", key="stale-input")
        claim = self.c.claim(u, "w1", 100)
        self.c.event(u, "start")
        job = self.c.submit_provider_job_v2(
            u, claim["attempt_id"], claim["fencing_token"], f"gatef-stale-{u}")
        with raw() as conn:
            conn.execute(
                "UPDATE provider_jobs SET status='FAILED', raw_response=%s"
                " WHERE job_id=%s",
                (json.dumps({"failure_code": "STALE_INPUT"}), job))
        self.c.event(u, "transient_error")
        report = RetryDriver(
            lambda: Coordinator(DSN, actor="retry-test"), rng=ZeroRng()
        ).run_once(now=datetime.now(timezone.utc))
        entry = [d for d in report["dead_lettered"] if d["unit_id"] == str(u)]
        self.assertEqual(len(entry), 1)
        self.assertEqual(entry[0]["error_class"], "stale_input")
        self.assertEqual(self.c.get_unit(u)["block_reason"],
                         "dead_letter:stale_input")

    def test_unknown_class_fails_closed_to_dead_letter(self):
        u = self.plan(key="unknown")
        with raw() as conn:
            conn.execute(
                "UPDATE execution_units SET state='RETRY_WAIT' WHERE unit_id=%s",
                (u,))
        report = RetryDriver(
            lambda: Coordinator(DSN, actor="retry-test"), rng=ZeroRng()
        ).run_once(now=datetime.now(timezone.utc))
        entry = [d for d in report["dead_lettered"] if d["unit_id"] == str(u)]
        self.assertEqual(len(entry), 1)
        self.assertEqual(entry[0]["error_class"], "unknown")
        self.assertEqual(self.state(u), "BLOCKED")


class TestReconciler(Base):
    def test_linked_job_completes_and_legacy_job_is_untouched(self):
        u = self.plan("11.06", key="reconcile-1")
        self.c.claim(u, "w1", 500)
        self.c.event(u, "start")
        job_id, _ = self.c.submit_provider_job(
            u, "mock", {"artifact_type": "media"}, f"gatef-reconcile-{u}")
        provider = MockProvider()
        pjob = provider.submit(
            {"artifact_type": "media", "data": b"vid", "cost_cents": 400},
            mode="complete")
        self.c.attach_provider_job_id(job_id, pjob)
        self.c.provider_timeout(u, job_id)
        self.assertEqual(self.state(u), "UNKNOWN")
        with raw() as conn:
            legacy = conn.execute(
                "INSERT INTO provider_jobs(unit_id, production_id, provider,"
                " provider_job_id, idempotency_key, request_payload, status,"
                " attempt_id) VALUES (%s,%s,'legacy','legacy-pjob',%s,'{}',"
                "'SUBMITTED',NULL) RETURNING job_id",
                (u, self.pid, f"gatef-legacy-{u}")).fetchone()["job_id"]
        report = ReconcilerService(
            lambda: Coordinator(DSN, actor="reconciler-test")).run_once(provider)
        self.assertEqual(report["completed"], 1)
        self.assertEqual(report["legacy_unlinked"], 1)
        self.assertEqual(self.state(u), "VALIDATING")
        with raw() as conn:
            status = conn.execute(
                "SELECT status FROM provider_jobs WHERE job_id=%s",
                (legacy,)).fetchone()["status"]
        self.assertEqual(status, "SUBMITTED")


class TestRestartRecovery(Base):
    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        cls.stub = StubReceiver()

    @classmethod
    def tearDownClass(cls):
        cls.stub.close()

    def test_fresh_services_recover_exactly_once(self):
        a = self.plan("01.01", key="restart-a")
        b = self.plan("02.12", key="restart-b")
        cunit = self.plan("03.12", key="restart-c")

        scheduler = SchedulerService(lambda: Coordinator(DSN, actor="scheduler-test"))
        report = scheduler.run_once(limit=1)
        self.assertEqual([c["unit_id"] for c in report["claimed"]], [str(a)])

        self.c.claim(b, "w-b", 100)
        with raw() as conn:
            conn.execute(
                "UPDATE worker_leases SET expires_at=now() - interval '1 second'"
                " WHERE unit_id=%s", (b,))
        self.c.claim(cunit, "w-c", 100)
        self.c.event(cunit, "transient_error")
        with raw() as conn:
            conn.execute(
                "UPDATE audit_events SET created_at=now() - interval '120 seconds'"
                " WHERE unit_id=%s AND new_state='RETRY_WAIT'", (cunit,))
            a_key = conn.execute(
                "SELECT idempotency_key FROM outbox_events WHERE aggregate_id=%s"
                " AND event_type='dispatch'", (a,)).fetchone()["idempotency_key"]
            a_attempts = conn.execute(
                "SELECT count(*) AS n FROM audit_events WHERE unit_id=%s"
                " AND event_type='claim'", (a,)).fetchone()["n"]
        self.assertEqual(a_attempts, 1)

        # "Crash": no dispatcher/reaper/retry cycle ran above.  Fresh
        # service objects now recover purely from coordinator state.
        dispatcher = DispatcherService(lambda: Coordinator(DSN, actor="dispatcher-test"))
        reaper = ReaperService(lambda: Coordinator(DSN, actor="reaper-test"))
        retry = RetryDriver(lambda: Coordinator(DSN, actor="retry-test"),
                            rng=ZeroRng())
        dispatcher.run_once(endpoint=self.stub.url)
        reaper.run_once()
        retry_report = retry.run_once(now=datetime.now(timezone.utc))

        self.assertEqual(self.stub.deliveries[a_key], 1)
        self.assertEqual(self.state(b), "RETRY_WAIT")
        self.assertIn(str(cunit),
                      [r["unit_id"] for r in retry_report["retried"]])
        self.assertEqual(self.state(cunit), "READY")

        counts_after_first = dict(self.stub.deliveries)
        dispatcher.run_once(endpoint=self.stub.url)
        reaper.run_once()
        retry.run_once(now=datetime.now(timezone.utc))
        self.assertEqual(dict(self.stub.deliveries), counts_after_first)
        self.assertEqual(self.stub.deliveries[a_key], 1)
        self.assertEqual(self.state(cunit), "READY")
        self.assertEqual(self.c.get_unit(a)["current_attempt"], 1)
        with raw() as conn:
            claim_audits = conn.execute(
                "SELECT count(*) AS n FROM audit_events WHERE unit_id=%s"
                " AND event_type='claim'", (a,)).fetchone()["n"]
            handoffs = conn.execute(
                "SELECT count(*) AS n FROM dispatch_handoffs h"
                " JOIN outbox_events o ON o.event_id=h.outbox_event_id"
                " WHERE o.idempotency_key=%s", (a_key,)).fetchone()["n"]
        self.assertEqual(claim_audits, 1)
        self.assertEqual(handoffs, 1)


if __name__ == "__main__":
    unittest.main(verbosity=2)
