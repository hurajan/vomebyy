"""Outbox dispatcher.

Delivery is at-least-once.  After a successful POST, the handoff record
(migration 013) and ``outbox_events.published_at`` are written in one
transaction.  A crash before that commit can produce a second POST after
restart; consumers therefore dedupe on the idempotency key carried in the
payload, and a pre-existing handoff row is reported as a suppressed
duplicate instead of being inserted twice.
"""
from __future__ import annotations

import json
import os
import random
import urllib.error
import urllib.request
from datetime import datetime

from .common import borrow_coordinator, utc_now


def _default_http_post(endpoint: str, payload: dict) -> int:
    data = json.dumps(payload).encode()
    req = urllib.request.Request(
        endpoint, data=data, method="POST",
        headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=15) as response:
            return int(response.status)
    except urllib.error.HTTPError as exc:
        return int(exc.code)


def _status_of(result) -> int:
    if result is None:
        return 200
    if isinstance(result, int):
        return result
    status = getattr(result, "status", None)
    if status is None:
        status = getattr(result, "status_code", None)
    if status is None and isinstance(result, dict):
        status = result.get("status", result.get("http_status", 200))
    return int(status)


class DispatcherService:
    actor = "dispatcher-service"

    def __init__(self, coordinator_factory=None, *, dsn=None,
                 environment="test", now_fn=None, rng=None):
        self.coordinator_factory = coordinator_factory
        self.dsn = dsn
        self.environment = environment
        self.now_fn = now_fn or utc_now
        self.rng = rng or random.Random()

    def run_once(self, http_post=None, endpoint: str | None = None,
                 limit: int | None = 100) -> dict:
        endpoint = endpoint or os.environ.get("FACTORY_DISPATCH_URL")
        poster = http_post or _default_http_post
        report = {"dispatched": 0, "duplicates_suppressed": 0,
                  "failed": 0, "notifications_published": 0}

        with borrow_coordinator(
                self.coordinator_factory, dsn=self.dsn, actor=self.actor,
                environment=self.environment) as coord:
            cur = coord.conn.cursor()
            sql = ("SELECT * FROM outbox_events WHERE published_at IS NULL"
                   " ORDER BY created_at, event_id")
            params = []
            if limit is not None:
                sql += " LIMIT %s"
                params.append(int(limit))
            cur.execute(sql, params)
            events = [dict(r) for r in cur.fetchall()]
            coord.conn.commit()

            for event in events:
                event_id = event["event_id"]
                if event["event_type"] == "notification":
                    with coord.conn.transaction():
                        ccur = coord.conn.cursor()
                        ccur.execute(
                            "UPDATE outbox_events SET published_at = now()"
                            " WHERE event_id=%s AND published_at IS NULL",
                            (event_id,))
                        report["notifications_published"] += int(ccur.rowcount == 1)
                    continue

                if event["event_type"] != "dispatch":
                    report["failed"] += 1
                    continue

                unit_id = event["aggregate_id"]
                cur = coord.conn.cursor()
                cur.execute(
                    "SELECT production_id, operation_id FROM execution_units"
                    " WHERE unit_id=%s", (unit_id,))
                unit = cur.fetchone()
                coord.conn.commit()
                if unit is None or not endpoint:
                    report["failed"] += 1
                    continue

                payload_in = event.get("payload") or {}
                payload = {
                    "idempotency_key": event["idempotency_key"],
                    "unit_id": str(unit_id),
                    "production_id": str(unit["production_id"]),
                    "operation_id": unit["operation_id"],
                    "attempt_no": payload_in.get("attempt_no"),
                }
                try:
                    status = _status_of(poster(endpoint, payload))
                except Exception:  # noqa: BLE001 - a failed POST is data here
                    report["failed"] += 1
                    continue
                if not (200 <= status < 300):
                    report["failed"] += 1
                    continue

                handed_off_at = self.now_fn()
                with coord.conn.transaction():
                    ccur = coord.conn.cursor()
                    ccur.execute(
                        "INSERT INTO dispatch_handoffs("
                        " outbox_event_id, unit_id, endpoint, http_status,"
                        " handed_off_at) VALUES (%s,%s,%s,%s,%s)"
                        " ON CONFLICT (outbox_event_id) DO NOTHING"
                        " RETURNING handoff_id",
                        (event_id, unit_id, endpoint, status, handed_off_at))
                    inserted = ccur.fetchone() is not None
                    ccur.execute(
                        "UPDATE outbox_events SET published_at = now()"
                        " WHERE event_id=%s AND published_at IS NULL",
                        (event_id,))
                if inserted:
                    report["dispatched"] += 1
                else:
                    report["duplicates_suppressed"] += 1
        return report


def run_once(http_post=None, endpoint: str | None = None,
             limit: int | None = 100, **kwargs) -> dict:
    return DispatcherService(**kwargs).run_once(
        http_post=http_post, endpoint=endpoint, limit=limit)
