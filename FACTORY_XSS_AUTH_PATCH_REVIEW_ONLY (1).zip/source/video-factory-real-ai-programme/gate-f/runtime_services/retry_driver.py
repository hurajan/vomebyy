"""Bounded retry driver and dead-lettering for RETRY_WAIT units.

Classification is intentionally small and fail-closed.  The observed
error class is taken, in order, from:

1. the latest provider job's ``raw_response`` (Gate C stores
   ``failure_code`` there; there is no failure_code column);
2. the current attempt's ``error_class``;
3. the audit event that parked the unit in RETRY_WAIT (its payload's
   error/failure class, its ``via`` marker—notably ``lease_reaper``—or
   the transition event name itself); and
4. ``unknown`` when none of those sources says anything usable.

Unknown is non-retryable.  Failure time comes from that parking audit
event because a RETRY_WAIT unit's current attempt deliberately remains
RUNNING (finished_at is only written when retry_unit closes it).
"""
from __future__ import annotations

import json
import random
import re
from datetime import datetime, timedelta, timezone

from .common import borrow_coordinator, ensure_aware, utc_now

RETRYABLE_CLASSES = {
    "transient_error",
    "worker_error",
    "timeout",
    "timed_out",
    "provider_timeout",
    "rate_limited",
    "rate_limit",
    "provider_error",
    "provider_5xx",
    "http_5xx",
    "5xx",
    "stale_fencing",
    "lease_expired",
}

NON_RETRYABLE_CLASSES = {
    "stale_input",
    "validation",
    "validation_error",
    "validation_failed",
    "content",
    "content_error",
    "config",
    "configuration",
    "configuration_missing",
    "hash",
    "hash_mismatch",
    "artifact_hash_mismatch",
    "gate",
    "gate_refusal",
    "gate_not_satisfied",
    "budget_exceeded",
    "unauthorized_transition",
    "unknown",
}

_NON_RETRYABLE_TOKENS = (
    "validation", "content", "config", "hash", "gate", "budget",
    "stale_input", "permission", "unauthorized",
)

_ALIASES = {
    "worker": "worker_error",
    "provider": "provider_error",
    "provider_failure": "provider_error",
    "http_500": "provider_5xx",
    "http_502": "provider_5xx",
    "http_503": "provider_5xx",
    "http_504": "provider_5xx",
    "server_error": "provider_5xx",
    "lease_reaper": "lease_expired",
    "expired_lease": "lease_expired",
}


def normalize_error_class(value) -> str:
    if value is None:
        return "unknown"
    key = str(value).strip().lower().replace("-", "_").replace(" ", "_")
    key = re.sub(r"[^a-z0-9_]", "_", key)
    key = re.sub(r"_+", "_", key).strip("_")
    if re.fullmatch(r"5\d\d", key) or re.fullmatch(r"http_5\d\d", key):
        return "provider_5xx"
    return _ALIASES.get(key, key or "unknown")


def classify_error_class(value) -> tuple[str, bool]:
    """Return (normalized class, retryable?).  Fail closed."""
    cls = normalize_error_class(value)
    if cls in RETRYABLE_CLASSES:
        return cls, True
    if cls in NON_RETRYABLE_CLASSES:
        return cls, False
    if any(token in cls for token in _NON_RETRYABLE_TOKENS):
        return cls, False
    return (cls if cls != "unknown" else "unknown"), False


def _policy_value(policy: dict, *names, default=None):
    for name in names:
        if policy.get(name) is not None:
            return policy[name]
    return default


class RetryDriver:
    actor = "retry-driver"

    # Data table exposed for tests/operators; classification behavior is
    # implemented by classify_error_class above.
    CLASSIFICATION = {
        "retryable": sorted(RETRYABLE_CLASSES),
        "non_retryable": sorted(NON_RETRYABLE_CLASSES),
        "unknown": "non_retryable",
    }

    def __init__(self, coordinator_factory=None, *, dsn=None,
                 environment="test", now_fn=None, rng=None):
        self.coordinator_factory = coordinator_factory
        self.dsn = dsn
        self.environment = environment
        self.now_fn = now_fn or utc_now
        self.rng = rng or random.Random()

    # ---------------------------------------------------------- extraction
    @staticmethod
    def _derive_class(attempt, job, audit) -> str:
        raw = (job or {}).get("raw_response") or {}
        if isinstance(raw, str):
            try:
                raw = json.loads(raw)
            except json.JSONDecodeError:
                raw = {}
        for source in (raw.get("failure_code"), raw.get("error_class"),
                       raw.get("class")):
            if source:
                return normalize_error_class(source)
        if attempt and attempt.get("error_class"):
            return normalize_error_class(attempt["error_class"])
        payload = (audit or {}).get("payload") or {}
        if isinstance(payload, str):
            try:
                payload = json.loads(payload)
            except json.JSONDecodeError:
                payload = {}
        for source in (payload.get("error_class"), payload.get("failure_code"),
                       payload.get("class"), payload.get("reason")):
            if source:
                return normalize_error_class(source)
        if payload.get("via") == "lease_reaper":
            return "lease_expired"
        if audit and audit.get("event_type"):
            return normalize_error_class(audit["event_type"])
        return "unknown"

    def _candidates(self, coord):
        cur = coord.conn.cursor()
        cur.execute(
            "SELECT u.*, od.resource_ceiling"
            " FROM execution_units u"
            " JOIN operation_definitions od"
            "   ON od.workflow_version = u.workflow_version_ref"
            "  AND od.operation_id = u.operation_id"
            " WHERE u.state = 'RETRY_WAIT'"
            " ORDER BY u.created_at, u.unit_id")
        units = [dict(r) for r in cur.fetchall()]
        detailed = []
        for unit in units:
            cur.execute(
                "SELECT * FROM action_attempts WHERE unit_id=%s"
                " ORDER BY attempt_no DESC LIMIT 1", (unit["unit_id"],))
            attempt = cur.fetchone()
            job = None
            if attempt:
                cur.execute(
                    "SELECT * FROM provider_jobs WHERE unit_id=%s"
                    " AND attempt_id=%s"
                    " ORDER BY submitted_at DESC, job_id DESC LIMIT 1",
                    (unit["unit_id"], attempt["attempt_id"]))
                job = cur.fetchone()
            if job is None:
                # Fall back to the latest job for the unit only when the
                # current attempt has no linked job (legacy submissions).
                cur.execute(
                    "SELECT * FROM provider_jobs WHERE unit_id=%s"
                    " ORDER BY submitted_at DESC, job_id DESC LIMIT 1",
                    (unit["unit_id"],))
                job = cur.fetchone()
            cur.execute(
                "SELECT * FROM audit_events WHERE unit_id=%s"
                " AND new_state='RETRY_WAIT' ORDER BY created_at DESC, log_id DESC"
                " LIMIT 1", (unit["unit_id"],))
            audit = cur.fetchone()
            detailed.append((unit, attempt, job, audit))
        coord.conn.commit()
        return detailed

    # ------------------------------------------------------------- policy
    def _timing(self, unit, attempt, audit):
        snapshot = (attempt or {}).get("resolved_config") or {}
        if isinstance(snapshot, str):
            snapshot = json.loads(snapshot)
        policy = snapshot.get("retry_policy") or {}
        if isinstance(policy, str):
            policy = json.loads(policy)

        ceiling = unit.get("resource_ceiling") or {}
        default_cap = int(ceiling.get("max_attempts") or 3)
        cap = int(_policy_value(policy, "max_attempts", default=default_cap))
        base = float(_policy_value(
            policy, "base_seconds", "base_s", "base", "backoff_base_seconds",
            default=30.0))
        cap_seconds = float(_policy_value(
            policy, "cap_seconds", "max_backoff_seconds", "backoff_cap_seconds",
            default=900.0))
        jitter_raw = _policy_value(
            policy, "jitter_pct", "jitter_percent", "jitter_fraction",
            "jitter", default=20.0)
        jitter = float(jitter_raw)
        # A value above 1 is naturally a percentage (the lock's ±20%).
        jitter_fraction = jitter / 100.0 if jitter > 1 else jitter
        jitter_fraction = max(0.0, min(1.0, jitter_fraction))

        attempt_no = int(unit.get("current_attempt") or
                         (attempt or {}).get("attempt_no") or 0)
        failed_at = None
        if audit and audit.get("created_at"):
            failed_at = ensure_aware(audit["created_at"])
        elif attempt and attempt.get("finished_at"):
            failed_at = ensure_aware(attempt["finished_at"])
        elif attempt and attempt.get("started_at"):
            failed_at = ensure_aware(attempt["started_at"])
        else:
            failed_at = ensure_aware(unit["created_at"])

        exponent = max(0, attempt_no - 1)
        raw_delay = base * (2 ** exponent)
        jitter_factor = self.rng.uniform(
            -jitter_fraction, jitter_fraction) if jitter_fraction else 0.0
        delay = max(0.0, min(cap_seconds, raw_delay * (1.0 + jitter_factor)))
        return {
            "attempt_no": attempt_no,
            "attempt_cap": cap,
            "failed_at": failed_at,
            "due_at": failed_at + timedelta(seconds=delay),
            "delay_seconds": delay,
            "policy": policy,
        }

    # --------------------------------------------------------- dead letter
    def _dead_letter(self, coord, unit, cls: str, attempt_no: int) -> None:
        reason = f"dead_letter:{cls}"
        coord.event(
            str(unit["unit_id"]), "block",
            payload={"error_class": cls, "attempts": attempt_no,
                     "via": "retry_driver"},
            block_reason=reason)
        payload = {"kind": "dead_letter", "unit_id": str(unit["unit_id"]),
                   "error_class": cls, "attempts": attempt_no,
                   "block_reason": reason}
        with coord.conn.transaction():
            cur = coord.conn.cursor()
            cur.execute(
                "INSERT INTO audit_events(production_id, unit_id, event_type,"
                " old_state, new_state, actor, payload)"
                " VALUES (%s,%s,'dead_lettered','RETRY_WAIT','BLOCKED',%s,%s)",
                (unit["production_id"], unit["unit_id"], self.actor,
                 json.dumps(payload)))
            cur.execute(
                "INSERT INTO outbox_events(aggregate_type, aggregate_id,"
                " event_type, payload, idempotency_key)"
                " VALUES ('production',%s,'notification',%s,%s)"
                " ON CONFLICT (idempotency_key) DO NOTHING",
                (unit["production_id"], json.dumps(payload),
                 f"dead-letter:{unit['unit_id']}:{attempt_no}:{cls}"))

    # -------------------------------------------------------------- cycle
    def run_once(self, now: datetime | None = None) -> dict:
        now = ensure_aware(now or self.now_fn())
        report = {"retried": [], "dead_lettered": [], "waiting": [],
                  "errors": []}
        with borrow_coordinator(
                self.coordinator_factory, dsn=self.dsn, actor=self.actor,
                environment=self.environment) as coord:
            for unit, attempt, job, audit in self._candidates(coord):
                unit_id = str(unit["unit_id"])
                try:
                    cls, retryable = classify_error_class(
                        self._derive_class(attempt, job, audit))
                    timing = self._timing(unit, attempt, audit)
                    attempt_no = timing["attempt_no"]
                    if (not retryable) or attempt_no >= timing["attempt_cap"]:
                        self._dead_letter(coord, unit, cls, attempt_no)
                        report["dead_lettered"].append({
                            "unit_id": unit_id, "error_class": cls,
                            "attempts": attempt_no,
                            "attempt_cap": timing["attempt_cap"],
                            "block_reason": f"dead_letter:{cls}",
                        })
                    elif now >= timing["due_at"]:
                        coord.retry_unit(unit_id)
                        report["retried"].append({
                            "unit_id": unit_id, "error_class": cls,
                            "attempts": attempt_no,
                            "due_at": timing["due_at"].isoformat(),
                        })
                    else:
                        report["waiting"].append({
                            "unit_id": unit_id, "error_class": cls,
                            "attempts": attempt_no,
                            "due_at": timing["due_at"].isoformat(),
                        })
                except Exception as exc:  # noqa: BLE001 - report, don't hide
                    report["errors"].append({
                        "unit_id": unit_id,
                        "error": f"{type(exc).__name__}: {exc}",
                    })
        return report


# Descriptive alias: this module is the retry driver, not a generic service.
RetryService = RetryDriver


def run_once(now: datetime | None = None, **kwargs) -> dict:
    return RetryDriver(**kwargs).run_once(now=now)
