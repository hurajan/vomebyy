# GATE F VERIFIER REPORT — independent verification

**Verdict: VERIFIED — all items CONFIRMED. Defects: NONE (no CRITICAL, MAJOR, or MINOR).**
Method: full suite logs read from disk; coordinator diff inspected directly; all runtime behaviors probed with my own fixtures on my own chain-built scratch DB (`gatef_verify_scratch`, dropped after); runner exercised as a real subprocess. No product code was modified.

## Item 1 — Suite logs: CONFIRMED

Full logs in `gate-f/evidence/logs/` read directly: G1 9 OK, G2 58 OK, G3 20 OK, G4 2 OK, G5 1 OK, G6 3 OK, G7 2 OK, G8 1 OK, G9 9 OK, worker_service 11 OK, storage_service 5 OK, evaluation_service 21 OK, runtime_services 10 OK — **152 tests, all OK**, exactly the builder's claim.

## Item 2 — Coordinator diff discipline: CONFIRMED

- `TRANSITIONS` in `g2/coordinator/coordinator.py` now holds exactly **30** entries: the Gate A 28 (GA-02), plus Gate C's `(AWAITING_PROVIDER, transient_error) → RETRY_WAIT` (commented in code as such), plus exactly one Gate F addition: `(RETRY_WAIT, block) → BLOCKED` (commented "Gate F: the retry driver's terminal dead-letter transition"). No other transition added, removed, or retargeted.
- `event()` signature is `(unit_id, event, payload=None, block_reason=None)` — the only change is the trailing optional parameter; `_transition`/`_set_state` thread it through to the pre-existing `execution_units.block_reason` column. All existing call sites pass no `block_reason` (one pre-existing internal use at the budget path, `PRODUCTION_BUDGET_EXCEEDED`, predates Gate F). The G2 suite (58/58) passing is supporting evidence of no behavioral break.
- Migration `013_dispatch_handoffs.sql` is additive only: one `CREATE TABLE IF NOT EXISTS` (with `outbox_event_id UNIQUE`, matching the lock) + one index. No ALTER/DROP of anything existing.
- `CHANGED_ASSERTIONS.md` is accurate: no pre-existing assertions changed; the three additive changes it records are exactly the ones found.

## Item 3 — Own probes (fresh fixtures, scratch DB): CONFIRMED (a–f)

**(a) Scheduler cap.** Schema fact first: the capacity column is `max_concurrency` (migration 002), not the lock text's `max_in_flight` — `lanes.py` documents this discrepancy in its docstring; behavior matches the lock's intent. With `capacity_policies.max_concurrency = 1` for lane `text` and two READY units under the mock FACTORY binding: first `scheduler run_once` claimed exactly 1, at the config estimate **100** (not 0); second `run_once` claimed 0 while the first was in flight; end state one CLAIMED, one READY.

**(b) Dispatcher exactly-once.** My own stub HTTP receiver counting by `idempotency_key`: after (a)'s claim, one `run_once` → exactly 1 delivery, report `dispatched=1`, one `dispatch_handoffs` row, outbox event published. Second `run_once` → still 1 delivery, `dispatched=0`. A second claimed unit with the stub forced to 500 → report `failed=1`, event left unpublished, no handoff; stub healthy → delivered exactly once and published.

**(c) Retry driver — due, cap, dead-letter.** The driver's failure-time source is the parking `audit_events` row (`new_state='RETRY_WAIT'`), confirmed in `retry_driver.py` and used for backdating. A unit failed via `transient_error` with its parking audit backdated 10 minutes (default policy: base 30 s, zero-jitter RNG injected) → `run_once` retried it to READY, class `transient_error`. A unit driven to `current_attempt = 3` (the registry `max_attempts`) in RETRY_WAIT → `run_once` dead-lettered it: state BLOCKED, `block_reason = "dead_letter:transient_error"` (prefix `dead_letter:` ✓), exactly one `dead_lettered` audit row and one outbox `notification` row. A further `run_once` (clock +1 day) left it untouched — still BLOCKED, still exactly one `dead_lettered` audit.

**(d) Not-yet-due.** A freshly failed unit (no backdating) was reported in the same driver run's `waiting` list with a future `due_at`, and remained RETRY_WAIT.

**(e) Reaper.** Unit claimed with `lease_ttl_s=1`, `worker_leases.expires_at` backdated: reaper `run_once` moved it to **RETRY_WAIT** — exactly what `reap_expired_leases` does for a CLAIMED/RUNNING unit with no outstanding provider job (transient_error transition, `via: lease_reaper`). With its parking audit backdated, the retry driver then consumed it (derived class `lease_expired`, retryable) → READY. The reaper → RETRY_WAIT → driver chain has no orphaned state.

**(f) Restart idempotence.** Two-phase, reported honestly: the first fresh-services pass over the post-probe DB delivered six dispatch events that had been created by claims made *during* probes (c)/(e) and had never been dispatched before — every idempotency key's delivery count is exactly 1 (no key delivered twice), and the six new handoff rows correspond one-to-one to those first deliveries; the fresh retry driver in that pass retried nothing and dead-lettered nothing, the fresh scheduler claimed nothing (lane at cap), and all unit states were unchanged. I then re-ran all four fresh services against the now-settled DB: zero unpublished events beforehand, and afterwards **zero** deliveries, zero handoffs added (8→8), zero new claims (8→8 claim audits), zero new dead-letters (1→1), and byte-identical unit states. Restart recovery is exactly-once in effect.

## Item 4 — Runner smoke: CONFIRMED

`runner.py` launched as a subprocess (g2 venv python, cwd = gate tree) against the scratch DB with `FACTORY_DISPATCH_URL` pointing at my stub and all five intervals set to 1 s. After ~10 s, SIGTERM was sent to the PID: the process exited with code **0**; stdout contained 45 lines, all valid JSON, each a structured `{"service": ..., "report": ...}` cycle line covering all five services (scheduler, dispatcher, reaper, retry, reconciler), with zero error lines. (The scheduler lines correctly reported the two READY units as lane-full skips; the dispatcher/reaper lines were empty no-ops — consistent with the settled DB.)

## Item 5 — Scope discipline: CONFIRMED

- Direct state writes in the non-test package (grep for INSERT/UPDATE/DELETE) are exactly the sanctioned set: `dispatcher_service.py` — INSERT into `dispatch_handoffs` and UPDATE of `outbox_events.published_at`, both inside the single post-POST transaction (plus the notification-path publication UPDATE the lock specifies); `retry_driver.py` — the dead-letter INSERTs into `audit_events` (`dead_lettered`) and `outbox_events` (notification), alongside the coordinator `event(..., block_reason=...)` call. Scheduler, reaper, and reconciler services contain **no** direct writes — they act only through coordinator methods (`scheduler_claim`, `reap_expired_leases`, `reconcile_once`, `retry_unit`). `lanes.py`/`common.py` are read-only/plumbing.
- No n8n/dashboard changes: all five station `tools/gen_workflows.py` files carry mtime 21:12 UTC, predating the Gate F lock file (22:44 UTC); nothing in the station trees was touched in Gate F's window.
- Manual redispatch untouched: `Coordinator.retry_unit(self, unit_id)` signature is byte-for-byte the F-G9-03 original (single argument, no additions); the driver is additive automation on top of it, as the lock required.

## Notes (not defects)

1. My first (f) pass initially looked like duplicate dispatch; on inspection every delivered key had count 1 — those were first deliveries of events created mid-probe. The strict settled-state rerun (zero-change across all four services) is the operative idempotence evidence, recorded above.
2. The lock text names the capacity limit `max_in_flight`; the schema's column is `max_concurrency`. The services read the real column and document the naming gap. Behavior is as locked.
