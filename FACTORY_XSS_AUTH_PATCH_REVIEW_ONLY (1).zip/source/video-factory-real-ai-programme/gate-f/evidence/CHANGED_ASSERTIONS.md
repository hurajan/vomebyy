# Gate F changed assertions

No pre-existing test assertions were changed.

Coordinator code changes were additive and are recorded here because the
Gate F lock anticipated flagging any necessary change:

- Added the `RETRY_WAIT --block--> BLOCKED` transition used only for
  retry-driver dead-lettering.
- Extended `Coordinator.event()` and the internal transition helper with
  an optional `block_reason` argument. Existing calls, which do not pass
  it, retain their prior behavior apart from the pre-existing transition
  machinery's state/audit handling.
- Added migration 013 (`dispatch_handoffs`) and wired it into the G2
  scratch-database setup chain after migration 012.
