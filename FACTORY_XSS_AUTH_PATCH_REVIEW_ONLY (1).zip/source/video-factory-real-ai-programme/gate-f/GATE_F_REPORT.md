# GATE F REPORT — Scheduling, dispatch, and recovery services

**Status: GATE F COMPLETE + INDEPENDENTLY VERIFIED, defects NONE — ACCEPTED by Raj 2026-10-28, who RULED OD-E1 = (iii) LAYERED and CONFIRMED the Gate G lock (bundled options in the report).** Lock: LOCK_GATE_F.md (Gate E accepted + Gate F lock confirmed by Raj 2026-10-28). Evidence: suite logs in `evidence/logs/`, `evidence/CHANGED_ASSERTIONS.md`, verifier report `evidence/GATE_F_VERIFIER_REPORT.md`. No pre-existing test assertions were changed.

## Results

**Suites (152 total, all green):** runtime_services 10/10 (new) · G1 9/9 · G2 58/58 · G3 20/20 · G4 2/2 · G5 1/1 · G6 3/3 · G7 2/2 · G8 1/1 · G9 9/9 · worker_service 11/11 · storage_service 5/5 · evaluation_service 21/21.

The runtime services run the factory unattended, and the verifier proved the behaviors on its own fixtures:
- **Scheduler**: with a lane cap of 1 it claimed exactly 1 of 2 READY units (at the config estimate 100, never 0) and nothing more while that unit was in flight; unresolvable bindings are skipped, never claimed.
- **Dispatcher**: exactly-once effect — one delivery, one handoff record, event published; a 500 from the receiver leaves the event unpublished for the next cycle; a rerun delivers nothing twice.
- **Retry driver**: a due retry fires to READY; a fresh failure waits with its due time reported; at the attempt cap the unit is dead-lettered — BLOCKED with `dead_letter:transient_error` recorded, exactly one audit event and one outbox notification, untouched by later cycles.
- **Reaper + driver chain**: an expired lease lands in RETRY_WAIT and the driver consumes it as `lease_expired` back to READY.
- **Restart recovery**: fresh service instances over settled state changed literally nothing (deliveries, handoffs, claims, dead-letters, states all identical) — the loops are stateless over coordinator state, as designed. The runner emits structured cycle logs and exits cleanly on SIGTERM.

## Changes beyond the new package (both disclosed, both minimal)

- **One coordinator addition**: the transition `RETRY_WAIT --block--> BLOCKED` plus an optional `block_reason` on `event()` — dead-lettering was impossible without it (the transition did not exist). Verifier counted the table: exactly 30 entries = Gate A's 28 + Gate C's 1 + this 1.
- **Migration 013** (`dispatch_handoffs`), additive only.
- Lane handling: the service derives lanes from resolved bindings for gating/reporting but does not rewrite `execution_units.lane` (the coordinator enforces the capacity table on recorded lanes; the schema's column is `max_concurrency`, documented in `lanes.py`). Manual redispatch (`retry_unit`) is byte-for-byte the F-G9-03 path — the driver is additive automation, not a replacement.

## Gate G needs OD-E1 ruled

Gate G (n8n regeneration + dashboard completion + station rewiring onto the worker/evaluation/storage services) cannot be scoped honestly until the envelope decision is taken, because it determines what the regenerated workflows ask workers to produce and what the evaluation service checks:

- **(i) Contracts authoritative** — workers emit the registry envelope; deliverables ride inside `output_artifacts`. Registry data untouched; producers change.
- **(iii) Layered** — envelope wrapper at step exits (`.12`), deliverable schemas for the artifacts inside. Most faithful to both artifacts and contracts; most work.
- **(ii) Payloads authoritative** — the 32 contracts are regenerated to describe today's deliverable shapes. This edits registry contract content — a workflow-version change under the §18 protocol, with definition-hash consequences to manage explicitly.

The options below bundle the Gate F acceptance with each OD-E1 ruling + the Gate G lock, or hold Gate G.
