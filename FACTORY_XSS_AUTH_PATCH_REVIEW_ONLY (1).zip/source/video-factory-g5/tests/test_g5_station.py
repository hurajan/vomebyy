"""G5 end-to-end tests: Station 3 driven by n8n through the G3 API,
the mechanical T-CRE-01 trace check, and the HG2 hash-bound gate evidence.

Requires tools/setup_env.py: API on 8730 (g5_station_scratch), the Gate C
worker service on 8795, the Gate E evaluation service on 8796, n8n on
5678 with the G5 workflows active. Fails loudly if the environment is
down. Gate G: artifact contents live in the Gate D store and step-exit
contents are layered envelopes — artifact_content unwraps them.
"""
import hashlib
import json
import sys
import time
import unittest
import urllib.request
import urllib.error
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "driver"))
import dispatch as driver  # noqa: E402

API = "http://127.0.0.1:8730"
TOKEN = "dev-operator-token"
STORE = (Path.home() / "workspace/video-factory-real-ai-programme"
         / "gate-d/storage_service/.store")


def call(method, path, body=None, expect=(200, 201)):
    req = urllib.request.Request(API + path, method=method)
    req.add_header("X-Operator-Token", TOKEN)
    data = None
    if body is not None:
        data = json.dumps(body).encode()
        req.add_header("Content-Type", "application/json")
    try:
        with urllib.request.urlopen(req, data=data, timeout=15) as r:
            out = json.loads(r.read() or b"{}")
            status = r.status
    except urllib.error.HTTPError as e:
        status, out = e.code, json.loads(e.read() or b"{}")
    assert status in expect, f"{method} {path} -> {status}: {out}"
    return out


def unit_state(pid, unit_id):
    units = call("GET", f"/productions/{pid}/units")["units"]
    return [u for u in units if u["unit_id"] == unit_id][0]


HUMAN_DECISIONS = []


def drive_until(pid, targets, inputs_by_unit=None, timeout=240):
    deadline = time.time() + timeout
    states = {}
    while time.time() < deadline:
        out = driver.run_once(pid, inputs_by_unit=inputs_by_unit)
        HUMAN_DECISIONS.extend(out["human_decisions"])
        states = {uid: unit_state(pid, uid)["state"] for uid in targets}
        if all(states[uid] in tg for uid, tg in targets.items()):
            return states
        time.sleep(2)
    raise AssertionError(f"drive_until timed out: {states}")


def artifact_content(art):
    """Read the artifact's bytes from the Gate D store by the
    coordinator-recorded sha (verifying the hash), and unwrap the
    layered envelope: the deliverable is output_artifacts[0].content."""
    raw = (STORE / "objects" / art["sha256"]).read_bytes()
    assert hashlib.sha256(raw).hexdigest() == art["sha256"], \
        f"store content hash mismatch for {art['artifact_type']}"
    doc = json.loads(raw)
    if isinstance(doc, dict) and doc.get("output_artifacts"):
        return doc["output_artifacts"][0]["content"]
    return doc


def require(pid, artifact_id):
    q = f"/gates/require?production_id={pid}&gate_kind=HG2&artifact_id={artifact_id}"
    return call("GET", q)["satisfied"]


class TestStation3EndToEnd(unittest.TestCase):
    def make_production(self):
        p = call("POST", "/productions", {"title": "G5 test premise",
                                          "hard_ceiling_cents": 1000000,
                                          "soft_ceiling_cents": 900000})
        pid = p["production_id"]
        run = call("POST", f"/productions/{pid}/runs", {"kind": "FULL"})["run_id"]
        return pid, run

    def plan(self, pid, run, op, depends=(), inputs=()):
        return call("POST", f"/productions/{pid}/units",
                    {"operation_id": op, "run_id": run, "unit_key": "main",
                     "depends_on": list(depends), "input_artifact_ids": list(inputs)})

    def test_chain_trace_and_hg2(self):
        pid, run = self.make_production()
        # canon fixture: the Station 1-2 output Station 3 consumes
        # (operator-registered stand-in, as with the G4 rights fixtures)
        canon = call("POST", f"/productions/{pid}/artifacts",
                     {"artifact_type": "canon_manifest", "content": "canon fixture",
                      "storage_uri": "local://canon-fixture"})["artifact_id"]

        # Gate G fixture alignment: the four deliverables all declare
        # the canon in canon_refs, so canon is a PLANNED input of each
        # unit (the retired mock worker looked it up through the API —
        # its own docstring called that "the mock stand-in for receiving
        # canon as a unit input"). The evaluation continuity layer now
        # checks declared refs against planned inputs honestly.
        u05 = self.plan(pid, run, "05.12", inputs=[canon])["unit_id"]
        u06 = self.plan(pid, run, "06.12", depends=[u05], inputs=[canon])["unit_id"]
        u07 = self.plan(pid, run, "07.12", depends=[u06], inputs=[canon])["unit_id"]
        u08 = self.plan(pid, run, "08.12", depends=[u07], inputs=[canon])["unit_id"]
        drive_until(pid, {u: {"ACCEPTED"} for u in (u05, u06, u07, u08)},
                    inputs_by_unit={u05: [canon]})
        # the evaluation + harness-as-human path was exercised
        self.assertTrue(HUMAN_DECISIONS,
                        "no unit reached AWAITING_HUMAN — evaluation path untested")

        arts = call("GET", f"/productions/{pid}/artifacts")["artifacts"]
        cur = {a["artifact_type"]: a for a in arts if a["state"] == "CURRENT"}
        for t in ("story_architecture", "beat_graph", "scene_set", "script"):
            self.assertIn(t, cur)

        # ---- T-CRE-01: mechanical trace check over the real contents
        story = artifact_content(cur["story_architecture"])
        beats = artifact_content(cur["beat_graph"])
        scenes = artifact_content(cur["scene_set"])
        script = artifact_content(cur["script"])
        node_ids = {n["id"] for n in story["story_nodes"]}
        beat_map = {b["id"]: b["story_ref"] for b in beats["beats"]}
        scene_map = {s["id"]: s["beat_ref"] for s in scenes["scenes"]}
        for ref in beat_map.values():
            self.assertIn(ref, node_ids)
        for ref in scene_map.values():
            self.assertIn(ref, beat_map)
        for doc in (story, beats, scenes, script):
            self.assertEqual(doc["canon_refs"], [canon])
        line_ids = set()
        for line in script["lines"]:
            line_ids.add(line["id"])
            self.assertIn(line["scene_ref"], scene_map)
            self.assertIn(line["beat_ref"], beat_map)
            self.assertIn(line["story_ref"], node_ids)
            # cross-reference consistency: the line's beat is its scene's
            # beat, and its story node is that beat's story node
            self.assertEqual(line["beat_ref"], scene_map[line["scene_ref"]])
            self.assertEqual(line["story_ref"], beat_map[line["beat_ref"]])
            self.assertEqual(line["canon_refs"], [canon])
        self.assertGreaterEqual(len(line_ids), 3)
        trace = script["trace"]
        clue_ids = {c["id"] for c in trace["clues"]}
        for c in trace["clues"]:
            self.assertIn(c["planted"], line_ids)
            self.assertIn(c["payoff"], line_ids)
        for k in trace["knowledge"]:
            self.assertIn(k["learns"], clue_ids)
            self.assertIn(k["at"], line_ids)
        for p in trace["payoffs"]:
            self.assertIn(p["clue"], clue_ids)
            self.assertIn(p["line"], line_ids)

        # ---- HG2: the station flow created the gate on the script v1
        script_v1 = cur["script"]
        gate = None
        for _ in range(30):
            gates = call("GET", f"/productions/{pid}/gates")["gates"]
            hg2 = [g for g in gates if g["gate_kind"] == "HG2"]
            if hg2:
                gate = hg2[0]
                break
            time.sleep(2)
        self.assertIsNotNone(gate, "station-03 never created the HG2 gate")
        self.assertEqual(gate["artifact_id"], script_v1["artifact_id"])
        self.assertEqual(gate["artifact_sha256"], script_v1["sha256"])
        self.assertEqual(gate["verdict"], "PENDING")
        self.assertFalse(require(pid, script_v1["artifact_id"]))

        # human decision (via the API, as an operator would)
        call("POST", f"/gates/{gate['gate_id']}/decide",
             {"decision": "APPROVED", "decided_by": "operator"})
        self.assertTrue(require(pid, script_v1["artifact_id"]))

        # a revised script does NOT inherit the approval (exact binding)
        v2 = call("POST", f"/productions/{pid}/artifacts",
                  {"artifact_type": "script", "content": "revised script v2",
                   "storage_uri": "local://script-v2"})
        self.assertFalse(require(pid, v2["artifact_id"]))
        gate2 = call("POST", f"/productions/{pid}/gates",
                     {"gate_kind": "HG2", "artifact_id": v2["artifact_id"]})
        call("POST", f"/gates/{gate2['gate_id']}/decide",
             {"decision": "APPROVED", "decided_by": "operator"})
        self.assertTrue(require(pid, v2["artifact_id"]))

        # budget: exactly the four chain units settled at the mock cost
        budget = call("GET", f"/productions/{pid}/budget")
        self.assertEqual(budget["spent_cents"], 4 * 90)
        self.assertEqual(budget["reserved_cents"], 0)


if __name__ == "__main__":
    unittest.main(verbosity=2)
