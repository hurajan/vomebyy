#!/usr/bin/env python3
"""Deterministic mock workers for G5 Station 3 (LOCK_G5).

POST /work {operation_id, production_id, unit_id, force_fail?} -> one of the
Steps 05-08 exit operations, producing a trace-bearing JSON artifact
content. Contents are persisted to a content-addressed store
(store/<sha256>.json next to this tree) and the response carries
storage_uri mock-store://<sha256>, so tests/verifiers can mechanically
check the trace against the coordinator-recorded hash (T-CRE-01).

Canon refs: the production's real canon_manifest artifact id, looked up
through the G3 API — the mock stand-in for receiving canon as a unit
input. Trace ids are shared deterministic constants across the four
workers; the T-CRE-01 checker validates them against the actual artifact
contents, so a drift here fails the check rather than passing silently.
"""
import hashlib
import json
import urllib.request
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path

API = "http://127.0.0.1:8730"
TOKEN = "dev-operator-token"
STORE = Path(__file__).resolve().parent.parent / "store"
COST = 90

STORY_NODES = ["S1", "S2"]
BEATS = {"B1": "S1", "B2": "S2"}
SCENES = {"SC1": "B1", "SC2": "B2"}


def canon_ref(production_id):
    req = urllib.request.Request(
        f"{API}/productions/{production_id}/artifacts",
        headers={"X-Operator-Token": TOKEN})
    with urllib.request.urlopen(req, timeout=10) as r:
        arts = json.loads(r.read())["artifacts"]
    cur = [a for a in arts if a["artifact_type"] == "canon_manifest"
           and a["state"] == "CURRENT"]
    return cur[0]["artifact_id"] if cur else None


def build(operation_id, production_id):
    canon = canon_ref(production_id)
    if operation_id == "05.12":
        return "story_architecture", {
            "kind": "story_architecture",
            "story_nodes": [{"id": s, "summary": f"Story node {s}"}
                            for s in STORY_NODES],
            "canon_refs": [canon]}
    if operation_id == "06.12":
        return "beat_graph", {
            "kind": "beat_graph",
            "beats": [{"id": b, "story_ref": s} for b, s in BEATS.items()],
            "canon_refs": [canon]}
    if operation_id == "07.12":
        return "scene_set", {
            "kind": "scene_set",
            "scenes": [{"id": sc, "beat_ref": b, "canon_refs": [canon]}
                       for sc, b in SCENES.items()],
            "canon_refs": [canon]}
    if operation_id == "08.12":
        lines = [
            {"id": "L1", "scene_ref": "SC1", "beat_ref": "B1",
             "story_ref": "S1", "canon_refs": [canon],
             "text": "Mara finds the brass key behind the clock."},
            {"id": "L2", "scene_ref": "SC2", "beat_ref": "B2",
             "story_ref": "S2", "canon_refs": [canon],
             "text": "Tobin admits the archive door was locked from inside."},
            {"id": "L3", "scene_ref": "SC1", "beat_ref": "B1",
             "story_ref": "S1", "canon_refs": [canon],
             "text": "The brass key opens the archive; the ledger is gone."},
        ]
        return "script", {
            "kind": "script", "lines": lines,
            "trace": {
                "clues": [{"id": "CL1", "planted": "L1", "payoff": "L3"}],
                "knowledge": [{"character": "Mara", "learns": "CL1",
                               "at": "L2"}],
                "payoffs": [{"id": "PO1", "clue": "CL1", "line": "L3"}]},
            "canon_refs": [canon]}
    return "step_output", {"kind": "step_output", "operation_id": operation_id}


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _send(self, code, obj):
        body = json.dumps(obj).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        self._send(200, {"ok": True, "service": "g5-mock-workers"})

    def do_POST(self):
        n = int(self.headers.get("Content-Length") or 0)
        req = json.loads(self.rfile.read(n) or b"{}")
        if req.get("force_fail"):
            return self._send(500, {"error": "forced failure (test)"})
        artifact_type, content_obj = build(req.get("operation_id"),
                                           req.get("production_id"))
        content = json.dumps(content_obj, sort_keys=True)
        sha = hashlib.sha256(content.encode()).hexdigest()
        STORE.mkdir(parents=True, exist_ok=True)
        (STORE / f"{sha}.json").write_text(content)
        self._send(200, {"artifact_type": artifact_type, "content": content,
                         "storage_uri": f"mock-store://{sha}",
                         "actual_cost_cents": COST, "verdict": "PASS"})


if __name__ == "__main__":
    HTTPServer(("127.0.0.1", 8791), Handler).serve_forever()
