# G6 LOCK REQUEST — Station 4 (Steps 09–12) + coordinator gate-claim fix — prepared, NOT confirmed

**Entry condition:** G5 acceptance — MET (Raj accepted G5 without freezing, 2026-10-28 07:29 EDT). The recorded golden-set limitation carries (evaluators advisory).
**Owner amendment (Raj, 2026-10-28 08:01 EDT):** the coordinator gate-claim enforcement (design below) is ADDED to this lock. This explicitly authorizes a scoped amendment to the accepted G2 coordinator inside G6 — migration 003 + the claim() gate check + its tests, and, only if needed for the refusal to surface correctly, the matching error mapping in the G3 API. No other G2/G3 change is authorized by this lock.
**Baseline if confirmed:** G1–G5 as accepted; the G4/G5 pattern carries over (n8n client, workflows as generated JSON, deterministic mock workers, driver harness, content-addressed store). New tree `~/workspace/video-factory-g6/`, own scratch DB, workers on :8792, webhook `/webhook/dispatch-g6`. The coordinator amendment changes the shared baseline for every station suite — all prior suites are re-run as regressions (criterion 5).

## Scope sketch (A–Z §17 G6; step names from the G1 contracts)

Station 4: Step 09 (Direction), Step 10 (Shot & Sound Design), Step 11 (Production), Step 12 (Edit). Mock workers for the exit chain, planned against the HG2-approved script:

- **09.12 → direction package** (references script lines/scenes it directs)
- **10.12 → shot manifest + sound design plan** (shots referencing script lines; the voice plan rides inside the sound design, per the step's own exit title "Approve feasible Shot Manifest and Sound Design Plan")
- **11.12 → asset registry commit** (approved media entries with hashes — content-addressed, like-for-like with the G5 store discipline)
- **12.12 → edit timeline** carrying the **Rule of Six assessment block**: the six dimensions with the weights from Raj's supplied source (Emotion 51%, Story 23%, Rhythm 10%, Eye Trace 7%, 2D Plane 5%, 3D Space 4%) recorded as data, a deterministic mock score per dimension, the weighted total, and the standing rule from the guide — the rubric is an assessment, it never overrides a hard validation failure.

Premise discipline: the test premise registers an HG2-approved script fixture (script artifact + HG2 gate + APPROVED decision via the API — the operator stand-in for G5's output, exactly as G5's premise registered the canon fixture), and the first Station-4 unit takes the script as its planned input.

## Coordinator amendment — gate-claim enforcement (owner-added)

The gap this closes: before this amendment, nothing in the coordinator prevented claiming a unit planned against a CURRENT script that was simply never HG2-approved; eligibility rested on the operator. The fix puts the check at claim time, beside the existing T-DEP-01 input-currency check, in the coordinator (never in n8n):

1. **Migration 003** adds `gate_requirements (artifact_type PRIMARY KEY, gate_kind)` and seeds one row: `script → HG2`. Requirements are data; future gated artifacts are configuration, not code.
2. **claim() gate check:** for each planned input artifact whose type has a required gate, the claim requires an APPROVED human gate bound to that exact artifact id + sha256 (the existing require_gate semantics). Unsatisfied → a typed refusal (`GateNotSatisfied`): the API surfaces it as 409, **zero attempts are recorded, no budget is reserved**, and the refusal evidence (audit event) is committed following the G2 durability pattern (evidence must survive the refusal — the G2 D2 lesson).
3. **Composition with existing checks:** currency without approval now refuses on the gate rule; approval without currency still refuses on T-DEP-01. Both refusals are coordinator decisions; workflows keep treating any claim 409 as a quiet stop.

Test battery for the amendment (in the G5-style end-to-end suite and/or the coordinator suite): (a) unit planned against a CURRENT, never-approved script → claim refused, 0 attempts, audit event present, unit still READY; (b) approve HG2 → the same unit claims and completes; (c) gate approved for a *different* artifact → refused; (d) approve v1, supersede with v2, plan against v2 unapproved → refused on the gate rule; plan against v1 (superseded) → refused on currency; (e) units whose inputs have no gate requirement are unaffected (G4/G5 flows unchanged).

## PASS evidence (guide §17 G6 + the amendment)

1. One production fully planned through n8n: 09.12 → 10.12 → 11.12 → 12.12 ACCEPTED; direction_package, shot_manifest, asset_registry, edit_timeline artifacts CURRENT.
2. Mechanical reference check over the real contents (content-addressed store, as G5): shots reference real script line ids from the premise's script fixture; asset registry entries carry hashes that re-hash correctly; the edit timeline references real shot ids; the Rule of Six block contains all six dimensions with the source weights summing to 100 and a weighted total consistent with its scores.
3. Budget: spent == 4 × mock cost, reserved 0.
4. **Gate-claim battery (a)–(e) above, all passing** — including the unapproved-script refusal with 0 attempts and committed audit evidence, exercised through the real API + n8n path (the station flow dispatches; the coordinator refuses).
5. Regressions: G1 7/7, G2 17/17 + the amendment's new coordinator tests, G3 5/5, G4 2/2, G5 1/1 (shared-API DB pointing handled explicitly per suite, as in G5). The G1 seed and definition_hash are untouched by migration 003 (registry data is not coordinator state).
6. Independent verification (own premise, own reference checker, tamper probe on a shot reference, own gate-claim probes incl. the unapproved refusal).

## Out of scope

Real AI/models, real providers, Steps 13+ (G7+ — Station 5 and the master gate), OVHcloud/queue mode (G0), any edit to G1–G5 trees beyond the scoped coordinator amendment above (migration 003 + claim gate check + tests; G3 API error mapping only if the refusal does not already surface as 409).
