# LOCK G5 — Station 3 (Steps 05–08) + script gate HG2

- **Confirmed by Raj:** 2026-10-28 06:58 EDT ("Confirm G5 lock as scoped (Station 3 + HG2)").
- **Entry conditions met:** G4 ACCEPTED (without freezing) 2026-10-28; OD-F04 DECIDED = (c) built-Studio numbering — the script gate is `HG2`.
- **Baseline:** G1 (definition_hash ea4503f516fc4f7940f187f5cd9dac38c57f0d239726cac90e2d0a18a8bc9d73), G2, G3, G4 — all ACCEPTED, none frozen, unmodified by this build. OD-F01=(b) carries: n8n is a client of the coordinator, no authoritative state, API only.
- **Source spec:** A–Z Implementation Guide §9.3 (Station 3 narrative) + §17 (G5 scope and exit evidence) + §11 (T-CRE-01 trace completeness). Full scope text: ~/workspace/video-factory-g4/G5_LOCK_REQUEST.md (as confirmed).

## In scope

1. New tree `~/workspace/video-factory-g5/`. The G4 environment services (PostgreSQL, G3 API, n8n instance + data dir) are reused as-is; G5 uses its own scratch DB (`g5_station_scratch`) and its own mock workers on :8791.
2. `station-03` workflow + G5 copies of the §9.2 sub-workflows (dispatch receiver at webhook path `dispatch-g5`, unit-executor, call-worker, error-handler) as generated, versioned JSON in `workflows/` — the G4 workflows and tree are not edited; G5 workflows sync into the same n8n instance via the REST path codified in G4.
3. Deterministic mock workers for the Steps 05–08 exit chain: **05.12 story architecture → 06.12 beat graph → 07.12 scene set → 08.12 script candidate**, chained on unit dependencies. Artifact contents are structured JSON carrying the trace (below); workers persist contents to a content-addressed store (`store/<sha256>.json`) and return `mock-store://<sha256>` as the storage URI, so artifact contents are mechanically checkable against the coordinator-recorded hashes.
4. **Trace (T-CRE-01):** story nodes S*, beats B* (each → a story node), scenes SC* (each → a beat + canon refs), script lines L* (each → scene + beat + story node + canon refs), and a script trace block (clues planted → payoff lines; knowledge entries referencing clue ids; payoffs referencing clue ids). Canon refs are the production's real canon_manifest artifact id, looked up by the worker through the API (the mock stand-in for receiving canon as a unit input).
5. **HG2 as the station exit:** the station-03 flow creates a coordinator human gate of kind `HG2` bound to the script artifact id + exact sha256 once 08.12 completes. The gate decision is the human's (via the G3 API). Station completion evidence requires HG2 APPROVED for the CURRENT script artifact's exact hash.
6. Builder tests (unittest) driving the real stack via the G5 driver + API, including the mechanical T-CRE-01 check over the real artifact contents and the HG2 cross-version evidence (below).

## Out of scope

- Real AI/models, real providers/credentials; Steps 09+ (G6+); OVHcloud / n8n queue mode + Redis (G0); §9.4 production security audit; real-browser dashboard work.
- Any edit to the G1 seed, G2 code/schema, G3 API/dashboard, or the G4 tree/workflows.

## Recorded limitation (on record, not a blocker)

Golden-set arming: EXPERT cases < 50 (Studio framework: 12 SEED / 0 EXPERT) → evaluators advisory, HG2 human-only. No G5 evidence may claim armed evaluators. Mock validation verdicts are deterministic.

## PASS criteria

1. Station-3 walk on a test premise through n8n: 05.12 → 06.12 → 07.12 → 08.12 all ACCEPTED; story_architecture, beat_graph, scene_set, script artifacts CURRENT.
2. T-CRE-01 mechanical check over the real contents (fetched by coordinator-recorded sha256): 100% of script lines resolve scene → beat → story + canon; cross-references consistent (a line's beat == its scene's beat); trace block present, clue/knowledge/payoff references all resolve.
3. HG2 evidence (per the G2/G3 gate interface: creation snapshots the artifact's sha256 into the gate; require is evaluated per artifact id): the workflow-created gate is PENDING with artifact_sha256 == the script artifact's sha; require(HG2, script v1) is false before and true after an APPROVED decision; registering a revised script (v2, new artifact id + hash) is NOT covered (require false for v2) and needs its own gate + approval; station completion = CURRENT script artifact with a satisfied HG2.
   *Drafting note (corrected in-lock before build): an earlier draft of this criterion described a decide-with-hash call; the verified G2/G3 interface binds the hash at gate creation and evaluates require per artifact — the criterion above is the same hash-binding property expressed through the real interface.*
4. Budget: spent == 4 × 90¢ (mock cost), reserved 0 at rest.
5. Regressions: G1 7/7, G2 17/17, G3 5/5, G4 2/2.
6. Independent verification by a separate verifier agent (builder ≠ verifier): own premise, own trace check, own gate probes. Defects reported, not smoothed over.

## NOT TESTED expected at PASS

Real models/providers; evaluator quality (advisory by the recorded limitation); queue mode; multi-process contention; real-browser rendering.
