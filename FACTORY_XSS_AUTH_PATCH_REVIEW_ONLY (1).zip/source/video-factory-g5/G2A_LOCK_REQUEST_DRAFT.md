# G2 AMENDMENT LOCK REQUEST (DRAFT) — Claim-time gate enforcement — prepared, NOT confirmed

**Origin:** Raj's question, 2026-10-28 07:30 EDT — how to fix the limitation recorded in
`G6_LOCK_REQUEST.md`: "Station 4's own flow does not re-check gates (eligibility is the
coordinator's + operator's, recorded honestly rather than implying a gate check the design
doesn't have)."
**Status:** DRAFT prepared 2026-10-28 by proactive groundwork. No lock confirmed, nothing built,
no tree modified. This is a G2 coordinator change; G2 is ACCEPTED without freezing
(2026-10-28), so it requires its own lock — it cannot ride silently inside G6.
**Design summary (as answered in chat):** enforcement inside the coordinator's `claim()`,
driven by a gate-requirements table as data — not in any n8n workflow (advisory/bypassable)
and not at plan time (races with revision). This draft adds the code-level specifics the
chat answer did not carry, each verified against the accepted trees on 2026-10-28.

## Verified code facts (checked 2026-10-28, accepted trees)

1. `claim()` — `~/workspace/video-factory-g2/coordinator/coordinator.py:263`;
   `_claim_txn` (~:285) order is: READY check → `verify_inputs_current(unit_id)` (T-DEP-01,
   :237) → production row `FOR UPDATE` → budget reservation → lease/fencing → attempt row →
   outbox. A gate check inserted beside `verify_inputs_current` runs **before** any
   reservation, lease, or attempt exists — so a refusal leaves 0 attempts by construction.
2. `require_gate(production_id, gate_kind, artifact_id)` already exists (:485): it raises
   `GateNotSatisfied` (:77) unless an APPROVED `human_gates` row is bound to the artifact's
   exact current sha256. `human_gates` schema: migration `002_g2_coordinator.sql:181`
   (`gate_kind TEXT`, `artifact_sha256 TEXT`). No new gate logic is needed — claim-time
   enforcement is a caller, not a new mechanism.
3. The seed row is exact against real values: `artifact_type = 'script'`
   (G5 `tests/test_g5_station.py:104`; `workers/mock_workers.py:75`),
   `gate_kind = 'HG2'` (OD-F04 = (c); G5 `workflows/station-03.json`, "Prepare HG2 gate").
4. **No API change is needed.** The G3 API already maps `GateNotSatisfied` → HTTP 409 in a
   dedicated handler branch (`~/workspace/video-factory-g3/api/server.py`, `except
   GateNotSatisfied` in the request handler). A claim refusal surfaces through the existing
   contract unchanged.
5. Planned inputs are already joined in `verify_inputs_current` via `unit_inputs` →
   `artifacts` (artifact_id, artifact_type, state) — the gate check consumes the same rows.

## Two design points the lock must state (not leave to the builder)

A. **The refused unit stays READY — it must NOT be set BLOCKED.**
   In the transition table (coordinator.py:14–47) BLOCKED's only outgoing transition is
   `cancel → CANCELLED`; there is no BLOCKED → READY. Budget refusal can afford BLOCKED
   (ceiling breach is not self-healing); a gate refusal cannot — HG2 approval arrives later
   and the same unit must then claim. Refusal = typed error to the caller + audit event,
   unit state unchanged.
B. **The audit event must be committed outside the claim transaction.**
   A refusal raised inside `_claim_txn` rolls the transaction back; an audit row inserted
   in that transaction would roll back with it (the D1 defect class documented in
   `_flush_reads`, coordinator.py:97–107 — the defect that failed G2's first verification).
   The lock therefore mandates the existing `_BudgetBlocked` pattern (:61, :269–283):
   an internal signal exception escapes the rolled-back claim transaction, `claim()` then
   writes the audit event (`gate_claim_refused`, payload: artifact_id, gate_kind) in its
   own committed transaction, and only then raises `GateNotSatisfied` to the caller.
   Verification must read the audit row from a **second connection** (cross-connection
   visibility was the G2 re-verifier's standard).

## Scope if confirmed

- New tree (per the G-stage convention) or an amendment tree against the G2 baseline —
  builder's structure, Raj's lock wording governs; G1 seed and `definition_hash ea4503f5…`
  untouched (gate requirements are coordinator data, not registry definitions).
- Migration 003: `gate_requirements(artifact_type TEXT PRIMARY KEY, gate_kind TEXT NOT NULL)`,
  seeded with exactly one row: `('script', 'HG2')`. Generic by design — a future gated
  artifact (e.g. a master gate at G7) is a new row, not new code.
- `claim()`: after the T-DEP-01 currency check, for each planned input whose
  `artifact_type` appears in `gate_requirements`, enforce `require_gate` semantics against
  that exact artifact; on failure apply design points A+B above.
- Nothing else: no workflow changes, no plan-time check, no dashboard change, no change to
  gate creation/decision (hash binding stays at creation, per the LOCK_G5 correction).

## PASS evidence proposed

1. CURRENT script with **no** HG2 gate → claim refused with `GateNotSatisfied` (API: 409);
   0 action_attempts, 0 budget_reservations, 0 worker_leases for the unit; unit still READY;
   `gate_claim_refused` audit row visible from a second connection.
2. Same unit after HG2 APPROVED on that exact artifact → claim succeeds and the unit
   completes normally.
3. Script approved at v1, then superseded by v2 → claim refused again, by T-DEP-01
   (`StaleInput`) — the two checks compose and the refusal reason distinguishes them.
4. Gate APPROVED for a *different* artifact (or a REJECTED/PENDING gate on the right one)
   → refusal stands (hash/identity binding, not kind-only).
5. Units whose planned inputs have no `gate_requirements` row are unaffected (existing
   G2 behaviour byte-for-byte on those paths).
6. Regressions: G2 suite extended with the new cases (17/17 baseline grows, never shrinks);
   G1 7/7, G3 5/5, G4 2/2, G5 1/1 re-run — the coordinator is shared, so every downstream
   suite is in the regression surface (shared-API DB pointing handled explicitly, as in G5).
7. Independent verification with its own premise and its own refusal probes, including the
   second-connection audit check in B.

## Sequencing — Raj's call (the question already in front of him in chat)

- **Option 1 — amendment first, then G6:** G6's premise then runs on an enforcing
  coordinator; the G6 lock's honesty note is retired and its negative probe (unapproved
  script) becomes a real claim-refusal test instead of an out-of-premise note.
- **Option 2 — G6 as locked-draft stands, amendment after:** G6 PASS does not depend on
  enforcement (its premise registers an HG2-approved script either way); the limitation
  stays on record for one stage and the amendment lands before G7, where a second gated
  artifact (master) makes the generic table pay off.

## Out of scope

Real providers/models, plan-time warnings, any n8n-side gate check, G0/OVHcloud,
editing the accepted G1–G5 trees in place, and any change to the golden-set limitation
(evaluators advisory; HG2 remains human-only).
