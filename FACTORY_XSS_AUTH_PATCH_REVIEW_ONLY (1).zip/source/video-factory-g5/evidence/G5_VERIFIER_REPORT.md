# G5 INDEPENDENT VERIFICATION REPORT

- **Verifier:** independent agent (not the builder). All behavioral evidence is my own: my own production, my own canon fixture, my own webhook POSTs (I did not import or use the builder's driver), my own T-CRE-01 checker (independent implementation in /tmp/g5_verify.py).
- **Scope read:** LOCK_G5.md (incl. the in-lock drafting correction to PASS criterion 3) + README.md.
- **Environment:** `tools/setup_env.py` run by me — API :8730 on g5_station_scratch, G5 workers :8791, 5 G5 workflows synced + active in the shared n8n.
- **Verdict: VERIFIED — defects NONE.**

## 1. End-to-end, verifier's own premise — PASS

Production `ad98a36f-8f8d-4fe4-94fe-cf32ff40df0f` ("G5 VERIFIER premise (independent)"), canon fixture artifact `42c4b88a-073a-4cbe-b7db-cdad84c07491` registered by me. Chain planned 05.12 (input = canon) → 06.12 → 07.12 → 08.12 with unit dependencies, driven by my own POSTs to `/webhook/dispatch-g5`. All four units reached **ACCEPTED** (~9 s); `story_architecture`, `beat_graph`, `scene_set`, `script` all **CURRENT**.

## 2. T-CRE-01, verifier's own checker — PASS (with teeth)

- For each of the four artifacts: read `store/<sha256>.json` by the API-reported sha256, re-hashed the bytes — **equal to the coordinator-recorded sha256** in all four cases; `storage_uri == mock-store://<sha256>` in all four cases.
- Trace validation (my checker, independent logic): every beat's story_ref resolves to a story node; every scene's beat_ref resolves to a beat; every script line's scene_ref/beat_ref/story_ref resolve; **each line's beat_ref equals its scene's beat_ref and its story_ref equals that beat's story_ref**; `canon_refs == [my canon artifact id]` in all four documents, in every scene, and in every line; the trace block's clue planted/payoff line refs, knowledge learns/at refs, and payoff clue/line refs all resolve to real ids. Zero violations.
- **Negative probes (checker rejects all three):** (a) a copy of the script with one line's beat_ref replaced by a nonexistent id → rejected; (b) a copy with the clue's payoff line replaced by a nonexistent id → rejected; (c) a copy with a line's beat_ref swapped to another *existing* beat (cross-reference inconsistency) → rejected. The check has teeth; it is not a rubber stamp.

## 3. HG2 evidence — PASS

- **The workflow created the first HG2 gate; I created none before checking.** Gates list for my production showed an HG2 gate with `artifact_id` == script v1 artifact id and `artifact_sha256` == script v1's sha256 (prefix 0ec916ec962b both). **Provenance nailed in n8n's own execution data:** station-03 execution 259 (my production, operation 08.12) ran the *Create HG2 gate* node, whose output was exactly that gate_id with status PENDING; the 05.12/06.12/07.12 executions took the "Not the script exit" branch.
- **Gate-field semantics checked at the source, not assumed** (the builder suite asserts `verdict == "PENDING"` from the gates list): `human_gates.verdict` is `TEXT NOT NULL DEFAULT 'PENDING'` with CHECK in (PENDING, APPROVED, REJECTED, CONDITIONAL) (G2 migration 002, line 187), `decide_gate` updates only `WHERE verdict='PENDING'`, and the G3 gates-list SELECT returns that column. So `verdict == 'PENDING'` is a genuine undecided-state assertion, and live it read `'PENDING'` pre-decision and `'APPROVED'` with my `decided_by` recorded post-decision. The builder's assertion is sound.
- require(HG2, script v1): **false** before decision → decide APPROVED via API → **true**.
- Revised script v2 registered: require(HG2, v2) **false** (no inheritance); my own HG2 gate for v2 + APPROVED decision → **true**; v1 still true.
- Workflow JSON contains **no gate-decision call**: the string `decide` appears nowhere in any G5 workflow; station-03 only POSTs gate *creation* ({artifact_id, gate_kind}).

## 4. Authority + scope — PASS

- Static audit of all five G5 workflow JSONs: node types are only webhook / executeWorkflowTrigger / executeWorkflow / httpRequest / code / if / noOp — **zero database node types** (the `"source": "database"` strings are the Execute Workflow node's standard workflow-reference parameter, not a DB node). Every HTTP URL in workflows, generator, workers, and driver is localhost: G3 API :8730, workers :8791, n8n webhook :5678. No external hosts, no provider names, no API keys (only the documented local dev operator token, as in G3/G4).
- Operations: the only operation literal in the workflows is `08.12` (the station-03 script-exit IF); workers produce only the 05.12/06.12/07.12/08.12 artifact types (+ a generic fallback). **No Steps 09+ anywhere.**
- Baseline integrity: fresh G1 `registry_tool.py validate` → **PASS**, `definition_hash` **ea4503f516fc4f7940f187f5cd9dac38c57f0d239726cac90e2d0a18a8bc9d73** (exact). Seed file SHA-256 = `8bc567a61b60334abd36415abb84faae1486f3d2aa08f29523ddacfd408ad8d4`, identical to the accepted G1 seed.
- Modification sweep (files newer than the G5 lock, 2026-10-28 10:58 UTC; __pycache__ excluded): **G2 and G3 source trees — zero files.** G1 — only the seed file's *mtime* (bytes hash-identical to the accepted seed; the same loader-touch phenomenon the G3/G4 verifiers recorded — hash, not mtime, is the evidence). G4 — excluding node_modules (vendored deps) and n8n-data (runtime state, per instructions), only `driver/dispatch-state.json`, the harness's own runtime state file — not source. **No G1/G2/G3/G4 source file was modified after the lock.**

## 5. Budget + suites — PASS (one explicit skip)

- My premise's budget: **spent 360 (4 × 90), reserved 0**. Exact.
- Suites re-run by me: **G5 builder 1/1 OK**, **G3 5/5 OK**, plus regressions **G1 7/7 OK**, **G2 17/17 OK**.
- **G4 suite NOT re-run — stated explicitly, not implied:** the shared G3 API is currently pointed at the G5 scratch DB (per the documented last-setup-wins arrangement), and the G4 suite requires the API on the G4 DB. I did not re-point the API mid-verification. (This matches PASS criterion 5 only partially by my own hand; the G4 regression claim rests on the builder's recorded run after restoring the G4 DB. Everything else in criterion 5 I reproduced myself.)

## Observations (not defects)

- O1: Mock workers derive all trace ids from shared constants; the trace is therefore real but minimal (3 lines, 1 clue). That is within the lock's mock scope, and the mechanical check + tamper probes show the verification path is genuine.
- O2: As recorded in the lock, HG2 remains human-only and evaluators advisory (EXPERT < 50) — no G5 evidence claims otherwise, and none was found.
