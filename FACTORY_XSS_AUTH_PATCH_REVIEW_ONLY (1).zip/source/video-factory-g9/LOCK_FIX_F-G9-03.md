# LOCK — FIX F-G9-03: retry recovery wiring

- **Authorized by Raj:** 2026-10-28 14:17 EDT ("Authorize a fix lock for F-G9-03 (retry recovery wiring)").
- **Confirmed by Raj:** 2026-10-28 14:21 EDT ("Confirm the F-G9-03 fix lock as scoped").
- **Scope text:** ~/workspace/video-factory-g9/FIX_LOCK_REQUEST_F-G9-03.md (as confirmed) — coordinator `retry_unit()` (refuses unless RETRY_WAIT; closes RUNNING attempt rows as FAILED; emits `retry_ready`), API `POST /units/{id}/retry`, pre-claim retry step in all five station unit-executors. F-G9-01 and F-G9-02 are OUT of scope. Autonomous retry/backoff/scheduler service remains G0 scope; retry here is operator-driven via the existing redispatch gesture.
- **On acceptance:** the changes are absorbed into the G1–G8 baselines as an accepted amendment (G6 Part A precedent), G9 criterion 3 is met, and G9 is re-submitted as a whole.
