# FIX LOCK REQUEST — F-G9-03: retry recovery wiring

**Status: PREPARED under Raj's authorization (2026-10-28 14:17 EDT, "Authorize a fix lock for F-G9-03 (retry recovery wiring)") — build starts on lock confirmation.** Finding: G9 report F-G9-03 (MAJOR) — after a worker failure the unit parks in RETRY_WAIT and nothing in the integrated system can move it; PASS criterion 3 of G9 is not met until this is fixed and re-verified.

## Root cause (from the sources, verified during G9)

The coordinator's transition table has `(RETRY_WAIT, "retry_ready") → READY`, and the API even exposes a generic events route — but no workflow, route caller, or service ever emits `retry_ready` for a dispatched unit, and the failed attempt's `action_attempts` row is left RUNNING (the completion path that closes attempt rows is never reached on the failure path). The unit-executor goes straight to claim on every dispatch; claim against RETRY_WAIT fails and the executor stops at its duplicate/stale branch.

## Proposed scope (option (a), as recommended to and authorized by Raj)

1. **G2 coordinator — one new method, `retry_unit(unit_id)`** (the only coordinator change): in one transaction — refuse unless the unit is RETRY_WAIT (typed error); close the unit's RUNNING `action_attempts` rows as FAILED; emit `retry_ready` (→ READY) with an audit payload naming the retry path. New G2 tests: retry from RETRY_WAIT succeeds and closes the attempt; retry from READY/ACCEPTED/other states is refused and changes nothing; a second retry after a successful one is refused.
2. **G3 API — one new route, `POST /units/{id}/retry`**, added to `contracts/api_contract.json` with the other unit routes; wrong-state calls return a client error under the API's existing error mapping and leave the unit untouched. G3 suite updated for the route.
3. **Station unit-executors (G4–G8 trees, five copies of the same generated workflow)**: insert a pre-claim step — load the unit's state; if RETRY_WAIT, POST the retry route; then claim as today. Regenerated via each tree's `tools/gen_workflows.py` and re-synced via its setup. No driver changes: the operator's existing redispatch gesture becomes the recovery action at every station.
4. **Deliberate properties (recorded, not oversights):** retry is operator-driven (redispatch), immediate, and uncapped — no backoff and no automatic retry loop is built here; autonomous retry/scheduler service remains G0 scope. Budget semantics pinned by test: a failed attempt books no spend; after recovery and success, spent == 90¢ for the unit's production share and reserved == 0.

## PASS criteria

1. G9's `test_worker_failure_recovers` passes through the real n8n path, unmodified: forced failure → RETRY_WAIT (attempt 1) → redispatch → ACCEPTED with attempt 2; the attempt-1 row is FAILED, not RUNNING; spent/reserved for that production == 90 / 0.
2. A second-station recovery spot check (Station 5 executor): a forced failure at 13.12 against fixture inputs recovers the same way.
3. Wrong-state retry probes: POST /units/{id}/retry against READY and ACCEPTED units returns a client error and changes nothing.
4. Regressions, all green: G2 suite (incl. the new retry tests), G3 suite (incl. the new route), G4 2/2, G5 1/1, G6 3/3, G7 2/2, G8 1/1, G9 full run 1/1 and the full G9 battery 8/8.
5. Independent verification: own forced-failure recovery at a station of the verifier's choice, own wrong-state probes, all suites re-run.

## Out of scope

F-G9-01 (loader dependency templates) and F-G9-02 (duplicate PENDING gate) — separate findings, separately ruled; not touched here. Autonomous retry, backoff policy, attempt caps, scheduler service (G0). Any other coordinator/API behavior change.

## On completion

The fix is submitted for acceptance like a station build. On acceptance, G9's criterion 3 is met and G9 can be re-submitted for acceptance as a whole; the G1–G8 baselines absorb the executor/coordinator/API changes as an accepted amendment (the G6 Part A precedent).
