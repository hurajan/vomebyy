# F-G9-03 FIX — INDEPENDENT VERIFIER REPORT

**Verdict: VERIFIED — defects NONE.**
Lock: ~/workspace/video-factory-g9/LOCK_FIX_F-G9-03.md (scope: FIX_LOCK_REQUEST_F-G9-03.md, confirmed by Raj 2026-10-28). Builder ≠ verifier: all behavioral evidence below is from the verifier's own productions, fixtures, dispatches and database reads; the builder's suites were re-run for regression purposes only.

## 1. Recovery end-to-end — verifier's own probes (stations chosen by the verifier, NOT the builder's 3 and 5)

**Probe A — Station 1/2 executor (G4 tree), force-fail 02.12 after a clean 01.12:**
- Forced worker failure parked the unit in RETRY_WAIT (attempt 1); pre-retry DB state showed the original F-G9-03 symptoms intact as the starting point: attempt row `RUNNING`, budget reservation `HELD`.
- Redispatch (no manual intervention, no library call) recovered the unit: ACCEPTED with attempt 2.
- DB invariants after recovery: `action_attempts` == [(1, FAILED), (2, ACCEPTED)]; attempt 1's reservation state == RELEASED; a `RELEASE` row exists in `budget_transactions` for that reservation; production budget spent == 180 (= 90 × 2 units), reserved == 0.

**Probe B — Station 4 executor (G6 tree), force-fail 09.12 against an HG2-approved script fixture (verifier's own fixture + gate):**
- Same sequence and same invariants: RETRY_WAIT with RUNNING attempt + HELD reservation → redispatch → ACCEPTED attempt 2; attempts [(1, FAILED), (2, ACCEPTED)]; reservation RELEASED with RELEASE ledger row; spent == 90, reserved == 0.

Together with the builder's battery (stations 3 and 5, re-run green below), recovery is now demonstrated through **four of the five** executor copies (G4, G5, G6, G7 trees); the fifth (G8 tree) carries the identical generated pre-claim step (see §3) and its suite passes, though the verifier did not force a failure through station 6 specifically.

## 2. Wrong-state and unknown-unit probes (API level, verifier's own)

- `POST /units/{id}/retry` on a READY unit → **HTTP 409**; unit state and attempt count unchanged; no attempt rows created.
- `POST /units/{id}/retry` on an ACCEPTED unit → **HTTP 409**; unit unchanged.
- `POST /units/{unknown}/retry` → **HTTP 404**.
- Coordinator level: `tests/test_retry.py` (3 tests — retry closes attempt and restores READY; refused from READY; refused from ACCEPTED and double-retry refused) passes within the G2 suite (§4).

## 3. Scope discipline

- **Coordinator:** the only behavioral addition is `Coordinator.retry_unit` (one method, read in full): refuses with `UnauthorizedTransition` unless the unit is RETRY_WAIT; releases the failed attempts' HELD reservations, writing the schema's RELEASE ledger entries; closes RUNNING attempts as FAILED; emits `retry_ready`. Fix-marker footprint in the G2 tree is confined to `coordinator/coordinator.py` + `tests/test_retry.py`.
- **API:** one new route `POST /units/{id}/retry` beside the other unit routes; one entry in `contracts/api_contract.json`; the contract test exercises the route (including the unknown-id 404 list and a claim → transient_error → retry → second-retry-refused scenario). Error mapping reuses the existing CoordinatorError mapping (409 state conflicts / 404 unknown ids), matching the probes in §2.
- **Executors:** all five generated `unit-executor.json` files (G4–G8 trees) contain the pre-claim step with identical structure — Load unit → Unit state → Is RETRY_WAIT? → Retry unit (POST /units/{id}/retry, errors tolerated) → Claim unit — inserted in each tree's `tools/gen_workflows.py` at the same position; no other workflow logic changed (node inventories otherwise match the pre-fix executor shape). No driver changes.
- **F-G9-01 UNTOUCHED:** the G1 loader still hardcodes `'1.0.0'` in the dependency-template INSERT (registry_tool.py line 198).
- **F-G9-02 UNTOUCHED:** `create_gate` remains an unconditional INSERT with no existence/dedup check; gate-creation behavior in the station workflows is unchanged (the G9 HG5 sweep still observes exactly one flow-created PENDING gate).

## 4. Suites re-run by the verifier (full logs, no piped tails)

| Suite | Result |
|---|---|
| G9 failure battery (incl. builder's station-5 recovery test) | **8/8 OK** |
| G9 full run (one production, 16 steps) | **1/1 OK** |
| G1 registry | **7/7 OK** |
| G2 coordinator (incl. 3 new test_retry tests) | **25/25 OK** |
| G3 API + contract | **5/5 OK** |
| G4 stations 1–2 | **2/2 OK** |
| G5 station 3 | **1/1 OK** |
| G6 station 4 | **3/3 OK** |
| G7 station 5 | **2/2 OK** |
| G8 station 6 | **1/1 OK** |

All five PASS criteria of the fix lock are met: (1) G9's recovery test passes unmodified through the real n8n path with attempt-1 FAILED and spent/reserved 90/0; (2) second-station recovery confirmed — in fact at two additional stations (1/2 and 4) by the verifier; (3) wrong-state probes return client errors and change nothing; (4) every regression suite green; (5) this independent verification.

## 5. Not tested

- Autonomous retry, backoff, attempt caps, scheduler service — out of scope by the lock (G0); retry remains operator-driven via redispatch, as designed.
- A forced failure driven specifically through the Station 6 (G8 tree) executor copy — mitigated by the identical generated step (§3) and the green G8 suite, but not directly exercised.
- Concurrent double-redispatch racing the same RETRY_WAIT unit (the retry route is transactional and the executor tolerates its error output, but no explicit race test was run).
- Real providers/models/rendering/distribution; multi-instance n8n/queue mode (G0); real-browser rendering. Evaluators remain advisory (EXPERT < 50).

## 6. Transparency note

The verifier's first probe run reported one failure that was a bug in the verifier's own throwaway probe script (a cross-production id mixup in a state re-check), not in the product; the script was corrected and the full probe set re-ran green (exit 0, all checks PASS). No product code was modified by the verifier.

**Defects found: NONE.** The builder's claims are confirmed in full, including the in-scope completion the new tests discovered (failed-attempt reservation release inside `retry_unit`), which the verifier independently observed as HELD → RELEASED with its RELEASE ledger row in both probes.
