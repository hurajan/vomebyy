# G9 VERIFIER REPORT — Full-system verification

**Verdict: NOT VERIFIED — one PASS criterion fails reproducibly (new finding F-G9-03). All other builder claims verified, including F-G9-01 and F-G9-02 (concurred, MINOR).**
Verifier: independent agent (builder ≠ verifier), 2026-10-28. This report supersedes the verifier's initial summary, which relied on a faulty process-poll readout for the failure battery; the corrected battery results below rest on two correctly-configured runs whose completion outputs agree, plus direct database inspection. The error and its correction are recorded in §7 for the record.

## What I verified

**1. Full run (own inspection of a fresh full run).** Note: `setup_fullrun.py` rebuilds `g9_fullrun_scratch` from scratch, so the builder's earlier productions no longer existed when I started; I ran `tests.test_g9_fullrun` (PASS, 42.6s) and then inspected the resulting production (`1649a772-…`, title "G9 full run") myself:
- SQL: exactly 18 units, all ACCEPTED, 18 distinct operation ids = 01.01 + the 16 step exits + 14.01.
- Budget: `budget_transactions` CHARGE total = **1620¢**; all 18 reservations in state SETTLED → open reserve **0**.
- Gates (SQL): HG2 APPROVED, HG4 APPROVED, HG5 APPROVED — all decided_by "operator" — plus the dangling HG5 PENDING of F-G9-02.
- Cross-station references, checked against the actual store contents by hash: the script's `canon_refs` == the production's canon_manifest artifact id; the shot manifest's `script_ref` == the script artifact id and its shot ids {SH1, SH2, SH3} == the edit timeline's shot refs; the master package's `timeline_ref`/`registry_ref` and both sha256s == the real timeline/registry artifacts; the distribution record's `package_ref` == the derivative_package id; the learning record's comparison keys == the derivative portfolio's prediction keys exactly {D-square, D-thumb, D-vertical}.
- The production also reads consistently through the G3 API (observability criterion, API level).
→ PASS criterion 1 and the API-level part of criterion 5: **met**.

**2. Accounting (recomputed independently).** Registry SQL: 192 operation_definitions for workflow 1.0.0; 191 dependency_templates. `evidence/op_accounting.json` contains exactly 192 per-operation entries whose classifications sum to 18 + 1 + 173 = 192, matching its own header; the 18 `executed_full_run` ids are exactly the full-run production's 18 distinct ACCEPTED operation ids; the single station-suite entry is 03.02. The wording is honest: the 173 are classified "defined-and-chained only" and the report explicitly does **not** claim all 192 were unit-executed.
→ PASS criterion 2: **met**. (Reporting nit, not a criterion issue: the builder's report calls the G9 suites "7/7 (full run 1 + battery/sweep 6)", but the battery module contains 7 tests, so the G9 total is 8 tests, not 7.)

**3a. F-G9-01 — CONCUR (MINOR).** Source: `~/workspace/video-factory-g1/tools/registry_tool.py`, `build_load_sql`, line 198 — the dependency-template INSERT hardcodes `'1.0.0'`, while the operation INSERT directly above it correctly uses each row's own `workflow_version`. I re-ran the rehearsal myself on a fresh `g9_upgrade_scratch` and confirmed by SQL: operation_definitions 192 for 1.0.0 **and** 192 for 1.1.0; dependency_templates **191 for 1.0.0, 0 for 1.1.0**; 1.0.0 definition_hash unchanged (`ea4503f5…`, the G1-accepted value); the pinned in-flight 1.0.0 unit preserved (READY); a new 1.1.0 production sees the variant and plans the changed operation. Zero cross-version interference on the pin; the gap is exactly as reported — a silent registry incompleteness for future versions, no runtime impact today (claim checks use instance-level `depends_on`). MINOR is the right severity.
→ PASS criterion 4: **met** (with the finding as the lock requires — reported, not patched).

**3b. F-G9-02 — CONCUR (MINOR).** Confirmed twice over: `evidence/fullrun_gates.json`, and the gates table of the fresh full run I inspected — two HG5 gates on the **same** derivative_package artifact (same artifact_id and sha256): one APPROVED (decided by operator), one dangling PENDING created ~0.3s later by the re-dispatch. I read the coordinator's enforcement path (`coordinator.py` `_verify_input_gates` → `require_gate`): satisfaction requires a gate row with `verdict='APPROVED'` whose `artifact_sha256` equals the artifact's current hash. A PENDING gate is never selected and grants nothing; even if an operator later decided the duplicate, it would approve the exact artifact already approved — it cannot release any other or newer artifact. The duplicate is therefore inert; the harm is a spurious pending gate in the dashboard and a pointless possible decision. MINOR upheld.

## 4. Failure battery — **CRITERION 3 NOT MET** (new finding F-G9-03)

Module `tests.test_g9_failures` (7 tests). Results in the correct G9 environment (API on `g9_fullrun_scratch` via `setup_fullrun.py`), two runs agreeing:
- PASS (6): stale-input refusal; hard-ceiling BLOCKED; duplicate dispatch at two stations; HG2, HG4 and HG5 sweep refusals (each: unit READY, 0 attempts, ≥1 `gate_claim_refused` audit event).
- **FAIL (1, reproducible): `test_worker_failure_recovers`** — in both correctly-configured runs (each "FAILED (failures=1)", same test).

**F-G9-03 (MAJOR for criterion 3) — transient-failure recovery never completes in the integrated system; the redispatch path is inert for RETRY_WAIT units.** Evidence from the failed run's unit (`882decfd-…`, production "G9 failure: worker"): the forced worker failure is recorded (audit: `claim`, then `transient_error`); the unit sits in **RETRY_WAIT, current_attempt 1**; its `action_attempts` row 1 is left in status **RUNNING** (never finished); after the test's redispatch, the audit trail shows **no second claim** and the unit never leaves RETRY_WAIT within the 180s window. Root cause, from the sources: the coordinator's transition table defines `(RETRY_WAIT, "retry_ready") → READY`, but **nothing in the built system emits `retry_ready`** — no API route (no match in the G3 API), no station workflow, no driver — and `scheduler_claim` selects only `state='READY'` units, with no scheduler process running in the station environment in any case. The dispatch driver's `run_once` likewise skips non-READY units. So once a unit lands in RETRY_WAIT, no component of the integrated system ever returns it to service. The failure state itself is safe (the unit parks; no incorrect output or extra spend observed), and the coordinator-level pieces were unit-tested in G2 — but the end-to-end recovery the lock's criterion 3 requires ("worker failure → RETRY_WAIT → ACCEPTED on redispatch") does not exist in the integrated build. The builder's report claim "Failure-injection battery — PASS" is therefore **not sustained**: 6 of 7 battery cases pass; the recovery case fails.

I also reproduced two battery cases myself, outside the harness, on fresh productions via direct API claims (both behaved exactly as specified): HG2 gate refusal → **HTTP 409**, unit READY/0 attempts; stale input (planned input superseded before claim) → **HTTP 409** ("non-current inputs: canon_manifest(SUPERSEDED)"), unit READY/0 attempts.

**5. Regressions — all re-run by me, none skipped:** G1 7/7, G2 22/22, G3 5/5, G4 2/2, G5 1/1, G6 3/3, G7 2/2, G8 1/1 — all green. G9: full-run 1/1; failures 6/7 (see §4). → PASS criterion 6 met for G1–G8; the G9 battery itself is criterion 3, addressed above.

**6. No-product-change claim.** Code-file mtimes across the G1–G8 trees (loader, coordinator, API, workers, workflow generators, setup chain) all predate the G9 lock confirmation (12:54 EDT); G9 wrote only its own tree (harness, evidence) plus runtime state (databases, n8n sync, store artifacts). Consistent with the claim that G9 changed no G1–G8 product code.

## What I did NOT test

Real-browser rendering of the dashboard (NOT TESTED, as recorded — G0-host-dependent); real providers/models/rendering/distribution; queue mode / multi-instance n8n; OVHcloud deployment (G0, BLOCKED on G0.6); evaluator arming (EXPERT < 50); prediction accuracy (mock records); a full 16-step chain driven by my own hand rather than the builder's full-run test (I inspected the resulting production independently instead, and drove my own fresh productions for the failure probes).

## §7. Correction record (verifier's own error, disclosed)

My first battery run's result reached me through `process.poll`, which displayed "Ran 6 tests … OK"; the run's authoritative completion output was in fact "Ran 7 tests … FAILED (failures=1)". A second run I launched after the G1–G8 regressions failed 4 tests — but 3 of those (the gate sweep) were caused by my own sequencing error: the regressions had re-pointed the shared API at `g8_station_scratch` while the sweep reads refusal counts from `g9_fullrun_scratch`. I withdraw those 3 as environment artifacts (they pass in the correct environment, §4) and my initial "battery PASS" statement with them. The recovery failure (F-G9-03) is **not** an environment artifact: it is the single failure in both correctly-configured runs and is corroborated by direct database and source inspection.

## Bottom line

Criteria 1, 2, 4, 5 (API level) and 6 are met; F-G9-01 and F-G9-02 are real and correctly rated MINOR. Criterion 3 fails on its recovery case (F-G9-03): the builder's "battery PASS" claim does not reproduce. **Verdict: NOT VERIFIED.** Per the lock, F-G9-03 is a finding for owner ruling, not something to patch inside G9.
