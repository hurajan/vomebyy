#!/usr/bin/env python3
"""G9 192-operation accounting (LOCK_G9 PASS 2): machine-generated over
the registry in g9_fullrun_scratch, reconciled against the full-run
production's executed units. Writes evidence/op_accounting.json.
Classification is exact: an operation is 'executed' only if a unit for
it reached ACCEPTED in the G9 full run or in a station suite (01.01 and
03.02 — G4 suite evidence); everything else is defined-and-chained.
"""
import json
import sys
from pathlib import Path

import psycopg
from psycopg.rows import dict_row

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "tests"))
from g9_common import call  # noqa: E402

DSN = "host=127.0.0.1 dbname=g9_fullrun_scratch user=factory password=factory_dev_local"
OUT = Path(__file__).resolve().parent.parent / "evidence" / "op_accounting.json"
SUITE_EXECUTED = {"01.01", "03.02"}  # G4 suite (premise op + rights probe op)


def main():
    with psycopg.connect(DSN, row_factory=dict_row, autocommit=True) as conn:
        ops = conn.execute(
            "SELECT operation_id, step_id, station, title FROM"
            " operation_definitions WHERE workflow_version='1.0.0'"
            " ORDER BY operation_id").fetchall()
        deps = conn.execute("SELECT count(*) AS n FROM dependency_templates"
                            ).fetchone()["n"]
    prods = []
    with psycopg.connect(DSN, row_factory=dict_row, autocommit=True) as conn:
        prods = conn.execute(
            "SELECT production_id FROM productions WHERE title=%s"
            " ORDER BY created_at DESC", ("G9 full run",)).fetchall()
    assert prods, "full-run production not found — run the full run first"
    full_pid = prods[0]["production_id"]
    units = call("GET", f"/productions/{full_pid}/units")["units"]
    fullrun_executed = {u["operation_id"] for u in units
                        if u["state"] == "ACCEPTED"}

    rows, counts = [], {"executed_full_run": 0, "executed_station_suite": 0,
                        "defined_and_chained": 0}
    for o in ops:
        if o["operation_id"] in fullrun_executed:
            cls = "executed_full_run"
        elif o["operation_id"] in SUITE_EXECUTED:
            cls = "executed_station_suite"
        else:
            cls = "defined_and_chained"
        counts[cls] += 1
        rows.append({**o, "classification": cls})
    report = {"workflow_version": "1.0.0",
              "total_operations": len(ops),
              "dependency_templates": deps,
              "counts": counts,
              "reconciles_to_192": len(ops) == 192
              and sum(counts.values()) == 192,
              "operations": rows}
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(json.dumps(report, indent=2))
    print(json.dumps({k: report[k] for k in
                      ("total_operations", "dependency_templates", "counts",
                       "reconciles_to_192")}, indent=2))


if __name__ == "__main__":
    main()
