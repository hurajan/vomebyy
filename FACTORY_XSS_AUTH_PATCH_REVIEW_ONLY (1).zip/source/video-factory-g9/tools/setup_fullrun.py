#!/usr/bin/env python3
"""G9 full-run environment (LOCK_G9, reworked by Gate G): sync every
station's workflows into the shared n8n instance (env expressions
resolve service URLs + role tokens from the n8n process env — each
tree's setup launches n8n with them), run every tree's setup (each
restarts the shared API onto its own scratch DB and respawns the
Gate C worker service + Gate E evaluation service bound to that DB),
then finish on the ONE full-run database: build g9_fullrun_scratch,
restart the API + worker service + evaluation service onto it, and
seed STATION provider bindings for stations 1-6 there.

The old per-tree mock workers (ports 8790-8794) are retired (Gate G):
one worker service on 8795 and one evaluation service on 8796 serve
all six stations, exactly as in a real deployment.
"""
import json
import subprocess
import sys
import time
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
TREES = ["video-factory-g4", "video-factory-g5", "video-factory-g6",
         "video-factory-g7", "video-factory-g8"]
HOME = Path.home() / "workspace"
PROG = HOME / "video-factory-real-ai-programme"
API = "http://127.0.0.1:8730"
DSN = ("host=127.0.0.1 dbname=g9_fullrun_scratch "
       "user=factory password=factory_dev_local")
TOKENS = {"FACTORY_OPERATOR_TOKEN": "dev-operator-token",
          "FACTORY_WORKER_TOKEN": "dev-worker-token",
          "FACTORY_SCHEDULER_TOKEN": "dev-scheduler-token",
          "FACTORY_VALIDATOR_TOKEN": "dev-validator-token",
          "FACTORY_CALLBACK_TOKEN": "dev-callback-token"}


def run(cmd, **kw):
    print("+", " ".join(str(c) for c in cmd))
    subprocess.run(cmd, check=True, **kw)


def up(url):
    try:
        with urllib.request.urlopen(url, timeout=3) as r:
            return r.status == 200
    except Exception:
        return False


def api_call(method, path, body=None, expect=(200, 201)):
    req = urllib.request.Request(API + path, method=method)
    req.add_header("X-Operator-Token", TOKENS["FACTORY_OPERATOR_TOKEN"])
    data = None
    if body is not None:
        data = json.dumps(body).encode()
        req.add_header("Content-Type", "application/json")
    with urllib.request.urlopen(req, data=data, timeout=15) as r:
        return json.loads(r.read() or b"{}")


def wait_up(url, timeout=30):
    for _ in range(timeout):
        if up(url):
            return
        time.sleep(1)
    raise SystemExit(f"{url} did not come up")


def main():
    subprocess.run(["pg_ctlcluster", "16", "main", "start"],
                   capture_output=True)
    for tree in TREES:
        run([sys.executable, str(HOME / tree / "tools" / "setup_env.py")])
    run([sys.executable, str(HOME / "video-factory-g3/tools/setup_db.py"),
         "g9_fullrun_scratch"])

    # Restart the shared API onto the full-run DB (with role tokens).
    subprocess.run(["fuser", "-k", "8730/tcp"], capture_output=True)
    time.sleep(1)
    env = {"FACTORY_DSN": DSN, "FACTORY_PORT": "8730",
           "PATH": "/usr/bin:/bin:/usr/local/bin",
           "HOME": str(Path.home()), "USER": "root", **TOKENS}
    subprocess.Popen(
        [str(HOME / "video-factory-g3/.venv/bin/python"),
         str(HOME / "video-factory-g3/api/server.py")],
        stdout=open("/tmp/g9-api.log", "wb"), stderr=subprocess.STDOUT,
        start_new_session=True, env=env)
    wait_up(API + "/health")
    print("api: up (g9_fullrun_scratch)")

    # Restart the worker + evaluation services onto the full-run DB.
    venv_py = str(HOME / "video-factory-g2/.venv/bin/python")
    for port in (8795, 8796):
        subprocess.run(["fuser", "-k", f"{port}/tcp"], capture_output=True)
    time.sleep(1)
    wenv = {"WORKER_SERVICE_PORT": "8795", "WORKER_ENVIRONMENT": "test",
            "PATH": "/usr/bin:/bin:/usr/local/bin",
            "HOME": str(Path.home()),
            # Gate 04: plan-pin verification + action-record sink.
            "WORKER_DSN": DSN, "FACTORY_API_URL": API,
            "FACTORY_WORKER_TOKEN": TOKENS["FACTORY_WORKER_TOKEN"]}
    subprocess.Popen(
        [venv_py, str(PROG / "gate-c/worker_service/service.py")],
        stdout=open("/tmp/g9-worker-service.log", "wb"),
        stderr=subprocess.STDOUT, start_new_session=True, env=wenv)
    eenv = {"FACTORY_DSN": DSN, "FACTORY_API_URL": API,
            "FACTORY_VALIDATOR_TOKEN": TOKENS["FACTORY_VALIDATOR_TOKEN"],
            "FACTORY_EVAL_PORT": "8796",
            "PATH": "/usr/bin:/bin:/usr/local/bin",
            "HOME": str(Path.home())}
    subprocess.Popen(
        [venv_py, str(PROG / "gate-e/evaluation_service/service.py")],
        stdout=open("/tmp/g9-evaluation-service.log", "wb"),
        stderr=subprocess.STDOUT, start_new_session=True, env=eenv)
    wait_up("http://127.0.0.1:8795/health")
    wait_up("http://127.0.0.1:8796/health")
    print("worker service + evaluation service: up on g9_fullrun_scratch")

    # STATION bindings for all six stations on the full-run DB. The
    # reported_actual_cents param preserves the programme-wide
    # accounting (estimate 100, measured actual 90 per completion).
    seeded = []
    for station in (1, 2, 3, 4, 5, 6):
        out = api_call("POST", "/configs", {
            "scope": "STATION", "station": station, "environment": "test",
            "provider": "deterministic-local", "est_cost_cents": 100,
            "params": {"reported_actual_cents": 90}})
        seeded.append((station, out["version"]))
    print(f"bindings: STATION deterministic-local seeded: {seeded}")

    for tree in TREES:
        state = HOME / tree / "driver" / "dispatch-state.json"
        state.unlink(missing_ok=True)
    print("G9 environment ready: API + worker service + evaluation "
          "service on g9_fullrun_scratch, all station workflows synced")


if __name__ == "__main__":
    main()
