#!/usr/bin/env python3
"""G9 upgrade rehearsal (LOCK_G9 PASS 4, guide section 18): load a
1.1.0 variant of the workflow seed alongside 1.0.0 in a dedicated
scratch DB and prove zero cross-version interference on a pinned,
in-flight 1.0.0 production, while a new 1.1.0 production sees the
variant. Uses the G1 loader's own SQL builder (SEED_DIR repointed at
the staged variant) and the G2 coordinator library. Findings are
reported, never patched. Run with the G2 venv interpreter.
Writes evidence/upgrade_rehearsal.json.
"""
import hashlib
import importlib.util
import json
import shutil
import sys
from pathlib import Path

import psycopg
from psycopg.rows import dict_row

HOME = Path.home() / "workspace"
DB = "g9_upgrade_scratch"
DSN = f"host=127.0.0.1 dbname={DB} user=factory password=factory_dev_local"
VARIANT_DIR = Path("/tmp/g9-seed-110")
CHANGED_OP = "16.12"
NEW_TITLE_SUFFIX = " [v1.1 rehearsal variant]"
OUT = Path(__file__).resolve().parent.parent / "evidence" / "upgrade_rehearsal.json"

sys.path.insert(0, str(HOME / "video-factory-g2"))
from coordinator.coordinator import Coordinator  # noqa: E402


def load_tool():
    spec = importlib.util.spec_from_file_location(
        "registry_tool", HOME / "video-factory-g1/tools/registry_tool.py")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def titles(conn, version):
    return {r["operation_id"]: r["title"] for r in conn.execute(
        "SELECT operation_id, title FROM operation_definitions"
        " WHERE workflow_version=%s", (version,)).fetchall()}


def main():
    findings = []
    # 1) production A pinned to 1.0.0, in-flight BEFORE the upgrade
    coord = Coordinator(DSN, actor="g9-rehearsal")
    pid_a = coord.create_production("G9 rehearsal A (pinned 1.0.0)",
                                    1000000, 900000, "g9")
    run_a = coord.start_run(pid_a, "FULL", "g9")
    unit_a = coord.plan_unit(pid_a, run_a, "01.01")
    with psycopg.connect(DSN, row_factory=dict_row, autocommit=True) as conn:
        before = titles(conn, "1.0.0")
        hash_before = conn.execute(
            "SELECT definition_hash FROM workflow_versions"
            " WHERE workflow_version='1.0.0'").fetchone()["definition_hash"]
        deps_before = conn.execute(
            "SELECT count(*) AS n FROM dependency_templates"
            " WHERE workflow_version='1.0.0'").fetchone()["n"]

    # 2) stage + load the 1.1.0 variant via the loader's own SQL builder
    src = HOME / "video-factory-g1/seed-definitions/workflow-1.0.0"
    if VARIANT_DIR.exists():
        shutil.rmtree(VARIANT_DIR)
    VARIANT_DIR.mkdir(parents=True)
    for f in ("capabilities.json", "genre_profiles.json"):
        shutil.copyfile(src / f, VARIANT_DIR / f)
    seed = json.loads((src / "operations.json").read_text())
    seed["workflow_version"] = "1.1.0"
    for op in seed["operations"]:
        op["workflow_version"] = "1.1.0"
        if op["operation_id"] == CHANGED_OP:
            op["title"] = op["title"] + NEW_TITLE_SUFFIX
    variant_bytes = json.dumps(seed, indent=2, sort_keys=True).encode()
    seed["definition_hash"] = hashlib.sha256(variant_bytes).hexdigest()
    (VARIANT_DIR / "operations.json").write_text(
        json.dumps(seed, indent=2, sort_keys=True))
    tool = load_tool()
    tool.SEED_DIR = VARIANT_DIR
    sql_file = Path("/tmp/g9-load-110.sql")
    sql_file.write_text(tool.build_load_sql())
    tool.psql(DB, sql_file=sql_file)

    # 3) interference checks
    with psycopg.connect(DSN, row_factory=dict_row, autocommit=True) as conn:
        after = titles(conn, "1.0.0")
        hash_after = conn.execute(
            "SELECT definition_hash FROM workflow_versions"
            " WHERE workflow_version='1.0.0'").fetchone()["definition_hash"]
        versions = [r["workflow_version"] for r in conn.execute(
            "SELECT workflow_version FROM workflow_versions"
            " ORDER BY 1").fetchall()]
        deps_110 = conn.execute(
            "SELECT count(*) AS n FROM dependency_templates"
            " WHERE workflow_version='1.1.0'").fetchone()["n"]
        unit_a_state = conn.execute(
            "SELECT state FROM execution_units WHERE unit_id=%s",
            (unit_a,)).fetchone()
    assert after == before, "1.0.0 definitions changed under a pinned production"
    assert hash_after == hash_before == \
        "ea4503f516fc4f7940f187f5cd9dac38c57f0d239726cac90e2d0a18a8bc9d73"
    assert versions == ["1.0.0", "1.1.0"], versions
    assert unit_a_state is not None, "in-flight unit vanished"
    if deps_110 == 0:
        findings.append({
            "id": "F-G9-01", "severity": "MINOR",
            "finding": "The G1 loader's dependency-template INSERT hardcodes"
                       " workflow_version '1.0.0': loading the 1.1.0 seed"
                       " registers its operations but attaches NO dependency"
                       " templates to 1.1.0 (templates remain 1.0.0-only)."
                       " Impact: none on 1.0.0 or on runtime claim checks"
                       " (which use instance-level depends_on), but a future"
                       " version's registry record is incomplete; the loader"
                       " is not version-clean for dependency templates."
                       " Reported, not patched (G9 is verification-only)."})

    # 4) a new production on 1.1.0 sees the variant and can plan the op
    pid_b = coord.create_production("G9 rehearsal B (1.1.0)", 1000000,
                                    900000, "g9", workflow_version="1.1.0")
    run_b = coord.start_run(pid_b, "FULL", "g9")
    unit_b = coord.plan_unit(pid_b, run_b, CHANGED_OP)
    with psycopg.connect(DSN, row_factory=dict_row, autocommit=True) as conn:
        t110 = titles(conn, "1.1.0")
    assert t110[CHANGED_OP].endswith(NEW_TITLE_SUFFIX)
    assert t110[CHANGED_OP] != after[CHANGED_OP]

    report = {"versions_present": versions,
              "pin_1_0_0_definitions_unchanged": True,
              "definition_hash_1_0_0": hash_after,
              "in_flight_unit_preserved": unit_a_state["state"],
              "dependency_templates_1_0_0": deps_before,
              "dependency_templates_1_1_0": deps_110,
              "variant_visible_to_new_production": True,
              "variant_unit_planned": unit_b,
              "findings": findings}
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(json.dumps(report, indent=2))
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
