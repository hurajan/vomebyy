# LOCK G9 — Full-system verification

- **Confirmed by Raj:** 2026-10-28 12:54 EDT ("Confirm G9 lock as scoped").
- **Entry condition met:** G8 ACCEPTED (without freezing) 2026-10-28.
- **Baseline:** G1–G8 as accepted. Full scope text: ~/workspace/video-factory-g8/G9_LOCK_REQUEST.md (as confirmed).
- **Nature:** verification only. The G9 tree (`~/workspace/video-factory-g9/`) contains harness code, evidence and reports — no changes to G1–G8 product code. Any defect found is a **finding** for owner ruling, never silently patched.

## Harness design (recorded)

- **One database for the full run** (`g9_fullrun_scratch`, built by the standard chain — all three gate rows present): a production lives in one database, so all six station workflow sets (already co-resident in the single n8n instance) drive the same production through the shared API pointed at the G9 database. Each station's own setup runs first (syncs its workflows, starts its workers), then the API is re-pointed to the G9 database last.
- **Store bridge (disclosed):** each station tree has its own content-addressed store directory (a mock-build artifact). Between stations, the harness copies the produced artifacts' content files (`<sha256>.json`) into the next station's store so its workers can read contents by hash. In a real deployment the content store is one shared object store; the bridge emulates that. It touches no product code and no artifact bytes.
- **Full-run chain (18 units):** 01.01 → 01.12 → 02.12 → 03.12 → 04.12 (Stations 1–2) → 05.12 (input: the real canon_manifest) → 06.12 → 07.12 → 08.12 (Station 3; HG2 created by the flow, approved by the operator) → 09.12 (input: the real script) → 10.12 → 11.12 → 12.12 (Station 4) → 13.12 (inputs: real edit_timeline + asset_registry) → HG4 approved → 14.01 → 14.12 (Station 5) → 15.12 (input: real derivative_package; HG5 created at point of need, approved) → 16.12 (Station 6). Expected budget: 18 × 90¢ = 1620¢, reserved 0.

## PASS criteria

1. Full run: all 18 units ACCEPTED in dependency order; cross-station references verified against the real predecessor artifacts (script's canon_refs == the Station-1–2 canon_manifest id; timeline's shot refs resolve; master's refs == the real timeline/registry; distribution matches the real package; learning covers the real portfolio's predictions); budget exactly 1620¢ / reserved 0; audit trail contains all three gate decisions.
2. Accounting: machine-generated over the registry, reconciling to 192 exactly, with the executed/defined classification stated precisely (full-run executed: the 16 step exits + 01.01; station suites additionally executed 03.02; the remainder defined-and-chained only). No claim that all 192 were unit-executed.
3. Failure battery (own productions in the G9 database): worker failure → RETRY_WAIT → ACCEPTED on redispatch; stale input → claim refused, unit READY with 0 attempts; hard-ceiling production → unit BLOCKED with budget evidence; duplicate dispatch at two stations → no duplicate artifacts or spend; gate sweep — HG2/HG4/HG5 each refuse a pre-approval claim on sibling productions.
4. Upgrade rehearsal (§18): per the registry's actual versioning support, investigated before execution; the outcome — including any gap between §18 and the G1/G2 design — is reported as evidence/finding, not patched.
5. Observability: the full-run production reads consistently through the API (units, gates, budget, artifacts, audit). Real-browser rendering remains NOT TESTED.
6. Regressions: G1 7/7, G2 22/22, G3 5/5, G4 2/2, G5 1/1, G6 3/3, G7 2/2, G8 1/1.
7. Independent verification of the G9 harness and its claims.

## Out of scope

Fixes to G1–G8, real providers/models/distribution, OVHcloud/queue mode (G0, BLOCKED on G0.6), arming evaluators (EXPERT < 50).
