# FIX REPORT — F-G9-03: retry recovery wiring

**Status: COMPLETE + INDEPENDENTLY VERIFIED (defects NONE) — ACCEPTED by Raj 2026-10-28 WITHOUT FREEZING (fix and G9 accepted together; the changes are absorbed into the baselines as an amendment, G6 Part A precedent).** Lock: LOCK_FIX_F-G9-03.md (authorized by Raj 2026-10-28 14:17 EDT; confirmed as scoped 14:21 EDT). Scope text: FIX_LOCK_REQUEST_F-G9-03.md. Verifier report: evidence/FIX_F-G9-03_VERIFIER_REPORT.md.

## What was built (exactly the locked scope)

1. **G2 coordinator — `retry_unit(unit_id)`** (the only coordinator change): one transaction — refuses unless RETRY_WAIT (typed `UnauthorizedTransition`); releases the failed attempts' HELD budget reservations with RELEASE ledger entries; closes their RUNNING `action_attempts` rows as FAILED; emits `retry_ready` → READY with an audit payload (attempts_closed, reservations_released). New tests: `tests/test_retry.py` (3).
2. **G3 API — `POST /units/{id}/retry`** + contract entry (contract now 22 endpoints) + contract-test scenario (drive a unit to RETRY_WAIT via the API, retry → READY, second retry → 409; unknown id added to the 404 battery).
3. **Station unit-executors (G4–G8, five generated copies)**: a pre-claim step — Load unit → "Is RETRY_WAIT?" → Retry unit → Claim unit (non-RETRY_WAIT units flow straight to claim, unchanged). Regenerated via each tree's `tools/gen_workflows.py`; no driver changes — the operator's redispatch is now the recovery action at every station.

## In-scope completion disclosed (found by the new tests, pinned by the lock)

The lock's PASS criterion 1 pins "spent/reserved == 90 / 0 after recovery." The first test run proved the failed attempt's reservation stayed HELD forever (held == 100 after full recovery) — the failure path never released it, so the F-G9-03 wound had a budget half as well as a state half. The reservation release inside `retry_unit` (above) is that completion: same method, same transaction, required by the locked criterion — not a scope expansion. The verifier observed the HELD → RELEASED transition directly in both of its probes.

## Builder evidence

- G2 suite **25/25** (22 + 3 new retry tests: recovery closes attempt + settles 90/0; refusal from READY; refusal from ACCEPTED + double-retry).
- G3 suite **5/5** (contract test exercises the retry route end-to-end).
- G9 battery **8/8** — the unmodified `test_worker_failure_recovers` (Station 3) passes through the real n8n path; new Station-5 spot check passes; attempt rows [(1, FAILED), (2, ACCEPTED)]; budget 90/0 in both.
- G9 full run **1/1**; regressions G1 **7/7**, G4 **2/2**, G5 **1/1**, G6 **3/3**, G7 **2/2**, G8 **1/1** — all with full logs written to files (the G9 lesson applied throughout).

## Independent verification — VERIFIED, defects NONE

The verifier used its own productions and fixtures at two stations the builder did not use — **Station 1/2** (force-fail 02.12) and **Station 4** (force-fail 09.12 against its own HG2-approved script) — starting from the original symptoms (attempt RUNNING, reservation HELD) and recovering via plain redispatch to ACCEPTED, rows [(1, FAILED), (2, ACCEPTED)], reservation RELEASED with its ledger row, spent 90 × units / reserved 0. Wrong-state probes: READY → 409 unchanged, ACCEPTED → 409, unknown id → 404. Scope discipline confirmed by diff inspection: coordinator confined to `retry_unit` + its tests; API to the one route + contract + test scenario; all five executors carry the identical pre-claim step and nothing else; **F-G9-01 and F-G9-02 untouched** (loader still hardcodes '1.0.0'; gate creation unchanged). All ten suites re-run with full logs, every count matching the builder's.

NOT TESTED (recorded by the verifier): a forced failure driven specifically through the Station 6 executor copy (identical generated step + green G8 suite mitigate); a concurrent double-redispatch race on the same unit; autonomous retry/backoff/scheduler (G0 scope, per the lock).

## Environment note

Mid-build the VM was replaced and PostgreSQL 16 vanished entirely (packages, cluster, and the postgres user). All code and home-directory state survived; PG 16.15 was reinstalled from the local package cache and the setup chain rebuilt every scratch database. No product code was changed for the outage; no evidence was lost (suites re-run after recovery).

## Effect on acceptance

G9 PASS criterion 3 (failure battery through the integrated path) is now met. On the owner's acceptance of this fix: the coordinator/API/executor changes are absorbed into the accepted baselines as an amendment (G6 Part A precedent), and **G9 is re-submitted for acceptance as a whole** — all six criteria met, findings F-G9-01 and F-G9-02 still open as MINORs for separate ruling.
