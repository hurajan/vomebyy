"""Gate 04 (G01-D03): registry-driven materialization equivalence.

The G9 full run's unit graph was hand-planned for eight gates. This
test proves Coordinator.materialize_run (via the API) produces the
SAME graph — same operations, same dependency edges, same initial
states — as the hand-planned chain for the same operation set, so the
hand-planned harness and the registry-driven path are interchangeable.
Requires tools/setup_fullrun.py (runs against g9_fullrun_scratch).
"""
import sys
import unittest
from pathlib import Path

import psycopg
from psycopg.rows import dict_row

sys.path.insert(0, str(Path(__file__).resolve().parent))
from g9_common import DSN, call, make_production, plan  # noqa: E402

OPS = ["01.01", "01.12", "02.12", "03.12", "04.12", "05.12", "06.12",
       "07.12", "08.12", "09.12", "10.12", "11.12", "12.12", "13.12",
       "14.01", "14.12", "15.12", "16.12"]


def graph(pid):
    """(ops, edges, states) for a production, from the DB."""
    with psycopg.connect(DSN, row_factory=dict_row, autocommit=True) as conn:
        units = conn.execute(
            "SELECT unit_id, operation_id, state, unit_key, lane FROM "
            "execution_units WHERE production_id=%s", (pid,)).fetchall()
        by_id = {u["unit_id"]: u for u in units}
        edges = set()
        for row in conn.execute(
                "SELECT d.unit_id, d.depends_on_unit FROM unit_dependencies d "
                "JOIN execution_units u ON u.unit_id=d.unit_id "
                "WHERE u.production_id=%s", (pid,)).fetchall():
            edges.add((by_id[row["depends_on_unit"]]["operation_id"],
                       by_id[row["unit_id"]]["operation_id"]))
        return ({u["operation_id"] for u in units}, edges,
                {u["operation_id"]: u["state"] for u in units},
                {(u["unit_key"], u["lane"]) for u in units})


class TestMaterializedEquivalence(unittest.TestCase):
    def test_materialized_graph_equals_hand_planned(self):
        # hand-planned (the pre-Gate-04 harness shape)
        pid_a, run_a = make_production("G9 equivalence hand-planned")
        prev = None
        for op in OPS:
            uid = plan(pid_a, run_a, op, depends=[prev] if prev else [])
            prev = uid
        # registry-materialized
        pid_b, run_b = make_production("G9 equivalence materialized")
        out = call("POST", f"/productions/{pid_b}/runs/{run_b}/materialize",
                   {"operation_ids": OPS})
        self.assertEqual(out["unit_count"], 18)

        ops_a, edges_a, states_a, keys_a = graph(pid_a)
        ops_b, edges_b, states_b, keys_b = graph(pid_b)
        self.assertEqual(ops_a, ops_b)
        self.assertEqual(edges_a, edges_b)
        self.assertEqual(len(edges_b), 17)
        self.assertEqual(states_a, states_b)
        self.assertEqual(states_b["01.01"], "READY")
        self.assertEqual(keys_a, keys_b)


if __name__ == "__main__":
    unittest.main(verbosity=2)
