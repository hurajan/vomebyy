"""G9 failure-injection battery + gate sweep (LOCK_G9 PASS 3).
Own productions in the full-run database; the shared API must point at
g9_fullrun_scratch (tools/setup_fullrun.py). G2 venv interpreter.
"""
import hashlib
import json
import sys
import time
import unittest
from pathlib import Path

import psycopg
from psycopg.rows import dict_row

sys.path.insert(0, str(Path(__file__).resolve().parent))
from g9_common import (DRIVERS, DSN, artifacts, call, make_production,  # noqa: E402
                       plan, unit_state, wait_state)

def refusals(unit_id):
    with psycopg.connect(DSN, row_factory=dict_row, autocommit=True) as conn:
        return conn.execute(
            "SELECT count(*) AS n FROM audit_events WHERE unit_id=%s"
            " AND event_type='gate_claim_refused'", (unit_id,)).fetchone()["n"]


def register(pid, artifact_type, doc, store=None):
    # Gate G: registration alone suffices — the coordinator stores the
    # bytes in the Gate D content store (by sha); the old per-tree
    # mock-store file writes are gone with the store bridge.
    content = json.dumps(doc, sort_keys=True)
    sha = hashlib.sha256(content.encode()).hexdigest()
    return call("POST", f"/productions/{pid}/artifacts",
                {"artifact_type": artifact_type, "content": content,
                 "storage_uri": f"mock-store://{sha}"})


def drive_to(driver, pid, unit_id, target, timeout=180):
    """Drive a station driver until the unit reaches `target` (Gate G:
    completed units pause at AWAITING_HUMAN and the driver, acting as
    the human, approves them on its next pass)."""
    deadline = time.time() + timeout
    while time.time() < deadline:
        driver.run_once(pid)
        unit = unit_state(pid, unit_id)
        if unit["state"] == target:
            return unit
        time.sleep(2)
    raise AssertionError(f"unit {unit_id} stuck at "
                         f"{unit_state(pid, unit_id)['state']}, wanted {target}")


SCRIPT = {"kind": "script",
          "lines": [{"id": "L1", "scene_ref": "SC1", "beat_ref": "B1",
                     "story_ref": "S1", "canon_refs": ["canon-x"],
                     "text": "Line one."}],
          "trace": {"clues": [], "knowledge": [], "payoffs": []},
          "canon_refs": ["canon-x"]}


class TestFailureBattery(unittest.TestCase):
    def test_worker_failure_recovers(self):
        pid, run = make_production("G9 failure: worker")
        canon = register(pid, "canon_manifest",
                         {"kind": "canon_manifest", "facts": []})
        u = plan(pid, run, "05.12", inputs=[canon["artifact_id"]])
        DRIVERS[3].run_once(pid, inputs_by_unit={u: [canon["artifact_id"]]},
                            force_fail_units={u})
        unit = wait_state(pid, u, "RETRY_WAIT")
        self.assertEqual(unit["current_attempt"], 1)
        DRIVERS[3].redispatch(pid, u, "05.12", inputs=[canon["artifact_id"]])
        unit = drive_to(DRIVERS[3], pid, u, "ACCEPTED")
        self.assertEqual(unit["current_attempt"], 2)

    def test_worker_failure_recovers_station5(self):
        # LOCK_FIX_F-G9-03 PASS 2: the same recovery through Station 5's
        # executor (the fix patched all five executor copies).
        import hashlib as _h
        pid, run = make_production("G9 failure: worker (station 5)")
        shots = ["SH1", "SH2"]
        timeline = {"kind": "edit_timeline",
                    "segments": [{"shot_ref": s, "order": i + 1}
                                 for i, s in enumerate(shots)],
                    "rule_of_six": {"dimensions": [], "weighted_total": 0}}
        registry = {"kind": "asset_registry", "assets": [
            {"id": f"A-{s}", "shot_ref": s, "payload": f"p-{s}",
             "sha256": _h.sha256(f"p-{s}".encode()).hexdigest()} for s in shots]}
        t = register(pid, "edit_timeline", timeline)
        r = register(pid, "asset_registry", registry)
        u = plan(pid, run, "13.12", inputs=[t["artifact_id"], r["artifact_id"]])
        inputs = {u: [t["artifact_id"], r["artifact_id"]]}
        DRIVERS[5].run_once(pid, inputs_by_unit=inputs, force_fail_units={u})
        unit = wait_state(pid, u, "RETRY_WAIT")
        self.assertEqual(unit["current_attempt"], 1)
        DRIVERS[5].redispatch(pid, u, "13.12",
                              inputs=[t["artifact_id"], r["artifact_id"]])
        unit = drive_to(DRIVERS[5], pid, u, "ACCEPTED")
        self.assertEqual(unit["current_attempt"], 2)
        budget = call("GET", f"/productions/{pid}/budget")
        self.assertEqual(budget["spent_cents"], 90)
        self.assertEqual(budget["reserved_cents"], 0)
        with psycopg.connect(DSN, row_factory=dict_row, autocommit=True) as conn:
            rows = conn.execute(
                "SELECT attempt_no, status FROM action_attempts"
                " WHERE unit_id=%s ORDER BY attempt_no", (u,)).fetchall()
        self.assertEqual([(x["attempt_no"], x["status"]) for x in rows],
                         [(1, "FAILED"), (2, "ACCEPTED")])

    def test_stale_input_refused(self):
        pid, run = make_production("G9 failure: stale input")
        v1 = register(pid, "canon_manifest",
                      {"kind": "canon_manifest", "facts": ["v1"]})
        u = plan(pid, run, "05.12", inputs=[v1["artifact_id"]])
        register(pid, "canon_manifest",
                 {"kind": "canon_manifest", "facts": ["v2"]})
        DRIVERS[3].run_once(pid, inputs_by_unit={u: [v1["artifact_id"]]})
        time.sleep(10)
        unit = unit_state(pid, u)
        self.assertEqual(unit["state"], "READY")
        self.assertEqual(unit["current_attempt"], 0)

    def test_hard_ceiling_blocks(self):
        p = call("POST", "/productions", {"title": "G9 failure: budget",
                                          "hard_ceiling_cents": 50,
                                          "soft_ceiling_cents": 40})
        pid = p["production_id"]
        run = call("POST", f"/productions/{pid}/runs", {"kind": "FULL"})["run_id"]
        u = plan(pid, run, "01.01")
        DRIVERS[1].run_once(pid)
        unit = wait_state(pid, u, "BLOCKED")
        self.assertEqual(unit["current_attempt"], 0)
        budget = call("GET", f"/productions/{pid}/budget")
        self.assertEqual(budget["spent_cents"], 0)

    def test_duplicate_dispatch_two_stations(self):
        # station 3 duplicate
        pid, run = make_production("G9 failure: duplicates")
        canon = register(pid, "canon_manifest",
                         {"kind": "canon_manifest", "facts": []})
        u = plan(pid, run, "05.12", inputs=[canon["artifact_id"]])
        DRIVERS[3].run_once(pid, inputs_by_unit={u: [canon["artifact_id"]]})
        drive_to(DRIVERS[3], pid, u, "ACCEPTED")
        before = call("GET", f"/productions/{pid}/budget")["spent_cents"]
        n_art = len(artifacts(pid))
        DRIVERS[3].redispatch(pid, u, "05.12", inputs=[canon["artifact_id"]])
        time.sleep(10)
        self.assertEqual(call("GET", f"/productions/{pid}/budget")["spent_cents"],
                         before)
        self.assertEqual(len(artifacts(pid)), n_art)


class TestGateSweep(unittest.TestCase):
    def test_hg2_refuses(self):
        pid, run = make_production("G9 sweep: HG2")
        script = register(pid, "script", SCRIPT)
        u = plan(pid, run, "09.12", inputs=[script["artifact_id"]])
        DRIVERS[4].run_once(pid, inputs_by_unit={u: [script["artifact_id"]]})
        time.sleep(10)
        unit = unit_state(pid, u)
        self.assertEqual(unit["state"], "READY")
        self.assertEqual(unit["current_attempt"], 0)
        self.assertGreaterEqual(refusals(u), 1)

    def test_hg4_refuses(self):
        pid, run = make_production("G9 sweep: HG4")
        master = register(pid, "master_package",
                          {"kind": "master_package", "timeline_ref": "t",
                           "timeline_sha256": "x", "registry_ref": "r",
                           "registry_sha256": "y", "asset_hashes": []},
)
        u = plan(pid, run, "14.01", inputs=[master["artifact_id"]])
        DRIVERS[5].run_once(pid, inputs_by_unit={u: [master["artifact_id"]]})
        time.sleep(10)
        unit = unit_state(pid, u)
        self.assertEqual(unit["state"], "READY")
        self.assertEqual(unit["current_attempt"], 0)
        self.assertGreaterEqual(refusals(u), 1)

    def test_hg5_refuses(self):
        pid, run = make_production("G9 sweep: HG5")
        package = register(pid, "derivative_package",
                           {"kind": "derivative_package", "derivatives": []},
)
        u = plan(pid, run, "15.12", inputs=[package["artifact_id"]])
        DRIVERS[6].run_once(pid, inputs_by_unit={u: [package["artifact_id"]]})
        time.sleep(10)
        unit = unit_state(pid, u)
        self.assertEqual(unit["state"], "READY")
        self.assertEqual(unit["current_attempt"], 0)
        self.assertGreaterEqual(refusals(u), 1)
        gates = [g for g in call("GET", f"/productions/{pid}/gates")["gates"]
                 if g["gate_kind"] == "HG5"]
        self.assertEqual(len(gates), 1)
        self.assertEqual(gates[0]["verdict"], "PENDING")


if __name__ == "__main__":
    unittest.main(verbosity=2)
