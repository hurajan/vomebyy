"""G9 full run (LOCK_G9 PASS 1 + 5): ONE production through all six
stations / sixteen steps in the single full-run database, each station
consuming the previous station's real outputs, all three human gates
decided en route. Requires tools/setup_fullrun.py.
Runs under the G2 venv interpreter (psycopg for audit reads).
"""
import sys
import time
import unittest
from pathlib import Path

import psycopg
from psycopg.rows import dict_row

sys.path.insert(0, str(Path(__file__).resolve().parent))
from g9_common import (API, DSN, approve, artifacts, call,  # noqa: E402
                       content_of, current, drive, make_production, plan,
                       unit_state, wait_gate, wait_state)

TITLE = "G9 full run"


def audit(pid, event_type):
    with psycopg.connect(DSN, row_factory=dict_row, autocommit=True) as conn:
        return conn.execute(
            "SELECT count(*) AS n FROM audit_events WHERE production_id=%s"
            " AND event_type=%s", (pid, event_type)).fetchone()["n"]


class TestFullRun(unittest.TestCase):
    def test_sixteen_steps_one_production(self):
        pid, run = make_production(TITLE)

        # ---- Stations 1-2 (G4 driver / webhook /dispatch)
        u = {}
        u["01.01"] = plan(pid, run, "01.01")
        prev = u["01.01"]
        for op in ("01.12", "02.12", "03.12", "04.12"):
            u[op] = plan(pid, run, op, depends=[prev])
            prev = u[op]
        drive(1, pid, [u[op] for op in ("01.01", "01.12", "02.12", "03.12", "04.12")])
        canon = current(pid, "canon_manifest")
        current(pid, "production_charter")
        current(pid, "rights_register")
        current(pid, "people_manifest")

        # ---- Station 3 (input: the real canon_manifest)
        prev = u["04.12"]
        s3 = []
        for op in ("05.12", "06.12", "07.12", "08.12"):
            u[op] = plan(pid, run, op, depends=[prev],
                         inputs=[canon["artifact_id"]])
            prev = u[op]
            s3.append(u[op])
        drive(3, pid, s3, inputs_by_unit={
            u[op]: [canon["artifact_id"]]
            for op in ("05.12", "06.12", "07.12", "08.12")})
        script = current(pid, "script")
        script_doc = content_of(script)
        self.assertIn(canon["artifact_id"], script_doc["canon_refs"])
        hg2 = wait_gate(pid, "HG2")
        self.assertEqual(hg2["artifact_id"], script["artifact_id"])
        self.assertEqual(hg2["verdict"], "PENDING")
        approve(hg2["gate_id"])

        # ---- Station 4 (input: the real script; steps 09-11)
        prev = u["08.12"]
        s4 = []
        for op in ("09.12", "10.12", "11.12"):
            u[op] = plan(pid, run, op, depends=[prev],
                         inputs=[script["artifact_id"]] if op == "09.12" else ())
            prev = u[op]
            s4.append(u[op])
        drive(4, pid, s4, inputs_by_unit={u["09.12"]: [script["artifact_id"]]})
        registry = current(pid, "asset_registry")

        # ---- Station 5 entry: step 12 (Gate 03 Option B — 12.12 is
        # registry Station 5 and is served by the G7 tree; it depends
        # on 11.12 and, as in the original chain, declares no planned
        # input artifacts — its deliverable declares shot references,
        # and 11.12's asset_registry is 13.12's declared input below)
        u["12.12"] = plan(pid, run, "12.12", depends=[u["11.12"]])
        drive(5, pid, [u["12.12"]], inputs_by_unit={
            u["12.12"]: [registry["artifact_id"]]})
        timeline = current(pid, "edit_timeline")
        timeline_doc = content_of(timeline)
        shots = content_of(current(pid, "shot_manifest"))
        self.assertEqual({s["shot_ref"] for s in timeline_doc["segments"]},
                         {s["id"] for s in shots["shots"]})

        # ---- Station 5 (inputs: the real timeline + registry)
        u["13.12"] = plan(pid, run, "13.12", depends=[u["12.12"]],
                          inputs=[timeline["artifact_id"], registry["artifact_id"]])
        drive(5, pid, [u["13.12"]], inputs_by_unit={
            u["13.12"]: [timeline["artifact_id"], registry["artifact_id"]]})
        master = current(pid, "master_package")
        master_doc = content_of(master)
        self.assertEqual(master_doc["timeline_ref"], timeline["artifact_id"])
        self.assertEqual(master_doc["registry_ref"], registry["artifact_id"])
        hg4 = wait_gate(pid, "HG4")
        self.assertEqual(hg4["artifact_sha256"], master["sha256"])
        approve(hg4["gate_id"])
        u["14.01"] = plan(pid, run, "14.01", depends=[u["13.12"]],
                          inputs=[master["artifact_id"]])
        u["14.12"] = plan(pid, run, "14.12", depends=[u["14.01"]],
                          inputs=[master["artifact_id"]])
        drive(5, pid, [u["14.01"], u["14.12"]], inputs_by_unit={
            u["14.01"]: [master["artifact_id"]], u["14.12"]: [master["artifact_id"]]})
        package = current(pid, "derivative_package")
        portfolio = current(pid, "derivative_portfolio")

        # ---- Station 6 (HG5 created at point of need, then approved)
        u["15.12"] = plan(pid, run, "15.12", depends=[u["14.12"]],
                          inputs=[package["artifact_id"]])
        from g9_common import DRIVERS
        DRIVERS[6].run_once(pid, inputs_by_unit={u["15.12"]: [package["artifact_id"]]})
        hg5 = wait_gate(pid, "HG5")
        self.assertEqual(hg5["artifact_id"], package["artifact_id"])
        self.assertEqual(unit_state(pid, u["15.12"])["state"], "READY")
        approve(hg5["gate_id"])
        DRIVERS[6].redispatch(pid, u["15.12"], "15.12",
                              inputs=[package["artifact_id"]])
        # Gate G: completion pauses at AWAITING_HUMAN (QA binding is
        # the unarmed factory mock); the driver, acting as the human,
        # approves on its next pass — drive until ACCEPTED.
        for _ in range(90):
            DRIVERS[6].run_once(pid)
            if unit_state(pid, u["15.12"])["state"] == "ACCEPTED":
                break
            time.sleep(2)
        else:
            raise AssertionError("15.12 never ACCEPTED")
        dist = current(pid, "distribution_record")
        dist_doc = content_of(dist)
        self.assertEqual(dist_doc["package_ref"], package["artifact_id"])
        u["16.12"] = plan(pid, run, "16.12", depends=[u["15.12"]],
                          inputs=[portfolio["artifact_id"], dist["artifact_id"]])
        drive(6, pid, [u["16.12"]], inputs_by_unit={
            u["16.12"]: [portfolio["artifact_id"], dist["artifact_id"]]})
        learn = content_of(current(pid, "learning_record"))
        portfolio_doc = content_of(portfolio)
        self.assertEqual(set(learn["comparison"]),
                         set(portfolio_doc["predictions"]))

        # ---- whole-run assertions
        self.assertEqual(len(u), 18)
        for op, uid in u.items():
            self.assertEqual(unit_state(pid, uid)["state"], "ACCEPTED", op)
        budget = call("GET", f"/productions/{pid}/budget")
        self.assertEqual(budget["spent_cents"], 18 * 90)
        self.assertEqual(budget["reserved_cents"], 0)
        gates = call("GET", f"/productions/{pid}/gates")["gates"]
        self.assertEqual({g["gate_kind"] for g in gates}, {"HG2", "HG4", "HG5"})
        for kind in ("HG2", "HG4", "HG5"):
            self.assertTrue(any(g["gate_kind"] == kind
                                and g["verdict"] == "APPROVED" for g in gates),
                            f"no APPROVED {kind} gate")
        # Finding F-G9-02 evidence: the post-approval redispatch of 15.12
        # created a second, dangling PENDING HG5 gate (gate creation is
        # not deduplicated once the first gate leaves PENDING). Inert —
        # the APPROVED gate satisfies the requirement — but recorded.
        import json as _json
        ev = Path(__file__).resolve().parent.parent / "evidence"
        ev.mkdir(parents=True, exist_ok=True)
        (ev / "fullrun_gates.json").write_text(_json.dumps(
            {"production_id": pid, "gates": gates}, indent=2, default=str))
        # Gate decisions live in the gates table itself (verdict +
        # decided_by), not in audit_events — the audit vocabulary covers
        # unit/claim events. Assert the decision trail where it lives.
        for kind in ("HG2", "HG4", "HG5"):
            g = next(g for g in gates if g["gate_kind"] == kind
                     and g["verdict"] == "APPROVED")
            self.assertEqual(g["decided_by"], "operator")
        self.assertGreaterEqual(audit(pid, "claim"), 18)


if __name__ == "__main__":
    unittest.main(verbosity=2)
