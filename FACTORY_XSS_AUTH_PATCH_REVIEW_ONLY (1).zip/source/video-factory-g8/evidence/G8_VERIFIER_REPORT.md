# G8 VERIFIER REPORT — Station 6 (Steps 15–16) + publication gate HG5

**Verdict: VERIFIED — defects NONE.**

Independent verification against `~/workspace/video-factory-g8/LOCK_G8.md`. The verifier used its own premise, fixtures, dispatch code and checker (harness preserved at `evidence/g8_verifier_harness.py`, 32/32 assertions passed); the builder's test assertions were not used for the behavioral evidence.

## What was verified

### 1. Own station-6 premise + HG5 gate battery (real n8n path)
Verifier premise: derivatives `V-alpha` / `V-beta` / `V-gamma` (platforms `vids` / `feedo` / `storyo`), payloads `verifier8-payload::<id>`, locked prediction ranges [12000, 30000] / [3000, 9000] / [500, 2500] — all distinct from the builder's fixtures. Fixture payloads re-hash to their recorded sha256 under the verifier's own math.
- First 15.12 dispatch (verifier's own webhook POSTs): a `gate_claim_refused` audit event appeared in `g8_station_scratch` through the real path; the unit stayed **READY with 0 attempts**; budget reserved 0 / spent 0.
- A direct API claim (`POST /units/{id}/claim`) was refused with **HTTP 409** and left the unit READY with 0 attempts.
- Exactly **one HG5 gate** existed, created by station-06 at the point of need: **PENDING**, bound to the verifier package's exact artifact id and sha256. No G8 workflow contains a `decide` call (static grep) — the decision stayed human via the API.
- After the verifier's APPROVED decision and re-dispatch: 15.12 → **ACCEPTED**.

### 2. Distribution integrity + duplicate-dispatch idempotency
- Exactly one `distribution_record`; its store bytes re-hash to the coordinator-recorded sha256; `package_ref` is the verifier package.
- The verifier's checker found **zero mismatches**: publication derivative ids == package ids, each publication sha256 == package sha256 (and == payload-derived sha), platforms match, and every publication carries a platform post id.
- Duplicate dispatch of the accepted 15.12: still exactly one `distribution_record`, budget spent unchanged at 90.

### 3. Learning record (16.12)
- 16.12 → ACCEPTED; `learning_record` CURRENT, store bytes re-hash to the recorded sha; `portfolio_ref` and `distribution_ref` point at the verifier's portfolio and the distribution record.
- Comparison keys == the locked prediction keys exactly; every `predicted_range` equals the verifier's locked range; every `delta_vs_midpoint` and `within_range` recomputes from the recorded actuals under the verifier's math.
- Final budget: **spent 180, reserved 0**.

### 4. Tamper probe
One derivative's sha256 in a copy of the verifier package was altered (payload untouched). The verifier checker flagged **exactly that derivative** (`V-beta`); the untampered package flags nothing. Probe behaves honestly in both directions.

### 5. Builder's disclosed defect — fix confirmed
Static: `tools/gen_workflows.py` contains the "Restore dispatch payload" code node (`return [{ json: $('Execute Workflow Trigger').first().json }]`), and the generated `workflows/station-06.json` wires it on **both** gate paths — `Create HG5 gate` (success output) → Restore → `Run unit`, and `Create HG5 gate` (error output) → `HG5 gate already pending` → Restore → `Run unit`. Behavioral: the battery in §1 produced `gate_claim_refused` evidence through the real path, which is exactly what the original defect prevented. The fix is confirmed, not taken on the builder's word.

### 6. Placement audit (migration 005)
- `005_g8_publication_gate_requirement.sql` is data-only: a single `INSERT INTO gate_requirements … ON CONFLICT DO NOTHING` inside a transaction. No DDL, no logic.
- Idempotence proven on a throwaway chain-built DB: re-applying 005 twice returned `INSERT 0 0` both times; the table held exactly 3 rows with exactly one `derivative_package → HG5` row. (A first probe attempt hit a file-permission error reading the migration as the postgres OS user — an artifact of file modes, not of the migration; the probe was redone via a `/tmp` copy and passed. The throwaway DB was dropped.)*
- A database built from the G2 setup chain **alone** carries all three rows: `script→HG2`, `master_package→HG4`, `derivative_package→HG5`.
- G2 tree changes in the G8 window are confined to exactly the new 005 file + the one `setup_db.py` line applying it (line 53; both files timestamped 16:23:49 UTC, the G8 lock window, 2026-10-28). `coordinator.py` mtime is 12:05 UTC — the G6-authorized amendment — untouched by G7 and G8.

### 7. Regressions — all re-run by the verifier, none skipped
| Suite | Result |
|---|---|
| G1 | 7/7 OK |
| G2 | 22/22 OK (DB rebuilt via the chain; all three gate rows present) |
| G3 | 5/5 OK |
| G4 | 2/2 OK (API re-pointed to `g4_station_scratch`) |
| G5 | 1/1 OK |
| G6 | 3/3 OK |
| G7 | 2/2 OK |
| G8 (builder's suite) | 1/1 OK |

The builder's claims are confirmed in full: G8 suite 1/1 after the disclosed in-lock fix; all regressions green; G2 22/22 with three gate rows present.

## Not tested
Real platform APIs/OAuth/posting and real metrics sources (founder-side integrations; distribution and actuals are mocks with real reference/hash discipline); prediction or distribution *accuracy*; real-browser UI rendering; G9 full-system verification; OVHcloud/queue mode (G0); moving HG5 creation into station-05's tail (explicitly out of scope for G8). Evaluators remain advisory (EXPERT < 50), as recorded in the lock.
