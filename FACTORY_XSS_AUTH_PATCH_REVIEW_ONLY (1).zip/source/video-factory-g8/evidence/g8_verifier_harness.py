#!/usr/bin/env python3
"""G8 INDEPENDENT VERIFIER harness (builder != verifier).

Own premise (derivative ids / platforms / payloads / prediction ranges
all distinct from the builder's fixtures), own dispatch POSTs to the
n8n webhook, own checker functions. Verifies LOCK_G8 PASS criteria:
HG5 point-of-need gate battery through the real path, direct-claim
409, distribution reference integrity, duplicate-dispatch idempotency,
prediction-vs-actual learning record, and a tamper probe.
"""
import copy
import hashlib
import json
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path

import psycopg
from psycopg.rows import dict_row

API = "http://127.0.0.1:8730"
WEBHOOK = "http://127.0.0.1:5678/webhook/dispatch-g8"
TOKEN = "dev-operator-token"
STORE = Path(__file__).resolve().parent.parent / "store"
DSN = ("host=127.0.0.1 dbname=g8_station_scratch user=factory "
       "password=factory_dev_local")

RESULTS = []


def check(name, cond, detail=""):
    RESULTS.append((name, bool(cond), detail))
    print(f"[{'PASS' if cond else 'FAIL'}] {name}" + (f" — {detail}" if detail and not cond else ""))


def call(method, path, body=None, expect=(200, 201)):
    req = urllib.request.Request(API + path, method=method)
    req.add_header("X-Operator-Token", TOKEN)
    data = None
    if body is not None:
        data = json.dumps(body).encode()
        req.add_header("Content-Type", "application/json")
    try:
        with urllib.request.urlopen(req, data=data, timeout=15) as r:
            return r.status, json.loads(r.read() or b"{}")
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read() or b"{}")


def dispatch(pid, unit_id, op, inputs):
    payload = {"production_id": pid, "unit_id": unit_id, "operation_id": op,
               "station": 6, "input_artifact_ids": list(inputs),
               "force_fail": False,
               "idempotency_key": f"dispatch:{unit_id}:1"}
    req = urllib.request.Request(WEBHOOK, method="POST",
                                 data=json.dumps(payload).encode(),
                                 headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=15) as r:
        return r.status


def unit_state(pid, unit_id):
    _, out = call("GET", f"/productions/{pid}/units")
    return [u for u in out["units"] if u["unit_id"] == unit_id][0]


def wait_state(pid, unit_id, target, timeout=150):
    deadline = time.time() + timeout
    last = None
    while time.time() < deadline:
        last = unit_state(pid, unit_id)
        if last["state"] == target:
            return last
        time.sleep(2)
    raise AssertionError(f"unit stuck at {last and last['state']}, wanted {target}")


def refusals(unit_id):
    with psycopg.connect(DSN, row_factory=dict_row, autocommit=True) as conn:
        return conn.execute(
            "SELECT count(*) AS n FROM audit_events WHERE unit_id=%s"
            " AND event_type='gate_claim_refused'", (unit_id,)).fetchone()["n"]


def wait_refusal(unit_id, timeout=90):
    deadline = time.time() + timeout
    while time.time() < deadline:
        if refusals(unit_id) >= 1:
            return True
        time.sleep(3)
    return False


# ---------------------------------------------------------------- premise
DERIVS = [{"id": "V-alpha", "format": "9:16", "platform": "vids"},
          {"id": "V-beta", "format": "1:1", "platform": "feedo"},
          {"id": "V-gamma", "format": "4:5", "platform": "storyo"}]
RANGES = {"V-alpha": [12000, 30000], "V-beta": [3000, 9000], "V-gamma": [500, 2500]}
PORTFOLIO = {"kind": "derivative_portfolio", "master_ref": "verifier-master-8",
             "derivatives": DERIVS,
             "predictions": {d["id"]: {"view_range": RANGES[d["id"]],
                                        "ctr_band": "2-4%",
                                        "confidence": "LOW — verifier mock prediction"}
                             for d in DERIVS},
             "predictions_locked": True}
PACKAGE = {"kind": "derivative_package", "master_ref": "verifier-master-8",
           "derivatives": [{**d, "payload": f"verifier8-payload::{d['id']}",
                            "sha256": hashlib.sha256(
                                f"verifier8-payload::{d['id']}".encode()).hexdigest()}
                           for d in DERIVS],
           "upload_manifest": {"files": [d["id"] for d in DERIVS],
                               "master_ref": "verifier-master-8",
                               "metadata": {"title": "Verifier upload package",
                                            "visibility": "unlisted"}}}


def flag_mismatches(package_doc, dist_doc):
    """Verifier checker: derivative ids whose publication sha in the
    distribution record differs from the package's recorded sha, whose
    payload-derived sha differs from the package's recorded sha, or
    which are missing on either side."""
    pubs = {r["derivative_id"]: r for r in dist_doc.get("publications", [])}
    bad = []
    pkg_ids = set()
    for d in package_doc.get("derivatives", []):
        pkg_ids.add(d["id"])
        derived = hashlib.sha256(d["payload"].encode()).hexdigest()
        pub = pubs.get(d["id"])
        if derived != d["sha256"] or pub is None or pub["sha256"] != d["sha256"]:
            bad.append(d["id"])
    for pid_ in pubs:
        if pid_ not in pkg_ids:
            bad.append(pid_)
    return bad


def register(pid, artifact_type, doc):
    content = json.dumps(doc, sort_keys=True)
    sha = hashlib.sha256(content.encode()).hexdigest()
    STORE.mkdir(parents=True, exist_ok=True)
    (STORE / f"{sha}.json").write_text(content)
    status, art = call("POST", f"/productions/{pid}/artifacts",
                       {"artifact_type": artifact_type, "content": content,
                        "storage_uri": f"mock-store://{sha}"})
    assert status in (200, 201), art
    return art


def main():
    # fixture internal consistency (payload -> sha) under verifier math
    for d in PACKAGE["derivatives"]:
        check(f"fixture {d['id']} payload hashes to its recorded sha",
              hashlib.sha256(d["payload"].encode()).hexdigest() == d["sha256"])

    _, p = call("POST", "/productions", {"title": "G8 VERIFIER premise",
                                         "hard_ceiling_cents": 1000000,
                                         "soft_ceiling_cents": 900000})
    pid = p["production_id"]
    _, r = call("POST", f"/productions/{pid}/runs", {"kind": "FULL"})
    run = r["run_id"]
    portfolio = register(pid, "derivative_portfolio", PORTFOLIO)
    package = register(pid, "derivative_package", PACKAGE)

    def plan(op, depends=(), inputs=()):
        s, out = call("POST", f"/productions/{pid}/units",
                      {"operation_id": op, "run_id": run, "unit_key": "main",
                       "depends_on": list(depends),
                       "input_artifact_ids": list(inputs)})
        assert s in (200, 201), out
        return out["unit_id"]

    # ---- 1. HG5 battery: first dispatch creates gate at point of need, refused
    u15 = plan("15.12", inputs=[package["artifact_id"]])
    dispatch(pid, u15, "15.12", [package["artifact_id"]])
    check("gate_claim_refused evidence appears via real n8n path",
          wait_refusal(u15, timeout=90))
    unit = unit_state(pid, u15)
    check("unapproved 15.12 stays READY", unit["state"] == "READY", unit["state"])
    check("unapproved 15.12 has 0 attempts", unit["current_attempt"] == 0)
    _, budget = call("GET", f"/productions/{pid}/budget")
    check("no budget movement while refused",
          budget["reserved_cents"] == 0 and budget["spent_cents"] == 0, str(budget))

    # direct API claim -> 409, and still no attempt afterwards
    status, body = call("POST", f"/units/{u15}/claim",
                        {"worker_id": "verifier-probe", "estimated_cents": 100},
                        expect=(200, 201, 409))
    check("direct API claim refused with HTTP 409", status == 409, f"{status}: {body}")
    unit = unit_state(pid, u15)
    check("direct claim left unit READY with 0 attempts",
          unit["state"] == "READY" and unit["current_attempt"] == 0)

    _, gout = call("GET", f"/productions/{pid}/gates")
    hg5 = [g for g in gout["gates"] if g["gate_kind"] == "HG5"]
    check("exactly one HG5 gate created by station-06", len(hg5) == 1, str(len(hg5)))
    gate = hg5[0]
    check("HG5 bound to verifier package artifact id",
          gate["artifact_id"] == package["artifact_id"])
    check("HG5 bound to verifier package exact sha256",
          gate["artifact_sha256"] == package["sha256"])
    check("HG5 verdict PENDING before decision", gate["verdict"] == "PENDING")

    # ---- 2. approve -> distribution proceeds; duplicate dispatch is a no-op
    call("POST", f"/gates/{gate['gate_id']}/decide",
         {"decision": "APPROVED", "decided_by": "verifier"})
    dispatch(pid, u15, "15.12", [package["artifact_id"]])
    wait_state(pid, u15, "ACCEPTED")
    check("15.12 ACCEPTED after HG5 approval", True)

    _, aout = call("GET", f"/productions/{pid}/artifacts")
    dists = [a for a in aout["artifacts"] if a["artifact_type"] == "distribution_record"]
    check("exactly one distribution_record", len(dists) == 1, str(len(dists)))
    dist = dists[0]
    raw = (STORE / f"{dist['sha256']}.json").read_bytes()
    check("distribution store bytes re-hash to coordinator-recorded sha",
          hashlib.sha256(raw).hexdigest() == dist["sha256"])
    dist_doc = json.loads(raw)
    check("distribution package_ref is verifier package",
          dist_doc["package_ref"] == package["artifact_id"])
    check("checker: publications match verifier package exactly",
          flag_mismatches(PACKAGE, dist_doc) == [],
          str(flag_mismatches(PACKAGE, dist_doc)))
    pubs = {r["derivative_id"]: r for r in dist_doc["publications"]}
    check("every publication carries a platform post id",
          all(pubs[d["id"]].get("platform_post_id") for d in DERIVS))
    check("publication platforms match package platforms",
          all(pubs[d["id"]]["platform"] == d["platform"] for d in DERIVS))

    dispatch(pid, u15, "15.12", [package["artifact_id"]])
    time.sleep(10)
    _, aout = call("GET", f"/productions/{pid}/artifacts")
    check("duplicate dispatch: still one distribution_record",
          len([a for a in aout["artifacts"]
               if a["artifact_type"] == "distribution_record"]) == 1)
    _, budget = call("GET", f"/productions/{pid}/budget")
    check("duplicate dispatch: budget unchanged (spent 90)",
          budget["spent_cents"] == 90, str(budget))

    # ---- 3. learning record vs locked predictions
    u16 = plan("16.12", depends=[u15],
               inputs=[package["artifact_id"], portfolio["artifact_id"]])
    dispatch(pid, u16, "16.12", [package["artifact_id"], portfolio["artifact_id"]])
    wait_state(pid, u16, "ACCEPTED")
    check("16.12 ACCEPTED", True)
    _, aout = call("GET", f"/productions/{pid}/artifacts")
    learn = [a for a in aout["artifacts"] if a["artifact_type"] == "learning_record"
             and a["state"] == "CURRENT"][0]
    lraw = (STORE / f"{learn['sha256']}.json").read_bytes()
    check("learning store bytes re-hash to coordinator-recorded sha",
          hashlib.sha256(lraw).hexdigest() == learn["sha256"])
    ldoc = json.loads(lraw)
    check("learning portfolio_ref is verifier portfolio",
          ldoc["portfolio_ref"] == portfolio["artifact_id"])
    check("learning distribution_ref is the distribution_record",
          ldoc["distribution_ref"] == dist["artifact_id"])
    check("comparison keys == locked prediction keys exactly",
          set(ldoc["comparison"]) == set(PORTFOLIO["predictions"]),
          str(set(ldoc["comparison"])))
    ok_ranges, ok_deltas = True, True
    for did, entry in ldoc["comparison"].items():
        lo, hi = RANGES[did]
        if entry["predicted_range"] != [lo, hi]:
            ok_ranges = False
        if entry["delta_vs_midpoint"] != entry["actual_views"] - (lo + hi) // 2:
            ok_deltas = False
        if entry["within_range"] != (lo <= entry["actual_views"] <= hi):
            ok_deltas = False
    check("every predicted_range equals the locked prediction", ok_ranges)
    check("every delta/within_range recomputes from actuals", ok_deltas)
    _, budget = call("GET", f"/productions/{pid}/budget")
    check("final budget spent == 180, reserved == 0",
          budget["spent_cents"] == 180 and budget["reserved_cents"] == 0, str(budget))

    # ---- 4. tamper probe
    tampered = copy.deepcopy(PACKAGE)
    victim = tampered["derivatives"][1]
    victim["sha256"] = ("0" if victim["sha256"][0] != "0" else "1") + victim["sha256"][1:]
    flagged = flag_mismatches(tampered, dist_doc)
    check("tamper probe: altered derivative sha flagged exactly",
          flagged == [victim["id"]], str(flagged))
    check("tamper probe: untampered package flags nothing",
          flag_mismatches(PACKAGE, dist_doc) == [])

    failed = [n for n, ok, _ in RESULTS if not ok]
    print(f"\n== verifier harness: {len(RESULTS) - len(failed)}/{len(RESULTS)} passed ==")
    if failed:
        print("FAILED:", failed)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
