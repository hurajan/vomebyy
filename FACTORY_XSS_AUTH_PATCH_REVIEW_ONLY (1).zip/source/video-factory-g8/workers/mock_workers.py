#!/usr/bin/env python3
"""Deterministic mock workers for G8 Station 6 (LOCK_G8).

POST /work {operation_id, production_id, unit_id, force_fail?} ->
15.12 distribution_record / 16.12 learning_record. Contents are
reference-bearing JSON persisted to the content-addressed store
(store/<sha256>.json), storage_uri mock-store://<sha256>.

15.12 (15.01: "Resolve exact derivative hash"; 15.12: "distribute
published IDs to analytics") reads the production's CURRENT
derivative_package through the API and emits one publish record per
derivative — id and sha256 carried from the package, platform, and a
deterministic mock platform post id. 16.12 ("Persist learning with
confidence limitations") reads the CURRENT derivative_portfolio's
locked predictions and the CURRENT distribution_record and emits mock
actuals with a prediction-vs-actual delta per derivative. The actuals
are deterministic mock records: what G8 verifies is gating, reference
integrity, idempotency and the comparison structure — not real metrics.
"""
import hashlib
import json
import urllib.request
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path

API = "http://127.0.0.1:8730"
TOKEN = "dev-operator-token"
STORE = Path(__file__).resolve().parent.parent / "store"
COST = 90


def artifacts(production_id):
    req = urllib.request.Request(
        f"{API}/productions/{production_id}/artifacts",
        headers={"X-Operator-Token": TOKEN})
    with urllib.request.urlopen(req, timeout=10) as r:
        return json.loads(r.read())["artifacts"]


def current(production_id, artifact_type):
    cur = [a for a in artifacts(production_id)
           if a["artifact_type"] == artifact_type and a["state"] == "CURRENT"]
    return cur[0] if cur else None


def store_content(sha):
    p = STORE / f"{sha}.json"
    return json.loads(p.read_text()) if p.exists() else None


def build(operation_id, production_id):
    if operation_id == "15.12":
        package = current(production_id, "derivative_package")
        doc = store_content(package["sha256"]) if package else None
        records = [{"derivative_id": d["id"], "sha256": d["sha256"],
                    "platform": d["platform"],
                    "platform_post_id": f"mock-{d['id']}-001"}
                   for d in (doc or {}).get("derivatives", [])]
        return "distribution_record", {
            "kind": "distribution_record",
            "package_ref": package["artifact_id"] if package else None,
            "publications": records}
    if operation_id == "16.12":
        portfolio = current(production_id, "derivative_portfolio")
        pdoc = store_content(portfolio["sha256"]) if portfolio else None
        distribution = current(production_id, "distribution_record")
        comparison = {}
        for deriv_id, pred in sorted((pdoc or {}).get("predictions", {}).items()):
            lo, hi = pred["view_range"]
            actual_views = (lo + hi) // 2 + 500
            comparison[deriv_id] = {
                "predicted_range": [lo, hi],
                "actual_views": actual_views,
                "within_range": lo <= actual_views <= hi,
                "delta_vs_midpoint": actual_views - (lo + hi) // 2}
        return "learning_record", {
            "kind": "learning_record",
            "portfolio_ref": portfolio["artifact_id"] if portfolio else None,
            "distribution_ref": distribution["artifact_id"] if distribution else None,
            "comparison": comparison,
            "confidence_limitations":
                "Mock actuals; comparison structure verified, accuracy not claimed."}
    return "step_output", {"kind": "step_output", "operation_id": operation_id}


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _send(self, code, obj):
        body = json.dumps(obj).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        self._send(200, {"ok": True, "service": "g8-mock-workers"})

    def do_POST(self):
        n = int(self.headers.get("Content-Length") or 0)
        req = json.loads(self.rfile.read(n) or b"{}")
        if req.get("force_fail"):
            return self._send(500, {"error": "forced failure (test)"})
        artifact_type, content_obj = build(req.get("operation_id"),
                                           req.get("production_id"))
        content = json.dumps(content_obj, sort_keys=True)
        sha = hashlib.sha256(content.encode()).hexdigest()
        STORE.mkdir(parents=True, exist_ok=True)
        (STORE / f"{sha}.json").write_text(content)
        self._send(200, {"artifact_type": artifact_type, "content": content,
                         "storage_uri": f"mock-store://{sha}",
                         "actual_cost_cents": COST, "verdict": "PASS"})


if __name__ == "__main__":
    HTTPServer(("127.0.0.1", 8794), Handler).serve_forever()
