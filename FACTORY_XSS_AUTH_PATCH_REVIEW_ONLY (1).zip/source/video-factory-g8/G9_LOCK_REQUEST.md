# G9 LOCK REQUEST — Full-system verification

**Status: PREPARED — NOT locked.** Entry condition met (G8 ACCEPTED by Raj 2026-10-28 without freezing). Starts only on Raj's lock confirmation. Guide §17 G9: "Full-system verification: every station, failure injection, observability, upgrade rehearsal." Guide acceptance: "all 192 operations accounted for; the full system passes its regression and recovery batteries; a minor-version upgrade executes under §18 with zero cross-version interference on in-flight productions."

G9 is a **verification programme, not a build**: a new harness tree `~/workspace/video-factory-g9/` containing tests and reports only. Any defect found is reported with evidence; fixing it needs its own lock or owner ruling — G9 does not silently patch G1–G8.

## Proposed scope

1. **One production, all sixteen steps.** A single production driven through all six station flows in sequence (dispatch → dispatch-g5 → dispatch-g6 → dispatch-g7 → dispatch-g8, with the G4 receiver covering Stations 1–2), planning the step-exit chain 01.12 → 16.12 with real inter-station artifact flow (each station consumes the previous station's actual outputs, not fixtures, wherever the station pattern allows), and the three human gates decided by the operator en route (HG2 after Station 3, HG4 after 13.12, HG5 at Station 6). Assertions: final state ACCEPTED at 16.12; every intermediate artifact CURRENT and reference-consistent across station boundaries; total budget == units executed × 90¢, reserved 0.
2. **192-operation accounting.** A machine-generated accounting over the G1 registry: all 192 definitions present, dependency templates resolve, every operation belongs to a step whose exit operation executed in (1). The classification is stated honestly in the report: the 16 step-exit operations are unit-executed end-to-end; the remaining 176 are defined, chained, and accounted for — **not** individually unit-executed in the mock build. G9 must not claim otherwise.
3. **Failure-injection battery** (system level, through the real flows): worker failure → RETRY_WAIT → success on redispatch; stale input (an input artifact superseded mid-chain → claim refused, unit stays READY); hard-ceiling budget refusal → BLOCKED with evidence; duplicate dispatch at two different stations → no duplicate outputs or spend; a gate regression sweep — all three gates (HG2/HG4/HG5) refuse before approval on the full-run production's siblings.
4. **Upgrade rehearsal (§18).** Using the registry's versioning: load a 1.1.0 variant seed (one operation title changed) into a scratch database alongside 1.0.0; a production pinned to 1.0.0 must be unaffected (its definitions and in-flight units unchanged) while a new production on 1.1.0 sees the variant. Any gap between what §18 requires and what the G1 registry supports is reported as a **finding**, not patched.
5. **Observability check.** The full-run production inspected through the G3 API/dashboard endpoints (units, gates, budget, artifacts, audit trail complete and consistent). Real-browser rendering remains NOT TESTED (G0-host-dependent) and G9 must not claim it.

## Proposed PASS criteria

1. The full-run production completes 01.12 → 16.12 with all assertions in scope item 1 green.
2. The 192-operation accounting report is generated and its classification matches the registry exactly (192 = 16 executed exits + 176 defined-and-chained).
3. Every failure-injection case lands in its specified state with evidence.
4. The upgrade rehearsal shows zero cross-version interference, or the gap is documented as a finding with evidence.
5. Regressions: all suites G1–G8 green (run as part of G9's own battery).
6. Independent verification of the G9 harness itself (own spot-checks of the full run, the accounting, and at least two failure cases).

## Out of scope

Fixes to G1–G8 (reported as findings for owner ruling), real providers/models, real distribution, OVHcloud deployment and queue mode (G0 — still BLOCKED on G0.6), arming evaluators (EXPERT < 50).

## After G9

The Factory programme's build sequence (G1–G9) is complete. Remaining owner-level items: G0 (host verification + deployment — BLOCKED on G0.6/OVHcloud provisioning, founder-side), OD-F03 (topology), OD-F06 (D-378 relationship), OD-F07, real provider binding through the neutral adapters, and the expert golden set (50+ EXPERT cases) that would let evaluators arm.
