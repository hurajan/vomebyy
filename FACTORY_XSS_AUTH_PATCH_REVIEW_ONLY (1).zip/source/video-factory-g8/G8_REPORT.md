# G8 REPORT — Station 6 (Steps 15–16): Distribute & Learn + publication gate HG5

**Status: COMPLETE + INDEPENDENTLY VERIFIED — ACCEPTED by Raj 2026-10-28 WITHOUT FREEZING.**
Lock: LOCK_G8.md (confirmed by Raj 2026-10-28 12:22 EDT, WITH publication gate (ii); kind HG5). Verifier report: evidence/G8_VERIFIER_REPORT.md (harness preserved alongside).

## What was built

- **Publication gate, permanent:** migration `005_g8_publication_gate_requirement.sql` in the G2 tree — data-only, idempotent INSERT of `derivative_package → HG5`; one setup_db line after 004. Every chain-built database now carries three gate rows: script→HG2, master_package→HG4, derivative_package→HG5. No coordinator logic change.
- **Station 6** (`~/workspace/video-factory-g8/`): mock workers :8794; station-06 workflow set (webhook `/webhook/dispatch-g8`). Because the derivative_package predates this station, station-06 ensures the HG5 gate **at the point of need**: on a 15.12 dispatch, before running the unit, it creates the gate on the CURRENT derivative_package (creation only — decision stays human, via the API). Workers: 15.12 → distribution_record (one publish record per derivative — id, sha256 and platform carried from the package, plus a mock platform post id); 16.12 → learning_record (mock actuals + a prediction-vs-actual comparison against the locked G7 predictions — one actuals entry per prediction, deltas and within-range flags as data, confidence limitations stated).

## Builder-cycle defect (found and fixed in-lock, disclosed to the verifier)

The first station-06 design fed the unit executor the gate-creation *response* instead of the dispatch payload, so claims carried no unit id and the battery recorded no refusal (planning events present, zero claim activity — caught from the audit trail; a direct API probe proved the coordinator itself refused correctly with 409). Fixed by a "Restore dispatch payload" step on both gate paths in the generator; the battery then behaved exactly as specified. The verifier independently confirmed the fix is present on both paths and that the battery now produces the refusal evidence.

## Evidence (builder)

- G8 suite 1/1: first 15.12 dispatch creates the HG5 gate (PENDING, exact package id+sha) and the unit is refused (READY, 0 attempts, no budget movement, `gate_claim_refused` evidence); after the human APPROVED decision, distribution proceeds; publications match the package hash-for-hash; duplicate dispatch changes nothing; 16.12 learning record covers every locked prediction exactly once; budget exactly 2 × 90¢.
- Regressions: G1 7/7, G2 22/22 (three gate rows present), G3 5/5, G4 2/2, G5 1/1, G6 3/3, G7 2/2.
- Infra note: the local PostgreSQL cluster reset during this build window (all scratch databases and the factory role vanished — the recurring host instability). The setup chain rebuilt everything from scratch; no product code was changed for it.

## Independent verification — VERIFIED, defects NONE

Own premise (own derivatives/payloads/prediction ranges), own dispatches, own checker (32/32): the full HG5 battery reproduced including a direct API claim → HTTP 409; no `decide` call in any G8 workflow; duplicate-dispatch idempotency confirmed; learning deltas recompute from the recorded actuals; tamper probe (one altered derivative sha) flagged for exactly that derivative; the disclosed payload fix confirmed in the generator and the generated workflow on both gate paths; migration 005 idempotence proven on a throwaway DB; a chain-only database carries all three gate rows; G2 diff confined to the 005 file + the setup line (coordinator.py untouched by G8). All suites re-run, none skipped: G1 7/7, G2 22/22, G3 5/5, G4 2/2, G5 1/1, G6 3/3, G7 2/2, G8 1/1.

## Not tested / limitations

Real platform APIs/posting and real metrics (mocks with real hash/reference discipline); prediction accuracy; real-browser rendering; G9 full-system verification (its own lock); OVHcloud/queue mode (G0). Evaluators remain advisory (EXPERT < 50).

**With G8, all six stations and all 16 steps of the Factory are built and independently verified. What remains in the programme: G9 (full-system verification) and G0 (host — BLOCKED on G0.6).**
