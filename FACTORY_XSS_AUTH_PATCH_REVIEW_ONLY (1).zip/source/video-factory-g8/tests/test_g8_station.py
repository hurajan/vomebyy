"""G8 end-to-end tests (LOCK_G8): Station 6 through n8n, the HG5
publication gate battery (gate created by station-06 at the point of
need), distribution reference integrity, duplicate-dispatch
idempotency, and the prediction-vs-actual learning record.

Requires tools/setup_env.py: API on 8730 (g8_station_scratch with all
three gate_requirements rows), G8 mock workers on 8794, n8n with the
G8 workflows active. Runs under the G2 venv interpreter (psycopg).
"""
import hashlib
import json
import sys
import time
import unittest
import urllib.request
import urllib.error
from pathlib import Path

import psycopg
from psycopg.rows import dict_row

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "driver"))
import dispatch as driver  # noqa: E402

API = "http://127.0.0.1:8730"
TOKEN = "dev-operator-token"
STORE = Path(__file__).resolve().parent.parent / "store"
# Gate G: produced contents live in the Gate D store, layered envelopes
GATE_D_STORE = (Path.home() / "workspace/video-factory-real-ai-programme"
                / "gate-d/storage_service/.store")


def content_of(art):
    raw = (GATE_D_STORE / "objects" / art["sha256"]).read_bytes()
    assert hashlib.sha256(raw).hexdigest() == art["sha256"]
    doc = json.loads(raw)
    if isinstance(doc, dict) and doc.get("output_artifacts"):
        return doc["output_artifacts"][0]["content"]
    return doc
DSN = "host=127.0.0.1 dbname=g8_station_scratch user=factory password=factory_dev_local"

DERIVS = [{"id": "D-vertical", "format": "9:16", "platform": "shorts"},
          {"id": "D-square", "format": "1:1", "platform": "feed"},
          {"id": "D-thumb", "format": "16:9", "platform": "thumbnail"}]
PORTFOLIO = {"kind": "derivative_portfolio", "master_ref": "fixture-master",
             "derivatives": DERIVS,
             "predictions": {d["id"]: {"view_range": [8000, 20000],
                                        "ctr_band": "3-5%",
                                        "confidence": "LOW — mock prediction record"}
                             for d in DERIVS},
             "predictions_locked": True}
PACKAGE = {"kind": "derivative_package", "master_ref": "fixture-master",
           "derivatives": [{**d, "payload": f"g7-derivative-payload-{d['id']}",
                            "sha256": hashlib.sha256(
                                f"g7-derivative-payload-{d['id']}".encode()).hexdigest()}
                           for d in DERIVS],
           "upload_manifest": {"files": [d["id"] for d in DERIVS],
                               "master_ref": "fixture-master",
                               "metadata": {"title": "Mock upload package",
                                            "visibility": "unlisted"}}}


def call(method, path, body=None, expect=(200, 201)):
    req = urllib.request.Request(API + path, method=method)
    req.add_header("X-Operator-Token", TOKEN)
    data = None
    if body is not None:
        data = json.dumps(body).encode()
        req.add_header("Content-Type", "application/json")
    try:
        with urllib.request.urlopen(req, data=data, timeout=15) as r:
            out = json.loads(r.read() or b"{}")
            status = r.status
    except urllib.error.HTTPError as e:
        status, out = e.code, json.loads(e.read() or b"{}")
    assert status in expect, f"{method} {path} -> {status}: {out}"
    return out


def unit_state(pid, unit_id):
    units = call("GET", f"/productions/{pid}/units")["units"]
    return [u for u in units if u["unit_id"] == unit_id][0]


def wait_state(pid, unit_id, target, timeout=120):
    deadline = time.time() + timeout
    last = None
    while time.time() < deadline:
        last = unit_state(pid, unit_id)
        if last["state"] == target:
            return last
        time.sleep(2)
    raise AssertionError(f"unit stuck at {last and last['state']}, wanted {target}")


def drive_until(pid, unit_id, target="ACCEPTED", inputs_by_unit=None, timeout=240):
    """Gate G: acceptance now routes through evaluation + the driver's
    harness-as-human approval, so keep driving until the unit lands."""
    deadline = time.time() + timeout
    last = None
    while time.time() < deadline:
        driver.run_once(pid, inputs_by_unit=inputs_by_unit or {})
        last = unit_state(pid, unit_id)
        if last["state"] == target:
            return last
        time.sleep(2)
    raise AssertionError(f"unit stuck at {last and last['state']}, wanted {target}")


def refusals(unit_id):
    with psycopg.connect(DSN, row_factory=dict_row, autocommit=True) as conn:
        return conn.execute(
            "SELECT count(*) AS n FROM audit_events WHERE unit_id=%s"
            " AND event_type='gate_claim_refused'", (unit_id,)).fetchone()["n"]


class TestStation6(unittest.TestCase):
    def test_publication_gate_distribution_and_learning(self):
        p = call("POST", "/productions", {"title": "G8 premise",
                                          "hard_ceiling_cents": 1000000,
                                          "soft_ceiling_cents": 900000})
        pid = p["production_id"]
        run = call("POST", f"/productions/{pid}/runs", {"kind": "FULL"})["run_id"]

        def register(artifact_type, doc):
            content = json.dumps(doc, sort_keys=True)
            sha = hashlib.sha256(content.encode()).hexdigest()
            STORE.mkdir(parents=True, exist_ok=True)
            (STORE / f"{sha}.json").write_text(content)
            return call("POST", f"/productions/{pid}/artifacts",
                        {"artifact_type": artifact_type, "content": content,
                         "storage_uri": f"mock-store://{sha}"})

        portfolio = register("derivative_portfolio", PORTFOLIO)
        package = register("derivative_package", PACKAGE)

        def plan(op, key="main", depends=(), inputs=()):
            return call("POST", f"/productions/{pid}/units",
                        {"operation_id": op, "run_id": run, "unit_key": key,
                         "depends_on": list(depends),
                         "input_artifact_ids": list(inputs)})

        # --- HG5 battery: first dispatch creates the gate, claim refused
        u15 = plan("15.12", inputs=[package["artifact_id"]])["unit_id"]
        driver.run_once(pid, inputs_by_unit={u15: [package["artifact_id"]]})
        time.sleep(10)
        unit = unit_state(pid, u15)
        self.assertEqual(unit["state"], "READY")
        self.assertEqual(unit["current_attempt"], 0)
        self.assertEqual(call("GET", f"/productions/{pid}/budget")["reserved_cents"], 0)
        self.assertGreaterEqual(refusals(u15), 1)
        gates = [g for g in call("GET", f"/productions/{pid}/gates")["gates"]
                 if g["gate_kind"] == "HG5"]
        self.assertEqual(len(gates), 1)
        gate = gates[0]
        self.assertEqual(gate["artifact_id"], package["artifact_id"])
        self.assertEqual(gate["artifact_sha256"], package["sha256"])
        self.assertEqual(gate["verdict"], "PENDING")

        # --- approve -> distribution proceeds
        call("POST", f"/gates/{gate['gate_id']}/decide",
             {"decision": "APPROVED", "decided_by": "operator"})
        driver.redispatch(pid, u15, "15.12", inputs=[package["artifact_id"]])
        drive_until(pid, u15, "ACCEPTED")

        arts = call("GET", f"/productions/{pid}/artifacts")["artifacts"]
        dist = [a for a in arts if a["artifact_type"] == "distribution_record"]
        self.assertEqual(len(dist), 1)
        dist_doc = content_of(dist[0])
        self.assertEqual(dist_doc["package_ref"], package["artifact_id"])
        pubs = {r["derivative_id"]: r for r in dist_doc["publications"]}
        self.assertEqual(set(pubs), {d["id"] for d in DERIVS})
        for d in PACKAGE["derivatives"]:
            self.assertEqual(pubs[d["id"]]["sha256"], d["sha256"])
            self.assertTrue(pubs[d["id"]]["platform_post_id"])

        # --- duplicate dispatch changes nothing
        driver.redispatch(pid, u15, "15.12", inputs=[package["artifact_id"]])
        time.sleep(10)
        arts = call("GET", f"/productions/{pid}/artifacts")["artifacts"]
        self.assertEqual(len([a for a in arts
                              if a["artifact_type"] == "distribution_record"]), 1)
        self.assertEqual(call("GET", f"/productions/{pid}/budget")["spent_cents"], 90)

        # --- learning: every locked prediction gets exactly one actuals entry
        # Gate G fixture alignment: the learning builder consumes and
        # declares the portfolio (predictions) and the distribution
        # record (actuals) — those are its planned inputs.
        u16 = plan("16.12", depends=[u15],
                   inputs=[portfolio["artifact_id"],
                           dist[0]["artifact_id"]])["unit_id"]
        drive_until(pid, u16, "ACCEPTED", inputs_by_unit={
            u16: [portfolio["artifact_id"], dist[0]["artifact_id"]]})
        arts = call("GET", f"/productions/{pid}/artifacts")["artifacts"]
        learn = [a for a in arts if a["artifact_type"] == "learning_record"
                 and a["state"] == "CURRENT"][0]
        ldoc = content_of(learn)
        self.assertEqual(ldoc["portfolio_ref"], portfolio["artifact_id"])
        self.assertEqual(ldoc["distribution_ref"], dist[0]["artifact_id"])
        self.assertEqual(set(ldoc["comparison"]), set(PORTFOLIO["predictions"]))
        for deriv_id, entry in ldoc["comparison"].items():
            self.assertEqual(entry["predicted_range"],
                             PORTFOLIO["predictions"][deriv_id]["view_range"])
            self.assertIsInstance(entry["within_range"], bool)
            self.assertIn("delta_vs_midpoint", entry)

        budget = call("GET", f"/productions/{pid}/budget")
        self.assertEqual(budget["spent_cents"], 2 * 90)
        self.assertEqual(budget["reserved_cents"], 0)


if __name__ == "__main__":
    unittest.main(verbosity=2)
