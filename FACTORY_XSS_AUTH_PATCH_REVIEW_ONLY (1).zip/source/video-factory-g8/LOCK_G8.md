# LOCK G8 — Station 6 (Steps 15–16): Distribute & Learn + publication gate HG5

- **Confirmed by Raj:** 2026-10-28 12:22 EDT ("Confirm G8 lock WITH a publication gate (ii)"). The publication-gate question in the lock request is therefore ruled **(ii)**: publishing is human-gated. Gate kind **HG5** — the kind proposed in the lock-confirmation message, not objected to; recorded here as part of the confirmed package.
- **Entry condition met:** G7 ACCEPTED (without freezing) 2026-10-28.
- **Baseline:** G1–G7 as accepted. Full scope text: ~/workspace/video-factory-g7/G8_LOCK_REQUEST.md (as confirmed).
- **Placement:** per the placement-(A) precedent Raj ruled in G7, the `derivative_package → HG5` row is PERMANENT: data-only migration 005 in the G2 tree + one setup_db line after 004. No coordinator logic change. The lock request's scope explicitly provided for this ("a data-only migration 005 in the G2 tree, authorized explicitly by the lock") and the lock was confirmed on that text.

## Design note — where the HG5 gate is created

The derivative_package is produced by Station 5 (14.12), not by a Station 6 unit, so the HG2/HG4 pattern (the producing station's flow creates the gate after its exit unit) cannot apply inside G8 without amending the accepted G7 tree. Instead, **station-06 ensures the gate at the point of need**: on a 15.12 dispatch, before running the unit, the flow loads the production's artifacts and creates the HG5 gate on the CURRENT derivative_package if none exists (creation only; duplicates tolerated exactly as in stations 03/05; the decision stays human, via the API). If Raj later wants creation moved into station-05's tail, that is a small future lock against G7 — not assumed here.

## In scope

1. New tree `~/workspace/video-factory-g8/`; own scratch DB `g8_station_scratch`; mock workers :8794; station-06 workflow set (webhook `/webhook/dispatch-g8`) in the shared n8n instance.
2. Mock workers (deterministic, reference-bearing JSON in the content-addressed store):
   - **15.12 → distribution_record** (15.12 = "Log takedowns and distribute published IDs to analytics"; 15.01 = "Resolve exact derivative hash"): one publish record per derivative from the production's CURRENT derivative_package — derivative id, sha256 carried from the package, platform, and a mock platform post id.
   - **16.12 → learning_record** (16.12 = "Persist learning with confidence limitations and close the loop"): mock actuals per derivative + a prediction-vs-actual comparison against the CURRENT derivative_portfolio's locked predictions — every prediction gets exactly one actuals entry; deltas and a within-range flag recorded as data; confidence limitations stated in the record (mock actuals).
3. The 15.12 unit takes the derivative_package as a planned input → the coordinator's gate-claim check enforces HG5. The 16.12 unit takes the derivative_package and derivative_portfolio as planned inputs (it runs after publication; HG5 will already be APPROVED in the happy path).
4. Premise fixtures: derivative_package + derivative_portfolio artifacts (G7-shaped contents) registered by the test — the operator stand-in for Station 5's output.

## PASS criteria

1. Publication gate battery through the real path: first 15.12 dispatch creates the HG5 gate (PENDING, exact package id+sha) and the unit is refused (READY, 0 attempts, no budget movement, `gate_claim_refused` evidence); after the human APPROVED decision, 15.12 proceeds to ACCEPTED.
2. distribution_record CURRENT; its derivative ids + hashes match the premise derivative_package exactly; every record carries a platform post id.
3. Duplicate dispatch of the accepted 15.12 unit changes nothing (one CURRENT distribution_record, budget unchanged).
4. 16.12 ACCEPTED; learning_record CURRENT; every locked prediction has exactly one actuals entry with a recorded delta; budget == 2 × 90¢, reserved 0.
5. Regressions: G1 7/7, G2 suite (22 incl. gate-claim tests, with three gate rows present), G3 5/5, G4 2/2, G5 1/1, G6 3/3, G7 2/2 (shared-API DB pointing explicit per suite).
6. Independent verification (own premise, own checker, tamper probe, own gate battery).

## Out of scope

Real platform APIs/OAuth/posting and real metrics (founder-side integrations), G9 full-system verification (its own lock), OVHcloud/queue mode (G0), coordinator logic changes, any amendment to the G7 tree (incl. moving HG5 creation into station-05).

## Recorded limitation (carried)

Distribution and metrics are mocks with real reference/hash discipline; what is verified is gating, reference integrity, idempotency, and the prediction-vs-actual structure — not real publication or real learning. Evaluators remain advisory (EXPERT < 50).
