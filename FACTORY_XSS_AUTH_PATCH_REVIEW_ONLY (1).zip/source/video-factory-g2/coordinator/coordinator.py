"""G2 Coordinator — single authoritative execution engine (A-Z Guide §7).

Python (OD-F02a), PostgreSQL 16 via psycopg. One Coordinator instance = one
writer process; all state changes go through the transition table below.
States are the OD-F05 ratified engine vocabulary (§7.1).
"""
import hashlib
import json
import uuid
from decimal import ROUND_HALF_UP, Decimal

import psycopg
from psycopg.rows import dict_row

# ---------------------------------------------------------------- transitions
# (from_state, event) -> to_state. Anything not listed is rejected.
TRANSITIONS = {
    ("READY", "claim"): "CLAIMED",
    ("CLAIMED", "start"): "RUNNING",
    ("RUNNING", "await_provider"): "AWAITING_PROVIDER",
    ("AWAITING_PROVIDER", "provider_resumed"): "RUNNING",
    ("RUNNING", "submit_candidate"): "VALIDATING",
    ("AWAITING_PROVIDER", "submit_candidate"): "VALIDATING",
    ("VALIDATING", "validation_passed"): "ACCEPTED",
    ("VALIDATING", "validation_failed_content"): "REPAIR_REQUIRED",
    ("VALIDATING", "validation_failed_deterministic"): "BLOCKED",
    ("VALIDATING", "validation_needs_human"): "AWAITING_HUMAN",
    ("AWAITING_HUMAN", "human_approved"): "ACCEPTED",
    ("AWAITING_HUMAN", "human_rejected"): "REPAIR_REQUIRED",
    ("CLAIMED", "transient_error"): "RETRY_WAIT",
    ("RUNNING", "transient_error"): "RETRY_WAIT",
    # Gate C (design B1.3, migration 010): a provider failure/stale-input
    # outcome while awaiting the provider parks the unit for retry.
    ("AWAITING_PROVIDER", "transient_error"): "RETRY_WAIT",
    ("RUNNING", "provider_unknown"): "UNKNOWN",
    ("AWAITING_PROVIDER", "provider_unknown"): "UNKNOWN",
    ("UNKNOWN", "reconciled_submitted"): "VALIDATING",
    ("UNKNOWN", "reconciled_failed"): "RETRY_WAIT",
    ("RETRY_WAIT", "retry_ready"): "READY",
    ("REPAIR_REQUIRED", "repair_ready"): "READY",
    ("PENDING", "cancel"): "CANCELLED",
    ("READY", "cancel"): "CANCELLED",
    ("CLAIMED", "cancel"): "CANCELLED",
    ("RUNNING", "cancel"): "CANCELLED",
    ("RETRY_WAIT", "cancel"): "CANCELLED",
    ("BLOCKED", "cancel"): "CANCELLED",
    ("READY", "block"): "BLOCKED",
    ("PENDING", "block"): "BLOCKED",
    # Gate F: the retry driver's terminal dead-letter transition. The
    # reason is carried explicitly by event(..., block_reason=...).
    ("RETRY_WAIT", "block"): "BLOCKED",
}
TERMINAL = {"ACCEPTED", "CANCELLED", "SUPERSEDED"}

# ------------------------------------------------------- Fix D-H1 (design b)
# Executor worker identities, one per serving tree. LOCK_FIX_DH1 §1/§2: the
# scheduler pre-stages each claim under the identity of the n8n executor that
# will serve the unit, so the executor can RESUME the pre-staged attempt
# instead of claiming again (the Gate H T9 deadlock: scheduler claimed as
# 'sched-<lane>', the executor's own claim then 409'd and it stopped).
# Gate 03 Option B (LOCK_GATE_03B): the mapping is derived from the
# REGISTRY station layout — station -> serving tree is 1,2 -> g4;
# 3 -> g5; 4 -> g6; 5 -> g7; 6 -> g8 — so the step ranges below
# (station spans in steps: S1 01-02, S2 03-04, S3 05-08, S4 09-11,
# S5 12-14, S6 15-16, grouped by tree) coincide exactly with the
# registry stations for all 16 steps. Step-derived and station-derived
# routing now agree everywhere (step 12 / station 5 -> g7, correcting
# the former G6-tree divergence); tests/test_fix_dh1.py asserts the
# agreement for all 192 operations.
# These strings MUST match EXECUTOR_WORKER_ID in each tree's
# tools/gen_workflows.py; tests/test_fix_dh1.py asserts the pairing
# against the generated unit-executor workflow JSONs.
EXECUTOR_WORKER_IDS = {
    "g4": "n8n-executor-g4",
    "g5": "n8n-executor-g5",
    "g6": "n8n-executor-g6",
    "g7": "n8n-executor-g7",
    "g8": "n8n-executor-g8",
}
_EXECUTOR_STEP_RANGES = ((1, 4, "g4"), (5, 8, "g5"), (9, 11, "g6"),
                         (12, 14, "g7"), (15, 16, "g8"))


def executor_worker_id_for_operation(operation_id):
    """Executor identity for an operation_id like '05.12' (step = prefix)."""
    step = int(str(operation_id).split(".")[0])
    for lo, hi, tree in _EXECUTOR_STEP_RANGES:
        if lo <= step <= hi:
            return EXECUTOR_WORKER_IDS[tree]
    raise ValueError(f"no executor tree serves step {step} "
                     f"(operation {operation_id!r})")


class CoordinatorError(Exception):
    pass


class UnauthorizedTransition(CoordinatorError):
    pass


class BudgetExceeded(CoordinatorError):
    pass


class _BudgetBlocked(Exception):
    """Internal: carries the projected total out of the rolled-back claim txn."""

    def __init__(self, projected):
        super().__init__("budget blocked")
        self.projected = projected


class _GateBlocked(Exception):
    """Internal (G6 amendment, LOCK_G6 Part A): carries the unsatisfied gate
    requirement out of the rolled-back claim txn so claim() can commit the
    refusal evidence before raising GateNotSatisfied."""

    def __init__(self, artifact_id, artifact_type, gate_kind):
        super().__init__("gate blocked")
        self.artifact_id = artifact_id
        self.artifact_type = artifact_type
        self.gate_kind = gate_kind


class StaleFencing(CoordinatorError):
    pass


class StaleInput(CoordinatorError):
    pass


class GateNotSatisfied(CoordinatorError):
    pass


class AdoptRefused(CoordinatorError):
    """Master Execution Programme Gate 02 (tasks 4-7): an adoption request
    for a scheduler-prestaged attempt was refused. `.reason` is
    machine-readable (attempt_not_found, unit_not_claimed, superseded,
    identity_mismatch, already_started, already_adopted, no_lease,
    lease_expired, stale_fencing). Refusal evidence is committed by
    adopt_attempt() before this is raised (gate-refusal pattern)."""

    def __init__(self, reason, detail=""):
        super().__init__(f"adoption refused: {reason}"
                         + (f" ({detail})" if detail else ""))
        self.reason = reason


class ConfigurationMissingError(CoordinatorError):
    """Gate C (design B2.3): no usable provider-config estimate for a claim —
    either a resolved binding carries no est_cost_cents and the caller gave
    no estimate, or no binding resolves and the caller gave no estimate.
    Fail-closed: zero attempts, no budget movement, audit evidence committed
    by claim() before this is raised (gate-refusal pattern)."""


class EstimateBelowConfigError(CoordinatorError):
    """Gate D (D-C1 correction, API claim path only): the request body's
    estimated_cents is below the resolved binding's est_cost_cents. The
    reservation is never written; an 'estimate_below_config' audit event is
    committed by claim() before this is raised. Library-mode claims keep
    the Gate C caller-wins behavior."""


class _EstimateBelowConfig(Exception):
    """Internal: carries the refused estimates out of the rolled-back claim
    transaction so claim() can commit the refusal evidence."""

    def __init__(self, operation_id, scope, config_est, caller_est):
        super().__init__("estimate below config")
        self.operation_id = operation_id
        self.scope = scope
        self.config_est = config_est
        self.caller_est = caller_est


class AssignmentCeilingExceeded(CoordinatorError):
    """MM-03 (C-01 decision): an ACTIVE operation_model_assignments row
    caps the operation's cost, and the claim's resolved estimate exceeds
    that ceiling. Fail-closed like the other claim refusals: zero
    attempts, no budget movement, an 'assignment_ceiling_exceeded' audit
    event committed by claim() before this is raised. PROPOSED
    assignments never reach this check — only a promoted (ACTIVE)
    assignment binds claims."""


class _AssignmentCeiling(Exception):
    """Internal: carries the ceiling detail out of the rolled-back claim
    transaction so claim() can commit the refusal evidence."""

    def __init__(self, operation_id, max_cost_cents, estimate_cents, policy_id):
        super().__init__("assignment ceiling exceeded")
        self.operation_id = operation_id
        self.max_cost_cents = max_cost_cents
        self.estimate_cents = estimate_cents
        self.policy_id = policy_id


class ArtifactHashMismatchError(CoordinatorError):
    """Gate D (LOCK_GATE_D §3): a caller-supplied expected sha256 differs
    from the staged content hash. Completion is refused, nothing is
    registered, the attempt stays in flight, and an
    'artifact_hash_mismatch' audit event is committed before this raises.
    The staged candidate stays STAGED (cleanup may abandon it)."""


class ChargeSettlementError(CoordinatorError):
    """Gate D (design B1.3/B3): settle_provider_charge refusal — the
    evidence row is not an unsettled PROVIDER_REPORTED charge, a FINALIZED
    row already cites the same (provider, provider_request_id), or the
    charge would breach the production's hard ceiling. MM-08: also the
    resolve_unresolved_charge refusals (not an UNRESOLVED row, already
    resolved, reservation no longer HELD, resolution inputs carry no
    calculable or reported amount, hard-ceiling breach)."""


class ProviderCapExceeded(CoordinatorError):
    """MM-08: a claim refused because the resolved provider's spend
    cap for the current window (settled + held, attributed by the
    attempts' pinned bindings) plus the claim estimate would exceed
    the cap. Committed 'provider_cap_refused' audit evidence; the
    unit's state is unchanged (the cap may clear with time or
    settlements, so — unlike the production budget path — the unit is
    NOT blocked)."""


class _ProviderCapBlocked(Exception):
    """Internal: carries provider-cap detail out of the rolled-back
    claim transaction so claim() can commit the refusal evidence."""

    def __init__(self, provider, cap_cents, settled_cents, held_cents,
                 estimate_cents):
        super().__init__("provider cap exceeded")
        self.provider = provider
        self.cap_cents = cap_cents
        self.settled_cents = settled_cents
        self.held_cents = held_cents
        self.estimate_cents = estimate_cents


class _ConfigMissing(Exception):
    """Internal: carries config-resolution detail out of the rolled-back
    claim transaction so claim() can commit the refusal evidence."""

    def __init__(self, operation_id, scope_found):
        super().__init__("configuration missing")
        self.operation_id = operation_id
        self.scope_found = scope_found


class PlanMissingError(CoordinatorError):
    """Gate 04 (G01-D01/D02): no execution plan resolves for the unit's
    operation at the current plan version. Fail-closed like
    ConfigurationMissingError: zero attempts, no budget movement, and a
    committed 'plan_missing' audit event before this is raised. There
    is no unplanned execution path."""


class _PlanMissing(Exception):
    """Internal: carries the operation id out of the rolled-back claim
    transaction so claim() can commit the refusal evidence."""

    def __init__(self, operation_id):
        super().__init__("execution plan missing")
        self.operation_id = operation_id


class ActionRecordRefused(CoordinatorError):
    """Gate 05 (GB-SEC-01 shape, Gate 04 follow-on): an action-record
    post whose presented worker identity does not match the attempt's
    claim identity. The refusal is committed audit evidence
    ('action_record_refused') before this is raised."""

    def __init__(self, reason, detail=""):
        super().__init__(f"action record refused: {reason}"
                         + (f" ({detail})" if detail else ""))
        self.reason = reason


class CancelRefused(CoordinatorError):
    """MM-04: a provider-job cancellation whose presented worker
    identity does not match the job attempt's claim identity. The
    refusal is committed audit evidence ('provider_job_cancel_refused')
    before this is raised (the claim/record refusal discipline)."""

    def __init__(self, reason, detail=""):
        super().__init__(f"provider job cancel refused: {reason}"
                         + (f" ({detail})" if detail else ""))
        self.reason = reason


class _CancelIdentityMismatch(Exception):
    """Internal: carries the identity detail out of the rolled-back
    cancel transaction so cancel_provider_job() can commit the
    refusal evidence."""

    def __init__(self, presented, expected, unit_id):
        super().__init__("provider job cancel identity mismatch")
        self.presented = presented
        self.expected = expected
        self.unit_id = unit_id


class _ActionIdentityMismatch(Exception):
    """Internal: carries the identity detail out of the rolled-back
    record transaction so record_action_attempt() can commit the
    refusal evidence (the claim() discipline)."""

    def __init__(self, presented, expected, action_key):
        super().__init__("action record identity mismatch")
        self.presented = presented
        self.expected = expected
        self.action_key = action_key


class CompletionBarrierError(CoordinatorError):
    """Gate 05 (programme tasks 6-7): a barrier-enforced completion
    whose attempt's pinned plan is not fully evidenced by terminal
    SUCCEEDED action records — a missing record, a FAILED/REFUSED
    record, an out-of-plan record, or no pinned plan at all. Raised
    only where the caller enforces the barrier (the API /complete
    path); the refusal is committed audit evidence
    ('completion_barrier_refused') before this is raised."""

    def __init__(self, detail):
        super().__init__(f"completion barrier refused: {detail}")
        self.detail = detail


CURRENT_PLAN_VERSION = "1.0.0"


class GateId(str):
    """FP-02 return value: a gate id that still behaves as the plain string
    every pre-Gate-C caller expects (decide_gate(gate, ...) keeps working),
    while also exposing the idempotence outcome: result['gate_id'] /
    result['existing'] / result.gate_id / result.existing."""

    def __new__(cls, gate_id, existing=False):
        obj = super().__new__(cls, gate_id)
        obj.gate_id = str(gate_id)
        obj.existing = bool(existing)
        return obj

    def __getitem__(self, key):
        if key == "gate_id":
            return self.gate_id
        if key == "existing":
            return self.existing
        return super().__getitem__(key)


def _uid():
    return str(uuid.uuid4())


def _sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


class Coordinator:
    def __init__(self, dsn: str, actor: str = "coordinator", environment: str = "test",
                 storage=None):
        self.conn = psycopg.connect(dsn, row_factory=dict_row, autocommit=False)
        self.actor = actor
        # Gate C: config resolution only sees bindings of this environment —
        # a production coordinator never resolves test bindings (design B2.3).
        self.environment = environment
        self.last_scheduler_report = {"claimed": [], "skipped_no_config": []}
        # Gate D: durable-storage client. Injected by tests (a LocalStorage
        # on a tmp root); otherwise built lazily from the environment on
        # first use (factory_from_env) so library-only consumers that never
        # stage content never touch the filesystem.
        self._storage = storage

    @property
    def storage(self):
        if self._storage is None:
            import sys
            from pathlib import Path
            gate_d = Path.home() / "workspace/video-factory-real-ai-programme/gate-d"
            if str(gate_d) not in sys.path:
                sys.path.insert(0, str(gate_d))
            from storage_service import factory_from_env
            self._storage = factory_from_env()
        return self._storage

    @storage.setter
    def storage(self, client):
        self._storage = client

    def close(self):
        self.conn.close()

    def _flush_reads(self):
        """End any dangling read transaction before opening a write transaction.
        With autocommit=False, a bare SELECT leaves a transaction open; a later
        transaction() block then nests as a savepoint whose effects never commit
        on their own (verifier defect D1 class). commit() on an idle connection
        is a no-op, so this is safe to call at the top of every write method.
        WARNING (re-verifier observation, 2026-10-27): the commit is unconditional
        — it would also commit any uncommitted work a future consumer performed
        by hand on this connection between coordinator calls. The connection is
        therefore private to the Coordinator: never expose it to callers."""
        self.conn.commit()

    # ------------------------------------------------------------- internals
    def _audit(self, cur, production_id, unit_id, event_type, old, new, payload=None):
        cur.execute(
            "INSERT INTO audit_events(production_id, unit_id, event_type, old_state, new_state, actor, payload)"
            " VALUES (%s,%s,%s,%s,%s,%s,%s)",
            (production_id, unit_id, event_type, old, new, self.actor,
             json.dumps(payload or {}, default=str)))

    def _unit(self, cur, unit_id):
        cur.execute("SELECT * FROM execution_units WHERE unit_id=%s FOR UPDATE", (unit_id,))
        row = cur.fetchone()
        if not row:
            raise CoordinatorError(f"unknown unit {unit_id}")
        return row

    def _set_state(self, cur, unit, new_state, event, payload=None, block_reason=None):
        old = unit["state"]
        cur.execute(
            "UPDATE execution_units SET state=%s, block_reason=%s WHERE unit_id=%s",
            (new_state, block_reason, unit["unit_id"]))
        self._audit(cur, unit["production_id"], unit["unit_id"], event, old, new_state, payload)

    def _transition(self, cur, unit, event, payload=None, block_reason=None):
        key = (unit["state"], event)
        if key not in TRANSITIONS:
            raise UnauthorizedTransition(f"{unit['state']} --{event}--> ? is not an allowed transition")
        self._set_state(cur, unit, TRANSITIONS[key], event, payload,
                        block_reason=block_reason)
        return TRANSITIONS[key]

    # ------------------------------------------- provider config (Gate C, B2)
    def _resolve_config(self, cur, unit, action_key=None):
        """Whole-row resolution, most specific scope wins:
        ACTION -> CAPABILITY -> OPERATION -> STATION -> FACTORY.
        Only ACTIVE rows of this coordinator's environment are visible.
        Returns the binding row dict, or None when nothing resolves."""
        cur.execute(
            "SELECT station, capability_slot FROM operation_definitions"
            " WHERE workflow_version=%s AND operation_id=%s",
            (unit["workflow_version_ref"], unit["operation_id"]))
        opdef = cur.fetchone() or {}
        station = opdef.get("station")
        slot = opdef.get("capability_slot")
        op = unit["operation_id"]
        action_key = action_key if action_key is not None else op
        probes = [
            ("scope='ACTION' AND operation_id=%s AND action_key=%s", (op, action_key)),
            ("scope='CAPABILITY' AND capability_slot=%s", (slot,)),
            ("scope='OPERATION' AND operation_id=%s", (op,)),
            ("scope='STATION' AND station=%s", (station,)),
            ("scope='FACTORY'", ()),
        ]
        for where, params in probes:
            cur.execute(
                f"SELECT * FROM provider_configs WHERE active AND environment=%s AND {where}"
                " ORDER BY version DESC LIMIT 1",
                (self.environment, *params))
            row = cur.fetchone()
            if row:
                return row
        return None

    @staticmethod
    def _config_snapshot(row):
        """Canonical snapshot of a resolved binding + its SHA-256 (INV-006)."""
        snap = dict(row)
        snap["config_id"] = str(snap["config_id"])
        canonical = json.dumps(snap, sort_keys=True, default=str)
        return snap, hashlib.sha256(canonical.encode()).hexdigest()

    def resolve_config_for_unit(self, unit_id, action_key=None):
        """Read-only resolution (scheduler estimate path / API reads)."""
        cur = self.conn.cursor()
        cur.execute("SELECT * FROM execution_units WHERE unit_id=%s", (unit_id,))
        unit = cur.fetchone()
        if not unit:
            raise CoordinatorError(f"unknown unit {unit_id}")
        return self._resolve_config(cur, unit, action_key)

    # ------------------------------------------- financial evidence (B3)
    def _evidence(self, cur, production_id, unit_id, attempt_id, provider, charge_class,
                  amount_cents, usage=None, provider_request_id=None, provider_job_id=None,
                  requires_reconciliation=False, pricing_version=None):
        cur.execute(
            "INSERT INTO financial_evidence(production_id, unit_id, attempt_id, provider_job_id,"
            " provider, provider_request_id, charge_class, amount_cents, usage,"
            " requires_reconciliation, pricing_version) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)",
            (production_id, unit_id, attempt_id, provider_job_id, provider,
             provider_request_id, charge_class, amount_cents,
             json.dumps(usage or {}, default=str), requires_reconciliation, pricing_version))

    # ---------------------------------------------------------- productions
    def create_production(self, title, hard_ceiling_cents, soft_ceiling_cents, created_by,
                          workflow_version="1.0.0"):
        self._flush_reads()
        pid = _uid()
        with self.conn.transaction():
            cur = self.conn.cursor()
            cur.execute(
                "INSERT INTO productions(production_id, title, workflow_version, hard_ceiling_cents,"
                " soft_ceiling_cents, created_by) VALUES (%s,%s,%s,%s,%s,%s)",
                (pid, title, workflow_version, hard_ceiling_cents, soft_ceiling_cents, created_by))
            self._audit(cur, pid, None, "production_created", None, "ACTIVE", {"title": title})
        return pid

    def start_run(self, production_id, kind, started_by):
        self._flush_reads()
        rid = _uid()
        with self.conn.transaction():
            cur = self.conn.cursor()
            cur.execute("INSERT INTO production_runs(run_id, production_id, kind, started_by)"
                        " VALUES (%s,%s,%s,%s)", (rid, production_id, kind, started_by))
        return rid

    def plan_unit(self, production_id, run_id, operation_id, unit_key="main", lane="text",
                  depends_on=(), input_artifact_ids=()):
        self._flush_reads()
        unit_id = _uid()
        with self.conn.transaction():
            cur = self.conn.cursor()
            cur.execute(
                "INSERT INTO execution_units(unit_id, production_id, run_id, operation_id, unit_key, lane)"
                " VALUES (%s,%s,%s,%s,%s,%s)", (unit_id, production_id, run_id, operation_id, unit_key, lane))
            for dep in depends_on:
                cur.execute("INSERT INTO unit_dependencies(unit_id, depends_on_unit) VALUES (%s,%s)",
                            (unit_id, dep))
            for art in input_artifact_ids:
                cur.execute("INSERT INTO unit_inputs(unit_id, artifact_id) VALUES (%s,%s)", (unit_id, art))
            self._audit(cur, production_id, unit_id, "unit_planned", None, "PENDING",
                        {"operation_id": operation_id, "unit_key": unit_key})
        self.recompute_readiness(production_id)
        return unit_id

    def recompute_readiness(self, production_id):
        self._flush_reads()
        """PENDING units whose dependencies are all ACCEPTED become READY."""
        with self.conn.transaction():
            cur = self.conn.cursor()
            cur.execute(
                "SELECT u.* FROM execution_units u WHERE u.production_id=%s AND u.state='PENDING'"
                " AND NOT EXISTS (SELECT 1 FROM unit_dependencies d JOIN execution_units p"
                "   ON p.unit_id=d.depends_on_unit WHERE d.unit_id=u.unit_id AND p.state<>'ACCEPTED')",
                (production_id,))
            for unit in cur.fetchall():
                self._set_state(cur, unit, "READY", "deps_met")

    # ------------------------------------------------- Gate 05 authority
    def _approval_policy_audit(self, cur, unit, mechanism, satisfied_by,
                               extra=None):
        """Gate 05 (G01-D06): at acceptance, record on the unit's audit
        trail which registry approval_policy applies to the unit's
        operation and how acceptance was reached. The policy string is
        never consulted for enforcement (enforcement lives in
        gate_requirements + the human paths — see gate-05
        APPROVAL_POLICY_MAP.md); this row is the provenance record.
        For the validation mechanism no human satisfied the policy:
        human_satisfied_by is null and the mechanism says so. Gate
        decisions bound to the unit's planned inputs are listed, so a
        gate-backed policy's decider is visible."""
        cur.execute(
            "SELECT approval_policy FROM operation_definitions"
            " WHERE operation_id=%s AND workflow_version=%s",
            (unit["operation_id"], unit["workflow_version_ref"]))
        row = cur.fetchone()
        gates = []
        cur.execute(
            "SELECT gr.gate_kind, hg.verdict, hg.decided_by FROM unit_inputs ui"
            " JOIN artifacts a ON a.artifact_id=ui.artifact_id"
            " JOIN gate_requirements gr ON gr.artifact_type=a.artifact_type"
            " JOIN human_gates hg ON hg.production_id=%s"
            "   AND hg.gate_kind=gr.gate_kind AND hg.artifact_id=a.artifact_id"
            " WHERE ui.unit_id=%s ORDER BY gr.gate_kind",
            (unit["production_id"], unit["unit_id"]))
        for g in cur.fetchall():
            gates.append({"gate_kind": g["gate_kind"], "verdict": g["verdict"],
                          "decided_by": g["decided_by"]})
        payload = {"approval_policy": row["approval_policy"] if row else None,
                   "mechanism": mechanism,
                   "human_satisfied_by": satisfied_by,
                   "input_gates": gates}
        if extra:
            payload.update(extra)
        self._audit(cur, unit["production_id"], unit["unit_id"],
                    "approval_policy_applied", unit["state"], "ACCEPTED",
                    payload)

    def audit_event_refusal(self, unit_id, event, reason, detail=None):
        """Gate 05 (G01-D07): committed evidence for an API events
        authorization refusal. The events route denies by role/event
        class BEFORE any transition is attempted; the refusal itself is
        recorded in its own transaction (the claim() evidence
        discipline). Returns the unit's unchanged state."""
        self._flush_reads()
        with self.conn.transaction():
            cur = self.conn.cursor()
            unit = self._unit(cur, unit_id)
            self._audit(cur, unit["production_id"], unit_id, "event_refused",
                        unit["state"], unit["state"],
                        {"event": event, "reason": reason, **(detail or {})})
            return unit["state"]

    def get_unit(self, unit_id):
        cur = self.conn.cursor()
        cur.execute("SELECT * FROM execution_units WHERE unit_id=%s", (unit_id,))
        return cur.fetchone()

    def event(self, unit_id, event, payload=None, block_reason=None):
        """Generic guarded transition for non-claim events.

        Gate F: ``block_reason`` is the explicit, backward-compatible way
        for a caller driving the ``block`` event to preserve its reason in
        execution_units.block_reason. Other events retain the existing
        behavior.

        Gate G: an event that lands the unit in ACCEPTED (the
        human_approved path — the only acceptance route the evaluation
        flow leaves open while the semantic layer is unarmed) promotes
        dependents exactly as validate-acceptance does; before Gate G,
        acceptance only ever arrived through validate, so the event
        path never needed the recompute."""
        self._flush_reads()
        with self.conn.transaction():
            cur = self.conn.cursor()
            unit = self._unit(cur, unit_id)
            new_state = self._transition(cur, unit, event, payload,
                                         block_reason=block_reason)
            production_id = unit["production_id"]
            if new_state == "ACCEPTED" and unit["state"] == "AWAITING_HUMAN":
                # Gate G: submit_validation closes the attempt as FAILED
                # whenever validation does not accept immediately —
                # including validation_needs_human. When the human then
                # approves, the accepted artifact IS that attempt's
                # candidate; close the attempt consistently.
                cur.execute(
                    "UPDATE action_attempts SET status='ACCEPTED'"
                    " WHERE unit_id=%s AND attempt_no=%s AND status='FAILED'",
                    (unit_id, unit["current_attempt"]))
                # Gate 05 (G01-D06): the human approval IS the policy
                # satisfaction event — record policy + approver.
                self._approval_policy_audit(
                    cur, unit, "human_approved", satisfied_by=self.actor)
        if new_state == "ACCEPTED":
            self.recompute_readiness(production_id)
        return new_state

    def retry_unit(self, unit_id):
        """F-G9-03 fix (LOCK_FIX_F-G9-03): make a RETRY_WAIT unit
        claimable again. Closes the failed attempt's dangling RUNNING
        action_attempts rows as FAILED (the completion path that
        normally closes them is never reached on the failure path),
        then emits retry_ready. Operator-driven via redispatch; no
        backoff or attempt cap is applied here — autonomous retry is
        G0 scope. Refuses from every other state."""
        self._flush_reads()
        with self.conn.transaction():
            cur = self.conn.cursor()
            unit = self._unit(cur, unit_id)
            if unit["state"] != "RETRY_WAIT":
                raise UnauthorizedTransition(
                    f"retry requires RETRY_WAIT, unit is {unit['state']}")
            # Release the failed attempts' HELD reservations (with the
            # RELEASE ledger entries the schema provides): the failure
            # path never releases them, so without this the money stays
            # held forever and every retry double-counts the ceiling.
            cur.execute(
                "SELECT a.reservation_id, b.estimated_cents FROM action_attempts a"
                " JOIN budget_reservations b ON b.reservation_id=a.reservation_id"
                " WHERE a.unit_id=%s AND a.status='RUNNING' AND b.state='HELD'",
                (unit_id,))
            released = 0
            for row in cur.fetchall():
                cur.execute(
                    "UPDATE budget_reservations SET state='RELEASED'"
                    " WHERE reservation_id=%s AND state='HELD'",
                    (row["reservation_id"],))
                if cur.rowcount:
                    cur.execute(
                        "INSERT INTO budget_transactions(production_id, kind,"
                        " amount_cents, reservation_id) VALUES (%s,'RELEASE',%s,%s)",
                        (unit["production_id"], row["estimated_cents"],
                         row["reservation_id"]))
                    released += 1
            cur.execute(
                "UPDATE action_attempts SET status='FAILED', finished_at=now()"
                " WHERE unit_id=%s AND status='RUNNING'", (unit_id,))
            closed = cur.rowcount
            return self._transition(cur, unit, "retry_ready",
                                    {"via": "retry_unit",
                                     "attempts_closed": closed,
                                     "reservations_released": released})

    # -------------------------------------------------------------- artifacts
    def register_artifact(self, production_id, artifact_type, data: bytes, storage_uri,
                          produced_by_unit=None, state="CURRENT", depends_on_artifact_ids=()):
        """Register an artifact; a new CURRENT version supersedes the previous CURRENT."""
        self._flush_reads()
        art_id = _uid()
        digest = _sha(data)
        # Gate G: persist the bytes in durable storage, content-addressed
        # by the same digest. The recorded storage_uri stays the caller's
        # (registrations name external fixtures), but every downstream
        # reader — the Gate E evaluation context, the Gate C worker
        # service — loads artifact bytes by sha from the store (the
        # Gate E loader's documented assumption); before Gate G only
        # completions ever landed there, so registered fixtures were
        # metadata without bytes.
        self.storage.promote(self.storage.put_candidate(data)["uri"])
        with self.conn.transaction():
            cur = self.conn.cursor()
            cur.execute(
                "SELECT COALESCE(MAX(version),0)+1 AS v FROM artifacts WHERE production_id=%s AND artifact_type=%s",
                (production_id, artifact_type))
            version = cur.fetchone()["v"]
            if state == "CURRENT":
                cur.execute(
                    "UPDATE artifacts SET state='SUPERSEDED' WHERE production_id=%s AND artifact_type=%s AND state='CURRENT'",
                    (production_id, artifact_type))
            cur.execute(
                "INSERT INTO artifacts(artifact_id, production_id, produced_by_unit, artifact_type, version,"
                " storage_uri, sha256, state) VALUES (%s,%s,%s,%s,%s,%s,%s,%s)",
                (art_id, production_id, produced_by_unit, artifact_type, version, storage_uri, digest, state))
            for consumed in depends_on_artifact_ids:
                cur.execute("SELECT version, sha256 FROM artifacts WHERE artifact_id=%s", (consumed,))
                c = cur.fetchone()
                cur.execute(
                    "INSERT INTO artifact_dependencies(consumer_artifact_id, consumed_artifact_id, consumed_version, consumed_sha256)"
                    " VALUES (%s,%s,%s,%s) ON CONFLICT DO NOTHING",
                    (art_id, consumed, c["version"], c["sha256"]))
        return {"artifact_id": art_id, "version": version, "sha256": digest}

    def verify_inputs_current(self, unit_id):
        """T-DEP-01 guard: a unit may not run on SUPERSEDED/INVALIDATED inputs."""
        cur = self.conn.cursor()
        cur.execute(
            "SELECT a.artifact_id, a.artifact_type, a.state FROM unit_inputs ui"
            " JOIN artifacts a ON a.artifact_id=ui.artifact_id WHERE ui.unit_id=%s", (unit_id,))
        bad = [r for r in cur.fetchall() if r["state"] != "CURRENT"]
        if bad:
            raise StaleInput(f"unit {unit_id} has non-current inputs: "
                             + ", ".join(f"{b['artifact_type']}({b['state']})" for b in bad))
        return True

    def _verify_input_gates(self, cur, unit):
        """G6 amendment (LOCK_G6 Part A): a unit may not be claimed against an
        input whose artifact type requires a human gate (gate_requirements,
        migration 003) unless an APPROVED gate is bound to that exact artifact
        id + hash (require_gate semantics). Runs inside the claim transaction,
        after the currency check and before any budget movement; raises the
        internal _GateBlocked so claim() can commit the refusal evidence."""
        cur.execute(
            "SELECT a.artifact_id, a.artifact_type, gr.gate_kind FROM unit_inputs ui"
            " JOIN artifacts a ON a.artifact_id=ui.artifact_id"
            " JOIN gate_requirements gr ON gr.artifact_type=a.artifact_type"
            " WHERE ui.unit_id=%s", (unit["unit_id"],))
        for row in cur.fetchall():
            try:
                self.require_gate(unit["production_id"], row["gate_kind"], row["artifact_id"])
            except GateNotSatisfied:
                raise _GateBlocked(row["artifact_id"], row["artifact_type"],
                                   row["gate_kind"]) from None
        return True

    # ----------------------------------------------------------------- budget
    @staticmethod
    def _spent_cents(cur, production_id):
        """Settled spend: SETTLED reservations plus standalone CHARGE ledger
        rows (Gate D settle_provider_charge writes CHARGE with no
        reservation; every Gate C-and-earlier CHARGE carries a reservation
        and is already counted through its SETTLED reservation, so this
        moves spent exactly once per charge)."""
        cur.execute(
            "SELECT COALESCE((SELECT SUM(settled_cents) FROM budget_reservations"
            "   WHERE production_id=%s AND state='SETTLED'),0)"
            " + COALESCE((SELECT SUM(amount_cents) FROM budget_transactions"
            "   WHERE production_id=%s AND kind='CHARGE' AND reservation_id IS NULL),0) AS s",
            (production_id, production_id))
        return cur.fetchone()["s"]

    @staticmethod
    def _held_cents(cur, production_id):
        cur.execute("SELECT COALESCE(SUM(estimated_cents),0) AS h FROM budget_reservations"
                    " WHERE production_id=%s AND state='HELD'", (production_id,))
        return cur.fetchone()["h"]

    # ------------------------------------- provider spend caps (MM-08)
    def _provider_cap(self, cur, provider):
        """The ACTIVE provider spend limit for this coordinator's
        environment (migration 018), or None — no row, no cap, no
        behavior change (every pre-MM-08 path is the proof)."""
        cur.execute(
            "SELECT * FROM provider_spend_limits WHERE provider=%s"
            " AND environment=%s AND active ORDER BY created_at DESC LIMIT 1",
            (provider, self.environment))
        return cur.fetchone()

    @staticmethod
    def _provider_window_position(cur, provider):
        """Settled + held spend attributed to a provider in the current
        window (v1: the UTC calendar day). Attribution is by the
        attempt's PINNED binding (action_attempts.resolved_config), so
        a fallback execution attributes to its provider — the executed
        model is recorded in evidence, but the model is not the
        provider. Reservation-backed spend is windowed on the
        reservation's created_at (when the spend was committed);
        standalone provider-charge settlements (Gate D
        settle_provider_charge — FINALIZED rows with basis
        'provider_charge_settled', which carry no reservation) are
        windowed on the evidence row's created_at."""
        cur.execute(
            "SELECT COALESCE(SUM(CASE WHEN r.state='SETTLED'"
            "   THEN r.settled_cents END),0) AS settled,"
            " COALESCE(SUM(CASE WHEN r.state='HELD'"
            "   THEN r.estimated_cents END),0) AS held"
            " FROM budget_reservations r"
            " JOIN action_attempts a ON a.reservation_id = r.reservation_id"
            " WHERE a.resolved_config->>'provider' = %s"
            " AND r.created_at >= (date_trunc('day', now() AT TIME ZONE 'UTC')"
            "                      AT TIME ZONE 'UTC')",
            (provider,))
        row = cur.fetchone()
        settled, held = int(row["settled"]), int(row["held"])
        cur.execute(
            "SELECT COALESCE(SUM(amount_cents),0) AS s FROM financial_evidence"
            " WHERE charge_class='FINALIZED' AND provider=%s"
            " AND usage->>'_finalization_basis' = 'provider_charge_settled'"
            " AND created_at >= (date_trunc('day', now() AT TIME ZONE 'UTC')"
            "                    AT TIME ZONE 'UTC')",
            (provider,))
        settled += int(cur.fetchone()["s"])
        return {"settled_cents": settled, "held_cents": held,
                "total_cents": settled + held}

    def budget_position(self, production_id):
        cur = self.conn.cursor()
        cur.execute("SELECT hard_ceiling_cents FROM productions WHERE production_id=%s", (production_id,))
        hard = cur.fetchone()["hard_ceiling_cents"]
        settled = self._spent_cents(cur, production_id)
        held = self._held_cents(cur, production_id)
        return {"hard_ceiling_cents": hard, "settled_cents": settled, "held_cents": held,
                "projected_cents": settled + held}

    def _maybe_soft_ceiling_notify(self, cur, production_id, spent_before, spent_after):
        """Gate D (LOCK_GATE_D §6): on a below->at-or-above crossing of the
        production's soft ceiling, write the audit event + an outbox
        'notification' event. Exactly once per crossing: the idempotency
        key carries the running count of prior crossings, so a later drop
        below the line and re-crossing notifies again while consecutive
        settlements above the line stay silent. Must be called inside the
        settlement transaction, after the money moved."""
        cur.execute("SELECT soft_ceiling_cents FROM productions WHERE production_id=%s",
                    (production_id,))
        prod = cur.fetchone()
        soft = prod["soft_ceiling_cents"] if prod else None
        if soft is None or not (spent_before < soft <= spent_after):
            return False
        cur.execute(
            "SELECT count(*) AS n FROM audit_events WHERE production_id=%s"
            " AND event_type='soft_ceiling_crossed'", (production_id,))
        crossing_no = cur.fetchone()["n"] + 1
        payload = {"kind": "soft_ceiling_crossed", "spent_cents": int(spent_after),
                   "soft_ceiling_cents": int(soft)}
        self._audit(cur, production_id, None, "soft_ceiling_crossed", None, None, payload)
        cur.execute(
            "INSERT INTO outbox_events(aggregate_type, aggregate_id, event_type, payload,"
            " idempotency_key) VALUES ('production',%s,'notification',%s,%s)"
            " ON CONFLICT (idempotency_key) DO NOTHING",
            (production_id, json.dumps(payload, default=str),
             f"soft-ceiling:{production_id}:{crossing_no}"))
        return True

    # ------------------------------------------- finance completion (Gate D, B3)
    _USAGE_KEY_FOR_KIND = {"input_token": "input_tokens", "output_token": "output_tokens",
                           "cached_token": "cached_tokens", "image": "images",
                           "media_second": "media_seconds", "request": "requests"}

    def _calculated_amount(self, cur, provider, model, usage):
        """CALCULATED amount from the price book (migration 012): ACTIVE
        rules for (provider, model), where a NULL-model rule matches any
        model. Only rules whose usage key is present in the attempt's usage
        are 'matched'; the matched rule with the latest created_at fixes
        the pricing_version, and only that version's rules are summed
        (a mixed-version book never blends). Returns (cents, version) or
        (None, None) when nothing matches — a price is never invented."""
        cur.execute(
            "SELECT * FROM pricing_rules WHERE active AND provider=%s"
            " AND (model IS NULL OR model=%s)", (provider, model))
        rules = [r for r in cur.fetchall()
                 if self._USAGE_KEY_FOR_KIND.get(r["unit_kind"]) in (usage or {})]
        if not rules:
            return None, None
        version = max(rules, key=lambda r: r["created_at"])["pricing_version"]
        total = Decimal(0)
        for r in rules:
            if r["pricing_version"] != version:
                continue
            qty = Decimal(str((usage or {})[self._USAGE_KEY_FOR_KIND[r["unit_kind"]]]))
            total += qty * Decimal(str(r["unit_price_cents"]))
        return int(total.quantize(Decimal("1"), rounding=ROUND_HALF_UP)), version

    def _finalization_tolerance_pct(self, cur):
        """finalization_tolerance_pct from the FACTORY binding's params
        (this coordinator's environment); default 10 (design B3)."""
        cur.execute(
            "SELECT params FROM provider_configs WHERE scope='FACTORY' AND active"
            " AND environment=%s ORDER BY version DESC LIMIT 1", (self.environment,))
        row = cur.fetchone()
        if row and row["params"] and row["params"].get("finalization_tolerance_pct") is not None:
            return Decimal(str(row["params"]["finalization_tolerance_pct"]))
        return Decimal(10)

    def _finalize_amount(self, cur, production_id, unit_id, attempt_id, provider, model,
                         usage, provider_request_id, provider_job_id,
                         reported_actual_cents, reported_cost_cents):
        """Write the completion's CALCULATED / PROVIDER_REPORTED evidence
        rows and exactly ONE FINALIZED row; return the FINALIZED amount
        (the amount settlement charges). Selection (LOCK_GATE_D §4):
        provider-reported within tolerance of calculated -> reported;
        else calculated; else provider-reported; else the attempt's
        reported actual (Gate C behavior). The FINALIZED row's usage JSON
        carries '_finalization_basis' (and '_pricing_version' when a price
        book applied). Mock flows have no rules and no provider report:
        FINALIZED = actual, basis 'reported_actual', as in Gate C."""
        usage = usage or {}
        calculated, version = self._calculated_amount(cur, provider, model, usage)
        if calculated is not None:
            self._evidence(cur, production_id, unit_id, attempt_id, provider,
                           "CALCULATED", calculated, usage=usage,
                           provider_request_id=provider_request_id,
                           provider_job_id=provider_job_id, pricing_version=version)
        if reported_cost_cents is not None:
            self._evidence(cur, production_id, unit_id, attempt_id, provider,
                           "PROVIDER_REPORTED", reported_cost_cents, usage=usage,
                           provider_request_id=provider_request_id,
                           provider_job_id=provider_job_id)
        if reported_cost_cents is not None and calculated is not None:
            tol = self._finalization_tolerance_pct(cur)
            within = (reported_cost_cents == calculated == 0) or (
                calculated != 0
                and abs(Decimal(reported_cost_cents) - Decimal(calculated)) * 100
                <= tol * Decimal(calculated))
            if within:
                basis, amount = "provider_reported", reported_cost_cents
            else:
                basis, amount = "calculated", calculated
        elif calculated is not None:
            basis, amount = "calculated", calculated
        elif reported_cost_cents is not None:
            basis, amount = "provider_reported", reported_cost_cents
        else:
            basis, amount = "reported_actual", reported_actual_cents
        final_usage = dict(usage)
        final_usage["_finalization_basis"] = basis
        if version is not None:
            final_usage["_pricing_version"] = version
        self._evidence(cur, production_id, unit_id, attempt_id, provider,
                       "FINALIZED", amount, usage=final_usage,
                       provider_request_id=provider_request_id,
                       provider_job_id=provider_job_id, pricing_version=version)
        return amount

    def settle_provider_charge(self, evidence_id, actor=None):
        """Gate D (design B1.3/B3): settle a failed/stale provider job's
        reported charge explicitly. The evidence row must be
        PROVIDER_REPORTED with requires_reconciliation=true; a FINALIZED
        row already citing the same (provider, provider_request_id) refuses
        the settle (the charge is never paid twice), as does a hard-ceiling
        breach. On success: a standalone CHARGE ledger row against the
        production (reservation_id NULL — budget_position counts standalone
        CHARGEs, so spent moves exactly once), the FINALIZED evidence row
        (basis 'provider_charge_settled'), requires_reconciliation cleared,
        an audit event, and the soft-ceiling check."""
        self._flush_reads()
        actor = actor or self.actor
        with self.conn.transaction():
            cur = self.conn.cursor()
            cur.execute("SELECT * FROM financial_evidence WHERE evidence_id=%s FOR UPDATE",
                        (evidence_id,))
            ev = cur.fetchone()
            if not ev:
                raise CoordinatorError(f"unknown financial evidence {evidence_id}")
            if ev["charge_class"] != "PROVIDER_REPORTED" or not ev["requires_reconciliation"]:
                raise ChargeSettlementError(
                    "evidence is not an unsettled provider-reported charge")
            if ev["provider_request_id"] is not None:
                cur.execute(
                    "SELECT count(*) AS n FROM financial_evidence WHERE charge_class='FINALIZED'"
                    " AND provider IS NOT DISTINCT FROM %s AND provider_request_id=%s",
                    (ev["provider"], ev["provider_request_id"]))
                if cur.fetchone()["n"]:
                    raise ChargeSettlementError(
                        "a FINALIZED row already cites this provider charge; refusing double settle")
            pid = ev["production_id"]
            amount = ev["amount_cents"]
            spent_before = self._spent_cents(cur, pid)
            cur.execute("SELECT hard_ceiling_cents FROM productions WHERE production_id=%s",
                        (pid,))
            hard = cur.fetchone()["hard_ceiling_cents"]
            if spent_before + self._held_cents(cur, pid) + amount > hard:
                raise ChargeSettlementError(
                    f"settling {amount} would breach the production hard ceiling {hard}")
            cur.execute(
                "INSERT INTO budget_transactions(production_id, kind, amount_cents,"
                " reservation_id, provider_job_id) VALUES (%s,'CHARGE',%s,NULL,%s)",
                (pid, amount, ev["provider_job_id"]))
            final_usage = dict(ev["usage"] or {})
            final_usage["_finalization_basis"] = "provider_charge_settled"
            cur.execute(
                "INSERT INTO financial_evidence(production_id, unit_id, attempt_id,"
                " provider_job_id, provider, provider_request_id, charge_class,"
                " amount_cents, usage) VALUES (%s,%s,%s,%s,%s,%s,'FINALIZED',%s,%s)"
                " RETURNING evidence_id",
                (pid, ev["unit_id"], ev["attempt_id"], ev["provider_job_id"],
                 ev["provider"], ev["provider_request_id"], amount,
                 json.dumps(final_usage, default=str)))
            finalized_id = cur.fetchone()["evidence_id"]
            cur.execute(
                "UPDATE financial_evidence SET requires_reconciliation=false"
                " WHERE evidence_id=%s", (evidence_id,))
            self._audit(cur, pid, ev["unit_id"], "provider_charge_settled", None, None,
                        {"evidence_id": str(evidence_id), "amount_cents": amount,
                         "provider": ev["provider"], "actor": actor})
            spent_after = self._spent_cents(cur, pid)
            self._maybe_soft_ceiling_notify(cur, pid, spent_before, spent_after)
            return {"evidence_id": str(finalized_id),
                    "settled_evidence_id": str(evidence_id),
                    "production_id": str(pid), "amount_cents": amount}

    # ------------------------- unresolved charges / missing usage (MM-08)
    @staticmethod
    def _usage_missing(usage):
        """True when a usage dict carries no measured line at all:
        empty, or every value absent / zero / non-numeric (the
        OpenRouter adapter yields {input_tokens: None, ...} when the
        provider response omits the usage object — normalized away by
        the gateway, but the completion path must not depend on that).
        Underscore keys are bookkeeping, not usage."""
        lines = {k: v for k, v in (usage or {}).items()
                 if not str(k).startswith("_")}
        return not any(isinstance(v, (int, float))
                       and not isinstance(v, bool) and v
                       for v in lines.values())

    def _missing_usage(self, snapshot, usage, reported_cost_cents):
        """MM-08 missing-usage detection: the attempt's pinned binding
        is a CREDENTIALED provider (the binding carries a
        credential_ref) and the completion brings no usage lines and
        no provider-reported cost — there is no measured cost, so the
        caller's integer (on the real path the estimate fallback) must
        never settle as if measured. Deterministic-local / mock /
        unbound attempts are never flagged: their reported actual is
        binding data, not missing usage."""
        if not snapshot or not snapshot.get("credential_ref"):
            return False
        if reported_cost_cents is not None:
            return False
        return self._usage_missing(usage)

    def _record_unresolved(self, cur, production_id, unit_id, attempt_id,
                           provider, amount_cents, provider_request_id,
                           provider_job_id):
        """Write the UNRESOLVED charge record inside the completion
        transaction: the amount at risk (the reservation's estimate —
        explicitly NOT a measured cost), flagged
        requires_reconciliation, plus the committed audit event and
        an operator-visible outbox notification. The reservation stays
        HELD; nothing settles. Returns the evidence id."""
        cur.execute(
            "INSERT INTO financial_evidence(production_id, unit_id, attempt_id,"
            " provider_job_id, provider, provider_request_id, charge_class,"
            " amount_cents, usage, requires_reconciliation)"
            " VALUES (%s,%s,%s,%s,%s,%s,'UNRESOLVED',%s,%s,true) RETURNING evidence_id",
            (production_id, unit_id, attempt_id, provider_job_id, provider,
             provider_request_id, amount_cents,
             json.dumps({"_unresolved_reason": "missing_usage"}, default=str)))
        evidence_id = cur.fetchone()["evidence_id"]
        payload = {"kind": "charge_unresolved", "attempt_id": str(attempt_id),
                   "provider": provider, "amount_cents": amount_cents,
                   "evidence_id": str(evidence_id),
                   "reason": "missing_usage"}
        self._audit(cur, production_id, unit_id, "charge_unresolved",
                    None, None, payload)
        cur.execute(
            "INSERT INTO outbox_events(aggregate_type, aggregate_id, event_type,"
            " payload, idempotency_key) VALUES ('attempt',%s,'notification',%s,%s)"
            " ON CONFLICT (idempotency_key) DO NOTHING",
            (attempt_id, json.dumps(payload, default=str),
             f"charge-unresolved:{attempt_id}"))
        return evidence_id

    def resolve_unresolved_charge(self, evidence_id, usage=None,
                                  reported_cost_cents=None,
                                  provider_request_id=None, actor=None):
        """MM-08: operator reconciliation of an UNRESOLVED charge. The
        operator posts the reconciled usage and/or the provider-
        reported amount; the NORMAL FINALIZED selection then runs on
        those inputs and the attempt's HELD reservation settles exactly
        once. Refusals (ChargeSettlementError): the row is not an
        UNRESOLVED charge; it was already resolved; the reservation is
        no longer HELD; a FINALIZED row already exists for the attempt;
        the inputs price to no calculable or reported amount (a
        resolution may not invent a number — and may never fall back
        to the estimate); or the settlement would breach the
        production's hard ceiling (the transaction rolls back, the
        charge stays unresolved)."""
        self._flush_reads()
        actor = actor or self.actor
        with self.conn.transaction():
            cur = self.conn.cursor()
            cur.execute("SELECT * FROM financial_evidence WHERE evidence_id=%s"
                        " FOR UPDATE", (evidence_id,))
            ev = cur.fetchone()
            if not ev:
                raise CoordinatorError(f"unknown financial evidence {evidence_id}")
            if ev["charge_class"] != "UNRESOLVED":
                raise ChargeSettlementError(
                    "evidence is not an unresolved charge")
            if not ev["requires_reconciliation"]:
                raise ChargeSettlementError(
                    "unresolved charge already resolved")
            if ev["attempt_id"] is None:
                raise ChargeSettlementError(
                    "unresolved charge carries no attempt linkage")
            cur.execute("SELECT * FROM action_attempts WHERE attempt_id=%s",
                        (ev["attempt_id"],))
            attempt = cur.fetchone()
            if attempt is None:
                raise ChargeSettlementError(
                    "unresolved charge's attempt no longer exists")
            cur.execute("SELECT * FROM budget_reservations WHERE reservation_id=%s",
                        (attempt["reservation_id"],))
            reservation = cur.fetchone()
            if reservation is None or reservation["state"] != "HELD":
                raise ChargeSettlementError(
                    "the attempt's reservation is no longer HELD; the "
                    "charge cannot settle through resolution")
            cur.execute(
                "SELECT count(*) AS n FROM financial_evidence"
                " WHERE attempt_id=%s AND charge_class='FINALIZED'",
                (ev["attempt_id"],))
            if cur.fetchone()["n"]:
                raise ChargeSettlementError(
                    "a FINALIZED row already exists for this attempt; "
                    "refusing a second settlement")
            pid = ev["production_id"]
            snapshot = attempt["resolved_config"] or {}
            model = snapshot.get("model")
            provider = ev["provider"]
            req_id = provider_request_id or ev["provider_request_id"]
            calculated, _ver = self._calculated_amount(
                cur, provider, model, usage or {})
            if calculated is None and reported_cost_cents is None:
                raise ChargeSettlementError(
                    "resolution requires reconciled usage that prices "
                    "under the provider's pricing rules, or a "
                    "provider-reported amount — never the estimate")
            spent_before = self._spent_cents(cur, pid)
            finalized = self._finalize_amount(
                cur, pid, ev["unit_id"], ev["attempt_id"], provider, model,
                usage, req_id, ev["provider_job_id"], None,
                reported_cost_cents)
            cur.execute("SELECT hard_ceiling_cents FROM productions"
                        " WHERE production_id=%s", (pid,))
            hard = cur.fetchone()["hard_ceiling_cents"]
            projected_after = (spent_before + self._held_cents(cur, pid)
                               - reservation["estimated_cents"] + finalized)
            if projected_after > hard:
                raise ChargeSettlementError(
                    f"resolving at {finalized} would breach the production "
                    f"hard ceiling {hard}; the charge stays unresolved")
            self._settle_reservation(cur, pid, attempt["reservation_id"],
                                     finalized)
            cur.execute(
                "UPDATE action_attempts SET actual_cost_cents=%s"
                " WHERE attempt_id=%s", (finalized, ev["attempt_id"]))
            cur.execute(
                "UPDATE financial_evidence SET requires_reconciliation=false"
                " WHERE evidence_id=%s", (evidence_id,))
            cur.execute(
                "SELECT usage FROM financial_evidence WHERE attempt_id=%s"
                " AND charge_class='FINALIZED' ORDER BY created_at DESC LIMIT 1",
                (ev["attempt_id"],))
            basis = (cur.fetchone()["usage"] or {}).get("_finalization_basis")
            self._audit(cur, pid, ev["unit_id"], "charge_resolved", None, None,
                        {"evidence_id": str(evidence_id),
                         "attempt_id": str(ev["attempt_id"]),
                         "amount_cents": finalized, "basis": basis,
                         "provider": provider, "actor": actor})
            self._maybe_soft_ceiling_notify(
                cur, pid, spent_before, self._spent_cents(cur, pid))
            return {"evidence_id": str(evidence_id),
                    "production_id": str(pid), "amount_cents": finalized,
                    "basis": basis}

    # ------------------------------------------------------------------ claim
    def claim(self, unit_id, worker_id, estimated_cents=None, lease_ttl_s=600,
              estimate_mode="library"):
        """Atomic: budget check + reservation + lease + fencing + CLAIMED + outbox.
        A budget rejection is itself a committed state change (BLOCKED + audit):
        the claim transaction raises _BudgetBlocked, rolls back, and the BLOCKED
        write is then committed in its own transaction before BudgetExceeded
        reaches the caller. A gate rejection (G6 amendment) follows the same
        evidence discipline but changes no state: the gate_claim_refused audit
        event is committed in its own transaction before GateNotSatisfied.
        Gate C: provider config is resolved inside the claim transaction and
        pinned on the attempt as a snapshot + hash (B2). A caller-supplied
        estimate wins when given (every pre-Gate-C caller); when the caller
        gives none, the binding's est_cost_cents is the estimate; when neither
        exists the claim fails closed with ConfigurationMissingError and a
        committed configuration_missing audit event.
        Gate D (D-C1 correction): estimate_mode='api' (the HTTP claim path)
        enforces the resolved binding — the effective estimate IS the
        config's est_cost_cents regardless of the body; a body estimate
        below it is refused with EstimateBelowConfigError and a committed
        estimate_below_config audit event. Library mode is unchanged."""
        self._flush_reads()
        try:
            return self._claim_txn(unit_id, worker_id, estimated_cents, lease_ttl_s,
                                   estimate_mode)
        except _EstimateBelowConfig as eb:
            with self.conn.transaction():
                cur = self.conn.cursor()
                unit = self._unit(cur, unit_id)
                self._audit(cur, unit["production_id"], unit_id, "estimate_below_config",
                            unit["state"], unit["state"],
                            {"worker_id": worker_id, "operation_id": eb.operation_id,
                             "scope_found": eb.scope, "config_estimate_cents": eb.config_est,
                             "caller_estimate_cents": eb.caller_est})
            raise EstimateBelowConfigError(
                f"claim refused: caller estimate {eb.caller_est} is below the resolved "
                f"{eb.scope} binding estimate {eb.config_est} for operation "
                f"{eb.operation_id}") from None
        except _ConfigMissing as cm:
            with self.conn.transaction():
                cur = self.conn.cursor()
                unit = self._unit(cur, unit_id)
                self._audit(cur, unit["production_id"], unit_id, "configuration_missing",
                            unit["state"], unit["state"],
                            {"worker_id": worker_id, "operation_id": cm.operation_id,
                             "scope_found": cm.scope_found})
            raise ConfigurationMissingError(
                f"claim refused: no provider-config estimate for operation "
                f"{cm.operation_id} (resolved scope: {cm.scope_found}) and no "
                f"caller estimate supplied") from None
        except _AssignmentCeiling as ac:
            with self.conn.transaction():
                cur = self.conn.cursor()
                unit = self._unit(cur, unit_id)
                self._audit(cur, unit["production_id"], unit_id,
                            "assignment_ceiling_exceeded",
                            unit["state"], unit["state"],
                            {"worker_id": worker_id,
                             "operation_id": ac.operation_id,
                             "assignment_max_cost_cents": ac.max_cost_cents,
                             "estimate_cents": ac.estimate_cents,
                             "policy_id": ac.policy_id})
            raise AssignmentCeilingExceeded(
                f"claim refused: resolved estimate {ac.estimate_cents} exceeds "
                f"the ACTIVE model assignment ceiling {ac.max_cost_cents} for "
                f"operation {ac.operation_id} (policy {ac.policy_id})") from None
        except _ProviderCapBlocked as pc:
            with self.conn.transaction():
                cur = self.conn.cursor()
                unit = self._unit(cur, unit_id)
                self._audit(cur, unit["production_id"], unit_id,
                            "provider_cap_refused",
                            unit["state"], unit["state"],
                            {"worker_id": worker_id,
                             "operation_id": unit["operation_id"],
                             "provider": pc.provider,
                             "cap_cents": pc.cap_cents,
                             "window_settled_cents": pc.settled_cents,
                             "window_held_cents": pc.held_cents,
                             "estimate_cents": pc.estimate_cents})
            raise ProviderCapExceeded(
                f"claim refused: provider {pc.provider} window spend "
                f"{pc.settled_cents}+{pc.held_cents} (settled+held) plus "
                f"estimate {pc.estimate_cents} exceeds the provider "
                f"spend cap {pc.cap_cents} for the current window") from None
        except _PlanMissing as pm:
            with self.conn.transaction():
                cur = self.conn.cursor()
                unit = self._unit(cur, unit_id)
                self._audit(cur, unit["production_id"], unit_id, "plan_missing",
                            unit["state"], unit["state"],
                            {"worker_id": worker_id, "operation_id": pm.operation_id,
                             "plan_version": CURRENT_PLAN_VERSION})
            raise PlanMissingError(
                f"claim refused: no execution plan for operation "
                f"{pm.operation_id} at plan version {CURRENT_PLAN_VERSION} "
                f"(operation_execution_plans is empty for this operation — "
                f"run the Gate 04 plan load)") from None
        except _GateBlocked as gb:
            with self.conn.transaction():
                cur = self.conn.cursor()
                unit = self._unit(cur, unit_id)
                self._audit(cur, unit["production_id"], unit_id, "gate_claim_refused",
                            unit["state"], unit["state"],
                            {"worker_id": worker_id, "artifact_id": gb.artifact_id,
                             "artifact_type": gb.artifact_type, "gate_kind": gb.gate_kind})
            raise GateNotSatisfied(
                f"claim refused: input {gb.artifact_type} requires an APPROVED "
                f"{gb.gate_kind} gate bound to artifact {gb.artifact_id}") from None
        except _BudgetBlocked as blocked:
            with self.conn.transaction():
                cur = self.conn.cursor()
                unit = self._unit(cur, unit_id)
                if unit["state"] == "READY":
                    self._set_state(cur, unit, "BLOCKED", "budget_exceeded",
                                    {"estimated_cents": estimated_cents,
                                     "projected_cents": blocked.projected},
                                    block_reason="PRODUCTION_BUDGET_EXCEEDED")
            raise BudgetExceeded(
                f"projected {blocked.projected}+{estimated_cents} exceeds the production ceiling") from None

    def _claim_txn(self, unit_id, worker_id, estimated_cents, lease_ttl_s=600,
                   estimate_mode="library"):
        with self.conn.transaction():
            cur = self.conn.cursor()
            unit = self._unit(cur, unit_id)
            if unit["state"] != "READY":
                raise UnauthorizedTransition(f"claim requires READY, unit is {unit['state']}")
            # Gate C (B2): resolve the provider binding inside the claim
            # transaction; the snapshot is pinned on the attempt below.
            config = self._resolve_config(cur, unit)
            if estimate_mode == "api" and config is not None \
                    and config["est_cost_cents"] is not None:
                # Gate D (D-C1): on the API path the binding is authoritative.
                if estimated_cents is not None and estimated_cents < config["est_cost_cents"]:
                    raise _EstimateBelowConfig(unit["operation_id"], config["scope"],
                                               config["est_cost_cents"], estimated_cents)
                effective_estimate = config["est_cost_cents"]
            elif estimated_cents is not None:
                effective_estimate = estimated_cents
            elif config is not None:
                effective_estimate = config["est_cost_cents"]
            else:
                effective_estimate = None
            if effective_estimate is None:
                raise _ConfigMissing(unit["operation_id"],
                                     config["scope"] if config else None)
            estimated_cents = effective_estimate
            # MM-03: an ACTIVE model assignment (a promoted registry
            # policy) contributes its C-01 ceiling + a pin. Absent an
            # ACTIVE assignment this block is inert — claim behavior is
            # exactly as before (the registry's design constraint).
            assignment = cur.execute(
                "SELECT * FROM operation_model_assignments"
                " WHERE operation_id=%s AND status='ACTIVE'",
                (unit["operation_id"],)).fetchone()
            if assignment is not None \
                    and assignment["max_cost_cents"] is not None \
                    and estimated_cents > assignment["max_cost_cents"]:
                raise _AssignmentCeiling(unit["operation_id"],
                                         assignment["max_cost_cents"],
                                         estimated_cents,
                                         assignment["policy_id"])
            # Gate 04: resolve the operation's execution plan inside the
            # claim transaction and pin it on the attempt. No plan, no
            # claim — the generic fallthrough is gone at the source.
            plan_row = cur.execute(
                "SELECT plan_id, plan_version, plan_hash, plan FROM "
                "operation_execution_plans WHERE operation_id=%s AND "
                "plan_version=%s",
                (unit["operation_id"], CURRENT_PLAN_VERSION)).fetchone()
            if plan_row is None:
                raise _PlanMissing(unit["operation_id"])
            self.verify_inputs_current(unit_id)
            self._verify_input_gates(cur, unit)
            # serialize budget per production
            cur.execute("SELECT * FROM productions WHERE production_id=%s FOR UPDATE",
                        (unit["production_id"],))
            pos = self.budget_position(unit["production_id"])
            if pos["projected_cents"] + estimated_cents > pos["hard_ceiling_cents"]:
                raise _BudgetBlocked(pos["projected_cents"])
            # MM-08: provider spend cap. Data-driven (migration 018);
            # absent a cap row this block never runs. The advisory
            # lock keyed on the provider serializes concurrent claims
            # across productions inside the cap check, so the
            # settled+held window total the check reads cannot be
            # raced past the cap.
            if config is not None:
                cap_row = self._provider_cap(cur, config["provider"])
                if cap_row is not None:
                    cur.execute(
                        "SELECT pg_advisory_xact_lock(hashtext(%s))",
                        ("mm08:provider-cap:" + config["provider"],))
                    wpos = self._provider_window_position(cur, config["provider"])
                    if wpos["total_cents"] + estimated_cents > cap_row["cap_cents"]:
                        raise _ProviderCapBlocked(
                            config["provider"], cap_row["cap_cents"],
                            wpos["settled_cents"], wpos["held_cents"],
                            estimated_cents)
            fencing = unit["fencing_token"] + 1
            attempt_no = unit["current_attempt"] + 1
            reservation_id = _uid()
            cur.execute(
                "INSERT INTO budget_reservations(reservation_id, production_id, unit_id, estimated_cents)"
                " VALUES (%s,%s,%s,%s)", (reservation_id, unit["production_id"], unit_id, estimated_cents))
            cur.execute(
                "INSERT INTO budget_transactions(production_id, kind, amount_cents, reservation_id)"
                " VALUES (%s,'RESERVE',%s,%s)", (unit["production_id"], estimated_cents, reservation_id))
            cur.execute(
                "INSERT INTO worker_leases(unit_id, worker_id, fencing_token, expires_at)"
                " VALUES (%s,%s,%s, now() + (%s || ' seconds')::interval)"
                " ON CONFLICT (unit_id) DO UPDATE SET worker_id=EXCLUDED.worker_id,"
                " fencing_token=EXCLUDED.fencing_token, lease_token=gen_random_uuid(),"
                " acquired_at=now(), heartbeat_at=now(), expires_at=EXCLUDED.expires_at",
                (unit_id, worker_id, fencing, lease_ttl_s))
            attempt_id = _uid()
            snapshot = snap_hash = config_id = None
            if config is not None:
                snapshot, snap_hash = self._config_snapshot(config)
                config_id = config["config_id"]
            if assignment is not None:
                # MM-03: pin the ACTIVE model assignment into the
                # attempt's config snapshot (same canonical hash — one
                # pin, so the attempt's provenance covers both the
                # resolved binding and the governing assignment even
                # after a later promotion changes the defaults).
                if snapshot is None:
                    snapshot = {}
                snapshot["model_assignment"] = {
                    "policy_id": assignment["policy_id"],
                    "role": assignment["role"],
                    "matrix_version": assignment["matrix_version"],
                    "primary_model": assignment["primary_model"],
                    "fallback_model": assignment["fallback_model"],
                    "evaluation_model": assignment["evaluation_model"],
                    "max_cost_cents": assignment["max_cost_cents"],
                }
                snap_hash = hashlib.sha256(json.dumps(
                    snapshot, sort_keys=True, default=str).encode()).hexdigest()
            cur.execute(
                "INSERT INTO action_attempts(attempt_id, unit_id, attempt_no, worker_id, reservation_id,"
                " config_id, resolved_config, resolved_config_hash, plan_id, plan_version, plan_hash)"
                " VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)",
                (attempt_id, unit_id, attempt_no, worker_id, reservation_id,
                 config_id, json.dumps(snapshot, default=str) if snapshot else None, snap_hash,
                 plan_row["plan_id"], plan_row["plan_version"], plan_row["plan_hash"]))
            # Gate 04: materialize the plan's action instances for this
            # unit (the migration-002 skeleton finally gets rows) so the
            # unit's planned actions are queryable state, not just JSON.
            plan_body = plan_row["plan"]
            if isinstance(plan_body, str):
                plan_body = json.loads(plan_body)
            for action in plan_body["actions"]:
                cur.execute(
                    "INSERT INTO action_instances(unit_id, action_id, mandatory, state)"
                    " VALUES (%s,%s,true,'PENDING') ON CONFLICT (unit_id, action_id) DO NOTHING",
                    (unit_id, action["action_key"]))
            self._evidence(cur, unit["production_id"], unit_id, attempt_id,
                           config["provider"] if config else "mock",
                           "ESTIMATED", estimated_cents)
            cur.execute(
                "UPDATE execution_units SET fencing_token=%s, current_attempt=%s WHERE unit_id=%s",
                (fencing, attempt_no, unit_id))
            unit = dict(unit, fencing_token=fencing, current_attempt=attempt_no)
            self._transition(cur, unit, "claim", {"worker_id": worker_id, "fencing_token": fencing})
            cur.execute(
                "INSERT INTO outbox_events(aggregate_type, aggregate_id, event_type, payload, idempotency_key)"
                " VALUES ('unit',%s,'dispatch',%s,%s) ON CONFLICT (idempotency_key) DO NOTHING",
                (unit_id, json.dumps({"worker_id": worker_id, "attempt_no": attempt_no}),
                 f"dispatch:{unit_id}:{attempt_no}"))
            return {"unit_id": unit_id, "attempt_no": attempt_no, "fencing_token": fencing,
                    "reservation_id": reservation_id, "attempt_id": attempt_id,
                    "plan_id": plan_row["plan_id"],
                    "plan_version": plan_row["plan_version"],
                    "plan_hash": plan_row["plan_hash"]}

    def record_action_attempt(self, unit_id, attempt_id, fencing_token,
                              action_key, seq, status, inputs_hash=None,
                              output_summary=None, cost_cents=0, error=None,
                              recorded_by="worker-service", worker_id=None):
        """Gate 04: persist one plan-action execution record for an
        in-flight attempt. The record is validated against the attempt's
        pinned plan (plan_id/version/hash are copied from the attempt,
        never trusted from the caller) and the unit's live fencing
        token. Idempotent: (attempt_id, action_key) is unique — a
        replay returns the stored record unchanged. A REFUSED record
        (an UNBOUND action the worker refused to execute) is first-class
        evidence, not an error.

        Gate 05 (Gate 04 follow-on): when worker_id is presented (the
        API path always presents it), it must equal BOTH the attempt's
        claim identity and the live lease holder — the GB-SEC-01 shape
        /complete enforces. A mismatch raises _ActionIdentityMismatch
        inside the transaction; the refusal is then committed as
        'action_record_refused' audit evidence and re-raised as
        ActionRecordRefused. Library callers that omit worker_id keep
        the fencing + plan validation only."""
        self._flush_reads()
        if status not in ("SUCCEEDED", "FAILED", "REFUSED"):
            raise CoordinatorError(f"invalid action record status {status!r}")
        try:
            return self._record_action_attempt_txn(
                unit_id, attempt_id, fencing_token, action_key, seq, status,
                inputs_hash, output_summary, cost_cents, error, recorded_by,
                worker_id)
        except _ActionIdentityMismatch as m:
            with self.conn.transaction():
                cur = self.conn.cursor()
                unit = self._unit(cur, unit_id)
                self._audit(cur, unit["production_id"], unit_id,
                            "action_record_refused", unit["state"],
                            unit["state"],
                            {"reason": "identity_mismatch",
                             "action_key": m.action_key,
                             "attempt_id": attempt_id,
                             "presented_worker_id": m.presented,
                             "attempt_worker_id": m.expected})
            raise ActionRecordRefused(
                "identity_mismatch",
                f"presented worker {m.presented!r}, attempt claimed by "
                f"{m.expected!r}") from None

    def _record_action_attempt_txn(self, unit_id, attempt_id, fencing_token,
                                   action_key, seq, status, inputs_hash,
                                   output_summary, cost_cents, error,
                                   recorded_by, worker_id):
        with self.conn.transaction():
            cur = self.conn.cursor()
            unit = self._unit(cur, unit_id)
            lease = cur.execute(
                "SELECT worker_id, fencing_token FROM worker_leases "
                "WHERE unit_id=%s", (unit_id,)).fetchone()
            if lease is None or lease["fencing_token"] != fencing_token:
                raise StaleFencing(
                    "action record rejected: no live lease for this "
                    "unit/fencing token")
            attempt = cur.execute(
                "SELECT * FROM action_attempts WHERE attempt_id=%s AND "
                "unit_id=%s", (attempt_id, unit_id)).fetchone()
            if attempt is None:
                raise CoordinatorError(
                    f"action record rejected: attempt {attempt_id} does "
                    f"not belong to unit {unit_id}")
            if worker_id is not None and (worker_id != attempt["worker_id"]
                                          or worker_id != lease["worker_id"]):
                raise _ActionIdentityMismatch(worker_id,
                                              attempt["worker_id"],
                                              action_key)
            if attempt["plan_id"] is None:
                raise CoordinatorError(
                    "action record rejected: attempt carries no pinned "
                    "plan (pre-Gate-04 attempt)")
            plan_row = cur.execute(
                "SELECT plan FROM operation_execution_plans WHERE "
                "operation_id=%s AND plan_version=%s",
                (unit["operation_id"], attempt["plan_version"])).fetchone()
            plan_body = plan_row["plan"] if plan_row else None
            if isinstance(plan_body, str):
                plan_body = json.loads(plan_body)
            actions = {a["action_key"]: a
                       for a in (plan_body or {}).get("actions", [])}
            if action_key not in actions:
                raise CoordinatorError(
                    f"action record rejected: {action_key!r} is not an "
                    f"action of the pinned plan {attempt['plan_id']}")
            if actions[action_key]["seq"] != seq:
                raise CoordinatorError(
                    f"action record rejected: seq {seq} does not match "
                    f"the pinned plan (action {action_key} is seq "
                    f"{actions[action_key]['seq']})")
            cur.execute(
                "INSERT INTO plan_action_attempts(attempt_id, unit_id, "
                "production_id, operation_id, plan_id, plan_version, "
                "plan_hash, action_key, seq, status, inputs_hash, "
                "output_summary, cost_cents, error, recorded_by) "
                "VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s) "
                "ON CONFLICT (attempt_id, action_key) DO NOTHING "
                "RETURNING plan_action_attempt_id",
                (attempt_id, unit_id, unit["production_id"],
                 unit["operation_id"], attempt["plan_id"],
                 attempt["plan_version"], attempt["plan_hash"], action_key,
                 seq, status, inputs_hash,
                 json.dumps(output_summary) if output_summary is not None else None,
                 cost_cents, error, recorded_by))
            row = cur.fetchone()
            recorded = row is not None
            if recorded:
                cur.execute(
                    "UPDATE action_instances SET state=%s WHERE unit_id=%s "
                    "AND action_id=%s",
                    (status, unit_id, action_key))
            existing = cur.execute(
                "SELECT * FROM plan_action_attempts WHERE attempt_id=%s "
                "AND action_key=%s", (attempt_id, action_key)).fetchone()
            return {"recorded": recorded,
                    "plan_action_attempt_id":
                        str(existing["plan_action_attempt_id"]),
                    "attempt_id": attempt_id, "action_key": action_key,
                    "status": existing["status"],
                    "plan_id": attempt["plan_id"],
                    "plan_hash": attempt["plan_hash"]}

    def materialize_run(self, production_id, run_id, operation_ids=None,
                        unit_key="main", lane="text"):
        """Gate 04 (G01-D03): registry-driven run materialization. The
        run's unit graph is derived from the registry's
        dependency_templates restricted to the requested operations
        (default: all 192): each unit depends on its nearest planned
        predecessor in template order, replacing hand-planned graphs.
        Units are planned through plan_unit, so readiness, audit and
        state handling are identical to hand-planned runs."""
        self._flush_reads()
        with self.conn.cursor() as cur:
            templates = [(r["from_operation"], r["to_operation"])
                         for r in cur.execute(
                             "SELECT from_operation, to_operation FROM "
                             "dependency_templates WHERE workflow_version='1.0.0' "
                             "ORDER BY from_operation, to_operation").fetchall()]
            known = {r["operation_id"] for r in cur.execute(
                "SELECT operation_id FROM operation_definitions WHERE "
                "workflow_version='1.0.0'").fetchall()}
        wanted = list(operation_ids) if operation_ids else sorted(known)
        unknown = [o for o in wanted if o not in known]
        if unknown:
            raise CoordinatorError(
                f"materialize_run: unknown operations {unknown}")
        wanted_set = set(wanted)
        # The templates form one linear chain; a unit depends on its
        # nearest PLANNED predecessor along that chain.
        chain_next = {frm: to for frm, to in templates}
        chain_order, node = [], "01.01"
        while node is not None:
            chain_order.append(node)
            node = chain_next.get(node)
        planned_before = {}
        last_planned = None
        for op in chain_order:
            if op in wanted_set:
                if last_planned is not None:
                    planned_before[op] = last_planned
                last_planned = op
        unit_ids = {}
        for op in chain_order:
            if op not in wanted_set:
                continue
            deps = (unit_ids[planned_before[op]],) if op in planned_before else ()
            unit_ids[op] = self.plan_unit(production_id, run_id, op,
                                          unit_key=unit_key, lane=lane,
                                          depends_on=deps)
        return {"production_id": production_id, "run_id": run_id,
                "units": unit_ids, "unit_count": len(unit_ids)}

    def heartbeat(self, unit_id, worker_id, fencing_token, extend_s=600):
        self._flush_reads()
        with self.conn.transaction():
            cur = self.conn.cursor()
            cur.execute(
                "UPDATE worker_leases SET heartbeat_at=now(), expires_at=now() + (%s || ' seconds')::interval"
                " WHERE unit_id=%s AND worker_id=%s AND fencing_token=%s",
                (extend_s, unit_id, worker_id, fencing_token))
            if cur.rowcount != 1:
                raise StaleFencing("heartbeat rejected: lease not held by this worker/token")

    # ------------------------------------------ artifact staging (Gate D, §3)
    def stage_content(self, data: bytes, content_type=None, actor=None, production_id=None):
        """Stage completion content in durable storage: bytes go to the
        configured StorageClient's candidate area and the candidate is
        recorded (migration 011, state STAGED). Content-addressed: staging
        identical bytes returns the existing candidate row. Returns the
        candidate row dict."""
        ref = self.storage.put_candidate(data, content_type)
        self._flush_reads()
        with self.conn.transaction():
            cur = self.conn.cursor()
            cur.execute(
                "INSERT INTO artifact_candidates(uri, sha256, size_bytes, content_type,"
                " staged_by, production_id) VALUES (%s,%s,%s,%s,%s,%s)"
                " ON CONFLICT (uri) DO UPDATE SET uri=EXCLUDED.uri RETURNING *",
                (ref["uri"], ref["sha256"], ref["size"], content_type,
                 actor or self.actor, production_id))
            row = cur.fetchone()
        return dict(row)

    def _prepare_completion_content(self, unit_id, data, candidate_uri,
                                    expected_sha256, actor):
        """Resolve a completion's content to (candidate row, bytes) BEFORE
        the completion transaction opens: stage inline bytes, or load the
        named candidate (must exist, be STAGED, and — when it was staged
        for a production — belong to this unit's production). A staged-hash
        or expected-hash mismatch commits an 'artifact_hash_mismatch' audit
        event and raises ArtifactHashMismatchError: nothing is registered
        and the attempt stays in flight; the candidate stays STAGED."""
        cur = self.conn.cursor()
        cur.execute("SELECT production_id FROM execution_units WHERE unit_id=%s", (unit_id,))
        urow = cur.fetchone()
        if not urow:
            raise CoordinatorError(f"unknown unit {unit_id}")
        pid = urow["production_id"]
        self._flush_reads()
        if candidate_uri is not None:
            cur = self.conn.cursor()
            cur.execute("SELECT * FROM artifact_candidates WHERE uri=%s", (candidate_uri,))
            cand = cur.fetchone()
            self._flush_reads()
            if not cand:
                raise CoordinatorError(f"unknown candidate {candidate_uri}")
            if cand["state"] != "STAGED":
                raise CoordinatorError(
                    f"candidate {candidate_uri} is {cand['state']}, not STAGED")
            if cand["production_id"] is not None and str(cand["production_id"]) != str(pid):
                raise CoordinatorError("candidate was staged for a different production")
            content = data if data is not None else self.storage.get(candidate_uri)
            cand = dict(cand)
        else:
            if data is None:
                raise CoordinatorError("completion requires content bytes or a candidate_uri")
            content = data
            cand = self.stage_content(content, None, actor=actor, production_id=pid)
        digest = _sha(content)
        if digest != cand["sha256"] or (expected_sha256 is not None
                                        and expected_sha256 != digest):
            with self.conn.transaction():
                cur = self.conn.cursor()
                self._audit(cur, pid, unit_id, "artifact_hash_mismatch", None, None,
                            {"expected_sha256": expected_sha256,
                             "staged_sha256": cand["sha256"], "actual_sha256": digest,
                             "candidate_uri": cand["uri"], "actor": actor})
            raise ArtifactHashMismatchError(
                f"content hash {digest} does not match the staged/expected hash "
                f"for unit {unit_id}; completion refused, nothing registered")
        return {"candidate": cand, "data": content, "sha256": digest}

    def _promote_candidate(self, cur, candidate, artifact_id):
        """Inside a completion transaction: place the candidate's bytes in
        the durable objects area and mark the candidate PROMOTED behind the
        freshly registered artifact. The promoted URI is a pure function of
        the hash (store://objects/<sha256>) on every backend."""
        self.storage.promote(candidate["uri"])
        cur.execute(
            "UPDATE artifact_candidates SET state='PROMOTED', promoted_artifact_id=%s,"
            " promoted_at=now() WHERE candidate_id=%s",
            (artifact_id, candidate["candidate_id"]))

    def cleanup_candidates(self, ttl_seconds, actor=None):
        """Abandon STAGED candidates older than the TTL: bytes deleted
        (missing bytes tolerated), state -> ABANDONED. PROMOTED candidates
        are never touched — their bytes back CURRENT artifacts."""
        self._flush_reads()
        abandoned = 0
        with self.conn.transaction():
            cur = self.conn.cursor()
            cur.execute(
                "SELECT * FROM artifact_candidates WHERE state='STAGED'"
                " AND created_at < now() - (%s || ' seconds')::interval FOR UPDATE",
                (ttl_seconds,))
            for cand in cur.fetchall():
                try:
                    self.storage.delete(cand["uri"])
                except Exception:
                    pass  # bytes already gone is the desired end state
                cur.execute(
                    "UPDATE artifact_candidates SET state='ABANDONED' WHERE candidate_id=%s",
                    (cand["candidate_id"],))
                abandoned += 1
            if abandoned:
                self._audit(cur, None, None, "candidates_cleaned", None, None,
                            {"abandoned": abandoned, "ttl_seconds": ttl_seconds,
                             "actor": actor or self.actor})
        return {"abandoned": abandoned}

    # ------------------------------------------------------------- completion
    def _settle_reservation(self, cur, production_id, reservation_id, actual_cost_cents):
        """Shared settlement (Gate C): HELD reservation -> SETTLED at the
        actual cost, with the CHARGE ledger entry. Used by the synchronous
        completion and by the async provider-job completion (B1.2) so money
        moves exactly once, through exactly one code path."""
        cur.execute(
            "UPDATE budget_reservations SET state='SETTLED', settled_cents=%s WHERE reservation_id=%s AND state='HELD'",
            (actual_cost_cents, reservation_id))
        if cur.rowcount != 1:
            raise CoordinatorError(f"reservation {reservation_id} is not HELD; cannot settle")
        cur.execute(
            "INSERT INTO budget_transactions(production_id, kind, amount_cents, reservation_id)"
            " VALUES (%s,'CHARGE',%s,%s)", (production_id, actual_cost_cents, reservation_id))

    def completion_barrier(self, unit_id):
        """Gate 05 (programme tasks 6-7): read-only completion-barrier
        status for the unit's CURRENT attempt. The barrier holds when
        every action of the attempt's pinned plan has a terminal
        SUCCEEDED plan_action_attempts record for that attempt. Plans
        carry no optional actions (every action in plans.json is
        required), so the barrier fails on: a missing record, a
        FAILED/REFUSED record, a record for an action outside the
        pinned plan, an attempt with no pinned plan, or no attempt.
        Read-only: ends its read transaction before returning."""
        cur = self.conn.cursor()
        cur.execute("SELECT * FROM execution_units WHERE unit_id=%s", (unit_id,))
        unit = cur.fetchone()
        if not unit:
            raise CoordinatorError(f"unknown unit {unit_id}")
        out = {"ok": False, "reason": None, "attempt_id": None,
               "plan_id": None, "required": 0, "recorded": 0,
               "missing": [], "not_succeeded": [], "out_of_plan": []}
        cur.execute(
            "SELECT * FROM action_attempts WHERE unit_id=%s AND attempt_no=%s",
            (unit_id, unit["current_attempt"]))
        attempt = cur.fetchone()
        if attempt is None:
            out["reason"] = "no_attempt"
            self.conn.commit()
            return out
        out["attempt_id"] = str(attempt["attempt_id"])
        if attempt["plan_id"] is None:
            out["reason"] = "no_pinned_plan"
            self.conn.commit()
            return out
        out["plan_id"] = attempt["plan_id"]
        plan_row = cur.execute(
            "SELECT plan FROM operation_execution_plans WHERE "
            "operation_id=%s AND plan_version=%s",
            (unit["operation_id"], attempt["plan_version"])).fetchone()
        plan_body = plan_row["plan"] if plan_row else None
        if isinstance(plan_body, str):
            plan_body = json.loads(plan_body)
        actions = (plan_body or {}).get("actions", [])
        out["required"] = len(actions)
        cur.execute(
            "SELECT action_key, status FROM plan_action_attempts "
            "WHERE attempt_id=%s", (attempt["attempt_id"],))
        records = {r["action_key"]: r["status"] for r in cur.fetchall()}
        plan_keys = {a["action_key"] for a in actions}
        out["out_of_plan"] = sorted(k for k in records if k not in plan_keys)
        for a in actions:
            key = a["action_key"]
            if key not in records:
                out["missing"].append(key)
            elif records[key] != "SUCCEEDED":
                out["not_succeeded"].append(
                    {"action_key": key, "status": records[key]})
            else:
                out["recorded"] += 1
        out["ok"] = not (out["missing"] or out["not_succeeded"]
                         or out["out_of_plan"])
        if not out["ok"]:
            out["reason"] = ("missing_records" if out["missing"] else
                             "actions_not_succeeded" if out["not_succeeded"]
                             else "out_of_plan_records")
        self.conn.commit()
        return out

    def complete_attempt(self, unit_id, worker_id, fencing_token, artifact_type, data: bytes,
                         storage_uri, actual_cost_cents, depends_on_artifact_ids=(),
                         usage=None, provider_request_id=None, candidate_uri=None,
                         expected_sha256=None, reported_cost_cents=None,
                         enforce_barrier=False, model=None):
        """Worker submits a candidate. Fencing guards the commit (§7.3).
        A stale-fencing rejection is evidence and must be committed even though
        the submission itself is rejected: the attempt transaction raises and
        rolls back, then the rejection record is written in its own transaction
        (verifier defect D2 — same pattern as the budget path in claim()).
        Gate C: GB-SEC-01 worker binding is verified inside the transaction;
        a FINALIZED financial-evidence row is written at settlement (B3).
        Gate D: content is staged in durable storage and hash-verified
        before the transaction opens (candidate_uri names pre-staged
        content instead of inline bytes); settlement charges the FINALIZED
        amount selected from the evidence (pricing rules / provider report
        / reported actual). Storage-URI rule: a caller-supplied storage_uri
        stays the artifact's recorded URI (the staged bytes are the durable
        copy behind it); with no caller URI the artifact records the
        promoted store://objects/<sha256> URI.
        Gate 05: enforce_barrier=True (the API /complete path — the
        production completion path) applies the completion barrier
        (programme tasks 6-7): the attempt's pinned plan must be fully
        evidenced by terminal SUCCEEDED action records before any
        content is staged or settled. The refusal is committed
        'completion_barrier_refused' audit evidence. The default
        (library) path is unchanged: in-process callers are trusted
        system actors and the older fixture suites complete attempts
        that never went through the worker service — the barrier is an
        API-boundary invariant, recorded here rather than silently
        applied to (or silently exempted from) library fixtures."""
        self._flush_reads()
        if enforce_barrier:
            barrier = self.completion_barrier(unit_id)
            if not barrier["ok"]:
                with self.conn.transaction():
                    cur = self.conn.cursor()
                    unit = self._unit(cur, unit_id)
                    self._audit(cur, unit["production_id"], unit_id,
                                "completion_barrier_refused",
                                unit["state"], unit["state"],
                                {"reason": barrier["reason"],
                                 "attempt_id": barrier["attempt_id"],
                                 "plan_id": barrier["plan_id"],
                                 "missing": barrier["missing"],
                                 "not_succeeded": barrier["not_succeeded"],
                                 "out_of_plan": barrier["out_of_plan"]})
                raise CompletionBarrierError(
                    f"attempt {barrier['attempt_id']} plan "
                    f"{barrier['plan_id']}: {barrier['reason']} "
                    f"(missing={barrier['missing']}, "
                    f"not_succeeded={barrier['not_succeeded']}, "
                    f"out_of_plan={barrier['out_of_plan']})")
        staged = None
        if candidate_uri is not None or data is not None:
            staged = self._prepare_completion_content(
                unit_id, data, candidate_uri, expected_sha256, worker_id)
            data = staged["data"]
        try:
            return self._complete_attempt_txn(unit_id, worker_id, fencing_token, artifact_type,
                                              data, storage_uri, actual_cost_cents,
                                              depends_on_artifact_ids, usage, provider_request_id,
                                              candidate=staged["candidate"] if staged else None,
                                              reported_cost_cents=reported_cost_cents,
                                              model=model)
        except StaleFencing:
            with self.conn.transaction():
                cur = self.conn.cursor()
                unit = self._unit(cur, unit_id)
                cur.execute(
                    "INSERT INTO action_attempts(unit_id, attempt_no, worker_id, status, error_class, finished_at)"
                    " VALUES (%s,%s,%s,'STALE_FENCED','STALE_FENCING',now())",
                    (unit_id, unit["current_attempt"] + 1000, worker_id))
                self._audit(cur, unit["production_id"], unit_id, "stale_commit_rejected",
                            unit["state"], unit["state"],
                            {"worker_id": worker_id, "fencing_token": fencing_token})
            raise

    def _complete_attempt_txn(self, unit_id, worker_id, fencing_token, artifact_type, data: bytes,
                              storage_uri, actual_cost_cents, depends_on_artifact_ids=(),
                              usage=None, provider_request_id=None, candidate=None,
                              reported_cost_cents=None, model=None):
        with self.conn.transaction():
            cur = self.conn.cursor()
            unit = self._unit(cur, unit_id)
            if unit["state"] not in ("CLAIMED", "RUNNING", "AWAITING_PROVIDER"):
                raise UnauthorizedTransition(f"complete requires an in-flight state, unit is {unit['state']}")
            cur.execute(
                "UPDATE execution_units SET state=state WHERE unit_id=%s AND fencing_token=%s",
                (unit_id, fencing_token))
            if cur.rowcount != 1:
                # Evidence is written by complete_attempt after this txn rolls back.
                raise StaleFencing(f"fencing token {fencing_token} is not current for unit {unit_id}")
            # GB-SEC-01 (Gate C / design B4.2): the completing worker must be
            # the worker that holds the lease AND owns the attempt — a valid
            # fencing token in foreign hands settles nothing.
            cur.execute("SELECT worker_id FROM worker_leases WHERE unit_id=%s", (unit_id,))
            lease = cur.fetchone()
            cur.execute(
                "SELECT attempt_id, worker_id, reservation_id, resolved_config"
                " FROM action_attempts WHERE unit_id=%s AND attempt_no=%s",
                (unit_id, unit["current_attempt"]))
            attempt = cur.fetchone()
            if (lease is None or lease["worker_id"] != worker_id
                    or attempt is None or attempt["worker_id"] != worker_id):
                raise StaleFencing(
                    f"worker binding mismatch for unit {unit_id}: completion by "
                    f"{worker_id!r} refused (lease/attempt held by another worker)")
            # Gate D storage rule (see complete_attempt docstring).
            final_uri = storage_uri
            if candidate is not None and not final_uri:
                final_uri = f"store://objects/{_sha(data)}"
            art = self._register_artifact_txn(cur, unit["production_id"], artifact_type, data,
                                              final_uri, unit_id, depends_on_artifact_ids)
            if candidate is not None:
                self._promote_candidate(cur, candidate, art["artifact_id"])
            reservation_id = attempt["reservation_id"]
            snapshot = attempt["resolved_config"] or {}
            provider = snapshot.get("provider", "mock")
            spent_before = self._spent_cents(cur, unit["production_id"])
            finalized = None
            if self._missing_usage(snapshot, usage, reported_cost_cents):
                # MM-08: no measured cost exists for this completion.
                # The charge is recorded UNRESOLVED and the reservation
                # stays HELD — the estimate never settles as measured.
                cur.execute(
                    "SELECT estimated_cents FROM budget_reservations"
                    " WHERE reservation_id=%s", (reservation_id,))
                self._record_unresolved(
                    cur, unit["production_id"], unit_id, attempt["attempt_id"],
                    provider, cur.fetchone()["estimated_cents"],
                    provider_request_id, None)
            else:
                # MM-04: pricing uses the EXECUTED model when the caller
                # presents one (an authorized-fallback completion must price
                # at the fallback model's rows); otherwise the attempt
                # snapshot's pinned model, exactly as before.
                finalized = self._finalize_amount(
                    cur, unit["production_id"], unit_id, attempt["attempt_id"], provider,
                    model if model is not None else snapshot.get("model"),
                    usage, provider_request_id, None,
                    actual_cost_cents, reported_cost_cents)
                self._settle_reservation(cur, unit["production_id"], reservation_id, finalized)
                self._maybe_soft_ceiling_notify(
                    cur, unit["production_id"], spent_before,
                    self._spent_cents(cur, unit["production_id"]))
            cur.execute(
                "UPDATE action_attempts SET status='VALIDATING', output_artifact_id=%s, actual_cost_cents=%s"
                " WHERE unit_id=%s AND attempt_no=%s",
                (art["artifact_id"], finalized, unit_id, unit["current_attempt"]))
            cur.execute("DELETE FROM worker_leases WHERE unit_id=%s", (unit_id,))
            if unit["state"] == "CLAIMED":
                self._transition(cur, unit, "start")
                unit = dict(unit, state="RUNNING")
            self._transition(cur, unit, "submit_candidate", {"artifact_id": art["artifact_id"]})
            return art

    def _register_artifact_txn(self, cur, production_id, artifact_type, data, storage_uri,
                               produced_by_unit, depends_on_artifact_ids):
        art_id = _uid()
        digest = _sha(data)
        cur.execute("SELECT COALESCE(MAX(version),0)+1 AS v FROM artifacts WHERE production_id=%s AND artifact_type=%s",
                    (production_id, artifact_type))
        version = cur.fetchone()["v"]
        cur.execute("UPDATE artifacts SET state='SUPERSEDED' WHERE production_id=%s AND artifact_type=%s AND state='CURRENT'",
                    (production_id, artifact_type))
        cur.execute(
            "INSERT INTO artifacts(artifact_id, production_id, produced_by_unit, artifact_type, version, storage_uri, sha256, state)"
            " VALUES (%s,%s,%s,%s,%s,%s,%s,'CURRENT')",
            (art_id, production_id, produced_by_unit, artifact_type, version, storage_uri, digest))
        for consumed in depends_on_artifact_ids:
            cur.execute("SELECT version, sha256 FROM artifacts WHERE artifact_id=%s", (consumed,))
            c = cur.fetchone()
            cur.execute(
                "INSERT INTO artifact_dependencies(consumer_artifact_id, consumed_artifact_id, consumed_version, consumed_sha256)"
                " VALUES (%s,%s,%s,%s) ON CONFLICT DO NOTHING", (art_id, consumed, c["version"], c["sha256"]))
        return {"artifact_id": art_id, "version": version, "sha256": digest}

    def validate(self, unit_id, evaluations):
        self._flush_reads()
        """evaluations: list of dicts {validator, method, verdict, evaluator, evidence}.
        All PASS -> ACCEPTED. A FAIL with evidence.deterministic=true -> BLOCKED;
        other FAIL -> REPAIR_REQUIRED; any REVIEW_REQUIRED -> AWAITING_HUMAN."""
        with self.conn.transaction():
            cur = self.conn.cursor()
            unit = self._unit(cur, unit_id)
            if unit["state"] != "VALIDATING":
                raise UnauthorizedTransition(f"validate requires VALIDATING, unit is {unit['state']}")
            cur.execute("SELECT output_artifact_id FROM action_attempts WHERE unit_id=%s AND attempt_no=%s",
                        (unit_id, unit["current_attempt"]))
            artifact_id = cur.fetchone()["output_artifact_id"]
            verdicts = []
            for ev in evaluations:
                cur.execute(
                    "INSERT INTO quality_evaluations(artifact_id, validator_id, method, evidence, verdict, evaluator_identity)"
                    " VALUES (%s,%s,%s,%s,%s,%s)",
                    (artifact_id, ev["validator"], ev["method"], json.dumps(ev.get("evidence", {})),
                     ev["verdict"], ev["evaluator"]))
                verdicts.append(ev)
            fails = [e for e in verdicts if e["verdict"] == "FAIL"]
            if any(e.get("evidence", {}).get("deterministic") for e in fails):
                event = "validation_failed_deterministic"
            elif fails:
                event = "validation_failed_content"
            elif any(e["verdict"] == "REVIEW_REQUIRED" for e in verdicts):
                event = "validation_needs_human"
            else:
                event = "validation_passed"
            new_state = self._transition(cur, unit, event, {"artifact_id": artifact_id})
            cur.execute("UPDATE action_attempts SET status=%s, finished_at=now() WHERE unit_id=%s AND attempt_no=%s",
                        ("ACCEPTED" if new_state == "ACCEPTED" else "FAILED", unit_id, unit["current_attempt"]))
            if new_state == "ACCEPTED":
                # Gate 05 (G01-D06): record which approval policy the
                # unit's operation carries and that acceptance came
                # through the validation layers — no human satisfied
                # the policy on this path (human_satisfied_by null).
                self._approval_policy_audit(
                    cur, unit, "validation_layers", satisfied_by=None,
                    extra={"evaluators": [e.get("evaluator") for e in verdicts]})
        if new_state == "ACCEPTED":
            self.recompute_readiness(unit["production_id"])
        return new_state

    # ------------------------------------------------------- human gates (§12)
    def create_gate(self, production_id, gate_kind, artifact_id):
        """FP-02 (F-G9-02): idempotent creation. One gate per (production,
        kind, artifact) — any verdict. A second create returns the existing
        gate (GateId with existing=True) instead of shadowing a decided gate
        with a dangling PENDING duplicate. Decision history is never touched:
        a revised artifact is a NEW artifact_id and gets its own gate."""
        cur = self.conn.cursor()
        cur.execute("SELECT sha256 FROM artifacts WHERE artifact_id=%s", (artifact_id,))
        row = cur.fetchone()
        if not row:
            raise CoordinatorError("gate artifact not found")
        cur.execute(
            "SELECT gate_id FROM human_gates WHERE production_id=%s AND gate_kind=%s"
            " AND artifact_id=%s ORDER BY created_at LIMIT 1",
            (production_id, gate_kind, artifact_id))
        existing = cur.fetchone()
        if existing:
            self._flush_reads()
            return GateId(existing["gate_id"], existing=True)
        gate_id = _uid()
        self._flush_reads()
        with self.conn.transaction():
            c2 = self.conn.cursor()
            c2.execute("INSERT INTO human_gates(gate_id, production_id, gate_kind, artifact_id, artifact_sha256)"
                       " VALUES (%s,%s,%s,%s,%s)", (gate_id, production_id, gate_kind, artifact_id, row["sha256"]))
        return GateId(gate_id, existing=False)

    def decide_gate(self, gate_id, verdict, decided_by, conditions=None):
        self._flush_reads()
        with self.conn.transaction():
            cur = self.conn.cursor()
            cur.execute("UPDATE human_gates SET verdict=%s, decided_by=%s, decided_at=now(), conditions=%s"
                        " WHERE gate_id=%s AND verdict='PENDING'",
                        (verdict, decided_by, json.dumps(conditions) if conditions else None, gate_id))
            if cur.rowcount != 1:
                raise CoordinatorError("gate not pending or not found")

    def require_gate(self, production_id, gate_kind, artifact_id):
        """An approval binds to the exact artifact hash (§12, T-GATE-01 analogue)."""
        cur = self.conn.cursor()
        cur.execute("SELECT sha256 FROM artifacts WHERE artifact_id=%s", (artifact_id,))
        art = cur.fetchone()
        cur.execute(
            "SELECT * FROM human_gates WHERE production_id=%s AND gate_kind=%s AND artifact_id=%s"
            " AND verdict='APPROVED' ORDER BY decided_at DESC LIMIT 1",
            (production_id, gate_kind, artifact_id))
        gate = cur.fetchone()
        if not gate or gate["artifact_sha256"] != art["sha256"]:
            raise GateNotSatisfied(f"no APPROVED {gate_kind} gate bound to artifact {artifact_id} hash")
        return gate

    # ----------------------------------------------------- provider jobs (§7.7)
    def submit_provider_job(self, unit_id, provider, payload, idempotency_key):
        """Legacy submit (pre-Gate-C signature). Gate C: the job is now also
        linked to the unit's current attempt (migration 006) so callback and
        reconciler completions converge on the v2 machinery (B1.2). Callers
        that need the strict claim-bound preconditions use
        submit_provider_job_v2."""
        self._flush_reads()
        with self.conn.transaction():
            cur = self.conn.cursor()
            unit = self._unit(cur, unit_id)
            job_id = _uid()
            cur.execute(
                "SELECT attempt_id, resolved_config_hash FROM action_attempts"
                " WHERE unit_id=%s AND attempt_no=%s", (unit_id, unit["current_attempt"]))
            attempt = cur.fetchone()
            cur.execute(
                "INSERT INTO provider_jobs(job_id, unit_id, production_id, provider, idempotency_key,"
                " request_payload, attempt_id, fencing_token, resolved_config_hash)"
                " VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s) ON CONFLICT (idempotency_key) DO NOTHING RETURNING job_id",
                (job_id, unit_id, unit["production_id"], provider, idempotency_key, json.dumps(payload),
                 attempt["attempt_id"] if attempt else None, unit["fencing_token"],
                 attempt["resolved_config_hash"] if attempt else None))
            row = cur.fetchone()
            if row is None:
                cur.execute("SELECT job_id FROM provider_jobs WHERE idempotency_key=%s", (idempotency_key,))
                return cur.fetchone()["job_id"], False
            if unit["state"] == "RUNNING":
                self._transition(cur, unit, "await_provider")
            return job_id, True

    def submit_provider_job_v2(self, unit_id, attempt_id, fencing_token, idempotency_key):
        """Gate C (design B1.1): claim-bound job registration. The unit must
        be RUNNING, the named attempt must be its current attempt, the
        fencing token must be current, and that attempt's reservation must
        be HELD — a provider call is never authorized by an unverifiable
        request. Provider and config come from the attempt's pinned snapshot
        ONLY, never from the caller. Duplicate idempotency keys return the
        existing job. Refusals raise CoordinatorError subclasses (StaleFencing
        / UnauthorizedTransition / CoordinatorError) and create no job row."""
        self._flush_reads()
        with self.conn.transaction():
            cur = self.conn.cursor()
            cur.execute("SELECT job_id FROM provider_jobs WHERE idempotency_key=%s",
                        (idempotency_key,))
            existing = cur.fetchone()
            if existing:
                return str(existing["job_id"])
            unit = self._unit(cur, unit_id)
            if unit["state"] != "RUNNING":
                raise UnauthorizedTransition(
                    f"provider submission requires RUNNING, unit is {unit['state']}")
            cur.execute("SELECT * FROM action_attempts WHERE attempt_id=%s", (attempt_id,))
            attempt = cur.fetchone()
            if attempt is None or attempt["unit_id"] != unit["unit_id"] \
                    or attempt["attempt_no"] != unit["current_attempt"]:
                raise CoordinatorError("attempt is not the unit's current attempt")
            if fencing_token != unit["fencing_token"]:
                raise StaleFencing(
                    f"fencing token {fencing_token} is not current for unit {unit_id}")
            cur.execute("SELECT state FROM budget_reservations WHERE reservation_id=%s",
                        (attempt["reservation_id"],))
            res = cur.fetchone()
            if res is None or res["state"] != "HELD":
                raise CoordinatorError("attempt reservation is not HELD; submission refused")
            snapshot = attempt["resolved_config"] or {}
            provider = snapshot.get("provider", "mock")
            job_id = _uid()
            cur.execute(
                "INSERT INTO provider_jobs(job_id, unit_id, production_id, provider, idempotency_key,"
                " request_payload, attempt_id, fencing_token, resolved_config_hash, provider_job_id)"
                " VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"
                " ON CONFLICT (idempotency_key) DO NOTHING RETURNING job_id",
                (job_id, unit_id, unit["production_id"], provider, idempotency_key,
                 json.dumps({"operation_id": unit["operation_id"]}),
                 attempt_id, fencing_token, attempt["resolved_config_hash"],
                 f"local-{job_id}"))
            if cur.fetchone() is None:  # lost a concurrent duplicate race
                cur.execute("SELECT job_id FROM provider_jobs WHERE idempotency_key=%s",
                            (idempotency_key,))
                return str(cur.fetchone()["job_id"])
            self._transition(cur, unit, "await_provider")
            return job_id

    def get_provider_job(self, job_id):
        cur = self.conn.cursor()
        cur.execute("SELECT * FROM provider_jobs WHERE job_id=%s", (job_id,))
        return cur.fetchone()

    def attach_provider_job_id(self, job_id, provider_job_id):
        self._flush_reads()
        with self.conn.transaction():
            cur = self.conn.cursor()
            cur.execute("UPDATE provider_jobs SET provider_job_id=%s WHERE job_id=%s",
                        (provider_job_id, job_id))

    def provider_timeout(self, unit_id, job_id):
        self._flush_reads()
        """Timeout AFTER submission: job may exist at the provider -> UNKNOWN (R2)."""
        with self.conn.transaction():
            cur = self.conn.cursor()
            unit = self._unit(cur, unit_id)
            cur.execute("UPDATE provider_jobs SET status='UNKNOWN' WHERE job_id=%s", (job_id,))
            if unit["state"] in ("RUNNING", "AWAITING_PROVIDER"):
                self._transition(cur, unit, "provider_unknown")

    # --------------------------------- cancellation (MM-04)
    def cancel_provider_job(self, job_id, worker_id=None, fencing_token=None,
                            reported_cost_cents=None, provider_request_id=None,
                            usage=None, correlation_id=None, actor=None):
        """MM-04: cancel an OPEN async provider job (status SUBMITTED /
        PROCESSING / UNKNOWN / TIMEOUT). The job is marked CANCELLED
        (migration 017) with failure_code CANCELLED; the job's attempt
        is failed with error_class 'CANCELLED'; the unit leaves its
        provider-wait state through the same transitions the provider-
        failure path uses (transient_error / reconciled_failed) —
        reservations are released only by the retry path, never
        silently. An optional reported charge is recorded as
        PROVIDER_REPORTED evidence awaiting explicit settlement,
        mirroring the failure path. Identity discipline mirrors
        /complete (GB-SEC-01): a caller presenting a worker_id must be
        the attempt's claim identity (and the live lease holder when a
        lease exists); a presented fencing_token must be current. A
        mismatch raises _CancelIdentityMismatch inside the transaction;
        the refusal is then committed as 'provider_job_cancel_refused'
        audit evidence and re-raised as CancelRefused. OPERATOR
        cancellations present no worker_id and are bound by the API's
        role check instead. Repeat cancellation of a CANCELLED job is
        idempotent; cancelling a COMPLETED / FAILED / NOT_FOUND job is
        refused (CoordinatorError)."""
        self._flush_reads()
        try:
            return self._cancel_provider_job_txn(
                job_id, worker_id, fencing_token, reported_cost_cents,
                provider_request_id, usage, correlation_id,
                actor or self.actor)
        except _CancelIdentityMismatch as m:
            with self.conn.transaction():
                cur = self.conn.cursor()
                unit = self._unit(cur, m.unit_id)
                self._audit(cur, unit["production_id"], m.unit_id,
                            "provider_job_cancel_refused",
                            unit["state"], unit["state"],
                            {"reason": "identity_mismatch",
                             "job_id": str(job_id),
                             "presented_worker_id": m.presented,
                             "attempt_worker_id": m.expected})
            raise CancelRefused(
                "identity_mismatch",
                f"presented worker {m.presented!r}, attempt claimed by "
                f"{m.expected!r}") from None

    def _cancel_provider_job_txn(self, job_id, worker_id, fencing_token,
                                 reported_cost_cents, provider_request_id,
                                 usage, correlation_id, actor):
        with self.conn.transaction():
            cur = self.conn.cursor()
            cur.execute("SELECT * FROM provider_jobs WHERE job_id=%s FOR UPDATE",
                        (job_id,))
            job = cur.fetchone()
            if not job:
                raise CoordinatorError(f"unknown provider job {job_id}")
            if job["status"] == "CANCELLED":
                return {"job_id": str(job_id), "status": "CANCELLED",
                        "already_cancelled": True}
            if job["status"] not in ("SUBMITTED", "PROCESSING", "UNKNOWN",
                                     "TIMEOUT"):
                raise CoordinatorError(
                    f"provider job {job_id} is {job['status']}; only an "
                    f"open job can be cancelled")
            cur.execute("SELECT * FROM execution_units WHERE unit_id=%s FOR UPDATE",
                        (job["unit_id"],))
            unit = cur.fetchone()
            attempt = None
            if job["attempt_id"] is not None:
                cur.execute("SELECT * FROM action_attempts WHERE attempt_id=%s",
                            (job["attempt_id"],))
                attempt = cur.fetchone()
            if worker_id is not None:
                if attempt is None:
                    raise _CancelIdentityMismatch(worker_id, None,
                                                  job["unit_id"])
                lease = cur.execute(
                    "SELECT worker_id FROM worker_leases WHERE unit_id=%s",
                    (job["unit_id"],)).fetchone()
                if worker_id != attempt["worker_id"] or (
                        lease is not None
                        and lease["worker_id"] != worker_id):
                    raise _CancelIdentityMismatch(worker_id,
                                                  attempt["worker_id"],
                                                  job["unit_id"])
                if fencing_token is not None \
                        and fencing_token != unit["fencing_token"]:
                    raise StaleFencing(
                        f"fencing token {fencing_token} is not current "
                        f"for unit {job['unit_id']}")
            raw = {"failure_code": "CANCELLED", "via": "cancel",
                   "actor": actor}
            if correlation_id:
                raw["correlation_id"] = correlation_id
            cur.execute(
                "UPDATE provider_jobs SET status='CANCELLED', raw_response=%s"
                " WHERE job_id=%s", (json.dumps(raw), job_id))
            if reported_cost_cents is not None:
                self._evidence(cur, job["production_id"], job["unit_id"],
                               job["attempt_id"], job["provider"],
                               "PROVIDER_REPORTED", reported_cost_cents,
                               usage=usage,
                               provider_request_id=provider_request_id,
                               provider_job_id=job["job_id"],
                               requires_reconciliation=True)
            if attempt is not None and attempt["status"] == "RUNNING":
                cur.execute(
                    "UPDATE action_attempts SET status='FAILED',"
                    " error_class='CANCELLED', finished_at=now()"
                    " WHERE attempt_id=%s", (attempt["attempt_id"],))
            old_state = unit["state"]
            new_state = old_state
            if old_state == "AWAITING_PROVIDER":
                new_state = self._transition(
                    cur, unit, "transient_error",
                    {"via": "cancel", "reason": "CANCELLED"})
            elif old_state == "UNKNOWN":
                new_state = self._transition(
                    cur, unit, "reconciled_failed",
                    {"via": "cancel", "reason": "CANCELLED"})
            elif old_state == "RUNNING":
                new_state = self._transition(
                    cur, unit, "transient_error",
                    {"via": "cancel", "reason": "CANCELLED"})
            self._audit(cur, job["production_id"], job["unit_id"],
                        "provider_job_cancelled", old_state, new_state,
                        {"job_id": str(job_id), "actor": actor,
                         "attempt_id": str(job["attempt_id"])
                         if job["attempt_id"] else None,
                         "correlation_id": correlation_id})
            return {"job_id": str(job_id), "status": "CANCELLED",
                    "unit_state": new_state, "already_cancelled": False}

    # --------------------------------- async completion (Gate C, design B1.2)
    def _complete_provider_job_txn(self, cur, job, unit, data, storage_uri, actual_cost_cents,
                                   usage=None, provider_request_id=None,
                                   reported_cost_cents=None, artifact_type=None, via="callback",
                                   candidate=None, correlation_id=None, model=None):
        """Convergent completion: job + unit rows are already locked by the
        caller. Fencing gate first — a stale job registers nothing, settles
        nothing, transitions nothing; its reported charge becomes flagged
        PROVIDER_REPORTED evidence. Success registers the artifact, settles
        the attempt's reservation through the shared settlement path, and
        leaves the unit in VALIDATING for independent validation."""
        if job["status"] == "COMPLETED":
            return {"outcome": "completed", "artifact_id": str(job["result_artifact_id"])}
        if job["attempt_id"] is None:
            raise CoordinatorError("provider job has no attempt linkage; cannot complete")
        cur.execute("SELECT * FROM action_attempts WHERE attempt_id=%s", (job["attempt_id"],))
        attempt = cur.fetchone()
        reservation_held = False
        if attempt is not None:
            cur.execute("SELECT state FROM budget_reservations WHERE reservation_id=%s",
                        (attempt["reservation_id"],))
            r = cur.fetchone()
            reservation_held = bool(r and r["state"] == "HELD")
        fencing_ok = (attempt is not None
                      and attempt["attempt_no"] == unit["current_attempt"]
                      and job["fencing_token"] == unit["fencing_token"]
                      and reservation_held)
        if not fencing_ok:
            raw = {"failure_code": "STALE_FENCING", "via": via}
            if correlation_id:
                raw["correlation_id"] = correlation_id
            cur.execute(
                "UPDATE provider_jobs SET status='FAILED', raw_response=%s WHERE job_id=%s",
                (json.dumps(raw), job["job_id"]))
            if reported_cost_cents is not None:
                self._evidence(cur, job["production_id"], job["unit_id"], job["attempt_id"],
                               job["provider"], "PROVIDER_REPORTED", reported_cost_cents,
                               usage=usage, provider_request_id=provider_request_id,
                               provider_job_id=job["job_id"], requires_reconciliation=True)
            return {"outcome": "stale_fencing"}
        # input currency (same guard as claim): no promotion on stale inputs
        cur.execute(
            "SELECT a.state FROM unit_inputs ui JOIN artifacts a ON a.artifact_id=ui.artifact_id"
            " WHERE ui.unit_id=%s", (unit["unit_id"],))
        if any(r["state"] != "CURRENT" for r in cur.fetchall()):
            raw = {"failure_code": "STALE_INPUT", "via": via}
            if correlation_id:
                raw["correlation_id"] = correlation_id
            cur.execute(
                "UPDATE provider_jobs SET status='FAILED', raw_response=%s WHERE job_id=%s",
                (json.dumps(raw), job["job_id"]))
            if unit["state"] == "AWAITING_PROVIDER":
                self._transition(cur, unit, "transient_error", {"via": via, "reason": "STALE_INPUT"})
            elif unit["state"] == "UNKNOWN":
                self._transition(cur, unit, "reconciled_failed", {"via": via, "reason": "STALE_INPUT"})
            return {"outcome": "stale_input"}
        out_type = artifact_type or (job["request_payload"] or {}).get("artifact_type") \
            or "provider_output"
        # Gate D storage rule (same as complete_attempt): a caller-supplied
        # storage_uri stays the recorded URI with the staged bytes as the
        # durable copy; otherwise the promoted store://objects URI is used.
        final_uri = storage_uri
        if candidate is not None and not final_uri:
            final_uri = f"store://objects/{_sha(data)}"
        art = self._register_artifact_txn(cur, job["production_id"], out_type, data,
                                          final_uri, job["unit_id"], ())
        if candidate is not None:
            self._promote_candidate(cur, candidate, art["artifact_id"])
        snapshot = (attempt["resolved_config"] if attempt else None) or {}
        spent_before = self._spent_cents(cur, job["production_id"])
        finalized = None
        unresolved_id = None
        if self._missing_usage(snapshot, usage, reported_cost_cents):
            # MM-08: same missing-usage rule as the sync path — record
            # UNRESOLVED, keep the reservation HELD, settle nothing.
            cur.execute(
                "SELECT estimated_cents FROM budget_reservations"
                " WHERE reservation_id=%s", (attempt["reservation_id"],))
            unresolved_id = self._record_unresolved(
                cur, job["production_id"], job["unit_id"], attempt["attempt_id"],
                job["provider"], cur.fetchone()["estimated_cents"],
                provider_request_id, job["job_id"])
        else:
            finalized = self._finalize_amount(
                cur, job["production_id"], job["unit_id"], attempt["attempt_id"],
                job["provider"],
                model if model is not None else snapshot.get("model"),
                usage, provider_request_id,
                job["job_id"], actual_cost_cents, reported_cost_cents)
            self._settle_reservation(cur, job["production_id"], attempt["reservation_id"],
                                     finalized)
            self._maybe_soft_ceiling_notify(
                cur, job["production_id"], spent_before,
                self._spent_cents(cur, job["production_id"]))
        cur.execute(
            "UPDATE action_attempts SET status='VALIDATING', output_artifact_id=%s,"
            " actual_cost_cents=%s WHERE attempt_id=%s",
            (art["artifact_id"], finalized, attempt["attempt_id"]))
        cur.execute("DELETE FROM worker_leases WHERE unit_id=%s", (unit["unit_id"],))
        done_raw = {"via": via}
        if unresolved_id is not None:
            done_raw["charge_unresolved"] = str(unresolved_id)
        if correlation_id:
            done_raw["correlation_id"] = correlation_id
        cur.execute(
            "UPDATE provider_jobs SET status='COMPLETED', result_artifact_id=%s,"
            " cost_charged_cents=%s, raw_response=%s WHERE job_id=%s",
            (art["artifact_id"], finalized, json.dumps(done_raw), job["job_id"]))
        if unit["state"] == "UNKNOWN":
            self._transition(cur, unit, "reconciled_submitted", {"via": via})
        elif unit["state"] == "AWAITING_PROVIDER":
            self._transition(cur, unit, "submit_candidate", {"via": via})
        elif unit["state"] == "RUNNING":
            self._transition(cur, dict(unit, state="AWAITING_PROVIDER"),
                             "submit_candidate", {"via": via})
        out = {"outcome": "completed", "artifact_id": art["artifact_id"],
               "sha256": art["sha256"]}
        if unresolved_id is not None:
            out["unresolved_evidence_id"] = str(unresolved_id)
        return out

    def _complete_provider_job(self, job_id, data, storage_uri, actual_cost_cents,
                               usage=None, provider_request_id=None,
                               reported_cost_cents=None, artifact_type=None, via="reconciler",
                               correlation_id=None, model=None):
        """Standalone (own-transaction) entry to B1.2 completion.
        Gate D: result content is staged in durable storage before the
        completion transaction opens (skipped when the job already
        completed — a re-poll changes nothing)."""
        self._flush_reads()
        existing = self.get_provider_job(job_id)
        if not existing:
            raise CoordinatorError(f"unknown provider job {job_id}")
        staged = None
        if data is not None and existing["status"] != "COMPLETED":
            staged = self._prepare_completion_content(
                str(existing["unit_id"]), data, None, None, self.actor)
            data = staged["data"]
        with self.conn.transaction():
            cur = self.conn.cursor()
            cur.execute("SELECT * FROM provider_jobs WHERE job_id=%s FOR UPDATE", (job_id,))
            job = cur.fetchone()
            if not job:
                raise CoordinatorError(f"unknown provider job {job_id}")
            cur.execute("SELECT * FROM execution_units WHERE unit_id=%s FOR UPDATE",
                        (job["unit_id"],))
            unit = cur.fetchone()
            return self._complete_provider_job_txn(
                cur, job, unit, data, storage_uri, actual_cost_cents, usage=usage,
                provider_request_id=provider_request_id,
                reported_cost_cents=reported_cost_cents, artifact_type=artifact_type, via=via,
                candidate=staged["candidate"] if staged else None,
                correlation_id=correlation_id, model=model)

    def _fail_provider_job_txn(self, cur, job, unit, reported_cost_cents=None,
                               provider_request_id=None, usage=None, via="callback",
                               correlation_id=None):
        """Provider-reported failure (B1.3): job FAILED; the unit leaves
        AWAITING_PROVIDER via transient_error — reservations are released
        only by the retry path, never silently. A reported charge is
        recorded as PROVIDER_REPORTED evidence awaiting explicit settlement."""
        raw = {"failure_code": "PROVIDER_ERROR", "via": via}
        if correlation_id:
            raw["correlation_id"] = correlation_id
        cur.execute(
            "UPDATE provider_jobs SET status='FAILED', raw_response=%s WHERE job_id=%s",
            (json.dumps(raw), job["job_id"]))
        if reported_cost_cents is not None:
            self._evidence(cur, job["production_id"], job["unit_id"], job["attempt_id"],
                           job["provider"], "PROVIDER_REPORTED", reported_cost_cents,
                           usage=usage, provider_request_id=provider_request_id,
                           provider_job_id=job["job_id"], requires_reconciliation=True)
        if unit["state"] == "AWAITING_PROVIDER":
            self._transition(cur, unit, "transient_error", {"via": via})
        elif unit["state"] == "UNKNOWN":
            self._transition(cur, unit, "reconciled_failed", {"via": via})
        return {"outcome": "failed"}

    def handle_callback(self, idempotency_key, artifact_type, data: bytes, storage_uri,
                        actual_cost_cents, usage=None, provider_request_id=None,
                        reported_cost_cents=None, status="COMPLETED",
                        correlation_id=None, model=None):
        """Claim-first exactly-once callback (T-PRV-01), rewired in Gate C
        onto the B1.2 completion machinery: the first delivery inserts its
        delivery row with processed=true in the same transaction as the
        effects; duplicates record a delivery with processed=false and
        change nothing (the 007 partial unique index makes the processed
        row unique at the schema level). A failure delivery (status !=
        COMPLETED) routes through _fail_provider_job_txn."""
        self._flush_reads()
        staged = None
        if status == "COMPLETED" and data:
            # Gate D: stage the result content before the exactly-once
            # transaction; a duplicate delivery skips staging entirely
            # (its recorded outcome is returned unchanged below).
            cur = self.conn.cursor()
            cur.execute("SELECT unit_id FROM provider_jobs WHERE idempotency_key=%s",
                        (idempotency_key,))
            job_row = cur.fetchone()
            cur.execute("SELECT count(*) AS n FROM callback_deliveries"
                        " WHERE idempotency_key=%s AND processed", (idempotency_key,))
            already = cur.fetchone()["n"] > 0
            self._flush_reads()
            if job_row and not already:
                staged = self._prepare_completion_content(
                    str(job_row["unit_id"]), data, None, None, self.actor)
                data = staged["data"]
        with self.conn.transaction():
            cur = self.conn.cursor()
            cur.execute("SELECT * FROM provider_jobs WHERE idempotency_key=%s FOR UPDATE",
                        (idempotency_key,))
            job = cur.fetchone()
            if not job:
                raise CoordinatorError(f"callback for unknown idempotency key {idempotency_key}")
            cur.execute("SELECT count(*) AS n FROM callback_deliveries WHERE idempotency_key=%s AND processed",
                        (idempotency_key,))
            already = cur.fetchone()["n"] > 0
            if already:
                cur.execute("SELECT result FROM callback_deliveries WHERE idempotency_key=%s AND processed",
                            (idempotency_key,))
                recorded = cur.fetchone()["result"]
                cur.execute("INSERT INTO callback_deliveries(idempotency_key, processed, result) VALUES (%s,false,%s)",
                            (idempotency_key, json.dumps(recorded, default=str)))
                return {"duplicate": True, "result": recorded}
            cur.execute("SELECT * FROM execution_units WHERE unit_id=%s FOR UPDATE", (job["unit_id"],))
            unit = cur.fetchone()
            if status != "COMPLETED":
                outcome = self._fail_provider_job_txn(
                    cur, job, unit, reported_cost_cents=reported_cost_cents,
                    provider_request_id=provider_request_id, usage=usage,
                    correlation_id=correlation_id)
            else:
                outcome = self._complete_provider_job_txn(
                    cur, job, unit, data, storage_uri, actual_cost_cents, usage=usage,
                    provider_request_id=provider_request_id,
                    reported_cost_cents=reported_cost_cents, artifact_type=artifact_type,
                    candidate=staged["candidate"] if staged else None,
                    correlation_id=correlation_id, model=model)
            result = {"artifact_id": outcome.get("artifact_id"), "sha256": outcome.get("sha256"),
                      "outcome": outcome["outcome"]}
            if outcome.get("unresolved_evidence_id"):
                # MM-08: surface the missing-usage flag on the callback
                # result (additive; present only when the completion
                # left an UNRESOLVED charge).
                result["unresolved_evidence_id"] = outcome["unresolved_evidence_id"]
            cur.execute("INSERT INTO callback_deliveries(idempotency_key, processed, result) VALUES (%s,true,%s)",
                        (idempotency_key, json.dumps(result, default=str)))
            return {"duplicate": False, "result": result}

    def reconcile_once(self, provider, unresolved_threshold_s=3600):
        """Gate C reconciler v2 (design B1.4). provider: object with
        poll(provider_job_id) -> dict with 'state' in
        completed|failed|processing|not_found, plus result bytes/cost when
        completed. Jobs WITH attempt linkage complete through the B1.2
        machinery; legacy jobs without linkage are reported as
        'legacy_unlinked' and NEVER auto-completed or polled.

        MM-08: the cycle report (last_reconcile_report) also carries
        the UNRESOLVED charges (missing-usage records) still requiring
        reconciliation and older than unresolved_threshold_s — the
        missing-usage detection surface. Reporting only: an unresolved
        charge is never auto-resolved here."""
        cur = self.conn.cursor()
        cur.execute(
            "SELECT * FROM provider_jobs WHERE status IN ('SUBMITTED','PROCESSING','UNKNOWN','TIMEOUT')"
            " AND poll_count < max_poll_attempts")
        jobs = cur.fetchall()
        # End the selection read transaction BEFORE processing: with
        # autocommit=False, an open read transaction makes every per-job
        # transaction() a savepoint inside it, and all reconciler effects roll
        # back when the connection closes (verifier defect D1).
        self.conn.commit()
        outcomes = []
        legacy = 0
        for job in jobs:
            if job["attempt_id"] is None:
                legacy += 1
                outcomes.append((str(job["job_id"]), "legacy_unlinked"))
                continue
            status = provider.poll(job["provider_job_id"])
            if status["state"] == "completed":
                with self.conn.transaction():
                    c2 = self.conn.cursor()
                    c2.execute("UPDATE provider_jobs SET poll_count=poll_count+1, last_polled_at=now() WHERE job_id=%s",
                               (job["job_id"],))
                outcome = self._complete_provider_job(
                    job["job_id"], status["data"], status["storage_uri"], status["cost_cents"],
                    artifact_type=status.get("artifact_type"), via="reconciler")
                outcomes.append((str(job["job_id"]), outcome["outcome"]))
                continue
            with self.conn.transaction():
                c2 = self.conn.cursor()
                c2.execute("UPDATE provider_jobs SET poll_count=poll_count+1, last_polled_at=now() WHERE job_id=%s",
                           (job["job_id"],))
                unit = self._unit(c2, job["unit_id"])
                if status["state"] == "failed":
                    c2.execute("UPDATE provider_jobs SET status='FAILED', raw_response=%s WHERE job_id=%s",
                               (json.dumps({"failure_code": "PROVIDER_ERROR",
                                            "error": status.get("error")}), job["job_id"]))
                    if unit["state"] in ("UNKNOWN", "AWAITING_PROVIDER"):
                        ev = "reconciled_failed" if unit["state"] == "UNKNOWN" else "transient_error"
                        self._transition(c2, unit, ev, {"via": "reconciler"})
                    outcomes.append((str(job["job_id"]), "failed"))
                elif status["state"] == "not_found":
                    c2.execute("UPDATE provider_jobs SET status='NOT_FOUND' WHERE job_id=%s", (job["job_id"],))
                    if unit["state"] in ("UNKNOWN", "AWAITING_PROVIDER"):
                        ev = "reconciled_failed" if unit["state"] == "UNKNOWN" else "transient_error"
                        self._transition(c2, unit, ev, {"via": "reconciler", "reason": "PROVIDER_LOST_JOB"})
                    outcomes.append((str(job["job_id"]), "not_found"))
                else:
                    c2.execute("UPDATE provider_jobs SET status='PROCESSING' WHERE job_id=%s AND status<>'UNKNOWN'",
                               (job["job_id"],))
                    outcomes.append((str(job["job_id"]), "processing"))
        ucur = self.conn.cursor()
        ucur.execute(
            "SELECT evidence_id, production_id, unit_id, attempt_id, provider,"
            " amount_cents, EXTRACT(EPOCH FROM (now() - created_at)) AS age_s"
            " FROM financial_evidence WHERE charge_class='UNRESOLVED'"
            " AND requires_reconciliation"
            " AND created_at <= now() - (%s || ' seconds')::interval"
            " ORDER BY created_at", (unresolved_threshold_s,))
        unresolved = [
            {"evidence_id": str(r["evidence_id"]),
             "production_id": str(r["production_id"]),
             "unit_id": str(r["unit_id"]),
             "attempt_id": str(r["attempt_id"]) if r["attempt_id"] else None,
             "provider": r["provider"], "amount_cents": r["amount_cents"],
             "age_s": int(r["age_s"])} for r in ucur.fetchall()]
        self.conn.commit()
        self.last_reconcile_report = {"outcomes": outcomes,
                                      "legacy_unlinked": legacy,
                                      "unresolved_charges": unresolved,
                                      "unresolved_charge_count": len(unresolved)}
        return outcomes

    # ------------------------------------------------------ invalidation (§7.6)
    def invalidate_artifact(self, artifact_id, reason, actor, cascade=True, co_authorizer=None):
        """Gate C / GB-SEC-02 (design B4.3): the master_authority request-body
        boolean is gone. Authority for a master_package artifact is a DATA
        rule checked here: an APPROVED HG4 gate bound to this exact artifact
        (id + hash), or a recorded co-authorizer different from the actor
        (four-eyes). Refusals commit an audit event before PermissionError is
        raised. cascade=False invalidates only the source artifact itself."""
        self._flush_reads()
        cur = self.conn.cursor()
        cur.execute("SELECT * FROM artifacts WHERE artifact_id=%s", (artifact_id,))
        source = cur.fetchone()
        if not source:
            raise CoordinatorError("artifact not found")
        if source["artifact_type"] == "master_package":
            cur.execute(
                "SELECT count(*) AS n FROM human_gates WHERE production_id=%s"
                " AND gate_kind='HG4' AND artifact_id=%s AND verdict='APPROVED'"
                " AND artifact_sha256=%s",
                (source["production_id"], artifact_id, source["sha256"]))
            hg4_ok = cur.fetchone()["n"] > 0
            four_eyes = bool(co_authorizer) and co_authorizer != actor
            if not (hg4_ok or four_eyes):
                self._flush_reads()
                with self.conn.transaction():
                    c2 = self.conn.cursor()
                    self._audit(c2, source["production_id"], None,
                                "master_invalidation_refused", None, None,
                                {"artifact_id": str(artifact_id), "actor": actor,
                                 "co_authorizer": co_authorizer})
                raise PermissionError(
                    "invalidating a master_package requires an APPROVED HG4 gate "
                    "bound to the artifact or a co-authorizer distinct from the actor")
        self._flush_reads()
        with self.conn.transaction():
            cur = self.conn.cursor()
            cur.execute("SELECT * FROM artifacts WHERE artifact_id=%s FOR UPDATE", (artifact_id,))
            source = cur.fetchone()
            if not source:
                raise CoordinatorError("artifact not found")
            if cascade:
                cur.execute(
                    "WITH RECURSIVE affected AS ("
                    "  SELECT consumer_artifact_id AS aid, 1 AS depth FROM artifact_dependencies WHERE consumed_artifact_id=%s"
                    "  UNION"
                    "  SELECT d.consumer_artifact_id, a.depth+1 FROM artifact_dependencies d"
                    "  JOIN affected a ON d.consumed_artifact_id=a.aid WHERE a.depth<50)"
                    " SELECT DISTINCT aid FROM affected", (artifact_id,))
                affected_ids = [uuid.UUID(str(r["aid"])) for r in cur.fetchall()]
            else:
                affected_ids = []
            all_ids = [uuid.UUID(str(artifact_id))] + affected_ids
            # 1. fence out live workers on units that produced affected artifacts
            cur.execute(
                "SELECT DISTINCT produced_by_unit AS uid FROM artifacts WHERE artifact_id = ANY(%s) AND produced_by_unit IS NOT NULL",
                (all_ids,))
            unit_ids = [r["uid"] for r in cur.fetchall()]
            for uid_ in unit_ids:
                cur.execute("UPDATE execution_units SET fencing_token=fencing_token+1 WHERE unit_id=%s", (uid_,))
                cur.execute("DELETE FROM worker_leases WHERE unit_id=%s", (uid_,))
            # 2. invalidate artifacts (rows kept, append-only evidence)
            cur.execute(
                "UPDATE artifacts SET state='INVALIDATED', invalidated_by=%s, invalidation_reason=%s"
                " WHERE artifact_id = ANY(%s) AND state<>'INVALIDATED'",
                (actor, reason, all_ids))
            # 3. supersede their units; replacements are planned in a NEW
            #    PARTIAL_REPAIR run (the unit uniqueness scope includes run_id,
            #    and a repair is a distinct run by definition). History preserved.
            new_units = []
            repair_run_id = None
            for uid_ in unit_ids:
                cur.execute("SELECT * FROM execution_units WHERE unit_id=%s", (uid_,))
                old = cur.fetchone()
                if old["state"] in TERMINAL and old["state"] != "ACCEPTED":
                    continue
                cur.execute("UPDATE execution_units SET state='SUPERSEDED' WHERE unit_id=%s", (uid_,))
                self._audit(cur, old["production_id"], uid_, "unit_superseded", old["state"], "SUPERSEDED",
                            {"reason": reason})
                if repair_run_id is None:
                    repair_run_id = _uid()
                    cur.execute(
                        "INSERT INTO production_runs(run_id, production_id, kind, started_by)"
                        " VALUES (%s,%s,'PARTIAL_REPAIR',%s)",
                        (repair_run_id, old["production_id"], actor))
                new_id = _uid()
                cur.execute(
                    "INSERT INTO execution_units(unit_id, production_id, run_id, operation_id, unit_key, lane, supersedes_unit_id)"
                    " VALUES (%s,%s,%s,%s,%s,%s,%s)",
                    (new_id, old["production_id"], repair_run_id, old["operation_id"], old["unit_key"],
                     old["lane"], uid_))
                new_units.append(new_id)
            event_id = _uid()
            cur.execute(
                "INSERT INTO cascade_events(event_id, source_artifact_id, affected_artifact_ids, affected_unit_ids, reason, authorized_by)"
                " VALUES (%s,%s,%s,%s,%s,%s)",
                (event_id, artifact_id, all_ids, unit_ids, reason, actor))
            self._audit(cur, source["production_id"], None, "cascade", None, None,
                        {"source_artifact": artifact_id, "affected": [str(x) for x in all_ids], "reason": reason})
            result = {"affected_artifact_ids": [str(x) for x in all_ids],
                      "affected_unit_ids": [str(x) for x in unit_ids],
                      "new_unit_ids": new_units,
                      "cascade_event_id": event_id}
        # MM-10 fix (B6 cascade readiness): the replacement units are
        # planned inside the transaction above but readiness was never
        # recomputed on this path, so they sat PENDING until an
        # unrelated completion happened to trigger a recompute
        # (observed in the MM-10 battery's B6 exercise). Mirror the
        # completion path: recompute once the transaction has
        # committed (plan_unit does the same after its own commit).
        self.recompute_readiness(source["production_id"])
        return result

    # ----------------------------------------------------------- scheduler (§7.5)
    def scheduler_claim(self, worker_prefix="sched", estimate_for=None):
        """Claim READY units up to per-lane concurrency, fair across productions
        (productions with fewer in-flight units first). Returns claim dicts.

        Gate C (design B1.6): the scheduler never invents an estimate. Per
        candidate the estimate comes from estimate_for(unit_id) when the
        caller supplies one, else from the unit's resolved provider-config
        binding (B2). A candidate with no resolvable estimate is SKIPPED and
        reported in self.last_scheduler_report['skipped_no_config'] — never
        claimed at 0 (the pre-Gate-C defect this replaces).

        Fix D-H1 (design b, LOCK_FIX_DH1 §2): each claim is pre-staged
        under the EXECUTOR identity for the candidate's step
        (executor_worker_id_for_operation) — the n8n executor that will
        serve the unit resumes this attempt instead of claiming again.
        Budget reservation, config resolution, lane gating and the
        dispatch outbox event are unchanged; the audit actor remains this
        coordinator's (the scheduler's). worker_prefix is retained for
        call compatibility only and no longer shapes the identity."""
        cur = self.conn.cursor()
        cur.execute("SELECT lane, max_concurrency FROM capacity_policies WHERE enabled")
        caps = {r["lane"]: r["max_concurrency"] for r in cur.fetchall()}
        cur.execute("SELECT lane, count(*) AS n FROM execution_units WHERE state IN ('CLAIMED','RUNNING') GROUP BY lane")
        inflight = {r["lane"]: r["n"] for r in cur.fetchall()}
        cur.execute(
            "SELECT u.*, (SELECT count(*) FROM execution_units x WHERE x.production_id=u.production_id"
            " AND x.state IN ('CLAIMED','RUNNING')) AS prod_inflight"
            " FROM execution_units u WHERE u.state='READY' ORDER BY prod_inflight ASC, u.created_at ASC")
        candidates = cur.fetchall()
        self.conn.commit()  # end the snapshot read txn; claims are their own txns (D1 class)
        claimed = []
        skipped_no_config = []
        for unit in candidates:
            lane = unit["lane"]
            if inflight.get(lane, 0) >= caps.get(lane, 0):
                continue
            unit_id = str(unit["unit_id"])
            if estimate_for is not None:
                est = estimate_for(unit_id)
            else:
                config = self.resolve_config_for_unit(unit_id)
                est = config["est_cost_cents"] if config else None
                self.conn.commit()  # close the read txn opened by resolution
            if est is None:
                skipped_no_config.append(unit_id)
                continue
            try:
                res = self.claim(
                    unit_id,
                    executor_worker_id_for_operation(unit["operation_id"]), est)
            except (GateNotSatisfied, BudgetExceeded, StaleInput, UnauthorizedTransition,
                    ConfigurationMissingError, AssignmentCeilingExceeded,
                    ProviderCapExceeded):
                # A refused claim (gate requirement, budget, stale input, or a
                # race on state) skips this candidate only — its refusal
                # evidence is already committed by claim(). Without the skip,
                # one permanently-unclaimable READY unit poisons every pass
                # (G6 amendment: gate refusals made this reachable by design).
                # MM-03: an ACTIVE-assignment ceiling refusal skips the same
                # way — the unit stays READY until the ceiling or the
                # binding changes.
                continue
            claimed.append(res)
            inflight[lane] = inflight.get(lane, 0) + 1
        self.last_scheduler_report = {
            "claimed": [c["unit_id"] for c in claimed],
            "skipped_no_config": skipped_no_config}
        return claimed

    # ------------------------------------- adoption of prestaged claims (Gate 02)
    def adopt_attempt(self, unit_id, worker_id, attempt_id, idempotency_key,
                      fencing_token=None):
        """Atomically adopt a scheduler-prestaged attempt (Master Execution
        Programme Gate 02, tasks 4-7 — the Coordinator-controlled adoption
        path that supersedes LOCK_FIX_DH1's snapshot-only resume).

        The ONLY caller that receives the attempt's execution credentials
        (fencing token + resolved-config snapshot) is the authenticated
        worker whose identity equals the attempt's worker_id. Adoption is
        a one-time transition recorded on the attempt (migration 014):
          * the first valid call wins, even under concurrency — the
            conditional UPDATE ... WHERE adopted_at IS NULL serializes
            racing callers on the attempt row;
          * a later call carrying the SAME idempotency key from the SAME
            worker returns the same adoption (fresh=False), no second
            start;
          * any other post-adoption call is refused already_adopted.
        Refused, with committed adopt_refused audit evidence: attempt not
        found / not this unit's, unit not CLAIMED (covers cancelled and
        BLOCKED), attempt superseded by a re-claim, identity mismatch,
        attempt already started (finished, output set, or a provider job
        references it), no lease, lease expired, presented fencing token
        stale. Adoption is NOT a start: the unit stays CLAIMED and the
        attempt's lifecycle is untouched."""
        self._flush_reads()  # D1 class: never nest under a dangling read txn
        try:
            with self.conn.transaction():
                cur = self.conn.cursor()
                return self._adopt_txn(cur, unit_id, worker_id, attempt_id,
                                       idempotency_key, fencing_token)
        except AdoptRefused as exc:
            with self.conn.transaction():
                cur = self.conn.cursor()
                cur.execute("SELECT production_id FROM execution_units"
                            " WHERE unit_id=%s", (unit_id,))
                row = cur.fetchone()
                if row:
                    self._audit(cur, row["production_id"], unit_id,
                                "adopt_refused", None, None,
                                {"worker_id": worker_id,
                                 "attempt_id": str(attempt_id),
                                 "reason": exc.reason})
            raise

    def _adopt_credentials(self, cur, unit, attempt, lease, fresh):
        return {
            "unit_id": str(unit["unit_id"]),
            "attempt_id": str(attempt["attempt_id"]),
            "attempt_no": attempt["attempt_no"],
            "worker_id": attempt["worker_id"],
            "fencing_token": unit["fencing_token"],
            "resolved_config": attempt["resolved_config"],
            "resolved_config_hash": attempt["resolved_config_hash"],
            "lease_expires_at": (lease["expires_at"].isoformat()
                                 if lease and lease.get("expires_at") else None),
            "adopted": True,
            "fresh": fresh,
        }

    def _adopt_txn(self, cur, unit_id, worker_id, attempt_id, idempotency_key,
                   fencing_token):
        unit = self._unit(cur, unit_id)  # SELECT ... FOR UPDATE: serializes
        cur.execute("SELECT * FROM action_attempts WHERE attempt_id=%s",
                    (attempt_id,))
        attempt = cur.fetchone()
        if attempt is None or str(attempt["unit_id"]) != str(unit_id):
            raise AdoptRefused("attempt_not_found")
        cur.execute("SELECT * FROM worker_leases WHERE unit_id=%s", (unit_id,))
        lease = cur.fetchone()
        if attempt["adopted_at"] is not None:
            if (attempt["adopted_by"] == worker_id
                    and attempt["adoption_key"] == idempotency_key
                    and unit["state"] == "CLAIMED"
                    and attempt["finished_at"] is None
                    and attempt["output_artifact_id"] is None):
                return self._adopt_credentials(cur, unit, attempt, lease,
                                               fresh=False)
            raise AdoptRefused("already_adopted")
        if unit["state"] != "CLAIMED":
            raise AdoptRefused("unit_not_claimed",
                               f"unit is {unit['state']}")
        if attempt["attempt_no"] != unit["current_attempt"]:
            raise AdoptRefused("superseded")
        if attempt["worker_id"] != worker_id:
            raise AdoptRefused("identity_mismatch")
        if (attempt["status"] != "RUNNING" or attempt["finished_at"] is not None
                or attempt["output_artifact_id"] is not None):
            raise AdoptRefused("already_started")
        cur.execute("SELECT count(*) AS n FROM provider_jobs WHERE attempt_id=%s",
                    (attempt_id,))
        if cur.fetchone()["n"]:
            raise AdoptRefused("already_started", "provider job exists")
        if lease is None:
            raise AdoptRefused("no_lease")
        if lease["worker_id"] != worker_id:
            raise AdoptRefused("identity_mismatch", "lease held by another worker")
        if int(lease["fencing_token"]) != int(unit["fencing_token"]):
            raise AdoptRefused("superseded", "lease fencing is not current")
        cur.execute("SELECT now() AS now")
        if lease["expires_at"] <= cur.fetchone()["now"]:
            raise AdoptRefused("lease_expired")
        if fencing_token is not None and int(fencing_token) != int(unit["fencing_token"]):
            raise AdoptRefused("stale_fencing")
        cur.execute(
            "UPDATE action_attempts SET adopted_at=now(), adopted_by=%s,"
            " adoption_key=%s WHERE attempt_id=%s AND adopted_at IS NULL",
            (worker_id, idempotency_key, attempt_id))
        if cur.rowcount != 1:
            raise AdoptRefused("already_adopted", "lost the adoption race")
        self._audit(cur, unit["production_id"], unit_id, "attempt_adopted",
                    "CLAIMED", "CLAIMED",
                    {"attempt_id": str(attempt_id),
                     "attempt_no": attempt["attempt_no"],
                     "worker_id": worker_id,
                     "fencing_token": unit["fencing_token"]})
        return self._adopt_credentials(cur, unit, attempt, lease, fresh=True)

    # ------------------------------------------------------------- lease reaper
    def reap_expired_leases(self):
        self._flush_reads()
        """Expire dead leases: CLAIMED/RUNNING units with an expired lease go to
        RETRY_WAIT — unless a provider job is outstanding, in which case the unit
        goes UNKNOWN and reconciliation owns it (§7.3/§7.7 R2)."""
        moved = []
        with self.conn.transaction():
            cur = self.conn.cursor()
            cur.execute(
                "SELECT u.* FROM execution_units u JOIN worker_leases l ON l.unit_id=u.unit_id"
                " WHERE l.expires_at < now() AND u.state IN ('CLAIMED','RUNNING','AWAITING_PROVIDER')")
            for unit in cur.fetchall():
                cur.execute(
                    "SELECT count(*) AS n FROM provider_jobs WHERE unit_id=%s AND status IN ('SUBMITTED','PROCESSING','UNKNOWN')",
                    (unit["unit_id"],))
                outstanding = cur.fetchone()["n"] > 0
                cur.execute("DELETE FROM worker_leases WHERE unit_id=%s", (unit["unit_id"],))
                if outstanding and unit["state"] in ("RUNNING", "AWAITING_PROVIDER"):
                    self._transition(cur, unit, "provider_unknown", {"via": "lease_reaper"})
                    moved.append((str(unit["unit_id"]), "UNKNOWN"))
                elif unit["state"] in ("CLAIMED", "RUNNING"):
                    self._transition(cur, unit, "transient_error", {"via": "lease_reaper"})
                    moved.append((str(unit["unit_id"]), "RETRY_WAIT"))
        return moved
