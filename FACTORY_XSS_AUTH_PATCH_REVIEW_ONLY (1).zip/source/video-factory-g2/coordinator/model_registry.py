"""MM-03 — central model + capability registry service.

The registry is the GOVERNANCE layer above provider_configs (migration
009), which remains the executable binding store. Policies and
assignments are data with lifecycle (PROPOSED / ACTIVE / RETIRED);
PROMOTION is the only path by which a policy writes provider_configs
rows, and it is OPERATOR-only at the API boundary with the approval
recorded in policy_events. Nothing PROPOSED ever affects a claim: the
Coordinator's claim integration reads operation_model_assignments only
at status='ACTIVE'.

Promotion writes, for the policy's role:
  * one STATION-scope binding carrying the role's primary model
    (station roles only; est = the role's largest assignment ceiling),
  * one OPERATION-scope binding per model-bound assignment of the
    policy's matrix version (model + fallback/evaluation in params,
    est + max = the assignment's max_cost_cents — the C-01 ceiling).
Existing active rows for the same scope keys are superseded in the
established provider_configs versioning pattern (deactivate + insert at
version+1); history is never edited. Rollback deactivates the current
policy's rows and re-writes the predecessor's bindings as new versions.

Concurrency: promotion/rollback take a per-role transaction advisory
lock with TRY semantics — a concurrent second promoter for the same
role fails fast with PolicyConflict (typed), and the partial unique
index on ACTIVE policies per role is the structural backstop.
"""
import json

PROVIDER = "openrouter-compatible"
CREDENTIAL_REF = "OPENROUTER_API_KEY"


class RegistryError(Exception):
    status = 500


class PolicyNotFound(RegistryError):
    status = 404


class PolicyConflict(RegistryError):
    status = 409


class PolicyNotPromotable(RegistryError):
    status = 409


class ModelRegistry:
    def __init__(self, conn, environment="test", actor="registry"):
        self.conn = conn
        self.environment = environment
        self.actor = actor

    def _flush(self):
        # Same discipline as Coordinator._flush_reads: end any dangling
        # read transaction so the write below is a real transaction, not
        # a savepoint whose effects would never commit on their own.
        self.conn.commit()

    # ------------------------------------------------------------- reads
    def list_policies(self):
        cur = self.conn.cursor()
        cur.execute("SELECT * FROM model_policies ORDER BY role, version")
        return [dict(r) for r in cur.fetchall()]

    def get_policy(self, policy_id):
        cur = self.conn.cursor()
        cur.execute("SELECT * FROM model_policies WHERE policy_id=%s",
                    (policy_id,))
        row = cur.fetchone()
        return dict(row) if row else None

    def policy_events(self, policy_id):
        cur = self.conn.cursor()
        cur.execute("SELECT * FROM policy_events WHERE policy_id=%s"
                    " ORDER BY at, event_id", (policy_id,))
        return [dict(r) for r in cur.fetchall()]

    def list_assignments(self, operation_id=None, status=None):
        cur = self.conn.cursor()
        where, params = [], []
        if operation_id:
            where.append("operation_id=%s")
            params.append(operation_id)
        if status:
            where.append("status=%s")
            params.append(status)
        sql = "SELECT * FROM operation_model_assignments"
        if where:
            sql += " WHERE " + " AND ".join(where)
        sql += " ORDER BY operation_id, matrix_version"
        cur.execute(sql, params)
        return [dict(r) for r in cur.fetchall()]

    def list_models(self, provider=None):
        cur = self.conn.cursor()
        if provider:
            cur.execute("SELECT * FROM models WHERE provider=%s"
                        " ORDER BY model_id", (provider,))
        else:
            cur.execute("SELECT * FROM models ORDER BY model_id")
        return [dict(r) for r in cur.fetchall()]

    def provider_health(self):
        cur = self.conn.cursor()
        cur.execute(
            "SELECT DISTINCT ON (provider) * FROM provider_health"
            " ORDER BY provider, checked_at DESC")
        return [dict(r) for r in cur.fetchall()]

    # -------------------------------------------------- refusal evidence
    def audit_refusal(self, policy_id, action, role):
        """Committed audit row for a non-OPERATOR promotion/rollback
        attempt (the API refuses with 403 after calling this)."""
        self._flush()
        with self.conn.transaction():
            cur = self.conn.cursor()
            cur.execute(
                "INSERT INTO audit_events(production_id, unit_id, event_type,"
                " actor, payload) VALUES (NULL, NULL, 'policy_action_refused',"
                " %s, %s)",
                (self.actor, json.dumps(
                    {"policy_id": policy_id, "action": action, "role": role},
                    default=str)))

    # ------------------------------------------------------------ events
    def _event(self, cur, policy_id, action, note=None, payload=None):
        cur.execute(
            "INSERT INTO policy_events(policy_id, action, actor, note, payload)"
            " VALUES (%s,%s,%s,%s,%s)",
            (policy_id, action, self.actor, note,
             json.dumps(payload or {}, default=str)))

    # ---------------------------------------------------------- bindings
    def _supersede_binding(self, cur, scope, station, operation_id,
                           model, est, max_cost, params):
        """Write one provider_configs row in this registry's
        environment, superseding the active row of the same scope key
        (the _create_config versioning pattern). Returns the new
        config_id."""
        cur.execute(
            "SELECT config_id, version FROM provider_configs WHERE active"
            " AND scope=%s AND environment=%s AND COALESCE(station,-1)=%s"
            " AND COALESCE(operation_id,'')=%s AND COALESCE(capability_slot,'')=''"
            " AND COALESCE(action_key,'')=''",
            (scope, self.environment, station if station is not None else -1,
             operation_id or ""))
        old = cur.fetchone()
        version = 1
        if old:
            version = old["version"] + 1
            cur.execute(
                "UPDATE provider_configs SET active=false, superseded_at=now()"
                " WHERE config_id=%s", (old["config_id"],))
        cur.execute(
            "INSERT INTO provider_configs(scope, station, operation_id,"
            " environment, provider, model, params, est_cost_cents,"
            " max_cost_cents, credential_ref, version, created_by)"
            " VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s) RETURNING config_id",
            (scope, station, operation_id, self.environment, PROVIDER, model,
             json.dumps(params), est, max_cost, CREDENTIAL_REF, version,
             self.actor))
        return str(cur.fetchone()["config_id"])

    def _policy_assignments(self, cur, policy):
        cur.execute(
            "SELECT * FROM operation_model_assignments WHERE role=%s"
            " AND matrix_version=%s AND primary_model IS NOT NULL"
            " ORDER BY operation_id",
            (policy["role"], policy["version"]))
        return cur.fetchall()

    def _write_bindings(self, cur, policy):
        """Bindings for one policy: STATION row (station roles) +
        OPERATION rows for its model-bound assignments. Returns the new
        config_ids."""
        written = []
        assignments = self._policy_assignments(cur, policy)
        base_params = {"policy_id": policy["policy_id"],
                       "matrix_version": policy["version"],
                       "source": "mm03_promotion"}
        if policy["station"] is not None:
            ceilings = [a["max_cost_cents"] for a in assignments
                        if a["max_cost_cents"] is not None]
            written.append(self._supersede_binding(
                cur, "STATION", policy["station"], None,
                policy["primary_model"],
                max(ceilings) if ceilings else None, None,
                {**base_params, "fallback_model": policy["fallback_model"],
                 "evaluation_model": policy["evaluation_model"]}))
        for a in assignments:
            written.append(self._supersede_binding(
                cur, "OPERATION", None, a["operation_id"],
                a["primary_model"], a["max_cost_cents"], a["max_cost_cents"],
                {**base_params, "fallback_model": a["fallback_model"],
                 "evaluation_model": a["evaluation_model"]}))
        return written

    def _deactivate_policy_rows(self, cur, policy_id, keep=()):
        """Deactivate every still-active provider_configs row a policy's
        promotion wrote (identified by params.policy_id), except `keep`.
        Catches scope keys a newer matrix version no longer covers."""
        cur.execute(
            "UPDATE provider_configs SET active=false, superseded_at=now()"
            " WHERE active AND environment=%s AND params->>'policy_id'=%s"
            " AND NOT (config_id = ANY(%s))",
            (self.environment, policy_id,
             [str(k) for k in keep] or ["00000000-0000-0000-0000-000000000000"]))
        return cur.rowcount

    def _role_lock(self, cur, role):
        cur.execute("SELECT pg_try_advisory_xact_lock(hashtext(%s)) AS ok",
                    (f"mm03:policy:{role}",))
        if not cur.fetchone()["ok"]:
            raise PolicyConflict(
                f"a promotion/rollback for role {role} is already in flight")

    # ---------------------------------------------------------- lifecycle
    def promote(self, policy_id, approval_note=None):
        self._flush()
        with self.conn.transaction():
            cur = self.conn.cursor()
            cur.execute("SELECT * FROM model_policies WHERE policy_id=%s"
                        " FOR UPDATE", (policy_id,))
            policy = cur.fetchone()
            if not policy:
                raise PolicyNotFound(f"unknown model policy {policy_id}")
            if policy["status"] != "PROPOSED":
                raise PolicyNotPromotable(
                    f"policy {policy_id} is {policy['status']}, not PROPOSED")
            self._role_lock(cur, policy["role"])
            cur.execute("SELECT * FROM model_policies WHERE role=%s"
                        " AND status='ACTIVE'", (policy["role"],))
            prev = cur.fetchone()
            written = self._write_bindings(cur, policy)
            if prev:
                self._deactivate_policy_rows(cur, prev["policy_id"],
                                             keep=written)
                cur.execute("UPDATE model_policies SET status='RETIRED'"
                            " WHERE policy_id=%s", (prev["policy_id"],))
                cur.execute(
                    "UPDATE operation_model_assignments SET status='RETIRED'"
                    " WHERE role=%s AND matrix_version=%s AND status='ACTIVE'",
                    (prev["role"], prev["version"]))
                self._event(cur, prev["policy_id"], "RETIRE",
                            note=f"superseded by {policy_id}",
                            payload={"superseded_by": policy_id})
            cur.execute("UPDATE model_policies SET status='ACTIVE'"
                        " WHERE policy_id=%s", (policy_id,))
            cur.execute(
                "UPDATE operation_model_assignments SET status='ACTIVE'"
                " WHERE role=%s AND matrix_version=%s AND status='PROPOSED'"
                " AND primary_model IS NOT NULL",
                (policy["role"], policy["version"]))
            self._event(cur, policy_id, "PROMOTE", note=approval_note,
                        payload={"bindings_written": written,
                                 "superseded_policy_id":
                                     prev["policy_id"] if prev else None})
            return {"policy_id": policy_id, "role": policy["role"],
                    "version": policy["version"], "status": "ACTIVE",
                    "bindings_written": len(written),
                    "binding_config_ids": written,
                    "superseded_policy_id":
                        prev["policy_id"] if prev else None}

    def rollback(self, policy_id, note=None):
        """Roll the role back to the policy this one superseded: the
        current policy's bindings are deactivated and the predecessor's
        bindings are re-written as new provider_configs versions.
        Historical rows (bindings, attempts, events) are never edited."""
        self._flush()
        with self.conn.transaction():
            cur = self.conn.cursor()
            cur.execute("SELECT * FROM model_policies WHERE policy_id=%s"
                        " FOR UPDATE", (policy_id,))
            policy = cur.fetchone()
            if not policy:
                raise PolicyNotFound(f"unknown model policy {policy_id}")
            if policy["status"] != "ACTIVE":
                raise PolicyNotPromotable(
                    f"rollback requires an ACTIVE policy, {policy_id} is "
                    f"{policy['status']}")
            self._role_lock(cur, policy["role"])
            cur.execute(
                "SELECT payload FROM policy_events WHERE policy_id=%s"
                " AND action='PROMOTE' ORDER BY at DESC LIMIT 1",
                (policy_id,))
            promo = cur.fetchone()
            prev_id = (promo["payload"] or {}).get("superseded_policy_id") \
                if promo else None
            self._deactivate_policy_rows(cur, policy_id)
            cur.execute("UPDATE model_policies SET status='RETIRED'"
                        " WHERE policy_id=%s", (policy_id,))
            cur.execute(
                "UPDATE operation_model_assignments SET status='RETIRED'"
                " WHERE role=%s AND matrix_version=%s AND status='ACTIVE'",
                (policy["role"], policy["version"]))
            self._event(cur, policy_id, "ROLLBACK", note=note,
                        payload={"restored_policy_id": prev_id})
            written = []
            if prev_id:
                cur.execute("SELECT * FROM model_policies WHERE policy_id=%s",
                            (prev_id,))
                prev = cur.fetchone()
                written = self._write_bindings(cur, prev)
                cur.execute("UPDATE model_policies SET status='ACTIVE'"
                            " WHERE policy_id=%s", (prev_id,))
                cur.execute(
                    "UPDATE operation_model_assignments SET status='ACTIVE'"
                    " WHERE role=%s AND matrix_version=%s"
                    " AND status IN ('PROPOSED','RETIRED')"
                    " AND primary_model IS NOT NULL",
                    (prev["role"], prev["version"]))
                self._event(cur, prev_id, "REACTIVATE",
                            note=f"rollback of {policy_id}",
                            payload={"via_rollback_of": policy_id,
                                     "bindings_written": written})
            return {"policy_id": policy_id, "role": policy["role"],
                    "version": policy["version"], "status": "RETIRED",
                    "restored_policy_id": prev_id,
                    "bindings_written": len(written),
                    "binding_config_ids": written}
