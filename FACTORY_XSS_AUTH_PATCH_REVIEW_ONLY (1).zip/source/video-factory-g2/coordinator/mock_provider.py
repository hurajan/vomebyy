"""Simulated provider for G2 tests only. No network, no credentials, no real
provider. Behaviour is scripted per job by the test harness."""


class MockProvider:
    def __init__(self):
        self.jobs = {}          # provider_job_id -> job dict
        self.submit_count = 0
        self._seq = 0

    def submit(self, payload, mode="complete"):
        self.submit_count += 1
        self._seq += 1
        pjob = f"mock-{self._seq}"
        self.jobs[pjob] = {
            "mode": mode, "payload": payload, "polls": 0,
            "artifact_type": payload.get("artifact_type", "mock_media"),
            "data": payload.get("data", b"mock-bytes"),
            "storage_uri": f"mock://{pjob}",
            "cost_cents": payload.get("cost_cents", 100),
        }
        return pjob

    def poll(self, provider_job_id):
        job = self.jobs.get(provider_job_id)
        if job is None or job["mode"] == "lost":
            return {"state": "not_found"}
        job["polls"] += 1
        if job["mode"] == "complete":
            return {"state": "completed", "artifact_type": job["artifact_type"],
                    "data": job["data"], "storage_uri": job["storage_uri"],
                    "cost_cents": job["cost_cents"]}
        if job["mode"] == "fail":
            return {"state": "failed", "error": "mock provider failure"}
        if job["mode"] == "processing":
            return {"state": "processing"}
        if job["mode"] == "complete_on_second_poll":
            if job["polls"] >= 2:
                return {"state": "completed", "artifact_type": job["artifact_type"],
                        "data": job["data"], "storage_uri": job["storage_uri"],
                        "cost_cents": job["cost_cents"]}
            return {"state": "processing"}
        return {"state": "processing"}
