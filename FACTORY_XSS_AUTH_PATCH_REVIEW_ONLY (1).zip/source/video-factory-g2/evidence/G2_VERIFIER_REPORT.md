# G2 — Independent Verifier Report

- **Programme:** AI Video Production Factory — G2 Coordinator
- **Lock:** `LOCK_G2.md` (owner-confirmed 2026-10-27 22:45 EDT; OD-F02a Python, OD-F05 §7.1 vocabulary)
- **Verifier role:** independent — did not build G2; build tree treated as read-only
- **Date:** 2026-10-27 (America/New_York)
- **Method:** clean extraction in `/tmp/g2_clean`, verifier's own scratch DB `g2_verify_scratch`
  (dropped after verification; the builder's `g2_coordinator_scratch` was left untouched),
  verifier's own probe scripts in `/tmp/g2verify/` using the coordinator's public API plus
  direct SQL inspection through **separate** connections. The builder's evidence files were not relied on.
- **Baseline:** G1 accepted seed, `definition_hash ea4503f516fc4f7940f187f5cd9dac38c57f0d239726cac90e2d0a18a8bc9d73`

---

## Check 1 — Clean-room reproduction — **PASS**

Copied the build tree to `/tmp/g2_clean` (excluding `.venv`; venv reused read-only via symlink),
created a fresh DB with the documented command (`tools/setup_db.py g2_verify_scratch`), then ran
the builder's suite against it (`G2_TEST_DB=g2_verify_scratch`):

- **Ran 13 tests in 13.3 s — OK.** All 13 pass, matching the expected count.

## Check 2 — Transition integrity (verifier's own probes) — **PASS**

Five unauthorized-transition probes, each followed by a SQL state check on a separate connection:

| Probe | Result |
|---|---|
| `validate()` on a READY unit | `UnauthorizedTransition`; state still READY |
| `event(validation_passed)` on a PENDING unit (PENDING→ACCEPTED) | `UnauthorizedTransition`; state still PENDING |
| `claim()` on an already-CLAIMED unit | `UnauthorizedTransition`; state still CLAIMED |
| `validate()` on CLAIMED, then on RUNNING unit | `UnauthorizedTransition` both times; state unchanged |
| ACCEPTED unit: `event(cancel)` and `event(claim)` | `UnauthorizedTransition` both times; state still ACCEPTED |

## Check 3 — T-BUD-01 (independent) — **PASS**

Production ceiling 100_00. Claim of 60_00 on unit 1 succeeded. Second claim of 60_00:

- raised `BudgetExceeded`;
- unit 2 is **BLOCKED in the DB (committed — read via a separate connection)** with
  `block_reason = PRODUCTION_BUDGET_EXCEEDED`, and a `budget_exceeded` audit event exists for it (1 row);
- budget position afterwards: held = 60_00, settled = 0, held + settled ≤ ceiling.

## Check 4 — T-REC-01 (independent) — **FAIL (evidence defect D2; safety itself PASS)**

Flow: claim by worker-old → lease expired via SQL → `reap_expired_leases()` moved the unit to
RETRY_WAIT → `retry_ready` → re-claim by worker-new with a higher fencing token.

- ✅ Old worker's `complete_attempt` raised `StaleFencing`.
- ✅ The current artifact is the new worker's bytes (DB sha256 == sha256 of the new payload);
  the stale bytes were never registered as an artifact (0 rows).
- ❌ **No `STALE_FENCED` attempt row and no `stale_commit_rejected` audit event exists in the DB**
  (verifier queried both the unit and DB-wide counts: **0 and 0**). Root cause: `complete_attempt`
  inserts the STALE_FENCED attempt and the audit event **inside the same transaction that the
  `StaleFencing` raise then rolls back**, so the evidence is never committed. This is the same
  defect class the builder fixed for budget rejection (README defect #4) but the fencing path
  was not given the same treatment (signal → roll back → commit the record in its own transaction).
  Safety is intact (the stale commit is rejected and cannot corrupt state), but the append-only
  audit trail the lock requires has a hole for exactly this event class.

## Check 5 — T-PRV-01 (independent, sequential) — **PASS**

Unit claimed and started, mock provider job submitted, then the same callback delivered 4 times
sequentially (the builder's threaded variant also passed in Check 1):

- exactly **1** artifact of that type; provider job `COMPLETED`;
- `callback_deliveries`: **4 rows, exactly 1 with `processed = true`**;
- delivery results: 1 non-duplicate + 3 duplicates.

## Check 6 — Selective invalidation / cascade §7.6 (independent) — **PASS**

Chain A (canon) → B (beat_graph, produced by unit ua) → C (scene_contract, produced by unit ub),
plus unrelated D; ua and ub held budget reservations (2 RESERVE transactions) before the cascade.

After `invalidate_artifact(A)`:

- SQL states: **A, B, C = INVALIDATED; D = CURRENT** (selective — unrelated work untouched);
- exactly **1** `cascade_events` row for source A; ua and ub are `SUPERSEDED`;
- **2 replacement units** exist, joined to a run of kind `PARTIAL_REPAIR`;
- **budget_transactions unchanged**: count 2 → 2, sum 1500 → 1500 (no attempts/cost reset).

## Check 7 — Provider reconciliation §7.7 (independent) — **FAIL (critical defect D1)**

Transition logic is correct **in-connection**; durability is absent.

Completing-mock sub-case (timeout after submit → UNKNOWN, then `reconcile_once`):

- reconciler reported `completed`; the **same connection** then showed the unit as VALIDATING;
- a **separate connection still showed unit = UNKNOWN, job = UNKNOWN, poll_count = 0**;
- after closing the coordinator connection, a separate connection **still** showed UNKNOWN / poll_count 0 —
  every reconciler effect was rolled back;
- `provider.submit_count` was 1 (no resubmission) — the R2 rule itself works as designed.

Lost-job sub-case (isolated probe): in-connection the unit reached RETRY_WAIT and the job NOT_FOUND;
separate connection before and after close: unit UNKNOWN, job UNKNOWN. Same durability failure.

**Connection-poisoning side effect (also D1):** after a `reconcile_once` call, an unrelated
`create_production` on the same coordinator connection was likewise rolled back on close — the
dangling transaction swallows all subsequent work on that connection.

**Root cause:** `reconcile_once` opens a read transaction with its initial `SELECT`
(psycopg, `autocommit=False`) and never commits it. Each per-job `with self.conn.transaction()`
block therefore runs as a **savepoint inside that outer transaction**, not as a commit. Nothing
the reconciler does is ever durable. The builder's own reconciler tests pass only because they
read results back through the same connection — a test-harness blind spot (the identical pattern
is what hid this from the G1-style checks; it is also why the lock's PASS criterion
"reconciliation demonstrated / jobs survive coordinator kills" is **not** met: a coordinator
restart loses 100% of reconciler work, poll counts included, so in production the reconciler
would re-poll the same jobs forever and UNKNOWN units would never durably recover).

**Fix direction (for the builder; not applied by the verifier):** end/commit the selection read
before processing (e.g. fetch the job IDs, commit, then process each job in its own top-level
transaction) so each job's outcome commits independently.

## Check 8 — Human-gate hash binding §12 (independent) — **PASS**

Gate created for script artifact v1: `require_gate` while PENDING → `GateNotSatisfied`;
after `decide_gate(APPROVED)`, `require_gate` on v1 **passes**; after registering v2 of the
same type, `require_gate` on v2 → `GateNotSatisfied`. The approval binds to the exact hash.

## Check 9 — G1 regression — **PASS**

- In the G2 scratch DB: `operation_definitions` = **192**, `workflow_versions.definition_hash`
  = `ea4503f516fc4f7940f187f5cd9dac38c57f0d239726cac90e2d0a18a8bc9d73` (baseline).
- G1 validator (`video-factory-g1/tools/registry_tool.py validate`, run by the verifier):
  **PASS**, zero errors; source SHA-256 matches the pin.

## Check 10 — Scope — **PASS**

- Grep over `coordinator/`, `database/`, `tools/`, `tests/` (excluding `.venv`, evidence, and
  README/LOCK prose) for real provider names and credential patterns
  (openai/anthropic/claude/gpt/elevenlabs/seedance/kling/deepseek/gemini/api-key/secret/oauth…):
  **no matches**. The only provider implementation in the tree is `mock_provider.py`
  (simulated, no network, no credentials); the coordinator takes a provider *name string*
  and a duck-typed poll object — no real provider is bound.
- G1 tree untouched by G2: seed file SHA-256 is still
  `8bc567a61b60334abd36415abb84faae1486f3d2aa08f29523ddacfd408ad8d4`.

---

## Defects

- **D1 — CRITICAL: `reconcile_once` never commits (Check 7).** All reconciler state changes
  (job status, poll_count, unit transitions, registered artifacts) live in a dangling outer
  transaction and are rolled back on disconnect; subsequent unrelated operations on the same
  connection are swallowed by the same transaction. Reconciliation — a named G2 PASS criterion —
  is functionally absent in any multi-connection or restart scenario, despite returning success
  and passing the builder's same-connection tests.
- **D2 — MODERATE: stale-fencing evidence is rolled back (Check 4).** The `STALE_FENCED`
  attempt row and `stale_commit_rejected` audit event are inserted inside the transaction that
  the `StaleFencing` raise aborts, so neither is ever persisted. The rejection itself is safe;
  the append-only audit trail is incomplete for stale-commit attempts.

No other defects found. Checks 1, 2, 3, 5, 6, 8, 9, 10 all PASS as detailed above.

## NOT TESTED

- Scheduler fairness/lane caps and the T-DEP-01 stale-input guard beyond the builder's own
  tests re-run in Check 1 (both passed there; the verifier wrote no separate probes for them).
- Concurrent callback delivery under threads (covered by the builder's test in Check 1;
  the verifier's independent callback probe was sequential, per the tasking allowance).
- Multi-process coordinator contention (the lock specifies a single-writer library; not probed).
- Migration re-application/idempotency of `002` on an already-migrated DB.
- HTTP API, dashboard, station workflows, real providers, deployment — all outside the G2 lock
  (G3/G4–G8/G0) and absent from this tree.

## Verdict

**NOT VERIFIED** — defect D1 defeats a named G2 PASS criterion (reconciliation must be
demonstrated and survive coordinator kills; as built, its effects do not survive a disconnect),
and D2 leaves a hole in the required audit trail. All other checks pass. Both defects are
localized transaction-boundary bugs with known fix patterns (the codebase already contains the
correct pattern in `claim()`'s budget path); re-verification can be scoped to Checks 4 and 7
plus a regression re-run once the builder reports a fix.
