# G2 — Independent RE-Verification Report (D1/D2 fix confirmation)

- **Programme:** AI Video Production Factory — G2 Coordinator
- **Re-verifier role:** independent — did not build G2 and did not perform the first verification. Scope: the two defects from `G2_VERIFIER_REPORT.md` (D1, D2), two further durability checks of the same class (gates, scheduler), the builder's fix in code, and regression.
- **Date:** 2026-10-27 (America/New_York)
- **Method:** clean copy of the tree in `/tmp/g2_reverify` (`.venv` symlinked read-only), re-verifier's own fresh scratch DB `g2_reverify_scratch` (created via `tools/setup_db.py`, **dropped after verification**), re-verifier's own probe script (`/tmp/g2reverify_probes.py`, 22 assertions). **Every durability assertion was made through a separate raw psycopg connection** (new connection per assertion block), never through the writer's connection. The builder's evidence files were not relied on.
- **Baseline:** G1 `definition_hash ea4503f516fc4f7940f187f5cd9dac38c57f0d239726cac90e2d0a18a8bc9d73`

---

## Check 1 — D1 re-check: `reconcile_once` durability — **PASS**

Own probe flow (claim → start → submit mock job → attach completing mock job → `provider_timeout` → `reconcile_once`), asserted via separate connections:

| Assertion | Result |
|---|---|
| Pre-reconcile unit is UNKNOWN (committed) | state = UNKNOWN |
| After reconcile: unit state via separate connection | **VALIDATING** (was UNKNOWN forever in the first verification) |
| `provider_jobs` via separate connection | **status = COMPLETED, poll_count = 1** (was UNKNOWN / 0) |
| No resubmission (R2) | mock `submit_count` = 1 |
| Lost-job case via separate connection | job = **NOT_FOUND**, unit = **RETRY_WAIT** (both committed) |
| Connection not poisoned afterwards | an unrelated `create_production` on the **same** coordinator after `reconcile_once` is visible from a separate connection (title row present) |

D1 is fixed behaviourally, including its connection-poisoning side effect.

## Check 2 — D2 re-check: stale-fencing evidence durability — **PASS**

Own probe: claim by worker-old → lease expired via SQL → reaper → RETRY_WAIT → retry_ready → re-claim by worker-new (fencing 1 → 2) → old worker `complete_attempt` raises `StaleFencing` → new worker completes. Via separate connections:

- **exactly 1** `action_attempts` row with status `STALE_FENCED` for the unit (was 0);
- **exactly 1** `stale_commit_rejected` audit event for the unit (was 0);
- the current artifact's sha256 equals sha256 of the new worker's payload (`1f52aac46a1d…`), state CURRENT; the stale payload was never registered as an artifact (0 rows).

## Check 3 — Gate durability (third instance of the class) — **PASS**

Gate created and APPROVED on coordinator A. Via a separate raw connection the verdict is committed (APPROVED). From a **second** Coordinator/connection: `require_gate` **passes** for the approved artifact and **raises `GateNotSatisfied`** for a re-registered v2 of the same type (new hash). Hash binding + cross-connection durability both hold.

## Check 4 — Scheduler durability — **PASS**

`scheduler_claim` on one coordinator (unit in the `video` lane); a separate connection sees the unit as **CLAIMED**.

## Check 5 — Regression — **PASS**

- **Full builder suite from the clean copy against the fresh DB: Ran 17 tests in 15.3 s — OK** (13 original + 4 durability, matching the builder's reported count; the 4 durability tests assert through separate connections).
- Own spot re-checks (all via separate connections, 22/22 probe assertions PASS overall):
  - **T-BUD-01:** second 60_00 claim against a 100_00 ceiling raised `BudgetExceeded`; unit BLOCKED with `block_reason = PRODUCTION_BUDGET_EXCEEDED` **committed**, plus exactly 1 `budget_exceeded` audit event.
  - **T-PRV-01:** same callback delivered ×4 sequentially (each from a fresh coordinator) → **1** artifact, 4 delivery rows, exactly **1** processed.
  - **Cascade:** A→B→C all INVALIDATED, unrelated D still CURRENT; `budget_transactions` unchanged (count 2 → 2, sum 1500 → 1500 cents) — no attempts/cost reset.
  - **G1 regression:** in-DB `operation_definitions` = **192**, `workflow_versions.definition_hash` = baseline `ea4503f5…`; G1 validator re-run: **PASS**, zero errors, source SHA-256 matches the pin; the G1 seed file's SHA-256 is still `8bc567a61b60334abd36415abb84faae1486f3d2aa08f29523ddacfd408ad8d4` (G1 untouched by the G2 fixes).

## Check 6 — Code inspection: root cause or symptom? — **Root cause addressed**

Read `coordinator/coordinator.py` in full and audited every write entry point (grep of `def` / `_flush_reads()` / `conn.commit()` / `conn.transaction()`):

1. **`reconcile_once` (D1 site):** the selection `SELECT` is followed by an explicit `self.conn.commit()` *before* the per-job loop, so each job's `transaction()` block is a top-level commit, not a savepoint inside a dangling read transaction. Comment in code names the D1 mechanism correctly.
2. **`complete_attempt` (D2 site):** the work runs in `_complete_attempt_txn`; on `StaleFencing` the wrapper writes the `STALE_FENCED` attempt + `stale_commit_rejected` audit in a **new** transaction after the doomed one rolls back — the same signal→rollback→commit-the-record pattern the codebase already used in `claim()`'s budget path.
3. **Systemic guard:** `_flush_reads()` (a `commit()`, no-op when idle) is called at the top of **every** public write method — `create_production`, `start_run`, `plan_unit`, `recompute_readiness`, `event`, `register_artifact`, `claim`, `heartbeat`, `complete_attempt`, `validate`, `decide_gate`, `submit_provider_job`, `attach_provider_job_id`, `provider_timeout`, `handle_callback`, `invalidate_artifact`, `reap_expired_leases`. The two snapshot-read methods (`reconcile_once`, `scheduler_claim`) use the explicit-commit variant. The private `_claim_txn` / `_complete_attempt_txn` are only invoked from flushing wrappers.
4. **`create_gate` read-then-write (specifically requested):** it performs its artifact `SELECT` first, *then* calls `_flush_reads()` (line 464) before opening the write transaction (line 465). Placement is after the read rather than at the method top, but the commit lands before the write transaction opens, which is what the defect class turns on — and Check 3 proves it behaviourally (gate created after that SELECT, decided, and enforced from a second connection). **No write path was found that still leaves a dangling read transaction before a write.**
5. Residual observations (not defects): read-only methods (`get_unit`, `verify_inputs_current`, `budget_position`, `require_gate`) leave a read transaction open by design — safe because every write entry point flushes first; `verify_inputs_current`/`budget_position` are also called *inside* open write transactions, where joining the caller's transaction is correct. `_flush_reads` uses an unconditional `commit()`: correct for this library's usage (all writes go through its own transaction blocks), but it would silently commit any uncommitted work a future consumer performed by hand on the coordinator's connection between calls — worth a docstring warning if the connection is ever exposed directly. The stale-evidence insert uses `attempt_no = current_attempt + 1000` to avoid the `(unit_id, attempt_no)` uniqueness scope — works (Check 2, exactly 1 row), slightly opaque.

Because the fix operates at all three levels — the two named sites, plus a guard that makes the whole read-then-write class default-safe — it addresses the root cause (psycopg `autocommit=False` read transactions turning later `transaction()` blocks into savepoints), not merely the two symptoms.

---

## Defects

**NONE.** D1 and D2 are confirmed fixed; the two additional durability probes of the same class (gates, scheduler) pass; no regression found.

## NOT TESTED

- Concurrent/threaded callback delivery in my own probes (sequential ×4 only; the builder's threaded variant is inside the 17-test suite re-run in Check 5 and passed).
- Multi-process coordinator contention (lock specifies a single-writer library).
- Migration re-application/idempotency of `002` on an already-migrated DB.
- `complete_on_second_poll` / `processing` / `failed` reconciler branches beyond the builder's suite (my D1 probes covered `completed` and `not_found`).
- HTTP API, dashboard, station workflows, real providers, deployment — outside the G2 lock (G3 / G4–G8 / G0), absent from this tree.

## Verdict

**VERIFIED** — for G2. Both defects from the first verification are independently confirmed fixed with cross-connection evidence, the previously passing checks show no regression, and the fix addresses the root-cause transaction-boundary pattern. This re-verification does not make G2 ACCEPTED or FROZEN; acceptance rests with the owner.
