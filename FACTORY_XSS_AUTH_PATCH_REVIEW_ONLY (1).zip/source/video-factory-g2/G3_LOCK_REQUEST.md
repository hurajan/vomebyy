# G3 LOCK REQUEST — Dashboard + Coordinator API (PREPARED, not confirmed)

Prepared 2026-10-27 after G2 was independently VERIFIED. **No G3 work starts until Raj accepts G2 and confirms this lock.**

## Proposed scope
Baseline: G2 coordinator library (verified) + G1 registry. Evolve — do not replace — the
M8-verified Control Tower approach (`index.html`-style single-page operator UI is the
starting reference in the frozen repo, read-only).

In:
1. **Thin HTTP API over the coordinator library** (Python, same process family as the
   coordinator; endpoints mirror coordinator methods 1:1 — productions, runs, units,
   claims, gates, budget position, artifacts, cascade preview, health). Contract-first:
   an OpenAPI/JSON-Schema contract in the repo, with contract tests running the UI's
   exact calls against a live API + scratch PG16 (the M8 lesson: no screen is done
   against a mocked shape).
2. **Dashboard screens (A–Z §13):** intake wizard (Steps 01–02), productions list +
   16-step tracker, operation ledger (192 ops per production with attempts/cost/verdicts),
   artifact viewer with hashes + dependency graph, gate inbox (decisions from each
   gate's own decision set), finance view (held/settled, cost per accepted second,
   ceiling meters, unresolved charges), repair console with invalidation preview,
   provider/health view.
3. **Mock-production walkthrough:** simulated workers (G2 mock harness) drive a full
   intake → gates → repair → completion pass; PASS = a nontechnical operator script
   (checklist) completes it unaided against the real API.

Out: station workflows (G4–G8), real providers, OVHcloud (G0/G0.6), auth hardening
beyond a single operator token for local use (production auth is a G0/G8 concern,
recorded as a limitation, not silently skipped), any change to G1 seed or G2 schema
(a schema need found in G3 is an owner decision, not an edit).

PASS: contract tests green; walkthrough checklist completed; G1 + G2 regression
(7 + 17 tests + validators) green; builder ≠ verifier.
