#!/usr/bin/env python3
"""PRODUCTION SAFETY GUARD: historical scratch database initializer disabled.
The original developer-only script is preserved as .py.development-only.disabled
for audit; it must not be used to provision a deployment database.
"""
raise SystemExit("BLOCKED: destructive scratch setup is disabled in release builds; use audited forward-only migrations")
