import os
import subprocess
import sys
import threading
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "coordinator"))
DB = os.environ.get("G2_TEST_DB", "g2_coordinator_scratch")
DSN = f"host=127.0.0.1 dbname={DB} user=factory password=factory_dev_local"  # TCP: socket peer-auth rejects password logins

from coordinator import (  # noqa: E402
    BudgetExceeded, Coordinator, GateNotSatisfied, StaleFencing, StaleInput,
    UnauthorizedTransition)
from mock_provider import MockProvider  # noqa: E402


def fresh_coord():
    return Coordinator(DSN)


class Base(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        subprocess.run([str(ROOT / ".venv" / "bin" / "python"),
                        str(ROOT / "tools" / "setup_db.py"), DB],
                       check=True, capture_output=True)

    def setUp(self):
        self.c = fresh_coord()
        self.pid = self.c.create_production("Test production", 100_00, 80_00, "tester")
        self.run = self.c.start_run(self.pid, "FULL", "tester")

    def tearDown(self):
        self.c.close()

    def plan(self, op, key="main", lane="text", deps=(), inputs=()):
        return self.c.plan_unit(self.pid, self.run, op, key, lane, deps, inputs)

    def drive_to_accepted(self, unit_id, worker="w1", est=100, cost=90, data=b"payload"):
        claim = self.c.claim(unit_id, worker, est)
        art = self.c.complete_attempt(unit_id, worker, claim["fencing_token"],
                                      "generic_artifact", data, "local://x", cost)
        state = self.c.validate(unit_id, [{
            "validator": "schema_validation", "method": "contract", "verdict": "PASS",
            "evaluator": "test", "evidence": {}}])
        self.assertEqual(state, "ACCEPTED")
        return art


class TestTransitions(Base):
    def test_happy_path_and_illegal_transitions(self):
        u = self.plan("01.01")
        self.assertEqual(self.c.get_unit(u)["state"], "READY")
        with self.assertRaises(UnauthorizedTransition):
            self.c.event(u, "validation_passed")   # READY cannot validate
        with self.assertRaises(UnauthorizedTransition):
            self.c.event(u, "start")               # READY cannot start directly
        self.drive_to_accepted(u)
        with self.assertRaises(UnauthorizedTransition):
            self.c.event(u, "claim")               # ACCEPTED is terminal
        with self.assertRaises(UnauthorizedTransition):
            self.c.claim(u, "w2", 10)

    def test_dependency_readiness(self):
        a = self.plan("01.01")
        b = self.plan("01.02", deps=(a,))
        self.assertEqual(self.c.get_unit(b)["state"], "PENDING")
        self.drive_to_accepted(a)
        self.assertEqual(self.c.get_unit(b)["state"], "READY")


class TestDepGuard(Base):
    def test_T_DEP_01_superseded_input_refused(self):
        bg = self.c.register_artifact(self.pid, "beat_graph", b"v1", "local://bg1")
        scene = self.plan("07.01", inputs=(bg["artifact_id"],))
        self.assertTrue(self.c.verify_inputs_current(scene))
        self.c.register_artifact(self.pid, "beat_graph", b"v2", "local://bg2")  # supersedes v1
        with self.assertRaises(StaleInput):
            self.c.verify_inputs_current(scene)
        with self.assertRaises(StaleInput):
            self.c.claim(scene, "w1", 0)


class TestBudget(Base):
    def test_T_BUD_01_parallel_claims_cannot_exceed_ceiling(self):
        self.c.close()
        self.c = fresh_coord()
        self.pid = self.c.create_production("Budget race", 100_00, 80_00, "tester")
        self.run = self.c.start_run(self.pid, "FULL", "tester")
        u1 = self.plan("11.01", key="a")
        u2 = self.plan("11.02", key="b")
        self.c.claim(u1, "w1", 60_00)
        with self.assertRaises(BudgetExceeded):
            self.c.claim(u2, "w2", 60_00)
        self.assertEqual(self.c.get_unit(u2)["state"], "BLOCKED")
        pos = self.c.budget_position(self.pid)
        self.assertEqual(pos["held_cents"], 60_00)
        self.assertLessEqual(pos["projected_cents"], pos["hard_ceiling_cents"])

    def test_settle_and_release_accounting(self):
        u = self.plan("11.01")
        claim = self.c.claim(u, "w1", 50_00)
        pos = self.c.budget_position(self.pid)
        self.assertEqual(pos["held_cents"], 50_00)
        self.c.complete_attempt(u, "w1", claim["fencing_token"], "media", b"m", "local://m", 42_00)
        pos = self.c.budget_position(self.pid)
        self.assertEqual(pos["held_cents"], 0)
        self.assertEqual(pos["settled_cents"], 42_00)
        cur = self.c.conn.cursor()
        cur.execute("SELECT kind, amount_cents FROM budget_transactions WHERE production_id=%s ORDER BY txn_id",
                    (self.pid,))
        rows = [(r["kind"], r["amount_cents"]) for r in cur.fetchall()]
        self.assertEqual(rows, [("RESERVE", 50_00), ("CHARGE", 42_00)])


class TestFencing(Base):
    def test_T_REC_01_stale_worker_cannot_commit(self):
        u = self.plan("08.05", key="scene-1")
        first = self.c.claim(u, "worker-old", 100)
        # simulate lease expiry + reaper
        cur = self.c.conn.cursor()
        cur.execute("UPDATE worker_leases SET expires_at=now() - interval '1 second' WHERE unit_id=%s", (u,))
        self.c.conn.commit()
        moved = self.c.reap_expired_leases()
        self.assertIn((u, "RETRY_WAIT"), moved)
        self.c.event(u, "retry_ready")
        second = self.c.claim(u, "worker-new", 100)
        self.assertGreater(second["fencing_token"], first["fencing_token"])
        with self.assertRaises(StaleFencing):
            self.c.complete_attempt(u, "worker-old", first["fencing_token"],
                                    "script", b"stale", "local://stale", 10)
        art = self.c.complete_attempt(u, "worker-new", second["fencing_token"],
                                      "script", b"fresh", "local://fresh", 10)
        cur = self.c.conn.cursor()
        cur.execute("SELECT sha256 FROM artifacts WHERE artifact_id=%s", (art["artifact_id"],))
        import hashlib
        self.assertEqual(cur.fetchone()["sha256"], hashlib.sha256(b"fresh").hexdigest())


class TestCallbacks(Base):
    def test_T_PRV_01_duplicate_callbacks_exactly_once(self):
        u = self.plan("11.06", key="shot-1")
        self.c.claim(u, "w1", 500)
        self.c.event(u, "start")
        job_id, created = self.c.submit_provider_job(u, "mock", {"artifact_type": "media"}, "cb-key-1")
        self.assertTrue(created)
        results, errors = [], []

        def deliver():
            try:
                cc = fresh_coord()
                results.append(cc.handle_callback("cb-key-1", "media", b"clip", "local://clip", 500))
                cc.close()
            except Exception as e:  # noqa: BLE001
                errors.append(e)

        threads = [threading.Thread(target=deliver) for _ in range(4)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()
        self.assertEqual(errors, [])
        self.assertEqual(sum(1 for r in results if not r["duplicate"]), 1)
        self.assertEqual(sum(1 for r in results if r["duplicate"]), 3)
        cur = self.c.conn.cursor()
        cur.execute("SELECT count(*) AS n FROM artifacts WHERE production_id=%s AND artifact_type='media'", (self.pid,))
        self.assertEqual(cur.fetchone()["n"], 1)
        cur.execute("SELECT count(*) AS n FROM callback_deliveries WHERE idempotency_key='cb-key-1'")
        self.assertEqual(cur.fetchone()["n"], 4)
        cur.execute("SELECT status FROM provider_jobs WHERE job_id=%s", (job_id,))
        self.assertEqual(cur.fetchone()["status"], "COMPLETED")


class TestCascade(Base):
    def test_selective_invalidation_recursive(self):
        a = self.c.register_artifact(self.pid, "canon", b"a", "local://a")
        ua = self.plan("03.12")
        # link production of B and C to units so the cascade has units to supersede
        b = self.c.register_artifact(self.pid, "beat_graph", b"b", "local://b",
                                     produced_by_unit=ua, depends_on_artifact_ids=(a["artifact_id"],))
        ub = self.plan("06.12")
        cc = self.c.register_artifact(self.pid, "scene_contract", b"c", "local://c",
                                      produced_by_unit=ub, depends_on_artifact_ids=(b["artifact_id"],))
        d = self.c.register_artifact(self.pid, "unrelated", b"d", "local://d")
        out = self.c.invalidate_artifact(a["artifact_id"], "canon correction", "canon-steward")
        self.assertEqual(set(out["affected_artifact_ids"]),
                         {a["artifact_id"], b["artifact_id"], cc["artifact_id"]})
        cur = self.c.conn.cursor()
        cur.execute("SELECT state FROM artifacts WHERE artifact_id=%s", (d["artifact_id"],))
        self.assertEqual(cur.fetchone()["state"], "CURRENT")
        cur.execute("SELECT state FROM artifacts WHERE artifact_id=%s", (cc["artifact_id"],))
        self.assertEqual(cur.fetchone()["state"], "INVALIDATED")
        cur.execute("SELECT count(*) AS n FROM cascade_events WHERE source_artifact_id=%s", (a["artifact_id"],))
        self.assertEqual(cur.fetchone()["n"], 1)
        # history preserved: attempt/transaction tables untouched by cascade
        # (MM-10 fix cycle: the count is scoped to THIS production —
        # the property is "this cascade created exactly the
        # replacements it reported"; the unscoped count silently
        # assumed no sibling test ever cascades, which the new B6
        # readiness test now does.)
        cur.execute("SELECT count(*) AS n FROM execution_units WHERE supersedes_unit_id IS NOT NULL AND production_id=%s", (self.pid,))
        self.assertEqual(cur.fetchone()["n"], len(out["new_unit_ids"]))

    def test_cascade_replacements_ready_and_claimable(self):
        """MM-10 fix (B6 cascade readiness): the invalidation cascade
        plans replacement units and must leave them READY — and
        claimable — when invalidate_artifact returns, WITHOUT any
        manual recompute_readiness call or service cycle in between
        (the battery's B6 exercise found them stuck PENDING until the
        driver recomputed by hand)."""
        a = self.c.register_artifact(self.pid, "canon", b"a", "local://a")
        ua = self.plan("03.12")
        self.c.register_artifact(self.pid, "beat_graph", b"b", "local://b",
                                 produced_by_unit=ua,
                                 depends_on_artifact_ids=(a["artifact_id"],))
        out = self.c.invalidate_artifact(a["artifact_id"],
                                         "canon correction",
                                         "canon-steward")
        self.assertEqual(len(out["new_unit_ids"]), 1)
        replacement = out["new_unit_ids"][0]
        self.assertEqual(self.c.get_unit(replacement)["state"], "READY")
        claim = self.c.claim(replacement, "w-cascade", 100)
        self.assertEqual(claim["unit_id"], replacement)

    def test_master_invalidation_needs_authority(self):
        # GB-SEC-02 (Gate C): the guard now names the REAL master type
        # ("master_package", not the dead "master" literal) and authority is
        # a data rule — an APPROVED HG4 gate bound to the exact artifact, or
        # a co-authorizer distinct from the actor. The master_authority
        # request-body boolean no longer exists.
        m = self.c.register_artifact(self.pid, "master_package", b"m", "local://m")
        with self.assertRaises(PermissionError):
            self.c.invalidate_artifact(m["artifact_id"], "x", "editor")
        with self.assertRaises(PermissionError):
            self.c.invalidate_artifact(m["artifact_id"], "x", "editor",
                                       co_authorizer="editor")  # self co-sign is not four-eyes
        out = self.c.invalidate_artifact(m["artifact_id"], "x", "editor",
                                         co_authorizer="producer")
        self.assertEqual(out["affected_artifact_ids"], [m["artifact_id"]])
        # an APPROVED HG4 gate on the exact artifact authorizes on its own
        m2 = self.c.register_artifact(self.pid, "master_package", b"m2", "local://m2")
        gate = self.c.create_gate(self.pid, "HG4", m2["artifact_id"])
        self.c.decide_gate(gate, "APPROVED", "owner")
        out = self.c.invalidate_artifact(m2["artifact_id"], "x", "editor")
        self.assertEqual(out["affected_artifact_ids"], [m2["artifact_id"]])


class TestReconciler(Base):
    def _job_in_unknown(self, mode):
        u = self.plan("11.06", key=f"shot-{mode}")
        self.c.claim(u, "w1", 500)
        self.c.event(u, "start")
        job_id, _ = self.c.submit_provider_job(u, "mock", {"artifact_type": "media"}, f"key-{mode}-{u}")
        provider = MockProvider()
        pjob = provider.submit({"artifact_type": "media", "data": b"vid", "cost_cents": 400}, mode=mode)
        self.c.attach_provider_job_id(job_id, pjob)
        self.c.provider_timeout(u, job_id)
        self.assertEqual(self.c.get_unit(u)["state"], "UNKNOWN")
        return u, provider

    def test_timeout_then_completed_reconciles_without_resubmit(self):
        u, provider = self._job_in_unknown("complete")
        outcomes = self.c.reconcile_once(provider)
        self.assertEqual(provider.submit_count, 1)   # never resubmitted
        self.assertEqual(self.c.get_unit(u)["state"], "VALIDATING")
        self.assertIn("completed", [o[1] for o in outcomes])

    def test_not_found_is_safe_to_retry(self):
        u, provider = self._job_in_unknown("lost")
        self.c.reconcile_once(provider)
        self.assertEqual(self.c.get_unit(u)["state"], "RETRY_WAIT")
        cur = self.c.conn.cursor()
        cur.execute("SELECT status FROM provider_jobs WHERE unit_id=%s", (u,))
        self.assertEqual(cur.fetchone()["status"], "NOT_FOUND")


class TestGates(Base):
    def test_gate_binds_exact_hash(self):
        art = self.c.register_artifact(self.pid, "script", b"script-v1", "local://s1")
        gate = self.c.create_gate(self.pid, "SCRIPT", art["artifact_id"])
        with self.assertRaises(GateNotSatisfied):
            self.c.require_gate(self.pid, "SCRIPT", art["artifact_id"])  # still PENDING
        self.c.decide_gate(gate, "APPROVED", "editorial-owner")
        self.c.require_gate(self.pid, "SCRIPT", art["artifact_id"])      # exact hash: OK
        art2 = self.c.register_artifact(self.pid, "script", b"script-v2", "local://s2")
        with self.assertRaises(GateNotSatisfied):
            self.c.require_gate(self.pid, "SCRIPT", art2["artifact_id"])  # new hash: refused


class TestScheduler(Base):
    def test_lane_caps_and_fairness(self):
        p2 = self.c.create_production("Second", 100_00, 80_00, "tester")
        r2 = self.c.start_run(p2, "FULL", "tester")
        u1 = self.plan("11.01", key="a", lane="video")
        u2 = self.c.plan_unit(p2, r2, "11.01", "b", "video")
        u3 = self.plan("11.02", key="c", lane="video")
        claimed = self.c.scheduler_claim()
        video_claims = [c for c in claimed if c]
        self.assertEqual(len(video_claims), 1)  # video lane cap = 1
        claimed_units = {c["unit_id"] for c in video_claims}
        # the single video claim goes to one production only; both productions
        # cannot be in flight in that lane simultaneously
        self.assertEqual(len(claimed_units), 1)
        states = {str(self.c.get_unit(x)["unit_id"]): self.c.get_unit(x)["state"] for x in (u1, u2, u3)}
        self.assertEqual(list(states.values()).count("CLAIMED"), 1)


if __name__ == "__main__":
    unittest.main(verbosity=2)
