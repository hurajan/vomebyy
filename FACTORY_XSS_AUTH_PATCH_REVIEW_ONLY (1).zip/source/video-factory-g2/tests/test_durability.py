"""Cross-connection durability tests — added after independent verification
found D1/D2: effects that are only visible on the writer's own connection are
NOT committed. Every assertion here is made through a SEPARATE connection."""
import subprocess
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "coordinator"))
sys.path.insert(0, str(ROOT / "tests"))
from test_coordinator import DSN, Base, fresh_coord  # noqa: E402
from coordinator import StaleFencing  # noqa: E402
from mock_provider import MockProvider  # noqa: E402


class TestDurability(Base):
    def test_reconcile_effects_are_committed(self):
        u = self.plan("11.06", key="dur-1")
        self.c.claim(u, "w1", 500)
        self.c.event(u, "start")
        job_id, _ = self.c.submit_provider_job(u, "mock", {"artifact_type": "media"}, f"dur-key-{u}")
        provider = MockProvider()
        pjob = provider.submit({"artifact_type": "media", "data": b"vid", "cost_cents": 400}, mode="complete")
        self.c.attach_provider_job_id(job_id, pjob)
        self.c.provider_timeout(u, job_id)
        self.c.reconcile_once(provider)
        other = fresh_coord()  # separate connection
        try:
            self.assertEqual(other.get_unit(u)["state"], "VALIDATING")
            cur = other.conn.cursor()
            cur.execute("SELECT status, poll_count FROM provider_jobs WHERE job_id=%s", (job_id,))
            row = cur.fetchone()
            self.assertEqual(row["status"], "COMPLETED")
            self.assertGreaterEqual(row["poll_count"], 1)
        finally:
            other.close()

    def test_stale_fencing_evidence_is_committed(self):
        u = self.plan("08.05", key="dur-2")
        first = self.c.claim(u, "worker-old", 100)
        cur = self.c.conn.cursor()
        cur.execute("UPDATE worker_leases SET expires_at=now() - interval '1 second' WHERE unit_id=%s", (u,))
        self.c.conn.commit()
        self.c.reap_expired_leases()
        self.c.event(u, "retry_ready")
        self.c.claim(u, "worker-new", 100)
        with self.assertRaises(StaleFencing):
            self.c.complete_attempt(u, "worker-old", first["fencing_token"],
                                    "script", b"stale", "local://stale", 10)
        other = fresh_coord()
        try:
            cur = other.conn.cursor()
            cur.execute("SELECT count(*) AS n FROM action_attempts WHERE unit_id=%s AND status='STALE_FENCED'", (u,))
            self.assertEqual(cur.fetchone()["n"], 1)
            cur.execute("SELECT count(*) AS n FROM audit_events WHERE unit_id=%s AND event_type='stale_commit_rejected'", (u,))
            self.assertEqual(cur.fetchone()["n"], 1)
        finally:
            other.close()

    def test_scheduler_claims_are_committed(self):
        u = self.plan("11.01", key="dur-3", lane="video")
        self.c.scheduler_claim()
        other = fresh_coord()
        try:
            self.assertEqual(other.get_unit(u)["state"], "CLAIMED")
        finally:
            other.close()

    def test_gate_decision_is_committed(self):
        art = self.c.register_artifact(self.pid, "script", b"v1", "local://s1")
        gate = self.c.create_gate(self.pid, "SCRIPT", art["artifact_id"])
        self.c.decide_gate(gate, "APPROVED", "editorial-owner")
        other = fresh_coord()
        try:
            other.require_gate(self.pid, "SCRIPT", art["artifact_id"])  # must not raise
        finally:
            other.close()


if __name__ == "__main__":
    unittest.main(verbosity=2)
