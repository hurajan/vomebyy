"""F-G9-03 fix tests (LOCK_FIX_F-G9-03): Coordinator.retry_unit.

A unit whose worker failed sits in RETRY_WAIT with its attempt row
left RUNNING. retry_unit must close that row as FAILED and return the
unit to READY so a redispatch can claim it; from every other state it
must refuse and change nothing.
"""
import os
import subprocess
import sys
import unittest
from pathlib import Path

import psycopg
from psycopg.rows import dict_row

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "coordinator"))
DB = os.environ.get("G2_TEST_DB", "g2_coordinator_scratch")
DSN = f"host=127.0.0.1 dbname={DB} user=factory password=factory_dev_local"

from coordinator import Coordinator, UnauthorizedTransition  # noqa: E402


def raw():
    return psycopg.connect(DSN, row_factory=dict_row, autocommit=True)


class TestRetryUnit(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        subprocess.run([str(ROOT / ".venv" / "bin" / "python"),
                        str(ROOT / "tools" / "setup_db.py"), DB],
                       check=True, capture_output=True)

    def setUp(self):
        self.c = Coordinator(DSN)
        self.pid = self.c.create_production("Retry production", 100_00, 80_00, "tester")
        self.run = self.c.start_run(self.pid, "FULL", "tester")

    def tearDown(self):
        self.c.close()

    def plan(self, op="05.12"):
        return self.c.plan_unit(self.pid, self.run, op)

    def fail_unit(self, unit_id):
        claim = self.c.claim(unit_id, "w1", 100)
        self.c.event(unit_id, "transient_error")
        return claim

    def attempt_rows(self, unit_id):
        with raw() as conn:
            return conn.execute(
                "SELECT attempt_no, status, finished_at FROM action_attempts"
                " WHERE unit_id=%s ORDER BY attempt_no", (unit_id,)).fetchall()

    def state(self, unit_id):
        return self.c.get_unit(unit_id)["state"]

    def test_retry_closes_attempt_and_restores_ready(self):
        u = self.plan()
        self.fail_unit(u)
        self.assertEqual(self.state(u), "RETRY_WAIT")
        rows = self.attempt_rows(u)
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]["status"], "RUNNING")
        self.assertIsNone(rows[0]["finished_at"])

        self.assertEqual(self.c.retry_unit(u), "READY")
        rows = self.attempt_rows(u)
        self.assertEqual(rows[0]["status"], "FAILED")
        self.assertIsNotNone(rows[0]["finished_at"])

        # claimable again; the second attempt completes the unit
        claim = self.c.claim(u, "w1", 100)
        self.assertEqual(claim["attempt_no"], 2)
        self.c.complete_attempt(u, "w1", claim["fencing_token"],
                                "generic_artifact", b"payload", "local://x", 90)
        state = self.c.validate(u, [{
            "validator": "schema_validation", "method": "contract",
            "verdict": "PASS", "evaluator": "test", "evidence": {}}])
        self.assertEqual(state, "ACCEPTED")
        pos = self.c.budget_position(self.pid)
        self.assertEqual(pos["settled_cents"], 90)
        self.assertEqual(pos["held_cents"], 0)

    def test_retry_refused_from_ready(self):
        u = self.plan()
        self.assertEqual(self.state(u), "READY")
        with self.assertRaises(UnauthorizedTransition):
            self.c.retry_unit(u)
        self.assertEqual(self.state(u), "READY")
        self.assertEqual(self.attempt_rows(u), [])

    def test_retry_refused_from_accepted_and_double_retry(self):
        u = self.plan()
        claim = self.c.claim(u, "w1", 100)
        self.c.complete_attempt(u, "w1", claim["fencing_token"],
                                "generic_artifact", b"payload", "local://x", 90)
        self.c.validate(u, [{
            "validator": "schema_validation", "method": "contract",
            "verdict": "PASS", "evaluator": "test", "evidence": {}}])
        self.assertEqual(self.state(u), "ACCEPTED")
        with self.assertRaises(UnauthorizedTransition):
            self.c.retry_unit(u)
        self.assertEqual(self.state(u), "ACCEPTED")

        u2 = self.plan("06.12")
        self.fail_unit(u2)
        self.assertEqual(self.c.retry_unit(u2), "READY")
        with self.assertRaises(UnauthorizedTransition):
            self.c.retry_unit(u2)
        self.assertEqual(self.state(u2), "READY")


if __name__ == "__main__":
    unittest.main(verbosity=2)
