"""Gate C tests: provider-config resolution + snapshot pinning, financial
evidence, GB-SEC-01 worker binding, GB-SEC-02 master invalidation, FP-02
idempotent gates, claim-bound provider jobs (B1.1/B1.2), scheduler
estimates (B1.6). DB is chain-built, so the FACTORY test binding
(provider 'mock', est 100) is seeded by setup_db."""
import hashlib
import json
import os
import subprocess
import sys
import unittest
from pathlib import Path

import psycopg
from psycopg.rows import dict_row

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "coordinator"))
DB = os.environ.get("G2_TEST_DB", "g2_coordinator_scratch")
DSN = f"host=127.0.0.1 dbname={DB} user=factory password=factory_dev_local"

from coordinator import (  # noqa: E402
    ConfigurationMissingError, Coordinator, CoordinatorError, StaleFencing,
    UnauthorizedTransition)


def raw():
    return psycopg.connect(DSN, row_factory=dict_row, autocommit=True)


class Base(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        subprocess.run([str(ROOT / ".venv" / "bin" / "python"),
                        str(ROOT / "tools" / "setup_db.py"), DB],
                       check=True, capture_output=True)

    def setUp(self):
        self.c = Coordinator(DSN)
        self.pid = self.c.create_production("Gate C production", 100_00, 80_00, "tester")
        self.run = self.c.start_run(self.pid, "FULL", "tester")

    def tearDown(self):
        # attempts pin snapshots by config_id (FK), so rows are deactivated,
        # not deleted; the next class rebuild wipes the scratch DB anyway.
        with raw() as conn:
            conn.execute("UPDATE provider_configs SET active=false WHERE created_by='gatec-test'")
        self.c.close()

    def plan(self, op, key="main"):
        return self.c.plan_unit(self.pid, self.run, op, key)

    def add_config(self, scope, est, provider, station=None, op=None, slot=None,
                   action=None, env="test"):
        with raw() as conn:
            return conn.execute(
                "INSERT INTO provider_configs(scope, station, operation_id, capability_slot,"
                " action_key, environment, provider, est_cost_cents, created_by)"
                " VALUES (%s,%s,%s,%s,%s,%s,%s,%s,'gatec-test') RETURNING config_id",
                (scope, station, op, slot, action, env, provider, est)).fetchone()["config_id"]

    def reservation_est(self, unit_id):
        with raw() as conn:
            return conn.execute(
                "SELECT b.estimated_cents FROM budget_reservations b"
                " JOIN action_attempts a ON a.reservation_id=b.reservation_id"
                " WHERE a.unit_id=%s ORDER BY a.attempt_no DESC LIMIT 1",
                (unit_id,)).fetchone()["estimated_cents"]

    def attempt_row(self, unit_id):
        with raw() as conn:
            return conn.execute(
                "SELECT * FROM action_attempts WHERE unit_id=%s ORDER BY attempt_no DESC LIMIT 1",
                (unit_id,)).fetchone()

    def evidence(self, unit_id):
        with raw() as conn:
            return conn.execute(
                "SELECT * FROM financial_evidence WHERE unit_id=%s ORDER BY created_at, charge_class",
                (unit_id,)).fetchall()


class TestConfigResolution(Base):
    def test_precedence_action_capability_operation_station_factory(self):
        with raw() as conn:
            opdef = conn.execute(
                "SELECT station, capability_slot FROM operation_definitions"
                " WHERE workflow_version='1.0.0' AND operation_id='05.12'").fetchone()
        station, slot = opdef["station"], opdef["capability_slot"]
        ids = {
            "STATION": self.add_config("STATION", 200, "station-prov", station=station),
            "OPERATION": self.add_config("OPERATION", 300, "op-prov", op="05.12"),
            "CAPABILITY": self.add_config("CAPABILITY", 400, "cap-prov", slot=slot),
            "ACTION": self.add_config("ACTION", 500, "action-prov", op="05.12", action="05.12"),
        }
        expect = [("ACTION", 500, "action-prov"), ("CAPABILITY", 400, "cap-prov"),
                  ("OPERATION", 300, "op-prov"), ("STATION", 200, "station-prov"),
                  (None, 100, "mock")]
        for i, (scope, est, provider) in enumerate(expect):
            u = self.plan("05.12", key=f"prec-{i}")
            claim = self.c.claim(u, "w1")  # no caller estimate -> config decides
            self.assertEqual(self.reservation_est(u), est, f"round {scope}")
            att = self.attempt_row(u)
            self.assertEqual(att["resolved_config"]["provider"], provider)
            if scope:
                with raw() as conn:
                    conn.execute("UPDATE provider_configs SET active=false WHERE config_id=%s",
                                 (ids[scope],))

    def test_snapshot_hash_matches_canonical_json(self):
        u = self.plan("05.12")
        self.c.claim(u, "w1")
        att = self.attempt_row(u)
        self.assertIsNotNone(att["config_id"])
        canonical = json.dumps(att["resolved_config"], sort_keys=True, default=str)
        self.assertEqual(att["resolved_config_hash"],
                         hashlib.sha256(canonical.encode()).hexdigest())

    def test_caller_estimate_still_wins_when_given(self):
        # compatibility: every pre-Gate-C caller passes an explicit estimate
        u = self.plan("05.12")
        self.c.claim(u, "w1", 42)
        self.assertEqual(self.reservation_est(u), 42)

    def test_missing_config_fail_closed_with_audit(self):
        prod_coord = Coordinator(DSN, environment="production")  # no production bindings exist
        try:
            u = self.plan("05.12")
            with self.assertRaises(ConfigurationMissingError):
                prod_coord.claim(u, "w1")
            self.assertEqual(self.c.get_unit(u)["state"], "READY")
            self.assertEqual(self.c.get_unit(u)["current_attempt"], 0)
            with raw() as conn:
                n = conn.execute(
                    "SELECT count(*) AS n FROM audit_events WHERE unit_id=%s"
                    " AND event_type='configuration_missing'", (u,)).fetchone()["n"]
            self.assertEqual(n, 1)
        finally:
            prod_coord.close()

    def test_resolved_row_without_estimate_fail_closed(self):
        self.add_config("OPERATION", None, "no-est-prov", op="07.07")
        u = self.plan("07.07")
        with self.assertRaises(ConfigurationMissingError):
            self.c.claim(u, "w1")
        # ...but a caller estimate rescues it (row resolved, snapshot pinned)
        self.c.claim(u, "w1", 250)
        self.assertEqual(self.reservation_est(u), 250)
        self.assertEqual(self.attempt_row(u)["resolved_config"]["provider"], "no-est-prov")


class TestFinancialEvidence(Base):
    def test_estimated_and_finalized_rows(self):
        u = self.plan("05.12")
        claim = self.c.claim(u, "w1")
        self.c.complete_attempt(u, "w1", claim["fencing_token"], "generic_artifact",
                                b"payload", "local://x", 90,
                                usage={"input_tokens": 10}, provider_request_id="req-1")
        ev = self.evidence(u)
        self.assertEqual([e["charge_class"] for e in ev], ["ESTIMATED", "FINALIZED"])
        self.assertEqual(ev[0]["amount_cents"], 100)   # FACTORY binding estimate
        self.assertEqual(ev[0]["provider"], "mock")
        self.assertEqual(ev[1]["amount_cents"], 90)
        self.assertEqual(ev[1]["provider_request_id"], "req-1")
        # Gate D (LOCK_GATE_D §4): the FINALIZED usage JSON also carries the
        # finalization basis; the worker usage itself is preserved verbatim.
        self.assertEqual(ev[1]["usage"]["input_tokens"], 10)
        self.assertEqual(ev[1]["usage"]["_finalization_basis"], "reported_actual")


class TestWorkerBinding(Base):
    def test_completion_by_foreign_worker_refused(self):
        u = self.plan("05.12")
        claim = self.c.claim(u, "worker-a", 100)
        with self.assertRaises(StaleFencing):
            self.c.complete_attempt(u, "worker-b", claim["fencing_token"],
                                    "generic_artifact", b"x", "local://x", 10)
        self.assertEqual(self.c.get_unit(u)["state"], "CLAIMED")
        with raw() as conn:
            n = conn.execute(
                "SELECT count(*) AS n FROM audit_events WHERE unit_id=%s"
                " AND event_type='stale_commit_rejected'", (u,)).fetchone()["n"]
        self.assertEqual(n, 1)
        # the rightful worker completes normally afterwards
        self.c.complete_attempt(u, "worker-a", claim["fencing_token"],
                                "generic_artifact", b"x", "local://x", 90)
        self.assertEqual(self.c.get_unit(u)["state"], "VALIDATING")


class TestMasterInvalidation(Base):
    def test_master_package_rule(self):
        m = self.c.register_artifact(self.pid, "master_package", b"m", "local://m")
        with self.assertRaises(PermissionError):
            self.c.invalidate_artifact(m["artifact_id"], "bad master", "editor")
        with raw() as conn:
            n = conn.execute(
                "SELECT count(*) AS n FROM audit_events WHERE event_type="
                "'master_invalidation_refused'").fetchone()["n"]
        self.assertGreaterEqual(n, 1)
        out = self.c.invalidate_artifact(m["artifact_id"], "bad master", "editor",
                                         co_authorizer="producer")
        self.assertEqual(out["affected_artifact_ids"], [m["artifact_id"]])


class TestGateIdempotence(Base):
    def test_create_gate_idempotent(self):
        art = self.c.register_artifact(self.pid, "script", b"s", "local://s")
        g1 = self.c.create_gate(self.pid, "HG2", art["artifact_id"])
        self.assertFalse(g1["existing"])
        g2 = self.c.create_gate(self.pid, "HG2", art["artifact_id"])
        self.assertTrue(g2["existing"])
        self.assertEqual(g2["gate_id"], g1["gate_id"])
        self.assertEqual(str(g2), str(g1))  # plain-string behaviour preserved
        self.c.decide_gate(g2, "APPROVED", "operator")  # GateId works as an id
        g3 = self.c.create_gate(self.pid, "HG2", art["artifact_id"])
        self.assertTrue(g3["existing"])  # a decided gate is never shadowed
        with raw() as conn:
            n = conn.execute(
                "SELECT count(*) AS n FROM human_gates WHERE production_id=%s"
                " AND artifact_id=%s", (self.pid, art["artifact_id"])).fetchone()["n"]
        self.assertEqual(n, 1)


class TestProviderJobV2(Base):
    def _running_unit(self, key="main"):
        u = self.plan("11.06", key=key)
        claim = self.c.claim(u, "w1", 100)
        self.c.event(u, "start")
        return u, claim

    def test_submit_refusals(self):
        u = self.plan("11.06", key="ref-1")
        claim = self.c.claim(u, "w1", 100)  # CLAIMED, not RUNNING
        with self.assertRaises(UnauthorizedTransition):
            self.c.submit_provider_job_v2(u, claim["attempt_id"], claim["fencing_token"], "k-ref-1")
        self.c.event(u, "start")
        with self.assertRaises(StaleFencing):
            self.c.submit_provider_job_v2(u, claim["attempt_id"], claim["fencing_token"] + 9, "k-ref-2")
        with self.assertRaises(CoordinatorError):
            self.c.submit_provider_job_v2(u, "00000000-0000-0000-0000-000000000000",
                                          claim["fencing_token"], "k-ref-3")
        with raw() as conn:  # reservation released under a RUNNING unit
            conn.execute("UPDATE budget_reservations SET state='RELEASED'"
                         " WHERE reservation_id=%s", (claim["reservation_id"],))
        with self.assertRaises(CoordinatorError):
            self.c.submit_provider_job_v2(u, claim["attempt_id"], claim["fencing_token"], "k-ref-4")
        with raw() as conn:
            n = conn.execute("SELECT count(*) AS n FROM provider_jobs WHERE unit_id=%s",
                             (u,)).fetchone()["n"]
        self.assertEqual(n, 0)  # refusals create no job rows

    def test_submit_happy_path_and_duplicate(self):
        u, claim = self._running_unit()
        job = self.c.submit_provider_job_v2(u, claim["attempt_id"], claim["fencing_token"], "k-happy")
        self.assertEqual(self.c.get_unit(u)["state"], "AWAITING_PROVIDER")
        with raw() as conn:
            row = conn.execute("SELECT * FROM provider_jobs WHERE job_id=%s", (job,)).fetchone()
        self.assertEqual(str(row["attempt_id"]), claim["attempt_id"])
        self.assertEqual(row["fencing_token"], claim["fencing_token"])
        self.assertEqual(row["resolved_config_hash"],
                         self.attempt_row(u)["resolved_config_hash"])
        again = self.c.submit_provider_job_v2(u, claim["attempt_id"], claim["fencing_token"], "k-happy")
        self.assertEqual(again, job)

    def test_callback_completes_and_settles_exactly_once(self):
        u, claim = self._running_unit()
        self.c.submit_provider_job_v2(u, claim["attempt_id"], claim["fencing_token"], "k-cb")
        out = self.c.handle_callback("k-cb", "media", b"clip", "local://clip", 90,
                                     provider_request_id="prov-1")
        self.assertFalse(out["duplicate"])
        self.assertEqual(out["result"]["outcome"], "completed")
        self.assertEqual(self.c.get_unit(u)["state"], "VALIDATING")
        dup = self.c.handle_callback("k-cb", "media", b"clip", "local://clip", 90)
        self.assertTrue(dup["duplicate"])
        pos = self.c.budget_position(self.pid)
        self.assertEqual(pos["settled_cents"], 90)
        self.assertEqual(pos["held_cents"], 0)
        with raw() as conn:
            charges = conn.execute(
                "SELECT count(*) AS n FROM budget_transactions WHERE production_id=%s"
                " AND kind='CHARGE'", (self.pid,)).fetchone()["n"]
            arts = conn.execute(
                "SELECT count(*) AS n FROM artifacts WHERE production_id=%s"
                " AND artifact_type='media'", (self.pid,)).fetchone()["n"]
        self.assertEqual(charges, 1)
        self.assertEqual(arts, 1)
        state = self.c.validate(u, [{"validator": "schema_validation", "method": "contract",
                                     "verdict": "PASS", "evaluator": "test", "evidence": {}}])
        self.assertEqual(state, "ACCEPTED")

    def test_stale_callback_registers_and_settles_nothing(self):
        u, claim = self._running_unit()
        self.c.submit_provider_job_v2(u, claim["attempt_id"], claim["fencing_token"], "k-stale")
        self.c.event(u, "transient_error")   # AWAITING_PROVIDER -> RETRY_WAIT (010)
        self.c.retry_unit(u)
        claim2 = self.c.claim(u, "w1", 100)
        self.assertGreater(claim2["fencing_token"], claim["fencing_token"])
        out = self.c.handle_callback("k-stale", "media", b"late", "local://late", 90,
                                     reported_cost_cents=33, provider_request_id="prov-late")
        self.assertFalse(out["duplicate"])
        self.assertEqual(out["result"]["outcome"], "stale_fencing")
        self.assertEqual(self.c.get_unit(u)["state"], "CLAIMED")  # new attempt untouched
        with raw() as conn:
            job = conn.execute("SELECT status, raw_response FROM provider_jobs"
                               " WHERE idempotency_key='k-stale'").fetchone()
            arts = conn.execute(
                "SELECT count(*) AS n FROM artifacts WHERE production_id=%s"
                " AND artifact_type='media'", (self.pid,)).fetchone()["n"]
            ev = conn.execute(
                "SELECT * FROM financial_evidence WHERE unit_id=%s"
                " AND charge_class='PROVIDER_REPORTED'", (u,)).fetchall()
        self.assertEqual(job["status"], "FAILED")
        self.assertEqual(job["raw_response"]["failure_code"], "STALE_FENCING")
        self.assertEqual(arts, 0)
        self.assertEqual(len(ev), 1)
        self.assertEqual(ev[0]["amount_cents"], 33)
        self.assertTrue(ev[0]["requires_reconciliation"])

    def test_failure_callback_parks_unit_for_retry(self):
        u, claim = self._running_unit()
        self.c.submit_provider_job_v2(u, claim["attempt_id"], claim["fencing_token"], "k-fail")
        out = self.c.handle_callback("k-fail", "media", b"", "local://none", 0, status="FAILED")
        self.assertEqual(out["result"]["outcome"], "failed")
        self.assertEqual(self.c.get_unit(u)["state"], "RETRY_WAIT")
        with raw() as conn:
            st = conn.execute("SELECT status FROM provider_jobs WHERE idempotency_key='k-fail'"
                              ).fetchone()["status"]
        self.assertEqual(st, "FAILED")


class TestSchedulerEstimates(Base):
    def test_scheduler_uses_config_estimate_not_zero(self):
        u = self.plan("11.01", key="sched-1", )
        claimed = self.c.scheduler_claim()
        self.assertIn(u, [c["unit_id"] for c in claimed])
        self.assertEqual(self.reservation_est(u), 100)  # FACTORY binding, not 0
        pos = self.c.budget_position(self.pid)
        self.assertEqual(pos["held_cents"], 100)

    def test_scheduler_estimate_for_override(self):
        u = self.plan("11.01", key="sched-2")
        self.c.scheduler_claim(estimate_for=lambda uid: 555)
        self.assertEqual(self.reservation_est(u), 555)

    def test_scheduler_skips_unresolvable(self):
        prod_coord = Coordinator(DSN, environment="production")
        try:
            u = self.plan("11.01", key="sched-3")
            claimed = prod_coord.scheduler_claim()
            self.assertEqual(claimed, [])
            self.assertIn(u, prod_coord.last_scheduler_report["skipped_no_config"])
            self.assertEqual(self.c.get_unit(u)["state"], "READY")
        finally:
            prod_coord.close()


if __name__ == "__main__":
    unittest.main(verbosity=2)
