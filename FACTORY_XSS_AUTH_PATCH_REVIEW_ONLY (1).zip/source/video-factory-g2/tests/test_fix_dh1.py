"""Fix D-H1 (design b, LOCK_FIX_DH1) tests:

* scheduler_claim pre-stages each claim under the EXECUTOR identity for
  the candidate unit's step (steps 01-04 -> g4, 05-08 -> g5, 09-11 -> g6,
  12-14 -> g7, 15-16 -> g8);
* Gate 03 Option B (LOCK_GATE_03B): the step ranges are the REGISTRY
  station spans grouped by serving tree (stations 1,2 -> g4; 3 -> g5;
  4 -> g6; 5 -> g7; 6 -> g8), so step-derived and station-derived
  routing agree for all 192 operations — including 12.12, whose
  registry station is 5 and which the g7 executor now serves;
* the claim's audit actor remains the scheduler's (only the attempt's
  worker_id changes);
* cross-check: the identity literal in each tree's generated
  unit-executor.json is exactly the identity the coordinator's table
  maps that tree's steps to, and no trigger-derived 'n8n-station-'
  identity remains in any generated executor.
DB is chain-built (FACTORY test binding, provider 'mock', est 100),
mirroring tests/test_gatec.py fixtures.
"""
import json
import os
import re
import subprocess
import sys
import threading
import unittest
from pathlib import Path

import psycopg
from psycopg.rows import dict_row

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "coordinator"))
DB = os.environ.get("G2_TEST_DB", "g2_coordinator_scratch")
# DSN via the shared G3 test fixture — never embed the dev credential
# literal in a new file (the write path mangles credential literals;
# Gates D/E + Gate H harness all source the DSN from this one fixture).
sys.path.insert(0, str(ROOT.parent / "video-factory-g3" / "tests"))
from server_fixture import make_dsn  # noqa: E402

DSN = make_dsn(DB)

from coordinator import (  # noqa: E402
    AdoptRefused, EXECUTOR_WORKER_IDS, Coordinator,
    executor_worker_id_for_operation)

WS = ROOT.parent
STEP_RANGES = {"g4": range(1, 5), "g5": range(5, 9), "g6": range(9, 12),
               "g7": range(12, 15), "g8": range(15, 17)}
# Registry station -> serving tree (Gate 03 Option B: the authoritative
# routing layout; the coordinator's step ranges are these station spans).
STATION_TREES = {1: "g4", 2: "g4", 3: "g5", 4: "g6", 5: "g7", 6: "g8"}


def raw():
    return psycopg.connect(DSN, row_factory=dict_row, autocommit=True)


class TestSchedulerPreStaging(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        subprocess.run([str(ROOT / ".venv" / "bin" / "python"),
                        str(ROOT / "tools" / "setup_db.py"), DB],
                       check=True, capture_output=True)

    def setUp(self):
        self.c = Coordinator(DSN, actor="scheduler-service")
        self.pid = self.c.create_production("Fix D-H1 production", 100_00, 80_00,
                                            "tester")
        self.run = self.c.start_run(self.pid, "FULL", "tester")

    def tearDown(self):
        self.c.close()

    def test_pre_staged_identity_per_step(self):
        # (operation, lane, expected identity) — lanes rotate so the
        # per-lane in-flight caps never gate a sub-case.
        cases = [("01.01", "text", "n8n-executor-g4"),
                 ("05.01", "voice", "n8n-executor-g5"),
                 ("10.01", "image", "n8n-executor-g6"),
                 ("12.12", "qa", "n8n-executor-g7"),
                 ("13.01", "render-cpu", "n8n-executor-g7"),
                 ("15.01", "text", "n8n-executor-g8"),
                 ("16.01", "voice", "n8n-executor-g8")]
        for op, lane, expected in cases:
            uid = self.c.plan_unit(self.pid, self.run, op, lane=lane)
            self.assertEqual(self.c.get_unit(uid)["state"], "READY")
            claimed = self.c.scheduler_claim()
            self.assertIn(uid, [c["unit_id"] for c in claimed],
                          f"scheduler did not claim {op}")
            with raw() as conn:
                attempt = conn.execute(
                    "SELECT worker_id FROM action_attempts WHERE unit_id=%s"
                    " ORDER BY attempt_no DESC LIMIT 1", (uid,)).fetchone()
                lease = conn.execute(
                    "SELECT worker_id FROM worker_leases WHERE unit_id=%s",
                    (uid,)).fetchone()
            self.assertEqual(attempt["worker_id"], expected, op)
            self.assertEqual(lease["worker_id"], expected, op)
            self.assertEqual(self.c.get_unit(uid)["state"], "CLAIMED")

    def test_claim_audit_actor_stays_the_schedulers(self):
        uid = self.c.plan_unit(self.pid, self.run, "05.01")
        self.c.scheduler_claim()
        with raw() as conn:
            row = conn.execute(
                "SELECT actor, payload FROM audit_events WHERE unit_id=%s"
                " AND event_type='claim' ORDER BY created_at DESC LIMIT 1",
                (uid,)).fetchone()
        self.assertEqual(row["actor"], "scheduler-service")
        payload = row["payload"]
        if isinstance(payload, str):
            payload = json.loads(payload)
        self.assertEqual(payload["worker_id"], "n8n-executor-g5")


class TestExecutorIdentityMapping(unittest.TestCase):
    def test_step_boundaries(self):
        expected = {1: "g4", 4: "g4", 5: "g5", 8: "g5", 9: "g6", 11: "g6",
                    12: "g7", 13: "g7", 14: "g7", 15: "g8", 16: "g8"}
        for step, tree in expected.items():
            self.assertEqual(
                executor_worker_id_for_operation(f"{step:02d}.01"),
                EXECUTOR_WORKER_IDS[tree], f"step {step}")
        # Gate 03 Option B: 12.12's registry station is 5, and the
        # step-based mapping now sends it to the same G7 executor the
        # station layout assigns — the two routings agree.
        self.assertEqual(executor_worker_id_for_operation("12.12"),
                         "n8n-executor-g7")

    def test_step_and_station_routing_agree_all_operations(self):
        # Gate 03 Option B PASS condition, strong form: for EVERY one of
        # the 192 registry operations, the executor identity the
        # coordinator derives from the operation's step equals the
        # identity of the tree its REGISTRY station assigns it to.
        seed = json.loads((WS / "video-factory-g1" / "seed-definitions"
                           / "workflow-1.0.0"
                           / "operations.json").read_text())
        ops = seed["operations"]
        self.assertEqual(len(ops), 192)
        for op in ops:
            tree = STATION_TREES[op["station"]]
            self.assertEqual(
                executor_worker_id_for_operation(op["operation_id"]),
                EXECUTOR_WORKER_IDS[tree],
                f"{op['operation_id']} (station {op['station']})")

    def test_cross_check_generated_workflows(self):
        for tree, steps in STEP_RANGES.items():
            path = WS / f"video-factory-{tree}" / "workflows" / "unit-executor.json"
            text = path.read_text()
            found = set(re.findall(r"n8n-executor-g\d", text))
            self.assertEqual(found, {EXECUTOR_WORKER_IDS[tree]},
                             f"{tree}: generated executor identities {found}")
            self.assertNotIn("n8n-station-", text,
                             f"{tree}: trigger-derived identity remains")
            for step in steps:
                self.assertEqual(
                    executor_worker_id_for_operation(f"{step:02d}.01"),
                    EXECUTOR_WORKER_IDS[tree],
                    f"{tree} step {step}")
            # the generator source carries the same constant
            gen = (WS / f"video-factory-{tree}" / "tools"
                   / "gen_workflows.py").read_text()
            self.assertIn(f'EXECUTOR_WORKER_ID = "{EXECUTOR_WORKER_IDS[tree]}"',
                          gen, f"{tree}: generator constant")


if __name__ == "__main__":
    unittest.main()


class TestAdoption(unittest.TestCase):
    """Master Execution Programme Gate 02: Coordinator.adopt_attempt —
    atomic, single-winner, idempotent adoption of prestaged claims."""

    @classmethod
    def setUpClass(cls):
        subprocess.run([str(ROOT / ".venv" / "bin" / "python"),
                        str(ROOT / "tools" / "setup_db.py"), DB],
                       check=True, capture_output=True)

    def setUp(self):
        self.c = Coordinator(DSN, actor="scheduler-service")
        self.pid = self.c.create_production("Gate 02 adoption", 100_00, 80_00,
                                            "tester")
        self.run = self.c.start_run(self.pid, "FULL", "tester")

    def tearDown(self):
        self.c.close()

    _lane_cycle = ["text", "voice", "image", "qa", "render-cpu",
                   "render-gpu", "text", "voice"]
    _lane_idx = 0

    def _prestage(self, op="05.01", lane=None):
        if lane is None:
            lane = self._lane_cycle[TestAdoption._lane_idx % len(self._lane_cycle)]
            TestAdoption._lane_idx += 1
        uid = self.c.plan_unit(self.pid, self.run, op, lane=lane)
        claimed = self.c.scheduler_claim()
        mine = [c for c in claimed if c["unit_id"] == uid]
        self.assertEqual(len(mine), 1)
        return uid, mine[0]

    def _expire_lease(self, uid):
        with raw() as conn:
            conn.execute("UPDATE worker_leases SET expires_at="
                         " now() - interval '1 hour' WHERE unit_id=%s", (uid,))

    def test_adopt_success_and_idempotent_replay(self):
        uid, claim = self._prestage()
        out = self.c.adopt_attempt(uid, "n8n-executor-g5",
                                   claim["attempt_id"], "k1")
        self.assertTrue(out["adopted"])
        self.assertTrue(out["fresh"])
        self.assertEqual(out["fencing_token"], claim["fencing_token"])
        self.assertIsNotNone(out["resolved_config_hash"])
        replay = self.c.adopt_attempt(uid, "n8n-executor-g5",
                                      claim["attempt_id"], "k1")
        self.assertFalse(replay["fresh"])  # same adoption, no second start
        self.assertEqual(replay["fencing_token"], claim["fencing_token"])
        with self.assertRaises(AdoptRefused) as ctx:
            self.c.adopt_attempt(uid, "n8n-executor-g5",
                                 claim["attempt_id"], "another-key")
        self.assertEqual(ctx.exception.reason, "already_adopted")
        self.assertEqual(self.c.get_unit(uid)["state"], "CLAIMED")

    def test_adopt_wrong_identity_refused_then_rightful_succeeds(self):
        uid, claim = self._prestage()
        with self.assertRaises(AdoptRefused) as ctx:
            self.c.adopt_attempt(uid, "n8n-executor-g4",
                                 claim["attempt_id"], "k1")
        self.assertEqual(ctx.exception.reason, "identity_mismatch")
        # the refusal consumed nothing: the rightful executor still adopts
        out = self.c.adopt_attempt(uid, "n8n-executor-g5",
                                   claim["attempt_id"], "k1")
        self.assertTrue(out["fresh"])

    def test_adopt_stale_fencing_and_superseded_attempt(self):
        uid, claim = self._prestage()
        with self.assertRaises(AdoptRefused) as ctx:
            self.c.adopt_attempt(uid, "n8n-executor-g5", claim["attempt_id"],
                                 "k1", fencing_token=claim["fencing_token"] + 999)
        self.assertEqual(ctx.exception.reason, "stale_fencing")
        self._expire_lease(uid)
        self.c.reap_expired_leases()
        self.assertEqual(self.c.get_unit(uid)["state"], "RETRY_WAIT")
        self.c.retry_unit(uid)
        claim2 = self._prestage_claim_only(uid)
        with self.assertRaises(AdoptRefused) as ctx:
            self.c.adopt_attempt(uid, "n8n-executor-g5",
                                 claim["attempt_id"], "k1")
        self.assertEqual(ctx.exception.reason, "superseded")
        with self.assertRaises(AdoptRefused) as ctx:
            self.c.adopt_attempt(uid, "n8n-executor-g5", claim2["attempt_id"],
                                 "k1", fencing_token=claim["fencing_token"])
        self.assertEqual(ctx.exception.reason, "stale_fencing")
        out = self.c.adopt_attempt(uid, "n8n-executor-g5",
                                   claim2["attempt_id"], "k1")
        self.assertTrue(out["fresh"])

    def _prestage_claim_only(self, uid):
        claimed = self.c.scheduler_claim()
        mine = [c for c in claimed if c["unit_id"] == uid]
        self.assertEqual(len(mine), 1)
        return mine[0]

    def test_adopt_expired_lease_refused_and_reaper_still_works(self):
        uid, claim = self._prestage()
        self._expire_lease(uid)
        with self.assertRaises(AdoptRefused) as ctx:
            self.c.adopt_attempt(uid, "n8n-executor-g5",
                                 claim["attempt_id"], "k1")
        self.assertEqual(ctx.exception.reason, "lease_expired")
        self.assertEqual(self.c.get_unit(uid)["state"], "CLAIMED")
        # Gate 02 task 10: reaper behavior is intact after the refusal
        self.c.reap_expired_leases()
        self.assertEqual(self.c.get_unit(uid)["state"], "RETRY_WAIT")

    def test_adopt_started_attempt_refused(self):
        uid, claim = self._prestage()
        self.c.event(uid, "start")
        self.assertEqual(self.c.get_unit(uid)["state"], "RUNNING")
        with self.assertRaises(AdoptRefused) as ctx:
            self.c.adopt_attempt(uid, "n8n-executor-g5",
                                 claim["attempt_id"], "k1")
        self.assertEqual(ctx.exception.reason, "unit_not_claimed")

    def test_adopt_concurrent_single_winner(self):
        uid, claim = self._prestage()
        results = {}

        def attempt_adopt(tag, key):
            c2 = Coordinator(DSN, actor="scheduler-service")
            try:
                results[tag] = ("ok", c2.adopt_attempt(
                    uid, "n8n-executor-g5", claim["attempt_id"], key))
            except AdoptRefused as exc:
                results[tag] = ("refused", exc.reason)
            finally:
                c2.close()

        barrier = threading.Barrier(2)

        def run(tag, key):
            barrier.wait(timeout=10)
            attempt_adopt(tag, key)

        threads = [threading.Thread(target=run, args=("a", "key-a")),
                   threading.Thread(target=run, args=("b", "key-b"))]
        for t in threads:
            t.start()
        for t in threads:
            t.join(timeout=30)
        outcomes = sorted(v[0] for v in results.values())
        self.assertEqual(outcomes, ["ok", "refused"])
        with raw() as conn:
            n = conn.execute(
                "SELECT count(*) AS n FROM audit_events WHERE unit_id=%s"
                " AND event_type='attempt_adopted'", (uid,)).fetchone()["n"]
        self.assertEqual(n, 1)  # exactly one adoption
