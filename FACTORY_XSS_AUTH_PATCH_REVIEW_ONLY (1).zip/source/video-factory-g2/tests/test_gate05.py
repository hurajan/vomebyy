"""Gate 05 coordinator tests (Master Execution Programme).

- completion barrier: the completion_barrier() status surface and
  complete_attempt(enforce_barrier=True) refusal semantics (missing /
  not-succeeded records; committed completion_barrier_refused audit).
  The DEFAULT library path is not barrier-enforced — the lock's
  fixture-completion rule: the barrier binds completions that assert
  worker execution through the API; in-process library callers are
  trusted system actors (runtime services, test fixtures).
- record_action_attempt worker-identity binding (worker_id presented):
  a mismatch raises ActionRecordRefused with committed
  action_record_refused audit evidence; omitting worker_id preserves
  the Gate 04 behavior exactly.
- approval-policy audit (G01-D06): acceptance writes an
  approval_policy_applied audit row naming the unit operation's
  registry approval_policy and the mechanism that reached acceptance —
  on the validation path (no human) and on the human_approved path
  (approver recorded; input-gate deciders listed).
"""
import subprocess
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "coordinator"))
from coordinator import (  # noqa: E402
    ActionRecordRefused, CompletionBarrierError, Coordinator)
import psycopg  # noqa: E402
from psycopg.rows import dict_row  # noqa: E402

DB = "g2_gate05_scratch"
DSN = f"host=127.0.0.1 dbname={DB} user=factory password=factory_dev_local"


def q(sql, args=()):
    with psycopg.connect(DSN, row_factory=dict_row, autocommit=True) as conn:
        return conn.execute(sql, args).fetchall()


def audit(unit_id, event_type):
    return q("SELECT * FROM audit_events WHERE unit_id=%s AND event_type=%s"
             " ORDER BY created_at", (unit_id, event_type))


class TestGate05(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        r = subprocess.run([sys.executable, str(ROOT / "tools" / "setup_db.py"), DB],
                           capture_output=True, text=True)
        assert r.returncode == 0, r.stdout[-500:] + r.stderr[-500:]

    def setUp(self):
        self.c = Coordinator(DSN, actor="test:gate05")
        self.pid = self.c.create_production("Gate05", 10_000_000, 10_000_000,
                                            "test")
        self.rid = self.c.start_run(self.pid, "FULL", "test")

    def tearDown(self):
        self.c.close()

    def plan_actions(self, op):
        rows = q("SELECT plan FROM operation_execution_plans"
                 " WHERE operation_id=%s", (op,))
        return rows[0]["plan"]["actions"]

    def record_all(self, uid, claim, op, worker_id=None, skip_last=False,
                   last_status="SUCCEEDED"):
        actions = self.plan_actions(op)
        for i, a in enumerate(actions):
            status = last_status if (skip_last and i == len(actions) - 1) \
                else "SUCCEEDED"
            if skip_last and i == len(actions) - 1 and last_status is None:
                continue
            self.c.record_action_attempt(
                uid, claim["attempt_id"], claim["fencing_token"],
                a["action_key"], a["seq"], status, worker_id=worker_id)

    # ---------------------------------------------------------- barrier
    def test_barrier_status_progression(self):
        uid = self.c.plan_unit(self.pid, self.rid, "01.01")
        claim = self.c.claim(uid, "w1", estimated_cents=100)
        actions = self.plan_actions("01.01")
        barrier = self.c.completion_barrier(uid)
        self.assertFalse(barrier["ok"])
        self.assertEqual(barrier["reason"], "missing_records")
        self.assertEqual(barrier["required"], len(actions))
        self.assertEqual(sorted(barrier["missing"]),
                         sorted(a["action_key"] for a in actions))
        self.record_all(uid, claim, "01.01", skip_last=True, last_status=None)
        barrier = self.c.completion_barrier(uid)
        self.assertFalse(barrier["ok"])
        self.assertEqual(barrier["missing"], [actions[-1]["action_key"]])
        self.c.record_action_attempt(uid, claim["attempt_id"],
                                     claim["fencing_token"],
                                     actions[-1]["action_key"],
                                     actions[-1]["seq"], "SUCCEEDED")
        barrier = self.c.completion_barrier(uid)
        self.assertTrue(barrier["ok"])
        self.assertEqual(barrier["recorded"], len(actions))

    def test_enforced_completion_refused_then_succeeds(self):
        uid = self.c.plan_unit(self.pid, self.rid, "01.01")
        claim = self.c.claim(uid, "w1", estimated_cents=100)
        with self.assertRaises(CompletionBarrierError):
            self.c.complete_attempt(uid, "w1", claim["fencing_token"],
                                    "generic_artifact", b"x", "local://x", 90,
                                    enforce_barrier=True)
        rows = audit(uid, "completion_barrier_refused")
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]["payload"]["reason"], "missing_records")
        self.assertEqual(self.c.get_unit(uid)["state"], "CLAIMED")
        self.assertEqual(q("SELECT count(*) AS n FROM artifacts"
                           " WHERE produced_by_unit=%s", (uid,))[0]["n"], 0)
        # a FAILED record does not satisfy the barrier either
        actions = self.plan_actions("01.01")
        self.c.record_action_attempt(uid, claim["attempt_id"],
                                     claim["fencing_token"],
                                     actions[0]["action_key"], actions[0]["seq"],
                                     "FAILED", error="boom")
        with self.assertRaises(CompletionBarrierError):
            self.c.complete_attempt(uid, "w1", claim["fencing_token"],
                                    "generic_artifact", b"x", "local://x", 90,
                                    enforce_barrier=True)
        rows = audit(uid, "completion_barrier_refused")
        self.assertEqual(rows[-1]["payload"]["reason"], "missing_records")
        self.assertIn(actions[0]["action_key"],
                      [n["action_key"] for n in
                       rows[-1]["payload"]["not_succeeded"]])

    def test_enforced_completion_succeeds_when_fully_evidenced(self):
        uid = self.c.plan_unit(self.pid, self.rid, "01.01")
        claim = self.c.claim(uid, "w1", estimated_cents=100)
        self.record_all(uid, claim, "01.01", worker_id="w1")
        art = self.c.complete_attempt(uid, "w1", claim["fencing_token"],
                                      "generic_artifact", b"x", "local://x",
                                      90, enforce_barrier=True)
        self.assertEqual(self.c.get_unit(uid)["state"], "VALIDATING")
        self.assertTrue(art["artifact_id"])

    def test_default_library_completion_is_not_barrier_enforced(self):
        # The fixture-completion rule (LOCK_GATE_05 SS2): in-process
        # library completions assert no worker execution; the barrier
        # binds the API path only. No records -> still completes.
        uid = self.c.plan_unit(self.pid, self.rid, "01.01")
        claim = self.c.claim(uid, "w1", estimated_cents=100)
        self.c.complete_attempt(uid, "w1", claim["fencing_token"],
                                "generic_artifact", b"x", "local://x", 90)
        self.assertEqual(self.c.get_unit(uid)["state"], "VALIDATING")
        self.assertEqual(audit(uid, "completion_barrier_refused"), [])

    # --------------------------------------------- action-record identity
    def test_record_identity_binding(self):
        uid = self.c.plan_unit(self.pid, self.rid, "01.01")
        claim = self.c.claim(uid, "w1", estimated_cents=100)
        actions = self.plan_actions("01.01")
        with self.assertRaises(ActionRecordRefused):
            self.c.record_action_attempt(
                uid, claim["attempt_id"], claim["fencing_token"],
                actions[0]["action_key"], actions[0]["seq"], "SUCCEEDED",
                worker_id="intruder")
        rows = audit(uid, "action_record_refused")
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]["payload"]["presented_worker_id"], "intruder")
        self.assertEqual(rows[0]["payload"]["attempt_worker_id"], "w1")
        self.assertEqual(q("SELECT count(*) AS n FROM plan_action_attempts"
                           " WHERE unit_id=%s", (uid,))[0]["n"], 0)
        # the claim's own identity records fine
        rec = self.c.record_action_attempt(
            uid, claim["attempt_id"], claim["fencing_token"],
            actions[0]["action_key"], actions[0]["seq"], "SUCCEEDED",
            worker_id="w1")
        self.assertTrue(rec["recorded"])
        # omitting worker_id preserves the Gate 04 library behavior
        rec = self.c.record_action_attempt(
            uid, claim["attempt_id"], claim["fencing_token"],
            actions[1]["action_key"], actions[1]["seq"], "SUCCEEDED")
        self.assertTrue(rec["recorded"])

    # ------------------------------------------- approval-policy audit
    def test_policy_audit_on_validation_acceptance(self):
        uid = self.c.plan_unit(self.pid, self.rid, "01.01")
        claim = self.c.claim(uid, "w1", estimated_cents=100)
        self.c.complete_attempt(uid, "w1", claim["fencing_token"],
                                "generic_artifact", b"x", "local://x", 90)
        state = self.c.validate(uid, [{
            "validator": "schema_validation", "method": "contract",
            "verdict": "PASS", "evaluator": "test", "evidence": {}}])
        self.assertEqual(state, "ACCEPTED")
        rows = audit(uid, "approval_policy_applied")
        self.assertEqual(len(rows), 1)
        payload = rows[0]["payload"]
        self.assertEqual(payload["approval_policy"],
                         "PRODUCER_AND_BUDGET_OWNER")  # step 01 registry row
        self.assertEqual(payload["mechanism"], "validation_layers")
        self.assertIsNone(payload["human_satisfied_by"])
        self.assertEqual(payload["input_gates"], [])

    def test_policy_audit_on_human_acceptance_with_gate(self):
        # script artifact + APPROVED HG2 gate decided by a named human
        art = self.c.register_artifact(self.pid, "script", b"the script",
                                       "local://script")
        gid = self.c.create_gate(self.pid, "HG2", art["artifact_id"])
        self.c.decide_gate(gid, "APPROVED", "editor-jane")
        uid = self.c.plan_unit(self.pid, self.rid, "09.01", "main", "text",
                               (), (art["artifact_id"],))
        claim = self.c.claim(uid, "w1", estimated_cents=100)
        self.c.complete_attempt(uid, "w1", claim["fencing_token"],
                                "generic_artifact", b"x", "local://x", 90)
        state = self.c.validate(uid, [{
            "validator": "semantic_evaluation", "method": "qa_binding",
            "verdict": "REVIEW_REQUIRED", "evaluator": "test",
            "evidence": {}}])
        self.assertEqual(state, "AWAITING_HUMAN")
        human = Coordinator(DSN, actor="operator:raj")
        try:
            state = human.event(uid, "human_approved")
        finally:
            human.close()
        self.assertEqual(state, "ACCEPTED")
        rows = audit(uid, "approval_policy_applied")
        self.assertEqual(len(rows), 1)
        payload = rows[0]["payload"]
        self.assertEqual(payload["approval_policy"], "DIRECTOR")  # step 09
        self.assertEqual(payload["mechanism"], "human_approved")
        self.assertEqual(payload["human_satisfied_by"], "operator:raj")
        self.assertEqual(payload["input_gates"],
                         [{"gate_kind": "HG2", "verdict": "APPROVED",
                           "decided_by": "editor-jane"}])


if __name__ == "__main__":
    unittest.main(verbosity=2)
