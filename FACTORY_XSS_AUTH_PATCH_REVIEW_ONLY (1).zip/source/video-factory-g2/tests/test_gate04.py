"""Gate 04 coordinator tests (Master Execution Programme).

- claim pins the operation's execution plan (id/version/hash) on the
  attempt and materializes the plan's action_instances;
- a claim with no resolvable plan fails closed (PlanMissingError) with
  a committed plan_missing audit event and zero attempts;
- record_action_attempt validates against the pinned plan + fencing,
  is idempotent per (attempt_id, action_key), and records REFUSED;
- materialize_run derives the unit graph from dependency_templates
  (nearest planned predecessor) — equivalence with the hand-planned
  G9 graph shape for the same operation set.
"""
import subprocess
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "coordinator"))
from coordinator import (  # noqa: E402
    Coordinator, CoordinatorError, PlanMissingError, StaleFencing)
import psycopg  # noqa: E402

DB = "g2_gate04_scratch"
DSN = f"host=127.0.0.1 dbname={DB} user=factory password=factory_dev_local"

G9_OPS = ["01.01", "01.12", "02.12", "03.12", "04.12", "05.12", "06.12",
          "07.12", "08.12", "09.12", "10.12", "11.12", "12.12", "13.12",
          "14.01", "14.12", "15.12", "16.12"]


def q(sql, args=()):
    import psycopg.errors
    with psycopg.connect(DSN, autocommit=True) as conn:
        cur = conn.execute(sql, args)
        try:
            return cur.fetchall()
        except psycopg.errors.ProgrammingError:
            return []


class TestGate04(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        r = subprocess.run([sys.executable, str(ROOT / "tools" / "setup_db.py"), DB],
                           capture_output=True, text=True)
        assert r.returncode == 0, r.stdout[-500:] + r.stderr[-500:]

    def setUp(self):
        self.c = Coordinator(DSN)
        self.pid = self.c.create_production("Gate04", 10_000_000, 10_000_000,
                                            "test")
        self.rid = self.c.start_run(self.pid, "FULL", "test")

    def tearDown(self):
        self.c.close()

    def test_claim_pins_plan_and_materializes_actions(self):
        uid = self.c.plan_unit(self.pid, self.rid, "06.01")
        out = self.c.claim(uid, "w1", estimated_cents=100)
        self.assertEqual(out["plan_id"], "plan/1.0.0/06.01")
        self.assertEqual(out["plan_version"], "1.0.0")
        rows = q("SELECT plan_id, plan_version, plan_hash FROM "
                 "action_attempts WHERE attempt_id=%s", (out["attempt_id"],))
        self.assertEqual(rows[0][0], "plan/1.0.0/06.01")
        self.assertEqual(rows[0][2], out["plan_hash"])
        inst = q("SELECT action_id, state FROM action_instances "
                 "WHERE unit_id=%s ORDER BY action_id", (uid,))
        self.assertEqual({r[0] for r in inst},
                         {"inputs.manifest", "records.extract",
                          "records.assign_ids", "record.compose",
                          "output.emit"})
        self.assertTrue(all(r[1] == "PENDING" for r in inst))

    def test_claim_without_plan_fails_closed(self):
        uid = self.c.plan_unit(self.pid, self.rid, "06.01")
        q("DELETE FROM operation_execution_plans WHERE operation_id='06.01'")
        try:
            with self.assertRaises(PlanMissingError):
                self.c.claim(uid, "w1", estimated_cents=100)
            self.assertEqual(
                q("SELECT count(*) FROM action_attempts WHERE unit_id=%s",
                  (uid,))[0][0], 0)
            audits = q("SELECT count(*) FROM audit_events WHERE unit_id=%s "
                       "AND event_type='plan_missing'", (uid,))
            self.assertEqual(audits[0][0], 1)
            self.assertEqual(self.c.get_unit(uid)["state"], "READY")
        finally:
            # restore the plan row from the seed file for other tests
            g1 = Path.home() / "workspace/video-factory-g1/tools/registry_tool.py"
            r = subprocess.run([sys.executable, str(g1), "load-plans", DB],
                               capture_output=True, text=True)
            assert r.returncode == 0, r.stdout[-300:] + r.stderr[-300:]

    def test_record_action_attempt_lifecycle(self):
        uid = self.c.plan_unit(self.pid, self.rid, "06.01")
        claim = self.c.claim(uid, "w1", estimated_cents=100)
        rec = self.c.record_action_attempt(
            uid, claim["attempt_id"], claim["fencing_token"],
            "inputs.manifest", 1, "SUCCEEDED",
            output_summary={"inputs": 0})
        self.assertTrue(rec["recorded"])
        self.assertEqual(rec["plan_id"], "plan/1.0.0/06.01")
        # idempotent replay: same (attempt, action) returns stored record
        rec2 = self.c.record_action_attempt(
            uid, claim["attempt_id"], claim["fencing_token"],
            "inputs.manifest", 1, "SUCCEEDED")
        self.assertFalse(rec2["recorded"])
        self.assertEqual(rec2["plan_action_attempt_id"],
                         rec["plan_action_attempt_id"])
        self.assertEqual(
            q("SELECT count(*) FROM plan_action_attempts WHERE unit_id=%s",
              (uid,))[0][0], 1)
        # action_instances reflects the record
        self.assertEqual(
            q("SELECT state FROM action_instances WHERE unit_id=%s AND "
              "action_id='inputs.manifest'", (uid,))[0][0], "SUCCEEDED")
        # wrong fencing refused
        with self.assertRaises(StaleFencing):
            self.c.record_action_attempt(
                uid, claim["attempt_id"], claim["fencing_token"] + 5,
                "records.extract", 2, "SUCCEEDED")
        # action outside the pinned plan refused
        with self.assertRaises(CoordinatorError):
            self.c.record_action_attempt(
                uid, claim["attempt_id"], claim["fencing_token"],
                "creative_generate", 3, "REFUSED")
        # REFUSED records are first-class evidence
        uid2 = self.c.plan_unit(self.pid, self.rid, "08.05")
        claim2 = self.c.claim(uid2, "w1", estimated_cents=100)
        rec3 = self.c.record_action_attempt(
            uid2, claim2["attempt_id"], claim2["fencing_token"],
            "creative_generate", 2, "REFUSED",
            error="UNBOUND_OPERATION: creative.generate")
        self.assertTrue(rec3["recorded"])
        self.assertEqual(rec3["status"], "REFUSED")

    def test_materialize_run_matches_hand_planned_graph(self):
        out = self.c.materialize_run(self.pid, self.rid, G9_OPS)
        self.assertEqual(out["unit_count"], 18)
        units = out["units"]
        self.assertEqual(set(units), set(G9_OPS))
        # edges: every unit except 01.01 depends on its chain predecessor
        edges = {}
        for op, unit_id in units.items():
            rows = q("SELECT u2.operation_id FROM unit_dependencies d "
                     "JOIN execution_units u2 ON u2.unit_id=d.depends_on_unit "
                     "WHERE d.unit_id=%s", (unit_id,))
            edges[op] = [r[0] for r in rows]
        for i, op in enumerate(G9_OPS):
            expected = [] if i == 0 else [G9_OPS[i - 1]]
            self.assertEqual(edges[op], expected, f"edges for {op}")
        states = {u["operation_id"]: u["state"] for u in
                  (self.c.get_unit(u) for u in units.values())}
        self.assertEqual(states["01.01"], "READY")
        self.assertTrue(all(s == "PENDING" for op, s in states.items()
                            if op != "01.01"))

    def test_materialize_full_run_192(self):
        out = self.c.materialize_run(self.pid, self.rid)
        self.assertEqual(out["unit_count"], 192)
        n_edges = q("SELECT count(*) FROM unit_dependencies d JOIN "
                    "execution_units u ON u.unit_id=d.unit_id "
                    "WHERE u.production_id=%s", (self.pid,))[0][0]
        self.assertEqual(n_edges, 191)


if __name__ == "__main__":
    unittest.main(verbosity=2)
