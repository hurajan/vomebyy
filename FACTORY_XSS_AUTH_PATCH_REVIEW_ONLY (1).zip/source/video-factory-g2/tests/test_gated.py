"""Gate D tests: D-C1 API-mode estimate enforcement, durable-storage
candidate lifecycle, pricing/finalization evidence, settle_provider_charge,
soft-ceiling notifications. DB is chain-built (setup_db applies migrations
through 012 and seeds the FACTORY test binding). Storage is a LocalStorage
on a per-class temp root, injected into the coordinator."""
import hashlib
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

import psycopg
from psycopg.rows import dict_row

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "coordinator"))
GATE_D = Path.home() / "workspace/video-factory-real-ai-programme/gate-d"
sys.path.insert(0, str(GATE_D))

from coordinator import (  # noqa: E402
    ArtifactHashMismatchError, ChargeSettlementError, Coordinator,
    EstimateBelowConfigError)

from storage_service import LocalStorage  # noqa: E402

DB = os.environ.get("G2_TEST_DB", "g2_coordinator_scratch")
DSN = f"host=127.0.0.1 dbname={DB} user=factory password=factory_dev_local"


def raw():
    return psycopg.connect(DSN, row_factory=dict_row, autocommit=True)


class Base(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        subprocess.run([str(ROOT / ".venv" / "bin" / "python"),
                        str(ROOT / "tools" / "setup_db.py"), DB],
                       check=True, capture_output=True)
        cls._tmp = tempfile.TemporaryDirectory()
        cls.store = LocalStorage(cls._tmp.name)

    @classmethod
    def tearDownClass(cls):
        cls._tmp.cleanup()

    def setUp(self):
        self.c = Coordinator(DSN, storage=self.store)
        self.pid = self.c.create_production("Gate D production", 100_00, 80_00, "tester")
        self.run = self.c.start_run(self.pid, "FULL", "tester")

    def tearDown(self):
        with raw() as conn:
            conn.execute("UPDATE provider_configs SET active=false WHERE created_by='gated-test'")
            conn.execute("UPDATE pricing_rules SET active=false WHERE created_by='gated-test'")
        self.c.close()

    def plan(self, op, key="main", pid=None, run=None):
        return self.c.plan_unit(pid or self.pid, run or self.run, op, key)

    def add_config(self, scope, est, provider, station=None, op=None, slot=None,
                   action=None, env="test"):
        with raw() as conn:
            return conn.execute(
                "INSERT INTO provider_configs(scope, station, operation_id, capability_slot,"
                " action_key, environment, provider, est_cost_cents, created_by)"
                " VALUES (%s,%s,%s,%s,%s,%s,%s,%s,'gated-test') RETURNING config_id",
                (scope, station, op, slot, action, env, provider, est)).fetchone()["config_id"]

    def add_rule(self, unit_kind, price, provider="mock", model=None, version="pv-1"):
        with raw() as conn:
            return conn.execute(
                "INSERT INTO pricing_rules(provider, model, unit_kind, unit_price_cents,"
                " pricing_version, created_by) VALUES (%s,%s,%s,%s,%s,'gated-test')"
                " RETURNING rule_id",
                (provider, model, unit_kind, price, version)).fetchone()["rule_id"]

    def reservation_est(self, unit_id):
        with raw() as conn:
            return conn.execute(
                "SELECT b.estimated_cents FROM budget_reservations b"
                " JOIN action_attempts a ON a.reservation_id=b.reservation_id"
                " WHERE a.unit_id=%s ORDER BY a.attempt_no DESC LIMIT 1",
                (unit_id,)).fetchone()["estimated_cents"]

    def evidence(self, unit_id, charge_class=None):
        q = "SELECT * FROM financial_evidence WHERE unit_id=%s"
        args = [unit_id]
        if charge_class:
            q += " AND charge_class=%s"
            args.append(charge_class)
        with raw() as conn:
            return conn.execute(q + " ORDER BY created_at, charge_class", args).fetchall()

    def complete_simple(self, op="05.12", key="main", actual=90, usage=None,
                        reported=None, pid=None, run=None):
        u = self.plan(op, key=key, pid=pid, run=run)
        claim = self.c.claim(u, "w1", 100)
        self.c.complete_attempt(u, "w1", claim["fencing_token"], "generic_artifact",
                                b"payload-" + key.encode(), "local://x", actual,
                                usage=usage, reported_cost_cents=reported)
        return u


class TestApiEstimateMode(Base):
    """D-C1 correction: estimate_mode='api' makes the binding authoritative."""

    def test_below_config_refused_with_audit(self):
        self.add_config("OPERATION", 900, "op-prov", op="05.12")
        u = self.plan("05.12", key="dc1-a")
        with self.assertRaises(EstimateBelowConfigError):
            self.c.claim(u, "w1", 100, estimate_mode="api")
        self.assertEqual(self.c.get_unit(u)["state"], "READY")
        self.assertEqual(self.c.get_unit(u)["current_attempt"], 0)
        with raw() as conn:
            n = conn.execute(
                "SELECT count(*) AS n FROM audit_events WHERE unit_id=%s"
                " AND event_type='estimate_below_config'", (u,)).fetchone()["n"]
            held = conn.execute(
                "SELECT count(*) AS n FROM budget_reservations WHERE unit_id=%s",
                (u,)).fetchone()["n"]
        self.assertEqual(n, 1)
        self.assertEqual(held, 0)

    def test_at_or_above_config_reserves_config_estimate(self):
        self.add_config("OPERATION", 900, "op-prov", op="05.12")
        u = self.plan("05.12", key="dc1-b")
        self.c.claim(u, "w1", 950, estimate_mode="api")
        self.assertEqual(self.reservation_est(u), 900)  # config, not the body's 950
        u2 = self.plan("05.12", key="dc1-c")
        self.c.claim(u2, "w1", estimate_mode="api")     # no body estimate at all
        self.assertEqual(self.reservation_est(u2), 900)

    def test_library_mode_unchanged(self):
        self.add_config("OPERATION", 900, "op-prov", op="05.12")
        u = self.plan("05.12", key="dc1-d")
        self.c.claim(u, "w1", 100)  # default library mode: caller still wins
        self.assertEqual(self.reservation_est(u), 100)


class TestPricingFinalization(Base):
    def test_calculated_from_rules_and_settled(self):
        self.add_rule("input_token", "0.3000")
        self.add_rule("output_token", "0.4000")
        u = self.complete_simple(key="pf-1", actual=999,
                                 usage={"input_tokens": 1000, "output_tokens": 500})
        calc = self.evidence(u, "CALCULATED")
        self.assertEqual(len(calc), 1)
        self.assertEqual(calc[0]["amount_cents"], 500)  # 1000*.3 + 500*.4
        self.assertEqual(calc[0]["pricing_version"], "pv-1")
        fin = self.evidence(u, "FINALIZED")
        self.assertEqual(len(fin), 1)
        self.assertEqual(fin[0]["amount_cents"], 500)
        self.assertEqual(fin[0]["usage"]["_finalization_basis"], "calculated")
        self.assertEqual(fin[0]["usage"]["_pricing_version"], "pv-1")
        self.assertEqual(self.c.budget_position(self.pid)["settled_cents"], 500)

    def test_calculated_rounding_half_up(self):
        self.add_rule("input_token", "0.3000")
        u = self.complete_simple(key="pf-2", actual=999, usage={"input_tokens": 5})
        calc = self.evidence(u, "CALCULATED")
        self.assertEqual(calc[0]["amount_cents"], 2)  # 1.5 rounds half-up to 2
        self.assertEqual(self.c.budget_position(self.pid)["settled_cents"], 2)

    def test_reported_within_tolerance_wins(self):
        self.add_rule("input_token", "0.3000")
        self.add_rule("output_token", "0.4000")
        u = self.complete_simple(key="pf-3", actual=999, reported=520,
                                 usage={"input_tokens": 1000, "output_tokens": 500})
        rep = self.evidence(u, "PROVIDER_REPORTED")
        self.assertEqual(len(rep), 1)
        self.assertEqual(rep[0]["amount_cents"], 520)
        fin = self.evidence(u, "FINALIZED")
        self.assertEqual(fin[0]["amount_cents"], 520)  # |520-500| within 10% of 500
        self.assertEqual(fin[0]["usage"]["_finalization_basis"], "provider_reported")
        self.assertEqual(self.c.budget_position(self.pid)["settled_cents"], 520)

    def test_reported_outside_tolerance_falls_back_to_calculated(self):
        self.add_rule("input_token", "0.3000")
        self.add_rule("output_token", "0.4000")
        u = self.complete_simple(key="pf-4", actual=999, reported=700,
                                 usage={"input_tokens": 1000, "output_tokens": 500})
        fin = self.evidence(u, "FINALIZED")
        self.assertEqual(fin[0]["amount_cents"], 500)
        self.assertEqual(fin[0]["usage"]["_finalization_basis"], "calculated")
        self.assertEqual(self.c.budget_position(self.pid)["settled_cents"], 500)

    def test_no_rules_no_report_stays_reported_actual(self):
        self.add_rule("input_token", "0.3000", provider="someone-else")
        u = self.complete_simple(key="pf-5", actual=90, usage={"input_tokens": 1000})
        self.assertEqual(self.evidence(u, "CALCULATED"), [])
        fin = self.evidence(u, "FINALIZED")
        self.assertEqual(fin[0]["amount_cents"], 90)
        self.assertEqual(fin[0]["usage"]["_finalization_basis"], "reported_actual")


class TestSettleProviderCharge(Base):
    def _flagged_evidence(self, amount=33, request_id="prov-late"):
        """A stale-callback charge, exactly as Gate C records it."""
        u = self.plan("11.06", key=f"spc-{request_id}")
        claim = self.c.claim(u, "w1", 100)
        self.c.event(u, "start")
        self.c.submit_provider_job_v2(u, claim["attempt_id"], claim["fencing_token"],
                                      f"k-{request_id}")
        self.c.event(u, "transient_error")
        self.c.retry_unit(u)
        self.c.claim(u, "w1", 100)
        self.c.handle_callback(f"k-{request_id}", "media", b"late", "local://late", 90,
                               reported_cost_cents=amount, provider_request_id=request_id)
        rows = [e for e in self.evidence(u, "PROVIDER_REPORTED")
                if e["requires_reconciliation"]]
        self.assertEqual(len(rows), 1)
        return u, rows[0]

    def test_settle_happy_path_and_repeat_refusal(self):
        u, ev = self._flagged_evidence()
        before = self.c.budget_position(self.pid)["settled_cents"]
        out = self.c.settle_provider_charge(ev["evidence_id"], actor="operator:test")
        self.assertEqual(out["amount_cents"], 33)
        after = self.c.budget_position(self.pid)["settled_cents"]
        self.assertEqual(after - before, 33)  # spent moved exactly once
        fin = [e for e in self.evidence(u, "FINALIZED")
               if e["usage"].get("_finalization_basis") == "provider_charge_settled"]
        self.assertEqual(len(fin), 1)
        self.assertEqual(fin[0]["amount_cents"], 33)
        with raw() as conn:
            row = conn.execute("SELECT requires_reconciliation FROM financial_evidence"
                               " WHERE evidence_id=%s", (ev["evidence_id"],)).fetchone()
            audits = conn.execute(
                "SELECT count(*) AS n FROM audit_events WHERE production_id=%s"
                " AND event_type='provider_charge_settled'", (self.pid,)).fetchone()["n"]
            standalone = conn.execute(
                "SELECT count(*) AS n FROM budget_transactions WHERE production_id=%s"
                " AND kind='CHARGE' AND reservation_id IS NULL", (self.pid,)).fetchone()["n"]
        self.assertFalse(row["requires_reconciliation"])
        self.assertEqual(audits, 1)
        self.assertEqual(standalone, 1)
        with self.assertRaises(ChargeSettlementError):
            self.c.settle_provider_charge(ev["evidence_id"])

    def test_settle_refuses_when_finalized_already_cites_charge(self):
        u = self.complete_simple(key="spc-dup", actual=90, reported=None)
        # a completed attempt's FINALIZED row citing (mock, 'dup-1')...
        claim_unit = self.plan("05.12", key="spc-dup2")
        claim = self.c.claim(claim_unit, "w1", 100)
        self.c.complete_attempt(claim_unit, "w1", claim["fencing_token"],
                                "generic_artifact", b"p", "local://x", 90,
                                provider_request_id="dup-1", reported_cost_cents=44)
        with raw() as conn:
            ev = conn.execute(
                "INSERT INTO financial_evidence(production_id, unit_id, provider,"
                " provider_request_id, charge_class, amount_cents, requires_reconciliation)"
                " VALUES (%s,%s,'mock','dup-1','PROVIDER_REPORTED',44,true)"
                " RETURNING evidence_id", (self.pid, claim_unit)).fetchone()
        with self.assertRaises(ChargeSettlementError):
            self.c.settle_provider_charge(ev["evidence_id"])
        # and a plain (non-flagged) PROVIDER_REPORTED row refuses too
        with raw() as conn:
            plain = conn.execute(
                "SELECT evidence_id FROM financial_evidence WHERE unit_id=%s"
                " AND charge_class='PROVIDER_REPORTED' AND NOT requires_reconciliation"
                " LIMIT 1", (claim_unit,)).fetchone()
        with self.assertRaises(ChargeSettlementError):
            self.c.settle_provider_charge(plain["evidence_id"])

    def test_settle_refuses_hard_ceiling_breach(self):
        pid = self.c.create_production("Gate D tiny ceiling", 40, 40, "tester")
        run = self.c.start_run(pid, "FULL", "tester")
        u = self.c.plan_unit(pid, run, "05.12", "spc-ceil")
        with raw() as conn:
            ev = conn.execute(
                "INSERT INTO financial_evidence(production_id, unit_id, provider,"
                " provider_request_id, charge_class, amount_cents, requires_reconciliation)"
                " VALUES (%s,%s,'mock','ceil-1','PROVIDER_REPORTED',50,true)"
                " RETURNING evidence_id", (pid, u)).fetchone()
        with self.assertRaises(ChargeSettlementError):
            self.c.settle_provider_charge(ev["evidence_id"])
        self.assertEqual(self.c.budget_position(pid)["settled_cents"], 0)


class TestSoftCeiling(Base):
    def test_crossing_notifies_exactly_once(self):
        pid = self.c.create_production("Gate D soft ceiling", 100_00, 100, "tester")
        run = self.c.start_run(pid, "FULL", "tester")
        for i in range(3):
            u = self.plan("05.12", key=f"sc-{i}", pid=pid, run=run)
            claim = self.c.claim(u, "w1", 100)
            self.c.complete_attempt(u, "w1", claim["fencing_token"], "generic_artifact",
                                    b"p", "local://x", 90)
            with raw() as conn:
                audits = conn.execute(
                    "SELECT count(*) AS n FROM audit_events WHERE production_id=%s"
                    " AND event_type='soft_ceiling_crossed'", (pid,)).fetchone()["n"]
                outbox = conn.execute(
                    "SELECT count(*) AS n FROM outbox_events WHERE aggregate_id=%s"
                    " AND event_type='notification'", (pid,)).fetchone()["n"]
            # spent: 90 (below), 180 (crossing), 270 (still above, silent)
            expect = 0 if i == 0 else 1
            self.assertEqual(audits, expect, f"after settle {i + 1}")
            self.assertEqual(outbox, expect, f"after settle {i + 1}")
        with raw() as conn:
            row = conn.execute(
                "SELECT payload FROM outbox_events WHERE aggregate_id=%s"
                " AND event_type='notification'", (pid,)).fetchone()
        self.assertEqual(row["payload"]["kind"], "soft_ceiling_crossed")
        self.assertEqual(row["payload"]["soft_ceiling_cents"], 100)


class TestCandidateLifecycle(Base):
    def _candidate_row(self, uri):
        with raw() as conn:
            return conn.execute("SELECT * FROM artifact_candidates WHERE uri=%s",
                                (uri,)).fetchone()

    def test_stage_complete_by_candidate_promotes(self):
        data = b"hello gate d"
        sha = hashlib.sha256(data).hexdigest()
        cand = self.c.stage_content(data, "text/plain", actor="tester",
                                    production_id=self.pid)
        self.assertEqual(cand["state"], "STAGED")
        self.assertEqual(cand["uri"], f"store://candidates/{sha}")
        u = self.plan("05.12", key="cand-1")
        claim = self.c.claim(u, "w1", 100)
        art = self.c.complete_attempt(u, "w1", claim["fencing_token"],
                                      "generic_artifact", None, None, 90,
                                      candidate_uri=cand["uri"])
        self.assertEqual(art["sha256"], sha)
        with raw() as conn:
            stored = conn.execute("SELECT storage_uri FROM artifacts WHERE artifact_id=%s",
                                  (art["artifact_id"],)).fetchone()
        self.assertEqual(stored["storage_uri"], f"store://objects/{sha}")
        row = self._candidate_row(cand["uri"])
        self.assertEqual(row["state"], "PROMOTED")
        self.assertEqual(str(row["promoted_artifact_id"]), art["artifact_id"])
        self.assertEqual(self.store.get(f"store://objects/{sha}"), data)

    def test_caller_uri_kept_but_bytes_durable(self):
        u = self.plan("05.12", key="cand-2")
        claim = self.c.claim(u, "w1", 100)
        art = self.c.complete_attempt(u, "w1", claim["fencing_token"],
                                      "generic_artifact", b"xyz-bytes",
                                      "local://keep-me", 90)
        with raw() as conn:
            stored = conn.execute("SELECT storage_uri FROM artifacts WHERE artifact_id=%s",
                                  (art["artifact_id"],)).fetchone()
        self.assertEqual(stored["storage_uri"], "local://keep-me")
        sha = hashlib.sha256(b"xyz-bytes").hexdigest()
        row = self._candidate_row(f"store://candidates/{sha}")
        self.assertEqual(row["state"], "PROMOTED")
        self.assertEqual(self.store.get(f"store://objects/{sha}"), b"xyz-bytes")

    def test_hash_mismatch_refuses_and_registers_nothing(self):
        u = self.plan("05.12", key="cand-3")
        claim = self.c.claim(u, "w1", 100)
        with self.assertRaises(ArtifactHashMismatchError):
            self.c.complete_attempt(u, "w1", claim["fencing_token"],
                                    "generic_artifact", b"abc", "local://x", 90,
                                    expected_sha256="0" * 64)
        self.assertEqual(self.c.get_unit(u)["state"], "CLAIMED")
        with raw() as conn:
            arts = conn.execute(
                "SELECT count(*) AS n FROM artifacts WHERE produced_by_unit=%s",
                (u,)).fetchone()["n"]
            audits = conn.execute(
                "SELECT count(*) AS n FROM audit_events WHERE unit_id=%s"
                " AND event_type='artifact_hash_mismatch'", (u,)).fetchone()["n"]
        self.assertEqual(arts, 0)
        self.assertEqual(audits, 1)

    def test_cleanup_abandons_stale_staged_only(self):
        orphan = self.c.stage_content(b"orphan", None, actor="tester",
                                      production_id=self.pid)
        promoted = self.c.stage_content(b"promoted", None, actor="tester",
                                        production_id=self.pid)
        u = self.plan("05.12", key="cand-4")
        claim = self.c.claim(u, "w1", 100)
        self.c.complete_attempt(u, "w1", claim["fencing_token"], "generic_artifact",
                                None, None, 90, candidate_uri=promoted["uri"])
        fresh = self.c.stage_content(b"fresh", None, actor="tester",
                                     production_id=self.pid)
        with raw() as conn:
            conn.execute("UPDATE artifact_candidates SET created_at=now() - interval '2 hours'"
                         " WHERE candidate_id IN (%s,%s)",
                         (orphan["candidate_id"], promoted["candidate_id"]))
        out = self.c.cleanup_candidates(3600, actor="tester")
        self.assertEqual(out["abandoned"], 1)
        self.assertEqual(self._candidate_row(orphan["uri"])["state"], "ABANDONED")
        self.assertIsNone(self.store.head(orphan["uri"]))
        self.assertEqual(self._candidate_row(promoted["uri"])["state"], "PROMOTED")
        self.assertEqual(self._candidate_row(fresh["uri"])["state"], "STAGED")


if __name__ == "__main__":
    unittest.main(verbosity=2)
