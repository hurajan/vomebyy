"""MM-08 tests: provider spend caps, missing-usage UNRESOLVED charges,
operator resolution, and the reconciler's unresolved-charges report.

DB is chain-built (setup_db applies migration 018): provider_spend_limits
exists and financial_evidence accepts the UNRESOLVED charge class.
Cap-absent behavior is the pre-MM-08 behavior — the whole existing
regression is that proof; here the caps and the detection are exercised
directly. Every provider here is a local fixture binding; nothing real
is called.
"""
import os
import re
import subprocess
import sys
import unittest
from pathlib import Path

import psycopg
from psycopg.rows import dict_row

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "coordinator"))
DB = os.environ.get("G2_TEST_DB", "g2_coordinator_scratch")
_pw = re.search(r"password=([^\s\"]+)",
                (ROOT / "tests" / "test_gatec.py").read_text()).group(1)
DSN = f"host=127.0.0.1 dbname={DB} user=factory password={_pw}"

from coordinator import (  # noqa: E402
    ChargeSettlementError, Coordinator, ProviderCapExceeded)
from mock_provider import MockProvider  # noqa: E402


def raw():
    return psycopg.connect(DSN, row_factory=dict_row, autocommit=True)


class Base(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        subprocess.run([str(ROOT / ".venv" / "bin" / "python"),
                        str(ROOT / "tools" / "setup_db.py"), DB],
                       check=True, capture_output=True)

    def setUp(self):
        self.c = Coordinator(DSN)
        self.pid = self.c.create_production("MM-08 production", 100_00, 80_00,
                                            "mm08-test")
        self.run = self.c.start_run(self.pid, "FULL", "mm08-test")

    def tearDown(self):
        with raw() as conn:
            conn.execute("UPDATE provider_configs SET active=false"
                         " WHERE created_by='mm08-test'")
            conn.execute("UPDATE provider_spend_limits SET active=false"
                         " WHERE created_by='mm08-test'")
            conn.execute("DELETE FROM pricing_rules WHERE created_by='mm08-test'")
        self.c.close()

    def plan(self, op, key="main", pid=None, run=None):
        return self.c.plan_unit(pid or self.pid, run or self.run, op, key)

    def production(self, hard=100_00):
        pid = self.c.create_production("MM-08 extra", hard, hard, "mm08-test")
        return pid, self.c.start_run(pid, "FULL", "mm08-test")

    def add_config(self, est, provider, op=None, cred=None, model=None):
        with raw() as conn:
            return conn.execute(
                "INSERT INTO provider_configs(scope, operation_id, environment,"
                " provider, model, est_cost_cents, credential_ref, created_by)"
                " VALUES ('OPERATION',%s,'test',%s,%s,%s,%s,'mm08-test')"
                " RETURNING config_id",
                (op, provider, model, est, cred)).fetchone()["config_id"]

    def add_cap(self, provider, cap_cents):
        with raw() as conn:
            return conn.execute(
                "INSERT INTO provider_spend_limits(provider, cap_cents,"
                " created_by) VALUES (%s,%s,'mm08-test') RETURNING limit_id",
                (provider, cap_cents)).fetchone()["limit_id"]

    def add_pricing(self, provider, model, unit_kind, price, version="mm08-1"):
        with raw() as conn:
            conn.execute(
                "INSERT INTO pricing_rules(provider, model, unit_kind,"
                " unit_price_cents, pricing_version, created_by)"
                " VALUES (%s,%s,%s,%s,%s,'mm08-test')",
                (provider, model, unit_kind, price, version))

    def evidence(self, attempt_id):
        with raw() as conn:
            return conn.execute(
                "SELECT * FROM financial_evidence WHERE attempt_id=%s"
                " ORDER BY created_at", (attempt_id,)).fetchall()

    def reservation(self, reservation_id):
        with raw() as conn:
            return conn.execute(
                "SELECT * FROM budget_reservations WHERE reservation_id=%s",
                (reservation_id,)).fetchone()


class TestProviderCaps(Base):
    def provider(self):
        # window sums are DB-wide per provider: isolate each test with
        # its own provider name so earlier tests' reservations (the
        # class shares one scratch DB) cannot pollute the window
        return "cap-" + self.id().rsplit(".", 1)[-1]

    def test_cap_admits_one_then_refuses_with_audit(self):
        self.add_config(100, self.provider(), op="01.01")
        self.add_cap(self.provider(), 150)
        u1 = self.plan("01.01", "one")
        self.c.claim(u1, "w1", 100)
        pid2, run2 = self.production()
        u2 = self.plan("01.01", "two", pid2, run2)
        with self.assertRaises(ProviderCapExceeded):
            self.c.claim(u2, "w2", 100)
        # no state change (the cap may clear); refusal is committed audit
        self.assertEqual(self.c.get_unit(u2)["state"], "READY")
        with raw() as conn:
            rows = conn.execute(
                "SELECT payload FROM audit_events WHERE unit_id=%s"
                " AND event_type='provider_cap_refused'", (u2,)).fetchall()
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]["payload"]["cap_cents"], 150)
        self.assertEqual(rows[0]["payload"]["window_held_cents"], 100)
        # the scheduler skips the capped candidate instead of raising
        self.c.scheduler_claim()
        self.assertEqual(self.c.get_unit(u2)["state"], "READY")

    def test_settled_spend_counts_toward_cap(self):
        self.add_config(100, self.provider(), op="01.01")
        self.add_cap(self.provider(), 150)
        u1 = self.plan("01.01", "one")
        claim = self.c.claim(u1, "w1", 100)
        # non-credentialed binding: completion settles reported actual 90
        self.c.complete_attempt(u1, "w1", claim["fencing_token"],
                                "research_brief", b"x", "local://x", 90)
        pid2, run2 = self.production()
        u2 = self.plan("01.01", "two", pid2, run2)
        with self.assertRaises(ProviderCapExceeded):  # 90 settled + 100 > 150
            self.c.claim(u2, "w2", 100)

    def test_window_boundary_backdated_spend_not_counted(self):
        self.add_config(100, self.provider(), op="01.01")
        self.add_cap(self.provider(), 150)
        u1 = self.plan("01.01", "one")
        claim = self.c.claim(u1, "w1", 100)
        with raw() as conn:
            conn.execute("UPDATE budget_reservations SET created_at="
                         " now() - interval '2 days' WHERE reservation_id=%s",
                         (claim["reservation_id"],))
        pid2, run2 = self.production()
        u2 = self.plan("01.01", "two", pid2, run2)
        self.c.claim(u2, "w2", 100)  # prior-window spend does not count

    def test_absent_cap_no_effect(self):
        self.add_config(100, self.provider(), op="01.01")
        u1 = self.plan("01.01", "one")
        self.c.claim(u1, "w1", 100)
        pid2, run2 = self.production()
        u2 = self.plan("01.01", "two", pid2, run2)
        self.c.claim(u2, "w2", 100)  # no cap row: both claims proceed

    def test_standalone_provider_charge_settlement_counts(self):
        self.add_config(100, "settle-provider", op="01.01")
        u = self.plan("01.01", "job")
        claim = self.c.claim(u, "w1", 100)
        self.c.event(u, "start")
        self.c.submit_provider_job_v2(u, claim["attempt_id"],
                                      claim["fencing_token"], "mm08-k-fail")
        self.c.handle_callback("mm08-k-fail", "media", b"", "local://f", 0,
                               reported_cost_cents=30, status="FAILED")
        ev = [e for e in self.evidence(claim["attempt_id"])
              if e["charge_class"] == "PROVIDER_REPORTED"]
        self.assertEqual(len(ev), 1)
        self.c.settle_provider_charge(ev[0]["evidence_id"])
        # release the failed attempt's own reservation through the real
        # retry path, so the ONLY in-window spend left for this provider
        # is the standalone settlement
        self.assertEqual(self.c.get_unit(u)["state"], "RETRY_WAIT")
        self.c.retry_unit(u)
        self.assertEqual(self.reservation(claim["reservation_id"])["state"],
                         "RELEASED")
        # 30 standalone-settled + a fresh 100 estimate > cap 120
        self.add_cap("settle-provider", 120)
        pid2, run2 = self.production()
        u2 = self.plan("01.01", "two", pid2, run2)
        with self.assertRaises(ProviderCapExceeded):
            self.c.claim(u2, "w2", 100)


class TestMissingUsage(Base):
    def _credentialed_claim(self, op="01.02"):
        self.add_config(100, "cred-provider", op=op, cred="SOME_KEY",
                        model="m1")
        u = self.plan(op, "cred")
        return u, self.c.claim(u, "w-cred", 100)

    def test_sync_completion_without_usage_is_unresolved(self):
        u, claim = self._credentialed_claim()
        self.c.complete_attempt(u, "w-cred", claim["fencing_token"],
                                "research_brief", b"content", "local://d",
                                100, usage=None,
                                provider_request_id="req-1")
        ev = self.evidence(claim["attempt_id"])
        self.assertEqual([(e["charge_class"], e["amount_cents"]) for e in ev],
                         [("ESTIMATED", 100), ("UNRESOLVED", 100)])
        self.assertTrue(ev[1]["requires_reconciliation"])
        self.assertEqual(ev[1]["usage"]["_unresolved_reason"], "missing_usage")
        self.assertEqual(self.reservation(claim["reservation_id"])["state"],
                         "HELD")
        pos = self.c.budget_position(self.pid)
        self.assertEqual((pos["settled_cents"], pos["held_cents"]), (0, 100))
        with raw() as conn:
            att = conn.execute("SELECT actual_cost_cents FROM action_attempts"
                               " WHERE attempt_id=%s",
                               (claim["attempt_id"],)).fetchone()
            audits = conn.execute(
                "SELECT count(*) AS n FROM audit_events WHERE unit_id=%s"
                " AND event_type='charge_unresolved'", (u,)).fetchone()["n"]
            outbox = conn.execute(
                "SELECT count(*) AS n FROM outbox_events"
                " WHERE idempotency_key=%s",
                (f"charge-unresolved:{claim['attempt_id']}",)).fetchone()["n"]
        self.assertIsNone(att["actual_cost_cents"])
        self.assertEqual(audits, 1)
        self.assertEqual(outbox, 1)

    def test_all_none_usage_is_unresolved(self):
        u, claim = self._credentialed_claim()
        self.c.complete_attempt(
            u, "w-cred", claim["fencing_token"], "research_brief", b"c",
            "local://d", 100,
            usage={"input_tokens": None, "output_tokens": None,
                   "total_tokens": None})
        classes = [e["charge_class"] for e in self.evidence(claim["attempt_id"])]
        self.assertIn("UNRESOLVED", classes)
        self.assertNotIn("FINALIZED", classes)

    def test_async_completion_without_usage_is_unresolved(self):
        u, claim = self._credentialed_claim()
        self.c.event(u, "start")
        job = self.c.submit_provider_job_v2(u, claim["attempt_id"],
                                            claim["fencing_token"], "mm08-k-async")
        out = self.c.handle_callback("mm08-k-async", "media", b"clip",
                                     "local://clip", 100, usage=None)
        self.assertIn("unresolved_evidence_id", out["result"])
        self.assertEqual(self.reservation(claim["reservation_id"])["state"],
                         "HELD")
        with raw() as conn:
            job_row = conn.execute("SELECT * FROM provider_jobs WHERE job_id=%s",
                                   (job,)).fetchone()
        self.assertEqual(job_row["status"], "COMPLETED")
        self.assertIsNone(job_row["cost_charged_cents"])

    def test_usage_present_settles_calculated_not_unresolved(self):
        self.add_pricing("cred-provider", "m1", "input_token", "1.0")
        u, claim = self._credentialed_claim()
        self.c.complete_attempt(u, "w-cred", claim["fencing_token"],
                                "research_brief", b"c", "local://d", 100,
                                usage={"input_tokens": 40})
        ev = self.evidence(claim["attempt_id"])
        self.assertEqual([e["charge_class"] for e in ev],
                         ["ESTIMATED", "CALCULATED", "FINALIZED"])
        self.assertEqual(ev[-1]["amount_cents"], 40)
        self.assertEqual(self.reservation(claim["reservation_id"])["state"],
                         "SETTLED")

    def test_reported_cost_present_not_unresolved(self):
        u, claim = self._credentialed_claim()
        self.c.complete_attempt(u, "w-cred", claim["fencing_token"],
                                "research_brief", b"c", "local://d", 100,
                                usage=None, reported_cost_cents=55)
        ev = self.evidence(claim["attempt_id"])
        self.assertEqual([e["charge_class"] for e in ev],
                         ["ESTIMATED", "PROVIDER_REPORTED", "FINALIZED"])
        self.assertEqual(ev[-1]["amount_cents"], 55)

    def test_resolution_settles_exactly_once(self):
        self.add_pricing("cred-provider", "m1", "input_token", "1.0")
        u, claim = self._credentialed_claim()
        self.c.complete_attempt(u, "w-cred", claim["fencing_token"],
                                "research_brief", b"c", "local://d", 100,
                                usage=None)
        unres = [e for e in self.evidence(claim["attempt_id"])
                 if e["charge_class"] == "UNRESOLVED"][0]
        out = self.c.resolve_unresolved_charge(
            unres["evidence_id"], usage={"input_tokens": 40})
        self.assertEqual((out["amount_cents"], out["basis"]), (40, "calculated"))
        res = self.reservation(claim["reservation_id"])
        self.assertEqual((res["state"], res["settled_cents"]), ("SETTLED", 40))
        with raw() as conn:
            charges = conn.execute(
                "SELECT count(*) AS n FROM budget_transactions"
                " WHERE reservation_id=%s AND kind='CHARGE'",
                (claim["reservation_id"],)).fetchone()["n"]
            flag = conn.execute(
                "SELECT requires_reconciliation FROM financial_evidence"
                " WHERE evidence_id=%s", (unres["evidence_id"],)).fetchone()
        self.assertEqual(charges, 1)
        self.assertFalse(flag["requires_reconciliation"])
        with self.assertRaises(ChargeSettlementError):
            self.c.resolve_unresolved_charge(unres["evidence_id"],
                                             usage={"input_tokens": 40})

    def test_resolution_refusals(self):
        self.add_pricing("cred-provider", "m1", "input_token", "1.0")
        u, claim = self._credentialed_claim()
        self.c.complete_attempt(u, "w-cred", claim["fencing_token"],
                                "research_brief", b"c", "local://d", 100,
                                usage=None)
        ev = self.evidence(claim["attempt_id"])
        unres = [e for e in ev if e["charge_class"] == "UNRESOLVED"][0]
        estimated = [e for e in ev if e["charge_class"] == "ESTIMATED"][0]
        # not an UNRESOLVED row
        with self.assertRaises(ChargeSettlementError):
            self.c.resolve_unresolved_charge(estimated["evidence_id"],
                                             usage={"input_tokens": 1})
        # no inputs at all
        with self.assertRaises(ChargeSettlementError):
            self.c.resolve_unresolved_charge(unres["evidence_id"])
        # inputs that price to nothing (provider has rules here, so use a
        # usage key with no rule) and no reported amount
        with self.assertRaises(ChargeSettlementError):
            self.c.resolve_unresolved_charge(unres["evidence_id"],
                                             usage={"requests": 3})
        # unknown evidence id
        with self.assertRaises(Exception):
            self.c.resolve_unresolved_charge(
                "00000000-0000-0000-0000-000000000000",
                reported_cost_cents=10)

    def test_resolution_hard_ceiling_rolls_back(self):
        pid, run = self.production(hard=120)
        self.add_config(100, "cred-provider", op="01.02", cred="SOME_KEY",
                        model="m1")
        u = self.plan("01.02", "cred", pid, run)
        claim = self.c.claim(u, "w-cred", 100)
        self.c.complete_attempt(u, "w-cred", claim["fencing_token"],
                                "research_brief", b"c", "local://d", 100,
                                usage=None)
        unres = [e for e in self.evidence(claim["attempt_id"])
                 if e["charge_class"] == "UNRESOLVED"][0]
        with self.assertRaises(ChargeSettlementError):
            self.c.resolve_unresolved_charge(unres["evidence_id"],
                                             reported_cost_cents=150)
        # charge stays unresolved, reservation stays HELD, no FINALIZED
        ev = self.evidence(claim["attempt_id"])
        self.assertNotIn("FINALIZED", [e["charge_class"] for e in ev])
        self.assertEqual(self.reservation(claim["reservation_id"])["state"],
                         "HELD")


class TestReconcilerReport(Base):
    def _unresolved_attempt(self):
        self.add_config(100, "cred-provider", op="01.02", cred="SOME_KEY",
                        model="m1")
        u = self.plan("01.02", "cred")
        claim = self.c.claim(u, "w-cred", 100)
        self.c.complete_attempt(u, "w-cred", claim["fencing_token"],
                                "research_brief", b"c", "local://d", 100,
                                usage=None)
        return claim

    def test_unresolved_reported_after_threshold(self):
        claim = self._unresolved_attempt()
        with raw() as conn:
            conn.execute("UPDATE financial_evidence SET created_at="
                         " now() - interval '2 hours' WHERE attempt_id=%s"
                         " AND charge_class='UNRESOLVED'",
                         (claim["attempt_id"],))
        self.c.reconcile_once(MockProvider(), unresolved_threshold_s=3600)
        report = self.c.last_reconcile_report
        self.assertEqual(report["unresolved_charge_count"], 1)
        row = report["unresolved_charges"][0]
        self.assertEqual(row["attempt_id"], str(claim["attempt_id"]))
        self.assertEqual(row["amount_cents"], 100)
        self.assertGreaterEqual(row["age_s"], 3600)

    def test_unresolved_below_threshold_not_reported(self):
        self._unresolved_attempt()
        self.c.reconcile_once(MockProvider(), unresolved_threshold_s=3600)
        self.assertEqual(self.c.last_reconcile_report["unresolved_charge_count"],
                         0)
        self.c.reconcile_once(MockProvider(), unresolved_threshold_s=0)
        self.assertEqual(self.c.last_reconcile_report["unresolved_charge_count"],
                         1)


if __name__ == "__main__":
    unittest.main()
