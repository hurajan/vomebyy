"""G6 amendment tests (LOCK_G6 Part A): claim-time gate enforcement.

gate_requirements (migration 003) seeds script -> HG2. A unit planned
against a script artifact may not be claimed until an APPROVED HG2 gate
is bound to that exact artifact (id + hash). Refusals record zero
attempts, move no budget, and commit a gate_claim_refused audit event
that is durable across connections.
"""
import os
import subprocess
import sys
import unittest
from pathlib import Path

import psycopg
from psycopg.rows import dict_row

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "coordinator"))
DB = os.environ.get("G2_TEST_DB", "g2_coordinator_scratch")
DSN = f"host=127.0.0.1 dbname={DB} user=factory password=factory_dev_local"

from coordinator import Coordinator, GateNotSatisfied  # noqa: E402


def raw():
    return psycopg.connect(DSN, row_factory=dict_row, autocommit=True)


class TestGateClaim(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        subprocess.run([str(ROOT / ".venv" / "bin" / "python"),
                        str(ROOT / "tools" / "setup_db.py"), DB],
                       check=True, capture_output=True)

    def setUp(self):
        self.c = Coordinator(DSN)
        self.pid = self.c.create_production("Gate-claim production", 100_00, 80_00, "tester")
        self.run = self.c.start_run(self.pid, "FULL", "tester")

    def tearDown(self):
        self.c.close()

    def script(self, data=b"script v1"):
        return self.c.register_artifact(self.pid, "script", data, "local://script")["artifact_id"]

    def attempts(self, unit_id):
        with raw() as conn:
            return conn.execute("SELECT count(*) AS n FROM action_attempts WHERE unit_id=%s",
                                (unit_id,)).fetchone()["n"]

    def refusals(self, unit_id):
        with raw() as conn:
            return conn.execute(
                "SELECT * FROM audit_events WHERE unit_id=%s AND event_type='gate_claim_refused'",
                (unit_id,)).fetchall()

    def test_unapproved_script_refused_with_durable_evidence(self):
        s = self.script()
        u = self.c.plan_unit(self.pid, self.run, "09.01", "main", "text", (), [s])
        with self.assertRaises(GateNotSatisfied):
            self.c.claim(u, "w1", 100)
        unit = self.c.get_unit(u)
        self.assertEqual(unit["state"], "READY")
        self.assertEqual(unit["current_attempt"], 0)
        self.assertEqual(self.attempts(u), 0)
        self.assertEqual(self.c.budget_position(self.pid)["held_cents"], 0)
        ev = self.refusals(u)  # read through a separate connection: durable
        self.assertEqual(len(ev), 1)
        self.assertEqual(ev[0]["payload"]["gate_kind"], "HG2")
        self.assertEqual(ev[0]["payload"]["artifact_id"], s)

    def test_approved_gate_releases_claim(self):
        s = self.script()
        u = self.c.plan_unit(self.pid, self.run, "09.01", "main", "text", (), [s])
        gate = self.c.create_gate(self.pid, "HG2", s)
        self.c.decide_gate(gate, "APPROVED", "operator")
        res = self.c.claim(u, "w1", 100)
        self.assertEqual(res["attempt_no"], 1)
        self.assertEqual(self.c.get_unit(u)["state"], "CLAIMED")

    def test_rejected_and_foreign_gates_do_not_release(self):
        s = self.script()
        u = self.c.plan_unit(self.pid, self.run, "09.01", "main", "text", (), [s])
        gate = self.c.create_gate(self.pid, "HG2", s)
        self.c.decide_gate(gate, "REJECTED", "operator")
        with self.assertRaises(GateNotSatisfied):
            self.c.claim(u, "w1", 100)
        # a gate in another production for its own script is irrelevant here
        pid2 = self.c.create_production("Other production", 100_00, 80_00, "tester")
        s2 = self.c.register_artifact(pid2, "script", b"other script", "local://s2")["artifact_id"]
        g2 = self.c.create_gate(pid2, "HG2", s2)
        self.c.decide_gate(g2, "APPROVED", "operator")
        with self.assertRaises(GateNotSatisfied):
            self.c.claim(u, "w1", 100)
        self.assertEqual(len(self.refusals(u)), 2)

    def test_requirement_free_inputs_unaffected(self):
        canon = self.c.register_artifact(self.pid, "canon_manifest", b"canon", "local://c")["artifact_id"]
        u = self.c.plan_unit(self.pid, self.run, "05.01", "main", "text", (), [canon])
        res = self.c.claim(u, "w1", 100)
        self.assertEqual(res["attempt_no"], 1)

    def test_scheduler_skips_gated_unit(self):
        s = self.script()
        gated = self.c.plan_unit(self.pid, self.run, "09.01", "gated", "text", (), [s])
        free = self.c.plan_unit(self.pid, self.run, "01.01", "free", "text", (), ())
        claimed = self.c.scheduler_claim()
        claimed_ids = {c["unit_id"] for c in claimed}
        self.assertIn(free, claimed_ids)
        self.assertNotIn(gated, claimed_ids)
        self.assertEqual(self.c.get_unit(gated)["state"], "READY")


if __name__ == "__main__":
    unittest.main(verbosity=2)
