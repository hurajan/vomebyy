# G2 — Coordinator

Python coordinator for the AI Video Production Factory (OD-F02a: Python;
OD-F05: §7.1 engine state vocabulary). Lock: `LOCK_G2.md`.
Status: built by the builder; independent verification and owner acceptance are separate steps.

## Layout
- `coordinator/coordinator.py` — the single-writer coordinator: transition table,
  claim (budget reservation + lease + fencing, atomic), completion with fencing guard,
  validation routing, human gates bound to artifact hashes, claim-first provider
  callbacks, provider reconciliation, selective invalidation, capacity scheduler,
  lease reaper, append-only audit.
- `coordinator/mock_provider.py` — simulated provider for tests (no network/credentials).
- `database/migrations/002_g2_coordinator.sql` — execution/finance/evidence/reliability
  tables; apply after G1's `001_g1_registry.sql`.
- `tools/setup_db.py` — fresh scratch DB = G1 load + G2 migration.
- `tests/test_coordinator.py` — 13 tests incl. T-DEP-01, T-BUD-01, T-REC-01, T-PRV-01.
- `evidence/` — builder test output + G1 regression result.

## Reproduce
```bash
python3 -m venv .venv && .venv/bin/pip install "psycopg[binary]"
.venv/bin/python tools/setup_db.py g2_coordinator_scratch
.venv/bin/python -m unittest discover -s tests    # 13 tests, ~15 s
```
DB access in tests uses TCP (`127.0.0.1`) with the dev-only local role
`factory / factory_dev_local` — a scratch credential for this VM only, created by
`setup_db.py`; not a production secret. (Unix-socket peer auth rejects password logins.)

## Defects found by the builder's own tests and fixed during G2
1. `complete_attempt` built the CLAIMED→RUNNING transition from a mutated state copy
   (looked up `(RUNNING, start)`) — fixed to transition from the real state.
2. Audit payloads crashed on PG `Decimal` sums — JSON encoding now stringifies
   non-primitive values.
3. Cascade mixed `str`/`UUID` in one array parameter — normalized to UUID objects.
4. Budget rejection rolled itself back: a BLOCKED write inside the raising
   transaction was undone by the raise. Claim now raises an internal signal,
   rolls back, then commits BLOCKED + audit in its own transaction.
5. Cascade replacement units collided with the unit uniqueness scope — replacements
   are now planned in a new `PARTIAL_REPAIR` run (also the semantically right model).
6. Test-harness flow: provider jobs are now submitted from RUNNING, matching the
   real lifecycle (claim → start → submit).

## Defects found by INDEPENDENT VERIFICATION and fixed (re-verification pending)
The first verifier pass returned NOT VERIFIED with two defects — both the same
transaction-boundary class, caught because the verifier inspected through separate
connections while the builder's tests read back on the writer's connection:
- **D1 (critical):** `reconcile_once` never committed — its selection SELECT left a
  read transaction open, so every per-job write nested as a savepoint and rolled
  back on close. Reconciliation reported success but recovered nothing durably.
- **D2 (moderate):** stale-fencing evidence (`STALE_FENCED` attempt + audit event)
  was inserted inside the transaction its own raise rolled back — the rejection was
  safe, the audit trail had a hole.
Fixes: per-job processing now starts after committing the selection read; the
scheduler does the same for its snapshot; `complete_attempt` writes its rejection
evidence in its own transaction after rollback (the claim() pattern); and a general
guard — `_flush_reads()` at the top of every write method — ends any dangling read
transaction before a write transaction opens (this also fixed a third instance the
new tests exposed in the gate path). New `tests/test_durability.py` asserts effects
through SEPARATE connections: reconcile commit, fencing evidence, scheduler claims,
gate decisions. Suite is now 17 tests, all passing on the builder side.

## Not in G2
HTTP API (G3), dashboard (G3), station workflows (G4–G8), real providers, deployment
(G0 — blocked on G0.6). The G1 seed is read, never modified.
