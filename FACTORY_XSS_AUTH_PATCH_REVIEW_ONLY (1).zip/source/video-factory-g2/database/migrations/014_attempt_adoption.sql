-- 014: adoption markers for scheduler-prestaged attempts (Master Execution
-- Programme Gate 02, tasks 4-6). A prestaged attempt is adopted exactly once
-- by its authorized executor through the Coordinator adoption path; the
-- marker records who adopted it and under which idempotency key so a
-- sequential re-call by the same executor with the same key can return the
-- same adoption while any other post-adoption call is refused.
ALTER TABLE action_attempts ADD COLUMN IF NOT EXISTS adopted_at TIMESTAMPTZ;
ALTER TABLE action_attempts ADD COLUMN IF NOT EXISTS adopted_by TEXT;
ALTER TABLE action_attempts ADD COLUMN IF NOT EXISTS adoption_key TEXT;
