-- 015_gate04_execution_plans.sql — Gate 04 (Master Execution Programme):
-- registry-driven capability execution plans become first-class,
-- versioned data (G01-D02/D03), and attempts pin the plan they run
-- under (D01 enforcement point).
--
-- Additive only:
--   * operation_execution_plans — one row per (operation, plan
--     version): the materialized plan (source: seed plans.json via
--     g1 registry_tool load-plans). Content-addressed: a plan body
--     never changes under an existing plan_version (the loader asserts
--     hash stability on re-load).
--   * execution_plan_versions rollups are populated by the loader
--     (one row per STEP_SLOT capability); the table itself is
--     unchanged from migration 001.
--   * plan_id / plan_version / plan_hash on action_attempts — set by
--     the coordinator at claim time from operation_execution_plans.
--     A claim that cannot resolve a plan FAILS (coordinator commits a
--     'plan_missing' audit event); there is no unplanned execution.
--   * plan_action_attempts — per-action execution records written
--     through the coordinator API by the worker service as plan
--     actions finish. (attempt_id, action_key) is unique, so record
--     writes are idempotent replays.

CREATE TABLE IF NOT EXISTS operation_execution_plans (
    plan_id              TEXT NOT NULL,
    workflow_version     TEXT NOT NULL,
    plan_version         TEXT NOT NULL,
    operation_id         TEXT NOT NULL,
    capability_slot      TEXT NOT NULL,
    capability_version   TEXT NOT NULL,
    binding_status       TEXT NOT NULL
                         CHECK (binding_status IN ('FULLY_BOUND','PARTIALLY_BOUND')),
    plan                 JSONB NOT NULL,
    plan_hash            TEXT NOT NULL,
    action_count         INTEGER NOT NULL CHECK (action_count > 0),
    unbound_action_count INTEGER NOT NULL CHECK (unbound_action_count >= 0),
    created_at           TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (operation_id, plan_version)
);
CREATE INDEX IF NOT EXISTS idx_oep_plan_id
    ON operation_execution_plans (plan_id);
CREATE INDEX IF NOT EXISTS idx_oep_capability_slot
    ON operation_execution_plans (capability_slot);

ALTER TABLE action_attempts
    ADD COLUMN IF NOT EXISTS plan_id TEXT,
    ADD COLUMN IF NOT EXISTS plan_version TEXT,
    ADD COLUMN IF NOT EXISTS plan_hash TEXT;

CREATE TABLE IF NOT EXISTS plan_action_attempts (
    plan_action_attempt_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    attempt_id         UUID NOT NULL REFERENCES action_attempts(attempt_id),
    unit_id            UUID NOT NULL REFERENCES execution_units(unit_id),
    production_id      UUID NOT NULL REFERENCES productions(production_id),
    operation_id       TEXT NOT NULL,
    plan_id            TEXT NOT NULL,
    plan_version       TEXT NOT NULL,
    plan_hash          TEXT NOT NULL,
    action_key         TEXT NOT NULL,
    seq                INTEGER NOT NULL,
    status             TEXT NOT NULL
                       CHECK (status IN ('SUCCEEDED','FAILED','REFUSED')),
    inputs_hash        TEXT,
    output_summary     JSONB,
    cost_cents         INTEGER NOT NULL DEFAULT 0,
    error              TEXT,
    recorded_by        TEXT NOT NULL,
    recorded_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (attempt_id, action_key)
);
CREATE INDEX IF NOT EXISTS idx_paa_unit
    ON plan_action_attempts (unit_id, seq);
CREATE INDEX IF NOT EXISTS idx_paa_attempt
    ON plan_action_attempts (attempt_id, seq);
