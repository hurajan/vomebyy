-- MM-08 (Multi-Model programme) — financial controls completion.
--
-- Two additive pieces:
--
-- 1. provider_spend_limits: data-driven per-provider spending caps.
--    Ceilings existed per-production (migration 002) and per-assignment
--    (MM-03), but nothing aggregated spend by the provider of the
--    attempts' pinned bindings. A cap is operational policy, not a
--    binding: it gets its own rows (one ACTIVE row per provider +
--    environment) so it can be created, superseded, and audited
--    without touching provider_configs. The v1 window is the UTC
--    calendar day (window_kind is a column so a later window shape is
--    data, not a schema change).
--
-- 2. financial_evidence.charge_class gains 'UNRESOLVED': a
--    credentialed-provider completion that carries no usage evidence
--    at all must not settle on the caller's number (the estimate in
--    disguise). Its charge is recorded UNRESOLVED with
--    requires_reconciliation=true and the reservation stays HELD
--    until an operator reconciles it (MM-08 resolve path). Widened
--    with the migration-017 pattern: discover the inline CHECK from
--    migration 008 by its definition and replace it with a named
--    constraint carrying the original four values plus 'UNRESOLVED'.
--    Idempotent. Apply AFTER 017.

CREATE TABLE IF NOT EXISTS provider_spend_limits (
    limit_id      UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    provider      TEXT NOT NULL,
    environment   TEXT NOT NULL DEFAULT 'test'
        CHECK (environment IN ('test','production')),
    window_kind   TEXT NOT NULL DEFAULT 'calendar_day_utc'
        CHECK (window_kind IN ('calendar_day_utc')),
    cap_cents     BIGINT NOT NULL CHECK (cap_cents >= 0),
    active        BOOLEAN NOT NULL DEFAULT true,
    created_by    TEXT,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    superseded_at TIMESTAMPTZ
);

CREATE UNIQUE INDEX IF NOT EXISTS provider_spend_limits_one_active
    ON provider_spend_limits (provider, environment) WHERE active;

DO $$
DECLARE
    cname TEXT;
    cdef  TEXT;
BEGIN
    SELECT con.conname, pg_get_constraintdef(con.oid)
      INTO cname, cdef
      FROM pg_constraint con
     WHERE con.conrelid = 'financial_evidence'::regclass
       AND con.contype = 'c'
       AND pg_get_constraintdef(con.oid) LIKE '%FINALIZED%'
       AND pg_get_constraintdef(con.oid) NOT LIKE '%UNRESOLVED%'
     LIMIT 1;
    IF cname IS NOT NULL THEN
        EXECUTE format('ALTER TABLE financial_evidence DROP CONSTRAINT %I', cname);
    END IF;
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint
         WHERE conrelid = 'financial_evidence'::regclass
           AND pg_get_constraintdef(oid) LIKE '%UNRESOLVED%') THEN
        ALTER TABLE financial_evidence
            ADD CONSTRAINT financial_evidence_charge_class_check CHECK (
                charge_class IN
                ('ESTIMATED','CALCULATED','PROVIDER_REPORTED','FINALIZED',
                 'UNRESOLVED'));
    END IF;
END $$;
