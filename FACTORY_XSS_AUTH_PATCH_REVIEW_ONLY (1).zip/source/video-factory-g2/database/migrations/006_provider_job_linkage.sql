-- Gate C (from Gate B draft 006) — async provider-job linkage: bind every
-- provider job to the coordinator attempt that authorized it (INV-004/INV-005).
-- Additive only: new nullable columns + one index. Existing rows keep NULL
-- linkage and are treated as legacy/unlinked by the reconciler (never
-- auto-completed). Apply AFTER 005.

ALTER TABLE provider_jobs
    ADD COLUMN IF NOT EXISTS attempt_id UUID REFERENCES action_attempts(attempt_id),
    ADD COLUMN IF NOT EXISTS fencing_token BIGINT,
    ADD COLUMN IF NOT EXISTS resolved_config_hash TEXT;

-- Dispatcher scan support (design B1.5): unpublished outbox rows in
-- creation order.
CREATE INDEX IF NOT EXISTS outbox_unpublished_idx
    ON outbox_events (created_at) WHERE published_at IS NULL;

-- NOTE (deliberate, from the Gate B draft): the provider_jobs status CHECK
-- is NOT widened. Every terminal non-success job outcome is FAILED + a
-- failure_code (design B1.2 as clarified under GBV-01).
