-- Gate D migration 011 — artifact candidates (LOCK_GATE_D §3).
--
-- Durable-storage staging area, as data: every blob that enters the
-- coordinator through a completion path is first STAGED (bytes in the
-- configured StorageClient's candidate area), verified, and only then
-- PROMOTED behind a CURRENT artifact registration. ABANDONED rows are the
-- cleanup trail for staged content that was never promoted (TTL expiry).
-- Additive only: one new table + indexes. Apply AFTER 010.

CREATE TABLE IF NOT EXISTS artifact_candidates (
    candidate_id       UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    uri                TEXT NOT NULL UNIQUE,
    sha256             TEXT NOT NULL,
    size_bytes         BIGINT NOT NULL,
    content_type       TEXT,
    staged_by          TEXT,
    production_id      UUID REFERENCES productions(production_id),
    state              TEXT NOT NULL DEFAULT 'STAGED'
        CHECK (state IN ('STAGED','PROMOTED','ABANDONED')),
    promoted_artifact_id UUID REFERENCES artifacts(artifact_id),
    created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
    promoted_at        TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS artifact_candidates_state_idx
    ON artifact_candidates (state, created_at);
CREATE INDEX IF NOT EXISTS artifact_candidates_sha_idx
    ON artifact_candidates (sha256);
