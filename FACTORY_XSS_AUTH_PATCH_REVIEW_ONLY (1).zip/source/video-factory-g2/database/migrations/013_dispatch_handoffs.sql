-- Gate F migration 013 — dispatch handoffs (LOCK_GATE_F §2).
--
-- One durable record per outbox dispatch event handed to the configured
-- dispatch endpoint. The dispatcher writes this row and marks the outbox
-- event published in the same transaction after a successful POST. The
-- outbox idempotency key remains the consumer-facing deduplication key;
-- this table is the coordinator-side proof of handoff. Additive only:
-- one new table. Apply AFTER 012.

CREATE TABLE IF NOT EXISTS dispatch_handoffs (
    handoff_id      UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    outbox_event_id UUID NOT NULL UNIQUE REFERENCES outbox_events(event_id),
    unit_id         UUID NOT NULL REFERENCES execution_units(unit_id),
    endpoint        TEXT NOT NULL,
    http_status     INT NOT NULL,
    handed_off_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS dispatch_handoffs_unit_idx
    ON dispatch_handoffs (unit_id);
