-- Gate C (from Gate B draft 007) — callback exactly-once at the schema
-- level: at most one PROCESSED delivery per idempotency key. Previously
-- exactly-once rested on the job-row lock plus a processed-count check
-- inside one transaction (sound single-instance); this partial unique
-- index makes it a schema guarantee (INV-004). Apply AFTER 006.
--
-- Compatibility: duplicate (unprocessed) delivery rows remain allowed and
-- expected; only a second PROCESSED row is rejected.

CREATE UNIQUE INDEX IF NOT EXISTS callback_deliveries_one_processed
    ON callback_deliveries (idempotency_key) WHERE processed;
