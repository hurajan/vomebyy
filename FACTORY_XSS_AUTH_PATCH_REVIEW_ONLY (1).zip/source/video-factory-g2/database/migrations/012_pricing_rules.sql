-- Gate D migration 012 — pricing rules (LOCK_GATE_D §4, design B3).
--
-- The price book, as data: completion computes a CALCULATED evidence row
-- from the attempt's usage x the ACTIVE rules for its provider/model
-- (a NULL model matches any model of that provider). Prices are
-- NUMERIC(12,4) cents per unit so sub-cent token prices stay exact until
-- the single half-up rounding at evidence time. No rule -> no CALCULATED
-- row; a price is never invented. Additive only. Apply AFTER 011.

CREATE TABLE IF NOT EXISTS pricing_rules (
    rule_id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    provider        TEXT NOT NULL,
    model           TEXT,
    modality        TEXT,
    unit_kind       TEXT NOT NULL CHECK (unit_kind IN
        ('input_token','output_token','cached_token','image','media_second','request')),
    unit_price_cents NUMERIC(12,4) NOT NULL,
    pricing_version TEXT NOT NULL,
    active          BOOLEAN NOT NULL DEFAULT true,
    created_by      TEXT,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS pricing_rules_provider_idx
    ON pricing_rules (provider, model) WHERE active;
