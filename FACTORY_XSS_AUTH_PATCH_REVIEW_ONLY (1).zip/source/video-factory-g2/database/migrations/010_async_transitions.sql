-- Gate C migration 010 — async transitions (design B1.3).
--
-- The engine transition table is CODE-resident (TRANSITIONS dict in
-- coordinator/coordinator.py — migration 002 defines no transitions
-- table). The (AWAITING_PROVIDER, transient_error) -> RETRY_WAIT entry
-- declared in design B1.3 is therefore added in coordinator.py alongside
-- this migration; this file exists so the setup chain records the schema
-- generation at which the entry became legal, and so DB-only consumers
-- can detect it. It intentionally changes no schema objects.

SELECT 1;
