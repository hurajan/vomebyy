-- G2 coordinator schema — AI Video Production Factory, programme migration set.
-- Apply AFTER 001_g1_registry.sql (G1) in the same database. PostgreSQL 16.
-- Money is integer cents. Ledger tables are append-only by contract (coordinator
-- never UPDATEs budget_transactions / audit_events / action_attempts history).

BEGIN;

CREATE TABLE IF NOT EXISTS productions (
    production_id    UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    title            TEXT NOT NULL,
    workflow_version TEXT NOT NULL REFERENCES workflow_versions(workflow_version),
    hard_ceiling_cents BIGINT NOT NULL CHECK (hard_ceiling_cents >= 0),
    soft_ceiling_cents BIGINT NOT NULL CHECK (soft_ceiling_cents >= 0),
    status           TEXT NOT NULL DEFAULT 'ACTIVE' CHECK (status IN ('ACTIVE','PAUSED','COMPLETED','CANCELLED')),
    created_by       TEXT NOT NULL,
    created_at       TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS production_runs (
    run_id        UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    production_id UUID NOT NULL REFERENCES productions(production_id),
    kind          TEXT NOT NULL CHECK (kind IN ('FULL','PARTIAL_REPAIR','DERIVATIVE_ONLY')),
    started_by    TEXT NOT NULL,
    started_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS execution_units (
    unit_id        UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    production_id  UUID NOT NULL REFERENCES productions(production_id),
    run_id         UUID NOT NULL REFERENCES production_runs(run_id),
    workflow_version_ref TEXT NOT NULL DEFAULT '1.0.0',
    operation_id   TEXT NOT NULL,
    unit_key       TEXT NOT NULL DEFAULT 'main',
    lane           TEXT NOT NULL DEFAULT 'text',
    state          TEXT NOT NULL DEFAULT 'PENDING' CHECK (state IN
        ('PENDING','READY','CLAIMED','RUNNING','VALIDATING','ACCEPTED',
         'RETRY_WAIT','AWAITING_PROVIDER','AWAITING_HUMAN','REPAIR_REQUIRED',
         'BLOCKED','CANCELLED','UNKNOWN','SUPERSEDED')),
    current_attempt INT NOT NULL DEFAULT 0,
    fencing_token  BIGINT NOT NULL DEFAULT 0,
    supersedes_unit_id UUID REFERENCES execution_units(unit_id),
    block_reason   TEXT,
    created_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (production_id, operation_id, unit_key, run_id),
    FOREIGN KEY (workflow_version_ref, operation_id) REFERENCES operation_definitions(workflow_version, operation_id)
);

CREATE TABLE IF NOT EXISTS unit_dependencies (
    unit_id         UUID NOT NULL REFERENCES execution_units(unit_id),
    depends_on_unit UUID NOT NULL REFERENCES execution_units(unit_id),
    PRIMARY KEY (unit_id, depends_on_unit),
    CHECK (unit_id <> depends_on_unit)
);

CREATE TABLE IF NOT EXISTS artifacts (
    artifact_id     UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    production_id   UUID NOT NULL REFERENCES productions(production_id),
    produced_by_unit UUID REFERENCES execution_units(unit_id),
    artifact_type   TEXT NOT NULL,
    version         INT NOT NULL CHECK (version >= 1),
    storage_uri     TEXT NOT NULL,
    sha256          TEXT NOT NULL,
    state           TEXT NOT NULL DEFAULT 'CANDIDATE' CHECK (state IN ('CANDIDATE','CURRENT','SUPERSEDED','INVALIDATED')),
    invalidated_by  TEXT,
    invalidation_reason TEXT,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (production_id, artifact_type, version)
);

CREATE TABLE IF NOT EXISTS artifact_dependencies (
    consumer_artifact_id UUID NOT NULL REFERENCES artifacts(artifact_id),
    consumed_artifact_id UUID NOT NULL REFERENCES artifacts(artifact_id),
    consumed_version     INT NOT NULL,
    consumed_sha256      TEXT NOT NULL,
    PRIMARY KEY (consumer_artifact_id, consumed_artifact_id)
);

CREATE TABLE IF NOT EXISTS unit_inputs (
    unit_id     UUID NOT NULL REFERENCES execution_units(unit_id),
    artifact_id UUID NOT NULL REFERENCES artifacts(artifact_id),
    PRIMARY KEY (unit_id, artifact_id)
);

CREATE TABLE IF NOT EXISTS action_instances (
    instance_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    unit_id     UUID NOT NULL REFERENCES execution_units(unit_id),
    action_id   TEXT NOT NULL,
    mandatory   BOOLEAN NOT NULL DEFAULT true,
    state       TEXT NOT NULL DEFAULT 'PENDING',
    UNIQUE (unit_id, action_id)
);

CREATE TABLE IF NOT EXISTS worker_leases (
    unit_id       UUID PRIMARY KEY REFERENCES execution_units(unit_id),
    worker_id     TEXT NOT NULL,
    lease_token   UUID NOT NULL DEFAULT gen_random_uuid(),
    fencing_token BIGINT NOT NULL,
    acquired_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
    expires_at    TIMESTAMPTZ NOT NULL,
    heartbeat_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS budget_reservations (
    reservation_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    production_id  UUID NOT NULL REFERENCES productions(production_id),
    unit_id        UUID NOT NULL REFERENCES execution_units(unit_id),
    estimated_cents BIGINT NOT NULL CHECK (estimated_cents >= 0),
    settled_cents  BIGINT,
    state          TEXT NOT NULL DEFAULT 'HELD' CHECK (state IN ('HELD','SETTLED','RELEASED')),
    expires_at     TIMESTAMPTZ,
    created_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS budget_transactions (
    txn_id        BIGSERIAL PRIMARY KEY,
    production_id UUID NOT NULL REFERENCES productions(production_id),
    kind          TEXT NOT NULL CHECK (kind IN ('RESERVE','CHARGE','RELEASE','REFUND','ADJUSTMENT')),
    amount_cents  BIGINT NOT NULL,
    reservation_id UUID REFERENCES budget_reservations(reservation_id),
    provider_job_id UUID,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS provider_jobs (
    job_id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    unit_id         UUID NOT NULL REFERENCES execution_units(unit_id),
    production_id   UUID NOT NULL REFERENCES productions(production_id),
    provider        TEXT NOT NULL,
    provider_job_id TEXT,
    idempotency_key TEXT NOT NULL UNIQUE,
    request_payload JSONB NOT NULL DEFAULT '{}'::jsonb,
    status          TEXT NOT NULL DEFAULT 'SUBMITTED' CHECK (status IN
        ('SUBMITTED','PROCESSING','COMPLETED','FAILED','TIMEOUT','UNKNOWN','NOT_FOUND')),
    result_artifact_id UUID REFERENCES artifacts(artifact_id),
    cost_charged_cents BIGINT,
    poll_count      INT NOT NULL DEFAULT 0,
    max_poll_attempts INT NOT NULL DEFAULT 60,
    raw_response    JSONB,
    submitted_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    last_polled_at  TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS callback_deliveries (
    delivery_id     BIGSERIAL PRIMARY KEY,
    idempotency_key TEXT NOT NULL,
    processed       BOOLEAN NOT NULL DEFAULT false,
    result          JSONB,
    delivered_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS action_attempts (
    attempt_id      UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    instance_id     UUID REFERENCES action_instances(instance_id),
    unit_id         UUID NOT NULL REFERENCES execution_units(unit_id),
    attempt_no      INT NOT NULL,
    worker_id       TEXT,
    capability_version TEXT,
    status          TEXT NOT NULL DEFAULT 'RUNNING' CHECK (status IN
        ('RUNNING','VALIDATING','ACCEPTED','FAILED','STALE_FENCED','ORPHANED')),
    output_artifact_id UUID REFERENCES artifacts(artifact_id),
    reservation_id  UUID REFERENCES budget_reservations(reservation_id),
    actual_cost_cents BIGINT,
    error_class     TEXT,
    retry_decision  TEXT,
    started_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    finished_at     TIMESTAMPTZ,
    UNIQUE (unit_id, attempt_no)
);

CREATE TABLE IF NOT EXISTS quality_evaluations (
    evaluation_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    artifact_id   UUID NOT NULL REFERENCES artifacts(artifact_id),
    validator_id  TEXT NOT NULL,
    method        TEXT NOT NULL,
    evidence      JSONB NOT NULL DEFAULT '{}'::jsonb,
    verdict       TEXT NOT NULL CHECK (verdict IN ('PASS','FAIL','REVIEW_REQUIRED')),
    evaluator_identity TEXT NOT NULL,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS human_gates (
    gate_id        UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    production_id  UUID NOT NULL REFERENCES productions(production_id),
    gate_kind      TEXT NOT NULL,
    artifact_id    UUID NOT NULL REFERENCES artifacts(artifact_id),
    artifact_sha256 TEXT NOT NULL,
    verdict        TEXT NOT NULL DEFAULT 'PENDING' CHECK (verdict IN ('PENDING','APPROVED','REJECTED','CONDITIONAL')),
    conditions     JSONB,
    decided_by     TEXT,
    decided_at     TIMESTAMPTZ,
    created_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS audit_events (
    log_id        BIGSERIAL PRIMARY KEY,
    production_id UUID REFERENCES productions(production_id),
    unit_id       UUID REFERENCES execution_units(unit_id),
    event_type    TEXT NOT NULL,
    old_state     TEXT,
    new_state     TEXT,
    actor         TEXT NOT NULL,
    payload       JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS cascade_events (
    event_id      UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    source_artifact_id UUID NOT NULL REFERENCES artifacts(artifact_id),
    affected_artifact_ids UUID[] NOT NULL DEFAULT '{}',
    affected_unit_ids     UUID[] NOT NULL DEFAULT '{}',
    reason        TEXT NOT NULL,
    authorized_by TEXT NOT NULL,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS outbox_events (
    event_id        UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    aggregate_type  TEXT NOT NULL,
    aggregate_id    UUID NOT NULL,
    event_type      TEXT NOT NULL,
    payload         JSONB NOT NULL DEFAULT '{}'::jsonb,
    idempotency_key TEXT NOT NULL UNIQUE,
    published_at    TIMESTAMPTZ,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS capacity_policies (
    lane            TEXT PRIMARY KEY,
    max_concurrency INT NOT NULL CHECK (max_concurrency >= 0),
    enabled         BOOLEAN NOT NULL DEFAULT true
);

INSERT INTO capacity_policies VALUES
    ('text', 4, true), ('voice', 2, true), ('image', 2, true), ('video', 1, true),
    ('render-cpu', 2, true), ('render-gpu', 1, true), ('qa', 4, true)
ON CONFLICT (lane) DO NOTHING;

COMMIT;
