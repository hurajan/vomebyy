-- G8 (LOCK_G8) — publication gate requirement, PERMANENT placement (owner
-- ruling 2026-10-28: G8 lock confirmed WITH publication gate (ii); placement
-- per the G7 placement-(A) precedent). Apply AFTER
-- 004_g7_master_gate_requirement.sql in the same database. PostgreSQL 16.
-- Data only — no coordinator logic change: every database built by the
-- setup chain now requires an APPROVED HG5 gate before a unit planned
-- against a derivative_package may be claimed, via the G6 gate-claim
-- mechanism.

BEGIN;

INSERT INTO gate_requirements(artifact_type, gate_kind) VALUES
    ('derivative_package', 'HG5')
ON CONFLICT (artifact_type) DO NOTHING;

COMMIT;
