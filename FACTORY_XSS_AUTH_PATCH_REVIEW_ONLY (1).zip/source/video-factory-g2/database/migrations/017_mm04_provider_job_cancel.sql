-- MM-04 (Multi-Model programme) — provider-job cancellation.
--
-- The async provider-job lifecycle gains a CANCELLED terminal state:
-- the Coordinator's cancel operation (cancel_provider_job) marks the
-- job CANCELLED with raw_response {failure_code: 'CANCELLED'} and fails
-- the attempt with error_class 'CANCELLED'. The Gate B design note for
-- migration 006 deliberately did NOT widen this CHECK at that time
-- (every terminal non-success outcome was FAILED + a failure_code);
-- MM-04's brief explicitly requires the job to be marked CANCELLED, so
-- the widening lands here, additively: one new migration, no history
-- edited, no existing status value changed or removed.
--
-- Idempotent: discovers the inline CHECK from migration 002 by its
-- definition and replaces it with a named constraint carrying the
-- original seven values plus 'CANCELLED'. Apply AFTER 016.

DO $$
DECLARE
    cname TEXT;
    cdef  TEXT;
BEGIN
    SELECT con.conname, pg_get_constraintdef(con.oid)
      INTO cname, cdef
      FROM pg_constraint con
     WHERE con.conrelid = 'provider_jobs'::regclass
       AND con.contype = 'c'
       AND pg_get_constraintdef(con.oid) LIKE '%NOT_FOUND%'
     LIMIT 1;
    IF cname IS NOT NULL AND cdef NOT LIKE '%CANCELLED%' THEN
        EXECUTE format('ALTER TABLE provider_jobs DROP CONSTRAINT %I', cname);
    END IF;
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint
         WHERE conrelid = 'provider_jobs'::regclass
           AND conname = 'provider_jobs_status_check') THEN
        ALTER TABLE provider_jobs
            ADD CONSTRAINT provider_jobs_status_check CHECK (status IN
                ('SUBMITTED','PROCESSING','COMPLETED','FAILED','TIMEOUT',
                 'UNKNOWN','NOT_FOUND','CANCELLED'));
    END IF;
END $$;
