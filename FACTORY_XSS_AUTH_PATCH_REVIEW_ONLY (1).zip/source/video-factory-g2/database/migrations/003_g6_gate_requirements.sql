-- G6 amendment (LOCK_G6 Part A) — gate requirements for claim-time enforcement.
-- Apply AFTER 002_g2_coordinator.sql in the same database. PostgreSQL 16.
-- Requirements are DATA: which artifact types require which human gate
-- before a unit planned against them may be claimed. Seeded: script -> HG2
-- (OD-F04=(c) built-Studio numbering; G5's script gate).

BEGIN;

CREATE TABLE IF NOT EXISTS gate_requirements (
    artifact_type TEXT PRIMARY KEY,
    gate_kind     TEXT NOT NULL
);

INSERT INTO gate_requirements(artifact_type, gate_kind) VALUES
    ('script', 'HG2')
ON CONFLICT (artifact_type) DO NOTHING;

COMMIT;
