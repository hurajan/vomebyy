-- MM-03 (Multi-Model programme) — central model + capability registry.
--
-- The registry is the GOVERNANCE layer above provider_configs (migration
-- 009), which remains the executable binding store. Policies and
-- assignments exist here as data with lifecycle; PROMOTION is the only
-- path by which a policy writes provider_configs rows, and it requires
-- an OPERATOR-role approval recorded in policy_events. Nothing PROPOSED
-- ever affects a claim.
--
-- C-01 decision (MM-01 finding, independently confirmed): the approved
-- registry sets NO per-operation cost ceiling (resource_ceiling is null
-- for 192/192 operations), so ceilings live on
-- operation_model_assignments.max_cost_cents, seeded from the MM-01
-- classification with provenance in cost_source ('BINDING' where a real
-- binding set the figure, 'PROPOSED_CLASS_DEFAULT' otherwise). A ceiling
-- binds claims only while its assignment is ACTIVE.
--
-- Additive only: seven new tables + two partial unique indexes. No
-- existing table is altered. Apply AFTER 015.

CREATE TABLE IF NOT EXISTS providers (
    name            TEXT PRIMARY KEY,
    adapter         TEXT NOT NULL,
    base_url        TEXT,
    credential_ref  TEXT,  -- env var NAME only; never a secret value
    status          TEXT NOT NULL DEFAULT 'enabled',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- The OpenRouter catalog as data (MM-02 snapshot). provider here is the
-- catalog vendor prefix of the model id (e.g. 'anthropic'); the
-- execution-provider namespace is the providers table above (the same
-- namespace provider_configs.provider uses). Pricing is the catalog's
-- USD-per-token figure, stored exactly (NUMERIC(20,10)).
CREATE TABLE IF NOT EXISTS models (
    model_id          TEXT PRIMARY KEY,
    provider          TEXT NOT NULL,
    name              TEXT,
    context_length    BIGINT,
    pricing_in        NUMERIC(20,10),
    pricing_out       NUMERIC(20,10),
    modalities        JSONB NOT NULL DEFAULT '{}'::jsonb,
    structured_output BOOLEAN NOT NULL DEFAULT false,
    catalog_version   TEXT,
    provenance        TEXT,
    created_at        TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS model_policies (
    policy_id       TEXT PRIMARY KEY,
    role            TEXT NOT NULL,
    station         INT,
    primary_model   TEXT,
    fallback_model  TEXT,
    evaluation_model TEXT,
    version         TEXT NOT NULL,
    status          TEXT NOT NULL DEFAULT 'PROPOSED'
        CHECK (status IN ('PROPOSED','ACTIVE','RETIRED')),
    created_by      TEXT,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (role, version)
);

-- At most one ACTIVE policy per role (structural backstop; the service
-- also serializes promotion per role — see model_registry.py).
CREATE UNIQUE INDEX IF NOT EXISTS model_policies_one_active_per_role
    ON model_policies (role) WHERE status='ACTIVE';

CREATE TABLE IF NOT EXISTS operation_model_assignments (
    assignment_id   UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    operation_id    TEXT NOT NULL,
    role            TEXT NOT NULL,
    policy_id       TEXT REFERENCES model_policies(policy_id),
    station         INT,
    execution_class TEXT,
    primary_model   TEXT,
    fallback_model  TEXT,
    evaluation_model TEXT,
    matrix_version  TEXT NOT NULL,
    max_cost_cents  BIGINT,
    cost_source     TEXT,
    null_reason     TEXT,
    status          TEXT NOT NULL DEFAULT 'PROPOSED'
        CHECK (status IN ('PROPOSED','ACTIVE','RETIRED','NONE')),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (operation_id, matrix_version)
);

-- At most one ACTIVE assignment per operation: claim reads exactly one.
CREATE UNIQUE INDEX IF NOT EXISTS oma_one_active_per_operation
    ON operation_model_assignments (operation_id) WHERE status='ACTIVE';

-- Append-only policy lifecycle history (promotion approvals live here).
CREATE TABLE IF NOT EXISTS policy_events (
    event_id    UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    policy_id   TEXT NOT NULL REFERENCES model_policies(policy_id),
    action      TEXT NOT NULL,
    actor       TEXT,
    note        TEXT,
    payload     JSONB NOT NULL DEFAULT '{}'::jsonb,
    at          TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS policy_events_policy_idx
    ON policy_events (policy_id, at);

-- Benchmark evidence. Ships EMPTY: no score may exist here without a
-- real benchmark run behind it (MM-02 labeling rule).
CREATE TABLE IF NOT EXISTS benchmark_results (
    result_id   UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    model_id    TEXT NOT NULL,
    task        TEXT NOT NULL,
    score       NUMERIC,
    status      TEXT NOT NULL CHECK (status IN ('VERIFIED','UNVERIFIED')),
    source      TEXT,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS provider_health (
    health_id   UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    provider    TEXT NOT NULL,
    status      TEXT NOT NULL,
    checked_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    detail      TEXT
);

CREATE INDEX IF NOT EXISTS provider_health_provider_idx
    ON provider_health (provider, checked_at DESC);
