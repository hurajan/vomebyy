-- G7 (LOCK_G7) — master gate requirement, PERMANENT placement (owner ruling
-- 2026-10-28: option (A)). Apply AFTER 003_g6_gate_requirements.sql in the
-- same database. PostgreSQL 16. Data only — no coordinator logic change:
-- every database built by the setup chain now requires an APPROVED HG4
-- gate (OD-F04=(c)) before a unit planned against a master_package may
-- be claimed, via the G6 gate-claim mechanism.

BEGIN;

INSERT INTO gate_requirements(artifact_type, gate_kind) VALUES
    ('master_package', 'HG4')
ON CONFLICT (artifact_type) DO NOTHING;

COMMIT;
