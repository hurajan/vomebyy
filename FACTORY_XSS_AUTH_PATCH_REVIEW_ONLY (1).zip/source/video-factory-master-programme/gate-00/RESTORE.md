# RESTORE — reproducing the Gate 00 baseline

The baseline is the nine factory trees + the Real-AI programme trees **as
content**, pinned by `evidence/source_manifest.json` (1,535 files; aggregate
SHA-256 `78cd4744b158799d6248c1b5047406180bc8480f67d21ecd8d04ee7a0c129b3c`
over sorted `"<sha256>  <path>"` lines; stable part 1,498 files /
`64dbdce308cb8096eef3ce698cd30dbbcd139865b8cb75312184739639134f1c`; seam
part 37 files — see the caveat below). The trees themselves are the
checkpoint; this tarball carries the manifests, facts, ownership register,
reports, and locks needed to verify and rebuild the runtime state.

## Caveat — the seam

37 files in the claim/dispatch seam were `IN_FLUX` during Gate 00 capture
(the Gate 02 D-H1 fix was being built concurrently under
`gate-h/LOCK_FIX_DH1.md`); one seam file
(`gate-f/runtime_services/scheduler_service.py`) was still `PRE_FIX`. For
seam files, the **post-fix baseline is pinned by Gate 02's own evidence**
(`gate-h/evidence/results/fix-dh1/` + its changed-assertions), not by this
manifest. Everything outside the seam is pinned exactly by this manifest.

## Verify the source baseline

```bash
python3 - <<'EOF'
import json, hashlib
from pathlib import Path
m = json.load(open('evidence/source_manifest.json'))  # inside gate-00/
ws = Path.home() / 'workspace'
bad = []
for e in m['files']:
    p = ws / e['path']
    if not p.exists() or hashlib.sha256(p.read_bytes()).hexdigest() != e['sha256']:
        bad.append(e['path'])
print('mismatches:', bad if bad else 'NONE (seam files may differ — see caveat)')
EOF
```

## Rebuild the runtime state from scratch

Prerequisites on this VM: PostgreSQL 16 (`pg_lsclusters` → cluster `16/main`),
Python 3.12 with the g2/g3 venvs present in-tree, Node 24, n8n 2.45.5 in
`video-factory-g4/node_modules`. Exact versions: `evidence/baseline_facts.json`.

```bash
pg_ctlcluster 16 main start                     # if the cluster is down
# 1. Registry (validates the frozen 1.0.0 seed; expect verdict PASS,
#    definition_hash ea4503f516fc4f7940f187f5cd9dac38c57f0d239726cac90e2d0a18a8bc9d73)
cd ~/workspace/video-factory-g1 && ~/workspace/video-factory-g2/.venv/bin/python tools/registry_tool.py validate
# 2. A runtime scratch DB (registry load + migrations 002–013 + FACTORY/test mock binding)
~/workspace/video-factory-g2/.venv/bin/python ~/workspace/video-factory-g2/tools/setup_db.py <dbname>
#    (video-factory-g3/tools/setup_db.py wraps this for the G3 tree.)
# 3. One station tree's full stack (API :8730, worker :8795, evaluation :8796,
#    n8n :5678 with that tree's workflows synced via REST + activated)
python3 ~/workspace/video-factory-g5/tools/setup_env.py     # or g4/g6/g7/g8
# 4. The full-run stack (all stations on one DB)
python3 ~/workspace/video-factory-g9/tools/setup_fullrun.py
```

Notes: only one station stack runs at a time (shared ports and a single
n8n instance in the g4 tree). Setups kill prior listeners on 8730/8795/8796
by port (`fuser -k`). Dev role tokens and DSNs are injected by the setups
via process env — the variable **names** are listed in
`evidence/baseline_facts.json`; no values are recorded in Gate 00 evidence.

## Reproduce the regression baseline

Canonical commands per suite are in `evidence/baseline_facts.json`
(`test_commands`). Gate 00's own run — with the Gate 02 concurrency caveat,
both attempts, and the clean-restart result — is classified in
`evidence/results/regression_summary.json` with full logs in
`evidence/logs/`.
