# OWNERSHIP — exclusive write ownership register (Master Execution Programme)

Established at Gate 00 (2026-10-28). **Rule: no agent or task edits a file
without its ownership being recorded here first. One writer per file at a
time; concurrent modifications are never silently merged — a second writer
must wait for release or escalate to the controller.** Ownership is released
when the owning gate's evidence is committed; the controller (parent agent)
updates this register on gate transitions. Baseline hashes for all files:
`gate-00/evidence/source_manifest.json`.

## Current ownership

| Scope | Owner | Authority | Since |
|---|---|---|---|
| **Gate 02 seam** (files below) | Gate 02 builder (D-H1 fix) | `video-factory-real-ai-programme/gate-h/LOCK_FIX_DH1.md` + Programme Gate 02 | 2026-10-28 |
| **Lean Phase 3 slice seam** (files below) | Lean Phase 3 builder (op 08.12 provider preparation) | LEAN_EXECUTION_PROMPT.md Phase 3 + lean-phase-2/SELECTED_OPERATION_SPEC.md (attested, lean-phase-3/SPEC_ATTESTATION.md) | 2026-10-29 |
| **Lean Phase 4 prep fix seam** (files below) | Lean Phase 4 prep fix builder (F-P4P-01 / F-P4P-02) | Controller authorization under LEAN_EXECUTION_PROMPT.md (in-scope repair; lean-phase-4-prep/FINDING.md + spec §3.2) | 2026-10-29 |
| `video-factory-master-programme/gate-00/**` | Gate 00 executor | Gate 00 lock (this programme) | 2026-10-28 |
| `video-factory-master-programme/controller/STATE.md`, `PROGRAMME.md` | Controller (parent agent) only | Programme §5 | 2026-10-28 |
| Everything else in the factory + programme trees | **UNASSIGNED — read-only for all agents** until a gate lock assigns it | — | — |

## Gate 02 seam — owned files (design (b), claim/dispatch seam only)

- `video-factory-g2/coordinator/coordinator.py` — `scheduler_claim` pre-staging (+ adoption support per Programme Gate 02)
- `video-factory-g2/tests/test_fix_dh1.py` — the fix's new tests (builder-created)
- `video-factory-g3/api/server.py` — attempts snapshot completeness / adoption endpoint
- `video-factory-g3/contracts/api_contract.json` — contract version (observed at 1.5.0 during Gate 00 capture; Gate G left 1.4.0)
- `video-factory-g4/tools/gen_workflows.py`, `video-factory-g5/tools/gen_workflows.py`, `video-factory-g6/tools/gen_workflows.py`, `video-factory-g7/tools/gen_workflows.py`, `video-factory-g8/tools/gen_workflows.py` — executor identity constants + resume branch
- `video-factory-g4/workflows/*.json`, `video-factory-g5/workflows/*.json`, `video-factory-g6/workflows/*.json`, `video-factory-g7/workflows/*.json`, `video-factory-g8/workflows/*.json` — regenerated workflow files
- `video-factory-real-ai-programme/gate-f/runtime_services/scheduler_service.py` — scheduler service (claims through `scheduler_claim`)
- `video-factory-real-ai-programme/gate-h/harness/fix_dh1_t09.py` — the fix's T9 re-run harness
- Incidental, only if a pinned shape changes and recorded in the fix's changed-assertions: the affected suite's test files (g2/g3/station/runtime suites)

Gate 02's own evidence (its T9 re-run results + changed-assertions + suite
logs) pins the **post-fix baseline** for every seam file; Gate 00's manifest
marks them `IN_FLUX` (see `source_manifest.json`, per-file `seam_status`).

## Lean Phase 3 slice seam — owned files (op 08.12 provider-aware seq-2, inside plan_exec only)

- `video-factory-real-ai-programme/gate-c/worker_service/actions.py` — new `op.generate_script` implementation + specs; `ActionRefused`; `ActionContext.binding`
- `video-factory-real-ai-programme/gate-c/worker_service/plan_exec.py` — binding pass-through into ActionContext; refusal/error mapping; provider-evidence in summary + generation action record
- `video-factory-real-ai-programme/gate-c/worker_service/service.py` — route provider-dispatch plans through plan_exec (pin verify + API action sink)
- `video-factory-real-ai-programme/gate-c/worker_service/envelope.py` — wrap plan-executed provider results
- `video-factory-real-ai-programme/gate-c/worker_service/action_implementations.json` — regenerated manifest (new implementation entry)
- `video-factory-real-ai-programme/gate-c/worker_service/tests/test_generate_script.py` — builder-created slice unit tests
- `video-factory-g1/tools/generate_plans.py` — 08.12 seq-2 implementation swap only
- `video-factory-g1/seed-definitions/workflow-1.0.0/plans.json` — regenerated (only the 08.12 plan body + plans_hash may change)
- `video-factory-master-programme/lean-phase-3/**` — slice setup script, harness, evidence (logs/results), changed-assertions
- Incidental, only if a pinned shape changes and recorded in lean-phase-3/evidence/CHANGED_ASSERTIONS.md: the affected suite's test files

No migrations (next free number 014 untouched). No coordinator, API-server,
registry-definition, or workflow files. Real-provider acceptance stays
BLOCKED_EXTERNAL (no credential exists; no paid request is authorized or made).

## Lean Phase 4 prep fix seam — owned files (F-P4P-01 / F-P4P-02, unit-executor workflows only)

- `video-factory-g4/tools/gen_workflows.py`, `video-factory-g5/tools/gen_workflows.py`, `video-factory-g6/tools/gen_workflows.py`, `video-factory-g7/tools/gen_workflows.py`, `video-factory-g8/tools/gen_workflows.py` — unit-executor ONLY: (01) worker-request ref assembly additionally includes the CURRENT output artifacts of the unit's dependency units (production artifacts joined to ACCEPTED same-run producer units via the existing units/artifacts reads; planned inputs unchanged and first); (02) submit-candidate additionally forwards the worker response's `usage` + `provider_request_id` verbatim when present
- `video-factory-g4/workflows/*.json`, `video-factory-g5/workflows/*.json`, `video-factory-g6/workflows/*.json`, `video-factory-g7/workflows/*.json`, `video-factory-g8/workflows/*.json` — regenerated workflow files (diffs must stay confined to the unit-executor workflow in each tree)
- `video-factory-master-programme/lean-phase-4-prep/fix/**` — fix battery harness, evidence (logs/results), changed-assertions
- Incidental, only if a pinned shape changes and recorded in lean-phase-4-prep/fix/CHANGED_ASSERTIONS.md: the affected suite's test files

No coordinator, API-server, worker-service, registry-definition, or contract
changes. No migrations. All provider-involved battery runs are STUB_TESTED;
real-provider acceptance stays BLOCKED_EXTERNAL (no credential exists).

**Release (2026-10-29):** fix complete; the post-fix baseline for the seam
files is pinned by `video-factory-master-programme/lean-phase-4-prep/fix/`
(FIX_REPORT.md + evidence/results/fix_battery_summary.json + normalized
workflow diffs). Slice battery P4P-1..5 all PASS on the fixed executors;
deterministic regression green (g9 10/10 with the full run at 18 ACCEPTED /
1620¢, station suites g4 2/2 · g5 1/1 · g6 3/3 · g7 2/2 · g8 1/1, T02-H 12/12,
worker 40/40, g3 36/36).

## MM-03 registry seam — owned files (Multi-Model Gate 03, central model + capability registry)

| Scope | Owner | Authority | Since |
|---|---|---|---|
| **MM-03 registry seam** (files below) | MM-03 builder | `video-factory-master-programme/mm-gate-03/LOCK_MM03.md` + MULTI_MODEL_EXECUTION_PROMPT.md Gate MM-03 | 2026-10-29 |

- `video-factory-g2/database/migrations/016_mm03_model_registry.sql` — NEW (additive): providers, models, model_policies, operation_model_assignments, policy_events, benchmark_results, provider_health. **Migration 016 claimed by MM-03** (the namespace note below predates 014/015; on-disk chain runs to 015, so 016 is the next free number).
- `video-factory-g2/tools/setup_db.py` — one added apply line for migration 016
- `video-factory-g2/coordinator/model_registry.py` — NEW: promotion/rollback service + registry reads + refusal audit
- `video-factory-g2/coordinator/coordinator.py` — MM-03 claim integration ONLY (ACTIVE-assignment lookup, ceiling refusal, `model_assignment` snapshot pin)
- `video-factory-g3/api/server.py` — MM-03 registry routes ONLY (policies/assignments/models/health reads; OPERATOR-only promote/rollback)
- `video-factory-g3/contracts/api_contract.json` — contract 1.8.0 (+8 MM-03 endpoints)
- `video-factory-g3/tests/test_api_contract.py` — exercise the 8 new endpoints (the contract test asserts full endpoint coverage; recorded in mm-gate-03/evidence/CHANGED_ASSERTIONS.md)
- `video-factory-master-programme/mm-gate-03/**` — lock, seeder tool, tests, evidence

No registry-definition, plan, workflow, worker/evaluation/runtime-service,
or dashboard changes. `provider_configs` remains the executable binding
store — promotion is the only registry→binding write path. No real
provider call; no credential exists or is requested (MM-12 owns that).

## Migration namespace ownership

- Authoritative applied chain: `video-factory-g1/database/migrations/001_*`
  (registry DB) and `video-factory-g2/database/migrations/002_*` … `013_*`
  (runtime DB; applied by `video-factory-g2/tools/setup_db.py`;
  `video-factory-g3/tools/setup_db.py` wraps it). Numbers are global across
  the two directories — never reuse a number.
- **Next free migration number: 014.** Owner: UNASSIGNED. The next gate
  whose lock authorizes a migration claims 014 here before writing the file.
- `video-factory-real-ai-programme/gate-b/migrations-draft/006–009` are
  historical drafts (their content was applied as the real 006–009 in
  Gate C) — not a live namespace; do not apply from the draft directory.

## Unassigned gates

Gates 01, 03, 04, 05, 06, 07, 08, 09, 10, 11, 12, 13, 14: no file ownership
granted. Gate 01 (architecture audit) is read-only by its own guardrail and
needs no write ownership outside its own gate directory when locked.

## Standing rules

1. Record ownership here **before** editing; include the lock that authorizes it.
2. A file with an owner is read-only to everyone else — including "small fixes".
3. Regenerated files (workflows) belong to whoever owns their generator.
4. Runtime state is not source: scratch databases, `n8n-data/`, `store/`
   artifact stores, `.venv/`, `__pycache__/` carry no ownership.
5. On release, the owner records the gate evidence path that pins the new
   baseline for the released files.

## MM-04 gateway seam — owned files (Multi-Model Gate 04, provider gateway)

| Scope | Owner | Authority | Since |
|---|---|---|---|
| **MM-04 gateway seam** (files below) | MM-04 builder | `video-factory-master-programme/mm-gate-04/LOCK_MM04.md` + MULTI_MODEL_EXECUTION_PROMPT.md Gate MM-04 | 2026-10-29 |

- `video-factory-real-ai-programme/gate-c/worker_service/gateway.py` — NEW: the provider gateway (context-limit check, bounded in-attempt retries, authorized fallback, correlation IDs, per-provider rate/concurrency limiter, cancellation checks, provider_health writes)
- `video-factory-real-ai-programme/gate-c/worker_service/adapters.py` — `_http_json` headers passthrough + error-body capture on ProviderError; adapters forward `_gateway_headers`
- `video-factory-real-ai-programme/gate-c/worker_service/service.py` — gateway wiring only (direct + submit/poll paths, per-request gateway context, result-payload passthrough)
- `video-factory-real-ai-programme/gate-c/worker_service/actions.py` — `op.generate_script` provider call routed through the gateway; provider evidence extended
- `video-factory-real-ai-programme/gate-c/worker_service/plan_exec.py` — ActionContext gateway pass-through; provider-evidence extension (incl. FAILED-record gateway summary)
- `video-factory-real-ai-programme/gate-c/worker_service/tests/test_gateway.py` — NEW: MM-04 gateway tests
- `video-factory-g2/coordinator/coordinator.py` — MM-04 surface ONLY: `CancelRefused` + `cancel_provider_job`; optional executed-model + correlation threading in complete_attempt/handle_callback
- `video-factory-g2/database/migrations/017_mm04_provider_job_cancel.sql` — NEW (additive): provider_jobs status CHECK widened with 'CANCELLED'. **Migration 017 claimed by MM-04**
- `video-factory-g2/tools/setup_db.py` — one added apply line for migration 017
- `video-factory-g3/api/server.py` — MM-04 routes ONLY: POST /provider-jobs/{job_id}/cancel; optional `correlation_id` (callback) + `model` (complete) passthrough
- `video-factory-g3/contracts/api_contract.json` — contract 1.9.0 (+1 endpoint, +2 optional fields)
- `video-factory-g3/tests/test_api_contract.py` — exercise the cancel endpoint (contract coverage; recorded in mm-gate-04/evidence/CHANGED_ASSERTIONS.md)
- `video-factory-master-programme/mm-gate-04/**` — lock, battery harness, evidence

No registry-definition, plan, workflow, evaluation/runtime-service, or
dashboard changes. No real provider call; no credential exists or is
requested (MM-12 owns that). All provider contact is against local stubs.

## MM-05 n8n integration battery — owned files (Multi-Model Gate 05)

| Scope | Owner | Authority | Since |
|---|---|---|---|
| **MM-05 battery** (files below) | MM-05 builder | `video-factory-master-programme/mm-gate-05/LOCK_MM05.md` + MULTI_MODEL_EXECUTION_PROMPT.md Gate MM-05 | 2026-10-29 |

- `video-factory-master-programme/mm-gate-05/**` — lock, battery harness, stub, evidence. Integration battery only: NO product files are owned or edited under this lock unless the battery proves a defect; any such repair is claimed here by amendment before the edit, with the failing evidence attached, and recorded in mm-gate-05/evidence/CHANGED_ASSERTIONS.md.
- AMENDMENT 1 (D-MM05-01 repair, see mm-gate-05/LOCK_MM05.md): `video-factory-g{4,5,6,7,8}/tools/gen_workflows.py` — submit-candidate body only (forward the executed `model` to /complete, the F-P4P-02 pattern extended to the MM-04 field) + the regenerated `workflows/unit-executor.json` in each tree. Claimed by the MM-05 builder before the edit, on the M05-3 failing evidence.
- AMENDMENT 2 (D-MM05-01 second layer, see mm-gate-05/LOCK_MM05.md): `video-factory-real-ai-programme/gate-c/worker_service/service.py` — the provider-dispatch plan branch of `run_work` only (surface the plan summary's gateway fields as `result["gateway"]` so `_result_payload` emits the executed model on the /work response). Claimed by the MM-05 builder before the edit, on the M05-3 re-run evidence.

## MM-06 specialized providers seam — owned files (Multi-Model Gate 06)

| Scope | Owner | Authority | Since |
|---|---|---|---|
| **MM-06 providers seam** (files below) | MM-06 builder | `video-factory-master-programme/mm-gate-06/LOCK_MM06.md` + MULTI_MODEL_EXECUTION_PROMPT.md Gate MM-06 | 2026-10-29 |

- `video-factory-real-ai-programme/gate-c/worker_service/media_tools.py` — NEW: ffprobe probe + media validator (named failure reasons) + ffmpeg runner + flite speech synthesis + master-spec constants
- `video-factory-real-ai-programme/gate-c/worker_service/actions.py` — NEW media action implementations (`media.ffmpeg_process`, `media.ffmpeg_render`, `media.synthesize_speech`) + their ACTION_IMPLEMENTATIONS / INPUT_SPECS / OUTPUT_SPECS entries ONLY
- `video-factory-real-ai-programme/gate-c/worker_service/adapters.py` — NEW `FliteLocalAdapter` (local TTS via the ffmpeg flite source) + one registry entry ONLY
- `video-factory-real-ai-programme/gate-c/worker_service/payloads.py` — op 15.12 distribution-record simulation marking ONLY (`simulated: true`, mock provider name, per-receipt `status: "SIMULATED"`)
- `video-factory-real-ai-programme/gate-c/worker_service/action_implementations.json` — regenerated manifest (new implementation entries only; all existing entries byte-identical)
- `video-factory-real-ai-programme/gate-c/worker_service/tests/test_mm06_media.py` — NEW: MM-06 battery (validator, bound media plans, TTS, simulation labeling)
- `video-factory-g1/tools/generate_plans.py` — media core kinds (`media`/`render`) + the CLASS entries for 12.05, 12.06, 12.07, 12.08, 13.03, 13.05, 13.08, 14.06, 14.07, 14.08 ONLY
- `video-factory-g1/seed-definitions/workflow-1.0.0/plans.json` — regenerated (only the 10 media plans' bodies/hashes + plans_hash may change; the other 182 plans byte-identical, proven by diff)
- Incidental, only if a pinned shape/count changes and recorded in mm-gate-06/evidence/CHANGED_ASSERTIONS.md: the affected suites' test files (known at lock: worker `tests/test_worker_service.py` FULLY_BOUND count 69 → 79)
- `video-factory-master-programme/mm-gate-06/**` — lock, capability matrix, harness, evidence

No registry-definition, migration, coordinator, API-server, workflow,
evaluation/runtime-service, or dashboard changes. media.generate and
external.* plans stay UNBOUND (credential/owner-gated, registered in
the MM-06 capability matrix). No real provider call; no credential
exists or is requested (MM-12 owns that). All media execution is
local tooling (ffmpeg/ffprobe/flite) over synthesized test media,
labeled LOCAL_TOOL_EXECUTION.

## MM-07 quality + verification seam — owned files (Multi-Model Gate 07)

| Scope | Owner | Authority | Since |
|---|---|---|---|
| **MM-07 evaluation seam** (files below) | MM-07 builder | `video-factory-master-programme/mm-gate-07/LOCK_MM07.md` + MULTI_MODEL_EXECUTION_PROMPT.md Gate MM-07 | 2026-10-29 |

- `video-factory-real-ai-programme/gate-e/evaluation_service/layers.py` — three NEW deterministic technical-layer checks (`internal_reference_integrity`, `media_technical_validation`, `input_set_coverage`) + the Rule-of-Six QA-binding-param threshold ONLY; all existing layers/checks/rubrics byte-preserved in behavior
- `video-factory-real-ai-programme/gate-e/evaluation_service/context.py` — additive only: `fetch_bytes_by_sha` callable exposed in the evaluation context
- `video-factory-real-ai-programme/gate-e/evaluation_service/tests/test_mm07_checks.py` — NEW unit tests for the MM-07 checks
- `video-factory-master-programme/mm-gate-07/**` — lock, evaluation policy matrix (+ generator), negative-battery harness, evidence

No golden-case/arming, coordinator, API-server, workflow, worker-service,
plan, registry-definition, or dashboard changes. No migration. No real
provider call; no credential exists or is requested (MM-12 owns that).

## MM-08 financial controls seam — owned files (Multi-Model Gate 08)

| Scope | Owner | Authority | Since |
|---|---|---|---|
| **MM-08 financial seam** (files below) | MM-08 builder | `video-factory-master-programme/mm-gate-08/LOCK_MM08.md` + MULTI_MODEL_EXECUTION_PROMPT.md Gate MM-08 | 2026-10-29 |

- `video-factory-g2/database/migrations/018_mm08_financial_controls.sql` — NEW: `provider_spend_limits` table + `financial_evidence.charge_class` CHECK widened with 'UNRESOLVED' (migration-017 pattern)
- `video-factory-g2/tools/setup_db.py` — the 018 apply line ONLY
- `video-factory-g2/coordinator/coordinator.py` — provider-cap enforcement in the claim path (`ProviderCapExceeded` + committed `provider_cap_refused` audit; `scheduler_claim` skip), missing-usage detection + UNRESOLVED recording on both completion paths, `resolve_unresolved_charge`, `reconcile_once` unresolved-charges report ONLY; FINALIZED selection, pricing, settlement and all other behavior byte-preserved
- `video-factory-real-ai-programme/gate-f/runtime_services/reconciler_service.py` — pass the unresolved-charges report through the cycle output ONLY
- `video-factory-g3/api/server.py` — NEW route `POST /financial-evidence/{evidence_id}/resolve` (OPERATOR only) ONLY
- `video-factory-g3/contracts/api_contract.json` — contract 1.10.0: the resolve endpoint + auth-notes line ONLY
- `video-factory-g2/tests/test_mm08.py` — NEW permanent suite (caps, missing usage, resolution, reconciler report)
- `video-factory-g3/tests/test_mm08_api.py` — NEW permanent suite (resolve endpoint roles/semantics)
- Incidental, only if a pinned shape/count changes and recorded in mm-gate-08/evidence/CHANGED_ASSERTIONS.md: test files asserting the contract version / endpoint count or the reconciler cycle-output keys
- `video-factory-master-programme/mm-gate-08/**` — lock, harness, evidence

No registry-definition, plan, workflow, worker-service, evaluation-service,
dashboard, or transition changes. No real provider call; no credential exists
or is requested (MM-12 owns that). Estimates are never settled as measured.

## MM-09 dashboard + operator control seam — owned files (Multi-Model Gate 09)

| Scope | Owner | Authority | Since |
|---|---|---|---|
| **MM-09 dashboard seam** (files below) | MM-09 builder | `video-factory-master-programme/mm-gate-09/LOCK_MM09.md` + MULTI_MODEL_EXECUTION_PROMPT.md Gate MM-09 | 2026-10-29 |

- `video-factory-g3/api/server.py` — four additive READ-ONLY routes ONLY: `GET /benchmarks`, `GET /provider-spend`, `GET /productions/{pid}/evaluations`, `GET /evaluation-status` (pass-through of the Gate E service's own `/health`). No mutation route added or altered; no existing route behavior changed.
- `video-factory-g3/contracts/api_contract.json` — contract 1.11.0: the four read endpoints + auth-notes line ONLY
- `video-factory-g3/dashboard/index.html` — four new/extended views (Models, Finance extension, Quality, Approvals) + header role selector; existing views' behavior preserved
- `video-factory-g3/tests/test_mm09_dashboard.py` — NEW permanent suite (view/data vs SQL truth, actions via dashboard routes, secret scan)
- `video-factory-g3/tests/test_dashboard.py` — the VIEWS list gains the four new views ONLY (recorded in mm-gate-09/evidence/CHANGED_ASSERTIONS.md)
- Incidental, only if a pinned shape/count changes and recorded in mm-gate-09/evidence/CHANGED_ASSERTIONS.md: tests asserting the contract version / endpoint count
- `video-factory-master-programme/mm-gate-09/**` — lock, browser harness, evidence

No coordinator, migration, registry-definition, plan, workflow, worker-service,
or evaluation-service changes. The dashboard gains NO new coordinator powers:
every action goes through a pre-existing endpoint with its existing role
enforcement. No secret or credential_ref string is rendered. No real provider
call; no credential exists or is requested (MM-12 owns that).

## MM-10 full mock end-to-end acceptance seam — owned files (Multi-Model Gate 10)

| Scope | Owner | Authority | Since |
|---|---|---|---|
| **MM-10 mock-action + battery seam** (files below) | MM-10 builder | `video-factory-master-programme/mm-gate-10/LOCK_MM10.md` + MULTI_MODEL_EXECUTION_PROMPT.md Gate MM-10 | 2026-10-29 |

- `video-factory-real-ai-programme/gate-c/worker_service/actions.py` — four additive implementations ONLY (`mock.creative.generate`, `mock.media.generate`, `mock.external.platform`, `mock.external.provider`) + their INPUT_SPECS/OUTPUT_SPECS + registry entries. No existing implementation altered.
- `video-factory-real-ai-programme/gate-c/worker_service/action_implementations.json` — regenerated manifest (additive: 4 new entries; the 19 existing entries byte-identical).
- `video-factory-g1/tools/generate_plans.py` — the four mockable unbound core kinds (creative.generate, media.generate, external.platform, external.provider) become bound "simulate" cores; plan classification records simulated_mock. human.decision / semantic.evaluate cores untouched.
- `video-factory-g1/seed-definitions/workflow-1.0.0/plans.json` — regenerated via tools/generate_plans.py ONLY (pre-regeneration snapshot: mm-gate-10/evidence/plans_snapshot_pre_mm10.json per rule O-1). Exactly the 58 mockable plans change; the other 134 stay byte-identical.
- `video-factory-real-ai-programme/gate-c/worker_service/tests/test_mm10_mock_actions.py` — NEW permanent suite (dispatch discipline, simulated labeling, media bytes, receipts).
- `video-factory-real-ai-programme/gate-c/worker_service/tests/test_worker_service.py` — two pinned assertions ONLY (FULLY_BOUND count 79 -> 137; unbound-refusal subject op 08.05 -> 01.02), recorded in mm-gate-10/evidence/CHANGED_ASSERTIONS.md.
- `video-factory-master-programme/mm-gate-10/**` — lock, harness, evidence.

No coordinator, API, contract, migration, workflow-JSON, evaluation-service,
or dashboard changes. The mock implementations run ONLY under a pinned
'mock' binding and refuse (ActionRefused) under any other binding — no
simulated output can be produced under a real or deterministic label.
No real provider call; no credential exists or is requested (MM-12 owns that).
