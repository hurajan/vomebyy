# GATE MM-00 — AUTHORITATIVE BASELINE REPORT

**Auditor:** MM-00 baseline auditor (independent, read-only on product code)
**Date:** 2026-10-29 (capture 14:31Z; regression 14:40:16–14:50:22Z)
**Verdict: PASS recommended** — baseline independently reproduced with **zero unexplained changes and zero destructive changes**.

Evidence: [manifest.json](evidence/manifest.json) · [attribution.json](evidence/attribution.json) · [inventory.json](evidence/inventory.json) · [regression_results.json](evidence/regression_results.json) · [regression logs](evidence/regression/)

---

## 1. File baseline

Fresh manifest captured over the identical scope and pruning rules as the first-series Gate 00 manifest (aggregate method verified first: re-aggregating Gate 00's own per-file hashes reproduces its recorded aggregate `78cd4744…` exactly).

| | Files | Aggregate SHA-256 |
|---|---|---|
| Gate 00 baseline (2026-10-29T03:24Z) | 1,535 | `78cd4744b158799d6248c1b5047406180bc8480f67d21ecd8d04ee7a0c129b3c` |
| MM-00 capture (2026-10-29T14:31Z) | 3,115 | `3358af775f173783279887d522b0e9fea445e501e879628b5035834fa640c9b2` |

Diff: **1,471 unchanged · 64 changed · 1,580 added · 0 removed.** Every changed and added file is attributed (detail in `attribution.json`):

- **Changed (64):** Gate 02 seam finalization (36 files were `IN_FLUX` at capture) · Gate 02 documented extras (5, per the Gate 03 verifier's verbatim classification) · Gate 03 Option B test/coordinator updates · Gate 04 build window (mtime cluster 04:48–04:58Z + in-file Gate 04 markers: `registry_tool.py`, worker `adapters.py`/`payloads.py`/`service.py`, `setup_db.py`, `setup_fullrun.py`, `setup_env.py` ×5) · Gate 05 authority build (`server.py`, contract 1.7.0, error-handler regeneration) · Lean Phase 3 (`envelope.py` — the exact +1 reconciling the Gate 05 verifier's 63 to today's 64) · F-P4P re-touch of already-changed generator/workflow files only · runtime state (`dispatch-state.json` ×5, `fullrun_gates.json`) · controller's STATE.md.
- **Added (1,580):** 1,165 storage-service `.store` runtime blobs (content-addressed, immutable; Gate 00 already held 962, all still present) · 359 programme gate records (Gates 01/03/04/05 + Lean phases' own locks/evidence) · 41 Gate 02 evidence/harness files · 13 product source additions (migrations 014/015, `plans.json` + generator, Gate 04 plan machinery, Gate 04/05 + Phase 3 test files) · 2 owner-directive records.
- **Unexplained changes: NONE. Removed files: NONE.** Protected paths are byte-identical: registry seed, all step contracts, 18 deliverable schemas, migrations 001–013.

Three independent scope audits now chain consistently over this manifest lineage: Gate 03 verifier 51 changed (all classified) → Gate 05 verifier 63 (all attributable) → MM-00 64 (all attributed).

## 2. Regression reproduction

Full serial regression on the canonical commands (`evidence/run_regression.sh`; logs in `evidence/regression/`):

| Suite | G1 | G2 | G3 | G4 | G5 | G6 | G7 | G8 | G9 | Worker | Storage | Evaluation | Runtime | **Total** |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Ran/OK | 9 | 81 | 36 | 2 | 1 | 3 | 2 | 1 | 10 | 40 | 5 | 25 | 10 | **225/225** |

Every suite rc=0, verdict OK — **exactly** the latest known totals. **T02-H harness re-run: PASS 12/12.** Live DB check of the full run my own battery produced: 18 units / 18 ACCEPTED / max 1 attempt per unit / 54 action records / FINALIZED 1620¢ (basis `reported_actual`) / HG2+HG4+HG5 APPROVED / 12.12 executed under `n8n-executor-g7`. Lean fix battery recorded state (P4P-1..5 PASS, stub-tested) corroborated by this reproduction.

**Environment event (not a product defect):** this VM had been replaced — PostgreSQL was entirely absent at audit start (no packages, cluster, user, or cached debs). Restored via apt to **exactly** the baseline version (16.15, Ubuntu 16.15-0ubuntu0.24.04.1); the setup chain then rebuilt every scratch DB. Versions: PostgreSQL 16.15 · Node v24.22.1 · n8n 2.45.5 · Python 3.12.3.

**Post-battery footprint:** re-hashing after all MM-00 test runs shows changes confined to runtime state (8 files: dispatch states, full-run evidence, the T02-H harness's own rerun records) + 94 new `.store` blobs; **zero source files altered, zero removed** — the captured baseline is the source baseline.

## 3. Baseline anchors (for the register)

- Registry **definition_hash `ea4503f5…`** (validate PASS, 0 errors) · **plans_hash `a71d77c6…`** (plans-validate PASS) · **08.12 plan hash `244c5fcc…`** (`plan/1.0.0/08.12`, seq2 = `op.generate_script`)
- API contract **1.7.0 / 37 endpoints** (read from the contract file; Gate 05's semantics bump over Gate 04's 1.6.0)
- Migrations: max **015** (registry 001; runtime 002–015); next free 016
- TRANSITIONS: exactly **30** entries / 19 event names (imported and counted)
- Setup chain: g1 loader → g2 `setup_db.py` (migrations + load-plans with hash assertion) → g3 wrapper → per-tree `setup_env.py` → g9 `setup_fullrun.py`
- Ports: PostgreSQL 5432 · API 8730 · n8n 5678 · worker 8795 · evaluation 8796

## 4. Component classification

### COMPLETED (verified from source/live in this audit)
- **Six station workflow sets + shared executors** — 26 workflow JSONs; ids/names identical to the Gate 00 inventory; per-tree constant executor identities; span guards; Gate 03-B routing in code (`_EXECUTOR_STEP_RANGES`: 12–14 → g7).
- **16 steps / 192 operation definitions / 191 dependency templates** — registry validate PASS; stations 24/24/48/36/36/24; 32 step contracts + 18 deliverable schemas present.
- **Coordinator authority controls** — 5 roles, per-endpoint matrix, Gate 05 `EVENT_MATRIX` (human_approved OPERATOR-only), completion barrier, action-record identity binding, atomic adoption (migration 014 columns live), scheduler pre-staging, gate-claim enforcement.
- **Human gates HG2/HG4/HG5** — seeded by migrations 003/004/005 (`script→HG2`, `master_package→HG4`, `derivative_package→HG5`); all three APPROVED on this audit's live full run.
- **PostgreSQL schema + migrations 001–015** — chain applies cleanly from scratch (the whole regression ran on chain-built DBs).
- **Financial ledger machinery** — ESTIMATED/CALCULATED/PROVIDER_REPORTED/FINALIZED classes; FINALIZED selection with tolerance; `settle_provider_charge` exactly-once; basis recorded per row.
- **192 versioned execution plans as data** — claim-time pinning; plans-validate PASS; 69 FULLY_BOUND.
- **08.12 provider integration (preparation)** — provider-backed generation inside plan_exec, binding-dispatched, anti-fallback refusal proven (Phase 3 verification).
- **09.12 downstream consumer** — consumes the script ref into `direction_package`; HG2-gated claim.
- **n8n dispatch/executor/adoption/error/recovery flows** — all exercised green by the station suites, T02-H, and the G9 full run in this audit.
- **F-P4P executor repairs** — refs assembly + usage/provider-request forwarding live in all five trees' executors (fix battery PASS, confinement-proven).

### INCOMPLETE (present, partial by design/record)
- **Genuine completion levels:** L1 192 · **genuine L2 = 69** (19 SPECIFIC + 50 deterministic plan-bound) · **L3 = 20** · **L4 = 0** (Gate 01 classification as amended by Gates 03/04).
- **123 plans partially unbound** — each with exactly one UNBOUND action: creative.generate 43 · human.decision 28 · semantic.evaluate 27 · external.platform 9 · media.process 9 · media.generate 4 · external.provider 2 · media.render 1 (recounted live by plans-validate in this audit).
- **Semantic evaluation:** exactly 2 implemented rubrics (`08.12 script_canon_coverage`, `12.12 rule_of_six`) against 44 named validator checks (G01-D05 stands); real LLM judging deliberately unreachable.
- **Production identity:** approval-policy owner-decision class (144 ops) is **AWAITING_OWNER** — the five shared role tokens cannot express named approvers; no identity table exists in any migration (Gate 05 map, verified).
- **Multi-version plan storage: absent** — one stored plan body per operation at version 1.0.0; a body change replaces it (old pins fail closed with PLAN_PIN_MISMATCH; recorded minor observation for MM-14).
- **Capability registry proper:** 29 seed records all PROPOSED; loader-populated rollup tables are not read by any runtime code (grep-verified) — the operative binding layer is the Gate 04 plans, not the capability tables (G01-D02 core stands).
- **QA-binding interaction:** evaluation QA resolution (CAPABILITY → OPERATION → FACTORY, `evaluation_service/context.py:106`) resolves a provider-bound operation's work binding, so the semantic layer refuses and the unit lands AWAITING_HUMAN; the canon-coverage rubric does not run service-side on the provider path. Safe direction; QA/work binding separation is an open owner-visible decision.

### UNTESTED
- **Real-browser dashboard rendering** — NOT TESTED (standing since G3; dashboard source has 12 view sections; all verification is API/contract-level).
- **S3 storage** — stub-tested only; the running stack is LocalStorage (`.store` content-addressed). Real object storage NOT TESTED.
- **Real-provider execution** — never run: no credential exists; every provider-path result on record is STUB_TESTED or deterministic.
- **OVHcloud deployment** — nothing deployed; no container artifacts exist in the factory trees.

### MISSING
- **Golden-set EXPERT cases: 0** (7 SEED on disk, provenance-counted in this audit) — arming threshold 50 EXPERT (`golden.py: ARM_THRESHOLD = 50`) unmet; human approval carries acceptance.
- **Redis: absent** (n8n runs on SQLite locally) — MM-11 will have to introduce or waive it.
- **Remotion: absent** — no references anywhere in scope; no Dockerfile/compose deployment packaging exists in the factory trees.
- **Provider credentials: none present** (environment inventory re-verified) — by MM Rule 11 none is requested before MM-12.

### CONFLICTING
- **None in product state.** Two documentation-level notes: (1) STATE.md's Gate 04 row still cites contract 1.6.0 — the contract file itself is 1.7.0 post-Gate-05 (anchor corrected above, from source); (2) the Gate 00 pruning rule names `store` directories but the storage service's runtime dir is `.store`, so runtime blobs are (and were) inside manifest scope — harmless (they are immutable and classed as runtime data), recorded here so MM-14's evidence lock can prune deliberately if desired.

## 5. Known limitations carried into MM-01+

G0.6 SSH host identity unconfirmed (MM-11 expected BLOCKED_EXTERNAL; host not probed). OD-A1 (Git) still open — baselines remain manifest-pinned. BOUND-BUT-THIN bindings (09.01, 15.03, 15.05) stand as Gate 04 calibration notes. Gate 05 observations O1 (library-path barrier exemption) and O2 (some /actions forgery classes refuse without an audit row) carried. The `unit_dependencies` read surface remains a recorded precondition before branched generation (Lean Phases 10/11 lineage → MM-05/MM-10 scope).

**PASS condition assessment:** the baseline is independently reproduced (fresh manifest + full 225-test regression + T02-H + live full-run DB state), with **zero unexplained changes and zero destructive changes**. MM-00 is recommended **PASSED**.
