#!/usr/bin/env python3
"""MM-00 fresh source manifest, replicating the Gate 00 (first series) format.

Scope: identical roots and pruning rules as gate-00/evidence/source_manifest.json
so the diff is exact. Self-referential programme gate dirs (gate-00/, mm-gate-00/)
are excluded, mirroring Gate 00's own exclusion of its outputs.
"""
import hashlib, json, os, sys
from datetime import datetime, timezone

WS = "/home/hatch/workspace"
ROOTS = [f"video-factory-g{i}" for i in range(1, 10)] + [
    "video-factory-real-ai-programme",
    "video-factory-master-programme",
]
PRUNE_NAMES = {".venv", "__pycache__", "node_modules", "n8n-data", "store", ".git"}
SKIP_PREFIXES = (
    "video-factory-master-programme/gate-00/",
    "video-factory-master-programme/mm-gate-00/",
)

def aggregate(files):
    h = hashlib.sha256()
    for f in sorted(files, key=lambda x: x["path"]):
        h.update(f"{f['sha256']}  {f['path']}\n".encode("utf-8"))
    return h.hexdigest()

def main():
    # 1. Verify the documented aggregate method reproduces Gate 00's own aggregate
    old = json.load(open(f"{WS}/video-factory-master-programme/gate-00/evidence/source_manifest.json"))
    repro = aggregate(old["files"])
    method_ok = repro == old["aggregate_sha256"]
    print(f"method check: reproduced={repro} recorded={old['aggregate_sha256']} match={method_ok}")
    if not method_ok:
        print("FATAL: aggregate method does not reproduce Gate 00 manifest; aborting")
        sys.exit(1)

    files, pruned = [], []
    for root in ROOTS:
        base = os.path.join(WS, root)
        for dirpath, dirnames, filenames in os.walk(base):
            rel_dir = os.path.relpath(dirpath, WS)
            keep = []
            for d in dirnames:
                rel = f"{rel_dir}/{d}" if rel_dir != "." else d
                if d in PRUNE_NAMES:
                    pruned.append(rel)
                else:
                    keep.append(d)
            dirnames[:] = keep
            for name in filenames:
                rel = f"{rel_dir}/{name}" if rel_dir != "." else name
                if rel.startswith(SKIP_PREFIXES):
                    continue
                if name.endswith((".pyc", ".pyo")):
                    continue
                full = os.path.join(dirpath, name)
                try:
                    data = open(full, "rb").read()
                except OSError as e:
                    print(f"WARN unreadable {rel}: {e}")
                    continue
                st = os.stat(full)
                files.append({
                    "path": rel,
                    "bytes": len(data),
                    "sha256": hashlib.sha256(data).hexdigest(),
                    "mtime_utc": datetime.fromtimestamp(st.st_mtime, timezone.utc).isoformat(),
                    "part": "stable",
                    "modified_in_fix_window": False,
                })
    files.sort(key=lambda x: x["path"])
    agg = aggregate(files)
    out = {
        "schema": "gate-00-source-manifest-v1",
        "capture_context": "MM-00 baseline audit (multi-model programme); same scope/rules as Gate 00 first-series capture; no in-flight seam at capture (all files 'stable')",
        "captured_utc": datetime.now(timezone.utc).isoformat(),
        "seam_snapshot_utc": None,
        "aggregate_method": "sha256 over utf-8 lines '<sha256>  <path>\\n', entries sorted by path",
        "file_count": len(files),
        "total_bytes": sum(f["bytes"] for f in files),
        "aggregate_sha256": agg,
        "stable_file_count": len(files),
        "stable_aggregate_sha256": agg,
        "seam_file_count": 0,
        "seam_aggregate_sha256": hashlib.sha256(b"").hexdigest(),
        "exclusions": {
            "pruned_directories": sorted(set(pruned)),
            "rules": [
                "any directory named .venv, __pycache__, node_modules, n8n-data, store (runtime artifact stores), .git",
                "files ending .pyc/.pyo",
                "video-factory-g7-prep/ (prep scratch tree, not part of the integrated baseline)",
                "video-factory-master-programme/gate-00/ and video-factory-master-programme/mm-gate-00/ (programme gates' own outputs — self-referential)",
            ],
        },
        "files": files,
    }
    dest = f"{WS}/video-factory-master-programme/mm-gate-00/evidence/manifest.json"
    os.makedirs(os.path.dirname(dest), exist_ok=True)
    json.dump(out, open(dest, "w"), indent=1)
    print(f"wrote {dest}: {len(files)} files, {out['total_bytes']} bytes, aggregate {agg}")

if __name__ == "__main__":
    main()
