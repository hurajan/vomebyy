# GATE MM-00 — INDEPENDENT SPOT-VERIFICATION REPORT

**Verifier:** independent spot-verifier (own scratch runs; read-only on product code)
**Date:** 2026-10-29
**Subject:** [BASELINE_REPORT.md](../BASELINE_REPORT.md) + evidence (manifest.json, attribution.json, inventory.json, regression_results.json)
**Verdict: MM-00 PASSED** — the baseline is independently reproduced with zero unexplained destructive changes. All four spot-verification items PASS; defects NONE.

---

## 1. Manifest integrity — PASS

- **Aggregate recomputed independently** from manifest.json's per-file hashes using the documented method (SHA-256 over UTF-8 lines `<sha256>  <path>\n`, entries sorted by path): **3358af775f173783279887d522b0e9fea445e501e879628b5035834fa640c9b2** — exactly the reported aggregate. `file_count` field 3115 == actual entries 3115.
- **Method control:** the same method applied to the first-series Gate 00 manifest reproduces its recorded aggregate `78cd4744b158799d6248c1b5047406180bc8480f67d21ecd8d04ee7a0c129b3c` exactly, so the two captures are commensurable.
- **Diff arithmetic independently recomputed** (path→hash comparison of the two manifests, not taken from attribution.json): **1,471 unchanged + 64 changed + 1,580 added = 3,115 total; 0 removed** — matches the report and attribution.json's own totals (its `unexplained_changed` / `unexplained_added` / `removed_files` are all empty).
- **Protected-path spot check (10 files):** current on-disk bytes hashed and compared against *both* the Gate 00 and MM-00 per-file hashes — all 10 identical in all three:
  registry seed `operations.json`; deliverable schemas step-08, step-12, op-14.01; migrations 002, 005, 007, 013; step contracts step-08/output, step-01/output.

## 2. Anchors from source — PASS (all read directly, not from the report)

| Anchor | From source | Report claim |
|---|---|---|
| API contract | `g3/contracts/api_contract.json`: `contract_version` **1.7.0**, endpoints list length **37** | 1.7.0 / 37 ✓ |
| TRANSITIONS | imported from `g2/coordinator/coordinator.py`: **30** entries, **19** distinct event names | 30 / 19 ✓ |
| Migrations on disk | g1 `001`; g2 `002–015` — max **015**, none beyond | max 015 ✓ |
| definition_hash | `registry_tool.py validate` → **ea4503f516fc4f7940f187f5cd9dac38c57f0d239726cac90e2d0a18a8bc9d73**, verdict PASS, 0 errors | ea4503f5… ✓ |
| plans_hash | `plans-validate` PASS; plans.json field **a71d77c66da556f499646eab8fc2c04a5031a944ce4e2ed81723cd66aff3115e** | a71d77c6… ✓ |
| 08.12 plan | `plan/1.0.0/08.12`, plan_hash **244c5fcc0854700872552e8c3b5b7904bd4df1c2c071223bbc040a982e0cf8fa**; seq 2 implementation = `op.generate_script` | 244c5fcc… ✓ |

## 3. Regression spot — PASS (my own serial runs, logs read directly)

Leftover services from the prior battery were stopped by port before the G9 run so the suite's own setup bound its own stack (n8n shared instance left running, as established).

- **G2 suite:** Ran **81** tests — **OK** (rc=0).
- **Worker service suite:** Ran **40** tests — **OK** (rc=0).
- **G9 suite** (after `setup_fullrun.py`): Ran **10** tests — **OK** (rc=0).
- **Full-run production, checked in the DB my own battery produced** (`g9_fullrun_scratch`, production ae03e1ae…): **18 units / 18 ACCEPTED / max 1 attempt per unit**; FINALIZED evidence **18 rows totalling 1620¢**, basis `reported_actual` (present in the rows' usage payload as `_finalization_basis`, matching the coordinator's finalization code); gates **HG2/HG4/HG5 all APPROVED**; operation **12.12 executed under `n8n-executor-g7`**. The other 18-unit productions in the DB are the §18 upgrade-rehearsal pins (0 accepted), as designed.

## 4. Classification spot-checks — PASS (recounted from source data)

- **Partially-unbound plans, recounted directly from plans.json** (actions with `binding_status == "UNBOUND"`, grouped by `declared_implementation`): creative.generate **43**, human.decision **28**, semantic.evaluate **27**, external.platform **9**, media.process **9**, media.generate **4**, external.provider **2**, media.render **1** — total **123**, every partially-unbound plan carrying exactly one UNBOUND action (0 multi-unbound), and **69 fully bound** — all exactly as reported.
- **Golden set on disk** (`gate-e/evaluation_service/golden_cases/`): 7 case files, provenance field counted per file: **7 SEED / 0 EXPERT**. `golden.py` arming threshold confirmed in source: `ARM_THRESHOLD = 50` (EXPERT only).

## Notes

- No discrepancies found in any spot-checked number. Nothing in this verification upgrades any status beyond MM-00 itself: genuine L4 remains 0, real-provider execution remains untested/never run, and the report's INCOMPLETE/UNTESTED/MISSING items (production identity AWAITING_OWNER, S3 stub-tested only, real-browser dashboard NOT TESTED, 0 EXPERT cases, G0.6) were not contradicted by anything observed.
- Verifier environment left clean: my API/worker/evaluation processes stopped; scratch logs retained at /tmp/mm00v/ (g2.log, worker.log, g9.log, g9_setup.log).
