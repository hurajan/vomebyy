# MM-07 — INDEPENDENT VERIFIER REPORT

**Gate:** MM-07 (Quality + Independent Verification), Multi-Model programme
**Verifier:** independent agent (not the builder)
**Date:** 2026-10-29
**Verdict: PASS** — against the gate criterion *"negative tests prove
defective outputs cannot bypass mandatory acceptance gates."*
**Defects found: NONE** in product code.

All verification ran on the verifier's own stack and fixtures: scratch
DB `mm07_verify_scratch` (chain-built, dropped after use), API port
8766 / evaluation port 8967, verifier-owned tokens, and fixture content
distinct from the builder's battery (different characters, line ids
A1–A3/A77, scenes SN1/SN2, beats BT1/BT2, story nodes ND1/ND2, coverage
33.33%, Rule-of-Six 3.0 vs threshold 8.0). Every terminal unit state
below was read by raw SQL from `execution_units` /
`quality_evaluations` / `audit_events`, never from a service response
alone. Evidence: `evidence/verify/` (harness `verify_battery.py`,
`verify_probes.py`, `verify_matrix.py`, regression drivers, per-case
JSONs in `verify/results/`, logs in `verify/logs/`).

---

## 1. Negative battery reproduction — PASS (12/12, exceeding the 8-case minimum)

| Case | Verifier-observed (DB) | Verdict |
|---|---|---|
| N1 schema-violating script (no `trace`) | schema_validation FAIL; unit **BLOCKED** | PASS |
| N2 canon coverage 1/3 lines (33.33% < 100%) | semantic `RUBRIC_FAIL` ("canon_ref coverage 33.33% < threshold 100%"); unit **REPAIR_REQUIRED** | PASS |
| N3 Rule-of-Six 3.0 < policy threshold 8.0 | semantic `RUBRIC_FAIL` ("weighted total 3.0 below threshold 8.0"); unit REPAIR_REQUIRED | PASS |
| N4 durable store bytes tampered post-registration | `sha256_match` ok=false (recorded 8965b063… ≠ recomputed e6b7062d…); technical FAIL; unit **BLOCKED** | PASS |
| N5 planned input superseded before evaluation | continuity FAIL naming the superseded artifact id; unit **REPAIR_REQUIRED** | PASS |
| N6 worker self-report PASS, evaluation never called | unit remains **VALIDATING** (worker verdict advisory) | PASS |
| N7 WORKER token posts forged VALIDATOR verdict to `/validate` | HTTP **403**; **zero** `quality_evaluations` rows; unit VALIDATING | PASS |
| N8 HG4 REJECTED on master_package | downstream claim **409** + ≥1 committed `gate_claim_refused` audit; **zero** attempts | PASS |
| N9 mpeg4 media at 13.03 render exit | `media_technical_validation` FAIL, failures=[`VIDEO_CODEC_MISMATCH`]; unit **BLOCKED**; h264 control: media ok, unit AWAITING_HUMAN | PASS |
| N10 payoff → nonexistent line A77 | `internal_reference_integrity` FAIL, dangling={A77}; unit **BLOCKED** | PASS |
| N11 script leaves scene SN2 uncovered (schema-valid script) | schema PASS but `input_set_coverage` FAIL, uncovered=[SN2]; unit **BLOCKED** | PASS |
| N12 EVALUATION binding uncredentialed | semantic REVIEW_REQUIRED, reason `credential_absent`; unit **AWAITING_HUMAN** — not accepted, not rejected | PASS |

No defective output reached ACCEPTED in any case. The only landings
other than BLOCKED were REPAIR_REQUIRED (defective content held for
repair), VALIDATING (no evaluation performed), and AWAITING_HUMAN
(mandatory human path) — none of which is an acceptance.

## 2. New checks, unit level — PASS

- Evaluation suite re-run standalone: **46 tests, OK** (25 baseline +
  21 MM-07 additions; no existing test modified, per CHANGED_ASSERTIONS).
- Verifier's own synthetic-context probes (`verify_probes.py`, 6/6):
  - reference-integrity PASS: 09.12 directions LX-1/LX-2 resolve
    against the input script;
  - reference-integrity FAIL: line_ref `LX-404` → check ok=false,
    dangling entry names `LX-404` with its JSON path, layer verdict FAIL;
  - coverage PASS: 07.12 scenes cover every beat_graph beat;
  - coverage FAIL: scene_set omitting BT2 → uncovered=[BT2], verdict FAIL
    (a different coverage pairing than the builder's script/scenes tests);
  - media PASS: raw h264 1280×720 at 13.03, failures=[];
  - media FAIL: `media_output` WAV at 22050 Hz (op 12.05) → failures
    name `SAMPLE_RATE_MISMATCH` (a reason code the builder's tests did
    not exercise), verdict FAIL.

## 3. Policy matrix spot-check — PASS (29/29 assertions; 10 operations, all six stations)

Spot operations: 01.05 (S1), 03.07 + 04.03 (S2), 08.12 + 06.12 (S3),
11.06 (S4), 12.06 + 13.03 + 14.01 (S5), 16.05 (S6).

- **named_checks trace:** for all 10 spot ops — and, mechanically, for
  all 192 rows — the matrix's `named_checks` equal the mm-gate-01
  classification's registry `validator_policy` minus the two base
  policies. Approval policies and station assignments also match.
- **Deliverable schemas** exist exactly where the matrix's
  deterministic base claims them (step exits + op-14.01).
- **RUBRIC cells are exactly the two implemented rubrics**
  {(08.12, source_canon_fidelity), (12.12, editorial_quality)}, matching
  `layers.RUBRICS = {"12.12": rule_of_six, "08.12": script_canon_coverage}`.
  Matrix coverage-op list == `layers._COVERAGE_RULES` == {06.12, 07.12, 08.12}.
- **Human gates trace** to the gate-requirements seed migrations
  (script→HG2, master_package→HG4, derivative_package→HG5), and each
  spot row's `human_gate` names its gate.
- **NOT_IMPLEMENTED cells are exactly the 24 declared gap cells**
  (12× step-11 `audio_video_alignment` + 12× step-12
  `narration_fidelity`), each basis naming its gap. Absence greps over
  the whole evaluation service confirm both gaps are genuine: no
  AV-alignment measurement and no narration-vs-script comparison is
  implemented anywhere in the service.
- **MODEL_EVAL honesty:** all 297 MOD cells describe a named-check
  route; the matrix posture and the code agree that semantic named
  checks without an implemented rubric return REVIEW_REQUIRED
  (`NO_RUBRIC`), and credential-absent bindings also return
  REVIEW_REQUIRED — **no cell claims MODEL_EVAL as operational today.**
- Recomputed kind counts from the rows equal the declared counts
  exactly (DET 7, RUB 2, MED 22, MOD 297, HUM 34, GAP 24); every N/A
  cell carries a modality/stage basis.
- One initial FAIL in this section was a bug in the verifier's own
  extraction regex (truncated dict parse), corrected and re-run clean
  at 29/29; disclosed here, no matrix or product implication.

## 4. Regression — PASS (one clean serial pass, 13/13, 291 tests; g4 ×3)

Driver discipline: ports 8730/8795/8796 killed between **every** suite;
before each station suite's tests, the process listening on 8730 was
read from `/proc/<pid>/environ` and its `FACTORY_DSN` asserted equal to
that suite's own scratch DB (all six station suites passed the guard).

| Suite | Tests | Result |
|---|---|---|
| g1 | 9 | OK |
| g2 | 81 | OK |
| g3 | 36 | OK |
| g4 | 2 | OK (36.3s) |
| g5 | 1 | OK |
| g6 | 3 | OK |
| g7 | 2 | OK |
| g8 | 1 | OK |
| g9 | 10 | OK — persisted DB independently confirms: production "G9 full run" = 18 units, 18 ACCEPTED, 18 CHARGE transactions totalling **1620¢** |
| worker | 85 | OK |
| storage | 5 | OK |
| evaluation | 46 | OK |
| runtime | 10 | OK |
| **Total** | **291** | **13/13 rc=0** |

**g4 split-brain question retired:** in addition to the main pass, the
g4 suite was run twice more back-to-back under the same hygiene
(`g4_repeat1`, `g4_repeat2`): both rc=0, 2/2 OK in ~36s, each with the
API proven bound to `g4_station_scratch`. The builder's run-1 failure
does **not** reproduce under a coherent stack, corroborating the
builder's environmental root-cause account in
`REGRESSION_FINAL.txt` / CHANGED_ASSERTIONS (a surviving foreign API
on the shared port 8730 + a fresh evaluation service on a different
DB). The builder's two-run accounting (12/13 + g4 rerun) is accepted
as honestly recorded; the verifier's single clean 13/13 pass
supersedes it as the gate's regression evidence.

Verifier-side incidents (both in the verifier's own driver, both
corrected and re-evidenced; neither touches product code or the
builder's evidence): (i) the first double-run attempt derived tree
paths from suite tags g4b/g4c and cd-failed before any test ran —
rerun correctly as `g4_repeat1/2`; (ii) the first G9 DB probe grouped
ambiguous productions and mis-guessed two table names — the corrected
probe above reads the named full-run production directly.

## Standing observations (not defects against this gate)

- **OBS-1 (pre-existing, out of MM-07 scope):** the station-suite
  harness fragility the builder recorded is real — setups health-check
  and reuse any API answering on shared port 8730 regardless of its
  bound DB. It caused the builder's run-1 g4 failure and would have
  silently cross-wired this verification without the DSN guard. A
  programme-level harness fix (per-suite ports, or a setup-time
  DSN/health assertion) is recommended; it belongs to no single gate's
  ownership surface.
- **OBS-2:** the two NOT_IMPLEMENTED gap classes (AV alignment at
  step 11, narration-vs-script fidelity at step 12) remain open by
  design. Outputs in those dimensions route through MODEL_EVAL /
  human paths that park at AWAITING_HUMAN, so the gaps weaken
  *automation coverage*, not the acceptance barrier this gate tests.
  They stay on the register for MM-10/MM-13 scope decisions.
- **OBS-3:** consistent with the lock, no factory-wide Rule-of-Six
  score bar exists; the threshold fires only where a QA binding sets
  `rule_of_six_min_weighted_total` (N3 used the battery's own binding
  param). No threshold was invented, and none is claimed.

## Verdict

**MM-07: PASS.** The evaluation policy matrix is complete (192 × 12),
source-traced, and honest about what is not implemented; the three new
deterministic checks (internal reference integrity, input-set coverage,
media technical validation) plus the policy-gated Rule-of-Six threshold
behave as specified at unit level and end-to-end; and the 12-case
negative battery — independently reproduced with database-asserted
terminal states — proves defective outputs cannot bypass mandatory
acceptance gates. Full serial regression: 291/291, one clean pass,
including the G9 full run at 18 ACCEPTED / 1620¢. Defects: **NONE**.
