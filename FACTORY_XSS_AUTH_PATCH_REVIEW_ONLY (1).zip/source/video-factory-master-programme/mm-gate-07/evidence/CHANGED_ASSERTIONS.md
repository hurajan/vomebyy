# MM-07 — Changed Assertions

## Product changes (all additive; no existing assertion was edited)

1. `gate-e/evaluation_service/layers.py`
   - `technical_layer` now appends three MM-07 checks after the
     existing op-specific checks (`internal_reference_integrity`,
     `input_set_coverage` — inside the JSON branch) and
     `media_technical_validation` (all artifacts). Existing checks,
     their names, and their evidence shapes are unchanged; evaluation
     records for non-media, non-id-graph deliverables gain no new
     entries (the new checks emit nothing when their shape is absent).
   - `_rubric_rule_of_six` gained an optional `min_weighted_total`
     parameter and reports `weighted_total` in its stats. With no QA
     binding param set (every pre-MM-07 binding), behavior is
     byte-for-byte the old rubric: the Gate E tests
     `test_rubric_pass_unarmed_awaits_human` /
     `test_rubric_fail_is_content_fail` pass unmodified.
2. `gate-e/evaluation_service/context.py` — additive: the evaluation
   context now also carries `fetch_bytes_by_sha` (the loader's
   content-addressed byte fetch). No existing key changed.

## Test-count movements (regression — see correction below)

- evaluation suite: 25 → **46** (+21 new tests in
  `tests/test_mm07_checks.py`: internal-reference 5, coverage 3,
  media 9, Rule-of-Six threshold 4). No existing evaluation test was
  modified.
- All other suites at their standing counts: g1 9, g2 81, g3 36,
  g4 2, g5 1, g6 3, g7 2, g8 1, g9 10 (full run 18 ACCEPTED / 1620¢,
  asserted inside the suite), worker 85, storage 5, runtime 10.
  Total **291** = 270 standing baseline (266 at MM-06 close + 4
  worker tests from the MM-06 D-1 fix) + 21 MM-07 additions.

## Regression correction (recorded 2026-10-29, after the run-1 summary
## was initially misread as all-green)

- Run 1 (serial, 13 suites): **12/13 rc=0; g4 rc=1** —
  `test_manifests_rights_and_idempotency` hit its 240 s drive timeout
  (2 units VALIDATING, 4 PENDING, 1 BLOCKED-by-design rights block).
  Full accounting: `evidence/logs/regression/REGRESSION_FINAL.txt`;
  run-1 summary preserved as `SUMMARY_run1.txt`; failing log `g4.log`.
- Root cause: **environmental, not an MM-07 product defect.** The
  station suites share API port 8730 and a suite's setup reuses any
  API that answers its health check; a previous suite's API process
  bound to a different scratch DB was still live, while g4's fresh
  evaluation service pointed at `g4_station_scratch` — evaluations
  could never land, so units parked in VALIDATING. Proven by process
  start times + `FACTORY_DSN` of the surviving API and by the
  reproduction run's units being found in `g9_fullrun_scratch`
  (created 19:12:16Z, matching the timeout state dict exactly). A
  coherent run of the same test earlier that day (18:05Z) met all 7
  targets with the MM-07 evaluation code live.
- Run 2: after killing ports 8730/8795/8796 and a fresh co-started
  stack (API `FACTORY_DSN=g4_station_scratch`), the g4 suite passes:
  **rc=0, 2 tests in 39.195 s** (`g4_rerun.log`).
- Final regression state: **13/13 suites green, 291 tests.** The
  harness fragility (cross-suite API reuse on a shared port) is a
  pre-existing station-suite property, recorded here for the
  programme; it is outside MM-07's ownership surface and no product
  or harness code was changed to address it in this gate.

## Battery construction notes (honesty record)

- N4 (tamper): the brief labels the expected failure "continuity
  FAIL". Mechanically the hash mismatch is caught by the technical
  layer's `sha256_match` check (same `dependency_integrity` policy
  family; deterministic → BLOCKED). The battery records the actual
  layer evidence; the PASS criterion (defective output cannot reach
  acceptance) is met by the stronger outcome.
- N5 (superseded planned input): the deliverable content deliberately
  does not reference the superseded artifact — a content reference to
  a superseded artifact is the separate technical-layer
  `references_resolve` failure (deterministic → BLOCKED). N5 isolates
  the continuity path exactly as Gate E's own continuity scenario
  does, and lands REPAIR_REQUIRED as specified.
- N3 (Rule-of-Six threshold): no factory-wide score threshold exists
  in any approved source, and none was invented. The bar used in N3
  (7.5) is evaluation-policy data — a QA-binding param
  (`rule_of_six_min_weighted_total`) on that battery case's own
  OPERATION binding, the same mechanism as 08.12's pre-existing
  `canon_ref_threshold_pct`. Without the param, the rubric's behavior
  is unchanged.
- Battery harness defects found and fixed during the run (harness
  only, no product impact): (i) cases initially shared one production
  — artifact supersession is per (production, artifact_type), so
  N5's canon registrations superseded the shared canon input of
  later cases; fixed with per-case productions + binding cleanup.
  (ii) N4 initially overwrote the staged candidate copy of the
  artifact bytes instead of the durable `objects/<sha>` object the
  evaluation service reads; fixed to tamper with the durable object.
