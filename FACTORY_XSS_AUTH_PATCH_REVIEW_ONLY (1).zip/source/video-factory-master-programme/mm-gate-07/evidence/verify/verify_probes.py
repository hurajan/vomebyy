"""MM-07 verifier unit-level probes for the three new checks.

Synthetic evaluation contexts (no DB) with the verifier's own ids and
fixtures — different pairings/reason codes from the builder's test
module where the implementation offers them:
  REF  pass: 09.12 direction lines all resolve against the input script
  REF  fail: direction line_ref 'LX-404' -> FAIL naming LX-404
  COV  pass: 07.12 scene_set covers every beat_graph beat
  COV  fail: 07.12 scene_set omits BT2 -> FAIL naming BT2
  MED  pass: raw h264 1280x720 at 13.03 -> media check ok
  MED  fail: media_output WAV at 22050 Hz (op 12.05) -> FAIL naming
             SAMPLE_RATE_MISMATCH
Exit 0 iff all six probes behave as expected.
"""
import hashlib
import json
import subprocess
import sys
import tempfile
from pathlib import Path

RP = Path.home() / "workspace/video-factory-real-ai-programme"
sys.path.insert(0, str(RP / "gate-e" / "evaluation_service"))
sys.path.insert(0, str(RP / "gate-c"))  # media_tools import surface
import layers  # noqa: E402

PID = "mm07v-probe-production"
CANON = "99999999-9999-4999-8999-999999999999"


def _sha(b):
    return hashlib.sha256(b).hexdigest()


def art(aid, atype, content=None, state="CURRENT"):
    row = {"artifact_id": aid, "artifact_type": atype, "version": 1,
           "state": state, "production_id": PID,
           "sha256": _sha(content) if content is not None else "0" * 64,
           "storage_uri": "mm07v://artifact"}
    if content is not None:
        row["content_bytes"] = content
    return row


def ctx(op, content, atype, inputs=(), extras=(), fetch=None):
    out = art("88888888-8888-4888-8888-888888888888", atype, content)
    all_by_id = {out["artifact_id"]: out}
    rows = []
    for r in list(inputs) + list(extras):
        all_by_id[r["artifact_id"]] = r
    for r in inputs:
        rows.append(r)
    return {
        "production_id": PID,
        "unit": {"unit_id": "mm07v-unit", "operation_id": op,
                 "current_attempt": 1},
        "operation": {"operation_id": op, "step_id": op.split(".")[0],
                      "capability_slot": "mm07v_probe",
                      "validator_policy": ["schema_validation",
                                           "dependency_integrity",
                                           "named_check"]},
        "output_artifact": out, "output_bytes": content,
        "input_artifacts": rows,
        "planned_input_ids": [r["artifact_id"] for r in rows],
        "all_by_id": all_by_id,
        "current_by_sha": {r["sha256"]: r for r in all_by_id.values()
                           if r["state"] == "CURRENT"},
        "environment": "test",
        "resolve_qa_binding": lambda: None,
        "fetch_bytes_by_sha": fetch or (lambda sha: None),
    }


def named(res, name):
    for c in res["report"]["checks"]:
        if c["check"] == name:
            return c
    return None


def script_bytes():
    doc = {"kind": "script",
           "lines": [{"id": "LX-1", "scene_ref": "SN1", "beat_ref": "BT1",
                      "story_ref": "ND1", "canon_refs": [CANON],
                      "text": "p"},
                     {"id": "LX-2", "scene_ref": "SN2", "beat_ref": "BT2",
                      "story_ref": "ND2", "canon_refs": [CANON],
                      "text": "q"}],
           "trace": {"clues": [], "knowledge": [], "payoffs": []},
           "canon_refs": [CANON]}
    return json.dumps(doc, sort_keys=True).encode()


def direction_bytes(line_refs):
    doc = {"kind": "direction_package",
           "script_ref": "77777777-7777-4777-8777-777777777777",
           "directions": [{"line_ref": lr, "direction": "hold"}
                          for lr in line_refs]}
    return json.dumps(doc, sort_keys=True).encode()


def beat_graph_bytes():
    doc = {"kind": "beat_graph",
           "beats": [{"id": "BT1", "story_ref": "ND1"},
                     {"id": "BT2", "story_ref": "ND2"}],
           "canon_refs": [CANON]}
    return json.dumps(doc, sort_keys=True).encode()


def scene_set_bytes(beat_refs):
    doc = {"kind": "scene_set",
           "scenes": [{"id": f"SN{i+1}", "beat_ref": br,
                       "canon_refs": [CANON]}
                      for i, br in enumerate(beat_refs)],
           "canon_refs": [CANON]}
    return json.dumps(doc, sort_keys=True).encode()


def ffmpeg_clip(vcodec):
    out = Path(tempfile.mkdtemp(prefix="mm07v-probe-")) / "c.mp4"
    subprocess.run(["ffmpeg", "-nostdin", "-v", "error", "-y",
                    "-f", "lavfi", "-i",
                    "testsrc2=size=1280x720:rate=12:duration=0.5",
                    "-f", "lavfi", "-i", "sine=frequency=330:duration=0.5",
                    "-c:v", vcodec, "-pix_fmt", "yuv420p", "-c:a", "aac",
                    "-ar", "48000", "-shortest", str(out)],
                   check=True, capture_output=True)
    return out.read_bytes()


def wav_bytes(rate):
    out = Path(tempfile.mkdtemp(prefix="mm07v-probe-")) / "n.wav"
    subprocess.run(["ffmpeg", "-nostdin", "-v", "error", "-y",
                    "-f", "lavfi", "-i", "sine=frequency=330:duration=0.5",
                    "-ar", str(rate), "-ac", "1", "-c:a", "pcm_s16le",
                    str(out)], check=True, capture_output=True)
    return out.read_bytes()


results = []

# REF pass ----------------------------------------------------------------
script = art("77777777-7777-4777-8777-777777777777", "script", script_bytes())
res = layers.technical_layer(ctx("09.12", direction_bytes(["LX-1", "LX-2"]),
                                 "direction_package", inputs=(script,)))
chk = named(res, "internal_reference_integrity")
ok = chk is not None and chk["ok"] and chk["dangling"] == [] \
    and res["evaluation"]["verdict"] == "PASS"
results.append(("REF-PASS", ok, chk))

# REF fail ------------------------------------------------------------------
res = layers.technical_layer(ctx("09.12", direction_bytes(["LX-1", "LX-404"]),
                                 "direction_package", inputs=(script,)))
chk = named(res, "internal_reference_integrity")
ok = chk is not None and chk["ok"] is False \
    and {d["value"] for d in chk["dangling"]} == {"LX-404"} \
    and res["evaluation"]["verdict"] == "FAIL"
results.append(("REF-FAIL", ok, chk))

# COV pass (07.12 scenes vs beat_graph beats) --------------------------------
beats = art("66666666-6666-4666-8666-666666666666", "beat_graph",
            beat_graph_bytes())
res = layers.technical_layer(ctx("07.12", scene_set_bytes(["BT1", "BT2"]),
                                 "scene_set", inputs=(beats,)))
chk = named(res, "input_set_coverage")
ok = chk is not None and chk["ok"] and chk["uncovered"] == []
results.append(("COV-PASS", ok, chk))

# COV fail --------------------------------------------------------------------
res = layers.technical_layer(ctx("07.12", scene_set_bytes(["BT1"]),
                                 "scene_set", inputs=(beats,)))
chk = named(res, "input_set_coverage")
ok = chk is not None and chk["ok"] is False and chk["uncovered"] == ["BT2"] \
    and res["evaluation"]["verdict"] == "FAIL"
results.append(("COV-FAIL", ok, chk))

# MED pass (raw media bytes at 13.03) ------------------------------------------
res = layers.technical_layer(ctx(
    "13.03", ffmpeg_clip("libx264"),
    "render_a_review_master_deterministically_where_possible"))
chk = named(res, "media_technical_validation")
ok = chk is not None and chk["ok"] and chk["failures"] == []
results.append(("MED-PASS", ok, chk))

# MED fail (media_output wav at wrong sample rate, op 12.05) -------------------
wav = wav_bytes(22050)
doc = {"kind": "apply_motivated_cuts",
       "media_output": {"sha256": _sha(wav), "storage_uri": "store://v",
                        "size": len(wav)}}
store = {_sha(wav): wav}
res = layers.technical_layer(ctx("12.05", json.dumps(doc).encode(),
                                 "apply_motivated_cuts",
                                 fetch=lambda s: store.get(s)))
chk = named(res, "media_technical_validation")
ok = chk is not None and chk["ok"] is False \
    and "SAMPLE_RATE_MISMATCH" in chk["failures"] \
    and res["evaluation"]["verdict"] == "FAIL"
results.append(("MED-FAIL", ok, chk))

allok = True
for name, ok, chk in results:
    allok &= ok
    slim = {k: chk.get(k) for k in ("ok", "applied", "dangling", "uncovered",
                                    "failures", "source")} if chk else None
    print(f"{name}: {'PASS' if ok else 'FAIL'} {json.dumps(slim, default=str)}")
print("PROBES:", "ALL PASS" if allok else "FAILURES PRESENT")
sys.exit(0 if allok else 1)
