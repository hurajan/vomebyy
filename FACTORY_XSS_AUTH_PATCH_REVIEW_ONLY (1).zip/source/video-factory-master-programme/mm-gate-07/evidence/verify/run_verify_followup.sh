#!/usr/bin/env bash
# MM-07 verifier — follow-up: (1) G9 persisted-DB probe with the correct
# table name (production_runs); (2) the g4 suite TWICE IN A ROW with
# port hygiene + FACTORY_DSN guard before each run (tree arg fixed).
set -u
W="$HOME/workspace"
V="$W/video-factory-master-programme/mm-gate-07/evidence/verify"
LOGS="$V/logs/regression"
PY="$W/video-factory-g2/.venv/bin/python"
OUT="$LOGS/VERIFY_FOLLOWUP.txt"
: > "$OUT"

"$PY" - >> "$OUT" 2>&1 <<'PYEOF'
import sys
sys.path.insert(0, "/home/hatch/workspace/video-factory-g3/tests")
from server_fixture import make_dsn
import psycopg
conn = psycopg.connect(make_dsn("g9_fullrun_scratch"), autocommit=True)
rows = conn.execute(
    "SELECT COUNT(u.*) AS units,"
    " COUNT(*) FILTER (WHERE u.state='ACCEPTED') AS accepted"
    " FROM productions p JOIN production_runs r"
    "   ON r.production_id=p.production_id"
    " JOIN execution_units u ON u.run_id=r.run_id"
    " GROUP BY p.production_id ORDER BY units DESC LIMIT 1").fetchall()
print("g9_db_fullrun (units, accepted):", rows)
chg = conn.execute(
    "SELECT COALESCE(SUM(amount_cents),0) FROM budget_ledger"
    " WHERE entry_type='CHARGE'").fetchone()
print("g9_db_charge_total_cents:", chg)
PYEOF

hygiene() { fuser -k 8730/tcp 8795/tcp 8796/tcp 2>/dev/null; sleep 1; }
api_db() {
  local pid
  pid=$(ss -ltnp 2>/dev/null | grep ':8730 ' | grep -oP 'pid=\K[0-9]+' | head -1)
  [ -z "$pid" ] && { echo "NO_API"; return; }
  tr '\0' '\n' < "/proc/$pid/environ" 2>/dev/null | grep '^FACTORY_DSN=' \
    | sed -E 's/.*dbname=([^ ]+).*/\1/'
}
g4_run() {
  local tag="$1"
  hygiene
  python3 "$W/video-factory-g4/tools/setup_env.py" > "$LOGS/$tag.setup.log" 2>&1
  local src=$?
  local actual; actual=$(api_db)
  echo "$tag setup_rc=$src api_db=$actual expect=g4_station_scratch" >> "$OUT"
  if [ "$actual" != "g4_station_scratch" ]; then
    echo "$tag ABORTED split-brain guard" >> "$OUT"; return
  fi
  ( cd "$W/video-factory-g4" && "$PY" -m unittest discover -s tests ) \
    > "$LOGS/$tag.log" 2>&1
  local rc=$?
  echo "$tag rc=$rc $(grep -E '^Ran [0-9]+ tests' "$LOGS/$tag.log" | tail -1) $(grep -E '^(OK|FAILED)' "$LOGS/$tag.log" | tail -1)" >> "$OUT"
}
g4_run g4_repeat1
g4_run g4_repeat2
hygiene
echo "FOLLOWUP DONE" >> "$OUT"
cat "$OUT"
