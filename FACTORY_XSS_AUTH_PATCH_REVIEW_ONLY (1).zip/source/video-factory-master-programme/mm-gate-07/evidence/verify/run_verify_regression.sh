#!/usr/bin/env bash
# MM-07 VERIFIER clean serial regression — 13 suites, strict port hygiene.
# Between EVERY suite: kill 8730/8795/8796 (+ verifier battery ports).
# Before each station suite's tests: assert the process listening on
# 8730 carries FACTORY_DSN pointing at that suite's own scratch DB.
set -u
W="$HOME/workspace"
V="$W/video-factory-master-programme/mm-gate-07/evidence/verify"
LOGS="$V/logs/regression"
mkdir -p "$LOGS"
PY="$W/video-factory-g2/.venv/bin/python"
RP="$W/video-factory-real-ai-programme"
SUMMARY="$LOGS/VERIFY_SUMMARY.txt"
: > "$SUMMARY"

hygiene() {
  fuser -k 8730/tcp 8795/tcp 8796/tcp 8766/tcp 8967/tcp 2>/dev/null
  sleep 1
}

api_db() { # echoes FACTORY_DSN dbname of the process listening on 8730
  local pid
  pid=$(ss -ltnp 2>/dev/null | grep ':8730 ' | grep -oP 'pid=\K[0-9]+' | head -1)
  [ -z "$pid" ] && { echo "NO_API"; return; }
  tr '\0' '\n' < "/proc/$pid/environ" 2>/dev/null | grep '^FACTORY_DSN=' \
    | sed -E 's/.*dbname=([^ ]+).*/\1/'
}

run_suite() {
  local name="$1"; shift
  hygiene
  echo "=== $name" | tee -a "$SUMMARY"
  "$@" > "$LOGS/$name.log" 2>&1
  local rc=$?
  local line verdict
  line=$(grep -E "^Ran [0-9]+ tests" "$LOGS/$name.log" | tail -1)
  verdict=$(grep -E "^(OK|FAILED)" "$LOGS/$name.log" | tail -1)
  echo "$name rc=$rc $line $verdict" | tee -a "$SUMMARY"
}

station_suite() {
  local t="$1" db="$2" setup="$3"
  hygiene
  echo "=== $t (setup, expect API db=$db)" | tee -a "$SUMMARY"
  python3 "$setup" > "$LOGS/$t.setup.log" 2>&1
  local src=$?
  local actual
  actual=$(api_db)
  echo "$t setup_rc=$src api_db=$actual expect=$db" | tee -a "$SUMMARY"
  if [ "$actual" != "$db" ]; then
    echo "$t ABORTED: split-brain guard (API bound to '$actual')" \
      | tee -a "$SUMMARY"
    echo "$t rc=97 SETUP/DSN MISMATCH" >> "$SUMMARY"
    return
  fi
  ( cd "$W/video-factory-$t" && "$PY" -m unittest discover -s tests ) \
    > "$LOGS/$t.log" 2>&1
  local rc=$?
  local line verdict
  line=$(grep -E "^Ran [0-9]+ tests" "$LOGS/$t.log" | tail -1)
  verdict=$(grep -E "^(OK|FAILED)" "$LOGS/$t.log" | tail -1)
  echo "$t rc=$rc $line $verdict" | tee -a "$SUMMARY"
}

run_suite g1 bash -c "cd '$W/video-factory-g1' && '$PY' -m unittest discover -s tests"
run_suite g2 bash -c "cd '$W/video-factory-g2' && '$PY' -m unittest discover -s tests"
run_suite g3 bash -c "cd '$W/video-factory-g3' && '$PY' -m unittest discover -s tests"
station_suite g4 g4_station_scratch "$W/video-factory-g4/tools/setup_env.py"
station_suite g5 g5_station_scratch "$W/video-factory-g5/tools/setup_env.py"
station_suite g6 g6_station_scratch "$W/video-factory-g6/tools/setup_env.py"
station_suite g7 g7_station_scratch "$W/video-factory-g7/tools/setup_env.py"
station_suite g8 g8_station_scratch "$W/video-factory-g8/tools/setup_env.py"
station_suite g9 g9_fullrun_scratch "$W/video-factory-g9/tools/setup_fullrun.py"
run_suite worker bash -c "cd '$RP/gate-c' && '$PY' -m unittest discover -s worker_service/tests"
run_suite storage bash -c "cd '$RP/gate-d' && '$PY' -m unittest discover -s storage_service/tests"
run_suite evaluation bash -c "cd '$RP/gate-e' && '$PY' -m unittest discover -s evaluation_service/tests"
run_suite runtime bash -c "cd '$RP/gate-f' && '$PY' -m unittest discover -s runtime_services/tests"

# G9 full-run DB outcome (independent of suite assertions; DSN sourced
# from the g3 fixture module, never a literal in this file)
hygiene
"$PY" - >> "$SUMMARY" 2>&1 <<'PYEOF'
import sys
sys.path.insert(0, "/home/hatch/workspace/video-factory-g3/tests")
from server_fixture import make_dsn
import psycopg
conn = psycopg.connect(make_dsn("g9_fullrun_scratch"), autocommit=True)
rows = conn.execute(
    "SELECT COUNT(u.*) AS units,"
    " COUNT(*) FILTER (WHERE u.state='ACCEPTED') AS accepted"
    " FROM productions p JOIN runs r ON r.production_id=p.production_id"
    " JOIN execution_units u ON u.run_id=r.run_id"
    " GROUP BY p.production_id ORDER BY units DESC LIMIT 1").fetchall()
print("g9_db_fullrun (units, accepted):", rows)
PYEOF

# g4 TWICE IN A ROW under the same hygiene (split-brain non-reproduction)
station_suite g4b g4_station_scratch "$W/video-factory-g4/tools/setup_env.py"
station_suite g4c g4_station_scratch "$W/video-factory-g4/tools/setup_env.py"
hygiene
echo "VERIFY REGRESSION DONE" | tee -a "$SUMMARY"
