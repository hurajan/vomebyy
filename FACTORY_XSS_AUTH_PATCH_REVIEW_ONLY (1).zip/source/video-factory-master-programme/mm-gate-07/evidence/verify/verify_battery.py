"""MM-07 INDEPENDENT VERIFIER battery — N1..N12 reproduction.

Own scratch DB (mm07_verify_scratch), own ports (API 8766 / EVAL 8967),
own tokens, own fixture content (different characters/ids/values from
the builder's battery), and every terminal-state assertion read by raw
SQL from execution_units / quality_evaluations / audit_events —
never from the service response alone.

Exit code 0 iff all 12 cases PASS.
"""
import json
import os
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.request
from pathlib import Path

HERE = Path(__file__).resolve().parent
RESULTS = HERE / "results"
RESULTS.mkdir(parents=True, exist_ok=True)

HOME = Path.home()
G2 = HOME / "workspace/video-factory-g2"
G3 = HOME / "workspace/video-factory-g3"
RP = HOME / "workspace/video-factory-real-ai-programme"
for p in (str(G2), str(RP / "gate-d"), str(G3 / "tests"),
          str(RP / "gate-e" / "evaluation_service")):
    sys.path.insert(0, p)

import psycopg  # noqa: E402
from psycopg.rows import dict_row  # noqa: E402
from coordinator.coordinator import Coordinator  # noqa: E402
from storage_service import LocalStorage, final_uri  # noqa: E402
from server_fixture import make_dsn, start_server, stop_server  # noqa: E402

DB = "mm07_verify_scratch"
DSN = make_dsn(DB)
API_PORT, EVAL_PORT = 8766, 8967
API_URL = f"http://127.0.0.1:{API_PORT}"
EVAL_URL = f"http://127.0.0.1:{EVAL_PORT}"
VALIDATOR_TOKEN = "mm07v-validator-token"
WORKER_TOKEN = "mm07v-worker-token"
G2_PY = str(G2 / ".venv" / "bin" / "python")
CONTRACTS = HOME / "workspace/video-factory-g1/contracts"
RENDER_TYPE = "render_a_review_master_deterministically_where_possible"
ROS = [("Emotion", 51), ("Story", 23), ("Rhythm", 10),
       ("Eye Trace", 7), ("2D Plane", 5), ("3D Space", 4)]


def raw():
    return psycopg.connect(DSN, row_factory=dict_row, autocommit=True)


def db_unit_state(uid):
    with raw() as conn:
        return conn.execute(
            "SELECT state FROM execution_units WHERE unit_id=%s",
            (uid,)).fetchone()["state"]


def db_evals(artifact_id):
    with raw() as conn:
        rows = conn.execute(
            "SELECT validator_id, verdict, evidence FROM quality_evaluations"
            " WHERE artifact_id=%s", (artifact_id,)).fetchall()
    return {r["validator_id"]: r for r in rows}


def deliverable_name(step):
    schema = json.loads(
        (CONTRACTS / f"step-{step}" / "output.schema.json").read_text())
    return schema["properties"]["step_deliverable"]["const"]


def envelope(pid, op, artifact_type, content):
    return json.dumps({
        "production_id": pid, "operation_id": op, "status": "CANDIDATE",
        "step_deliverable": deliverable_name(op.split(".")[0]),
        "output_artifacts": [{
            "artifact_id": "55555555-5555-4555-8555-555555555555",
            "artifact_type": artifact_type, "sha256": "b" * 64,
            "content": content}],
        "evidence": []}, sort_keys=True).encode()


def script_doc(canon_id, scenes=("SN1", "SN2"), canon_lines=(0, 1, 2),
               payoff_line="A3"):
    """Verifier's own script fixture: lines A1..A3 over scenes SN1/SN2."""
    pool = [
        {"id": "A1", "scene_ref": "SN1", "beat_ref": "BT1",
         "story_ref": "ND1", "canon_refs": [canon_id],
         "text": "Ines pockets the torn map."},
        {"id": "A2", "scene_ref": "SN2", "beat_ref": "BT2",
         "story_ref": "ND2", "canon_refs": [canon_id],
         "text": "Rook burns the second copy."},
        {"id": "A3", "scene_ref": "SN1", "beat_ref": "BT1",
         "story_ref": "ND1", "canon_refs": [canon_id],
         "text": "The map's margin names the traitor."}]
    lines = [l for l in pool if l["scene_ref"] in scenes]
    for i, line in enumerate(pool):
        if i not in canon_lines:
            line["canon_refs"] = []
    return {"kind": "script", "lines": lines,
            "trace": {"clues": [{"id": "K1", "planted": "A1",
                                 "payoff": payoff_line}],
                      "knowledge": [{"character": "Ines", "learns": "K1",
                                     "at": "A2"}],
                      "payoffs": [{"id": "P1", "clue": "K1",
                                   "line": payoff_line}]},
            "canon_refs": [canon_id]}


class Stack:
    def __init__(self):
        subprocess.run(["fuser", "-k", f"{API_PORT}/tcp", f"{EVAL_PORT}/tcp"],
                       capture_output=True)
        time.sleep(0.5)
        self.store_root = tempfile.mkdtemp(prefix="mm07v-store-")
        self.storage = LocalStorage(self.store_root)
        self.api_proc, self.client = start_server(DB, API_PORT, env_extra={
            "FACTORY_VALIDATOR_TOKEN": VALIDATOR_TOKEN,
            "FACTORY_WORKER_TOKEN": WORKER_TOKEN,
            "FACTORY_STORAGE_ROOT": self.store_root})
        env = dict(os.environ, FACTORY_DSN=DSN, FACTORY_API_URL=API_URL,
                   FACTORY_VALIDATOR_TOKEN=VALIDATOR_TOKEN,
                   FACTORY_ENVIRONMENT="test",
                   FACTORY_STORAGE_ROOT=self.store_root,
                   FACTORY_EVAL_PORT=str(EVAL_PORT))
        self.eval_proc = subprocess.Popen(
            [G2_PY, str(RP / "gate-e" / "evaluation_service" / "service.py")],
            env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        for _ in range(120):
            try:
                with urllib.request.urlopen(EVAL_URL + "/health",
                                            timeout=2) as r:
                    if r.status == 200:
                        break
            except Exception:  # noqa: BLE001
                time.sleep(0.1)
        else:
            raise RuntimeError("evaluation service did not come up")
        # Confirm the API answers against OUR scratch DB (split-brain guard):
        self.c = Coordinator(DSN, storage=self.storage)
        self.pid = self.c.create_production("MM-07 verifier", 100_00, 80_00,
                                            "mm07v")
        self.run = self.c.start_run(self.pid, "FULL", "mm07v")
        status, body = self.client.call("GET", f"/productions/{self.pid}")
        assert status == 200, f"API split-brain guard failed: {status} {body}"

    def close(self):
        with raw() as conn:
            conn.execute("UPDATE provider_configs SET active=false"
                         " WHERE created_by='mm07-verify'")
        self.c.close()
        self.eval_proc.terminate()
        stop_server(self.api_proc)

    def fresh(self):
        with raw() as conn:
            conn.execute("UPDATE provider_configs SET active=false"
                         " WHERE created_by='mm07-verify'")
        self.pid = self.c.create_production("MM-07 verifier case",
                                            100_00, 80_00, "mm07v")
        self.run = self.c.start_run(self.pid, "FULL", "mm07v")
        return self.pid

    def put_input(self, data, artifact_type):
        ref = self.storage.put_candidate(data)
        self.storage.promote(ref["uri"])
        return self.c.register_artifact(self.pid, artifact_type, data,
                                        final_uri(ref["sha256"]))

    def complete_unit(self, op, content, artifact_type, inputs=(), key="main"):
        uid = self.c.plan_unit(self.pid, self.run, op, key,
                               input_artifact_ids=tuple(inputs))
        claim = self.c.claim(uid, "mm07v-worker", 100)
        art = self.c.complete_attempt(uid, "mm07v-worker",
                                      claim["fencing_token"], artifact_type,
                                      content, None, 90)
        return uid, art["artifact_id"]

    def evaluate(self, uid):
        req = urllib.request.Request(
            EVAL_URL + "/evaluate", method="POST",
            data=json.dumps({"unit_id": uid}).encode(),
            headers={"Content-Type": "application/json"})
        try:
            with urllib.request.urlopen(req, timeout=25) as r:
                return r.status, json.loads(r.read())
        except urllib.error.HTTPError as e:
            return e.code, json.loads(e.read() or b"{}")

    def add_binding(self, scope, provider, op=None, slot=None,
                    credential_ref=None, params=None):
        with raw() as conn:
            conn.execute(
                "INSERT INTO provider_configs(scope, operation_id,"
                " capability_slot, environment, provider, est_cost_cents,"
                " credential_ref, params, created_by) VALUES"
                " (%s,%s,%s,'test',%s,0,%s,%s,'mm07-verify')",
                (scope, op, slot, provider, credential_ref,
                 json.dumps(params or {})))

    def api(self, method, path, body=None, role=None, token=None,
            identity=None):
        req = urllib.request.Request(API_URL + path, method=method)
        if body is not None:
            req.data = json.dumps(body).encode()
            req.add_header("Content-Type", "application/json")
        if role:
            req.add_header("X-Role", role)
        if token:
            req.add_header("X-Role-Token", token)
        if identity:
            req.add_header("X-Identity", identity)
        try:
            with urllib.request.urlopen(req, timeout=15) as r:
                return r.status, json.loads(r.read() or b"{}")
        except urllib.error.HTTPError as e:
            try:
                return e.code, json.loads(e.read() or b"{}")
            except Exception:  # noqa: BLE001
                return e.code, {}


def record(case, title, observed, ok):
    rec = {"case": case, "title": title, "observed": observed,
           "verdict": "PASS" if ok else "FAIL"}
    (RESULTS / f"verify_{case.lower()}.json").write_text(
        json.dumps(rec, indent=1))
    print(f"{case}: {'PASS' if ok else 'FAIL'} — {title}", flush=True)
    return rec


def media_bytes(vcodec):
    out = Path(tempfile.mkdtemp(prefix="mm07v-media-")) / "clip.mp4"
    subprocess.run(
        ["ffmpeg", "-nostdin", "-v", "error", "-y",
         "-f", "lavfi", "-i", "testsrc2=size=1280x720:rate=12:duration=0.5",
         "-f", "lavfi", "-i", "sine=frequency=330:duration=0.5",
         "-c:v", vcodec, "-pix_fmt", "yuv420p", "-c:a", "aac", "-ar", "48000",
         "-shortest", str(out)], check=True, capture_output=True)
    return out.read_bytes()


def story_doc(canon_id):
    return {"kind": "story_architecture",
            "story_nodes": [{"id": "ND1", "summary": "v-one"},
                            {"id": "ND2", "summary": "v-two"}],
            "canon_refs": [canon_id]}


def main():
    s = Stack()
    out = []
    try:
        # ------------------------------------------------------------ N1
        s.fresh()
        canon = s.put_input(b'{"canon": "verifier"}', "canon_manifest")
        bad = {"kind": "script",
               "lines": [{"id": "A1", "scene_ref": "SN1", "beat_ref": "BT1",
                          "story_ref": "ND1",
                          "canon_refs": [canon["artifact_id"]], "text": "y"}],
               "canon_refs": [canon["artifact_id"]]}  # trace omitted
        uid, art = s.complete_unit(
            "08.12", envelope(s.pid, "08.12", "script", bad), "script",
            inputs=(canon["artifact_id"],), key="v-n1")
        _, rep = s.evaluate(uid)
        evs = db_evals(art)
        st = db_unit_state(uid)
        out.append(record("N1", "schema-violating deliverable -> BLOCKED",
                          {"db_unit_state": st,
                           "service_state": rep.get("resulting_state"),
                           "schema_verdict": evs["schema_validation"]["verdict"]},
                          st == "BLOCKED"
                          and evs["schema_validation"]["verdict"] == "FAIL"))

        # ------------------------------------------------------------ N2
        s.fresh()
        canon = s.put_input(b'{"canon": "verifier"}', "canon_manifest")
        uid, art = s.complete_unit(
            "08.12", envelope(s.pid, "08.12", "script",
                              script_doc(canon["artifact_id"],
                                         canon_lines=(2,))),
            "script", inputs=(canon["artifact_id"],), key="v-n2")
        s.add_binding("OPERATION", "deterministic-local", op="08.12")
        _, rep = s.evaluate(uid)
        evs = db_evals(art)
        sem = evs["semantic_evaluation"]["evidence"]
        st = db_unit_state(uid)
        out.append(record("N2", "canon coverage 1/3 < threshold -> RUBRIC_FAIL",
                          {"db_unit_state": st,
                           "semantic_status": sem.get("status"),
                           "problems": sem.get("problems")},
                          sem.get("status") == "RUBRIC_FAIL"
                          and st == "REPAIR_REQUIRED"))

        # ------------------------------------------------------------ N3
        s.fresh()
        dims = [{"name": n, "weight": w, "score": 3.0} for n, w in ROS]
        doc = {"kind": "edit_timeline",
               "segments": [{"shot_ref": "SH9", "order": 1}],
               "rule_of_six": {"dimensions": dims, "weighted_total": 3.0}}
        uid, art = s.complete_unit(
            "12.12", envelope(s.pid, "12.12", "edit_timeline", doc),
            "edit_timeline", key="v-n3")
        s.add_binding("OPERATION", "deterministic-local", op="12.12",
                      params={"rule_of_six_min_weighted_total": 8.0})
        _, rep = s.evaluate(uid)
        evs = db_evals(art)
        sem = evs["semantic_evaluation"]["evidence"]
        st = db_unit_state(uid)
        out.append(record("N3", "Rule-of-Six below policy threshold",
                          {"db_unit_state": st,
                           "semantic_status": sem.get("status"),
                           "problems": sem.get("problems")},
                          sem.get("status") == "RUBRIC_FAIL"
                          and any("below threshold" in p
                                  for p in sem.get("problems", []))
                          and st != "ACCEPTED"))

        # ------------------------------------------------------------ N4
        s.fresh()
        good = envelope(s.pid, "05.12", "story_architecture",
                        {"kind": "story_architecture",
                         "story_nodes": [{"id": "ND1", "summary": "v"}],
                         "canon_refs": []})
        uid, art = s.complete_unit("05.12", good, "story_architecture",
                                   key="v-n4")
        with raw() as conn:
            sha = conn.execute("SELECT sha256 FROM artifacts WHERE"
                               " artifact_id=%s", (art,)).fetchone()["sha256"]
        hit = 0
        for area in ("objects", "candidates"):
            t = Path(s.store_root) / area / sha
            if t.exists():
                t.write_bytes(b'{"kind": "story_architecture", "forged": 1}')
                hit += 1
        assert hit >= 1
        _, rep = s.evaluate(uid)
        evs = db_evals(art)
        tech = evs["deterministic_checks"]["evidence"]
        chk = [c for c in tech["checks"] if c["check"] == "sha256_match"][0]
        st = db_unit_state(uid)
        out.append(record("N4", "tampered durable bytes -> hash FAIL, BLOCKED",
                          {"db_unit_state": st,
                           "technical_verdict":
                               evs["deterministic_checks"]["verdict"],
                           "sha256_match_ok": chk["ok"],
                           "recorded": chk["recorded"][:12],
                           "recomputed": chk["recomputed"][:12]},
                          evs["deterministic_checks"]["verdict"] == "FAIL"
                          and chk["ok"] is False and st == "BLOCKED"))

        # ------------------------------------------------------------ N5
        s.fresh()

        def in_env():
            return json.dumps({"production_id": s.pid,
                               "operation_id": "05.12",
                               "input_artifacts": []},
                              sort_keys=True).encode()

        x = s.put_input(in_env(), "canon_manifest")
        uid, art = s.complete_unit(
            "05.12", envelope(s.pid, "05.12", "story_architecture",
                              {"kind": "story_architecture",
                               "story_nodes": [{"id": "ND1", "summary": "v"}],
                               "canon_refs": []}),
            "story_architecture", inputs=(x["artifact_id"],), key="v-n5")
        s.put_input(in_env(), "canon_manifest")  # supersedes planned input
        _, rep = s.evaluate(uid)
        evs = db_evals(art)
        cont = evs["continuity_checks"]["evidence"]
        st = db_unit_state(uid)
        out.append(record("N5", "superseded planned input -> REPAIR_REQUIRED",
                          {"db_unit_state": st,
                           "continuity_verdict":
                               evs["continuity_checks"]["verdict"],
                           "superseded": [r["artifact_id"] for r in
                                          cont.get("superseded_inputs", [])]},
                          st == "REPAIR_REQUIRED"
                          and evs["continuity_checks"]["verdict"] == "FAIL"))

        # ------------------------------------------------------------ N6
        s.fresh()
        uid, art = s.complete_unit(
            "05.12", envelope(s.pid, "05.12", "story_architecture",
                              story_doc("00000000-0000-4000-8000-000000000000")),
            "story_architecture", key="v-n6")
        with raw() as conn:
            conn.execute(
                "INSERT INTO quality_evaluations(artifact_id, validator_id,"
                " method, evidence, verdict, evaluator_identity) VALUES"
                " (%s,'worker_self','self_report','{}','PASS','mm07v-worker')",
                (art,))
        st = db_unit_state(uid)
        out.append(record("N6", "worker PASS, no evaluation -> never ACCEPTED",
                          {"db_unit_state": st,
                           "evaluation_rows": len(db_evals(art))},
                          st == "VALIDATING"))

        # ------------------------------------------------------------ N7
        s.fresh()
        uid, art = s.complete_unit(
            "05.12", envelope(s.pid, "05.12", "story_architecture",
                              story_doc("00000000-0000-4000-8000-000000000000")),
            "story_architecture", key="v-n7")
        status, body = s.api(
            "POST", f"/units/{uid}/validate",
            body={"evaluations": [{"validator": "semantic_evaluation",
                                   "verdict": "PASS",
                                   "evidence": {"deterministic": False}}]},
            role="WORKER", token=WORKER_TOKEN, identity="forged-validator")
        st = db_unit_state(uid)
        nrows = len(db_evals(art))
        out.append(record("N7", "WORKER token forges VALIDATOR verdict -> 403",
                          {"http_status": status, "response": body,
                           "db_unit_state": st, "evaluation_rows": nrows},
                          status == 403 and st == "VALIDATING" and nrows == 0))

        # ------------------------------------------------------------ N8
        s.fresh()
        master = s.put_input(b'{"kind": "master_package", "asset_hashes": []}',
                             "master_package")
        gate = s.c.create_gate(s.pid, "HG4", master["artifact_id"])
        s.c.decide_gate(gate["gate_id"], "REJECTED", "mm07-verify")
        uid = s.c.plan_unit(s.pid, s.run, "14.01", "v-n8",
                            input_artifact_ids=(master["artifact_id"],))
        status, body = s.api(
            "POST", f"/units/{uid}/claim",
            body={"worker_id": "mm07v-worker", "estimated_cents": 100},
            role="WORKER", token=WORKER_TOKEN, identity="mm07v-worker")
        with raw() as conn:
            audits = conn.execute(
                "SELECT COUNT(*) AS n FROM audit_events WHERE unit_id=%s"
                " AND event_type='gate_claim_refused'",
                (uid,)).fetchone()["n"]
            attempts = conn.execute(
                "SELECT COUNT(*) AS n FROM action_attempts WHERE unit_id=%s",
                (uid,)).fetchone()["n"]
        st = db_unit_state(uid)
        out.append(record("N8", "HG4 REJECTED -> downstream claim refused",
                          {"http_status": status,
                           "gate_claim_refused_audits": audits,
                           "attempts": attempts, "db_unit_state": st},
                          status == 409 and audits >= 1 and attempts == 0))

        # ------------------------------------------------------------ N9
        s.fresh()
        uid, art = s.complete_unit("13.03", media_bytes("mpeg4"),
                                   RENDER_TYPE, key="v-n9-bad")
        _, rep = s.evaluate(uid)
        evs = db_evals(art)
        chk = [c for c in evs["deterministic_checks"]["evidence"]["checks"]
               if c["check"] == "media_technical_validation"][0]
        uid2, art2 = s.complete_unit("13.03", media_bytes("libx264"),
                                     RENDER_TYPE, key="v-n9-good")
        _, rep2 = s.evaluate(uid2)
        evs2 = db_evals(art2)
        chk2 = [c for c in evs2["deterministic_checks"]["evidence"]["checks"]
                if c["check"] == "media_technical_validation"][0]
        st, st2 = db_unit_state(uid), db_unit_state(uid2)
        out.append(record("N9", "wrong-codec media at 13.03 -> BLOCKED",
                          {"bad": {"db_unit_state": st, "media_ok": chk["ok"],
                                   "failures": chk["failures"]},
                           "control": {"db_unit_state": st2,
                                       "media_ok": chk2["ok"],
                                       "failures": chk2["failures"]}},
                          chk["ok"] is False
                          and "VIDEO_CODEC_MISMATCH" in chk["failures"]
                          and st == "BLOCKED" and chk2["ok"] is True
                          and st2 != "BLOCKED"))

        # ----------------------------------------------------------- N10
        s.fresh()
        canon = s.put_input(b'{"canon": "verifier"}', "canon_manifest")
        uid, art = s.complete_unit(
            "08.12", envelope(s.pid, "08.12", "script",
                              script_doc(canon["artifact_id"],
                                         payoff_line="A77")),
            "script", inputs=(canon["artifact_id"],), key="v-n10")
        _, rep = s.evaluate(uid)
        evs = db_evals(art)
        chk = [c for c in evs["deterministic_checks"]["evidence"]["checks"]
               if c["check"] == "internal_reference_integrity"][0]
        st = db_unit_state(uid)
        out.append(record("N10", "payoff -> nonexistent line A77",
                          {"db_unit_state": st,
                           "technical_verdict":
                               evs["deterministic_checks"]["verdict"],
                           "dangling": [d["value"] for d in chk["dangling"]]},
                          chk["ok"] is False
                          and {d["value"] for d in chk["dangling"]} == {"A77"}
                          and st == "BLOCKED"))

        # ----------------------------------------------------------- N11
        s.fresh()
        canon = s.put_input(b'{"canon": "verifier"}', "canon_manifest")
        cid = canon["artifact_id"]
        s.complete_unit(
            "05.12", envelope(s.pid, "05.12", "story_architecture",
                              story_doc(cid)),
            "story_architecture", inputs=(cid,), key="v-n11-s")
        s.complete_unit(
            "06.12", envelope(s.pid, "06.12", "beat_graph",
                              {"kind": "beat_graph",
                               "beats": [{"id": "BT1", "story_ref": "ND1"},
                                         {"id": "BT2", "story_ref": "ND2"}],
                               "canon_refs": [cid]}),
            "beat_graph", inputs=(cid,), key="v-n11-b")
        s.complete_unit(
            "07.12", envelope(s.pid, "07.12", "scene_set",
                              {"kind": "scene_set",
                               "scenes": [
                                   {"id": "SN1", "beat_ref": "BT1",
                                    "canon_refs": [cid]},
                                   {"id": "SN2", "beat_ref": "BT2",
                                    "canon_refs": [cid]}],
                               "canon_refs": [cid]}),
            "scene_set", inputs=(cid,), key="v-n11-sc")
        uid, art = s.complete_unit(
            "08.12", envelope(s.pid, "08.12", "script",
                              script_doc(cid, scenes=("SN1",))),
            "script", inputs=(cid,), key="v-n11")
        _, rep = s.evaluate(uid)
        evs = db_evals(art)
        chk = [c for c in evs["deterministic_checks"]["evidence"]["checks"]
               if c["check"] == "input_set_coverage"][0]
        st = db_unit_state(uid)
        out.append(record("N11", "scene SN2 uncovered -> coverage FAIL",
                          {"db_unit_state": st,
                           "schema_verdict":
                               evs["schema_validation"]["verdict"],
                           "coverage_ok": chk["ok"],
                           "uncovered": chk["uncovered"]},
                          chk["ok"] is False and chk["uncovered"] == ["SN2"]
                          and evs["schema_validation"]["verdict"] == "PASS"
                          and st == "BLOCKED"))

        # ----------------------------------------------------------- N12
        s.fresh()
        uid, art = s.complete_unit(
            "05.12", envelope(s.pid, "05.12", "story_architecture",
                              {"kind": "story_architecture",
                               "story_nodes": [{"id": "ND1", "summary": "v"}],
                               "canon_refs": []}),
            "story_architecture", key="v-n12")
        s.add_binding("OPERATION", "openrouter-compatible", op="05.12",
                      credential_ref="MM07V_KEY_THAT_DOES_NOT_EXIST")
        _, rep = s.evaluate(uid)
        evs = db_evals(art)
        sem = evs["semantic_evaluation"]["evidence"]
        st = db_unit_state(uid)
        out.append(record("N12", "uncredentialed EVALUATION -> AWAITING_HUMAN",
                          {"db_unit_state": st,
                           "semantic_verdict":
                               evs["semantic_evaluation"]["verdict"],
                           "semantic_status": sem.get("status"),
                           "semantic_reason": sem.get("reason")},
                          evs["semantic_evaluation"]["verdict"]
                          == "REVIEW_REQUIRED"
                          and sem.get("reason") == "credential_absent"
                          and st == "AWAITING_HUMAN"))
    finally:
        s.close()
    summary = {"battery": "MM-07 verifier reproduction N1-N12",
               "passed": sum(1 for r in out if r["verdict"] == "PASS"),
               "total": len(out),
               "cases": {r["case"]: r["verdict"] for r in out}}
    (RESULTS / "verify_summary.json").write_text(json.dumps(summary, indent=1))
    print(json.dumps(summary, indent=1))
    return 0 if summary["passed"] == summary["total"] == 12 else 1


if __name__ == "__main__":
    sys.exit(main())
