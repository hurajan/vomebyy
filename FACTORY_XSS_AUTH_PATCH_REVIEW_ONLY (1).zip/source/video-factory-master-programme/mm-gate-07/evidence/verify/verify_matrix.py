"""MM-07 verifier — policy matrix spot-check.

10 operations across all six stations; every applicable cell traced to
its source (mm-gate-01 classification validator_policy, deliverable
schema files, layers.py RUBRICS/coverage rules, gate seed migrations),
plus global honesty scans (RUBRIC/MED/GAP counts, MODEL_EVAL posture)
and absence greps for the two NOT_IMPLEMENTED gap classes.
Exit 0 iff every check passes.
"""
import json
import re
import sys
from pathlib import Path

HOME = Path.home()
MP = HOME / "workspace/video-factory-master-programme"
mx = json.loads((MP / "mm-gate-07/evidence/policy_matrix.json").read_text())
rows = {r["operation_id"]: r for r in mx["rows"]}
cls = json.loads((MP / "gate-01/evidence/operation_classification.json")
                 .read_text())
cls_ops = {o["operation_id"]: o for o in cls["operations"]}
layers_src = (HOME / "workspace/video-factory-real-ai-programme/gate-e"
              / "evaluation_service/layers.py").read_text()
eval_dir = HOME / "workspace/video-factory-real-ai-programme/gate-e/evaluation_service"
deliv = HOME / "workspace/video-factory-g1/contracts/deliverables"
mig = ""
for n in ("003", "004", "005"):
    mig += "".join(p.read_text() for p in
                   (HOME / "workspace/video-factory-g2/database/migrations")
                   .glob(f"{n}_*.sql"))

results = []


def check(name, ok, detail=""):
    results.append((name, ok))
    print(f"{'PASS' if ok else 'FAIL'}  {name}  {detail}")


SPOT = ["01.05", "03.07", "04.03", "08.12", "06.12",
        "11.06", "12.06", "13.03", "14.01", "16.05"]
BASE = {"schema_validation", "dependency_integrity"}

# 1) named_checks trace to classification validator_policy -------------
bad = []
for op in SPOT:
    expect = [p for p in cls_ops[op]["validator_policy"] if p not in BASE]
    if rows[op]["named_checks"] != expect:
        bad.append((op, rows[op]["named_checks"], expect))
check("named_checks == classification validator_policy minus base (10 ops)",
      not bad, str(bad))

# also: all 192 rows
bad = [op for op in rows
       if rows[op]["named_checks"]
       != [p for p in cls_ops[op]["validator_policy"] if p not in BASE]]
check("named_checks trace holds for all 192 rows", not bad, str(bad[:4]))

# 2) approval policy + station trace ------------------------------------
bad = [(op, rows[op]["approval_policy"], cls_ops[op]["approval_policy"])
       for op in SPOT
       if rows[op]["approval_policy"] != cls_ops[op]["approval_policy"]
       or rows[op]["station"] != cls_ops[op]["station_registry"]]
check("approval_policy + station match classification (10 ops)", not bad,
      str(bad))

# 3) deliverable schema existence for exits ------------------------------
for op in ["08.12", "06.12", "13.03"]:
    step = op.split(".")[0]
    check(f"deliverable schema exists for exit {op}",
          (deliv / f"step-{step}.schema.json").exists())
check("deliverable schema exists for op 14.01",
      (deliv / "op-14.01.schema.json").exists())

# 4) RUBRIC cells are exactly the two implemented rubrics -----------------
rub = [(op, dim) for op, r in rows.items() for dim, c in r["dimensions"].items()
       if c["kind"] == "RUBRIC"]
check("RUBRIC cells == {(08.12, source_canon_fidelity), (12.12, editorial)}",
      set(rub) == {("08.12", "source_canon_fidelity"),
                   ("12.12", "editorial_quality")}, str(rub))
m = re.search(r'RUBRICS = \{([^}]*)\}', layers_src)
check("layers.py RUBRICS == {12.12, 08.12}",
      '"12.12"' in m.group(1) and '"08.12"' in m.group(1)
      and m.group(1).count(':') == 2, m.group(1))

# 5) coverage-rule ops in matrix match _COVERAGE_RULES --------------------
region = layers_src.split("_COVERAGE_RULES")[1].split("def _coverage_check")[0]
cov_ops = set(re.findall(r'"(\d\d\.\d\d)": \{"entries"', region))
listed = {op for op, r in rows.items()
          if "input_set_coverage" in (r.get("mm07_checks") or [])}
check("matrix coverage ops == layers _COVERAGE_RULES ops",
      listed == cov_ops == {"06.12", "07.12", "08.12"},
      f"matrix={sorted(listed)} code={sorted(cov_ops)}")

# 6) human gates trace to seed migrations --------------------------------
for artifact, gate in [("script", "HG2"), ("master_package", "HG4"),
                       ("derivative_package", "HG5")]:
    check(f"gate_requirements seed maps {artifact} -> {gate}",
          artifact in mig and gate in mig)
for op, gate in [("08.12", "HG2"), ("13.03", "HG4"), ("14.01", "HG5")]:
    check(f"matrix human_gate for {op} names {gate}",
          gate in (rows[op].get("human_gate") or ""))

# 7) NOT_IMPLEMENTED cells: exactly the two gap classes -------------------
gaps = [(op, dim) for op, r in rows.items()
        for dim, c in r["dimensions"].items()
        if c["kind"] == "NOT_IMPLEMENTED"]
exp = ({(f"11.{i:02d}", "audio_video_alignment") for i in range(1, 13)}
       | {(f"12.{i:02d}", "narration_fidelity") for i in range(1, 13)})
check("NOT_IMPLEMENTED cells == 12x step-11 AV-alignment + 12x step-12 "
      "narration-fidelity", set(gaps) == exp and len(gaps) == 24,
      f"n={len(gaps)}")
check("every GAP cell basis names its gap",
      all(rows[op]["dimensions"][dim]["basis"].lower().startswith("gap:")
          or "no " in rows[op]["dimensions"][dim]["basis"][:12].lower()
          for op, dim in gaps))

# 8) gap classes genuinely unimplemented in the evaluation service -------
svc_src = "".join(p.read_text() for p in eval_dir.glob("*.py"))
align_hits = [ln for ln in svc_src.splitlines()
              if re.search(r"align", ln, re.I)
              and "alignment" in ln.lower()
              and not ln.strip().startswith("#")]
impl_align = [ln for ln in align_hits
              if re.search(r"def |sync|offset|drift", ln, re.I)]
narr_impl = [ln for ln in svc_src.splitlines()
             if re.search(r"def .*narrat|narrat.*(compar|fidelity.*script|"
                          r"script.*compar)", ln, re.I)]
check("no AV-alignment measurement implemented in evaluation service",
      not impl_align, str(impl_align[:2]))
check("no narration-vs-script comparison implemented in evaluation service",
      not narr_impl, str(narr_impl[:2]))

# 9) MEDIA_TECHNICAL cells -------------------------------------------------
med = [(op, dim) for op, r in rows.items()
       for dim, c in r["dimensions"].items()
       if c["kind"] == "MEDIA_TECHNICAL"]
check("MEDIA_TECHNICAL cell count == 22", len(med) == 22, f"n={len(med)}")
check("every MED cell basis cites media_technical_validation",
      all("media_technical_validation" in rows[op]["dimensions"][dim]["basis"]
          for op, dim in med))
check("media check exists in layers.py",
      "def _media_technical_check" in layers_src
      and '"media_technical_validation"' in layers_src)

# 10) MODEL_EVAL posture: no cell claims live judging ----------------------
posture = mx["model_eval_posture"]
check("matrix posture states REVIEW_REQUIRED / not wired",
      "REVIEW_REQUIRED" in posture and "not wired" in posture)
mod_cells = [(op, dim, c) for op, r in rows.items()
             for dim, c in r["dimensions"].items()
             if c["kind"] == "MODEL_EVAL"]
claimy = [(op, dim) for op, dim, c in mod_cells
          if re.search(r"(model|llm) (judges|scores|verifies|evaluates) "
                       r"(today|operationally|live)", c["basis"], re.I)]
check(f"no MODEL_EVAL cell claims operational judging ({len(mod_cells)} cells)",
      not claimy, str(claimy[:3]))
check("semantic layer: no-rubric named checks return REVIEW_REQUIRED "
      "(NO_RUBRIC)", '"status": "NO_RUBRIC"' in layers_src
      and "REVIEW_REQUIRED" in layers_src)
check("semantic layer: credential-absent also REVIEW_REQUIRED",
      "credential_absent" in layers_src)

# 11) kind counts recomputed == declared ----------------------------------
from collections import Counter
cnt = Counter(c["kind"] for r in rows.values()
              for c in r["dimensions"].values() if c["applicable"])
decl = {k.upper(): v for k, v in mx["kind_counts"].items()}
mapping = {"DETERMINISTIC": "DETERMINISTIC", "RUBRIC": "RUBRIC",
           "MEDIA_TECHNICAL": "MEDIA_TECHNICAL", "MODEL_EVAL": "MODEL_EVAL",
           "HUMAN_GATE": "HUMAN_GATE", "NOT_IMPLEMENTED": "NOT_IMPLEMENTED"}
same = all(cnt.get(k, 0) == decl.get(v, -1) for k, v in mapping.items())
check("recomputed kind counts == declared kind_counts", same,
      f"recomputed={dict(cnt)} declared={decl}")

# 12) N/A cells all carry a modality/stage basis ---------------------------
na_bad = [(op, dim) for op, r in rows.items()
          for dim, c in r["dimensions"].items()
          if not c["applicable"] and not c["basis"]]
check("every N/A cell carries a basis", not na_bad, str(na_bad[:3]))

fails = [n for n, ok in results if not ok]
print(f"\nSPOT-CHECK: {len(results) - len(fails)}/{len(results)} PASS")
sys.exit(1 if fails else 0)
