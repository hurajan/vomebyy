"""MM-07 negative battery — N1..N12.

PASS criterion (the gate's): every defective output is proven UNABLE
to reach acceptance. Each case runs against a real stack — chain-built
scratch DB (mm07_eval_scratch), the real Coordinator API subprocess,
the real evaluation service subprocess, a tmp Gate D store — and
writes one results JSON per case plus a summary. Exit code 0 iff all
12 cases PASS.

Serial by construction (one stack, cases run in order). No provider
call is made or attempted; bindings are deterministic-local or
credential-refs pointing at env vars that do not exist.
"""
import json
import os
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.request
from pathlib import Path

HERE = Path(__file__).resolve().parent
MM07 = HERE.parent
RESULTS = MM07 / "evidence" / "results"
RESULTS.mkdir(parents=True, exist_ok=True)

G2 = Path.home() / "workspace/video-factory-g2"
G3 = Path.home() / "workspace/video-factory-g3"
RP = Path.home() / "workspace/video-factory-real-ai-programme"
for p in (str(G2), str(RP / "gate-d"), str(G3 / "tests"),
          str(RP / "gate-e" / "evaluation_service")):
    sys.path.insert(0, p)

import psycopg  # noqa: E402
from psycopg.rows import dict_row  # noqa: E402
from coordinator.coordinator import Coordinator  # noqa: E402
from storage_service import LocalStorage, final_uri  # noqa: E402
from server_fixture import make_dsn, start_server, stop_server  # noqa: E402

DB = "mm07_eval_scratch"
DSN = make_dsn(DB)
API_PORT, EVAL_PORT = 8756, 8957
API_URL = f"http://127.0.0.1:{API_PORT}"
EVAL_URL = f"http://127.0.0.1:{EVAL_PORT}"
VALIDATOR_TOKEN = "mm07-validator-token"
WORKER_TOKEN = "mm07-worker-token"
G2_PY = str(G2 / ".venv" / "bin" / "python")
CONTRACTS = Path.home() / "workspace/video-factory-g1/contracts"
RENDER_TYPE = "render_a_review_master_deterministically_where_possible"
RULE_OF_SIX = [("Emotion", 51), ("Story", 23), ("Rhythm", 10),
               ("Eye Trace", 7), ("2D Plane", 5), ("3D Space", 4)]


def raw():
    return psycopg.connect(DSN, row_factory=dict_row, autocommit=True)


def deliverable_name(step):
    schema = json.loads(
        (CONTRACTS / f"step-{step}" / "output.schema.json").read_text())
    return schema["properties"]["step_deliverable"]["const"]


def envelope(pid, op, artifact_type, content):
    doc = {"production_id": pid, "operation_id": op, "status": "CANDIDATE",
           "step_deliverable": deliverable_name(op.split(".")[0]),
           "output_artifacts": [{
               "artifact_id": "33333333-3333-4333-8333-333333333333",
               "artifact_type": artifact_type, "sha256": "a" * 64,
               "content": content}],
           "evidence": []}
    return json.dumps(doc, sort_keys=True).encode()


def script_content(canon_id, scenes=("SC1", "SC2"), canon_lines=(0, 1, 2),
                   payoff_line="L3"):
    all_lines = [
        {"id": "L1", "scene_ref": "SC1", "beat_ref": "B1", "story_ref": "S1",
         "canon_refs": [canon_id], "text": "Mara finds the brass key."},
        {"id": "L2", "scene_ref": "SC2", "beat_ref": "B2", "story_ref": "S2",
         "canon_refs": [canon_id], "text": "Tobin admits it was locked."},
        {"id": "L3", "scene_ref": "SC1", "beat_ref": "B1", "story_ref": "S1",
         "canon_refs": [canon_id], "text": "The key opens the archive."}]
    lines = [l for l in all_lines if l["scene_ref"] in scenes]
    for i, line in enumerate(all_lines):
        if i not in canon_lines:
            line["canon_refs"] = []
    return {"kind": "script", "lines": lines,
            "trace": {"clues": [{"id": "CL1", "planted": "L1",
                                 "payoff": payoff_line}],
                      "knowledge": [{"character": "Mara", "learns": "CL1",
                                     "at": "L2"}],
                      "payoffs": [{"id": "PO1", "clue": "CL1",
                                   "line": payoff_line}]},
            "canon_refs": [canon_id]}


class Stack:
    def __init__(self):
        subprocess.run(["fuser", "-k", f"{API_PORT}/tcp", f"{EVAL_PORT}/tcp"],
                       capture_output=True)
        self.store_root = tempfile.mkdtemp(prefix="mm07-store-")
        self.storage = LocalStorage(self.store_root)
        self.api_proc, _ = start_server(DB, API_PORT, env_extra={
            "FACTORY_VALIDATOR_TOKEN": VALIDATOR_TOKEN,
            "FACTORY_WORKER_TOKEN": WORKER_TOKEN,
            "FACTORY_STORAGE_ROOT": self.store_root})
        env = dict(os.environ, FACTORY_DSN=DSN, FACTORY_API_URL=API_URL,
                   FACTORY_VALIDATOR_TOKEN=VALIDATOR_TOKEN,
                   FACTORY_ENVIRONMENT="test",
                   FACTORY_STORAGE_ROOT=self.store_root,
                   FACTORY_EVAL_PORT=str(EVAL_PORT))
        self.eval_proc = subprocess.Popen(
            [G2_PY, str(RP / "gate-e" / "evaluation_service" / "service.py")],
            env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        for _ in range(100):
            try:
                with urllib.request.urlopen(EVAL_URL + "/health", timeout=2) as r:
                    if r.status == 200:
                        break
            except Exception:  # noqa: BLE001
                time.sleep(0.1)
        else:
            raise RuntimeError("evaluation service did not come up")
        self.c = Coordinator(DSN, storage=self.storage)
        self.pid = self.c.create_production("MM-07 battery", 100_00, 80_00,
                                            "mm07")
        self.run = self.c.start_run(self.pid, "FULL", "mm07")

    def close(self):
        with raw() as conn:
            conn.execute("UPDATE provider_configs SET active=false"
                         " WHERE created_by='mm07-battery'")
        self.c.close()
        self.eval_proc.terminate()
        stop_server(self.api_proc)

    # ------------------------------------------------------------ helpers
    def fresh(self):
        """A new production (+ run) per case: artifact supersession is
        per (production, artifact_type), so cases must not share one
        production; battery bindings are deactivated for the same
        reason."""
        with raw() as conn:
            conn.execute("UPDATE provider_configs SET active=false"
                         " WHERE created_by='mm07-battery'")
        self.pid = self.c.create_production("MM-07 battery case",
                                            100_00, 80_00, "mm07")
        self.run = self.c.start_run(self.pid, "FULL", "mm07")
        return self.pid

    def put_input(self, data, artifact_type):
        ref = self.storage.put_candidate(data)
        self.storage.promote(ref["uri"])
        return self.c.register_artifact(self.pid, artifact_type, data,
                                        final_uri(ref["sha256"]))

    def complete_unit(self, op, content, artifact_type, inputs=(), key="main"):
        uid = self.c.plan_unit(self.pid, self.run, op, key,
                               input_artifact_ids=tuple(inputs))
        claim = self.c.claim(uid, "mm07-worker", 100)
        art = self.c.complete_attempt(uid, "mm07-worker",
                                      claim["fencing_token"], artifact_type,
                                      content, None, 90)
        return uid, art["artifact_id"]

    def evaluate(self, uid):
        req = urllib.request.Request(
            EVAL_URL + "/evaluate", method="POST",
            data=json.dumps({"unit_id": uid}).encode(),
            headers={"Content-Type": "application/json"})
        try:
            with urllib.request.urlopen(req, timeout=25) as r:
                return r.status, json.loads(r.read())
        except urllib.error.HTTPError as e:
            return e.code, json.loads(e.read() or b"{}")

    def evaluations_of(self, artifact_id):
        with raw() as conn:
            rows = conn.execute(
                "SELECT validator_id, verdict, evidence FROM quality_evaluations"
                " WHERE artifact_id=%s", (artifact_id,)).fetchall()
        return {r["validator_id"]: r for r in rows}

    def add_binding(self, scope, provider, op=None, slot=None,
                    credential_ref=None, params=None):
        with raw() as conn:
            conn.execute(
                "INSERT INTO provider_configs(scope, operation_id,"
                " capability_slot, environment, provider, est_cost_cents,"
                " credential_ref, params, created_by) VALUES"
                " (%s,%s,%s,'test',%s,0,%s,%s,'mm07-battery')",
                (scope, op, slot, provider, credential_ref,
                 json.dumps(params or {})))

    def unit_state(self, uid):
        return self.c.get_unit(uid)["state"]

    def api(self, method, path, body=None, role=None, token=None,
            identity=None):
        req = urllib.request.Request(API_URL + path, method=method)
        if body is not None:
            req.data = json.dumps(body).encode()
            req.add_header("Content-Type", "application/json")
        if role:
            req.add_header("X-Role", role)
        if token:
            req.add_header("X-Role-Token", token)
        if identity:
            req.add_header("X-Identity", identity)
        try:
            with urllib.request.urlopen(req, timeout=15) as r:
                return r.status, json.loads(r.read() or b"{}")
        except urllib.error.HTTPError as e:
            try:
                return e.code, json.loads(e.read() or b"{}")
            except Exception:  # noqa: BLE001
                return e.code, {}


def verdict(case, title, expectation, observed, ok):
    rec = {"case": case, "title": title, "expectation": expectation,
           "observed": observed, "verdict": "PASS" if ok else "FAIL"}
    (RESULTS / f"{case.lower()}.json").write_text(json.dumps(rec, indent=1))
    print(f"{case}: {'PASS' if ok else 'FAIL'} — {title}")
    return rec


def media_bytes(vcodec):
    out = Path(tempfile.mkdtemp(prefix="mm07-battery-media-")) / "clip.mp4"
    subprocess.run(
        ["ffmpeg", "-nostdin", "-v", "error", "-y",
         "-f", "lavfi", "-i", "testsrc2=size=1280x720:rate=10:duration=0.4",
         "-f", "lavfi", "-i", "sine=frequency=440:duration=0.4",
         "-c:v", vcodec, "-pix_fmt", "yuv420p", "-c:a", "aac", "-ar", "48000",
         "-shortest", str(out)], check=True, capture_output=True)
    return out.read_bytes()


def main():
    s = Stack()
    results = []
    try:
        # ---------------------------------------------------------- N1
        s.fresh()
        canon = s.put_input(b'{"canon": "mm07"}', "canon_manifest")
        bad_script = {"kind": "script",
                      "lines": [{"id": "L1", "scene_ref": "SC1",
                                 "beat_ref": "B1", "story_ref": "S1",
                                 "canon_refs": [canon["artifact_id"]],
                                 "text": "x"}],
                      "canon_refs": [canon["artifact_id"]]}  # no trace
        uid, art = s.complete_unit(
            "08.12", envelope(s.pid, "08.12", "script", bad_script), "script",
            inputs=(canon["artifact_id"],), key="n1")
        _, report = s.evaluate(uid)
        evs = s.evaluations_of(art)
        results.append(verdict(
            "N1", "schema-violating deliverable -> BLOCKED",
            "deliverable missing required 'trace': schema_validation FAIL "
            "(deterministic) and unit BLOCKED, never ACCEPTED",
            {"resulting_state": report.get("resulting_state"),
             "unit_state": s.unit_state(uid),
             "schema_verdict": evs["schema_validation"]["verdict"]},
            report.get("resulting_state") == "BLOCKED"
            and evs["schema_validation"]["verdict"] == "FAIL"
            and s.unit_state(uid) == "BLOCKED"))

        # ---------------------------------------------------------- N2
        s.fresh()
        canon = s.put_input(b'{"canon": "mm07"}', "canon_manifest")
        uid, art = s.complete_unit(
            "08.12", envelope(s.pid, "08.12", "script",
                              script_content(canon["artifact_id"],
                                             canon_lines=(0, 1))),
            "script", inputs=(canon["artifact_id"],), key="n2")
        s.add_binding("OPERATION", "deterministic-local", op="08.12")
        _, report = s.evaluate(uid)
        evs = s.evaluations_of(art)
        sem = evs["semantic_evaluation"]["evidence"]
        results.append(verdict(
            "N2", "script canon coverage < threshold -> RUBRIC_FAIL",
            "2/3 lines carry canon_refs (66.67% < 100% threshold): semantic "
            "RUBRIC_FAIL and unit REPAIR_REQUIRED, never ACCEPTED",
            {"resulting_state": report.get("resulting_state"),
             "unit_state": s.unit_state(uid),
             "semantic_status": sem.get("status"),
             "coverage_pct": (sem.get("rubric_stats") or {}).get("coverage_pct"),
             "problems": sem.get("problems")},
            sem.get("status") == "RUBRIC_FAIL"
            and report.get("resulting_state") == "REPAIR_REQUIRED"
            and s.unit_state(uid) != "ACCEPTED"))

        # ---------------------------------------------------------- N3
        s.fresh()
        dims = [{"name": n, "weight": w, "score": 2.0} for n, w in RULE_OF_SIX]
        ros = {"kind": "edit_timeline",
               "segments": [{"shot_ref": "SH1", "order": 1}],
               "rule_of_six": {"dimensions": dims, "weighted_total": 2.0}}
        uid, art = s.complete_unit(
            "12.12", envelope(s.pid, "12.12", "edit_timeline", ros),
            "edit_timeline", key="n3")
        s.add_binding("OPERATION", "deterministic-local", op="12.12",
                      params={"rule_of_six_min_weighted_total": 7.5})
        _, report = s.evaluate(uid)
        evs = s.evaluations_of(art)
        sem = evs["semantic_evaluation"]["evidence"]
        results.append(verdict(
            "N3", "Rule-of-Six weighted total below policy threshold",
            "weighted total 2.0 < binding-param threshold 7.5: RUBRIC_FAIL "
            "and unit not ACCEPTED (lands REPAIR_REQUIRED)",
            {"resulting_state": report.get("resulting_state"),
             "unit_state": s.unit_state(uid),
             "semantic_status": sem.get("status"),
             "problems": sem.get("problems")},
            sem.get("status") == "RUBRIC_FAIL"
            and any("below threshold" in p for p in sem.get("problems", []))
            and s.unit_state(uid) != "ACCEPTED"))

        # ---------------------------------------------------------- N4
        s.fresh()
        good = envelope(s.pid, "05.12", "story_architecture",
                        {"kind": "story_architecture",
                         "story_nodes": [{"id": "S1", "summary": "n"}],
                         "canon_refs": []})
        uid, art = s.complete_unit("05.12", good, "story_architecture",
                                   key="n4")
        with raw() as conn:
            row = conn.execute("SELECT sha256 FROM artifacts WHERE"
                               " artifact_id=%s", (art,)).fetchone()
        # Tamper with the DURABLE object (objects/<sha>) — the bytes the
        # evaluation service loads content-addressably — and any staged
        # candidate copy of the same bytes.
        tampered = 0
        for area in ("objects", "candidates"):
            target = Path(s.store_root) / area / row["sha256"]
            if target.exists():
                target.write_bytes(
                    b'{"kind": "story_architecture", "tampered": true}')
                tampered += 1
        assert tampered >= 1, "store object not found"
        _, report = s.evaluate(uid)
        evs = s.evaluations_of(art)
        tech = evs["deterministic_checks"]["evidence"]
        sha_check = [c for c in tech["checks"]
                     if c["check"] == "sha256_match"][0]
        results.append(verdict(
            "N4", "artifact bytes tampered after registration (hash mismatch)",
            "store bytes replaced post-registration: sha256_match FAIL in "
            "the deterministic technical layer and unit BLOCKED, never "
            "ACCEPTED (the brief's 'continuity FAIL' is this same "
            "dependency_integrity policy surface; the hash check itself "
            "is the technical layer's)",
            {"resulting_state": report.get("resulting_state"),
             "unit_state": s.unit_state(uid),
             "technical_verdict": evs["deterministic_checks"]["verdict"],
             "sha256_match_ok": sha_check["ok"],
             "recorded": sha_check["recorded"][:12],
             "recomputed": sha_check["recomputed"][:12]},
            evs["deterministic_checks"]["verdict"] == "FAIL"
            and sha_check["ok"] is False
            and s.unit_state(uid) == "BLOCKED"))

        # ---------------------------------------------------------- N5
        s.fresh()

        def input_envelope():
            return json.dumps({"production_id": s.pid, "operation_id": "05.12",
                               "input_artifacts": []},
                              sort_keys=True).encode()

        x = s.put_input(input_envelope(), "canon_manifest")
        # The superseded artifact is the unit's PLANNED input; the
        # deliverable content deliberately does not reference it (a
        # content reference to a superseded artifact is the separate
        # technical-layer references_resolve failure). This isolates
        # the continuity path, as in Gate E's continuity scenario.
        uid, art = s.complete_unit(
            "05.12", envelope(s.pid, "05.12", "story_architecture",
                              {"kind": "story_architecture",
                               "story_nodes": [{"id": "S1", "summary": "n"}],
                               "canon_refs": []}),
            "story_architecture", inputs=(x["artifact_id"],), key="n5")
        s.put_input(input_envelope(), "canon_manifest")  # supersedes
        _, report = s.evaluate(uid)
        evs = s.evaluations_of(art)
        cont = evs["continuity_checks"]["evidence"]
        results.append(verdict(
            "N5", "superseded planned input -> REPAIR_REQUIRED",
            "planned canon input superseded by a v2 before evaluation: "
            "continuity FAIL naming the superseded input and unit "
            "REPAIR_REQUIRED, never ACCEPTED",
            {"resulting_state": report.get("resulting_state"),
             "unit_state": s.unit_state(uid),
             "continuity_verdict": evs["continuity_checks"]["verdict"],
             "superseded": [r["artifact_id"] for r in
                            cont.get("superseded_inputs", [])]},
            report.get("resulting_state") == "REPAIR_REQUIRED"
            and evs["continuity_checks"]["verdict"] == "FAIL"
            and s.unit_state(uid) != "ACCEPTED"))

        # ---------------------------------------------------------- N6
        s.fresh()
        uid, art = s.complete_unit(
            "05.12", envelope(s.pid, "05.12", "story_architecture",
                              {"kind": "story_architecture",
                               "story_nodes": [{"id": "S1", "summary": "n"}],
                               "canon_refs": []}),
            "story_architecture", key="n6")
        with raw() as conn:
            conn.execute(
                "INSERT INTO quality_evaluations(artifact_id, validator_id,"
                " method, evidence, verdict, evaluator_identity) VALUES"
                " (%s,'worker_self','self_report','{}','PASS','mm07-worker')",
                (art,))
        state = s.unit_state(uid)
        results.append(verdict(
            "N6", "worker-reported PASS with NO evaluation -> never ACCEPTED",
            "a worker self-assessment PASS exists but /evaluate is never "
            "called: the unit stays VALIDATING (acceptance requires the "
            "evaluation service + human path; worker verdicts are advisory)",
            {"unit_state": state,
             "worker_evaluations": len(s.evaluations_of(art))},
            state == "VALIDATING"))

        # ---------------------------------------------------------- N7
        s.fresh()
        uid, art = s.complete_unit(
            "05.12", envelope(s.pid, "05.12", "story_architecture",
                              {"kind": "story_architecture",
                               "story_nodes": [{"id": "S1", "summary": "n"}],
                               "canon_refs": []}),
            "story_architecture", key="n7")
        status, body = s.api(
            "POST", f"/units/{uid}/validate",
            body={"evaluations": [{"validator": "semantic_evaluation",
                                   "verdict": "PASS",
                                   "evidence": {"deterministic": False}}]},
            role="WORKER", token=WORKER_TOKEN, identity="mallory-worker")
        results.append(verdict(
            "N7", "forged validator verdict (WORKER submits as VALIDATOR)",
            "POST /validate is OPERATOR/VALIDATOR only: WORKER role gets "
            "403, no quality_evaluations rows are written, unit state "
            "unchanged (VALIDATING)",
            {"http_status": status, "response": body,
             "unit_state": s.unit_state(uid),
             "evaluation_rows": len(s.evaluations_of(art))},
            status == 403 and s.unit_state(uid) == "VALIDATING"
            and len(s.evaluations_of(art)) == 0))

        # ---------------------------------------------------------- N8
        s.fresh()
        master = s.put_input(b'{"kind": "master_package", "asset_hashes": []}',
                             "master_package")
        gate = s.c.create_gate(s.pid, "HG4", master["artifact_id"])
        s.c.decide_gate(gate["gate_id"], "REJECTED", "mm07-battery")
        uid = s.c.plan_unit(s.pid, s.run, "14.01", "n8",
                            input_artifact_ids=(master["artifact_id"],))
        status, body = s.api(
            "POST", f"/units/{uid}/claim",
            body={"worker_id": "mm07-worker", "estimated_cents": 100},
            role="WORKER", token=WORKER_TOKEN, identity="mm07-worker")
        with raw() as conn:
            audits = conn.execute(
                "SELECT COUNT(*) AS n FROM audit_events WHERE unit_id=%s"
                " AND event_type='gate_claim_refused'",
                (uid,)).fetchone()["n"]
            attempts = conn.execute(
                "SELECT COUNT(*) AS n FROM action_attempts WHERE unit_id=%s",
                (uid,)).fetchone()["n"]
        results.append(verdict(
            "N8", "HUMAN-REJECTED gate artifact -> downstream claim refused",
            "HG4 REJECTED on the master_package: claiming the dependent "
            "14.01 unit returns 409 with a committed gate_claim_refused "
            "audit event and zero attempts created",
            {"http_status": status, "response": body,
             "gate_claim_refused_audits": audits, "attempts": attempts,
             "unit_state": s.unit_state(uid)},
            status == 409 and audits >= 1 and attempts == 0))

        # ---------------------------------------------------------- N9
        s.fresh()
        uid, art = s.complete_unit("13.03", media_bytes("mpeg4"),
                                   RENDER_TYPE, key="n9-bad")
        _, report = s.evaluate(uid)
        evs = s.evaluations_of(art)
        tech = evs["deterministic_checks"]["evidence"]
        media_chk = [c for c in tech["checks"]
                     if c["check"] == "media_technical_validation"][0]
        uid2, art2 = s.complete_unit("13.03", media_bytes("libx264"),
                                     RENDER_TYPE, key="n9-good")
        _, report2 = s.evaluate(uid2)
        evs2 = s.evaluations_of(art2)
        media_chk2 = [c for c in evs2["deterministic_checks"]["evidence"]["checks"]
                      if c["check"] == "media_technical_validation"][0]
        results.append(verdict(
            "N9", "wrong-codec media at the 13.03 render exit -> BLOCKED",
            "mpeg4 video where the render spec requires h264: "
            "media_technical_validation FAIL carrying VIDEO_CODEC_MISMATCH "
            "and unit BLOCKED; the h264 control PASSes the media check "
            "and is not BLOCKED",
            {"bad": {"resulting_state": report.get("resulting_state"),
                     "unit_state": s.unit_state(uid),
                     "media_ok": media_chk["ok"],
                     "failures": media_chk["failures"]},
             "control": {"resulting_state": report2.get("resulting_state"),
                         "unit_state": s.unit_state(uid2),
                         "media_ok": media_chk2["ok"],
                         "failures": media_chk2["failures"]}},
            media_chk["ok"] is False
            and "VIDEO_CODEC_MISMATCH" in media_chk["failures"]
            and s.unit_state(uid) == "BLOCKED"
            and media_chk2["ok"] is True
            and s.unit_state(uid2) != "BLOCKED"))

        # ---------------------------------------------------------- N10
        s.fresh()
        canon = s.put_input(b'{"canon": "mm07"}', "canon_manifest")
        uid, art = s.complete_unit(
            "08.12", envelope(s.pid, "08.12", "script",
                              script_content(canon["artifact_id"],
                                             payoff_line="L99")),
            "script", inputs=(canon["artifact_id"],), key="n10")
        _, report = s.evaluate(uid)
        evs = s.evaluations_of(art)
        tech = evs["deterministic_checks"]["evidence"]
        ref_chk = [c for c in tech["checks"]
                   if c["check"] == "internal_reference_integrity"][0]
        results.append(verdict(
            "N10", "script payoff pointing at a nonexistent line",
            "trace payoffs reference line L99 which the script does not "
            "declare: internal_reference_integrity FAIL naming L99 and "
            "unit BLOCKED, never ACCEPTED",
            {"resulting_state": report.get("resulting_state"),
             "unit_state": s.unit_state(uid),
             "technical_verdict": evs["deterministic_checks"]["verdict"],
             "dangling": [d["value"] for d in ref_chk["dangling"]]},
            ref_chk["ok"] is False
            and {d["value"] for d in ref_chk["dangling"]} == {"L99"}
            and s.unit_state(uid) == "BLOCKED"))

        # ---------------------------------------------------------- N11
        s.fresh()
        canon = s.put_input(b'{"canon": "mm07"}', "canon_manifest")
        story = s.complete_unit(
            "05.12", envelope(s.pid, "05.12", "story_architecture",
                              {"kind": "story_architecture",
                               "story_nodes": [{"id": "S1", "summary": "n1"},
                                               {"id": "S2", "summary": "n2"}],
                               "canon_refs": [canon["artifact_id"]]}),
            "story_architecture", inputs=(canon["artifact_id"],), key="n11-s")
        beats = s.complete_unit(
            "06.12", envelope(s.pid, "06.12", "beat_graph",
                              {"kind": "beat_graph",
                               "beats": [{"id": "B1", "story_ref": "S1"},
                                         {"id": "B2", "story_ref": "S2"}],
                               "canon_refs": [canon["artifact_id"]]}),
            "beat_graph", inputs=(canon["artifact_id"],), key="n11-b")
        scenes = s.complete_unit(
            "07.12", envelope(s.pid, "07.12", "scene_set",
                              {"kind": "scene_set",
                               "scenes": [
                                   {"id": "SC1", "beat_ref": "B1",
                                    "canon_refs": [canon["artifact_id"]]},
                                   {"id": "SC2", "beat_ref": "B2",
                                    "canon_refs": [canon["artifact_id"]]}],
                               "canon_refs": [canon["artifact_id"]]}),
            "scene_set", inputs=(canon["artifact_id"],), key="n11-sc")
        uid, art = s.complete_unit(
            "08.12", envelope(s.pid, "08.12", "script",
                              script_content(canon["artifact_id"],
                                             scenes=("SC1",))),
            "script", inputs=(canon["artifact_id"],), key="n11")
        _, report = s.evaluate(uid)
        evs = s.evaluations_of(art)
        tech = evs["deterministic_checks"]["evidence"]
        cov_chk = [c for c in tech["checks"]
                   if c["check"] == "input_set_coverage"][0]
        results.append(verdict(
            "N11", "script leaves a scene_set scene uncovered",
            "scene_set CURRENT declares SC1+SC2; the script's lines cover "
            "only SC1: input_set_coverage FAIL naming SC2 and unit "
            "BLOCKED, never ACCEPTED",
            {"resulting_state": report.get("resulting_state"),
             "unit_state": s.unit_state(uid),
             "schema_verdict": evs["schema_validation"]["verdict"],
             "coverage_ok": cov_chk["ok"],
             "uncovered": cov_chk["uncovered"]},
            cov_chk["ok"] is False and cov_chk["uncovered"] == ["SC2"]
            and evs["schema_validation"]["verdict"] == "PASS"
            and s.unit_state(uid) == "BLOCKED"))

        # ---------------------------------------------------------- N12
        s.fresh()
        uid, art = s.complete_unit(
            "05.12", envelope(s.pid, "05.12", "story_architecture",
                              {"kind": "story_architecture",
                               "story_nodes": [{"id": "S1", "summary": "n"}],
                               "canon_refs": []}),
            "story_architecture", key="n12")
        s.add_binding("OPERATION", "openrouter-compatible", op="05.12",
                      credential_ref="MM07_UNSET_EVAL_KEY")
        _, report = s.evaluate(uid)
        evs = s.evaluations_of(art)
        sem = evs["semantic_evaluation"]["evidence"]
        results.append(verdict(
            "N12", "EVALUATION model required while uncredentialed",
            "QA binding resolves to a credential-requiring provider whose "
            "credential is absent: semantic layer REVIEW_REQUIRED "
            "(credential_absent) and unit AWAITING_HUMAN — never "
            "auto-accepted, never auto-rejected",
            {"resulting_state": report.get("resulting_state"),
             "unit_state": s.unit_state(uid),
             "semantic_verdict": evs["semantic_evaluation"]["verdict"],
             "semantic_status": sem.get("status"),
             "semantic_reason": sem.get("reason")},
            evs["semantic_evaluation"]["verdict"] == "REVIEW_REQUIRED"
            and sem.get("reason") == "credential_absent"
            and s.unit_state(uid) == "AWAITING_HUMAN"))
    finally:
        s.close()
    summary = {"battery": "MM-07 negative battery N1-N12",
               "passed": sum(1 for r in results if r["verdict"] == "PASS"),
               "total": len(results),
               "cases": {r["case"]: r["verdict"] for r in results}}
    (RESULTS / "summary.json").write_text(json.dumps(summary, indent=1))
    print(json.dumps(summary, indent=1))
    return 0 if summary["passed"] == summary["total"] == 12 else 1


if __name__ == "__main__":
    sys.exit(main())
