"""MM-07 evaluation policy matrix generator.

Builds evidence/policy_matrix.json + EVALUATION_POLICY_MATRIX.md:
all 192 operations x the prompt's 12 quality dimensions, each
applicable cell naming its verification kind (DETERMINISTIC / RUBRIC /
MEDIA_TECHNICAL / MODEL_EVAL / HUMAN_GATE / NOT_IMPLEMENTED) with the
implementing check or route and its source. Derived from:
  * mm-gate-01 classification.json (registry validator policies,
    named checks, human gates, approval policies, modalities);
  * gate-e evaluation_service/layers.py (implemented layers, checks,
    rubrics — incl. the MM-07 checks);
  * gate-c worker_service/media_tools.py (MM-06 ffprobe validator);
  * mm-gate-02 selection.json (EVALUATION role) + mm-gate-03 registry
    (operation_model_assignments.evaluation_model, PROPOSED);
  * gate-c worker_service/payloads.py (deliverable id-graph shapes).
No scores are produced anywhere in this matrix — kinds and routes only.
"""
import json
from pathlib import Path

HOME = Path.home()
MM = HOME / "workspace/video-factory-master-programme"
CLASSIFICATION = MM / "mm-gate-01/evidence/classification.json"
SELECTION = MM / "mm-gate-02/evidence/selection.json"
OUT_JSON = MM / "mm-gate-07/evidence/policy_matrix.json"
OUT_MD = MM / "mm-gate-07/EVALUATION_POLICY_MATRIX.md"

DIMENSIONS = [
    ("source_canon_fidelity", "Source and canon fidelity"),
    ("character_continuity", "Character continuity"),
    ("narrative_causality", "Narrative causality"),
    ("dialogue_quality", "Dialogue quality"),
    ("script_coherence", "Script coherence"),
    ("narration_fidelity", "Narration fidelity"),
    ("visual_continuity", "Visual continuity"),
    ("shot_coverage", "Shot coverage"),
    ("audio_video_alignment", "Audio-video alignment"),
    ("cross_modal_consistency", "Cross-modal consistency"),
    ("editorial_quality", "Editorial quality"),
    ("derivative_completeness", "Derivative completeness"),
]
DIM_KEYS = [d[0] for d in DIMENSIONS]

MODEL_EVAL_POSTURE = (
    "MODEL_EVAL route: the registry validator policy's named checks route "
    "to the evaluation service's semantic layer; MM-03 "
    "operation_model_assignments carries the op's evaluation_model "
    "(EVALUATION role, status PROPOSED — not promoted). Current posture: "
    "no implemented rubric covers these named checks and real model "
    "judging is not wired (Gate E scope limit), so the semantic layer "
    "returns REVIEW_REQUIRED (NO_RUBRIC / credential_absent / "
    "provider_cannot_judge) and the unit parks at AWAITING_HUMAN. The "
    "dimension is never auto-accepted and never auto-rejected today; "
    "no score is invented for it.")

# Per-step applicable dimensions: dim -> (kind, basis). Kinds are
# today's actual verification routes. Everything not listed for a
# step is N/A with the step's na_reason (modality/stage mismatch).
STEP_DIMS = {
    "01": {},
    "02": {},
    "03": {
        "source_canon_fidelity": ("MODEL_EVAL", "named checks claim_classification_present + world_rule_consistency"),
        "narrative_causality": ("MODEL_EVAL", "named check chronology_consistency"),
    },
    "04": {
        "character_continuity": ("MODEL_EVAL", "named checks identity_uniqueness + distinctiveness + state_continuity"),
    },
    "05": {
        "source_canon_fidelity": ("MODEL_EVAL", "named check canon_validation"),
        "narrative_causality": ("MODEL_EVAL", "named checks causality_check + nq_story_eval"),
    },
    "06": {
        "narrative_causality": ("MODEL_EVAL", "named checks causal_vs_temporal_edges + knowledge_eligibility + setup_payoff_integrity"),
    },
    "07": {
        "narrative_causality": ("MODEL_EVAL", "named checks beat_coverage + entry_exit_state_present + production_feasibility"),
    },
    "08": {
        "source_canon_fidelity": ("MODEL_EVAL", "named check text_fidelity"),
        "narrative_causality": ("MODEL_EVAL", "named checks setup_payoff_integrity + knowledge_eligibility"),
        "dialogue_quality": ("MODEL_EVAL", "named check text_fidelity (dialogue is script text at this step)"),
        "script_coherence": ("MODEL_EVAL", "named checks text_fidelity + duration_estimate"),
    },
    "09": {
        "script_coherence": ("MODEL_EVAL", "named checks script_consistency + scope_consistency"),
    },
    "10": {
        "shot_coverage": ("MODEL_EVAL", "named check coverage_sufficiency; residual gap: no deterministic shots-vs-lines enumeration check is implemented"),
        "visual_continuity": ("MODEL_EVAL", "named check reveal_conceal_check"),
    },
    "11": {
        "character_continuity": ("MODEL_EVAL", "named check identity_continuity"),
        "narration_fidelity": ("MODEL_EVAL", "named check textual_fidelity"),
        "visual_continuity": ("MODEL_EVAL", "named checks identity_continuity + technical_validity"),
        "audio_video_alignment": ("NOT_IMPLEMENTED", "gap: no evaluation-side audio-video alignment measurement exists; dialogue sync is a production action (op 12.06), never an evaluation"),
    },
    "12": {
        "editorial_quality": ("MODEL_EVAL", "named checks cross_modal_qa + rule_of_six_rubric + reveal_timing"),
        "cross_modal_consistency": ("MODEL_EVAL", "named check cross_modal_qa"),
        "dialogue_quality": ("MODEL_EVAL", "named check dialogue_intelligibility"),
        "visual_continuity": ("MODEL_EVAL", "named checks cross_modal_qa + reveal_timing"),
        "audio_video_alignment": ("MODEL_EVAL", "named check cross_modal_qa"),
        "narration_fidelity": ("NOT_IMPLEMENTED", "gap: no implemented check compares mixed dialogue/narration against the script text; dialogue_intelligibility measures intelligibility, not fidelity to script"),
    },
    "13": {
        "editorial_quality": ("HUMAN_GATE", "HG4 master gate binds the master_package artifact id+sha; the human decision is the editorial acceptance route (named check accessibility_rights_audit supports it)"),
        "visual_continuity": ("HUMAN_GATE", "HG4 human review of the master; no automated visual-continuity check exists at the master stage (continuity automation lives at step 12)"),
        "cross_modal_consistency": ("HUMAN_GATE", "HG4 human review of the master package"),
        "audio_video_alignment": ("MEDIA_TECHNICAL", "named check codec_audio_caption_checks, codec/audio half: MM-07 media_technical_validation (MM-06 ffprobe validator) where the artifact carries media; residual gap: the caption half has no implemented validator (NOT_IMPLEMENTED)"),
    },
    "14": {
        "derivative_completeness": ("MODEL_EVAL", "named checks independent_comprehensibility + platform_profile"),
        "cross_modal_consistency": ("MODEL_EVAL", "named checks independent_comprehensibility + platform_profile"),
        "visual_continuity": ("MODEL_EVAL", "named check platform_profile (per-platform adaptation)"),
    },
    "15": {},
    "16": {
        "narrative_causality": ("MODEL_EVAL", "named check causal_claim_check (causal claims in learning records)"),
    },
}

NA_REASONS = {
    "01": "intake/charter step: no narrative, character, or media artifact exists yet; the step's named check (charter_completeness) is an intake-completeness policy, not one of the 12 quality dimensions",
    "02": "rights/vendor step: named checks (rights_decision_present, vendor_policy_check) are authority checks enforced by claim gating, not creative/media quality dimensions",
    "03": "dimension attaches at a later stage (characters step 04, story step 05, script step 08, media steps 10-14)",
    "04": "dimension attaches at a later stage (story step 05, script step 08, media steps 10-14)",
    "05": "dimension attaches at a later stage (script step 08, media steps 10-14) or is not a story-architecture property",
    "06": "dimension attaches at a later stage (scenes step 07, script step 08, media steps 10-14)",
    "07": "dimension attaches at a later stage (script step 08, shots step 10, media steps 11-14)",
    "08": "modality mismatch: the script is a text artifact; visual/shot/AV/derivative dimensions attach at steps 10-14",
    "09": "direction is text planning: no visual, shot, audio, or derivative artifact exists yet (steps 10-14)",
    "10": "dimension attaches at capture/edit (steps 11-13) or is not a shot-planning property",
    "11": "dimension attaches at edit/master (steps 12-13) or is not a capture property",
    "12": "dimension attaches at packaging/release (step 14) or is not an editorial property",
    "13": "dimension was verified at its home stage (script step 08, edit step 12) or attaches at derivatives (step 14)",
    "14": "dimension was verified at its home stage (script step 08, edit step 12, master step 13)",
    "15": "release/authorization step: quality dimensions are verified at steps 13-14 and by the HG5 publication gate (see the op's human_gate field)",
    "16": "learning/analytics records: creative/media dimensions were verified at their home stages; the step's other named check (observation_interpretation_separation) is an analytics-integrity policy",
}

# Per-operation overrides: (op, dim) -> (kind, basis).
OP_OVERRIDES = {
    ("08.12", "source_canon_fidelity"): (
        "RUBRIC", "implemented rubric script_canon_coverage (layers.py): % of script lines carrying canon_refs vs the QA binding's canon_ref_threshold_pct (default 100); unarmed golden set -> even a rubric PASS yields REVIEW_REQUIRED -> AWAITING_HUMAN"),
    ("08.12", "narrative_causality"): (
        "DETERMINISTIC", "MM-07 internal_reference_integrity: the script trace graph (clues planted/payoff, payoffs clue/line, knowledge at) resolves to declared line/clue ids; causal quality beyond graph integrity remains MODEL_EVAL (setup_payoff_integrity)"),
    ("08.12", "script_coherence"): (
        "DETERMINISTIC", "MM-07 input_set_coverage: script lines cover every scene of the CURRENT scene_set; scene/beat/story refs resolve (internal_reference_integrity)"),
    ("08.12", "dialogue_quality"): (
        "HUMAN_GATE", "HG2 script gate binds the script artifact id+sha and a human reads the script; no rubric judges dialogue and the EVALUATION model is uncredentialed, so the human gate is today's dialogue-quality route"),
    ("06.12", "narrative_causality"): (
        "DETERMINISTIC", "MM-07 input_set_coverage: beats cover every story node of the CURRENT story_architecture; story_refs resolve (internal_reference_integrity). Causal quality beyond coverage remains MODEL_EVAL"),
    ("07.12", "narrative_causality"): (
        "DETERMINISTIC", "MM-07 input_set_coverage: scenes cover every beat of the CURRENT beat_graph; beat_refs resolve (internal_reference_integrity). Causal quality beyond coverage remains MODEL_EVAL"),
    ("12.12", "editorial_quality"): (
        "RUBRIC", "implemented rubric rule_of_six (layers.py): six dimensions, weights sum to 100, numeric scores; optional QA-binding param rule_of_six_min_weighted_total sets a score bar where policy defines one (MM-07); unarmed -> PASS yields REVIEW_REQUIRED"),
    ("14.01", "derivative_completeness"): (
        "DETERMINISTIC", "implemented checks prediction_entries_complete (every derivative carries view_range/ctr_band/confidence) + MM-07 internal_reference_integrity (prediction keys resolve to declared derivative ids)"),
    ("14.12", "derivative_completeness"): (
        "DETERMINISTIC", "implemented checks derivative_set_matches_portfolio (package set == portfolio set == upload_manifest files) + MM-07 internal_reference_integrity (manifest entries resolve to declared derivative ids)"),
    ("09.12", "script_coherence"): (
        "DETERMINISTIC", "MM-07 internal_reference_integrity: every direction's line_ref resolves to a line declared by the script input (plus MODEL_EVAL script_consistency for the direction content itself)"),
    ("12.06", "audio_video_alignment"): (
        "MEDIA_TECHNICAL", "the op's synchronized media output is re-validated by MM-07 media_technical_validation (MM-06 ffprobe validator: streams/codecs/sample rate); sync quality beyond media conformance remains MODEL_EVAL (cross_modal_qa)"),
    ("13.03", "audio_video_alignment"): (
        "MEDIA_TECHNICAL", "MM-07 media_technical_validation of the rendered master against the pinned plan's render spec (1280x720, h264 + aac 48 kHz)"),
    ("13.03", "visual_continuity"): (
        "MEDIA_TECHNICAL", "MM-07 media_technical_validation: the rendered master conforms to the plan render spec (codec/dimensions); visual continuity judgment itself remains HUMAN_GATE (HG4)"),
    ("14.08", "narration_fidelity"): (
        "MODEL_EVAL", "the op's contract (adapt narration only with authorized script transformations) routes to the step's semantic named checks; the produced narration audio is additionally conformance-validated by MM-07 media_technical_validation"),
}

MEDIA_OPS = {"12.05", "12.06", "12.07", "12.08", "13.03", "13.05", "13.08",
             "14.06", "14.07", "14.08"}
MEDIA_DIM_OVERRIDES = {
    ("12.05", "visual_continuity"), ("12.07", "visual_continuity"),
    ("12.08", "audio_video_alignment"), ("13.05", "visual_continuity"),
    ("13.08", "visual_continuity"), ("14.06", "visual_continuity"),
    ("14.07", "visual_continuity"),
}
for key in MEDIA_DIM_OVERRIDES:
    OP_OVERRIDES[key] = (
        "MEDIA_TECHNICAL", "the op's media_output is re-validated by MM-07 media_technical_validation (MM-06 ffprobe validator vs the factory MASTER spec / declared master_spec)")
OP_OVERRIDES[("14.08", "audio_video_alignment")] = (
    "MEDIA_TECHNICAL", "the adapted narration audio is re-validated by MM-07 media_technical_validation (audio stream present, 48 kHz, codec by container)")

# Which of the MM-07 deterministic checks apply to an op's shape
# (payloads.py deliverable shapes + layers.py check keying).
MM07_CHECKS = {
    "internal_reference_integrity": {
        "06.12", "07.12", "08.12", "09.12", "10.12", "11.12", "12.12",
        "14.01", "14.12", "15.12", "16.12"},
    "input_set_coverage": {"06.12", "07.12", "08.12"},
    "media_technical_validation": MEDIA_OPS,
}


def main():
    classification = json.loads(CLASSIFICATION.read_text())
    rows_in = classification["rows"]
    selection = json.loads(SELECTION.read_text())
    eval_role = (selection.get("roles") or {}).get("EVALUATION") or {}
    eval_primary = ((eval_role.get("primary") or {}).get("model_id")
                    or "see mm-gate-02 selection.json EVALUATION role")

    rows, gaps = [], []
    counts = {}
    for r in rows_in:
        op, step = r["operation_id"], r["step"]
        vr = r["validation_requirement"]
        dims = {}
        for key in DIM_KEYS:
            cell = OP_OVERRIDES.get((op, key)) or STEP_DIMS.get(step, {}).get(key)
            if cell is None:
                dims[key] = {"applicable": False, "kind": "N/A",
                             "basis": NA_REASONS[step],
                             "source": "modality/stage analysis (mm-gate-01 classification modalities)"}
                continue
            kind, basis = cell
            dims[key] = {"applicable": True, "kind": kind, "basis": basis,
                         "source": ("mm-gate-01 classification "
                                    "validation_requirement (registry "
                                    "validator_policy) + gate-e layers.py "
                                    "implemented checks")}
            counts[kind] = counts.get(kind, 0) + 1
            if kind == "NOT_IMPLEMENTED":
                gaps.append({"operation_id": op, "dimension": key,
                             "gap": basis})
        rows.append({
            "operation_id": op, "station": r["station"], "step": step,
            "title": r["title"],
            "output_artifact_type": r["output_artifact_type"],
            "output_modality": r["output_modality"],
            "execution_class": r["execution_class"],
            "approval_policy": vr.get("approval_policy"),
            "human_gate": vr.get("human_gate"),
            "named_checks": vr.get("named_checks"),
            "implemented_rubric": vr.get("implemented_rubric"),
            "semantic_note": vr.get("semantic_class"),
            "deterministic_base": [
                "schema_validation (envelope + deliverable schemas at step exits and op 14.01; applicability-noted elsewhere)",
                "dependency_integrity (technical layer: sha256/size/parse + references_resolve; continuity layer: planned-input currency + declared-vs-planned)"],
            "mm07_checks": sorted(name for name, ops in MM07_CHECKS.items()
                                  if op in ops),
            "dimensions": dims,
        })

    matrix = {
        "gate": "MM-07",
        "generated_from": [
            "mm-gate-01/evidence/classification.json",
            "gate-e/evaluation_service/layers.py (incl. MM-07 checks)",
            "gate-c/worker_service/media_tools.py (MM-06 validator)",
            "mm-gate-02/evidence/selection.json (EVALUATION role)",
            "mm-gate-03 registry (operation_model_assignments)"],
        "dimensions": [{"key": k, "label": label} for k, label in DIMENSIONS],
        "model_eval_posture": MODEL_EVAL_POSTURE,
        "evaluation_role_primary_model": eval_primary,
        "kind_counts": counts,
        "not_implemented_gaps": gaps,
        "rows": rows,
    }
    OUT_JSON.write_text(json.dumps(matrix, indent=1))

    # ------------------------------------------------------------ markdown
    code = {"DETERMINISTIC": "DET", "RUBRIC": "RUB", "MEDIA_TECHNICAL": "MED",
            "MODEL_EVAL": "MOD", "HUMAN_GATE": "HUM", "NOT_IMPLEMENTED": "GAP",
            "N/A": "—"}
    lines = [
        "# MM-07 — Evaluation Policy Matrix",
        "",
        "All 192 operations × the prompt's 12 quality dimensions. Each "
        "applicable cell names today's actual verification route; nothing "
        "here is a score. Generated by `tools/build_policy_matrix.py` "
        "from the sources listed in `evidence/policy_matrix.json`.",
        "",
        "Kinds: **DET** DETERMINISTIC (implemented deterministic check) · "
        "**RUB** RUBRIC (implemented deterministic rubric) · **MED** "
        "MEDIA_TECHNICAL (MM-06 ffprobe validator via MM-07) · **MOD** "
        "MODEL_EVAL (semantic named-check route; see posture) · **HUM** "
        "HUMAN_GATE (mandatory human gate is the route) · **GAP** "
        "NOT_IMPLEMENTED (named gap) · **—** N/A (modality/stage).",
        "",
        f"MODEL_EVAL posture: {MODEL_EVAL_POSTURE}",
        "",
        f"EVALUATION role primary (MM-02 selection): `{eval_primary}` "
        "(PROPOSED in the MM-03 registry; promotion is an owner action).",
        "",
        "Every operation additionally carries the deterministic base: "
        "schema_validation + dependency_integrity (technical sha256/"
        "reference checks + continuity currency checks), and the human "
        "gate / approval policy recorded per row in the JSON.",
        "",
        "## Cell counts (applicable cells only)",
        "",
        "| Kind | Cells |",
        "|---|---|",
    ]
    for kind in ("DETERMINISTIC", "RUBRIC", "MEDIA_TECHNICAL", "MODEL_EVAL",
                 "HUMAN_GATE", "NOT_IMPLEMENTED"):
        lines.append(f"| {kind} | {counts.get(kind, 0)} |")
    lines += ["", "## NOT_IMPLEMENTED gaps (carried to the register)", ""]
    by_gap = {}
    for g in gaps:
        by_gap.setdefault(g["gap"], []).append(g)
    for gap, gs in sorted(by_gap.items()):
        ops = ", ".join(f"{g['operation_id']} ({g['dimension']})" for g in gs)
        lines.append(f"- **{gap}** — {ops}")
    for step in sorted({r['step'] for r in rows}):
        lines += ["", f"## Step {step}", "",
                  "| Op | " + " | ".join(k.replace('_', ' ')[:12]
                                          for k in DIM_KEYS) + " |",
                  "|---|" + "---|" * 12]
        for r in [x for x in rows if x["step"] == step]:
            cells = [code[r["dimensions"][k]["kind"]] for k in DIM_KEYS]
            lines.append(f"| {r['operation_id']} | " + " | ".join(cells) + " |")
    lines += ["", "Per-cell bases, sources, named checks, human gates, "
              "and MM-07 check applicability: `evidence/policy_matrix.json`."]
    OUT_MD.write_text("\n".join(lines) + "\n")
    print(f"rows={len(rows)} counts={counts} gaps={len(gaps)}")
    print(f"wrote {OUT_JSON} and {OUT_MD}")


if __name__ == "__main__":
    main()
