# GATE MM-03 — INDEPENDENT VERIFIER REPORT

**Verdict: MM-03 PASS recommended — all six brief items verified on a fresh
chain-built scratch DB (`mm03_verify_scratch`, dropped after use) + my own
API instance (port 8853); defects NONE; one MINOR observation (O1).**
Harness, results, probes, and suite logs:
[verify/](sandbox://workspace/video-factory-master-programme/mm-gate-03/evidence/verify/)
(`verify_mm03.py`, `results.json`, `probe2_concurrency.py`, `probe2.json`,
`logs/g3.log`, `logs/worker.log`, `logs/g9.log`).

## Item 1 — Seeding (run twice): PASS (9/9)
First run inserted {models 457, policies 7, assignments 192}. Counts after
seeding: **providers 3** (`deterministic-local`, `mock`,
`openrouter-compatible`), **models 457**, **model_policies 7 — all
PROPOSED**, **operation_model_assignments 192** (72 PROPOSED model-bound +
120 NONE, **0 ACTIVE**), **benchmark_results 0 rows**. Second run inserted
**nothing** (all-zero inserted counts), row counts identical, and the
full-content hash over providers/models/policies/assignments/health was
identical across runs.

## Item 2 — Zero effect while PROPOSED: PASS (3/3)
With every policy PROPOSED, claiming 08.12 against the slice binding
resolved exactly today's binding (`anthropic/claude-haiku-4.5`,
openrouter-compatible, OPERATION scope) and the attempt's resolved-config
snapshot contains **no `model_assignment` key**. PROPOSED governance data
is inert at claim, as locked.

## Item 3 — Promotion authority: PASS (11/11)
- WORKER promote → **403**; SCHEDULER promote → **403**; each left exactly
  one committed `policy_action_refused` audit row naming the role; the
  policy stayed PROPOSED.
- OPERATOR promote → **200 ACTIVE, 23 bindings written** (1 STATION + 22
  OPERATION).
- Three `provider_configs` rows spot-checked against **selection.json
  data_version 1.0.1** (read independently, not from builder constants):
  STATION 3 binding = role primary `anthropic/claude-sonnet-4.5`;
  OPERATION 08.12 = assignment primary `anthropic/claude-opus-4.8` with
  est/max 25¢; OPERATION 08.05 = assignment primary
  `anthropic/claude-opus-4.8`; all carry `params.policy_id` = the promoted
  policy; the pre-promotion haiku slice row was superseded (no active
  haiku 08.12 row remains).
- `policy_events` holds the PROMOTE row with the recorded actor and my
  exact approval note.
- **Restart recovery (verified here):** registry reads
  (`/model-policies`, `/model-assignments?status=ACTIVE`,
  `/provider-health`, `/models?provider=anthropic`) were byte-identical
  before and after an API restart against the same DB.

## Item 4 — Pinning + ceiling: PASS (10/10)
- Claim under ACTIVE v1 pins `model_assignment` into the snapshot:
  policy `policy-station-03-1.0.0`, `matrix_version 1.0.0`, primary
  `anthropic/claude-opus-4.8`, ceiling 25.
- I authored a v2 fixture policy as data (cloned assignments at matrix
  2.0.0, 08.12 primary changed to `anthropic/claude-sonnet-4.5`) and
  promoted it (supersedes v1). The in-flight v1 attempt was then
  completed; its stored `resolved_config` and `resolved_config_hash` are
  **byte-identical** to the pre-promotion snapshot — the pin does not
  move. A new claim pins v2 (matrix 2.0.0, sonnet).
- Ceiling: with the ACTIVE 08.05 assignment's ceiling set to 10 (below
  its live binding estimate of 100, read from the DB), claim → **409**
  with a typed error body naming the ceiling, **zero attempts** written,
  and a committed `assignment_ceiling_exceeded` audit carrying
  estimate 100 / ceiling 10. Ceiling restored → claim succeeds (200).

## Item 5 — Rollback + concurrency: PASS (rollback 5/5; concurrency via adjudication probe)
- Rollback of v2 → 200, `restored_policy_id` = v1; v1 ACTIVE again, v2
  RETIRED; live bindings equal the v1 policy's models again (08.12 opus,
  STATION sonnet, policy tags = v1); `policy_events` contain the full
  ordered chain PROMOTE(v1) < PROMOTE(v2) < ROLLBACK + REACTIVATE.
- Concurrency — first barrier-synchronized pair in my harness happened
  to **serialize before the critical section** and both returned 200
  (the second superseding the first; exactly one ACTIVE, complete
  PROMOTE/RETIRE event chain — raw result preserved in results.json).
  Because that interleaving does not test the guard, I adjudicated
  deterministically in `probe2_concurrency.py`:
  - Holding the role advisory lock (`mm03:policy:STATION_01`) in an
    external session, a promotion attempt → **409 "already in flight"**,
    policy untouched; after release the same promotion → 200.
  - Three further barrier rounds returned [200,409], [200,409],
    [200,200]; every round ended with **exactly one ACTIVE** policy and
    exactly one PROMOTE event per successful promotion.
  The fail-fast guard works exactly as designed (`pg_try_advisory_xact_lock`);
  a both-200 outcome occurs only when the calls never actually overlap,
  in which case the second promotion is an ordinary, fully audited
  supersession. No invariant was violated in any interleaving.
  → **O1 (MINOR, observation):** the API does not (and by its documented
  TRY-lock design does not claim to) guarantee exactly one HTTP 200 for
  simultaneous promotion calls — it guarantees at most one ACTIVE policy,
  consistent bindings, and a complete event chain. If a future gate
  requires strict one-success semantics under simultaneity, that needs a
  generation/CAS mechanism; nothing in MM-03's PASS condition requires it.

## Item 6 — Regression spot + surface checks: PASS
From my own serial runs (logs in `verify/logs/`):
- **g3: Ran 36, OK** — the suite exercises the full contract:
  `api_contract.json` reads **`contract_version` 1.8.0 with 45 endpoints**
  (confirmed directly in the file).
- **worker: Ran 40, OK.**
- **g9: Ran 10, OK** — and the persisted full-run production in
  `g9_fullrun_scratch` confirms it directly: **18 units ACCEPTED, 18
  FINALIZED rows totalling 1620¢** (ESTIMATED 1800), so the registry's
  inert-by-default claim integration did not disturb the deterministic
  baseline.
- Migrations on disk max at **016** (`016_mm03_model_registry.sql`);
  coordinator `TRANSITIONS` still exactly **30** entries (import check).

## MM-03 verdict against the PASS condition
*"Registry persistence, version pinning, concurrent updates, promotion,
rollback, and restart recovery pass automated tests."*
- Persistence — seeded registry (457/7/192) survives API restart with
  byte-identical reads. **Verified.**
- Version pinning — ACTIVE assignment pins into claim snapshots and is
  immutable across a v1→v2 promotion. **Verified.**
- Concurrent updates — fail-fast typed conflict under genuine overlap;
  exactly one ACTIVE in every interleaving. **Verified** (O1 noted).
- Promotion — OPERATOR-only, refusal-audited, writes exactly the
  selection's bindings. **Verified.**
- Rollback — restores the prior policy's bindings with the full event
  chain preserved. **Verified.**
- Restart recovery — verified in item 3. **Verified.**

**MM-03: PASS.** No real provider call was made or attempted; no
credential exists in this environment (unchanged). Verifier-side harness
incidents (a wrong column name in my first probe, psycopg placeholder
escaping, and duplicate-key collisions on crashed probe re-runs) were
mine alone, are disclosed in the probe files, and touched only my
scratch DB.
