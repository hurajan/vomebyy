# MM-03 — CHANGED ASSERTIONS

## Pre-existing product tests

**One file changed: `video-factory-g3/tests/test_api_contract.py`.**
No existing assertion was altered, weakened, or removed.

1. The `server_fixture` import line gains `make_dsn` (used by the new
   block to seed one throwaway policy row directly in the scratch DB).
2. A new block at the end of `test_all_endpoints` exercises the 8 MM-03
   endpoints (contract 1.8.0). This is **required by the test's own
   design**: it ends with an assertion that every endpoint in
   `contracts/api_contract.json` was exercised (`want - covered == ∅`),
   so adding contract endpoints without exercising them fails the suite
   by construction. The new block asserts: registry reads return the
   contract keys against empty (migration-only) tables; an OPERATOR
   promote of a station-less, assignment-less fixture policy returns
   ACTIVE with `bindings_written == 0`; its rollback returns RETIRED
   with `restored_policy_id is None`. The full binding/pinning/ceiling
   behavior is asserted in MM-03's own battery
   (`mm-gate-03/tests/test_mm03.py`), not here.

No other suite's test files were touched. All other product changes are
additive: migration 016 (new tables only), one apply line in
`g2/tools/setup_db.py`, the new `coordinator/model_registry.py`, the
MM-03 claim-integration block in `coordinator.py` (inert when no ACTIVE
assignment exists), the MM-03 routes in `g3/api/server.py`, and the
contract file (version 1.7.0 → 1.8.0, +8 endpoints, notes appended).

## Harness incidents during the battery (own new files only)

- **Redaction trap (recorded per standing practice):** the dev scratch
  password literal typed into `mm-gate-03/tools/seed_registry.py` and a
  `token=<…>` literal in `test_mm03.py` were mangled at write time by
  the display-redaction layer (the Gate D/E/G incident class). Repairs:
  the seeder now sources the password at runtime from the canonical
  fixture (`g2/tools/setup_db.py` role-creation line) and carries no
  credential literal; the harness uses `token=None` + role headers.
  No product file was affected.
- **Harness bug 1:** planning several units for one operation in one
  run collided with the factory's
  `(production_id, operation_id, unit_key, run_id)` uniqueness — the
  harness now assigns a distinct `unit_key` per scenario unit. Product
  behavior correct as-is.
- **Harness bug 2:** the v2 assignment clone initially copied the v1
  rows' ACTIVE status and tripped the migration-016 partial unique
  index (one ACTIVE assignment per operation) — the index working as
  designed. The clone now lands as PROPOSED/NONE.

## Interpretation recorded

- `benchmark_results` ships empty and the seeder writes no rows to it:
  MM-02 labeled all quality claims UNVERIFIED (no task-specific
  comparative evidence exists), so any seeded score would be
  fabricated. The table exists for MM-07+ to populate from real runs.
- Policy *creation* (new versions) is governance data entry (SQL /
  future MM-09 surface); the brief's API surface is promote / rollback
  / reads, and the battery authors v2/v3/v4 policy rows as fixtures,
  exactly as the contract test does. Promotion itself — the governed
  act — is API-only and OPERATOR-gated in every test.
