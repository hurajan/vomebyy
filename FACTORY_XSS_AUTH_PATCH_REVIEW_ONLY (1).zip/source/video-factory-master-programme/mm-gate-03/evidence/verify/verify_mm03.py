#!/usr/bin/env python3
"""MM-03 INDEPENDENT VERIFIER harness (items 1-5; item 6 = suites run
separately). Fresh chain-built scratch DB + own API port; own stub-free
probes; assertions read from the DB and API directly. Serial.
Writes results.json beside this file."""
import hashlib
import json
import os
import subprocess
import sys
import threading
import time
import urllib.request
from pathlib import Path

import psycopg
from psycopg.rows import dict_row

HERE = Path(__file__).resolve().parent
GATE = HERE.parents[1]
G3_TESTS = Path.home() / "workspace/video-factory-g3/tests"
sys.path.insert(0, str(G3_TESTS))
sys.path.insert(0, str(Path.home() / "workspace/video-factory-g2"))
from server_fixture import Client, make_dsn, start_server, stop_server
from coordinator.coordinator import Coordinator

DB, PORT = "mm03_verify_scratch", 8853
G2PY = str(Path.home() / "workspace/video-factory-g2/.venv/bin/python")
SEEDER = GATE / "tools" / "seed_registry.py"
SELECTION = Path.home() / "workspace/video-factory-master-programme/mm-gate-02/evidence/selection.json"
DSN = make_dsn(DB)
ROLE_ENV = {"FACTORY_WORKER_TOKEN": "mm03v-worker-token",
            "FACTORY_SCHEDULER_TOKEN": "mm03v-scheduler-token",
            "FACTORY_VALIDATOR_TOKEN": "mm03v-validator-token"}
V1 = "policy-station-03-1.0.0"
V2 = "policy-station-03-2.0.0"
WORKER = "mm03v-worker"

results = {}


class Item:
    def __init__(self, key):
        self.key = key
        self.checks = []

    def check(self, label, ok, detail=""):
        self.checks.append({"name": label, "ok": bool(ok),
                            "detail": str(detail)[:600]})
        if not ok:
            print(f"  FAIL {self.key}: {label} -- {detail}")

    def done(self):
        v = "PASS" if all(c["ok"] for c in self.checks) else "FAIL"
        results[self.key] = {"verdict": v, "checks": self.checks}
        print(f"{self.key}: {v} "
              f"({sum(c['ok'] for c in self.checks)}/{len(self.checks)})")


def db(sql, params=(), one=False):
    with psycopg.connect(DSN, row_factory=dict_row) as conn:
        cur = conn.execute(sql, params)
        rows = [dict(r) for r in cur.fetchall()] if cur.description else []
        conn.commit()
    return rows[0] if one and rows else rows


def run_seeder():
    r = subprocess.run([G2PY, str(SEEDER), DB], capture_output=True, text=True)
    assert r.returncode == 0, f"seeder failed: {r.stdout} {r.stderr}"
    return json.loads(r.stdout.strip().splitlines()[-1])


def registry_hash():
    h = hashlib.sha256()
    for t, key in (("providers", "name"), ("models", "model_id"),
                   ("model_policies", "policy_id"),
                   ("operation_model_assignments", "operation_id, matrix_version"),
                   ("provider_health", "provider")):
        try:
            rows = db(f"SELECT * FROM {t} ORDER BY {key}")
        except Exception:
            rows = db(f"SELECT * FROM {t}")
        h.update(json.dumps(rows, sort_keys=True, default=str).encode())
    return h.hexdigest()


def table_counts():
    out = {}
    for t in ("providers", "models", "model_policies",
              "operation_model_assignments", "benchmark_results"):
        out[t] = db(f"SELECT COUNT(*) AS n FROM {t}", one=True)["n"]
    return out


def start_api_only():
    root = Path.home() / "workspace/video-factory-g3"
    env = dict(os.environ, FACTORY_DSN=DSN, FACTORY_PORT=str(PORT), **ROLE_ENV)
    proc = subprocess.Popen([str(root / ".venv" / "bin" / "python"),
                             str(root / "api" / "server.py")],
                            env=env, stdout=subprocess.DEVNULL,
                            stderr=subprocess.DEVNULL)
    client = Client(PORT)
    for _ in range(100):
        try:
            status, _ = client.call("GET", "/health")
            if status == 200:
                return proc, client
        except Exception:
            pass
        time.sleep(0.1)
    proc.kill()
    raise RuntimeError("server did not come up")


def main():
    sel = json.loads(SELECTION.read_text())
    sel_assign = {a["operation_id"]: a for a in sel["assignments"]}
    sel_role_primary = sel["roles"]["STATION_03"]["primary"]["model_id"]

    proc, api = start_server(DB, PORT, env_extra=ROLE_ENV)
    try:
        # ---------- ITEM 1: seeding (run twice)
        it = Item("item1_seeding")
        seed1 = run_seeder()
        counts1 = table_counts()
        h1 = registry_hash()
        statuses = {r["status"]: r["n"] for r in db(
            "SELECT status, COUNT(*) AS n FROM operation_model_assignments"
            " GROUP BY status")}
        pol_statuses = {r["status"]: r["n"] for r in db(
            "SELECT status, COUNT(*) AS n FROM model_policies GROUP BY status")}
        prov_names = sorted(r["name"] for r in db("SELECT name FROM providers"))
        it.check("first run inserted the full seed",
                 seed1["inserted"] == {"models": 457, "policies": 7,
                                       "assignments": 192},
                 seed1["inserted"])
        it.check("providers == 3 (execution providers)",
                 counts1["providers"] == 3 and prov_names == [
                     "deterministic-local", "mock", "openrouter-compatible"],
                 prov_names)
        it.check("models == 457", counts1["models"] == 457, counts1)
        it.check("policies == 7, all PROPOSED",
                 counts1["model_policies"] == 7
                 and pol_statuses == {"PROPOSED": 7}, pol_statuses)
        it.check("assignments == 192 (72 PROPOSED model-bound + 120 NONE, 0 ACTIVE)",
                 counts1["operation_model_assignments"] == 192
                 and statuses.get("PROPOSED") == 72
                 and statuses.get("NONE") == 120
                 and statuses.get("ACTIVE", 0) == 0, statuses)
        it.check("benchmark_results == 0 rows",
                 counts1["benchmark_results"] == 0, counts1)
        seed2 = run_seeder()
        counts2 = table_counts()
        h2 = registry_hash()
        it.check("second run inserted nothing",
                 seed2["inserted"] == {"models": 0, "policies": 0,
                                       "assignments": 0}, seed2["inserted"])
        it.check("counts identical after second run", counts1 == counts2,
                 (counts1, counts2))
        it.check("content hash identical across runs", h1 == h2,
                 f"{h1} vs {h2}")
        it.done()

        # ---------- fixture production + slice binding
        _, out = api.call("POST", "/productions",
                          {"title": "mm03-verify", "hard_ceiling_cents": 100000,
                           "soft_ceiling_cents": 100000})
        pid = out["production_id"]
        _, out = api.call("POST", f"/productions/{pid}/runs", {"kind": "FULL"})
        run_id = out["run_id"]
        status, out = api.call("POST", "/configs", {
            "scope": "OPERATION", "operation_id": "08.12",
            "provider": "openrouter-compatible",
            "model": "anthropic/claude-haiku-4.5", "est_cost_cents": 25,
            "credential_ref": "OPENROUTER_API_KEY",
            "params": {"temperature": 0.7, "max_tokens": 2000}})
        assert status == 201, out

        _uk = [0]

        def plan(op):
            _uk[0] += 1
            _, o = api.call("POST", f"/productions/{pid}/units",
                            {"operation_id": op, "run_id": run_id,
                             "unit_key": f"mm03v-{_uk[0]}"})
            return o["unit_id"]

        def claim(uid):
            return api.call("POST", f"/units/{uid}/claim",
                            {"worker_id": WORKER})

        def last_attempt(uid):
            _, o = api.call("GET", f"/units/{uid}/attempts")
            return o["attempts"][-1]

        # ---------- ITEM 2: zero effect pre-promotion
        it = Item("item2_zero_effect")
        uid_b = plan("08.12")
        st, claim_b = claim(uid_b)
        it.check("claim 08.12 succeeds with all policies PROPOSED",
                 st == 200, claim_b)
        snap_b = last_attempt(uid_b)["resolved_config"] or {}
        it.check("resolution == today's slice binding (haiku / openrouter-compatible)",
                 snap_b.get("model") == "anthropic/claude-haiku-4.5"
                 and snap_b.get("provider") == "openrouter-compatible", snap_b)
        it.check("attempt snapshot carries NO model_assignment pin",
                 "model_assignment" not in snap_b, list(snap_b))
        it.done()

        # ---------- ITEM 3: promotion authority + spot-checks + restart
        it = Item("item3_promotion_authority")
        rh = lambda role, tok: {"X-Role": role, "X-Role-Token": tok}
        st, _ = api.call("POST", f"/model-policies/{V1}/promote",
                         {"approval_note": "worker attempt"}, token=None,
                         headers=rh("WORKER", ROLE_ENV["FACTORY_WORKER_TOKEN"]))
        it.check("WORKER promote -> 403", st == 403, st)
        st, _ = api.call("POST", f"/model-policies/{V1}/promote",
                         {"approval_note": "scheduler attempt"}, token=None,
                         headers=rh("SCHEDULER", ROLE_ENV["FACTORY_SCHEDULER_TOKEN"]))
        it.check("SCHEDULER promote -> 403", st == 403, st)
        refusals = db("SELECT payload FROM audit_events"
                      " WHERE event_type='policy_action_refused'"
                      " AND payload->>'policy_id'=%s", (V1,))
        it.check("one committed policy_action_refused audit per refusal (WORKER+SCHEDULER)",
                 len(refusals) == 2
                 and {r["payload"].get("role") for r in refusals}
                 == {"WORKER", "SCHEDULER"}, refusals)
        it.check("policy still PROPOSED after refusals",
                 db("SELECT status FROM model_policies WHERE policy_id=%s",
                    (V1,), one=True)["status"] == "PROPOSED")
        st, out = api.call("POST", f"/model-policies/{V1}/promote",
                           {"approval_note": "MM-03 verifier approval"})
        it.check("OPERATOR promote -> 200 ACTIVE, 23 bindings written",
                 st == 200 and out.get("status") == "ACTIVE"
                 and out.get("bindings_written") == 23, out)
        st_row = db("SELECT * FROM provider_configs WHERE active AND scope='STATION'"
                    " AND station=3", one=True)
        it.check("spot-check 1: STATION 3 binding model == selection.json role primary",
                 st_row and st_row["model"] == sel_role_primary
                 and st_row["params"].get("policy_id") == V1,
                 (st_row or {}).get("model"))
        op12 = db("SELECT * FROM provider_configs WHERE active AND scope='OPERATION'"
                  " AND operation_id='08.12'", one=True)
        it.check("spot-check 2: 08.12 binding model == selection.json assignment primary, est/max 25",
                 op12 and op12["model"] == sel_assign["08.12"]["primary"]
                 and op12["est_cost_cents"] == 25
                 and op12["max_cost_cents"] == 25
                 and op12["params"].get("policy_id") == V1,
                 {k: (op12 or {}).get(k) for k in ("model", "est_cost_cents", "max_cost_cents")})
        op05 = db("SELECT * FROM provider_configs WHERE active AND scope='OPERATION'"
                  " AND operation_id='08.05'", one=True)
        it.check("spot-check 3: 08.05 binding model == selection.json assignment primary",
                 op05 and op05["model"] == sel_assign["08.05"]["primary"]
                 and op05["params"].get("policy_id") == V1,
                 (op05 or {}).get("model"))
        it.check("pre-promotion slice binding superseded (no active haiku 08.12 row)",
                 db("SELECT COUNT(*) AS n FROM provider_configs WHERE active"
                    " AND scope='OPERATION' AND operation_id='08.12'"
                    " AND model='anthropic/claude-haiku-4.5'", one=True)["n"] == 0)
        ev = db("SELECT * FROM policy_events WHERE policy_id=%s AND action='PROMOTE'",
                (V1,), one=True)
        actor = (ev or {}).get("actor") or (ev or {}).get("created_by")
        it.check("policy_events PROMOTE row carries actor + the approval note",
                 ev is not None and ev.get("note") == "MM-03 verifier approval"
                 and bool(actor), {"actor": actor, "note": (ev or {}).get("note")})

        def registry_dump(client):
            dump = {}
            for path in ("/model-policies", "/model-assignments?status=ACTIVE",
                         "/provider-health", "/models?provider=anthropic"):
                s2, o2 = client.call("GET", path)
                assert s2 == 200, (path, o2)
                dump[path] = o2
            return json.dumps(dump, sort_keys=True, default=str)
        before = registry_dump(api)
        stop_server(proc)
        proc, api = start_api_only()
        after = registry_dump(api)
        it.check("RESTART: registry reads byte-identical across API restart",
                 before == after, f"{len(before)} vs {len(after)} bytes")
        it.done()

        # ---------- ITEM 4: pinning + ceiling
        it = Item("item4_pinning_ceiling")
        uid_d = plan("08.12")
        st, claim_d = claim(uid_d)
        att_d = last_attempt(uid_d)
        snap_d = att_d["resolved_config"] or {}
        ma = snap_d.get("model_assignment") or {}
        it.check("claim under ACTIVE v1 pins the assignment (policy, matrix 1.0.0, model, ceiling)",
                 st == 200 and ma.get("policy_id") == V1
                 and ma.get("matrix_version") == "1.0.0"
                 and ma.get("primary_model") == sel_assign["08.12"]["primary"]
                 and ma.get("max_cost_cents") == 25, ma)
        it.check("resolved config model == v1 assignment primary",
                 snap_d.get("model") == sel_assign["08.12"]["primary"],
                 snap_d.get("model"))
        db("INSERT INTO model_policies(policy_id, role, station, primary_model,"
           " fallback_model, evaluation_model, version, status, created_by)"
           " VALUES (%s,'STATION_03',3,'anthropic/claude-sonnet-4.5',"
           " 'google/gemini-2.5-pro','google/gemini-2.5-pro','2.0.0',"
           " 'PROPOSED','mm03-verifier')", (V2,))
        db("INSERT INTO operation_model_assignments(operation_id, role,"
           " policy_id, station, execution_class, primary_model, fallback_model,"
           " evaluation_model, matrix_version, max_cost_cents, cost_source,"
           " null_reason, status) SELECT operation_id, role, %s, station,"
           " execution_class, primary_model, fallback_model, evaluation_model,"
           " '2.0.0', max_cost_cents, cost_source, null_reason,"
           " CASE WHEN primary_model IS NULL THEN 'NONE' ELSE 'PROPOSED' END"
           " FROM operation_model_assignments WHERE role='STATION_03'"
           " AND matrix_version='1.0.0'", (V2,))
        db("UPDATE operation_model_assignments SET"
           " primary_model='anthropic/claude-sonnet-4.5'"
           " WHERE operation_id='08.12' AND matrix_version='2.0.0'")
        st, out = api.call("POST", f"/model-policies/{V2}/promote",
                           {"approval_note": "v2 promotion (verifier)"})
        it.check("v2 promotion succeeds and supersedes v1",
                 st == 200 and out.get("superseded_policy_id") == V1, out)
        coord = Coordinator(DSN, actor="mm03-verifier")
        coord.complete_attempt(uid_d, WORKER, claim_d["fencing_token"],
                               "script", b'{"kind":"script","lines":[]}',
                               "mm03v://script-v1", 25)
        coord.close()
        att_after = last_attempt(uid_d)
        it.check("completed v1 attempt's pinned snapshot unchanged after v2 promotion",
                 att_after["resolved_config"] == snap_d
                 and att_after["resolved_config_hash"] == att_d["resolved_config_hash"],
                 att_after["resolved_config_hash"])
        uid_d2 = plan("08.12")
        st, _ = claim(uid_d2)
        ma2 = (last_attempt(uid_d2)["resolved_config"] or {}).get("model_assignment") or {}
        it.check("new claim pins v2 (matrix 2.0.0, sonnet for 08.12)",
                 st == 200 and ma2.get("policy_id") == V2
                 and ma2.get("matrix_version") == "2.0.0"
                 and ma2.get("primary_model") == "anthropic/claude-sonnet-4.5", ma2)
        # ceiling (v2 ACTIVE assignments): 08.05 binding estimate read live
        b05 = db("SELECT est_cost_cents FROM provider_configs WHERE active"
                 " AND scope='OPERATION' AND operation_id='08.05'", one=True)
        est05 = b05["est_cost_cents"]
        db("UPDATE operation_model_assignments SET max_cost_cents=10"
           " WHERE operation_id='08.05' AND status='ACTIVE'")
        uid_e = plan("08.05")
        st, out = claim(uid_e)
        body_txt = json.dumps(out).lower()
        it.check(f"claim with ceiling 10 < binding estimate {est05} refused (409)",
                 st == 409 and est05 > 10, out)
        it.check("refusal is typed (error body names the ceiling/assignment)",
                 "ceiling" in body_txt or "assignment" in body_txt, out)
        it.check("zero attempts written for the refused claim",
                 db("SELECT COUNT(*) AS n FROM action_attempts WHERE unit_id=%s",
                    (uid_e,), one=True)["n"] == 0)
        audit = db("SELECT payload FROM audit_events WHERE unit_id=%s"
                   " AND event_type='assignment_ceiling_exceeded'", (uid_e,), one=True)
        it.check("assignment_ceiling_exceeded audit carries estimate + ceiling",
                 audit and audit["payload"].get("estimate_cents") == est05
                 and audit["payload"].get("assignment_max_cost_cents") == 10, audit)
        db("UPDATE operation_model_assignments SET max_cost_cents=%s"
           " WHERE operation_id='08.05' AND status='ACTIVE'", (est05,))
        st, out = claim(uid_e)
        it.check("claim succeeds after ceiling restored", st == 200, out)
        it.done()

        # ---------- ITEM 5: rollback + concurrency
        it = Item("item5_rollback_concurrency")
        st, out = api.call("POST", f"/model-policies/{V2}/rollback",
                           {"note": "verifier rollback"})
        it.check("rollback -> 200, restores v1",
                 st == 200 and out.get("restored_policy_id") == V1, out)
        it.check("v1 ACTIVE again, v2 RETIRED",
                 db("SELECT status FROM model_policies WHERE policy_id=%s",
                    (V1,), one=True)["status"] == "ACTIVE"
                 and db("SELECT status FROM model_policies WHERE policy_id=%s",
                        (V2,), one=True)["status"] == "RETIRED")
        op12r = db("SELECT * FROM provider_configs WHERE active AND scope='OPERATION'"
                   " AND operation_id='08.12'", one=True)
        strr = db("SELECT * FROM provider_configs WHERE active AND scope='STATION'"
                  " AND station=3", one=True)
        it.check("bindings equal the v1 policy's models again (08.12 opus + STATION sonnet)",
                 op12r and op12r["model"] == sel_assign["08.12"]["primary"]
                 and op12r["params"].get("policy_id") == V1
                 and strr and strr["model"] == sel_role_primary,
                 {"op12": (op12r or {}).get("model"),
                  "station": (strr or {}).get("model")})
        chain = db("SELECT policy_id, action FROM policy_events"
                   " WHERE policy_id IN (%s,%s) ORDER BY at, event_id", (V1, V2))
        seq = [(r["policy_id"], r["action"]) for r in chain]
        i_p1 = seq.index((V1, "PROMOTE")) if (V1, "PROMOTE") in seq else -1
        i_p2 = seq.index((V2, "PROMOTE")) if (V2, "PROMOTE") in seq else -1
        i_rb = max((i for i, (_, a) in enumerate(seq) if a == "ROLLBACK"),
                   default=-1)
        i_ra = max((i for i, (_, a) in enumerate(seq) if a == "REACTIVATE"),
                   default=-1)
        it.check("policy_events hold the full chain in order (PROMOTE v1 < PROMOTE v2 < ROLLBACK/REACTIVATE)",
                 0 <= i_p1 < i_p2 < i_rb and i_ra > i_p2, seq)
        for ver, model in (("3.0.0", "openai/gpt-5"),
                           ("4.0.0", "openai/gpt-4.1")):
            db("INSERT INTO model_policies(policy_id, role, station,"
               " primary_model, version, status, created_by) VALUES"
               " (%s,'STATION_01',1,%s,%s,'PROPOSED','mm03-verifier')",
               (f"policy-station-01-{ver}", model, ver))
        barrier = threading.Barrier(2)
        cres = {}

        def promote_conc(ver):
            client = Client(PORT)
            barrier.wait(timeout=10)
            cres[ver] = client.call(
                "POST", f"/model-policies/policy-station-01-{ver}/promote",
                {"approval_note": f"concurrent {ver}"})
        threads = [threading.Thread(target=promote_conc, args=(v,))
                   for v in ("3.0.0", "4.0.0")]
        for t in threads:
            t.start()
        for t in threads:
            t.join(timeout=30)
        codes = sorted(r[0] for r in cres.values())
        it.check("two simultaneous promotions: exactly one 200, exactly one typed 409",
                 codes == [200, 409], {k: v[0] for k, v in cres.items()})
        it.check("exactly one ACTIVE policy for STATION_01 at the end",
                 db("SELECT COUNT(*) AS n FROM model_policies"
                    " WHERE role='STATION_01' AND status='ACTIVE'",
                    one=True)["n"] == 1)
        it.done()
    finally:
        try:
            stop_server(proc)
        except Exception:
            pass
    (HERE / "results.json").write_text(json.dumps(results, indent=1))
    bad = [k for k, v in results.items() if v["verdict"] != "PASS"]
    print("ITEMS:", {k: v["verdict"] for k, v in results.items()})
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
