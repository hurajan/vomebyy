#!/usr/bin/env python3
"""MM-03 verifier probe 2: deterministic concurrency adjudication.
Holds the role advisory lock (mm03:policy:<role>) in an external session
while a promotion is attempted (must 409 fail-fast), then releases and
retries (must 200). Plus 3 extra barrier-pair rounds recording the
interleaving + end-state consistency. Writes probe2.json."""
import json
import sys
import threading
from pathlib import Path

import psycopg
from psycopg.rows import dict_row

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(Path.home() / "workspace/video-factory-g3/tests"))
from server_fixture import Client, make_dsn, start_server, stop_server  # noqa
import importlib.util
spec = importlib.util.spec_from_file_location("v", HERE / "verify_mm03.py")
# reuse constants without running main: read them off the module source env
DB, PORT = "mm03_verify_scratch", 8853
DSN = make_dsn(DB)
ROLE_ENV = {"FACTORY_WORKER_TOKEN": "mm03v-worker-token",
            "FACTORY_SCHEDULER_TOKEN": "mm03v-scheduler-token",
            "FACTORY_VALIDATOR_TOKEN": "mm03v-validator-token"}

checks = []


def check(label, ok, detail=""):
    checks.append({"name": label, "ok": bool(ok), "detail": str(detail)[:600]})
    if not ok:
        print(f"  FAIL: {label} -- {detail}")


def db(sql, params=(), one=False):
    with psycopg.connect(DSN, row_factory=dict_row) as conn:
        cur = conn.execute(sql, params)
        rows = [dict(r) for r in cur.fetchall()] if cur.description else []
        conn.commit()
    return rows[0] if one and rows else rows


def author(ver, model):
    pid = f"policy-station-01-{ver}"
    db("INSERT INTO model_policies(policy_id, role, station, primary_model,"
       " version, status, created_by) VALUES (%s,'STATION_01',1,%s,%s,"
       " 'PROPOSED','mm03-verifier-probe2') ON CONFLICT (policy_id)"
       " DO NOTHING", (pid, model, ver))
    return pid


def main():
    import subprocess, os, time
    root = Path.home() / "workspace/video-factory-g3"
    env = dict(os.environ, FACTORY_DSN=DSN, FACTORY_PORT=str(PORT), **ROLE_ENV)
    proc = subprocess.Popen([str(root / ".venv" / "bin" / "python"),
                             str(root / "api" / "server.py")],
                            env=env, stdout=subprocess.DEVNULL,
                            stderr=subprocess.DEVNULL)
    api = Client(PORT)
    for _ in range(100):
        try:
            s, _ = api.call("GET", "/health")
            if s == 200:
                break
        except Exception:
            pass
        time.sleep(0.1)
    try:
        authored = []
        successes = [0]
        pid5 = author("5.2.0", "openai/gpt-5")
        authored.append(pid5)
        # hold the role advisory lock externally
        holder = psycopg.connect(DSN)
        holder.execute("SELECT pg_advisory_lock(hashtext('mm03:policy:STATION_01'))")
        holder.commit()
        st, out = api.call("POST", f"/model-policies/{pid5}/promote",
                           {"approval_note": "probe2 under held lock"})
        check("promotion under externally held role lock -> 409 fail-fast",
              st == 409 and "in flight" in json.dumps(out), out)
        check("policy untouched while lock held (still PROPOSED)",
              db("SELECT status FROM model_policies WHERE policy_id=%s",
                 (pid5,), one=True)["status"] == "PROPOSED")
        holder.execute("SELECT pg_advisory_unlock(hashtext('mm03:policy:STATION_01'))")
        holder.commit()
        holder.close()
        st, out = api.call("POST", f"/model-policies/{pid5}/promote",
                           {"approval_note": "probe2 after release"})
        check("same promotion succeeds once the lock is released",
              st == 200 and out.get("status") == "ACTIVE", out)
        if st == 200:
            successes[0] += 1
        check("exactly one ACTIVE for STATION_01 after probe",
              db("SELECT COUNT(*) AS n FROM model_policies"
                 " WHERE role='STATION_01' AND status='ACTIVE'",
                 one=True)["n"] == 1)
        # 3 extra barrier-pair rounds: record interleaving + end state
        rounds = []
        for a, b in (("12.0.0", "13.0.0"), ("14.0.0", "15.0.0"),
                     ("16.0.0", "17.0.0")):
            pa, pb = author(a, "openai/gpt-5"), author(b, "openai/gpt-4.1")
            authored += [pa, pb]
            barrier = threading.Barrier(2)
            res = {}

            def fire(pid, key):
                c = Client(PORT)
                barrier.wait(timeout=10)
                res[key] = c.call("POST", f"/model-policies/{pid}/promote",
                                  {"approval_note": f"probe2 round {key}"})
            ts = [threading.Thread(target=fire, args=(pa, a)),
                  threading.Thread(target=fire, args=(pb, b))]
            for t in ts:
                t.start()
            for t in ts:
                t.join(timeout=30)
            codes = sorted(v[0] for v in res.values())
            successes[0] += codes.count(200)
            n_active = db("SELECT COUNT(*) AS n FROM model_policies"
                          " WHERE role='STATION_01' AND status='ACTIVE'",
                          one=True)["n"]
            rounds.append({"pair": [a, b], "codes": codes,
                           "active_count": n_active})
        check("3 extra barrier rounds: end state always exactly one ACTIVE",
              all(r["active_count"] == 1 for r in rounds), rounds)
        ph = ",".join(["%s"] * len(authored))
        ev = db(f"SELECT COUNT(*) AS n FROM policy_events"
                f" WHERE action='PROMOTE' AND policy_id IN ({ph})",
                tuple(authored), one=True)
        check("every successful promotion in probe2 left exactly one PROMOTE event",
              ev["n"] == successes[0],
              {"events": ev["n"], "successes": successes[0]})
    finally:
        proc.terminate()
        try:
            proc.wait(timeout=5)
        except Exception:
            proc.kill()
    verdict = "PASS" if all(c["ok"] for c in checks) else "FAIL"
    (HERE / "probe2.json").write_text(json.dumps(
        {"probe": "concurrency_adjudication", "verdict": verdict,
         "checks": checks}, indent=1))
    print("probe2:", verdict,
          f"({sum(c['ok'] for c in checks)}/{len(checks)})")
    return 0 if verdict == "PASS" else 1


if __name__ == "__main__":
    sys.exit(main())
