#!/usr/bin/env python3
"""MM-03 battery — scenarios (a)..(h) from LOCK_MM03.md, serial, against
a real API server + scratch PG16 built by the canonical chain.

Run: video-factory-g2/.venv/bin/python test_mm03.py
Writes evidence/results/{a..h}_*.json + summary.json next to this file's
gate directory. Scenario (i) is run_regression.sh (the 13 canonical
suites), reported separately.
"""
import hashlib
import json
import os
import subprocess
import sys
import threading
import time
import urllib.request
from pathlib import Path

import psycopg

GATE = Path(__file__).resolve().parents[1]
RESULTS = GATE / "evidence" / "results"
RESULTS.mkdir(parents=True, exist_ok=True)
G3_TESTS = Path.home() / "workspace/video-factory-g3/tests"
sys.path.insert(0, str(G3_TESTS))
sys.path.insert(0, str(Path.home() / "workspace/video-factory-g2"))
from server_fixture import Client, make_dsn, start_server, stop_server  # noqa: E402
from coordinator.coordinator import Coordinator  # noqa: E402

DB, PORT = "mm03_registry_scratch", 8847
G2PY = str(Path.home() / "workspace/video-factory-g2/.venv/bin/python")
SEEDER = GATE / "tools" / "seed_registry.py"
DSN = make_dsn(DB)
ROLE_ENV = {"FACTORY_WORKER_TOKEN": "mm03-worker-token",
            "FACTORY_SCHEDULER_TOKEN": "mm03-scheduler-token",
            "FACTORY_VALIDATOR_TOKEN": "mm03-validator-token"}
V1 = "policy-station-03-1.0.0"
V2 = "policy-station-03-2.0.0"


def role_headers(role, token):
    return {"X-Role": role, "X-Role-Token": token}


class Scenario:
    def __init__(self, name):
        self.name = name
        self.checks = []

    def check(self, label, ok, detail=""):
        self.checks.append({"name": label, "ok": bool(ok),
                            "detail": str(detail)[:500]})
        if not ok:
            print(f"  FAIL {self.name}: {label} — {detail}")

    @property
    def verdict(self):
        return "PASS" if all(c["ok"] for c in self.checks) else "FAIL"

    def write(self, fname):
        (RESULTS / fname).write_text(json.dumps(
            {"scenario": self.name, "verdict": self.verdict,
             "checks": self.checks}, indent=1))
        print(f"{self.name}: {self.verdict} "
              f"({sum(c['ok'] for c in self.checks)}/{len(self.checks)})")


def db(sql, params=(), one=False):
    from psycopg.rows import dict_row
    with psycopg.connect(DSN, row_factory=dict_row) as conn:
        cur = conn.execute(sql, params)
        rows = [dict(r) for r in cur.fetchall()] \
            if cur.description else []
        conn.commit()
    return rows[0] if one and rows else rows


def run_seeder():
    r = subprocess.run([G2PY, str(SEEDER), DB], capture_output=True, text=True)
    assert r.returncode == 0, f"seeder failed: {r.stdout} {r.stderr}"
    return json.loads(r.stdout.strip().splitlines()[-1])


def registry_hash():
    h = hashlib.sha256()
    for t, key in (("models", "model_id"), ("model_policies", "policy_id"),
                   ("operation_model_assignments", "operation_id, matrix_version")):
        rows = db(f"SELECT * FROM {t} ORDER BY {key}")
        h.update(json.dumps(rows, sort_keys=True, default=str).encode())
    return h.hexdigest()


def start_api_only():
    """Restart the API against the EXISTING db (no rebuild) — scenario (h)."""
    import subprocess as sp
    root = Path.home() / "workspace/video-factory-g3"
    env = dict(os.environ, FACTORY_DSN=DSN, FACTORY_PORT=str(PORT), **ROLE_ENV)
    proc = sp.Popen([str(root / ".venv" / "bin" / "python"),
                     str(root / "api" / "server.py")],
                    env=env, stdout=sp.DEVNULL, stderr=sp.DEVNULL)
    client = Client(PORT)
    for _ in range(100):
        try:
            status, _ = client.call("GET", "/health")
            if status == 200:
                return proc, client
        except Exception:
            pass
        time.sleep(0.1)
    proc.kill()
    raise RuntimeError("server did not come up")


def main():
    proc, api = start_server(DB, PORT, env_extra=ROLE_ENV)
    summary = {}
    try:
        seed1 = run_seeder()

        # ---------------- (a) seeder idempotence + counts
        s = Scenario("a_seeder_idempotence")
        h1 = registry_hash()
        seed2 = run_seeder()
        h2 = registry_hash()
        counts = {t: db(f"SELECT COUNT(*) AS n FROM {t}", one=True)["n"]
                  for t in ("models", "model_policies",
                            "operation_model_assignments", "benchmark_results")}
        s.check("457 models", counts["models"] == 457, counts)
        s.check("7 policies", counts["model_policies"] == 7, counts)
        s.check("192 assignments",
                counts["operation_model_assignments"] == 192, counts)
        s.check("benchmark_results empty (no fabricated rows)",
                counts["benchmark_results"] == 0, counts)
        s.check("second run inserted nothing",
                seed2["inserted"] == {"models": 0, "policies": 0,
                                      "assignments": 0}, seed2["inserted"])
        s.check("content hash stable across runs", h1 == h2, f"{h1} vs {h2}")
        s.check("all policies PROPOSED",
                db("SELECT COUNT(*) AS n FROM model_policies"
                   " WHERE status='PROPOSED'", one=True)["n"] == 7)
        s.check("no ACTIVE assignments before any promotion",
                db("SELECT COUNT(*) AS n FROM operation_model_assignments"
                   " WHERE status='ACTIVE'", one=True)["n"] == 0)
        s.check("72 model-bound (PROPOSED) + 120 NONE assignments",
                db("SELECT COUNT(*) AS n FROM operation_model_assignments"
                   " WHERE status='PROPOSED'", one=True)["n"] == 72 and
                db("SELECT COUNT(*) AS n FROM operation_model_assignments"
                   " WHERE status='NONE'", one=True)["n"] == 120)
        s.check("08.12 ceiling = 25 with BINDING provenance (C-01)",
                db("SELECT max_cost_cents, cost_source FROM"
                   " operation_model_assignments WHERE operation_id='08.12'"
                   " AND matrix_version='1.0.0'", one=True)
                == {"max_cost_cents": 25, "cost_source": "BINDING"})
        s.write("a_seeder_idempotence.json")
        summary["a"] = s.verdict

        # ---------------- fixture: production + the lean slice binding
        _, out = api.call("POST", "/productions",
                          {"title": "mm03", "hard_ceiling_cents": 100000,
                           "soft_ceiling_cents": 100000})
        pid = out["production_id"]
        _, out = api.call("POST", f"/productions/{pid}/runs", {"kind": "FULL"})
        run_id = out["run_id"]
        status, out = api.call("POST", "/configs", {
            "scope": "OPERATION", "operation_id": "08.12",
            "provider": "openrouter-compatible",
            "model": "anthropic/claude-haiku-4.5", "est_cost_cents": 25,
            "credential_ref": "OPENROUTER_API_KEY",
            "params": {"temperature": 0.7, "max_tokens": 2000}})
        assert status == 201, out

        _uk = [0]

        def plan_and_claim(op):
            # one unit per (production, operation, unit_key, run) — each
            # scenario unit gets its own unit_key
            _uk[0] += 1
            _, o = api.call("POST", f"/productions/{pid}/units",
                            {"operation_id": op, "run_id": run_id,
                             "unit_key": f"mm03-{_uk[0]}"})
            uid = o["unit_id"]
            st, co = api.call("POST", f"/units/{uid}/claim",
                              {"worker_id": "mm03-worker"})
            return uid, st, co

        def attempt_snapshot(uid):
            _, o = api.call("GET", f"/units/{uid}/attempts")
            return o["attempts"][-1]

        # ---------------- (b) un-promoted policy: zero claim effect
        s = Scenario("b_unpromoted_zero_effect")
        uid_b, st, claim_b = plan_and_claim("08.12")
        s.check("claim succeeds pre-promotion", st == 200, claim_b)
        att = attempt_snapshot(uid_b)
        snap = att["resolved_config"] or {}
        s.check("resolution is the slice binding (haiku, est-bearing scope)",
                snap.get("model") == "anthropic/claude-haiku-4.5"
                and snap.get("provider") == "openrouter-compatible", snap)
        s.check("NO model_assignment pinned pre-promotion",
                "model_assignment" not in snap, list(snap))
        s.write("b_unpromoted_zero_effect.json")
        summary["b"] = s.verdict

        # ---------------- (c) promotion flow + role refusals
        s = Scenario("c_promotion_flow")
        st, _ = api.call("POST", f"/model-policies/{V1}/promote",
                         {"approval_note": "worker attempt"}, token=None,
                         headers=role_headers("WORKER", "mm03-worker-token"))
        s.check("WORKER promotion -> 403", st == 403, st)
        st, _ = api.call("POST", f"/model-policies/{V1}/promote",
                         {"approval_note": "scheduler attempt"}, token=None,
                         headers=role_headers("SCHEDULER", "mm03-scheduler-token"))
        s.check("SCHEDULER promotion -> 403", st == 403, st)
        refusals = db("SELECT payload FROM audit_events"
                      " WHERE event_type='policy_action_refused'"
                      " AND payload->>'policy_id'=%s", (V1,))
        s.check("both refusals audited",
                len(refusals) == 2
                and {r["payload"]["role"] for r in refusals}
                == {"WORKER", "SCHEDULER"}, refusals)
        st, out = api.call("POST", f"/model-policies/{V1}/promote",
                           {"approval_note": "MM-03 battery approval"})
        s.check("OPERATOR promotion -> 200 ACTIVE", st == 200
                and out["status"] == "ACTIVE", out)
        s.check("23 bindings written (1 STATION + 22 OPERATION)",
                out["bindings_written"] == 23, out)
        st_row = db("SELECT * FROM provider_configs WHERE active"
                    " AND scope='STATION' AND station=3", one=True)
        s.check("STATION 3 binding carries the role primary",
                st_row["model"] == "anthropic/claude-sonnet-4.5"
                and st_row["params"]["policy_id"] == V1, st_row)
        op_row = db("SELECT * FROM provider_configs WHERE active"
                    " AND scope='OPERATION' AND operation_id='08.12'", one=True)
        s.check("08.12 binding now the assignment's model + ceiling",
                op_row["model"] == "anthropic/claude-opus-4.8"
                and op_row["est_cost_cents"] == 25
                and op_row["max_cost_cents"] == 25
                and op_row["params"]["policy_id"] == V1, op_row)
        s.check("slice binding superseded by promotion",
                db("SELECT COUNT(*) AS n FROM provider_configs WHERE active"
                   " AND scope='OPERATION' AND operation_id='08.12'"
                   " AND model='anthropic/claude-haiku-4.5'", one=True)["n"] == 0)
        s.check("22 STATION_03 assignments ACTIVE",
                db("SELECT COUNT(*) AS n FROM operation_model_assignments"
                   " WHERE role='STATION_03' AND status='ACTIVE'",
                   one=True)["n"] == 22)
        ev = db("SELECT * FROM policy_events WHERE policy_id=%s"
                " AND action='PROMOTE'", (V1,), one=True)
        s.check("PROMOTE event records the approval",
                ev and ev["note"] == "MM-03 battery approval"
                and len(ev["payload"]["bindings_written"]) == 23, ev)
        _, out = api.call("GET", f"/model-policies/{V1}/events")
        s.check("events readable via API",
                any(e["action"] == "PROMOTE" for e in out["events"]), out)
        s.write("c_promotion_flow.json")
        summary["c"] = s.verdict

        # ---------------- (d) pinning across v1 -> v2
        s = Scenario("d_pinning")
        uid_d, st, claim_d = plan_and_claim("08.12")
        s.check("claim under v1 succeeds", st == 200, claim_d)
        att_d = attempt_snapshot(uid_d)
        snap_d = att_d["resolved_config"]
        ma = snap_d.get("model_assignment") or {}
        s.check("v1 assignment pinned (opus, matrix 1.0.0, ceiling 25)",
                ma.get("primary_model") == "anthropic/claude-opus-4.8"
                and ma.get("matrix_version") == "1.0.0"
                and ma.get("policy_id") == V1
                and ma.get("max_cost_cents") == 25, ma)
        s.check("v1 config model pinned (opus)",
                snap_d.get("model") == "anthropic/claude-opus-4.8", snap_d)
        # v2 policy + cloned assignments (fixture data authoring via SQL;
        # policy CREATION is governance data entry — promotion is the API)
        db("INSERT INTO model_policies(policy_id, role, station, primary_model,"
           " fallback_model, evaluation_model, version, status, created_by)"
           " VALUES (%s,'STATION_03',3,'anthropic/claude-sonnet-4.5',"
           " 'google/gemini-2.5-pro','google/gemini-2.5-pro','2.0.0',"
           " 'PROPOSED','mm03-battery')", (V2,))
        db("INSERT INTO operation_model_assignments(operation_id, role,"
           " policy_id, station, execution_class, primary_model, fallback_model,"
           " evaluation_model, matrix_version, max_cost_cents, cost_source,"
           " null_reason, status) SELECT operation_id, role, %s, station,"
           " execution_class, primary_model, fallback_model, evaluation_model,"
           " '2.0.0', max_cost_cents, cost_source, null_reason,"
           " CASE WHEN primary_model IS NULL THEN 'NONE' ELSE 'PROPOSED' END"
           " FROM operation_model_assignments WHERE role='STATION_03'"
           " AND matrix_version='1.0.0'", (V2,))
        db("UPDATE operation_model_assignments SET"
           " primary_model='anthropic/claude-sonnet-4.5'"
           " WHERE operation_id='08.12' AND matrix_version='2.0.0'")
        st, out = api.call("POST", f"/model-policies/{V2}/promote",
                           {"approval_note": "v2 promotion"})
        s.check("v2 promotion succeeds, supersedes v1",
                st == 200 and out["superseded_policy_id"] == V1, out)
        s.check("v1 policy RETIRED, v1 assignments RETIRED",
                db("SELECT status FROM model_policies WHERE policy_id=%s",
                   (V1,), one=True)["status"] == "RETIRED"
                and db("SELECT COUNT(*) AS n FROM operation_model_assignments"
                       " WHERE role='STATION_03' AND matrix_version='1.0.0'"
                       " AND status='RETIRED'", one=True)["n"] == 22)
        # complete the v1 attempt; its snapshot must not move
        coord = Coordinator(DSN, actor="mm03-battery")
        coord.complete_attempt(uid_d, "mm03-worker", claim_d["fencing_token"],
                               "script", b'{"kind":"script","lines":[]}',
                               "mm03://script-v1", 25)
        coord.close()
        att_after = attempt_snapshot(uid_d)
        s.check("completed v1 attempt keeps its v1 pin (snapshot immutable)",
                att_after["resolved_config"] == snap_d
                and att_after["resolved_config_hash"] == att_d["resolved_config_hash"],
                att_after["resolved_config"])
        uid_d2, st, claim_d2 = plan_and_claim("08.12")
        ma2 = (attempt_snapshot(uid_d2)["resolved_config"] or {}) \
            .get("model_assignment") or {}
        s.check("new claim pins v2 (sonnet, matrix 2.0.0)",
                st == 200 and ma2.get("matrix_version") == "2.0.0"
                and ma2.get("primary_model") == "anthropic/claude-sonnet-4.5",
                ma2)
        s.write("d_pinning.json")
        summary["d"] = s.verdict

        # ---------------- (e) ceiling refusal + restore
        s = Scenario("e_ceiling_refusal")
        db("UPDATE operation_model_assignments SET max_cost_cents=10"
           " WHERE operation_id='08.05' AND status='ACTIVE'")
        _, o = api.call("POST", f"/productions/{pid}/units",
                        {"operation_id": "08.05", "run_id": run_id,
                         "unit_key": "mm03-e"})
        uid_e = o["unit_id"]
        st, out = api.call("POST", f"/units/{uid_e}/claim",
                           {"worker_id": "mm03-worker"})
        s.check("claim over the ACTIVE ceiling -> 409", st == 409, out)
        s.check("zero attempts written",
                db("SELECT COUNT(*) AS n FROM action_attempts WHERE unit_id=%s",
                   (uid_e,), one=True)["n"] == 0)
        audit = db("SELECT payload FROM audit_events WHERE unit_id=%s"
                   " AND event_type='assignment_ceiling_exceeded'",
                   (uid_e,), one=True)
        s.check("refusal audited with estimate + ceiling",
                audit and audit["payload"]["estimate_cents"] == 100
                and audit["payload"]["assignment_max_cost_cents"] == 10, audit)
        db("UPDATE operation_model_assignments SET max_cost_cents=100"
           " WHERE operation_id='08.05' AND status='ACTIVE'")
        st, out = api.call("POST", f"/units/{uid_e}/claim",
                           {"worker_id": "mm03-worker"})
        s.check("claim succeeds after ceiling restored", st == 200, out)
        s.write("e_ceiling_refusal.json")
        summary["e"] = s.verdict

        # ---------------- (f) rollback
        s = Scenario("f_rollback")
        st, out = api.call("POST", f"/model-policies/{V2}/rollback",
                           {"note": "battery rollback"})
        s.check("rollback -> 200, restores v1",
                st == 200 and out["restored_policy_id"] == V1, out)
        s.check("v1 ACTIVE again, v2 RETIRED",
                db("SELECT status FROM model_policies WHERE policy_id=%s",
                   (V1,), one=True)["status"] == "ACTIVE"
                and db("SELECT status FROM model_policies WHERE policy_id=%s",
                       (V2,), one=True)["status"] == "RETIRED")
        op_row = db("SELECT * FROM provider_configs WHERE active"
                    " AND scope='OPERATION' AND operation_id='08.12'", one=True)
        s.check("08.12 binding restored to v1 content (opus, est 25)",
                op_row["model"] == "anthropic/claude-opus-4.8"
                and op_row["est_cost_cents"] == 25
                and op_row["params"]["policy_id"] == V1, op_row)
        chain = [r["action"] for r in db(
            "SELECT action FROM policy_events WHERE policy_id IN (%s,%s)"
            " ORDER BY at, event_id", (V1, V2))]
        s.check("history shows the full chain (never edited)",
                {"PROMOTE", "RETIRE", "ROLLBACK", "REACTIVATE"} <= set(chain),
                chain)
        att_f = attempt_snapshot(uid_d)
        s.check("historical attempt rows untouched by rollback",
                att_f["resolved_config"] == snap_d, att_f["resolved_config"])
        s.write("f_rollback.json")
        summary["f"] = s.verdict

        # ---------------- (g) concurrent promotions
        s = Scenario("g_concurrency")
        for ver, model in (("3.0.0", "openai/gpt-5"),
                           ("4.0.0", "openai/gpt-4.1")):
            db("INSERT INTO model_policies(policy_id, role, station,"
               " primary_model, version, status, created_by) VALUES"
               " (%s,'STATION_01',1,%s,%s,'PROPOSED','mm03-battery')",
               (f"policy-station-01-{ver}", model, ver))
        barrier = threading.Barrier(2)
        results = {}

        def promote_concurrent(ver):
            client = Client(PORT)
            barrier.wait(timeout=10)
            results[ver] = client.call(
                "POST", f"/model-policies/policy-station-01-{ver}/promote",
                {"approval_note": f"concurrent {ver}"})
        threads = [threading.Thread(target=promote_concurrent, args=(v,))
                   for v in ("3.0.0", "4.0.0")]
        for t in threads:
            t.start()
        for t in threads:
            t.join(timeout=30)
        codes = sorted(r[0] for r in results.values())
        s.check("exactly one promotion wins (200), loser typed 409",
                codes == [200, 409], results)
        s.check("exactly one ACTIVE policy for STATION_01",
                db("SELECT COUNT(*) AS n FROM model_policies"
                   " WHERE role='STATION_01' AND status='ACTIVE'",
                   one=True)["n"] == 1)
        loser = [r for r in results.values() if r[0] == 409]
        loser_err = (loser[0][1].get("error", "").lower() if loser else "")
        s.check("loser error is a typed conflict",
                bool(loser) and ("in flight" in loser_err
                                 or "conflict" in loser_err
                                 or "already" in loser_err),
                loser)
        s.write("g_concurrency.json")
        summary["g"] = s.verdict

        # ---------------- (h) restart recovery
        s = Scenario("h_restart_recovery")

        def registry_dump(client):
            dump = {}
            for path in ("/model-policies", "/model-assignments?status=ACTIVE",
                         "/provider-health", "/models?provider=anthropic"):
                st, out = client.call("GET", path)
                assert st == 200, (path, out)
                dump[path] = out
            return json.dumps(dump, sort_keys=True, default=str)
        before = registry_dump(api)
        stop_server(proc)
        proc2, api2 = start_api_only()
        try:
            after = registry_dump(api2)
        finally:
            stop_server(proc2)
        s.check("registry reads identical across API restart",
                before == after,
                f"{len(before)} vs {len(after)} bytes")
        s.check("models read serves the seeded catalog (anthropic subset)",
                len(json.loads(before)["/models?provider=anthropic"]
                    ["models"]) > 0)
        s.write("h_restart_recovery.json")
        summary["h"] = s.verdict
    finally:
        try:
            stop_server(proc)
        except Exception:
            pass
    (RESULTS / "summary.json").write_text(json.dumps(
        {"battery": "mm03_registry", "scenarios": summary,
         "verdict": "PASS" if all(v == "PASS" for v in summary.values())
         else "FAIL"}, indent=1))
    print("SUMMARY:", summary)
    return 0 if all(v == "PASS" for v in summary.values()) else 1


if __name__ == "__main__":
    sys.exit(main())
