# LOCK — GATE MM-03: Central Model + Capability Registry

**Gate:** MM-03 (Multi-Model programme, MULTI_MODEL_EXECUTION_PROMPT.md)
**Builder:** MM-03 builder agent (this session)
**Date:** 2026-10-29
**Status at lock:** LOCKED → IMPLEMENTING

## Scope (exactly the MM-03 brief, nothing more)

The registry is the **governance layer above** the existing provider-config
machinery. `provider_configs` remains the executable binding store;
Coordinator claim-time whole-row resolution + snapshot pinning stays as
built (Gates C/D/04/05). **Promotion is the only path** by which a registry
policy writes `provider_configs` rows, and promotion requires an
OPERATOR-role approval recorded in `policy_events`. Nothing PROPOSED ever
affects a claim.

### Deliverables
1. **Migration 016** (additive only, `video-factory-g2/database/migrations/
   016_mm03_model_registry.sql`): tables `providers`, `models`,
   `model_policies`, `operation_model_assignments`, `policy_events`,
   `benchmark_results` (created empty — no fabricated rows),
   `provider_health`. Partial unique indexes: one ACTIVE policy per role;
   one ACTIVE assignment per operation.
2. **Seeder** (`mm-gate-03/tools/seed_registry.py`, idempotent): MM-02
   catalog snapshot → `models` (457 rows, provenance preserved);
   selection.json (data_version 1.0.1, matrix_version 1.0.0) →
   `model_policies` (7 roles, status PROPOSED) +
   `operation_model_assignments` (192 rows; `max_cost_cents` +
   `cost_source` from MM-01 classification); execution providers +
   honest initial health rows.
3. **Promotion/rollback service** (`video-factory-g2/coordinator/
   model_registry.py`) + **API endpoints** (contract **1.8.0**):
   GET /model-policies, GET /model-policies/{id},
   GET /model-policies/{id}/events, POST /model-policies/{id}/promote,
   POST /model-policies/{id}/rollback, GET /model-assignments,
   GET /models, GET /provider-health. Promotion/rollback are OPERATOR
   only; other roles → 403 + committed refusal audit
   (`policy_action_refused`).
4. **Claim integration** (additive, `coordinator.py`): when an ACTIVE
   assignment exists for the claimed operation, claim also pins the
   assignment (models + matrix_version + policy_id) into the attempt's
   config snapshot under `model_assignment`, and refuses the claim
   (typed `AssignmentCeilingExceeded` + committed
   `assignment_ceiling_exceeded` audit) when the resolved estimate
   exceeds the assignment's `max_cost_cents`. No ACTIVE assignment →
   claim behavior byte-for-byte as before.
5. **C-01 decision record** (below) + this lock + OWNERSHIP entry.

### Seeding derivations (recorded, not invented)
- `models.provider` = vendor prefix of the catalog model id (the catalog
  is the OpenRouter catalog; every id carries a vendor prefix).
  `providers` is the *execution-provider* table (the namespace
  `provider_configs.provider` already uses): seeded rows
  `openrouter-compatible`, `deterministic-local`, `mock`.
- Assignment `evaluation_model`: the assigned role's `evaluation_model`
  from selection.json; for EVALUATION-role assignments the primary *is*
  the judging model, so `evaluation_model` = the assignment's primary;
  null when the assignment has no model.
- Assignment `status`: `NONE` when the selection assigns no model
  (117 deterministic/human + 3 MM-06 specialized — null_reason kept);
  `PROPOSED` otherwise. Only promotion flips PROPOSED → ACTIVE.

## C-01 decision (as implemented)

MM-01 finding C-01 (independently confirmed): the registry's
`resource_ceiling.max_cost_usd_per_unit` is null for **192/192**
operations — the approved operation definitions set **no** per-operation
cost ceiling, so no ceiling can be read out of the registry.
**Decision: per-operation cost ceilings live on
`operation_model_assignments.max_cost_cents`** — governance data, seeded
from the MM-01 classification values with their provenance kept in
`cost_source` (`BINDING` where a real binding set the figure, e.g. 08.12
= 25¢; `PROPOSED_CLASS_DEFAULT` where the figure is a proposed class
default). A ceiling binds claims **only while its assignment is ACTIVE**
(i.e. after an OPERATOR-approved promotion); PROPOSED ceilings are inert.
Promotion copies the ceiling into the written `provider_configs` rows
(`est_cost_cents` + `max_cost_cents`), and claim enforces it against the
resolved estimate with a typed, audited refusal. Changing a ceiling is a
new policy version + promotion — never an edit to history.

## Write ownership (claimed here + in gate-00/OWNERSHIP.md before edits)

- `video-factory-g2/database/migrations/016_mm03_model_registry.sql` (new)
- `video-factory-g2/tools/setup_db.py` — one added apply line for 016
- `video-factory-g2/coordinator/model_registry.py` (new)
- `video-factory-g2/coordinator/coordinator.py` — MM-03 claim integration
  only (assignment lookup, ceiling refusal, snapshot pin)
- `video-factory-g3/api/server.py` — MM-03 registry routes only
- `video-factory-g3/contracts/api_contract.json` — version 1.8.0, +8 endpoints
- `video-factory-g3/tests/test_api_contract.py` — exercise the 8 new
  endpoints (contract test asserts full coverage; recorded in
  CHANGED_ASSERTIONS.md)
- `video-factory-master-programme/mm-gate-03/**` — lock, seeder, tests,
  evidence
- Migration namespace: **016 claimed by MM-03** (015 was the last applied).

## Out of scope / guardrails

No changes to registry definitions, plans, workflows, worker/evaluation/
runtime services, or the dashboard (MM-09 owns dashboard extension; the
GET endpoints are its data surface). No real provider call; no credential
exists or is requested (MM-12 owns that). No benchmark rows seeded —
`benchmark_results` ships empty by design. Promotion of a policy whose
role has no assignments at its matrix version writes only its STATION
row (station roles) — recorded in the promotion event payload.

## Tests (mm-gate-03/evidence/results/, serial)

(a) seeder idempotence + counts (457/7/192) · (b) un-promoted policy has
zero claim effect · (c) promotion flow + role refusal · (d) pinning
across v1→v2 promotion · (e) ceiling refusal + restore · (f) rollback ·
(g) concurrent promotions → exactly one ACTIVE + typed conflict ·
(h) restart recovery of registry reads · (i) full regression (baseline
225 + new tests; G9 full run 18/1620 unchanged).
