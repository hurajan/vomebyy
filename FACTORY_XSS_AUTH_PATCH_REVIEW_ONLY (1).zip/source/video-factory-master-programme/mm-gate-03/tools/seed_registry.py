#!/usr/bin/env python3
"""MM-03 registry seeder — idempotent.

Imports the MM-02 catalog snapshot into `models`, and the MM-02
selection matrix (data_version 1.0.1, matrix_version 1.0.0) into
`model_policies` (7 roles, status PROPOSED) + `operation_model_
assignments` (192 rows), with per-operation cost ceilings taken from
the MM-01 classification (max_cost_cents + cost_source — the C-01
decision: ceilings live on assignments, provenance kept, binding
claims only once an assignment is ACTIVE via promotion).

Also seeds the execution-provider rows (`providers` — the namespace
provider_configs.provider uses) and honest initial `provider_health`
rows: openrouter-compatible is BLOCKED_NO_CREDENTIAL (no credential
exists; real calls stay disabled until MM-12).

Idempotence: every insert is ON CONFLICT DO NOTHING (or existence-
guarded); re-running changes no row. Run with the G2 venv python:
  video-factory-g2/.venv/bin/python seed_registry.py <dbname>
"""
import json
import re
import sys
from decimal import Decimal
from pathlib import Path

import psycopg


def _fixture_password():
    """The scratch role's dev password is sourced from the canonical
    fixture (g2 setup_db.py's role-creation line) — never re-typed into
    this file (the display-redaction trap mangles re-typed literals)."""
    text = (Path.home() / "workspace/video-factory-g2/tools/setup_db.py"
            ).read_text()
    m = re.search(r"CREATE ROLE factory LOGIN PASSWORD '([^']+)'", text)
    if not m:
        raise SystemExit("fixture password not found in g2 setup_db.py")
    return m.group(1)

MM = Path(__file__).resolve().parents[2]  # video-factory-master-programme
CATALOG = MM / "mm-gate-02" / "evidence" / "catalog_snapshot.json"
SELECTION = MM / "mm-gate-02" / "evidence" / "selection.json"
CLASSIFICATION = MM / "mm-gate-01" / "evidence" / "classification.json"

EXECUTION_PROVIDERS = [
    ("openrouter-compatible", "openrouter-compatible",
     "https://openrouter.ai/api/v1", "OPENROUTER_API_KEY", "enabled"),
    ("deterministic-local", "deterministic-local", None, None, "enabled"),
    ("mock", "mock", None, None, "test_only"),
]
INITIAL_HEALTH = [
    ("openrouter-compatible", "BLOCKED_NO_CREDENTIAL",
     "MM-00 inventory: no OPENROUTER_API_KEY present in the environment; "
     "real provider calls are disabled until MM-12 owner authorization"),
    ("deterministic-local", "READY",
     "local deterministic adapter (worker service); no credential needed"),
    ("mock", "TEST_ONLY",
     "mock adapter exists for tests only; never a production result"),
]


def policy_id_for(role, matrix_version):
    return f"policy-{role.lower().replace('_', '-')}-{matrix_version}"


def main():
    db = sys.argv[1] if len(sys.argv) > 1 else "mm03_registry_scratch"
    dsn = (f"host=127.0.0.1 dbname={db} user=factory "
           f"password={_fixture_password()}")
    catalog = json.loads(CATALOG.read_text())
    selection = json.loads(SELECTION.read_text())
    classification = json.loads(CLASSIFICATION.read_text())
    prov = catalog["provenance"]
    matrix_version = selection["matrix_version"]
    class_by_op = {r["operation_id"]: r for r in classification["rows"]}
    roles = selection["roles"]

    with psycopg.connect(dsn, autocommit=False) as conn:
        cur = conn.cursor()
        # --- execution providers + initial health (guarded inserts)
        for name, adapter, base_url, cred_ref, status in EXECUTION_PROVIDERS:
            cur.execute(
                "INSERT INTO providers(name, adapter, base_url, credential_ref,"
                " status) VALUES (%s,%s,%s,%s,%s) ON CONFLICT (name)"
                " DO NOTHING", (name, adapter, base_url, cred_ref, status))
        for provider, status, detail in INITIAL_HEALTH:
            cur.execute(
                "INSERT INTO provider_health(provider, status, detail)"
                " SELECT %s,%s,%s WHERE NOT EXISTS"
                " (SELECT 1 FROM provider_health WHERE provider=%s)",
                (provider, status, detail, provider))
        # --- model catalog (457 rows, provenance preserved)
        n_models = 0
        for m in catalog["data"]:
            arch = m.get("architecture") or {}
            pricing = m.get("pricing") or {}
            cur.execute(
                "INSERT INTO models(model_id, provider, name, context_length,"
                " pricing_in, pricing_out, modalities, structured_output,"
                " catalog_version, provenance) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"
                " ON CONFLICT (model_id) DO NOTHING",
                (m["id"], m["id"].split("/")[0], m.get("name"),
                 m.get("context_length"),
                 Decimal(pricing["prompt"]) if pricing.get("prompt") else None,
                 Decimal(pricing["completion"]) if pricing.get("completion") else None,
                 json.dumps({"modality": arch.get("modality"),
                             "input": arch.get("input_modalities"),
                             "output": arch.get("output_modalities")}),
                 "structured_outputs" in (m.get("supported_parameters") or []),
                 prov["fetched_at"], prov["source"]))
            n_models += cur.rowcount
        # --- policies (7 roles, PROPOSED) + SEEDED events for new rows
        n_policies = 0
        for role_name, role in roles.items():
            pid = policy_id_for(role_name, matrix_version)
            cur.execute(
                "INSERT INTO model_policies(policy_id, role, station,"
                " primary_model, fallback_model, evaluation_model, version,"
                " status, created_by) VALUES (%s,%s,%s,%s,%s,%s,%s,'PROPOSED',%s)"
                " ON CONFLICT (policy_id) DO NOTHING RETURNING policy_id",
                (pid, role_name, role.get("station"),
                 (role.get("primary") or {}).get("model_id"),
                 (role.get("fallback") or {}).get("model_id"),
                 (role.get("evaluation_model") or {}).get("model_id"),
                 matrix_version, "mm03-seeder"))
            if cur.fetchone():
                n_policies += 1
                cur.execute(
                    "INSERT INTO policy_events(policy_id, action, actor, payload)"
                    " VALUES (%s,'SEEDED','mm03-seeder',%s)",
                    (pid, json.dumps(
                        {"matrix_version": matrix_version,
                         "data_version": selection["data_version"],
                         "source": "mm-gate-02/evidence/selection.json"})))
        # --- assignments (192 rows)
        n_assignments = 0
        for a in selection["assignments"]:
            op = a["operation_id"]
            cls_row = class_by_op[op]
            role_name = a["assigned_role"]
            role = roles.get(role_name)
            if a.get("primary") is None:
                evaluation = None
                status = "NONE"
            elif role_name == "EVALUATION":
                # the assignment's primary IS the judging model
                evaluation = a["primary"]
                status = "PROPOSED"
            elif role and role.get("evaluation_model"):
                evaluation = role["evaluation_model"]["model_id"]
                status = "PROPOSED"
            else:
                evaluation = None
                status = "PROPOSED"
            cur.execute(
                "INSERT INTO operation_model_assignments(operation_id, role,"
                " policy_id, station, execution_class, primary_model,"
                " fallback_model, evaluation_model, matrix_version,"
                " max_cost_cents, cost_source, null_reason, status)"
                " VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"
                " ON CONFLICT (operation_id, matrix_version) DO NOTHING",
                (op, role_name,
                 policy_id_for(role_name, matrix_version) if role else None,
                 a.get("station"), a.get("execution_class"),
                 a.get("primary"), a.get("fallback"), evaluation,
                 matrix_version, cls_row["max_cost_cents"],
                 cls_row["cost_source"], a.get("null_reason"), status))
            n_assignments += cur.rowcount
        conn.commit()
        counts = {}
        for t in ("providers", "models", "model_policies",
                  "operation_model_assignments", "policy_events",
                  "benchmark_results", "provider_health"):
            cur.execute(f"SELECT COUNT(*) FROM {t}")
            counts[t] = cur.fetchone()[0]
    print(json.dumps({"inserted": {"models": n_models,
                                   "policies": n_policies,
                                   "assignments": n_assignments},
                      "counts": counts}))
    return 0


if __name__ == "__main__":
    sys.exit(main())
