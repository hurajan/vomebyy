# Master execution programme — architecture remediation through production acceptance

*Received from Raj 2026-10-28 (with the gate-flow diagram: Load next approved task → Acquire scope lock and baseline → Implement scoped changes → Run tests and verify evidence → PASS? → Commit evidence and unlock next; FAIL loops back to Implement. "Only verified PASS advances the gate."). This programme governs the factory work from receipt onward. The Gates A–H programme stands as completed evidence feeding Gates 00/01; Gate 02 below is the D-H1/V-H1 fix already ruled design (b) and in flight under LOCK_FIX_DH1, with its scope completed by this programme's fuller task/test list.*

## 1. Non-negotiable execution rules
The implementing AI must follow these rules throughout the programme.
1. Preserve the hierarchy: 192 Operations → Versioned Capabilities → Atomic Actions → Attempts → Artifacts and Evidence → Independent Validation → Coordinator Acceptance.
2. Preserve Coordinator authority: Workers, n8n, providers, schedulers, and dashboards cannot independently accept units, settle charges, approve gates, or unlock dependent operations.
3. Preserve the approved architecture: Six logical stations, versioned registry, PostgreSQL authority, and configurable model/provider bindings.
4. Audit before modifying: The earlier ARCHITECTURE_AUDIT_PROMPT_PREPARED has not been executed. It must become a mandatory gate, not be assumed complete because Gate A–H tests passed.
5. One owner per write: Use file locks, baseline hashes, and atomic commits. Never silently merge concurrent modifications.
6. No fabricated success: Distinguish mocked, stub-tested, deterministic, real-provider-tested, and production-verified behavior.
7. No automatic approval of policy changes: The AI may implement previously authorized changes, but cannot authorize new spending, destructive migrations, security exceptions, or altered product requirements.
8. Continue automatically after passing each gate: Do not request confirmation for ordinary implementation decisions already within scope. If blocked externally, isolate the blocked item, preserve evidence, and continue independent work without falsely passing the gate.

## 2. The four levels of completion
These classifications must exist separately for every operation.
- **L1 DEFINED** — Registered ID, semantics, dependencies, schemas and version.
- **L2 EXECUTABLE** — Real implementation binding, resolvable actions and callable worker or deterministic engine.
- **L3 TESTED** — Execution, validation, failures and recovery verified with retained evidence.
- **L4 PRODUCTION-VERIFIED** — Real authorized execution using production-equivalent infrastructure, measured costs, durable outputs and operational controls.

A registry entry cannot pass L2. A stub test cannot prove L4. An 18-unit representative execution cannot establish complete 192-operation runtime coverage.

## 3. Ordered gate programme
Gate numbers establish execution order. Every gate has prerequisites, scoped changes, required tests, and an explicit PASS condition.

| Gate | Workstream | Required exit condition |
|---|---|---|
| 00 | Baseline and ownership | Reproducible clean starting state |
| 01 | Execute missing architecture audit | All 192 operations classified |
| 02 | D-H1 atomic claim adoption | Unattended execution and concurrency PASS |
| 03 | Registry and station reconciliation | No ambiguous operation routing |
| 04 | Capability/action binding repair | 192/192 implementation plans resolved |
| 05 | Atomic execution and authority | Attempts, outputs, costs, fencing fully enforced |
| 06 | Independent validation contracts | Schema, continuity and human gates verified |
| 07 | Real AI provider integration | Genuine provider calls and billing evidence |
| 08 | Golden-set and semantic evaluation | Calibrated expert-based acceptance policy |
| 09 | Artifact and financial production integrity | Durable storage and exact accounting |
| 10 | Full operation verification | 192/192 operation paths tested |
| 11 | Cloud and runtime deployment | Production-equivalent stack verified |
| 12 | Full autonomous production | Complete graph executes without unauthorized intervention |
| 13 | Adversarial and recovery certification | Failure injection and safety invariants PASS |
| 14 | Final readiness and evidence lock | All mandatory gates closed, no critical blocker |

Gates are not passed merely because tests are green; their required behavior and test evidence must also be verified.

## 4. Detailed execution instructions

### Gate 00 — Freeze and reproduce the authoritative baseline
Prerequisites: Accessible source trees, runtime environment, database, workflow exports, and prior Gate A–H evidence.
Tasks: (1) Identify all nine factory source trees and the currently integrated working tree. (2) Create a Git baseline if authorized; otherwise construct a content-addressed source manifest. (3) Capture schema versions, registry hashes, workflow IDs, runtime configuration hashes, dependency versions, and test commands. (4) Run existing G1–G9 and service-level regressions. (5) Preserve existing reports, logs, artifacts, and test fixtures. (6) Obtain exclusive ownership of implementation files and migration namespaces. (7) Build a reproducible recovery checkpoint.
Tests: Source-integrity comparison, registry compatibility, database connectivity, regression reproduction, clean-restart test.
PASS: The baseline is reproducible, all pre-existing failures are identified, and source ownership is established.
Guardrail: No product edits, migrations, provider charges, or destructive environment operations during baseline discovery.

### Gate 01 — Execute the previously missing architecture audit
This gate executes the full substance of MASTER AI PROMPT — ARCHITECTURE AUDIT AND HIERARCHY REMEDIATION, rather than simply checking its conclusions against the earlier Gate A report.
Tasks: (1) Enumerate all 192 operation definitions and 191 dependency templates. (2) Extract every operation's station, required inputs, output contracts, dependencies, capabilities, and version. (3) Inspect all capability definitions, including the previously reported 29 PROPOSED entries. (4) Resolve operation-to-capability-to-action relationships. (5) Trace every action to its actual function, worker, provider adapter, or deterministic engine. (6) Trace runtime calls from webhook through Coordinator acceptance. (7) Identify all uncalled functions, generic fallback outputs, simulated artifacts, and unreachable branches. (8) Audit financial, artifact, validation, human-gate, fencing, and recovery contracts. (9) Reconcile the 20 individually executed versus 172 defined-and-chained Gate H claim. (10) Produce a deficiency-to-file-to-test remediation register.
Required tests: Registry integrity, graph completeness, binding resolution, source-level call tracing, schema integrity, and representative runtime trace comparisons.
PASS: All 192 operations are individually accounted for, every gap has an owner and remediation path, and no operation is labeled production-ready without evidence.
Guardrail: Do not rewrite registry definitions to make the audit pass. Record discrepancies first.

### Gate 02 — Repair D-H1 and V-H1 using approved design (b)
Objective: Make scheduler-prestaged claims safely adoptable by the intended executor.
Tasks: (1) Establish an authoritative, version-pinned operation-to-executor mapping. (2) Have the scheduler claim using that executor's authorized identity. (3) Bind the claim to unit ID, attempt ID, worker identity, fencing token, configuration hash, and lease. (4) Add a Coordinator-controlled, worker-authenticated adoption or resume endpoint. (5) Make adoption atomic, single-winner, and idempotent. (6) Ensure only the authorized executor can obtain its attempt's execution credentials. (7) Refuse already-started, expired, superseded, mismatched, and cancelled attempts. (8) Remove n8n-station-undefined from every dispatch and recovery route. (9) Preserve claim-time budgets and capacity restrictions. (10) Verify reaper and retry behavior after adoption failures.
Mandatory tests: T02-A scheduler claim followed by executor resume succeeds; T02-B two concurrent resume requests produce one execution owner; T02-C wrong worker identity receives refusal; T02-D stale fencing token receives refusal; T02-E duplicate dispatch cannot cause duplicate billable execution; T02-F crash between claim and adoption recovers; T02-G crash after adoption recovers without double-start; T02-H unattended Station 03 execution progresses; T02-I existing G1–G9 regression remains green.
PASS: All tests pass, every resumed attempt has a valid owner, and unattended processing no longer deadlocks.
Guardrail: Do not weaken worker identity checks, broaden fencing-token visibility, or introduce a second authoritative claimer.

### Gate 03 — Reconcile routing and registry integrity
Objective: Eliminate ambiguous station routing, particularly operation 12.12.
Tasks: (1) Compare the registry station assignment, generation scripts, active n8n flows, worker bindings, and scheduler routing. (2) Identify which assignment is authoritative under the approved workflow version. (3) If existing approval clearly resolves the discrepancy, implement the compatible correction. (4) Otherwise generate a human decision package comparing the alternatives, impact on registry hashes, and migration requirements. (5) Ensure executor routing uses a versioned mapping, not an undocumented special case. (6) Test every operation against its expected station.
PASS: All 192 operation routes resolve deterministically, and 12.12 has one approved, documented interpretation.
Guardrail: A registry-version change requires explicit approval; do not silently rewrite frozen definitions.

### Gate 04 — Complete capability and atomic-action bindings
Objective: Convert the execution blueprint into real executable plans.
Tasks: (1) Resolve every registered operation into its required capability versions. (2) Define all required atomic actions and dependency order. (3) Bind each action to an executable implementation. (4) Specify typed inputs, outputs, validation rules, timeout, idempotency, and cost policy. (5) Persist versioned action instances and attempts. (6) Detect missing bindings, cyclic dependencies, unsupported modalities, and undeclared fallback behavior. (7) Require explicit failures for unavailable capabilities rather than generic successful payloads. (8) Establish capability approval and activation procedures separately from implementation. (9) Verify that shared implementations satisfy each operation's distinct contract.
PASS: 192/192 registered operations have complete resolvable implementation plans, zero generic success fallthrough, and testable execution contracts.
Guardrail: This is an L2 readiness gate, not proof that all 192 operations have been executed or production-verified.

### Gate 05 — Verify action execution and Coordinator authority
Tasks: (1) Ensure each action is attached to its parent operation and authorized execution attempt. (2) Verify input freshness at claim time and again before authoritative promotion. (3) Record provider/engine selection and immutable configuration snapshots. (4) Enforce attempt ownership, fencing, leases, and idempotent retries. (5) Persist action-level success, failure, timeout, and cost evidence. (6) Implement parent-operation completion barriers. (7) Ensure an incomplete required action prevents operation acceptance. (8) Verify cancellation, stale callback, failure recovery, and partial repair.
PASS: All action-state and authority invariants pass, and no worker or orchestration component can bypass Coordinator acceptance.
Guardrail: Never convert a worker-reported PASS directly into authoritative acceptance.

### Gate 06 — Validate layered contracts and continuity
Tasks: (1) Preserve the approved layered envelope-plus-deliverable architecture. (2) Validate execution envelopes against registry contracts. (3) Validate actual deliverable content against typed schemas. (4) Verify artifact hashes, references, required fields, and input lineage. (5) Run continuity checks against CURRENT upstream artifacts. (6) Test intentionally malformed outputs, stale references, and contradictory content. (7) Verify repair and human-review state transitions. (8) Confirm HG2, HG4, and HG5 remain bound to exact approved artifact versions.
PASS: Invalid content is rejected with actionable evidence; corrected outputs can re-enter validation; and human-gated outputs cannot bypass approval.
Guardrail: Structural validity is not semantic quality. Do not label content production-approved solely because its schema passes.

### Gate 07 — Integrate real, measurable AI execution
Tasks: (1) Inventory which actions require text, reasoning, speech, image, video, media retrieval, rendering, or deterministic processing. (2) Match each to a verified compatible provider or local production engine. (3) Implement versioned, configurable provider bindings at station, operation, capability, and action levels. (4) Use authenticated provider requests with immutable execution configuration. (5) Record provider request IDs, model IDs, usage, latency, errors, and raw billing evidence where available. (6) Verify actual response content and artifact generation. (7) Test rate limits, provider failures, timeouts, cancellation, and asynchronous callbacks. (8) Apply provider-specific cost estimation and hard-budget checks before paid execution. (9) Prove at least one genuine real-provider execution for each implemented adapter/modality, followed by the operation-level tests in Gate 10. (10) Keep unsupported adapters BLOCKED until required credentials and permitted spending are available.
PASS: The real-provider test T3 succeeds for authorized provider integrations, with externally evidenced generation and accounting.
Guardrail: Never substitute a local stub for T3, invent credentials, or spend beyond an authorized cap. An unavailable credential is a genuine external blocker, not a reason to fake a successful test.

### Gate 08 — Calibrate independent semantic evaluation
Tasks: (1) Audit existing SEED and EXPERT cases, provenance, coverage, and evaluator requirements. (2) Establish expert-authored reference cases across relevant genres, modalities, and failure categories. (3) Satisfy the existing minimum of 50 EXPERT cases without counting SEED cases as EXPERT. (4) Validate annotation quality, reproducibility, and holdout separation. (5) Calibrate evaluators against expert judgments. (6) Measure false acceptance and false rejection for high-risk continuity and quality failures. (7) Define explicit acceptance thresholds and escalation policies. (8) Define explicit acceptance thresholds and escalation policies. (9) Test human approval, rejection, revision, and evaluator disagreement. (10) Version the evaluator, rubric, threshold, and golden set used for every verdict.
PASS: The expert-case arming requirement is met, agreed acceptance thresholds pass on independent holdouts, and semantic evaluation has reliable evidence.
Guardrail: Fifty cases satisfy a minimum arming threshold, not automatic proof of quality. When validation coverage remains insufficient, keep human review active. Do not generate supposed expert judgments using the same unverified model and label them expert-reviewed.

### Gate 09 — Verify durable artifacts and financial integrity
Tasks: (1) Deploy a real S3-compatible storage backend in the test environment. (2) Test candidate staging, SHA-256 integrity, Coordinator promotion, download, and cleanup. (3) Remove dependence on cross-tree artifact copying. (4) Measure provider usage and distinguish estimated, provider-reported, calculated, and finalized charges. (5) Test reservation, settlement, refund/release, and failed-provider charges. (6) Verify concurrency under hard-budget ceilings. (7) Test object-store outage, partial upload, duplicate callbacks, and database rollback. (8) Verify storage isolation, credentials, and recovery.
PASS: All accepted artifacts are retrievable and hash-correct; accounting reconciles without duplicate charges or unauthorized spending.
Guardrail: The ledger must record supported actual costs. A seeded reported_actual_cents: 90 value cannot represent measured AI-provider spending.

### Gate 10 — Verify all 192 operations individually
Tasks: (1) Generate an executable test case from each operation's approved contract. (2) Test each operation with valid inputs and independently validated outputs. (3) Test malformed inputs, missing dependencies, stale artifacts, and worker failures. (4) Verify atomic-action results and operation completion barriers. (5) Validate genuine provider or deterministic-engine behavior, not mock success. (6) Record actual execution evidence for all 192 operations. (7) Test each operation's declared dependency relationships. (8) Run an additional representative cross-station integration battery.
PASS: 192/192 operations individually reach L3 with retained execution and failure-path evidence. L4 is recorded separately based on real production-equivalent execution.
Guardrail: Shared worker code does not eliminate operation-specific testing. A full-graph execution does not replace isolated contract tests.

### Gate 11 — Verify cloud deployment
Tasks: (1) Select the approved cloud environment and deployment topology. (2) Package API, dashboard, n8n, scheduler, executor, worker, evaluator, and recovery services. (3) Configure managed or appropriately secured PostgreSQL and S3-compatible storage. (4) Implement production service identities, scoped authorization, and secrets management. (5) Verify TLS, network boundaries, audit logging, health checks, and resource limits. (6) Verify persistence and recovery across service and host restarts. (7) Test actual dashboard behavior in supported browsers. (8) Run authenticated API, worker, and callback security tests. (9) Confirm infrastructure and provider selection remain configurable. (10) Reproduce the local integration battery in the deployed environment.
PASS: The real deployed stack functions across restarts, persists artifacts and state, enforces security, and passes browser and operational tests.
Guardrail: Do not claim cloud deployment from Docker builds, infrastructure templates, or local container tests alone.

### Gate 12 — Execute a complete autonomous production
Tasks: (1) Create a production pinned to the approved workflow version. (2) Materialize the complete 192-operation execution graph. (3) Start the scheduler and let authorized components execute the graph. (4) Exercise every logical station and its required capabilities. (5) Complete genuine AI and deterministic actions. (6) Use human decisions only at explicitly required gates. (7) Verify current-artifact lineage between operations. (8) Complete independent validation and Coordinator acceptance. (9) Produce final deliverables and derivative outputs required by the production contract. (10) Reconcile total cost, execution durations, provider usage, and artifact completeness.
PASS: All 192 required operation instances reach their valid terminal success states, final outputs satisfy their contracts, and no unauthorized manual state manipulation occurs.
Guardrail: Human approvals are permitted where designed; manually editing database states or substituting mock artifacts is not.

### Gate 13 — Adversarial and recovery certification
Controlled fault injection across the integrated production stack. Required results: duplicate webhook → no duplicate billable execution; concurrent attempt adoption → exactly one authorized executor; expired lease → safe reconciliation and recovery; stale provider callback → no unauthorized artifact promotion; worker crash → recoverable attempt without ledger corruption; scheduler restart → no permanently orphaned work; PostgreSQL restart → consistent authoritative state; storage outage → no corrupt CURRENT artifact; provider timeout → classified retry or intervention; budget exhaustion → no unauthorized spending; malicious worker request → authorization refusal; human-gate bypass attempt → rejected with audit evidence; artifact invalidation → correct downstream repair cascade; model configuration change → existing attempt remains pinned.
PASS: Every mandatory safety invariant passes after fault injection and recovery.
Guardrail: Never disable authentication, budget enforcement, or fencing to get a test green.

### Gate 14 — Final acceptance and evidence lock
Verify that Gates 00–13 have valid evidence and that no critical or high-severity unresolved defect compromises the acceptance claim.
Final deliverables: (1) Architecture audit and remediation ledger. (2) 192-operation coverage register. (3) Capability and atomic-action implementation map. (4) Exact code and migration change manifest. (5) Coordinator authority and security report. (6) Real-provider usage and financial evidence. (7) Semantic evaluator calibration report. (8) Artifact integrity and recovery report. (9) Cloud deployment verification. (10) Complete autonomous production evidence. (11) Regression results and reproducibility commands. (12) Remaining risk, blockers, and required human decisions.
PASS: All required acceptance criteria are satisfied, independently reproducible, and tied to the exact source, registry, configuration, and deployment versions tested.
Guardrail: No summary status may override contradictory test evidence.

## 5. Automated gate controller
Implement a deterministic gate controller rather than relying on the implementing AI to remember which tasks passed.
Each task must record: task_id, gate_id, scope, owner, baseline_hash; approved_requirements, dependencies, implementation_files; test_ids, test_commands, expected_assertions; actual_results, evidence_paths, result_hashes; status, blocker, change_manifest, next_task_id.
State policy: PENDING → LOCKED → IMPLEMENTING → TESTING → VERIFYING → PASSED; test failure → REPAIR_REQUIRED; external dependency → BLOCKED_EXTERNAL; approval requirement → AWAITING_OWNER; contract or authority violation → BLOCKED_CRITICAL.
A PASSED gate must not be reopened silently. Any change to an accepted dependency triggers impact analysis and reruns of affected verification gates.

## 6. Instructions governing continuous AI execution
Execute Gates 00–14 in dependency order. Maintain the approved 192-operation hierarchy, six-station architecture, Coordinator-authoritative state, financial ledger, fencing, artifact lineage, and human approval contracts.
For every task: (1) Synchronize with the authoritative state register. (2) Verify predecessor gates and exact source hashes. (3) Acquire exclusive write ownership. (4) Read only the relevant approved source and contracts. (5) Establish expected behavior and reproducible tests. (6) Implement the smallest compatible correction. (7) Run focused tests. (8) Run integration and affected regression tests. (9) Independently verify the behavior. (10) Record exact evidence and source hashes. (11) Release ownership. (12) Mark PASSED only when every assertion succeeds. (13) Automatically advance to the next eligible approved task.
On failure, diagnose, perform a bounded repair within the same scope, and rerun all affected tests. Do not weaken assertions or change requirements to manufacture a PASS.
On an external blocker, preserve state, record exact unblock conditions, and continue any independent task whose prerequisites are satisfied. Do not mark the blocked gate complete or execute dependent tasks requiring its PASS.
On a new architectural decision, authorization requirement, destructive operation, or unapproved spending requirement, prepare a human decision package. Do not self-authorize the change.
Do not silently alter frozen registries, gate definitions, operation identities, versioning semantics, or accepted contracts.
Retain complete evidence for all 192 operations separately at DEFINED, EXECUTABLE, TESTED, and PRODUCTION-VERIFIED levels.
Continue until all approved tasks are completed or every remaining eligible task is blocked by an explicitly recorded external dependency. Never claim completion based on partial coverage.
Final success requires every mandatory gate to PASS, all 192 operation paths to be verified, real-provider evidence to exist, independent semantic quality policies to be satisfied, production deployment to be demonstrated, and a full autonomous production to complete with no Coordinator-authority violation.
The central acceptance rule is no gate advancement without test evidence, no production claim without real execution, and no architectural changes outside approved authority.
