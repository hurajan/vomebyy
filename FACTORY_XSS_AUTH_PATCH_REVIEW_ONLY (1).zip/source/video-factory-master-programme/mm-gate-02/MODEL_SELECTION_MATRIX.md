# MM-02 — MODEL SELECTION MATRIX

**matrix_version 1.0.0 · status: PROPOSED** — promotion to ACTIVE requires explicit owner authorization (MM-03 registry promotion; final approval at MM-12). These selections are **never silently active**: no workflow node may hardcode these model IDs; bindings resolve through the MM-03 central registry, and a production pins its approved configuration.

**Catalog provenance:** LIVE FETCH — `GET https://openrouter.ai/api/v1/models`, 2026-10-29T15:09:09Z, HTTP 200, **457 models**, no credential used. Snapshot: `evidence/catalog_snapshot.json` (trimmed faithful form with embedded provenance). Fetch record: `evidence/fetch_log.txt`. Machine-readable coverage: `evidence/selection.json` (all 192 operations).

**Amendment (2026-10-29):** `evidence/selection.json` was data-amended to **data_version 1.0.1**, correcting MM-02 verifier defects D1–D3 in ancillary fields only (`null_assignments` per-row reasons, the 08.12 `reconciliation_note`, `coverage_counts` role naming) — assignments unchanged; this matrix and **matrix_version 1.0.0** are unchanged, and the data_version bump applies to the data artifact only, so the two versions do not conflict.

**Benchmark labeling:** every comparative quality statement in this matrix is **UNVERIFIED_BENCHMARK**. Selections rest on catalog facts only — modality, context length, structured-output support (`supported_parameters`), pricing, provider family — plus task fit against the MM-01 classification. No task-specific comparative benchmark was run in this gate, and no benchmark numbers are invented. Quality-first ordering was applied as: frontier-class model lines for high-creative work, strongest structured-output support for extraction/judgment, then context fit, family diversity for fallback independence, then cost.

**Cross-cutting rules**
- **Fallback independence:** every fallback is a different provider family from its primary.
- **Evaluation independence:** all AI_EVAL operations route to the EVALUATION role, never to the generating station's model. Where the generating station's primary equals the EVALUATION primary (Station 04 only), the EVALUATION fallback judges instead (per-operation in `selection.json`).
- **Context rule:** L-band operations require ≥128k context; every assigned primary satisfies this (mechanically verified; smallest assigned primary context is 400k, image pair excepted — media ops are S-band).
- **Cost sanity (catalog arithmetic, not a benchmark):** at MM-01 caps (AI_TEXT ≤100¢, AI_EVAL ≤50¢ per op), even the most expensive selected pair (Opus-class at $25/M output tokens) funds ≈20k output tokens per eval-capped call and ≈40k per text-capped call — the caps bind before the models do.
- **Deterministic validators (all stations, from MM-01):** schema validation (step envelope + deliverable schema where one exists) · dependency integrity (CURRENT input currency + sha256 binding) · hash integrity (artifact sha256 + durable-store byte verification). Only **2** named rubrics are implemented today — `script_canon_coverage` (08.12) and `rule_of_six` (12.12); the other 41 named registry checks are named-but-unimplemented and are MM-07 work. The golden set is unarmed (0 EXPERT; threshold 50, never lowered) — semantic judgment routes to human review until MM-07/MM-08 of the first series' successor work arms it.

---

## Station 01 — Intake and Authority (3 AI_TEXT ops assigned)
*Responsibility: structured extraction, instruction fidelity, rights classification, safety screening.*
- **Primary: `openai/gpt-4.1`** — catalog: context 1,047,576; $2.00/$8.00 per M tokens; `structured_outputs` + `response_format` supported; text+image+file input. Chosen for structured-output strength and instruction fidelity (UNVERIFIED_BENCHMARK).
- **Fallback: `anthropic/claude-sonnet-4.5`** (Anthropic) — context 1,000,000; $3.00/$15.00 per M; structured outputs supported.
- **Evaluation model:** EVALUATION role (below) — Station 01 carries 7 AI_EVAL ops, all judged there.
- **High tier:** none — MM-01 classifies no HIGH-tier AI op in Station 01; the creative-escalation pair (below) applies if that changes.
- **Deterministic validators:** base set + named checks `charter_completeness`, `rights_decision_present`, `vendor_policy_check` (named, unimplemented → MM-07) + registry human gates.
- **Privacy:** step-02 operations are **rights-bearing** (consent/rights records per asset; op 02.03 also involves minors). The models API carries **no structured per-model data-policy or training-use terms**, so no catalog-grounded privacy preference can be claimed — **MM-12 confirmation item**: owner must confirm provider data-retention/no-training terms for Station 01 (and Station 02) content before any genuine call. Until then, rights-bearing content does not leave the factory.

## Station 02 — Reality and People (7 AI_TEXT ops, all HIGH tier; 4 AI_EVAL routed to EVALUATION)
*Responsibility: source reasoning, consistency, canon construction, character psychology, identity, continuity.*
- **Primary (default): `anthropic/claude-sonnet-4.5`** — 1,000,000 context (canon-scale), structured outputs, $3.00/$15.00 per M.
- **Fallback (default): `openai/gpt-5`** (OpenAI) — 400,000 context, structured outputs, $1.25/$10.00 per M.
- **HIGH tier (all 7 AI_TEXT ops): primary `anthropic/claude-opus-4.8`** — frontier Anthropic line, 1,000,000 context, structured outputs supported (note the catalog fact that `claude-opus-4.1` does *not* list structured-output support, which is why the current Opus line is selected), $5.00/$25.00 per M. **Fallback `openai/gpt-5.5`** — 1,050,000 context, structured outputs, $5.00/$30.00 per M.
- **Evaluation model:** EVALUATION role.
- **Deterministic validators:** base set + named continuity/consistency checks (unimplemented → MM-07).
- **Privacy:** step-03 content is **source/canon material about real-world subjects**; step-04 is **personal-data-adjacent** (character/person identity, biography, voice records). Same MM-12 confirmation requirement as Station 01.

## Station 03 — Narrative (22 generation assignments: 21 AI_TEXT, all HIGH tier, + MIXED 08.11; 3 AI_EVAL routed to EVALUATION)
*Responsibility: long-form story architecture, hooks, causality, dialogue, scriptwriting, emotional progression, contextual consistency.*
- **Primary (default): `anthropic/claude-sonnet-4.5`**; **fallback (default): `google/gemini-2.5-pro`** (Google) — 1,048,576 context, structured outputs, $1.25/$10.00 per M.
- **HIGH tier (all 21 AI_TEXT ops incl. 08.12): primary `anthropic/claude-opus-4.8`**, **fallback `openai/gpt-5.5`** — the station's top creative pair, per the tier rule. Frontier creative quality is claimed as UNVERIFIED_BENCHMARK; the catalog-grounded facts are context (1M / 1.05M), structured-output support, and family diversity.
- **Evaluation model:** EVALUATION role. The one implemented semantic-adjacent check for this station is deterministic: the `script_canon_coverage` rubric on 08.12.
- **Deterministic validators:** base set + `script_canon_coverage` (08.12 only); all other named checks unimplemented → MM-07.
- **Reconciliation (recorded, not silent):** the Lean slice's PROPOSED 08.12 binding (`anthropic/claude-haiku-4.5`, 25¢ estimate) predates this matrix. This matrix assigns 08.12 the Station 03 HIGH pair. The slice binding stays untouched until MM-12 promotion; MM-13's genuine battery runs the promoted matrix.
- **Privacy:** narrative content derives from Station 02 canon — inherits its MM-12 confirmation.

## Station 04 — Direction and Capture (8 HIGH AI_TEXT + 1 image AI_MEDIA assigned; 3 AI_MEDIA → MM-06; 5 AI_EVAL + MIXED 10.11 → EVALUATION with independence switch)
*Responsibility: visual direction, multimodal interpretation, storyboard planning, shot design, media acquisition decisions.*
- **Primary: `google/gemini-2.5-pro`** — the catalog's broadest input modality (text+image+file+**audio+video** → text), 1,048,576 context, structured outputs, $1.25/$10.00 per M. Multimodal interpretation is this station's core work; the modality fact is catalog-grounded.
- **Fallback: `anthropic/claude-sonnet-4.5`**.
- **HIGH tier (8 shot-design AI_TEXT ops): primary `anthropic/claude-opus-4.8`**, fallback `openai/gpt-5.5` (creative escalation pair).
- **Media generation (image): primary `google/gemini-3-pro-image`** — text+image → text+image, 131,072 context, per-image output pricing in catalog ($0.00012/image-output token unit as listed); **fallback `openai/gpt-5-image`** (OpenAI; 400,000 context). Assigned to op **10.10** (storyboard boards) only.
- **No adequate catalog model — stated plainly:** ops **11.04, 11.06, 11.11** (audio/video media-asset generation) have **no OpenRouter catalog path**: the fetched catalog contains **zero video-output models (0/457)**, and its only audio-output entries are two music-generation previews (Lyria) and two audio-I/O chat models (gpt-audio line) — none is a supported path for these operations. All three are assigned to the **MM-06 specialized-provider path** with null model fields in `selection.json`. No text model is forced into media generation.
- **Evaluation model:** EVALUATION **fallback** (`openai/gpt-5`) — independence switch, because this station's generator primary equals the EVALUATION primary.
- **Deterministic validators:** base set + media integrity/codec validation (MEDIA_TOOL class → MM-06) + named coverage checks (unimplemented → MM-07).
- **Privacy:** op 11.04 is **personal-data-adjacent (reference identities / likeness)** — likeness-bearing references must not be sent to any provider until the MM-12 privacy confirmation covers them.

## Station 05 — Post and Packaging (3 AI_TEXT ops, all HIGH tier; 3 AI_EVAL + MIXED 13.07 → EVALUATION)
*Responsibility: editorial reasoning, cross-modal checking, caption validation, packaging, titles, derivative coherence.*
- **Primary (default): `openai/gpt-5`** — multimodal input, structured outputs, 400,000 context, $1.25/$10.00 per M. **Fallback: `anthropic/claude-sonnet-4.5`**.
- **HIGH tier (3 ops): primary `anthropic/claude-opus-4.8`**, fallback `openai/gpt-5.5`.
- **Evaluation model:** EVALUATION role.
- **Deterministic validators:** base set + implemented rubric `rule_of_six` (12.12 only; Emotion 51 / Story 23 / Rhythm 10 / Eye Trace 7 / 2D Plane 5 / 3D Space 4, as data; never overrides hard failures) + named cross-modal/editorial checks (unimplemented → MM-07).

## Station 06 — Release and Learn (1 AI_TEXT op assigned; 2 AI_EVAL → EVALUATION)
*Responsibility: metadata, performance interpretation, analytics, experimentation, improvement proposals.*
- **Primary: `google/gemini-2.5-flash`** — 1,048,576 context, structured outputs, $0.30/$2.50 per M; cost-appropriate for metadata/analytics volume. **Fallback: `openai/gpt-5-mini`** (OpenAI) — 400,000 context, structured outputs, $0.25/$2.00 per M.
- **High tier:** none classified in Station 06 (MM-01); escalation pair applies if reclassified.
- **Evaluation model:** EVALUATION role.
- **Deterministic validators:** base set + named metadata/analytics checks (unimplemented → MM-07).
- **Privacy:** step-15 operations are **external transmission** (platform publication) and step 15.06 is credential-adjacent — those are EXTERNAL_SERVICE class (no model assigned); publication stays behind the existing provider-adapter + human-gate controls, not model selection.

## EVALUATION role — independent AI judgment (27 assignments: 24 AI_EVAL + MIXED 04.11, 10.11, 13.07)
- **Primary: `google/gemini-2.5-pro`** — multimodal (can judge text against image/audio/video evidence), 1,048,576 context, structured outputs (verdict-shaped JSON), $1.25/$10.00 per M. Differs from the generator primary of every station except Station 04 (handled by the switch below).
- **Fallback: `openai/gpt-5`** — also serves as the **judge for all Station 04 AI_EVAL operations** under the independence rule (a station is never judged by its own generator model).
- **Deterministic validators:** base set + the golden-set arming rule (EXPERT-only, threshold 50; currently 0 EXPERT — the semantic layer remains unarmed and routes to AWAITING_HUMAN; worker/generator verdicts are advisory only, exactly as built in Gate E).
- Quality claims for judge accuracy: **UNVERIFIED_BENCHMARK** — no comparative judging evidence exists yet; MM-07's negative-test battery is where judgment quality gets its first task-specific evidence.

---

## Coverage summary (from `selection.json`, mechanically verified)
| Assignment | Ops |
|---|---|
| STATION_01 pair | 3 |
| STATION_02 pair (HIGH pair for all 7) | 7 |
| STATION_03 pair (HIGH pair for 21; default for MIXED 08.11) | 22 |
| STATION_04 pair (HIGH pair for 8) | 8 |
| STATION_04 media image pair (10.10) | 1 |
| STATION_05 pair (HIGH pair for all 3) | 3 |
| STATION_06 pair | 1 |
| EVALUATION role | 27 |
| MM-06 specialized-provider path (11.04, 11.06, 11.11 — null models, reasons recorded) | 3 |
| No model (DETERMINISTIC 68 · HUMAN_DECISION 25 · MEDIA_TOOL 10 · EXTERNAL_SERVICE 11 · MIXED human-only 3) | 117 |
| **Total** | **192** |

Every model ID named above was verified mechanically to exist in `catalog_snapshot.json`; every L-band assignment's primary meets the ≥128k context rule. Stations with no adequate catalog model for a responsibility: **Station 04 media generation (audio/video)** — recorded above and in `selection.json`; all other responsibilities have at least two catalog-supported candidates from different provider families.
