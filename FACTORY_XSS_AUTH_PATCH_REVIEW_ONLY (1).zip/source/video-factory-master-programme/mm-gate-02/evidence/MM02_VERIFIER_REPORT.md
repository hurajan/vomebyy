# MM-02 INDEPENDENT VERIFIER REPORT

**Verdict: NOT VERIFIED as-is — core selection work verified sound; two MAJOR internal-consistency defects in `selection.json` ancillary fields must be corrected before MM-03 consumes the artifact.**
All brief-specified mechanical checks (items 1–5) PASS. The verdict is withheld solely on defects D1/D2 below, found by additional consistency checks (4j/4k in the checker): the machine-readable artifact contradicts itself and the matrix doc on (a) which operations have no catalog model and why, and (b) the flagship operation 08.12's assigned primary. Remediation is data-only — no re-selection, no re-fetch: the 192 assignment rows, all role entries, the snapshot, and the matrix doc are verified correct.
Checker: `evidence/check_mm02.py` · output: `evidence/check_mm02_output.txt` — **33 checks: 30 PASS / 3 FAIL** (the 3 failures are the extra consistency checks 4j/4k/4l; every brief-specified check passes).

---

## Item 1 — PROVENANCE: **PASS**
- `fetch_log.txt` shows the live fetch: `curl … https://openrouter.ai/api/v1/models`, **HTTP 200**, timestamp **2026-10-29T15:09:09Z**, curl exit 0, 768,853 bytes, `credential_used: none`.
- `catalog_snapshot.json` embedded provenance matches the log exactly (source `openrouter-api`, same URL/timestamp/status), and `selection.json`'s `catalog_provenance` is byte-identical to the snapshot's provenance object.
- Snapshot contains **457 models, 457 unique ids** (expected 457 ✓). The raw response (`catalog_raw.json`, retained in the same evidence dir) independently corroborates: 457 entries, identical id set.

## Item 2 — ID EXISTENCE + FACT ACCURACY: **PASS**
- **10 unique model ids** are named across `selection.json` (all role primaries/fallbacks/evaluation models, high-tier and media pairs, and all 192 assignment rows): **all 10 exist in the snapshot; zero missing.**
- Stronger than briefed: **all 30 role entries** (every station's primary, fallback, evaluation_model, high-tier pair, media pair, plus the EVALUATION role) match the snapshot **exactly** on context_length, per-token pricing, derived $/M pricing, and modality string — zero mismatches.
- The matrix doc quotes exact context and $/M pricing pairs for the **7 role primaries + the HIGH pair** (`anthropic/claude-opus-4.8` $5.00/$25.00, 1,000,000; `openai/gpt-5.5` $5.00/$30.00, 1,050,000) — all present and correct in the doc.
- **L-band rule:** 21 L-band operations in the MM-01 classification; the 3 with an assigned primary (05.11 → `google/gemini-2.5-pro` 1,048,576; 08.12 → `anthropic/claude-opus-4.8` 1,000,000; 12.10 → `google/gemini-2.5-pro`) all satisfy ≥128,000 (the remaining 18 L rows are DETERMINISTIC/HUMAN_DECISION with no model, correctly). Doc's context-sanity claim also verified: minimum assigned primary context = 131,072 (the image model), minimum non-image = 400,000, as stated.

## Item 3 — SELECTION RULES: **PASS**
- **Fallback family independence:** every role pair — 7 primary/fallback pairs, 4 identical high-tier pairs, the media pair, the EVALUATION pair — spans two different provider families (prefix before `/`). Also verified per-row: no assignment row pairs a primary and fallback from the same family.
- **Evaluation independence:** all **27 EVALUATION assignments** are judged by a model that is neither the generating station's default primary nor its HIGH primary. **Station 04 switch confirmed:** the 6 Station 04 evaluation assignments (09.03, 09.08, 10.03, 10.11, 11.08, 11.09) are judged by the EVALUATION **fallback** `openai/gpt-5` (primary/fallback swapped in-row), because Station 04's generator primary equals the EVALUATION primary (`google/gemini-2.5-pro`). All other stations' eval assignments use the EVALUATION primary.
- **AI_EVAL purity:** all 24 pure AI_EVAL operations are assigned to the EVALUATION role; none is assigned its own station's generator primary.
- Observation (not a defect): in EVALUATION rows, the *fallback* is the EVALUATION primary, which for Stations 04/05 equals that station's generator primary — the assigned judge (primary) is always independent, which is what the rule governs; a future promotion should note the fallback would only be reached on judge failure.

## Item 4 — COVERAGE ACCOUNTING: **PASS on every brief-specified check; FAIL on internal consistency of ancillary fields (defects D1–D3)**
Passing, mechanically:
- `selection.json` covers **exactly the 192 MM-01 classification ids** (no extras, no duplicates); every row agrees with the classification on station, execution_class, context_band, and creative_quality_tier for all 192.
- **72 rows have a non-null primary** (expected 72 ✓); **120 rows are null, every one with a recorded `null_reason`** (expected 120 ✓), splitting exactly **117 role-`none` + 3 MM06**.
- Every DETERMINISTIC (68), HUMAN_DECISION (25), MEDIA_TOOL (10), and EXTERNAL_SERVICE (11) operation has assignment `none` + reason.
- Ops **11.04 / 11.06 / 11.11**: assigned_role `MM06_SPECIALIZED_PROVIDER`, null model fields, `null_reason` explicitly routes to the MM-06 specialized-provider path.
- Op **10.10**: primary `google/gemini-3-pro-image`, fallback `openai/gpt-5-image` — both exist in the snapshot, both with `image` in `output_modalities`.

Defects found by the verifier's extra consistency checks:
- **D1 — MAJOR. `selection.json` top-level `null_assignments` is factually wrong.** It lists 6 operations (02.11, 11.04, 11.06, 11.10, 11.11, 16.06), all carrying the same audio/video-media reason. For **02.11, 11.10, and 16.06** that reason is false: their own assignment rows (and the MM-01 classification) show MIXED human-only operations with structured-record outputs and the human-only `null_reason`. The list also represents neither the 120 null rows nor exactly the 3 MM-06 ops. An MM-03 consumer reading this field would misroute three operations to specialized media providers.
- **D2 — MAJOR. `selection.json` `reconciliation_note` contradicts the assignments and the matrix doc on 08.12.** The note states 08.12 "is assigned the Station 03 default pair … primary anthropic/claude-sonnet-4.5". The assignment row (verified against the snapshot) and the matrix doc both assign the **HIGH pair** (`anthropic/claude-opus-4.8` / `openai/gpt-5.5`). The note's second claim — that the Lean slice binding stays untouched — is true (item 5f), but its model claim is a contradictory binding statement about the programme's flagship operation.
- **D3 — MINOR. `coverage_counts` role naming vs assignments.** `coverage_counts` splits Station 04 into `STATION_04: 8` + `STATION_04_MEDIA: 1` (matching the matrix doc's coverage table), while assignment rows use role `STATION_04` for all 9 (10.10 distinguished only by `tier_rule`). Totals reconcile to 192 either way; the split is a labeling inconsistency, not a count error.

## Item 5 — HONESTY SWEEP: **PASS**
- Superlative/comparative lines in the doc (grep, 4 hits): the global labeling statement (line 7: *"every comparative quality statement in this matrix is **UNVERIFIED_BENCHMARK**"*), "frontier Anthropic line" (line 31, same sentence cites catalog facts), "the station's top creative pair" (Station 03 section, labeled UNVERIFIED_BENCHMARK in the same bullet), and "the catalog's broadest input modality" (line 47). `UNVERIFIED_BENCHMARK` appears 4× in the doc and as the labeling policy in `selection.json`. No benchmark numbers are asserted anywhere; no "best" claim appears.
- The doc's catalog-fact claims verify against the snapshot: gemini-2.5-pro's input set (text+image+file+audio+video, 5 modalities) is in the catalog's broadest class (30 models share the 5-modality maximum — the enumerated set for this model is exact; "broadest" is a shared maximum, recorded here as a precision note, not a defect); `anthropic/claude-opus-4.1` indeed lacks `structured_outputs` in `supported_parameters`, as the doc states; **zero video-output models** exist in the snapshot (audio-output = exactly the 4 entries the doc/log name: 2 Lyria previews + gpt-audio line).
- **Status/version:** doc header and `selection.json` both read **status PROPOSED, matrix_version 1.0.0**, with promotion requiring explicit owner authorization.
- **Privacy honesty:** the doc states in three places that the models API carries **no structured per-model data-policy or training-use terms** and makes provider data-retention/no-training confirmation an **MM-12 item**; the fetch log records the catalog entry keys (no policy fields), and the snapshot's entry keys confirm no policy/training/retention fields exist.
- **Lean slice untouched:** `lean-phase-3/tools/setup_slice.py` still pins `MODEL = "anthropic/claude-haiku-4.5"` — the matrix does not alter the slice's PROPOSED 08.12 binding.

---

## Verdict against the PASS criterion
*"Versioned model-selection matrix exists, with supported capabilities, selection rationale, provenance, and explicit unverified benchmarks."*

The matrix **exists and satisfies every element of the criterion on its substance**: versioned (1.0.0, PROPOSED), provenance live-fetched and reproducible (457 models, HTTP 200, no credential), capabilities/rationale grounded in verified catalog facts for all 192 operations, benchmarks explicitly labeled UNVERIFIED_BENCHMARK, costs/context/family rules mechanically verified, and the MM-06 gap stated plainly rather than papered over.

**MM-02: NOT VERIFIED (remediable data amendment required)** — defects D1 (MAJOR) and D2 (MAJOR) are contradictory statements inside the versioned machine-readable artifact itself; under this programme's no-contradictory-bindings rule the gate cannot be certified until they are corrected. Required amendment (assignments, roles, snapshot, and matrix doc need **no** changes): (1) fix or remove `selection.json`'s top-level `null_assignments` so it matches the assignment rows (the true MM-06 set is exactly 11.04/11.06/11.11); (2) correct `reconciliation_note` to state 08.12's HIGH pair; (3) align `coverage_counts` naming with assignment roles (D3, MINOR — fix in the same pass). After that amendment, re-running `check_mm02.py` to 33/33 would support a PASSED verdict without further verification scope.
