#!/usr/bin/env python3
"""MM-02 independent verifier checker. Mechanical only; reads the gate's own
artifacts + MM-01 classification + the Lean slice setup script. No network."""
import json, re, sys
from pathlib import Path
from collections import Counter

BASE = Path.home() / "workspace/video-factory-master-programme"
SEL_P = BASE / "mm-gate-02/evidence/selection.json"
SNAP_P = BASE / "mm-gate-02/evidence/catalog_snapshot.json"
RAW_P = BASE / "mm-gate-02/evidence/catalog_raw.json"
LOG_P = BASE / "mm-gate-02/evidence/fetch_log.txt"
DOC_P = BASE / "mm-gate-02/MODEL_SELECTION_MATRIX.md"
CLS_P = BASE / "mm-gate-01/evidence/classification.json"
SLICE_P = BASE / "lean-phase-3/tools/setup_slice.py"

sel = json.loads(SEL_P.read_text())
snap = json.loads(SNAP_P.read_text())
cls = json.loads(CLS_P.read_text())
doc = DOC_P.read_text()
log = LOG_P.read_text()
models = {m["id"]: m for m in snap["data"]}
cls_rows = {r["operation_id"]: r for r in cls["rows"]}
assign = {a["operation_id"]: a for a in sel["assignments"]}

results = []  # (item, ok, detail)
def chk(item, ok, detail=""):
    results.append((item, bool(ok), detail))
    print(f"[{'PASS' if ok else 'FAIL'}] {item} :: {detail}")

# ---------- 1. PROVENANCE ----------
chk("1a fetch_log shows live GET url", "https://openrouter.ai/api/v1/models" in log and "curl" in log, "url+curl in fetch_log")
m = re.search(r"http_status:\s*(\d+)", log); ts = re.search(r"timestamp_utc:\s*(\S+)", log)
chk("1b fetch_log HTTP 200 + timestamp", m and m.group(1) == "200" and ts.group(1) == "2026-10-29T15:09:09Z",
    f"status={m.group(1) if m else None} ts={ts.group(1) if ts else None}")
prov = snap.get("provenance", {})
chk("1c snapshot embedded provenance matches fetch_log",
    prov.get("url") == "https://openrouter.ai/api/v1/models" and prov.get("http_status") == 200
    and prov.get("fetched_at") == "2026-10-29T15:09:09Z" and prov.get("model_count") == 457
    and sel["catalog_provenance"] == prov,
    f"snapshot prov={prov}; selection.catalog_provenance identical={sel['catalog_provenance']==prov}")
chk("1d snapshot model count == 457", len(snap["data"]) == 457 and len(models) == 457, f"data={len(snap['data'])} unique_ids={len(models)}")
if RAW_P.exists():
    raw = json.loads(RAW_P.read_text())
    rawdata = raw.get("data", raw if isinstance(raw, list) else [])
    chk("1e raw catalog corroborates (457, same id set)", len(rawdata) == 457 and {x['id'] for x in rawdata} == set(models),
        f"raw={len(rawdata)}")
chk("1f fetch_log records no credential used", "credential_used: none" in log, "")

# ---------- 2. ID EXISTENCE + FACT ACCURACY ----------
named = set()
def collect(o):
    if isinstance(o, dict):
        for k, v in o.items():
            if k == "model_id" and isinstance(v, str): named.add(v)
            elif k in ("primary", "fallback") and isinstance(v, str): named.add(v)
            else: collect(v)
    elif isinstance(o, list):
        for v in o: collect(v)
collect(sel["roles"]); collect(sel["assignments"])
missing = sorted(x for x in named if x not in models)
chk("2a every model id named in selection.json exists in snapshot", not missing,
    f"named={len(named)} ids; missing={missing}")

def snap_facts(mid):
    mm = models[mid]
    p = mm.get("pricing") or {}
    return mm["context_length"], p.get("prompt"), p.get("completion"), p.get("image_output")

def role_entries():
    out = []
    for rk, rv in sel["roles"].items():
        for slot in ("primary", "fallback", "evaluation_model"):
            if rv.get(slot): out.append((f"{rk}.{slot}", rv[slot]))
        ht = rv.get("high_tier")
        if ht:
            for slot in ("primary", "fallback"): out.append((f"{rk}.high_tier.{slot}", ht[slot]))
        mg = rv.get("media_generation")
        if mg:
            for slot in ("primary", "fallback"): out.append((f"{rk}.media_generation.{slot}", mg[slot]))
    return out

bad = []
for label, e in role_entries():
    ctx, pr, co, io = snap_facts(e["model_id"])
    if e["context_length"] != ctx: bad.append(f"{label} ctx sel={e['context_length']} snap={ctx}")
    pp = e["pricing_usd_per_token"]
    if pp.get("prompt") != pr or pp.get("completion") != co: bad.append(f"{label} pricing sel={pp} snap=({pr},{co})")
    if (pp.get("image_output") or None) != (io or None): bad.append(f"{label} image_output sel={pp.get('image_output')} snap={io}")
    pm = e["pricing_usd_per_m_tokens"]
    if abs(pm["prompt"] - float(pr) * 1e6) > 1e-9 or abs(pm["completion"] - float(co) * 1e6) > 1e-9:
        bad.append(f"{label} per-M mismatch sel={pm} snap=({float(pr)*1e6},{float(co)*1e6})")
    mod = (models[e["model_id"]].get("architecture") or {}).get("modality")
    if e.get("modality") != mod: bad.append(f"{label} modality sel={e.get('modality')} snap={mod}")
chk("2b ALL role entries (primary/fallback/eval/high/media) match snapshot ctx+pricing+modality exactly",
    not bad, f"entries_checked={len(role_entries())}; mismatches={bad}")

# doc-quoted facts for the 7 role primaries + HIGH pair
def fmt_ctx(c): return f"{c:,}"
def fmt_usd(per_token):
    v = float(per_token) * 1e6
    return f"${v:.2f}"
docbad = []
role_primaries = [(rk, rv["primary"]) for rk, rv in sel["roles"].items() if rv.get("primary")]
high_pair = [sel["roles"]["STATION_02"]["high_tier"]["primary"], sel["roles"]["STATION_02"]["high_tier"]["fallback"]]
for label, e in role_primaries + [("HIGH.primary", high_pair[0]), ("HIGH.fallback", high_pair[1])]:
    ctx, pr, co, _ = snap_facts(e["model_id"])
    if e["model_id"] not in doc: docbad.append(f"{label}: id not in doc")
    if fmt_ctx(ctx) not in doc: docbad.append(f"{label}: ctx {fmt_ctx(ctx)} not quoted in doc")
    pair = f"{fmt_usd(pr)}/{fmt_usd(co)}"
    if pair not in doc: docbad.append(f"{label}: pricing pair {pair} not quoted in doc")
chk("2c matrix doc quotes exact ctx + $/M pricing for 7 role primaries + HIGH pair", not docbad, f"problems={docbad}")

# L-band context rule (join with classification)
lbad = []
for oid, r in cls_rows.items():
    if r["context_band"] == "L":
        a = assign[oid]
        # selection.json row must agree with classification on band/class
        if a["context_band"] != "L": lbad.append(f"{oid} band mismatch in selection")
        if a["primary"] is not None:
            c = models[a["primary"]]["context_length"]
            if c < 128000: lbad.append(f"{oid} L-band primary ctx {c} < 128000")
chk("2d every L-band assigned primary has context_length >= 128000", not lbad,
    f"L rows={sum(1 for r in cls_rows.values() if r['context_band']=='L')}, with primary={[o for o,r in cls_rows.items() if r['context_band']=='L' and assign[o]['primary']]}; problems={lbad}")
allctx = [(a["primary"], models[a["primary"]]["context_length"]) for a in sel["assignments"] if a["primary"]]
nonimg = [(p, c) for p, c in allctx if p != "google/gemini-3-pro-image"]
chk("2e doc context sanity claim (min non-image primary = 400k)", min(c for _, c in nonimg) == 400000 and min(c for _, c in allctx) == 131072,
    f"min_all={min(c for _,c in allctx)} min_non_image={min(c for _,c in nonimg)}")

# ---------- 3. SELECTION RULES ----------
def fam(mid): return mid.split("/")[0]
fbad = []
for label, rv in [(rk, rv) for rk, rv in sel["roles"].items()]:
    pairs = []
    if rv.get("primary") and rv.get("fallback"): pairs.append(("primary/fallback", rv["primary"]["model_id"], rv["fallback"]["model_id"]))
    ht = rv.get("high_tier")
    if ht: pairs.append(("high pair", ht["primary"]["model_id"], ht["fallback"]["model_id"]))
    mg = rv.get("media_generation")
    if mg: pairs.append(("media pair", mg["primary"]["model_id"], mg["fallback"]["model_id"]))
    for name, p, f in pairs:
        if fam(p) == fam(f): fbad.append(f"{label} {name}: same family {p} / {f}")
abads = [a["operation_id"] for a in sel["assignments"] if a["primary"] and a["fallback"] and fam(a["primary"]) == fam(a["fallback"])]
chk("3a every role fallback is a different provider family than its primary (incl. high/media/eval pairs)",
    not fbad and not abads, f"role_problems={fbad}; assignment_same_family={abads}")

station_default = {1: "openai/gpt-4.1", 2: "anthropic/claude-sonnet-4.5", 3: "anthropic/claude-sonnet-4.5",
                   4: "google/gemini-2.5-pro", 5: "openai/gpt-5", 6: "google/gemini-2.5-flash"}
# derive from roles instead of hardcoding
station_default = {rv["station"]: rv["primary"]["model_id"] for rv in sel["roles"].values() if rv.get("station")}
station_high = {rv["station"]: rv["high_tier"]["primary"]["model_id"] for rv in sel["roles"].values() if rv.get("station") and rv.get("high_tier")}
eval_primary = sel["roles"]["EVALUATION"]["primary"]["model_id"]; eval_fallback = sel["roles"]["EVALUATION"]["fallback"]["model_id"]
ebad, st4 = [], []
for a in sel["assignments"]:
    if a["assigned_role"] == "EVALUATION":
        st = a["station"]
        if a["primary"] == station_default.get(st): ebad.append(f"{a['operation_id']} judged by own station default primary")
        if station_high.get(st) and a["primary"] == station_high[st]: ebad.append(f"{a['operation_id']} judged by own station HIGH primary")
        if st == 4:
            st4.append(a["operation_id"])
            if a["primary"] != eval_fallback: ebad.append(f"{a['operation_id']} St04 eval not switched to EVALUATION fallback")
        else:
            if a["primary"] != eval_primary: ebad.append(f"{a['operation_id']} non-St04 eval primary != EVALUATION primary")
chk("3b EVALUATION independence incl. Station 04 switch", not ebad,
    f"eval_assignments={sum(1 for a in sel['assignments'] if a['assigned_role']=='EVALUATION')}; st04_eval_ops={st4}; problems={ebad}")
aieval = [a for a in sel["assignments"] if a["execution_class"] == "AI_EVAL"]
aibad = [a["operation_id"] for a in aieval if a["primary"] == station_default.get(a["station"]) or a["primary"] == station_high.get(a["station"])]
chk("3c AI_EVAL ops never assigned their own station's generator primary", not aibad and all(a["assigned_role"] == "EVALUATION" for a in aieval),
    f"AI_EVAL ops={len(aieval)}; problems={aibad}")

# ---------- 4. COVERAGE ACCOUNTING ----------
chk("4a selection covers exactly the 192 classification ids",
    set(assign) == set(cls_rows) and len(sel["assignments"]) == 192 and len(set(assign)) == 192,
    f"assignments={len(sel['assignments'])} unique={len(set(assign))} cls={len(cls_rows)}")
nonnull = [a for a in sel["assignments"] if a["primary"] is not None]
nulls = [a for a in sel["assignments"] if a["primary"] is None]
chk("4b non-null primary rows == 72", len(nonnull) == 72, f"nonnull={len(nonnull)}")
chk("4c null rows == 120, all with recorded null_reason", len(nulls) == 120 and all(a.get("null_reason") for a in nulls),
    f"nulls={len(nulls)} without_reason={[a['operation_id'] for a in nulls if not a.get('null_reason')]}")
none_rows = [a for a in sel["assignments"] if a["assigned_role"] == "none"]
mm06 = [a for a in sel["assignments"] if a["assigned_role"] == "MM06_SPECIALIZED_PROVIDER"]
chk("4d null split: 117 role-none + 3 MM06 == 120", len(none_rows) == 117 and len(mm06) == 3,
    f"none={len(none_rows)} mm06={len(mm06)} mm06_ids={[a['operation_id'] for a in mm06]}")
purebad = []
for ec in ("DETERMINISTIC", "HUMAN_DECISION", "MEDIA_TOOL", "EXTERNAL_SERVICE"):
    for a in sel["assignments"]:
        if a["execution_class"] == ec and not (a["assigned_role"] == "none" and a["primary"] is None and a.get("null_reason")):
            purebad.append(f"{a['operation_id']} {ec} role={a['assigned_role']}")
chk("4e every DETERMINISTIC/HUMAN_DECISION/MEDIA_TOOL/EXTERNAL_SERVICE op: assignment none + reason", not purebad, f"problems={purebad}")
chk("4f ops 11.04/11.06/11.11 point at MM-06 path",
    all(assign[o]["assigned_role"] == "MM06_SPECIALIZED_PROVIDER" and "MM-06" in (assign[o].get("null_reason") or "") for o in ("11.04", "11.06", "11.11")),
    "")
a1010 = assign["10.10"]
outs = {m: (models[m].get("architecture") or {}).get("output_modalities", []) for m in (a1010["primary"], a1010["fallback"])}
chk("4g op 10.10 image models exist in snapshot with image output modality",
    all(m in models and "image" in o for m, o in outs.items()), f"10.10={a1010['primary']}/{a1010['fallback']} output_modalities={outs}")
# class/band consistency selection vs classification
consbad = [a["operation_id"] for a in sel["assignments"]
           if a["execution_class"] != cls_rows[a["operation_id"]]["execution_class"]
           or a["context_band"] != cls_rows[a["operation_id"]]["context_band"]
           or a["station"] != cls_rows[a["operation_id"]]["station"]
           or a["creative_quality_tier"] != cls_rows[a["operation_id"]]["creative_quality_tier"]]
chk("4h selection rows agree with classification on station/class/band/tier for all 192", not consbad, f"problems={consbad}")
cc = sel["coverage_counts"]
chk("4i coverage_counts sums to 192", sum(cc.values()) == 192 and sel["total_operations"] == 192, f"counts={cc}")
# internal-consistency extras (not in the brief's list, recorded as findings)
na = sel.get("null_assignments") or []
na_bad = []
for e in na:
    a = assign.get(e["operation_id"])
    if a is None or a.get("null_reason") != e["reason"]: na_bad.append(e["operation_id"])
chk("4j EXTRA: top-level null_assignments list consistent with assignments' null_reason", not na_bad,
    f"null_assignments has {len(na)} entries {[e['operation_id'] for e in na]}; inconsistent_with_assignments={na_bad}")
rec = sel.get("reconciliation_note") or ""
chk("4k EXTRA: selection.json reconciliation_note agrees with 08.12 assignment (HIGH pair opus/gpt-5.5)",
    assign["08.12"]["primary"] in rec, f"08.12 primary={assign['08.12']['primary']}; note says: {rec[:160]}")
chk("4l EXTRA: coverage_counts role naming matches assignments (STATION_04 split)",
    cc.get("STATION_04", 0) == sum(1 for a in sel['assignments'] if a['assigned_role'] == 'STATION_04'),
    f"coverage STATION_04={cc.get('STATION_04')} + STATION_04_MEDIA={cc.get('STATION_04_MEDIA')}; assignments with role STATION_04={sum(1 for a in sel['assignments'] if a['assigned_role']=='STATION_04')} (incl. 10.10)")

# ---------- 5. HONESTY SWEEP ----------
sup = []
for i, line in enumerate(doc.splitlines(), 1):
    if re.search(r"\b(best|strongest|frontier|broadest|top creative|quality-first|superior|leading|state-of-the-art|world-class|unmatched)\b", line, re.I):
        sup.append((i, line.strip()[:130]))
print("  -- superlative/comparative lines in matrix doc:")
for i, l in sup: print(f"     L{i}: {l}")
chk("5a doc carries global UNVERIFIED_BENCHMARK labeling for comparative claims",
    "every comparative quality statement in this matrix is **UNVERIFIED_BENCHMARK**" in doc and doc.count("UNVERIFIED_BENCHMARK") >= 4,
    f"UNVERIFIED_BENCHMARK occurrences={doc.count('UNVERIFIED_BENCHMARK')}; superlative_lines={len(sup)}")
# catalog-fact claims cited in doc, verified against snapshot
gem = models["google/gemini-2.5-pro"]; maxin = max(len((m.get('architecture') or {}).get('input_modalities', [])) for m in models.values())
opus41 = models.get("anthropic/claude-opus-4.1")
chk("5b doc's catalog-fact claims check out (gemini broadest input set; opus-4.1 lacks structured_outputs)",
    len(gem["architecture"]["input_modalities"]) == maxin and opus41 is not None and "structured_outputs" not in (opus41.get("supported_parameters") or []),
    f"gemini inputs={gem['architecture']['input_modalities']} max_input_count={maxin}; opus-4.1 structured={'structured_outputs' in (opus41.get('supported_parameters') or [])}")
chk("5c status PROPOSED + matrix_version 1.0.0 (doc and selection.json)",
    sel["status"] == "PROPOSED" and sel["matrix_version"] == "1.0.0" and "matrix_version 1.0.0" in doc and "status: PROPOSED" in doc,
    f"sel status={sel['status']} version={sel['matrix_version']}")
chk("5d doc states catalog carries no per-model data-policy terms; privacy -> MM-12 item",
    "carries **no structured per-model data-policy or training-use terms**" in doc and "MM-12 confirmation" in doc
    and not any("data_policy" in (m or {}) or "training" in json.dumps(m).lower().split('description')[0] for m in []),
    "doc statements present; fetch_log entry-keys list also records absence")
keys = set()
for mm in models.values(): keys.update(mm.keys())
chk("5e snapshot entries carry no data-policy/training terms fields", not any("policy" in k or "training" in k or "retention" in k for k in keys),
    f"snapshot entry keys={sorted(keys)}")
slice_txt = SLICE_P.read_text() if SLICE_P.exists() else ""
chk("5f Lean slice 08.12 binding untouched (setup_slice.py still pins anthropic/claude-haiku-4.5)",
    'MODEL = "anthropic/claude-haiku-4.5"' in slice_txt, f"slice file exists={SLICE_P.exists()}")
video_out = [m["id"] for m in models.values() if "video" in ((m.get("architecture") or {}).get("output_modalities") or [])]
audio_out = [m["id"] for m in models.values() if "audio" in ((m.get("architecture") or {}).get("output_modalities") or [])]
chk("5g doc's 'zero video-output models' claim true in snapshot", len(video_out) == 0, f"video_out={video_out}; audio_out={audio_out}")

print()
fails = [r for r in results if not r[1]]
print(f"TOTAL checks={len(results)} PASS={len(results)-len(fails)} FAIL={len(fails)}")
for it, _, d in fails: print(f"  FAILED: {it} :: {d}")
sys.exit(0)
