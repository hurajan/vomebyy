# Gate 04 — Changed Assertions

Every pre-existing test assertion changed by Gate 04, with the reason.
New tests in new files (g2 tests/test_gate04.py, g9
tests/test_g9_materialized.py, worker TestGate04Plans class) are
additive, not changes.

## 1. gate-c/worker_service/tests/test_worker_service.py — `test_g4_text_shape_and_fallback`
- WAS: `payloads.build("02.05", ...)` returns artifact_type
  `"step_output"` with a generic JSON body (the G01-D01 generic
  fallthrough, asserted as correct behavior).
- NOW: `payloads.build("02.05", ...)` raises
  `payloads.UnboundOperationError`. The generic branch no longer
  exists as a success path; non-specific operations execute through
  their execution plans (plan_exec) or refuse explicitly.
- The 01.01 specific-builder assertions are unchanged.

## 2. video-factory-g3/tests/test_api_contract.py — template normalization
- `contract_keys()` and the final coverage `want` set now also replace
  `{rid}` with `{id}`. Reason: the new materialize endpoint
  (`POST /productions/{pid}/runs/{rid}/materialize`) is the first
  contract path with a second distinct id placeholder; the existing
  normalization could not match it. No assertion was weakened — the
  endpoint is exercised and its response keys asserted like every
  other endpoint.
- `test_all_endpoints` additionally exercises the two Gate 04
  endpoints (actions record + replay/refusals; materialize graph) and
  asserts the claim response carries plan_id/plan_version/plan_hash.
  Additive coverage for contract 1.6.0.

## Contract change (not a test assertion)
- contracts/api_contract.json: 1.5.0 → 1.6.0. Added
  `POST /units/{uid}/actions` and
  `POST /productions/{pid}/runs/{rid}/materialize`; the claim endpoint's
  response list gains plan_id/plan_version/plan_hash (the coordinator
  claim now returns them).

## Design judgment recorded (no assertion changed)
- `engine.emit_output` checks exit payloads against the Gate G
  deliverable schemas and REPORTS violations in the emit action's
  record; it does not fail execution on them. Rationale: pre-Gate-04
  execution tolerated schema-imperfect builder output (e.g. a null
  upstream ref in `canon_refs` when an exit op runs without that
  input), and deliverable-schema verdicts belong to the evaluation
  service (Gate E). Making emit fail closed would have changed the 19
  specific operations' execution behavior beyond the lock's
  decomposition scope. Flagged for the verifier/owner.

