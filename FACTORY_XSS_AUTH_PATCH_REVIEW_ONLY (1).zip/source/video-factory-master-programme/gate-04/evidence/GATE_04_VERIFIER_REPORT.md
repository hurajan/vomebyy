# GATE 04 — Independent Verifier Report

**Verdict: VERIFIED — the builder's results stand. Defects: NONE.** Two observations (reporting precision; a builder-flagged judgment carried to Gate 06) are recorded in §8. Verification ran on the verifier's own scratch DB (`gate04_verify_scratch`) and own service stack, serially, read-only on product trees.

## 1. Plans integrity — CONFIRMED

- Chain-built scratch DB (g1 loader + g2 `setup_db.py`): `operation_execution_plans` holds exactly **192 rows** for workflow 1.0.0; **69 FULLY_BOUND**, **123 plans with UNBOUND actions**, **sum of unbound actions = 123** (one per partially-bound plan); 192 distinct plan hashes; 16 `execution_plan_versions` rollups.
- Verifier's own run of the loader's `plans-validate`: PASS, problems [], plans_hash `9955af63…` — counts and the UNBOUND category distribution reproduce exactly: creative.generate 43, human.decision 28, semantic.evaluate 27, external.platform 9, media.process 9, media.generate 4, external.provider 2, media.render 1 (= 123).
- Hash agreement: all 192 per-plan `plan_hash` values in the DB are identical to `plans.json`; every file plan_hash also self-recomputes from its body.
- Regenerability: `generate_plans.py` run in a copied tree produced a **byte-identical** `plans.json` (empty diff, same plans_hash).
- Registry untouched: verifier's `registry validate` → PASS, **definition_hash ea4503f5…** intact.

## 2. Generic fallthrough is dead — CONFIRMED (source + live behavior)

- Source: `payloads.build()` ends in `raise UnboundOperationError` for every non-specific operation; both payload-backed adapters (deterministic-local, mock) route exclusively through `plan_exec.execute_operation`, which raises `UnboundOperation` on UNBOUND actions / missing plans and records REFUSED first. The only surviving `step_output` mention in non-test code is the docstring recording its removal. A direct call `payloads.build('02.05', …)` raises `UnboundOperationError`.
- Live probe (verifier-chosen op **14.10**, external.platform UNBOUND; builder used 08.05): claim → `/work` → **502 UNBOUND_OPERATION**; zero artifacts in the production; unit left CLAIMED, never ACCEPTED; `plan_action_attempts` = [(inputs.manifest, SUCCEEDED), (external_platform, REFUSED)] — the refusal is persisted evidence, not a silent failure.

## 3. Bound generic execution — CONFIRMED (verifier-chosen op 16.02; builder used 06.01)

- Two end-to-end executions with different input content: both reached **ACCEPTED** via completion → evaluation service → AWAITING_HUMAN → `human_approved`. Output demonstrably input-derived: `records.project` output is the exact field projection (hypothesis/measure kept, noise field dropped) of each run's own input records; the two runs' registered artifact SHA-256s differ.
- Action records: exactly 5 per run, seq 1–5 in order, all SUCCEEDED, every record's `plan_hash` equal to the attempt's pinned hash (plan `plan/1.0.0/16.02`); `/work` reported `records_posted = 5`, `binding_status = FULLY_BOUND`.

## 4. Plan-pin enforcement — CONFIRMED

- Tamper probe (16.02 attempt's `plan_hash` overwritten in the verifier's scratch DB): `/work` → **502 PLAN_PIN_MISMATCH**, zero action records, zero artifacts produced. The worker compares the attempt's DB-pinned plan_id + plan_hash against its resolved plan before executing (service `_verify_plan_pin`).
- Missing-plan probe (plan row for 04.01 deleted on the scratch DB, coordinator level): claim raises **PlanMissingError**, exactly one committed `plan_missing` audit event, **zero attempts**, unit remains READY. Loader re-load restored the row (192 plans again).

## 5. Materialization — CONFIRMED

- Verifier's own coordinator-level `materialize_run` on the scratch DB: **192 units / 191 `unit_dependencies` edges**, exactly one READY unit (the chain head) — the graph is derived from `dependency_templates`, not hand-planned.
- Builder's G9 log shows `test_materialized_graph_equals_hand_planned` passing; the verifier additionally re-ran the G2 Gate 04 test module himself (5/5 OK, including `test_materialize_full_run_192` and the hand-planned-equivalence test).

## 6. Regressions + scope — CONFIRMED (with the precision notes in §8)

- Suite logs read and tallied: G1 9, G2 74, G3 26, G4 2, G5 1, G6 3, G7 2, G8 1, G9 10, worker 25, storage 5, evaluation 25, runtime 10 = **193**, all OK.
- Verifier's own serial re-runs: G1 **9/9 OK**, worker service **25/25 OK**, G2 Gate 04 module **5/5 OK**. (Disclosure: the verifier's first, parallel spot-runs collided on the environment's shared /tmp staging filenames and failed spuriously — the known contention hazard in the controller register; serial re-runs were clean. No product implication.)
- G9 DB facts checked against `g9_fullrun_scratch`: the "G9 full run" production has **18 ACCEPTED units** and CHARGE transactions summing to **exactly 1620¢** (18 × 90; RESERVE 18 × 100 = 1800). Action records on the full-run production itself: **54** (18 units × 3 actions — the specific plans are [manifest, build_payload, emit]), all SUCCEEDED. The builder's "63 action records" reconciles exactly as the G9-suite-wide count at the time it was taken (54 full-run + 9 across the three failure-battery productions that executed plan actions); the DB now totals 87 because the builder's own probe productions (06.01 ×20, 08.05 ×4) were also run against that DB. Substance confirmed; see §8(a) for the framing note.
- Migration **015 is additive-only** by inspection: two `CREATE TABLE IF NOT EXISTS`, three `ADD COLUMN IF NOT EXISTS`, two indexes; no DROP/ALTER of existing columns, no data writes.
- **TRANSITIONS still exactly 30** (counted by importing the coordinator).
- Changed-assertion scope: against the Gate 00 source manifest, the only differing pre-existing test files **in the worker and g3 trees** are precisely the two files declared in `gate-04/evidence/CHANGED_ASSERTIONS.md` (`test_worker_service.py`, `test_api_contract.py`). Two further diffs outside that scope are attributable and are not Gate 04 changes: `g2/tests/test_fix_dh1.py` (Gate 02 seam file, flagged in-flux in the manifest itself) and `g9/tests/test_g9_fullrun.py` (mtime 2026-10-29 04:21 UTC — before Gate 04's evidence window opened; consistent with Gate 03's station-chain correction).

## 7. Honesty audit of flagged bindings — calibrated genuine-L2 count: 69 (agrees with builder)

Structural pre-check: **zero** of the 69 FULLY_BOUND plans lack a substantive action — every one contains at least one of extract / project / index / cross-check / attest / verify / sort / assign-ids / group / analyze / aggregate / build_payload. There is no manifest+compose+emit-only plan in the bound set.

| Op | Binding | Assessment |
|---|---|---|
| **13.04** Run file-integrity (master_qc) | extract_records → verify_fields(file_ref, codec, duration_s) → compose | **AGREE as bound.** verify_fields genuinely checks the extracted input records field-by-field and emits checked-count, per-record violations, and a COMPLETE/INCOMPLETE verdict — the operation's typed output, computed from its inputs, capable of reporting adversely. Caveat (not a downgrade): it verifies metadata records, not media bytes — no actual codec/duration probing of files exists anywhere in the deterministic layer. |
| **15.03** Bind authorization to asset hash (distribution) | hash_attest → compose | **BOUND-BUT-THIN.** hash_attest computes a real cryptographic binding (sha256 over the sorted input artifact hashes) — the mechanical core of the operation. But no authorization operand is ever located or validated: whatever inputs exist are attested, and nothing reads rights/authorization fields. The hash-binding is genuine; the "authorization" half of the contract is implicit. |
| **15.05** Create stable release ID and idempotency/reconciliation key (distribution) | hash_attest → compose | **BOUND-BUT-THIN.** The attestation hash is in substance exactly a stable, reproducible, input-derived identifier — the semantics an idempotency/reconciliation key needs. But nothing names it a release ID or registers it as a key; it sits as `attestation_sha256` inside a composed document. Closest of the thin three to a full agree. |
| **09.01** Read the complete approved arc (direction) | analyze_content → compose | **BOUND-BUT-THIN.** analyze_content genuinely processes input content (per-artifact kind, keys, record counts, line/word counts, content hashes) and fails explicitly with no inputs — real analysis, more than record assembly. But a structural inventory is a shallow proxy for "read the complete approved arc": no arc substance (nodes, beats, continuity) is comprehended. |

None of the four is SHOULD-BE-UNBOUND: each chain's substantive action computes its typed output from the actual inputs and can fail or report adversely — the D01 failure mode (semantically empty success) is absent. **Calibrated genuine-L2 = 69**, unchanged from the builder's count, with 15.03 / 15.05 / 09.01 recorded as thin bindings for Gate 10 to weigh: Gate 10's per-operation contract tests are where shallow-but-honest outputs get measured against deliverable expectations.

## 8. Observations (not defects)

(a) **Count framing.** The Gate 04 headline "63 action records" for G9 is a suite-wide figure; the full-run production alone carries 54. Both numbers reconcile exactly against the DB (§6). Future reports should name the scope of such counts.
(b) **`engine.emit_output` reports deliverable-schema violations instead of failing on them** (builder's own flagged judgment in CHANGED_ASSERTIONS): within this gate's decomposition scope — the 19 specific operations' behavior is provably unchanged and deliverable verdicts belong to the evaluation service — but it means a bound generic exit op could complete with a schema-imperfect deliverable and rely on evaluation to catch it. Carried to Gate 06 (validation contracts) for a ruling, as the builder flagged.

## Method note

All live claims were established on the verifier's own scratch DB and stack (API 8730 / worker 8795 / evaluation 8796 against `gate04_verify_scratch`, STATION bindings seeded as in the G9 setup), with verifier-chosen operations (14.10, 16.02, 04.01) distinct from the builder's probe operations (06.01, 08.05). Probe script and materialization script were verifier-authored; services were stopped after the run.
