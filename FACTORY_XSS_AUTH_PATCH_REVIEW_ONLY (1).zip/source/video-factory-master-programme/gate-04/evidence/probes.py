#!/usr/bin/env python3
"""Gate 04 acceptance probes (LOCK_GATE_04 §5), run against the G9
full-run environment (API :8730 + worker service :8795 on
g9_fullrun_scratch) after tools/setup_fullrun.py.

Probe A: a formerly-generic operation with a FULLY BOUND plan (06.01)
executes end-to-end (claim -> /work -> complete -> validate) and its
output is derived from its inputs (two different inputs -> different
outputs); its five plan actions are recorded SUCCEEDED.
Probe B: an operation whose plan contains an UNBOUND action (08.05)
fails explicitly at the worker (UNBOUND_OPERATION), produces NO
artifact, never reaches ACCEPTED, and leaves a REFUSED action record.
Probe C: a corrupted attempt plan pin (plan_hash tampered in the DB)
makes the worker refuse with PLAN_PIN_MISMATCH before executing.
"""
import json
import sys
import urllib.error
import urllib.request

import psycopg
from psycopg.rows import dict_row

API = "http://127.0.0.1:8730"
WORKER = "http://127.0.0.1:8795"
DSN = ("host=127.0.0.1 dbname=g9_fullrun_scratch user=factory "
       "password=factory_dev_local")
OP_TOKEN = "dev-operator-token"
results = []


def call(base, method, path, body=None, token=None, expect=None):
    req = urllib.request.Request(base + path, method=method)
    data = None
    if token:
        req.add_header("X-Operator-Token", token)
    if body is not None:
        data = json.dumps(body).encode()
        req.add_header("Content-Type", "application/json")
    try:
        with urllib.request.urlopen(req, data=data, timeout=30) as r:
            out = json.loads(r.read() or b"{}")
            status = r.status
    except urllib.error.HTTPError as e:
        status, out = e.code, json.loads(e.read() or b"{}")
    if expect is not None and status != expect:
        raise AssertionError(f"{method} {path} -> {status} (want {expect}): {out}")
    return status, out


def db(sql, args=()):
    import psycopg.errors
    with psycopg.connect(DSN, row_factory=dict_row, autocommit=True) as conn:
        cur = conn.execute(sql, args)
        try:
            return cur.fetchall()
        except psycopg.errors.ProgrammingError:
            return []


def make_unit(op, input_content=None):
    _, p = call(API, "POST", "/productions",
                {"title": f"Gate04 probe {op}", "hard_ceiling_cents": 100000,
                 "soft_ceiling_cents": 90000}, token=OP_TOKEN, expect=201)
    pid = p["production_id"]
    _, r = call(API, "POST", f"/productions/{pid}/runs", {"kind": "FULL"},
                token=OP_TOKEN, expect=201)
    inputs = []
    if input_content is not None:
        _, a = call(API, "POST", f"/productions/{pid}/artifacts",
                    {"artifact_type": "beat_draft",
                     "content": json.dumps(input_content),
                     "storage_uri": f"probe://{op}/input"},
                    token=OP_TOKEN, expect=201)
        inputs = [a["artifact_id"]]
        art_id = a["artifact_id"]
    else:
        art_id = None
    _, u = call(API, "POST", f"/productions/{pid}/units",
                {"operation_id": op, "run_id": r["run_id"],
                 "input_artifact_ids": inputs}, token=OP_TOKEN, expect=201)
    return pid, u["unit_id"], art_id


def claim_and_work(pid, uid, op, refs):
    _, claim = call(API, "POST", f"/units/{uid}/claim",
                    {"worker_id": "probe-worker"}, token=OP_TOKEN, expect=200)
    _, attempts = call(API, "GET", f"/units/{uid}/attempts", token=OP_TOKEN)
    binding = attempts["attempts"][0]["resolved_config"]
    body = {"provider_binding": binding,
            "operation_id": op, "production_id": pid,
            "unit_id": uid, "attempt_id": claim["attempt_id"],
            "fencing_token": claim["fencing_token"],
            "input_artifact_refs": refs}
    return claim, call(WORKER, "POST", "/work", body)


def probe_a():
    changes = {"changes": [{"summary": "alpha"}, {"summary": "beta", "id": "B9"}]}
    pid, uid, art_id = make_unit("06.01", changes)
    refs = [{"artifact_type": "beat_draft", "artifact_id": art_id,
             "sha256": "probe", "content": changes}]
    claim, (status, out) = claim_and_work(pid, uid, "06.01", refs)
    assert status == 200, f"/work -> {status}: {out}"
    payload = out
    doc = json.loads(payload["content"])
    records = doc["derived"]["records.assign_ids"]["records"]
    assert [r["id"] for r in records] == ["B-001", "B9"], records
    assert payload["plan_execution"]["binding_status"] == "FULLY_BOUND"
    assert payload["plan_execution"]["records_posted"] == 5
    _, done = call(API, "POST", f"/units/{uid}/complete",
                   {"worker_id": "probe-worker",
                    "fencing_token": claim["fencing_token"],
                    "artifact_type": payload["artifact_type"],
                    "content": payload["content"],
                    "actual_cost_cents": payload["actual_cost_cents"]},
                   token=OP_TOKEN, expect=200)
    call(API, "POST", f"/units/{uid}/validate", {"verdict": "PASS"},
         token=OP_TOKEN, expect=200)
    _, units = call(API, "GET", f"/productions/{pid}/units", token=OP_TOKEN)
    state = [u for u in units["units"] if u["unit_id"] == uid][0]["state"]
    assert state == "ACCEPTED", state
    rows = db("SELECT action_key, status FROM plan_action_attempts "
              "WHERE unit_id=%s ORDER BY seq", (uid,))
    assert len(rows) == 5 and all(r["status"] == "SUCCEEDED" for r in rows), rows
    # input sensitivity: different input -> different output artifact
    changes2 = {"changes": [{"summary": "gamma"}]}
    pid2, uid2, art2 = make_unit("06.01", changes2)
    refs2 = [{"artifact_type": "beat_draft", "artifact_id": art2,
              "sha256": "probe2", "content": changes2}]
    _, (status2, out2) = claim_and_work(pid2, uid2, "06.01", refs2)
    assert status2 == 200
    assert json.loads(out2["content"]) != doc
    results.append(("A bound-generic 06.01 executes, input-derived, "
                    "5 action records, ACCEPTED", True))


def probe_b():
    pid, uid, _ = make_unit("08.05")
    claim, (status, out) = claim_and_work(pid, uid, "08.05", [])
    assert status == 502, f"/work -> {status}: {out}"
    assert out["error_class"] == "UNBOUND_OPERATION", out
    _, arts = call(API, "GET", f"/productions/{pid}/artifacts", token=OP_TOKEN)
    assert arts["artifacts"] == [], arts
    _, units = call(API, "GET", f"/productions/{pid}/units", token=OP_TOKEN)
    state = [u for u in units["units"] if u["unit_id"] == uid][0]["state"]
    assert state != "ACCEPTED", state
    rows = db("SELECT action_key, status FROM plan_action_attempts "
              "WHERE unit_id=%s ORDER BY seq", (uid,))
    assert [(r["action_key"], r["status"]) for r in rows] == [
        ("inputs.manifest", "SUCCEEDED"), ("creative_generate", "REFUSED")], rows
    results.append(("B unbound 08.05 refused explicitly, zero artifacts, "
                    "REFUSED record persisted", True))


def probe_c():
    pid, uid, art_id = make_unit("06.01", {"changes": [{"summary": "x"}]})
    _, claim = call(API, "POST", f"/units/{uid}/claim",
                    {"worker_id": "probe-worker"}, token=OP_TOKEN, expect=200)
    db("UPDATE action_attempts SET plan_hash='tampered' WHERE attempt_id=%s",
       (claim["attempt_id"],))
    _, attempts = call(API, "GET", f"/units/{uid}/attempts", token=OP_TOKEN)
    binding = attempts["attempts"][0]["resolved_config"]
    body = {"provider_binding": binding,
            "operation_id": "06.01", "production_id": pid,
            "unit_id": uid, "attempt_id": claim["attempt_id"],
            "fencing_token": claim["fencing_token"],
            "input_artifact_refs": []}
    status, out = call(WORKER, "POST", "/work", body)
    assert status == 502 and out["error_class"] == "PLAN_PIN_MISMATCH", (status, out)
    results.append(("C tampered plan pin refused (PLAN_PIN_MISMATCH)", True))


if __name__ == "__main__":
    for fn in (probe_a, probe_b, probe_c):
        fn()
    for name, ok in results:
        print(f"PROBE {'PASS' if ok else 'FAIL'}: {name}")
    print(f"probes: {len(results)}/3 PASS")
    sys.exit(0)
