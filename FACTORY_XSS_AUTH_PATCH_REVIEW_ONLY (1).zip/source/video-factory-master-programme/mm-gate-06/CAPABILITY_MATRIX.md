# MM-06 STEP 0 — CAPABILITY MATRIX (specialized non-LLM providers)

*Grounded in the environment probe of 2026-10-29
(`evidence/results/environment_probe.json`) and the MM-01
classification + Gate 04 plans. A capability is claimed only at the
level the probe and the code support.*

**Environment facts (probed, not assumed):** ffmpeg + ffprobe 8.1.2
with libx264/aac encoders; filters loudnorm, signalstats, adelay,
apad, atrim, scale, pad, crop, concat, aresample all present;
**libflite compiled in — the `flite` source live-synthesized a
1.235 s WAV**; NO espeak-ng/piper/festival; NO local ASR engine;
node v24 present, **no Remotion package installed**; no provider
credentials exist (MM-12 owns them).

| Capability | Required by | Disposition | Basis / external requirement |
|---|---|---|---|
| **FFmpeg media processing + rendering** | 12.05–12.08, 13.05, 13.08, 14.06–14.08 (`media.process`), 13.03 (`media.render`) | **EXECUTABLE_LOCAL** | New `media_tools.py` + `media.ffmpeg_process` / `media.ffmpeg_render` actions; the 10 plans bind this gate → FULLY_BOUND (L2 69 → 79) |
| **Audio processing** | 12.06 sync, 12.07 ambience, 12.08 mix, 14.08 narration | **EXECUTABLE_LOCAL** | ffmpeg adelay/apad/loudnorm transforms inside `media.ffmpeg_process`, measured before/after |
| **Media validation** | 13.04 (byte-level probing was named future tooling in its MM-01 note), 13.05, MM-07 policies | **EXECUTABLE_LOCAL** | `media_tools.validate_media` — ffprobe checks with NAMED failure reasons; media actions self-validate outputs |
| **Text-to-speech** | narration for step 10/11 voice plans; 14.08 context | **EXECUTABLE_LOCAL** (LOCAL_TOOL) | `FliteLocalAdapter` (`ffmpeg-flite-local`) + `media.synthesize_speech` action — real WAVs via libflite. **Honest limit:** flite voices are robotic formant synthesis — a functional local path, not production voice quality; production TTS stays an owner provider decision (http-speech adapter below) |
| **Speech recognition / alignment** | transcripts feeding 13.11; sync verification for 12.06 | **ADAPTER_READY_CREDENTIAL_GATED** | `http-transcription` adapter exists (generic HTTP, credential-required); no local ASR exists. Owner picks a transcription provider + credential at MM-12 (binding `credential_ref`); no specific API availability claimed |
| **Image generation** | 10.10, 11.04, 11.06, 11.11 (`media.generate`) | **ADAPTER_READY_CREDENTIAL_GATED** (+ MOCK_PATH_LABELED in tests) | `http-image` adapter exists; MM-02's catalog has image-output models for the MM-03 registry. Needs MM-12 credential + owner-approved image policy; binding the `media.generate` plans is a future gate's plan change — they stay UNBOUND here |
| **Video generation** | 11.06, 11.11 | **EXTERNAL_DEPENDENCY** | **Owner decision required:** MM-02 proved the OpenRouter catalog has **zero video-output models** — no OpenRouter binding can serve this. The owner must select a video provider outside that catalog + credential at MM-12; this gate picks none. The `http-video` adapter is only an unproven integration shape |
| **Stock acquisition** | 11.06 (one acquisition route); 11.05 is a human decision | **ADAPTER_READY_CREDENTIAL_GATED** (+ MOCK_PATH_LABELED in tests) | `http-stock` adapter exists. Owner's commercial provider choice + API credential at MM-12; no provider named or assumed |
| **Platform publishing** | 15.07 upload; 15.02/15.06/15.08–15.11, 14.10, 16.03 (`external.platform`) | **MOCK_PATH_LABELED** locally + **EXTERNAL_DEPENDENCY** for real publication | Local path = 15.12's deterministic receipts — simulations, now marked `simulated: true` + provider `mock-platform-publisher` + per-receipt `status: "SIMULATED"` (this gate). Real publishing needs the owner's platform accounts + OAuth/API credentials at MM-12; the platform selection is the owner's |
| **Remotion** | — (no approved operation names template composition) | **NOT_ADOPTED** | Not installed; no plan/classification requirement exists; 13.03's rendering is served by FFmpeg, the renderer of record. Adopting it now would be speculative. Revisit only on an owner-approved requirement |
| **(noted, out of MM-06 scope)** `external.provider` actions — 03.03, 11.03 | | remain UNBOUND | 03.03 is LLM text work for the MM-04 gateway path at MM-13; 11.03 validates real provider behavior, external by definition |

## External dependency register — owner actions at MM-12

| Capability | Adapter of record | Credential mechanism | Owner action at MM-12 |
|---|---|---|---|
| Speech recognition | `http-transcription` | provider binding `credential_ref` → env var named by the binding | Select transcription provider; supply its API credential via secure entry |
| Image generation | `http-image` / MM-03 registry image models | OpenRouter credential (MM-12's main ask) | Approve image model policy (MM-03 promotion) + OpenRouter credential |
| Video generation | `http-video` (shape only) | provider-specific credential | **Decide the video provider** (OpenRouter cannot serve it — MM-02 evidence) + supply credential |
| Stock acquisition | `http-stock` | provider binding `credential_ref` | Choose stock provider; supply API credential |
| Platform publishing | none approved (15.07 plan UNBOUND) | platform OAuth / API credentials | Authorize platform account(s) + grant upload credentials for the chosen platform(s) |
| Production TTS (optional upgrade) | `http-speech` | provider binding `credential_ref` | Only if flite quality is judged insufficient: select TTS provider + credential |
