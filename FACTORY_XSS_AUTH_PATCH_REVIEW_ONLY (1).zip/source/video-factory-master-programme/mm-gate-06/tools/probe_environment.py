#!/usr/bin/env python3
"""MM-06 Step 0 — environment probe: record what media tooling ACTUALLY
exists in this environment before any capability disposition is made.
Facts only; no capability is claimed from documentation."""
import json
import shutil
import subprocess
from pathlib import Path

OUT = Path(__file__).resolve().parent.parent / "evidence" / "results"


def run(args, timeout=60):
    try:
        p = subprocess.run(args, capture_output=True, text=True,
                           timeout=timeout, stdin=subprocess.DEVNULL)
        return p.returncode, p.stdout, p.stderr
    except Exception as exc:  # noqa: BLE001
        return None, "", str(exc)


def main():
    facts = {}
    for tool in ("ffmpeg", "ffprobe", "node", "npx", "espeak-ng", "espeak",
                 "piper", "festival"):
        facts[f"which_{tool}"] = shutil.which(tool)
    rc, out, _ = run(["ffmpeg", "-version"])
    facts["ffmpeg_version"] = out.splitlines()[0] if out else None
    rc, out, _ = run(["ffprobe", "-version"])
    facts["ffprobe_version"] = out.splitlines()[0] if out else None
    rc, out, err = run(["ffmpeg", "-hide_banner", "-encoders"])
    enc = out + err
    facts["encoders"] = {name: (name in enc) for name in
                         ("libx264", "aac", "pcm_s16le", "libmp3lame")}
    rc, out, err = run(["ffmpeg", "-hide_banner", "-filters"])
    filts = out + err
    facts["filters"] = {name: (name in filts) for name in
                        ("flite", "loudnorm", "signalstats", "adelay",
                         "apad", "atrim", "scale", "pad", "crop",
                         "concat", "aresample", "astats")}
    rc, out, err = run(["ffmpeg", "-hide_banner", "-h", "filter=flite"])
    facts["flite_filter_help_present"] = "Synthesize voice" in (out + err)
    # live flite synthesis probe: text -> WAV, probed duration
    tmp = Path("/tmp/mm06_probe_flite.wav")
    rc, out, err = run(["ffmpeg", "-nostdin", "-v", "error", "-f", "lavfi",
                        "-i", "flite=text='Hello world':voice=slt",
                        "-t", "3", str(tmp), "-y"])
    dur = None
    if tmp.exists():
        rc2, out2, _ = run(["ffprobe", "-v", "error", "-show_entries",
                            "format=duration", "-of", "csv=p=0", str(tmp)])
        try:
            dur = float(out2.strip())
        except ValueError:
            dur = None
    facts["flite_live_synthesis"] = {"ffmpeg_rc": rc, "wav_bytes": tmp.stat().st_size if tmp.exists() else 0,
                                     "duration_s": dur}
    rc, out, _ = run(["node", "--version"])
    facts["node_version"] = out.strip() or None
    remotion = []
    for base in (Path.home() / "workspace/video-factory-g4/node_modules",
                 Path.home() / "workspace/video-factory-g9/node_modules",
                 Path("/usr/lib/node_modules"),
                 Path("/opt/hatch-image/lib/node_modules")):
        candidate = base / "@remotion"
        if candidate.exists():
            remotion.append(str(candidate))
        if (base / "remotion").exists():
            remotion.append(str(base / "remotion"))
    facts["remotion_packages_found"] = remotion
    facts["credential_env_present"] = {
        name: bool(shutil.os.environ.get(name)) for name in
        ("OPENROUTER_API_KEY",)}
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / "environment_probe.json").write_text(
        json.dumps(facts, indent=1, sort_keys=True))
    print(json.dumps(facts, indent=1, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
