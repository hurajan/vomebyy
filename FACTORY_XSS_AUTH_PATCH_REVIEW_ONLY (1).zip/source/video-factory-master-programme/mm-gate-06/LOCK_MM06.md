# LOCK — GATE MM-06: Specialized Non-LLM Providers

**Gate:** MM-06 (Multi-Model programme, MULTI_MODEL_EXECUTION_PROMPT.md)
**Builder:** MM-06 builder agent (this session)
**Date:** 2026-10-29
**Status at lock:** LOCKED → IMPLEMENTING

## Scope

Step 0: a capability inventory (CAPABILITY_MATRIX.md +
evidence/capability_matrix.json) giving every capability in the
prompt's list a disposition — EXECUTABLE_LOCAL /
ADAPTER_READY_CREDENTIAL_GATED / MOCK_PATH_LABELED /
EXTERNAL_DEPENDENCY (or NOT_ADOPTED with reason) — grounded in
environment probes, never in assumed availability.

Build (only what the probes support):
1. **FFmpeg local tool adapter** in the worker service: deterministic
   media actions (probe, transcode/normalize to the master spec,
   segment cut/concat, dialogue sync offset, ambience pad, loudness
   mix, color measurement, error-fix re-encode, reframe, narration
   extract) behind the existing plan/action machinery. The 9 plans
   blocked on `media.process` (12.05–12.08, 13.05, 13.08, 14.06–14.08)
   and 13.03 (`media.render`) bind to these implementations via the
   plan generator → those 10 plans become FULLY_BOUND (genuine L2:
   69 → 79); all other 182 plans byte-identical (proven by
   regeneration diff).
2. **Media validation tool**: ffprobe-based validator with named
   failure reasons, used by the media actions to self-validate their
   outputs and covered by direct tests (valid / truncated / wrong
   codec / missing audio).
3. **TTS**: ffmpeg 8.1.2 in this environment is built with libflite
   and the `flite` source filter synthesizes real speech WAVs
   (probed: 1.235 s for a 2-word phrase) → implement the local TTS
   path (adapter + action) labeled LOCAL_TOOL. No fake voice path.
4. **Simulation labeling standard**: simulated outputs carry
   machine-visible marking — artifact field `simulated: true`,
   provider name containing the mock designation, and (publishing)
   per-receipt `status: "SIMULATED"` — applied to the 15.12
   distribution-record builder (the factory's mock publication
   receipt path; step-15 deliverable schema allows additional
   properties). A test proves a mock distribution record is
   distinguishable from a real-shaped one by stored fields alone and
   that the marking survives the plan/envelope/store round trip.
5. **External dependency register** (in the matrix): per
   credential-gated capability, the adapter, the credential binding
   mechanism, and the exact owner action at MM-12. Video generation:
   MM-02 proved zero video-output models on OpenRouter → a real
   video path is an OWNER DECISION (separate provider + credential),
   not something this gate picks. Remotion: NOT_ADOPTED with reason
   (no approved operation requires template composition; FFmpeg is
   the renderer of record).

## Environment probe facts (2026-10-29, this VM)

- ffmpeg + ffprobe **8.1.2** at /usr/bin; encoders libx264 ✓, aac ✓;
  **libflite compiled in** ✓ (`flite` lavfi source works); filters
  loudnorm, signalstats, adelay, apad, atrim, scale, pad, crop ✓.
- No espeak-ng / piper / festival binaries. No local ASR engine.
- node v24.22.1 present; **no Remotion package** installed anywhere.
- No provider credentials exist (standing fact; MM-12 owns them).

## Preserved behavior (hard constraints)

- Registry definitions + definition_hash ea4503f5… untouched; plan
  version stays 1.0.0 (coordinator CURRENT_PLAN_VERSION pin); plan
  bodies for the 10 media ops change → their plan_hashes change and
  are pinned per attempt, exactly as the 08.12 body change was.
- Media actions produce output FROM inputs or fail explicitly
  (Gate 04 discipline): no media input bytes in the artifact store
  → ActionFailed, never a fabricated media result.
- Credential-gated adapters keep refusing without credentials
  (Gate C discipline); nothing in this gate makes a real provider
  call or requests a credential (MM-12 owns that).
- Deterministic regression baseline 239 (MM-05 composition) must
  stay green apart from this gate's recorded additions and the one
  pinned-count assertion the binding change legitimately moves
  (worker plans test: 69 → 79 FULLY_BOUND), recorded in
  evidence/CHANGED_ASSERTIONS.md.

## Owned files (claimed in gate-00/OWNERSHIP.md before edits)

- `gate-c/worker_service/media_tools.py` — NEW (ffprobe probe +
  validator + ffmpeg runner + flite synthesis + master spec)
- `gate-c/worker_service/actions.py` — media action implementations
  (`media.ffmpeg_process`, `media.ffmpeg_render`,
  `media.synthesize_speech`) + registry/spec entries ONLY
- `gate-c/worker_service/adapters.py` — `FliteLocalAdapter` +
  registry entry ONLY
- `gate-c/worker_service/payloads.py` — 15.12 simulation marking ONLY
- `gate-c/worker_service/action_implementations.json` — regenerated
  manifest (new implementation entries only)
- `gate-c/worker_service/tests/test_mm06_media.py` — NEW
- `video-factory-g1/tools/generate_plans.py` — media core kinds +
  the 10 media CLASS entries ONLY
- `video-factory-g1/seed-definitions/workflow-1.0.0/plans.json` —
  regenerated (only the 10 media plans + plans_hash may change)
- Incidental, only if a pinned shape/count changes and recorded in
  mm-gate-06/evidence/CHANGED_ASSERTIONS.md: the affected suites'
  test files (known: worker test_worker_service.py FULLY_BOUND 69→79)
- `video-factory-master-programme/mm-gate-06/**` — lock, capability
  matrix, harness, evidence

## Battery (mm-gate-06/evidence/results/, serial)

- MM06-1 capability matrix + environment probe record.
- MM06-2 media validator tests (valid/truncated/wrong-codec/
  missing-audio, named reasons).
- MM06-3 real local execution of all 10 newly bound operations
  through the worker plan path over lavfi-synthesized media, with
  ffprobe validation of every output (label LOCAL_TOOL_EXECUTION).
- MM06-4 TTS: flite adapter + action produce real WAVs (duration
  > 0, probe-validated) (label LOCAL_TOOL).
- MM06-5 simulation labeling tests (15.12 record distinguishable by
  stored fields; marking survives envelope + store round trip; no
  stripping path).
- MM06-6 plans regeneration diff (exactly 10 plans change; other
  182 byte-identical) + plans-validate.
- MM06-7 full serial regression (baseline 239 + additions).

## Out of scope / guardrails

No registry-definition, migration, coordinator, API, workflow,
evaluation, or dashboard changes. media.generate (4 AI_MEDIA ops)
and external.* plans stay UNBOUND — they are credential/owner-gated
and are registered as such, not bound to mocks. No real provider
call; no credential requested. Serial execution only. No
STATE.md/MEMORY.md edits; no gate report (the verifier writes it).
