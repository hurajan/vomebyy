# D-1 FIX RECORD — media-action workdir cleanup (GATE MM-06 follow-up)

**Defect (MM06_VERIFIER_REPORT.md §7, MINOR):** the worker service's
media actions created `tempfile.mkdtemp` workdirs holding full media
copies per execution and never deleted them. During the MM-06 battery
~490 MB accumulated in `/tmp` (a 512 MB tmpfs), filling it and
breaking unrelated suite runs with ENOSPC.
**Fixer:** D-1 fixer agent, 2026-10-29. **Status: FIXED + tests green.**

## 1. Temp-dir creation sites found in the media path — and their disposition

Product code (worker service, `gate-c/worker_service/`) — all four
mkdtemp sites are FIXED:

| # | Site | Prefix | Disposition |
|---|---|---|---|
| 1 | `actions.py` `ffmpeg_process` (media.ffmpeg_process) | `mm06-media-` | wrapped in `media_tools.workdir(...)` |
| 2 | `actions.py` `ffmpeg_render` (media.ffmpeg_render, op 13.03) | `mm06-render-` | wrapped |
| 3 | `actions.py` `synthesize_speech` (media.synthesize_speech) | `mm06-tts-` | wrapped |
| 4 | `adapters.py` `FliteLocalAdapter.execute` (ffmpeg-flite-local TTS) | `mm06-flite-` | wrapped |

Checked and NOT a leak:

- `media_tools.py` `probe_bytes` — its `NamedTemporaryFile(delete=False)`
  was already removed in a `finally` block; left as-is apart from
  dropping its now-redundant local `import tempfile`.
- `plan_exec.py`, `service.py`, `gateway.py`, `payloads.py`,
  `envelope.py`, `plans.py` — no temp-dir creation anywhere (grep
  over the whole worker service).

Non-product sites (listed for completeness; no product change):

- `tests/test_mm06_media.py` module scratch root (`mm06-tests-*`,
  ~75 MB per suite run — the largest single residue chunk): the test
  module now registers `atexit` removal of its own TMP root.
- `mm-gate-06/harness/run_media_battery.py` scratch (`mm06-battery-*`):
  gate harness, left unmodified (it is the gate's as-run evidence
  tooling); its residue is covered by the §3 cleanup.
- `gate-h/harness/*` mkdtemp stores (`gateh-*-store-*`): a different
  gate's harness, not the media path — out of scope, untouched.

## 2. The fix

`media_tools.py` gains one context manager, used by all four sites:

```python
@contextlib.contextmanager
def workdir(prefix):
    path = Path(tempfile.mkdtemp(prefix=prefix))
    try:
        yield path
    finally:
        shutil.rmtree(path, ignore_errors=True)
```

Each action body now runs inside `with mt.workdir("mm06-…-") as
workdir:` (adapter: `media_tools.workdir(...)`), so the directory the
action created is removed deterministically on **success, on
ActionFailed / MediaToolError, and on unexpected exceptions** alike.
Only the directory created by that call is removed — never a shared
or caller-owned path. The now-unused local `import tempfile` /
`from pathlib import Path` lines were dropped from the four wrapped
functions (their bodies were verified to reference neither after the
wrap). No behavior change besides cleanup: outputs are promoted into
the artifact store before the workdir is removed, exactly as before.

Files changed:

- `gate-c/worker_service/media_tools.py` — `workdir()` + top-level
  `contextlib`/`shutil`/`tempfile` imports.
- `gate-c/worker_service/actions.py` — `ffmpeg_process`,
  `ffmpeg_render`, `synthesize_speech` bodies wrapped (pure
  re-indent + the one-line `with` replacement per function).
- `gate-c/worker_service/adapters.py` — `FliteLocalAdapter.execute`
  wrapped the same way.
- `gate-c/worker_service/tests/test_mm06_media.py` — `atexit`
  cleanup of the suite TMP root + new `TestWorkdirCleanup` class (§4).

Patch was dry-run on copies and diff-inspected before being applied:
in `actions.py` the changed regions are exactly the three function
bodies + their local-import lines; in `adapters.py` exactly the
`FliteLocalAdapter.execute` body + its local imports. Nothing else in
either file moved.

## 3. Residue cleanup (existing /tmp accumulation)

Patterns removed — only directories created by the media tooling and
its MM-06 test/battery harnesses: `mm06-media-*`, `mm06-render-*`,
`mm06-tts-*`, `mm06-flite-*`, `mm06-tests-*`, `mm06-battery-*`.

- **Before:** 18 directories, 129,424 KB (≈126 MiB) under those
  patterns (the verifier had already removed an earlier ~490 MB;
  this residue re-accumulated from the post-verification suite runs).
  `/tmp` overall: 149 M used / 364 M available.
- **After:** **0** directories under those patterns; `/tmp` overall:
  23 M used / 490 M available.
- Deliberately left in place (not media-action workdirs):
  `/tmp/mm06v` (the MM-06 verifier's own scratch state, 16 MB),
  `/tmp/mm06probe`, `/tmp/mm06_probe_flite.wav` (Step-0 probe
  artifacts). No process was running against the removed dirs
  (checked before removal).

## 4. Tests

New `TestWorkdirCleanup` class in `tests/test_mm06_media.py`
(4 tests), asserting the set of media workdirs under the temp root is
**unchanged** after media action runs:

- `test_success_paths_leave_no_workdirs` — ffmpeg_process (mix),
  ffmpeg_render, synthesize_speech action, and the flite adapter all
  succeed; workdir set unchanged. **PASS**
- `test_action_failed_paths_leave_no_workdirs` — cuts with no
  declared segments and an unknown transform both raise ActionFailed
  after workdir creation; set unchanged. **PASS**
- `test_unexpected_exception_paths_leave_no_workdirs` — `mt.ffmpeg`
  patched to raise MediaToolError through ffmpeg_render, and
  `synthesize_speech_wav` patched to raise RuntimeError through the
  flite adapter; both propagate and the set is unchanged. **PASS**
- `test_workdir_context_manager_removes_on_raise_and_success` — the
  created directory exists inside the `with` and is gone after both a
  clean exit and a raise. **PASS**

Suite results (run serially, canonical invocations):

- MM-06 media module (`tests.test_mm06_media`, includes the media
  execution, validator, and TTS tests): **31 tests, OK** (27
  pre-existing + 4 new).
- Full worker suite (`gate-c`, g2 venv python, `unittest discover
  -s worker_service/tests`): **85 tests, OK** (81 baseline + 4 new).
- Post-suite /tmp check: **0** media-pattern directories — a full
  suite run now leaves nothing behind (before the fix, one run left
  ~75 MB of `mm06-tests-*` plus per-action workdirs).

Note: an initial system-python discover run showed 2 import errors
(`psycopg` missing) in `test_gateway`/`test_worker_service` — an
environment artifact of invoking with the wrong interpreter, not a
test failure; the canonical venv invocation above is the record.

## 5. Standing rule O-1 — plans snapshot

`plans.json` snapshotted post-MM-06 to
`mm-gate-06/evidence/plans_snapshot_post_mm06.json` (728,500 bytes,
copied 2026-10-29 before any D-1 work; plan files were not modified
by this fix).

## 6. Scope statement

No product changes beyond the workdir cleanup above. No plans,
registry, coordinator, workflow, or contract files were touched.
Observations O-1/O-2 from the verifier report are not addressed here
(O-2 flite escaping remains recorded for the production-TTS
decision).
