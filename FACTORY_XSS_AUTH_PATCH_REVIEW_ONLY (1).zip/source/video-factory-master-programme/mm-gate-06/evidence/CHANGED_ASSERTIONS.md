# MM-06 — CHANGED ASSERTIONS

Every pre-existing assertion this gate changed, and why. All other
changes are additive (new files, new implementations, new tests) or
confined to the 10 media plans' bodies.

1. **Worker suite, `test_worker_service.py::TestGate04Plans::
   test_all_192_plans_resolve`** — FULLY_BOUND count **69 → 79**.
   This is the gate's intended effect: the 9 `media.process` plans +
   13.03 (`media.render`) bind to the local FFmpeg implementations.
   The assertion was updated in place with an explanatory comment;
   no other line of the file changed.

2. **Op 15.12 distribution-record content shape** (`payloads.py`,
   the specific builder): the record gains `simulated: true` and
   `provider: "mock-platform-publisher"`, and each publication gains
   `status: "SIMULATED"` (MM-06 simulation labeling standard). The
   step-15 deliverable schema allows additional properties at both
   levels, and no existing test asserted the absence of these
   fields; the G8/G9 suites (which consume the record) pass
   unchanged in the regression. Downstream 16.12 reads only the
   record's artifact id, not its content.

3. **The 10 media plans' bodies + hashes** (`plans.json` via
   `generate_plans.py`): the formerly UNBOUND `media_process` /
   `media_render` action is now BOUND to `media.ffmpeg_process` /
   `media.ffmpeg_render` with a per-op tool spec; plan classification
   class changes `media` → `media_tool` with an updated note;
   plan_version stays 1.0.0 (coordinator pin). The other 182 plans
   are byte-identical (evidence: results/
   plans_regeneration_diff.json). Attempts claim after this change
   pin the new hashes; no production was in flight.

4. **`action_implementations.json`** regenerated from actions.py:
   diff is purely additive (the 3 new implementation entries); all
   16 pre-existing entries byte-identical.

5. **Test/battery fixture note (not a product assertion):** the
   first synthesis of the subtitled test fixture used `-shortest`
   against a 2 s subtitle input, truncating the "6 s" source to
   ~2 s. The fixture (test file + evidence harness) was corrected
   to span the subtitles and drop `-shortest` for that case; the
   14.08 evidence was re-run and shows the full 6.016 s narration.
