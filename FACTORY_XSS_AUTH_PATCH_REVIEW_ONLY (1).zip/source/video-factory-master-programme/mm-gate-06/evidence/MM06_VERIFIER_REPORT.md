# GATE MM-06 — INDEPENDENT VERIFIER REPORT

**Verifier:** independent verifier agent (separate from the MM-06 builder)
**Date:** 2026-10-29
**Method:** my own media (different parameters from the builder's),
my own ffprobe/ffmpeg CLI probes and loudnorm re-measurements, my own
scratch artifact store (`/tmp/mm06v/store`), plan-baseline
reconstruction from independent records, and my own serial suite runs
(worker, g8, g6, g9) with counts read from my logs and, for g9, from
the persisted database directly. Builder result JSONs were read for
claims only; nothing below rests on them.

## Verdict summary

| Item | Result |
|---|---|
| 1. Real media execution (render / loudness / reframe / negatives) | **PASS** |
| 2. Plans integrity (10 changed, 182 unchanged, L2 = 79) | **PASS** (with evidence limitation O-1, §2) |
| 3. Media validator named reasons | **PASS** |
| 4. TTS via flite path | **PASS** (minor observation O-2) |
| 5. Simulation labeling on stored 15.12 bytes | **PASS** |
| 6. Dependency register honesty | **PASS** |
| 7. Regression spot (worker 81 / g6 / g9 18-1620¢) | **PASS** (minor defect D-1, §7) |

**Defects:** one MINOR (D-1, tempdir hygiene). No critical or major
defects. **MM-06 verdict: PASS** against the gate criterion (§8).

---

## 1. Real media execution — PASS

Executed through the worker adapter→plan path
(`DeterministicLocalAdapter.execute` → plan_exec → media actions),
over media I synthesized myself (builder used 1280×720/6 s/440 Hz;
mine differ in size, duration, and frequency):

- **(a) 13.03 render** — my source: 854×480, 4.5 s, 660 Hz sine.
  Output bytes fetched from the store by SHA and probed with my own
  ffprobe: **1280×720, h264, aac 48 kHz, duration 4.501 s**. Exactly
  the review-master spec.
- **(b) 12.08 loudness mix** — my source: 640×360, 5 s, 220 Hz at
  volume 0.05. My independent loudnorm analysis of the source:
  **−48.06 LUFS**; of the produced artifact: **−15.98 LUFS**
  (target −16). The action's stored measurements match my
  re-measurement **exactly** (stored before −48.06, stored after
  −15.98, both to 0.01 LUFS). The output moved 32 LUFS toward the
  target and lands within 0.02 of it.
- **(c) 14.07 reframe** — output probed at **720×1280** (the plan
  spec's target), h264 + aac 48 kHz, duration preserved.
- **(d) Negatives** — 13.08 with **no media input** fails explicitly
  (`media.ffmpeg_process: no input artifact resolves to media bytes
  in the artifact store — nothing to process`, raised as a typed
  ProviderError through the plan path); **12.05 with media but no
  declared segments** fails explicitly (`cuts: inputs declare no cut
  segments … the tool applies declared edits, it does not invent
  them`). Store object count before/between/after both negatives:
  5 / 5 / 5 — **zero output artifacts produced by either failure**.

## 2. Plans integrity — PASS (limitation O-1)

- **Regeneration:** I copied the g1 seed + generator to /tmp and
  regenerated: output is **byte-identical** to the committed
  `plans.json` (192 plans, 79 FULLY_BOUND, plans_hash
  `806a710d…` — equal to the builder's recorded after-hash). The
  committed file is exactly generator output; no hand edits.
- **Self-consistency:** all 192 stored `plan_hash` values recompute
  correctly from their bodies.
- **The 10 transitions:** the current hashes of 12.05, 12.06, 12.07,
  12.08, 13.03, 13.05, 13.08, 14.06, 14.07, 14.08 equal the builder's
  recorded new hashes; each contains **zero UNBOUND actions** and
  binds `media.ffmpeg_process` / `media.ffmpeg_render`; a
  whole-file scan shows **no other plan references the media
  implementations**.
- **Bound-set differences (the confinement proof):** the FULLY_BOUND
  set at the Gate 04 baseline was 69 (19 SPECIFIC + the 50 named
  deterministic ops, per the Gate 04 record) and in MM-01's
  classification (bound at plans_hash `a71d77c6…`) it is the same 69
  once 08.12's differently-worded derivation is accounted for. The
  current bound set (79) minus either baseline set is **exactly the
  10 named ops**; nothing was unbound. Genuine L2 = **79** confirmed
  by recount, not by assertion.
- **Registry:** `registry_tool.py validate` PASS with
  **definition_hash `ea4503f516fc…` intact**; `plans-validate` PASS,
  0 problems. 08.12's plan hash is `244c5fcc…`, identical to the
  MM-00 baseline record — the Phase 3 body is untouched by MM-06.

**O-1 (evidence limitation, not a build defect):** a literal
byte-diff of the current file against the pre-MM06 `plans.json`
cannot be re-performed: the file was regenerated in place, every
scratch DB's plan table was reloaded during the builder's regression
(I checked all 19 databases — all carry the new hashes), and my
attempt to reconstruct the 10 old bodies field-for-field did not
reproduce the builder's recorded old hashes (the old classification
note texts are not recoverable from any surviving record). The
confinement claim therefore rests on: regeneration determinism,
whole-doc hash-chain continuity (`a71d77c6…` baseline anchored
independently in the MM-00 baseline report, the MM-01
classification, and the Lean Phase 3 verifier report), the
bound-set differences against two independent baseline records
above, and generator-source confinement (only the 10 CLASS entries
use the media/render cores). That is sufficient to establish the
claim; the gap is recorded so a future gate can snapshot plan files
before regeneration instead of relying on hash chains.

## 3. Media validator — PASS

Using `media_tools.validate_media` on my own files against the
master expectations (h264 / aac / 48 kHz / video+audio required):

| Case | Failures returned | Expected |
|---|---|---|
| valid master | `[]` (ok) | `[]` |
| truncated (first 2048 bytes) | `MEDIA_TRUNCATED_OR_CORRUPT` | same |
| wrong codec (mpeg4 re-encode) | `VIDEO_CODEC_MISMATCH` | same |
| missing audio (video-only) | `AUDIO_STREAM_MISSING` | same |

Every failure is the specific named reason constant — no generic
errors, no false passes.

## 4. TTS — PASS (observation O-2)

Executed the `ffmpeg-flite-local` adapter on my own 84-character
text. The produced object, fetched from the store by its SHA and
probed with my own ffprobe: **pcm_s16le WAV, 5.435 s** — exactly the
duration of my direct CLI flite synthesis of the same text — plainly
consistent with real synthesis of the text, not a fixed stub file.
Result metadata: `simulated: false`, `label: "LOCAL_TOOL"`,
`engine: "ffmpeg-flite-local"`, voice `slt`. The honest labeling the
matrix promises is what the artifact carries.

**O-2 (MINOR observation):** the flite filter-argument construction
escapes apostrophes but not other filter metacharacters — my first
attempt's text contained a colon (`"The verifier speaks: …"`) and
synthesis failed with a typed ProviderError from the ffmpeg exit
(234). The failure is explicit and produces no artifact (safe
direction), but narration-grade prose routinely contains colons, so
the escaping should be hardened before this path carries production
text. Recorded for the production-TTS decision; does not affect the
gate criterion (an executable local implementation exists and works
on ordinary text).

## 5. Simulation labeling — PASS

I ran the g8 station suite myself (1/1 OK), then read the CURRENT
`distribution_record` artifact from the persisted g8 scratch DB and
fetched its bytes from the Gate D store by SHA (SHA-256 of the bytes
re-verified against the DB record — i.e., the stored artifact
itself, produced by the real station-6 n8n path, not an API
summary). The stored record carries:

- `simulated: true`
- `provider: "mock-platform-publisher"`
- **all 3 publications with `status: "SIMULATED"`** (and
  `platform_post_id` values visibly mock-prefixed).

A simulated record is distinguishable from a real one by its stored
fields alone. 

## 6. Dependency register honesty — PASS

Checked against the environment and the code myself:

- ffmpeg/ffprobe **8.1.2**; encoders libx264 + aac present; filters
  loudnorm, signalstats, **flite** present (matrix's probe facts
  reproduce exactly).
- **No** espeak, espeak-ng, piper, festival, or flite binaries on
  PATH (flite exists only as the ffmpeg filter, as the matrix
  states). Node v24 present; **no Remotion package** found in global
  modules or any workspace `node_modules` I searched — the
  NOT_ADOPTED rationale (not installed, no operation requires it)
  is accurate.
- **Zero provider credentials** in the environment (only runtime
  JARVIS_* vars) — consistent with "MM-12 owns credentials".
- `adapters.py`: the registry contains exactly the named adapters —
  `http-image`, `http-video`, `http-speech`, `http-transcription`,
  `http-stock` (all `HttpMediaAdapter`, inheriting
  `credential_required = True` from `DirectHttpTextAdapter`, and the
  base adapter refuses execution without a binding `credential_ref`)
  — so the matrix's "adapter exists, credential-gated" claims are
  literally true, including the honest demotion of `http-video` to
  "unproven integration shape".
- **Video generation blocker:** I counted output modalities in the
  MM-02 catalog snapshot (457 models, provenance: OpenRouter API,
  fetched 2026-10-29): **zero video-output models**, 12 image-output
  models. The matrix's statement — no OpenRouter binding can serve
  video generation; an owner provider decision is required — is
  accurate and correctly cited.

## 7. Regression spot — PASS (minor defect D-1)

Counts from my own logs, run serially:

- **Worker suite: 81 tests, OK** (54 baseline + 27 MM-06, matching
  the recorded addition).
- **g6 suite: 3 tests, OK.**
- **g9 suite: 10 tests, OK**; and from the persisted
  `g9_fullrun_scratch` DB directly: the full-run production has
  **18 units ACCEPTED, 18 FINALIZED evidence rows totalling
  1620¢, 18 CHARGE transactions totalling 1620¢, 18 reservations
  SETTLED** — the 18/1620 shape intact on the new plans.

**D-1 (MINOR):** my first worker-suite attempt failed in
`setUpClass` — `setup_db.py` died with `OSError: [Errno 28] No
space left on device`. Cause: `/tmp` is a 512 MB tmpfs and the
MM-06 media work had filled it — ~490 MB of `mm06-tests-*`,
`mm06-battery-*`, `mm06-render-*`, `mm06-media-*` tempdirs. The
media actions create `tempfile.mkdtemp` workdirs (full media copies
per execution) and never delete them; the builder's battery and the
gate's own test suite each leave tens of MB per run. After I removed
the stale tempdirs (490 MB free), the suite passed cleanly, so this
is not a correctness defect — but on any host with a small tmpfs,
sustained media execution will exhaust scratch space and start
failing unrelated work with misleading errors. Recommend the media
actions clean their workdirs (or write them under the storage root)
in a follow-up. Disclosed verifier-side impact: my first two suite
invocations (one rc=120 with an empty log, one FAILED errors=2) were
both this ENOSPC, not product assertion failures; the passing runs
above are the record.

## 8. Verdict

Against the gate PASS criterion — *"every required capability has
an executable implementation or a precisely identified external
dependency; no missing provider is represented by a fake production
result"*:

- FFmpeg processing/rendering, audio processing, media validation,
  and local TTS are **genuinely executable locally** — proven on my
  own media with my own probes, including exact loudness
  re-measurement and explicit-failure negatives.
- Speech recognition, image generation, and stock acquisition are
  **adapter-ready and credential-gated**, with the adapters verified
  to exist under the registered names and to refuse without
  credentials; the plans for AI-media generation remain UNBOUND
  rather than mock-bound.
- Video generation and real platform publishing are **precisely
  identified external dependencies** (the video blocker is backed
  by a counted catalog fact: 0/457), and the local publishing path
  is **machine-visibly labeled simulated in its stored bytes**.
- The plan bindings changed exactly where the lock said they would
  (10 plans; L2 69 → 79), the registry hash is intact, and the
  regression shape (81 worker / g6 / g9 18-units-1620¢) holds.

**GATE MM-06: PASS** — with one MINOR defect (D-1, media-workdir
cleanup) and two observations (O-1 baseline-file snapshot practice,
O-2 flite argument escaping) recorded for follow-up. No capability
is represented by a fake production result.

*Verifier scratch state: /tmp/mm06v (media, store, logs). The
builder's stale /tmp tempdirs were removed during §7 remediation —
disclosed above; no product file was modified by this verification.*
