#!/usr/bin/env python3
"""MM-06 evidence battery — executes the 10 newly bound media
operations, the media validator cases, local TTS and the simulation
labeling checks through the real worker path over lavfi-synthesized
media, and records ffprobe evidence excerpts as JSON results.

Label discipline: media execution = LOCAL_TOOL_EXECUTION (local
ffmpeg over synthetic media — not provider output); TTS =
LOCAL_TOOL; publishing receipts = SIMULATED."""
import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path

WS = Path.home() / "workspace/video-factory-real-ai-programme/gate-c/worker_service"
sys.path.insert(0, str(WS))
sys.path.insert(0, str(Path.home() / "workspace/video-factory-real-ai-programme/gate-d"))
import adapters as adapters_mod  # noqa: E402
import media_tools as mt  # noqa: E402
import payloads  # noqa: E402

OUT = Path(__file__).resolve().parent.parent / "evidence" / "results"
TMP = Path(tempfile.mkdtemp(prefix="mm06-battery-"))
os.environ["FACTORY_STORAGE_ROOT"] = str(TMP / "store")
os.environ["FACTORY_STORAGE_BACKEND"] = "local"


def ffmpeg(args):
    p = subprocess.run(["ffmpeg", "-nostdin", "-v", "error", *args],
                       capture_output=True, text=True,
                       stdin=subprocess.DEVNULL)
    assert p.returncode == 0, p.stderr[-400:]


def synth(name, video_dur=6, audio_dur=6, volume=None, subtitles=False):
    path = TMP / name
    args = ["-f", "lavfi", "-i",
            f"testsrc2=duration={video_dur}:size=1280x720:rate=30"]
    if audio_dur:
        args += ["-f", "lavfi", "-i",
                 f"sine=frequency=440:duration={audio_dur}"]
    if subtitles:
        srt = TMP / "subs.srt"
        srt.write_text("1\n00:00:00,500 --> 00:00:02,000\n"
                       "The ledger is gone.\n\n"
                       "2\n00:00:03,000 --> 00:00:05,500\n"
                       "It was locked from inside.\n")
        args += ["-i", str(srt)]
    args += ["-c:v", "libx264", "-pix_fmt", "yuv420p"]
    if audio_dur:
        if volume:
            args += ["-af", f"volume={volume}"]
        args += ["-c:a", "aac", "-ar", "48000"]
    if subtitles:
        args += ["-c:s", "mov_text"]
    if video_dur == audio_dur and not subtitles:
        args += ["-shortest"]
    args += [str(path), "-y"]
    ffmpeg(args)
    return path


def store(path):
    from storage_service import factory_from_env
    s = factory_from_env()
    staged = s.put_candidate(Path(path).read_bytes())
    s.promote(staged["uri"])
    return staged["sha256"]


def brief(probe):
    if not probe:
        return None
    v = mt.first_stream(probe, "video")
    a = mt.first_stream(probe, "audio")
    return {"format": probe["format_name"],
            "duration_s": probe["duration_s"],
            "video": ({"codec": v["codec"], "width": v["width"],
                       "height": v["height"]} if v else None),
            "audio": ({"codec": a["codec"],
                       "sample_rate": a["sample_rate"],
                       "start_time_s": a["start_time_s"],
                       "duration_s": a["duration_s"]} if a else None)}


BINDING = {"provider": "deterministic-local", "est_cost_cents": 100,
           "params": {}}


def run_op(op, refs):
    adapter = adapters_mod.DeterministicLocalAdapter()
    result = adapter.execute(BINDING, {
        "operation_id": op, "production_id": "mm06-battery",
        "unit_id": f"u-{op}", "attempt_id": None,
        "input_artifact_refs": refs})
    doc = json.loads(result["content"])
    summary = result["plan_execution"]
    return doc, summary


def main():
    src = synth("src.mp4")
    src_sha = store(src)
    media_ref = {"artifact_type": "media_asset", "artifact_id": "src",
                 "sha256": src_sha}
    input_probe = brief(mt.probe_media(src))
    results = {"label": "LOCAL_TOOL_EXECUTION", "battery": "mm06_media",
               "input_media": input_probe, "operations": []}

    def record(op, doc, extra_refs_desc, extra=None):
        derived = doc["derived"]
        key = "media_render" if "media_render" in derived else "media_process"
        action = derived[key]
        entry = {"operation_id": op, "action_key": key,
                 "inputs": extra_refs_desc,
                 "action_status": "SUCCEEDED",
                 "validation": action["validation"]}
        if action.get("media_output"):
            data = mt.fetch_media_bytes(action["media_output"]["sha256"])
            entry["output_probe"] = brief(mt.probe_bytes(data))
            entry["output_sha256"] = action["media_output"]["sha256"]
        else:
            entry["output_probe"] = None
        for k in ("segments_applied", "audio_offset_ms_applied",
                  "loudness_before", "loudness_after", "measurements",
                  "target", "subtitles"):
            if k in action:
                entry[k] = action[k]
        if extra:
            entry.update(extra)
        results["operations"].append(entry)

    edl = {"artifact_type": "edit_decision_list", "artifact_id": "edl",
           "sha256": "unused",
           "content": {"segments": [{"start_s": 0, "end_s": 2},
                                    {"start_s": 3, "end_s": 5}]}}
    doc, _ = run_op("12.05", [media_ref, edl])
    record("12.05", doc, "media + EDL segments [0-2, 3-5]")
    sync = {"artifact_type": "sync_record", "artifact_id": "sync",
            "sha256": "unused", "content": {"audio_offset_ms": 500}}
    doc, _ = run_op("12.06", [media_ref, sync])
    record("12.06", doc, "media + audio_offset_ms=500")
    short_sha = store(synth("short.mp4", audio_dur=2))
    doc, _ = run_op("12.07", [{"artifact_type": "media_asset",
                               "artifact_id": "short",
                               "sha256": short_sha}])
    record("12.07", doc, "media with 2s audio bed under 6s picture")
    quiet_sha = store(synth("quiet.mp4", volume=0.1))
    doc, _ = run_op("12.08", [{"artifact_type": "media_asset",
                               "artifact_id": "quiet",
                               "sha256": quiet_sha}])
    record("12.08", doc, "quiet media (volume 0.1 sine)")
    doc, _ = run_op("13.03", [media_ref])
    record("13.03", doc, "media (single input)")
    doc, _ = run_op("13.05", [media_ref])
    record("13.05", doc, "media (measurement only)")
    doc, _ = run_op("13.08", [media_ref])
    record("13.08", doc, "media")
    doc, _ = run_op("14.06", [media_ref, edl])
    record("14.06", doc, "media + EDL segments [0-2, 3-5]")
    doc, _ = run_op("14.07", [media_ref])
    record("14.07", doc, "media -> 720x1280 portrait")
    subs_sha = store(synth("subs.mp4", subtitles=True))
    doc, _ = run_op("14.08", [{"artifact_type": "media_asset",
                               "artifact_id": "subs",
                               "sha256": subs_sha}])
    record("14.08", doc, "media with embedded mov_text subtitles")

    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / "media_execution.json").write_text(
        json.dumps(results, indent=1, sort_keys=True))

    # validator battery
    master_exp = {"video_codec": "h264", "audio_codec": "aac",
                  "sample_rate": 48000, "require_video": True,
                  "require_audio": True}
    truncated = TMP / "truncated.mp4"
    truncated.write_bytes(src.read_bytes()[:4096])
    mpeg4 = TMP / "mpeg4.mp4"
    ffmpeg(["-i", str(src), "-c:v", "mpeg4", "-c:a", "aac",
            str(mpeg4), "-y"])
    vonly = TMP / "vonly.mp4"
    ffmpeg(["-f", "lavfi", "-i", "testsrc2=duration=3:size=640x360:rate=30",
            "-c:v", "libx264", "-pix_fmt", "yuv420p", str(vonly), "-y"])
    validator = {"label": "LOCAL_TOOL", "battery": "mm06_validator",
                 "cases": []}
    for name, path, exp in (
            ("valid_master", src, master_exp),
            ("truncated", truncated, master_exp),
            ("wrong_codec_mpeg4", mpeg4, master_exp),
            ("missing_audio", vonly, master_exp),
            ("missing_file", TMP / "nope.mp4", master_exp)):
        out = mt.validate_media(path, exp)
        validator["cases"].append(
            {"case": name, "ok": out["ok"], "failures": out["failures"],
             "probe": brief(out["probe"]) if out["probe"] else None})
    (OUT / "media_validator.json").write_text(
        json.dumps(validator, indent=1, sort_keys=True))

    # TTS battery
    adapter = adapters_mod.build_registry("test")["ffmpeg-flite-local"]
    tts = adapter.execute({"provider": "ffmpeg-flite-local", "params": {}},
                          {"prompt": "The archive door was locked "
                                     "from inside.",
                           "operation_id": "tts", "production_id": "mm06"})
    (OUT / "tts_local.json").write_text(json.dumps(
        {"label": "LOCAL_TOOL", "battery": "mm06_tts",
         "adapter": "ffmpeg-flite-local", "result_content": tts["content"],
         "usage": tts["usage"]}, indent=1, sort_keys=True))

    # simulation labeling battery
    pkg = {"artifact_type": "derivative_package", "artifact_id": "pkg",
           "sha256": "s",
           "content": {"kind": "derivative_package", "derivatives": [
               {"id": "D-vertical", "format": "9:16", "platform": "shorts",
                "payload": "x", "sha256": "a" * 64}]}}
    _t, content = payloads.build("15.12", "p", "u", [pkg])
    doc = json.loads(content)
    (OUT / "simulation_labeling.json").write_text(json.dumps(
        {"label": "SIMULATED", "battery": "mm06_labeling",
         "distribution_record": doc,
         "marking_fields": {"simulated": doc.get("simulated"),
                            "provider": doc.get("provider"),
                            "publication_statuses":
                                [p["status"] for p in doc["publications"]]}},
        indent=1, sort_keys=True))
    print("battery written:", [p.name for p in sorted(OUT.glob("*.json"))])
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
