# LEAN AI PRODUCTION FACTORY — EXECUTION-FIRST RECOVERY (owner directive, 2026-10-29)

*Raj's directive of 2026-10-29 06:31 EDT. Governing sequence from receipt: finish Gate 05 security, then ONE Station 03 vertical slice with a genuine provider, then controlled expansion. Full text as received is preserved in the conversation record and summarized operationally below; the architecture lock (n8n / PostgreSQL / Coordinator / Workers / Evaluator — exactly five responsibilities) and the forbidden-expansion list bind all further work. No new scheduler, engine, ledger, registry, plan abstraction, microservice, operation ID, or gate type may be introduced.*

## Phase map (controller's register)
| Phase | Content | Status |
|---|---|---|
| 0 | Source + environment verification | IN PROGRESS (register/baseline already established under Gates 00–04; credential inventory done 2026-10-29: **no provider credential present in environment or vault-adjacent files**) |
| 1 | Complete Gate 05 security (= Master Programme Gate 05) | Builder COMPLETE; independent verification against G05-T01..T10 in flight |
| 2 | Select one real Station 03 operation + freeze its spec | Queued after Phase 1 verification |
| 3 | Configure a real text provider | Preparation proceeds; **acceptance test BLOCKED_EXTERNAL** until owner supplies credential + spend authorization (env scan: none present) |
| 4 | Connect the real model to n8n (Station 03 workflow) | Depends on Phase 3 |
| 5 | Produce a genuine artifact | Depends on Phase 4 |
| 6 | Verify actual cost + DB records | Depends on Phase 5 |
| 7 | Independent quality + human approval (HG2; 50+ EXPERT arming NOT lowered) | Depends on Phase 5 |
| 8 | Verify downstream handoff (real consumption) | Depends on Phase 7 |
| 9 | Vertical-slice acceptance battery | Depends on Phases 4–8 |
| 10 | Expand inside Station 03 | After Phase 9 PASS |
| 11 | Expand across remaining stations (dependency order) | After Phase 10 |
| 12 | Complete the 192-operation coverage register (DEFINED/EXECUTABLE/TESTED/PRODUCTION-VERIFIED tracked separately) | Continuous from Phase 10 |
| 13 | Full end-to-end production | Final |

## Reconciliation with the Master Execution Programme (Gates 00–14)
Gates 00–04 PASSED stand. Gate 05 = Lean Phase 1. The lean sequence takes precedence for what happens next: Master-Programme Gates 07 (real providers), 10 (192-op verification), and 12 (autonomous production) are pursued THROUGH Lean Phases 3–13 in dependency order rather than as separate framework gates. Master-Programme items not covered by the lean sequence (Gate 06 validation-contract completion beyond the slice's needs, Gate 09 real-S3 deployment, Gate 13 adversarial certification, Gate 14 evidence lock) remain recorded in the register as open work, to be scheduled explicitly — not silently dropped, and not allowed to block the vertical slice. The Gate 01 remediation register remains the deficiency backlog for expansion phases.
