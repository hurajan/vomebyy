# GATE MM-12 — OWNER CREDENTIAL + SPENDING AUTHORIZATION PACKAGE

Prepared 2026-10-29 by the controller, per the Multi-Model programme's
Rule 11 (no credential request, no paid call, no real-provider spending
before this gate) and the MM-12 specification (exact selections,
bindings, pricing assumptions, test scope, maximum authorized spending,
expected requests, data retention/privacy — explicit owner approval
before enabling paid execution; credentials only via the secure vault,
never in chat).

## State behind this package

- MM-00 … MM-10: PASSED (MM-10 with the D-MM10-V1 evidence exception,
  recorded). MM-11: local readiness PASSED; deployment target
  BLOCKED_EXTERNAL (owner items, §7 below).
- Everything credential-independent is built and verified: model
  registry + promotion machinery (MM-03), authorized-fallback gateway
  with exactly-once cost accounting (MM-04/MM-08), provider spend caps
  (MM-08), evaluation independence (MM-02/MM-03), the Lean slice's
  genuine path for operation 08.12 (prepared Phases 3–4, verified).
- Zero genuine provider calls have ever been made. No credential
  exists in the environment (verified by name-only inventory).

## Decision 1 — Promote Model Selection Matrix 1.0.0 to ACTIVE

Promotion is an OPERATOR action in the MM-03 registry; it writes the
executable bindings for the 72 model-bound assignments. Nothing is
promoted before your approval. Selections (catalog of 457 models,
fetched live 2026-10-29; prices = published $ per 1M tokens
prompt/completion):

| Role | Primary | Fallback |
|---|---|---|
| Station 01 | openai/gpt-4.1 ($2.00/$8.00) | anthropic/claude-sonnet-4.5 ($3.00/$15.00) |
| Station 02 | anthropic/claude-sonnet-4.5 ($3.00/$15.00) | openai/gpt-5 ($1.25/$10.00) |
| Station 03 | anthropic/claude-sonnet-4.5 ($3.00/$15.00) | google/gemini-2.5-pro ($1.25/$10.00) |
| Station 04 | google/gemini-2.5-pro ($1.25/$10.00) | anthropic/claude-sonnet-4.5 ($3.00/$15.00) |
| Station 05 | openai/gpt-5 ($1.25/$10.00) | anthropic/claude-sonnet-4.5 ($3.00/$15.00) |
| Station 06 | google/gemini-2.5-flash ($0.30/$2.50) | openai/gpt-5-mini ($0.25/$2.00) |
| EVALUATION | google/gemini-2.5-pro ($1.25/$10.00) | openai/gpt-5 ($1.25/$10.00) |

- HIGH pairs (hard operations; Station 03's applies to all 21 of its
  AI_TEXT ops incl. 08.12): anthropic/claude-opus-4.8 /
  openai/gpt-5.5 (Station 02 HIGH pair identical).
- Evaluation independence is structural: where a station's generator
  primary equals the EVALUATION primary (Station 04), evaluation uses
  the EVALUATION fallback instead — verified for all 27 EVALUATION
  assignments at MM-02.
- Per-operation cost ceilings are already seeded on all 192
  assignments (MM-03, from MM-01 classes); an over-ceiling claim
  refuses before any call.
- The Lean slice's earlier PROPOSED binding (claude-haiku-4.5) is
  superseded by this matrix on promotion (Station 03 standard pair),
  as recorded since MM-02.
- Comparative quality claims in the matrix are labeled
  UNVERIFIED_BENCHMARK; MM-13 produces the first genuine evidence.

## Decision 2 — Credential (mechanics)

- ONE credential covers the entire matrix: an OpenRouter API key
  (every selected model routes through the single
  openrouter-compatible gateway). No other credential is required for
  the MM-13 scope below.
- Stage it ONLY through the secure vault capture (the programme never
  accepts secrets in chat). The worker service reads it via its
  credential_ref (OPENROUTER_API_KEY) at call time; the key value
  never enters code, workflows, logs, or evidence (verified pattern
  from MM-04: provider_health and evidence carry no prompt/secret
  content).

## Decision 3 — MM-13 test scope + maximum authorized spending

Bounded battery (through the real n8n workflows on the local stack —
see §6 for the deployment caveat), fixture content only:

1. Operation 08.12 genuine script generation (the Lean slice,
   Station 03 standard pair) — the program's headline proof, ending
   at your HG2 decision on genuine model content.
2. One genuine AI_TEXT operation per remaining station role
   (Stations 01, 02, 04, 05, 06) — 5 calls.
3. One EVALUATION-role judging call on a genuine output (independence
   rule applies) — 1 call.
4. One forced-fallback call (primary made to fail at the stub level
   is NOT possible against the real provider; instead the battery
   pins an assignment whose primary is a deliberately invalid model
   id within the test policy, proving authorized fallback + fallback
   pricing against the real gateway) — ~2 calls.
5. One image generation (op 10.10, google/gemini-3-pro-image /
   openai/gpt-5-image) — 1 call.
6. Retry/duplicate safety margin: the battery caps total requests at
   30 including bounded retries (gateway max 2 retries, 429/5xx
   only).

Expected requests: ~12 planned, ≤30 worst case.
Expected cost: ≈ $1–3 (per-call ≈ 2–10¢ at matrix prices with
fixture-sized prompts; image generation priced per matrix).
**Requested maximum authorized spending: $25 (2500¢)**, enforced
three ways by machinery already verified at MM-08: per-operation
max_cost_cents ceilings (seeded), a production hard ceiling on the
battery production, and a provider day-cap row
(openrouter-compatible, production environment). Any refusal stops
the battery and is reported; nothing retries past a cap. You may set
any other figure — the enforcement does not depend on the number.

## Decision 4 — Data retention / privacy posture

Verified gap (MM-02): the OpenRouter catalog exposes NO per-model
data-policy/training terms, so no zero-retention claim can be made
from catalog data. The MM-13 battery sends ONLY fixture content (the
standing test story fixture and synthetic prompts — no user data, no
personal data, no production manuscripts). Options:

(a) Proceed for MM-13 under OpenRouter's default routing/terms,
    fixture content only; revisit before any production content
    (MM-14) with per-model terms confirmed.
(b) Restrict provider routing to zero-retention endpoints where the
    gateway offers them (may change the effective serving provider
    per model; prices broadly similar; selection of models
    unchanged).
(c) Defer all genuine execution until per-model terms are confirmed
    to your satisfaction (MM-13 waits; everything else is done).

## Decision 5 — Deferrable provider choices (NOT needed for MM-13)

Recorded so they are decided deliberately, each at its own time:
video-generation provider for 11.04/11.06/11.11 (no video-output
models exist on OpenRouter — a separate provider decision; those
three ops stay mock/simulated or unbound until then); stock-media
provider; transcription provider; production-grade TTS provider
(local flite works and is quality-labeled); publishing platform
accounts/OAuth (15.x real publishing). None of these blocks the
MM-13 text/evaluation battery.

## Decision 6 — Production identity (deferrable to MM-14)

Approvals today are recorded under shared role identities
(OPERATOR/WORKER/...). The 144-operation approval-policy class from
Gate 05 remains AWAITING_OWNER: a named-approver model (who may
approve what, by name) is required before production approvals are
meaningful. Not needed for MM-13 (its human decisions are yours,
recorded as operator). Decide before MM-14.

## Deployment caveat (§6) + Decision 7 — MM-11 hosting items

MM-13's prompt text says "through the deployed n8n workflows". The
workflows are identical locally and deployed (same trees, same n8n);
MM-11's target is BLOCKED_EXTERNAL on owner items: (i) a factory
hosting decision/order (none exists — the Studio's OD-010 does not
apply to this workstream), (ii) G0.6 SSH host-identity confirmation
via the provider's out-of-band channel, (iii) DNS/TLS, (iv)
off-machine backup destination + storage backend decision (OD-A4),
(v) vault staging of service tokens for the deployed stack,
(vi) any data-residency/legal constraints you want applied.
Approving this package authorizes MM-13 on the LOCAL stack; the
programme's final token would remain
[BLOCK:DEPLOYMENT_ACCESS_REQUIRED] until MM-11 clears — MM-14 cannot
claim production readiness for an undeployed factory. If you prefer
MM-13 to wait for deployment, say so and MM-13 holds.

## Minor item — OD-A1

The factory trees are still not a Git repository (baselines are
manifest-pinned; MM-11's revision pin uses the manifest aggregate).
Creating a repo is a one-line approval whenever you want it; it
changes no behavior.

## What happens on approval

On your approval of Decisions 1–4 (+ the §6 local-stack note): you
stage the key via the vault; the controller promotes matrix 1.0.0
(OPERATOR action, audited, reversible by rollback); the MM-13
battery runs bounded as scoped; results return with actual spend vs
the authorized cap, request-by-request evidence, and your HG2
decision point on the genuine 08.12 script. If anything refuses on a
cap or a ceiling, the battery stops and reports — by design.
