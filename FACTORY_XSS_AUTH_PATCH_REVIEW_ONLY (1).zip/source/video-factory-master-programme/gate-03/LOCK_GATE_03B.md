# LOCK — GATE 03 Option B: correct the trees (step 12 → Station 5 / G7)

- **Ruling: Raj, 2026-10-28** — Option B selected. Options A and C explicitly rejected (A would change the authoritative registry to match an implementation error; C would formalize a known contradiction).
- **Evidence basis**: original source documents + all 192 registry entries agree — Chapter 12 belongs to Station 5 (gate-03/DECISION_PACKAGE_12_12.md; gate-03/evidence/routing_table.json).

## Ruling points (owner's, verbatim substance)
1. Preserve workflow version 1.0.0, its operation definitions, and registry hashes.
2. Move execution responsibility for all 12 Chapter 12 operations from the G6/Station 4 implementation to G7/Station 5.
3. Update generated n8n workflows, worker bindings, scheduler routing, and Gate 02 executor identity mappings consistently.
4. Preserve existing artifact identities, dependencies, financial records, and Coordinator authority.
5. Coordinate Gate 02 and Gate 03 changes through exclusive file ownership. Do not overwrite or merge the in-flight Gate 02 work.
6. Verify all 192 operation routes against the authoritative registry.
7. Run the affected G6/G7 suites, Gate 02 adoption tests T02-A–I, the G9 integration battery, and the complete regression suite.
8. Verify that no Chapter 12 operation can be executed through an unauthorized Station 4 worker.
9. Preserve historical execution evidence; document any compatibility requirements for existing in-flight productions.

## Mandatory PASS condition
All Chapter 12 operations route to Station 5, all 192 routing assignments match the approved registry, Gate 02 identity and adoption protections remain intact, and affected regressions pass.

## Coordination and sequencing (controller's, under ruling point 5)
- **Phase 1 (first, no product edits)**: Gate 02's remaining evidence run on the CURRENT seam — T02-E, T02-H, and the six station suites (fix_dh1_t02hi.py) — because those harnesses exercise the pre-B routing; their results are Gate 02's historical evidence and must be captured before the routing changes land.
- **Phase 2 (Gate 03-B build, exclusive ownership)**: the Gate 03 builder owns — g6 + g7 generators and regenerated workflows, g6/g7 setup_env.py (station bindings), g6/g7 drivers and suites, the coordinator's step→executor identity mapping (step 12: g6 → g7 identity), g9 setup_fullrun.py (chain re-homing), and Gate 01's routing-derived docs if needed. It does NOT own: gate-h evidence files, prior gate reports, the registry/seed/contracts, migrations, the worker service payload builders (12.12's builder is operation-keyed, tree-independent), or Gate 02's adoption code (read-only dependency).
- **Phase 3 (verification)**: independent verifier — ruling points 6–8 + full regression (serialized), Gate 02's T02-A–I re-run on the final code, Gate 01 spot-checks, Gate 00's outstanding suite runs close inside the same battery.
- **Compatibility note (point 9)**: routing is runtime mapping, not definition — productions pinned to workflow 1.0.0 are definitionally unaffected; any in-flight production with an unexecuted step-12 unit will route that unit to the Station 5 executor after this change (recorded here as the compatibility requirement; no production is in flight in the current environment).

## Terminology correction (owner, same ruling)
Gate 01's "L2 EXECUTABLE 192" is corrected: the 173 generic-only operations are **technically dispatchable but lacking operation-specific implementation evidence** — not genuinely L2. Genuine L2 count = 19 until Gate 04 establishes capability/action bindings. The Gate 01 register and classification are amended to carry this label; historical Gate H wording ("L2 192") is superseded by this correction wherever cited.
