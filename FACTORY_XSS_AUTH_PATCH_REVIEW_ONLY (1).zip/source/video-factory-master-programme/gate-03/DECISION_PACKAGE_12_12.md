# GATE 03 DECISION PACKAGE — Operation 12.12 (and all of step 12): registry station 5 vs serving tree g6

**Gate:** 03 — Registry and station reconciliation (Master Execution Programme)
**Type:** Owner decision package (Gate 03 task 4 route). Analysis only — nothing in this package has been implemented.
**Evidence:** `evidence/routing_table.json` (all 192 operations), `evidence/routing_sources.md` (source-document proof).

---

## 1. The facts

1. **The registry seed is faithful to its sources.** Both original source documents (`Six_Station_192_Operation_Runtime_Map.md` and `192_documented_atomic_operations.txt`, the seed's pinned provenance) assign Chapter/Step 12 (EDIT) to **Station 5**: Station 4 = chapters 09–11, Station 5 = chapters 12–14. The seed (workflow 1.0.0, definition_hash `ea4503f5…`) reproduces this exactly — its stations metadata, steps metadata, and all operation rows agree, and the G1 loader's `validate()` enforces the agreement. **The seed does not diverge from its own source documents.**
2. **The A–Z Guide agrees with the sources.** Its build table scopes G6/Station 4 as "Steps 09–11" and G7/Station 5 as "Steps 12–14: edit, master render, derivatives".
3. **The divergence entered at the G6 lock.** The G6 lock request (agent-prepared, owner-confirmed 2026-10-28) scoped "Station 4 (Steps 09–12)", listing Step 12 (Edit) under Station 4; the G7 lock consequently scoped Station 5 as steps 13–14. Neither lock text mentions the registry or source station assignment. The built g6 tree therefore serves steps 09–12 under a workflow named `station-04`, and its driver dispatches 12.12 with payload field `station: 4`.
4. **The divergence class is all 12 step-12 operations, not only 12.12.** The full routing table (192 rows) proves: exactly 12 rows diverge — `12.01`–`12.12`, registry station 5 vs serving tree g6 (station-04 label). Every other step is clean, including all other step exits; no station boundary falls inside any other step. 12.12 is simply the only step-12 operation ever executed as a unit (units are planned for step exits plus 01.01 and 14.01), which is why it is the only one that ever needed a workaround.
5. **Two routing systems currently coexist and disagree about step 12:**
   - *Config resolution* (coordinator `_resolve_config`) probes the STATION scope using the **registry** station read from `operation_definitions`. For 12.12 that is station 5 — so the g6 tree's seeded STATION-4 binding never resolves for it.
   - *Executor routing* (Gate 02 fix, in flight) is **step-based**: `coordinator._EXECUTOR_STEP_RANGES` maps steps 09–12 → g6 executor identity `n8n-executor-g6`, with an in-code comment recording that this is deliberate ("The mapping is STEP-based, not registry-station-based").
6. **The known workaround:** Gate G added an OPERATION-scope provider binding for 12.12 in `video-factory-g6/tools/setup_env.py` (with an explanatory comment) so claims in the g6 scratch environment resolve the deterministic-local binding instead of falling through to the FACTORY mock seed. In the G9 full-run environment the same claim instead resolves a STATION-5 binding, because `video-factory-g9/tools/setup_fullrun.py` seeds STATION bindings for all six stations globally. The workaround is therefore environment-dependent folklore, not a single recorded rule.
7. **Framing note on "existing approval":** the G6 lock *was* owner-confirmed with the steps 09–12 span in its text. It did not present the span as a change to the registry's station assignment, and every subsequent programme record (Gate G evidence, Gate H report, Gate 01 finding G01-D04, the controller's STATE.md) treats the question as unresolved. This package therefore puts the interpretation to the owner explicitly rather than inferring one.

## 2. The alternatives

### Option A — The registry is superseded: publish workflow 1.1.0 with step 12 in station 4

Change the definition so the registry matches the built trees: a new seed directory `seed-definitions/workflow-1.1.0/` in which step 12's metadata and its 12 operations carry station 4 (station counts become 24/24/48/48/24/24), producing a **new definition_hash**. Workflow 1.0.0 and hash `ea4503f5…` remain untouched and valid.

- **Files touched:** new g1 seed directory (operations.json only needs the station fields + steps/stations metadata); g1 `registry_tool.py` per-version expectations (station counts are validated — the 1.1.0 expectations must be version-scoped); no tree code changes (trees already behave this way).
- **Hash consequences:** definition_hash changes **for 1.1.0 only**; 1.0.0's hash, Gate A's source manifest, and every accepted report citing `ea4503f5…` remain accurate for 1.0.0. Existing productions are pinned to 1.0.0 and are unaffected; new productions would pin 1.1.0. The loader already supports coexisting versions (the Gate C FP-01 variant machinery loads a 1.1.0 seed alongside 1.0.0 — proven in Gate H T2).
- **Test consequences:** G1 suite gains a 1.1.0 validation case; tests that read station from a 1.1.0 context change expectation; the Gate G OPERATION-binding workaround in g6's setup becomes unnecessary for 1.1.0 databases (STATION-4 resolves) but must be retained or gated for 1.0.0 databases. The Gate 02 executor mapping stops being a "special case" — step ranges and registry stations agree under 1.1.0.
- **Semantic cost (stated plainly):** this option makes the registry **contradict its own source documents** (both sources, and the guide, put Edit in Station 5, "Post & Package"). The divergence would move from code-vs-registry to registry-vs-source. Any future rebuild from the source documents reintroduces it.
- **Gates affected:** 03 (closes), 04 (capability `serves_steps` unaffected — capabilities key on steps, not stations), 10 (route test runs against the pinned version per production), 14 (evidence lock records both hashes).

### Option B — The trees are wrong: move step 12's serving to the g7 tree (station-05)

Make the built system match the registry and the sources: the g7 tree's station-05 workflow chain extends to serve step 12 (12.12 joins 13.12/14.01/14.12 in its driver chain), and the g6 tree's span contracts to steps 09–11.

- **Files touched:** g6 generator (station-04 chain drops 12.12; driver chain shortens), g7 generator (station-05 chain gains 12.12 as its entry, fed by 11.12's `edit_timeline` input — the cross-tree input handoff pattern already exists between trees), g7 setup (its STATION-5 binding then resolves 12.12 naturally), g6 setup (OPERATION workaround deleted), g9 full-run setup/driver (chain re-links 11.12 → 12.12 across trees), coordinator `_EXECUTOR_STEP_RANGES` (step 12 → g7 — a Gate 02 seam change requiring coordination with that gate's lock), worker-service payload builders' tree groupings (comments/structure only — builders are keyed by operation).
- **Hash consequences:** none. Registry, seed, and definition_hash `ea4503f5…` are untouched; sources, guide, registry, and trees all agree afterwards.
- **Test consequences:** G6 suite redesigned (chain becomes 09.12 → 10.12 → 11.12; its Rule-of-Six fixture moves — 12.12's `edit_timeline` carries the Rule of Six block authored in the G6 tree, which must move or be re-homed in g7); G7 suite gains the 12.12 entry test; G9 full-run chain re-verified end-to-end; Gate H T9-style unattended run re-verified for the affected chains; Gate 02's T02-H and executor-mapping tests updated for the new range boundary (12 → g7). This is the largest test surface of the three options.
- **Gates affected:** 02 (executor mapping + its verification battery re-run for the changed range), 03 (closes), 10 (route test passes in its strong form: registry station == serving station == executor mapping for all 192), 12 (full autonomous production uses the corrected chain).

### Option C — Record-and-freeze: keep 1.0.0 and the trees as they are; make the routing mapping a versioned, approved artifact

Accept the divergence as a documented interpretation of workflow 1.0.0: the registry keeps station 5 for step 12 (definition of record), the trees keep serving it from g6, and the step→tree executor routing — today re-implemented as code in at least seven places (§3) — is consolidated into **one versioned routing-mapping artifact** (e.g. `routing-map-1.0.0.json` beside the seed, hash-pinned, read by the coordinator's executor mapping and referenced by the generators/setups), with the Gate G OPERATION-binding workaround either folded into that artifact's recorded exceptions or left in place and cited by it.

- **Files touched:** one new mapping artifact (location + loader in the coordinator; generators keep their constants but gain a cross-check test against the artifact — the pattern Gate 02 already uses between coordinator constants and generated workflow JSONs); Gate 03 evidence records the interpretation; no seed, registry, workflow-JSON, or chain changes.
- **Hash consequences:** none to the registry (definition_hash unchanged). The mapping artifact carries its own hash and version, recorded in the Gate 14 evidence lock.
- **Test consequences:** smallest surface — the Gate 03 route test (registry station == serving station == executor mapping) is replaced by a mapping-conformance test (every operation's route resolves through the versioned mapping; the 12 step-12 exceptions are enumerated in the artifact, not discovered). Existing suites stand.
- **Cost (stated plainly):** the special case becomes permanent and official. Every future reader must learn that "station" means two things (registry station for config resolution and reporting; serving station for execution) and that step 12 is where they differ. The ambiguity is documented rather than eliminated — Gate 03's PASS text ("no ambiguous operation routing") is met only in its weaker, documented-interpretation form, which is why this option needs the owner's explicit approval rather than an agent judgement.
- **Gates affected:** 03 (closes by owner-approved interpretation), 04/05 (config-resolution and executor routing both cite the mapping), 10 (per-operation route tests assert against the mapping), 14 (mapping hash in the evidence lock).

## 3. Inventory — every place step→tree/station routing currently lives as code

(Gate 03 task 5 material: converting these into a versioned mapping is implementation, after the owner's decision — not done here.)

| # | Location | What it encodes |
|---|---|---|
| 1 | `video-factory-g2/coordinator/coordinator.py` — `EXECUTOR_WORKER_IDS`, `_EXECUTOR_STEP_RANGES`, `executor_worker_id_for_operation()` (Gate 02 fix, in flight) | Step ranges → tree → executor identity (01–04 g4, 05–08 g5, 09–12 g6, 13–14 g7, 15–16 g8); comment explicitly records step-based-not-registry-based |
| 2 | `video-factory-g2/coordinator/coordinator.py` — `_resolve_config()` | The counter-routing: STATION-scope config probes use the **registry** station from `operation_definitions` |
| 3 | `video-factory-g{4,5,6,7,8}/tools/gen_workflows.py` | Per-tree station workflow files (`station-01`…`station-06`), `EXECUTOR_WORKER_ID` constants, dispatch-receiver → station workflow wiring, header comments stating spans |
| 4 | `video-factory-g{4,5,6,7,8}/tools/setup_env.py` | `STATIONS` tuples for binding seeds — g4 `(1, 2)`, g5 `(3,)`, g6 `(4,)` **plus the Gate G OPERATION-scope 12.12 block**, g7 `(5,)`, g8 `(6,)` |
| 5 | `video-factory-g{4,5,6,7,8}/driver/dispatch.py` | Hardcoded exit-op chains per tree (g6's chain includes 12.12) and a hardcoded `station` payload field per dispatch (g6 sends `station: 4` for every unit, including 12.12) |
| 6 | `video-factory-g9/tools/setup_fullrun.py` | Seeds STATION bindings for all stations 1–6 on the full-run DB (which is why 12.12 resolves differently there than in the g6 scratch DB) and loads all five trees' workflows into one n8n |
| 7 | `video-factory-g1/tools/registry_tool.py` | Registry-side only: `EXPECTED_STATION_COUNTS` + step/station consistency validation of the seed (registry stations, not serving routing) |
| 8 | Tests: `video-factory-g2/tests/test_fix_dh1.py` (asserts coordinator↔generator executor pairing, incl. a comment on the 12.12 nuance); g6/g7 station suites (assert their chains as built) | Routing expectations frozen into assertions on both sides |

Non-routing uses of "station" checked and excluded: the Gate F scheduler derives lanes from resolved-binding modality, not station; the evaluation and worker services key behaviour by operation, not station; the dashboard/API read station from the registry rows for display and config CRUD.

## 4. The question for the owner

The facts in §1 are not in dispute: **the registry seed faithfully implements both original source documents (Step 12 / Edit belongs to Station 5, "Post & Package"); the built trees serve step 12 from Station 4's tree because the agent-prepared, owner-confirmed G6 lock scoped Station 4 as steps 09–12 without flagging the conflict.** No recommendation is made — each option below is a legitimate owner ruling with the costs stated in §2 — but note that Option A is the only one that makes the registry contradict its own source documents.

**How should the step-12 routing divergence be resolved?**

- **Option A** — Supersede the registry: publish workflow 1.1.0 moving step 12 to station 4 (new definition_hash; 1.0.0 untouched; trees unchanged).
- **Option B** — Correct the trees: move step 12's serving to the g7/station-05 workflows (registry and sources untouched; largest build/test surface; requires a coordinated change to Gate 02's executor ranges).
- **Option C** — Record-and-freeze: keep both as they are and adopt a versioned routing-mapping artifact that documents the step-12 exception as the approved interpretation of workflow 1.0.0 (smallest surface; the special case becomes permanent and official).

On the owner's ruling, Gate 03 proceeds to implementation of the chosen option (for A and C) or raises the build lock for the tree correction (for B), followed by the all-192 route test that closes this gate.
