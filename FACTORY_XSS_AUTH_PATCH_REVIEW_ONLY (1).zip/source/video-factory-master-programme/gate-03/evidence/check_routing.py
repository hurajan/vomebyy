#!/usr/bin/env python3
"""Gate 03 Option B routing checker (LOCK_GATE_03B PASS condition).

For every one of the 192 registry operations, derive the serving tree
THREE independent ways and assert they all agree:

  1. by registry:      seed operation's `station` -> STATION_TREES
                       {1,2->g4; 3->g5; 4->g6; 5->g7; 6->g8}
  2. by coordinator:   coordinator.executor_worker_id_for_operation()
                       (the _EXECUTOR_STEP_RANGES table) -> tree
  3. by generator:     SERVED_STEPS parsed from the tree's
                       tools/gen_workflows.py (g6/g7 carry the constant
                       since Gate 03; for the unchanged trees g4/g5/g8
                       the span is taken from the pre-change routing
                       table and cross-checked against (2))

Also asserts: the Gate G OPERATION-scope 12.12 workaround is gone from
g6's setup_env.py, and the registry definition_hash is untouched.

Writes routing_table_post.json (same schema as routing_table.json)
beside this script and exits with the mismatch count.
"""
import ast
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
WS = Path.home() / "workspace"
sys.path.insert(0, str(WS / "video-factory-g2" / "coordinator"))
from coordinator import EXECUTOR_WORKER_IDS, executor_worker_id_for_operation  # noqa: E402

EXPECTED_HASH = "ea4503f516fc4f7940f187f5cd9dac38c57f0d239726cac90e2d0a18a8bc9d73"
STATION_TREES = {1: "g4", 2: "g4", 3: "g5", 4: "g6", 5: "g7", 6: "g8"}
TREE_BY_WORKER = {v: k for k, v in EXECUTOR_WORKER_IDS.items()}
TREES = ("g4", "g5", "g6", "g7", "g8")


def served_steps(tree):
    """Steps a tree's executor serves, from its generator source."""
    gen = (WS / f"video-factory-{tree}" / "tools" / "gen_workflows.py").read_text()
    for node in ast.walk(ast.parse(gen)):
        if isinstance(node, ast.Assign) and any(
                isinstance(t, ast.Name) and t.id == "SERVED_STEPS"
                for t in node.targets):
            return list(ast.literal_eval(node.value))
    return None


def seeded_stations(tree):
    src = (WS / f"video-factory-{tree}" / "tools" / "setup_env.py").read_text()
    for node in ast.walk(ast.parse(src)):
        if isinstance(node, ast.Assign) and any(
                isinstance(t, ast.Name) and t.id == "STATIONS"
                for t in node.targets):
            return list(ast.literal_eval(node.value))
    return []


def main():
    seed = json.loads((WS / "video-factory-g1" / "seed-definitions"
                       / "workflow-1.0.0" / "operations.json").read_text())
    assert seed["definition_hash"] == EXPECTED_HASH, (
        f"registry hash moved: {seed['definition_hash']}")
    step_names = {s["step_id"]: s.get("name") or s.get("title")
                  for s in seed["steps"]}
    pre = {r["operation_id"]: r
           for r in json.loads((HERE / "routing_table.json").read_text())["rows"]}

    spans = {}
    for tree in TREES:
        steps = served_steps(tree)
        if steps is None:  # unchanged tree: span from the pre-change table
            steps = sorted({int(r["step"]) for r in pre.values()
                            if r["serving_tree"] == tree})
        spans[tree] = steps
    gen_tree_by_step = {step: tree for tree, steps in spans.items()
                        for step in steps}
    bindings = {tree: seeded_stations(tree) for tree in TREES}

    g6_setup = (WS / "video-factory-g6" / "tools" / "setup_env.py").read_text()
    assert '"scope": "OPERATION"' not in g6_setup, \
        "g6 setup still seeds the Gate G OPERATION-scope workaround"

    rows, mismatches = [], []
    for op in seed["operations"]:
        oid, step, station = op["operation_id"], int(op["step_id"]), op["station"]
        by_registry = STATION_TREES[station]
        by_coord = TREE_BY_WORKER[executor_worker_id_for_operation(oid)]
        by_gen = gen_tree_by_step[step]
        agree = by_registry == by_coord == by_gen
        if not agree:
            mismatches.append({"operation_id": oid,
                               "by_registry": by_registry,
                               "by_coordinator": by_coord,
                               "by_generator": by_gen})
        rows.append({
            "operation_id": oid,
            "step": op["step_id"],
            "step_name": step_names.get(op["step_id"]),
            "registry_station": station,
            "serving_tree": by_gen,
            "serving_station_workflow": f"station-{station:02d}",
            "serving_station_label": station,
            "executor_worker_id_gate02": EXECUTOR_WORKER_IDS[by_gen],
            "executor_mapping_basis": (
                "coordinator._EXECUTOR_STEP_RANGES (Gate 03 Option B: "
                "step ranges are the registry station spans)"),
            "station_bindings_seeded_by_tree_setup": bindings[by_gen],
            "config_resolution_station_scope": station,
            "operation_scope_binding_workaround": None,
            "executed_as_unit": pre[oid]["executed_as_unit"],
            "divergent": not agree,
            "divergence": (None if agree else
                           f"registry {by_registry} / coordinator {by_coord}"
                           f" / generator {by_gen}"),
        })

    out = {
        "generated_from": {
            "seed": ("video-factory-g1/seed-definitions/workflow-1.0.0/"
                     f"operations.json (definition_hash {EXPECTED_HASH})"),
            "serving_spans": ("SERVED_STEPS parsed from g6/g7 generators "
                              "(Gate 03 Option B); unchanged trees g4/g5/g8 "
                              "from the pre-change routing table"),
            "executor_mapping": ("video-factory-g2/coordinator/coordinator.py "
                                 "EXECUTOR_WORKER_IDS + _EXECUTOR_STEP_RANGES "
                                 "(Gate 03 Option B ranges)"),
            "bindings": ("video-factory-g{4..8}/tools/setup_env.py STATIONS "
                         "tuples; g6 OPERATION 12.12 workaround removed"),
            "config_resolution": ("coordinator._resolve_config probes STATION "
                                  "scope with the REGISTRY station from "
                                  "operation_definitions"),
        },
        "row_count": len(rows),
        "divergent_count": len(mismatches),
        "divergent_operations": [m["operation_id"] for m in mismatches],
        "rows": rows,
    }
    (HERE / "routing_table_post.json").write_text(json.dumps(out, indent=1))
    step12 = [r for r in rows if r["step"] == "12"]
    print(f"rows={len(rows)} mismatches={len(mismatches)}")
    print(f"step-12 serving trees: {sorted({r['serving_tree'] for r in step12})} "
          f"executors: {sorted({r['executor_worker_id_gate02'] for r in step12})}")
    print(f"registry definition_hash intact: {EXPECTED_HASH[:12]}...")
    return len(mismatches)


if __name__ == "__main__":
    sys.exit(main())
