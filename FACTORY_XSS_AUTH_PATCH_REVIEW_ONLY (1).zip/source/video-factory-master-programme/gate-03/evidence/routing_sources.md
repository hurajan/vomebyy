# Gate 03 — Routing source evidence: what station does the ORIGINAL source assign to step 12?

**Question:** The registry seed (workflow 1.0.0, definition_hash `ea4503f5…`) assigns all step-12 operations to station 5; the built trees serve step 12 from the g6 tree whose station workflow is labelled station-04. Which side diverges from the original source documents?

**Answer: the seed matches its sources exactly. The trees diverge.** Both original source documents place Chapter/Step 12 (EDIT) in Station 5.

## Source 1 — `Six_Station_192_Operation_Runtime_Map.md`

- File: `~/workspace/user/files/Six_Station_192_Operation_Runtime_Map.md`, SHA-256 `dfe8065bfd4402fa7169a8654e0ff108cede5f6e3e26bb06baaf1eb67ab4a878`
- Line 128: `### Station 4: Design & Capture — 36 operations`
- Line 129: `**Chapters:** 09, 10, 11.`
- Line 173: `### Station 5: Post & Package — 36 operations`
- Line 174: `**Chapters:** 12, 13, 14.  **Output:** Editorial Timeline; Approved Master; Derivative Package Manifests.`
- Line 175 (heading): `#### Chapter 12: EDIT — Control timing and relationships`
- Line 186: `12.12 — **Operation 12.** Commit Edit Timeline, EDL, stems and narrative QC record.` — printed **inside the Station 5 section**, between the Station 5 heading (line 173) and the Station 6 heading (line 218).
- Full chapter layout in this source (the `**Chapters:**` line under each station heading): S1 = 01, 02 (line 8); S2 = 03, 04 (line 39); S3 = 05, 06, 07, 08 (line 70); S4 = 09, 10, 11 (line 129); S5 = 12, 13, 14 (line 174); S6 = 15, 16 (line 219). Operation counts per station: 24 / 24 / 48 / 36 / 36 / 24 (headings, lines 7, 38, 69, 128, 173, 218).

## Source 2 — `192_documented_atomic_operations.txt` (the seed's direct source; G1 pinned its SHA-256 as the seed provenance)

- File: `~/workspace/user/files/192_documented_atomic_operations.txt`, SHA-256 `0f3f38711c9761a67c161862feacbc72b08e1c172935691431e2f0cbbc8b7a8d`
- Line 114: `Station 4: Design & Capture — 36 operations` (its chapter span ends at Chapter 11)
- Line 155: `Station 5: Post & Package — 36 operations`
- Line 156: `Chapters: 12, 13, 14.`
- Line 157: `Chapter 12: EDIT — Control timing and relationships`
- Line 169: `12.12 — Operation 12. Commit Edit Timeline, EDL, stems and narrative QC record.`

## The registry seed (workflow 1.0.0)

- File: `~/workspace/video-factory-g1/seed-definitions/workflow-1.0.0/operations.json`
- Its own `stations` metadata reads: station 4 = steps `['09','10','11']` (36 operations); station 5 = steps `['12','13','14']` (36 operations).
- Its `steps` metadata: step `12` → station 5, name "Edit"; step `11` → station 4, "Production"; step `13` → station 5, "Master".
- All 12 operations `12.01`–`12.12` carry `station: 5`.
- `video-factory-g1/tools/registry_tool.py` validate() enforces exactly this: station counts must equal `EXPECTED_STATION_COUNTS` (24/24/48/36/36/24) and every operation's station must match its step's station in the seed metadata. The seed is internally consistent and source-faithful.

## The A–Z Implementation Guide (PROPOSED deliverable, the G4–G8 build spec)

- File: `~/workspace/goals/storytelling-studio-v1-1-rebuild/files/AI_Video_Production_Factory_Implementation_Guide_A-Z.md`
- Build-sequence table: `| **G6** Station 4 | Steps 09–11 + voice/visual capabilities …` and `| **G7** Station 5 | Steps 12–14: edit, master render, derivatives, master gate |` — the guide also assigns step 12 to Station 5 / the G7 build.
- §9.3 names Station 5 "Post & Package — Edit, master, derivatives".

## Where the divergence entered: the G6 lock

- `~/workspace/video-factory-g5/G6_LOCK_REQUEST.md` line 1: `# G6 LOCK REQUEST — Station 4 (Steps 09–12) + coordinator gate-claim fix`; line 9: `Station 4: Step 09 (Direction), Step 10 (Shot & Sound Design), Step 11 (Production), Step 12 (Edit).`
- `~/workspace/video-factory-g6/LOCK_G6.md` line 1: `# LOCK G6 — Station 4 (Steps 09–12) + coordinator gate-claim fix — Confirmed by Raj: 2026-10-28`.
- `~/workspace/video-factory-g7/LOCK_G7.md` line 1: `# LOCK G7 — Station 5 (Steps 13–14) + master gate HG4 — Confirmed by Raj: 2026-10-28`.
- Neither lock text acknowledges any conflict with the registry station assignment; the divergence was first recorded as a finding in Gate G's evidence (CHANGED_ASSERTIONS #17) and carried into Gate H and Gate 01 finding G01-D04. The programme controller (STATE.md, Gate 03 row) records: "12.12 has NO existing approval → decision package route expected". Whether the owner's G6 lock confirmation constitutes an approval of the station redefinition is itself part of the owner's decision (see DECISION_PACKAGE_12_12.md, framing note).

## Cosmetic variance (not a routing divergence)

The source documents name Station 4 "Design & Capture"; the seed's stations metadata and the A–Z Guide name it "Direction & Capture". Same chapters (09–11), same operation count (36). Recorded for completeness; no routing effect.
