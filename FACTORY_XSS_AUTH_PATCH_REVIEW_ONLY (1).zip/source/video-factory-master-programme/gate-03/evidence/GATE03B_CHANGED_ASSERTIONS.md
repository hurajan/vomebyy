# GATE 03 Option B — Changed Assertions (Phase 2 build)

Every pre-existing test assertion changed by the step-12 tree
correction, with reason and intent preservation. New tests are marked
NEW; everything not listed is byte-unchanged.

## video-factory-g2/tests/test_fix_dh1.py (Gate 02 cross-check — updated under LOCK_GATE_03B item 3)

1. **Module docstring + STEP_RANGES**: step ranges changed from
   g6 `range(9, 13)` / g7 `range(13, 15)` to g6 `range(9, 12)` /
   g7 `range(12, 15)`; the "12.12 maps by STEP to G6, not by registry
   station" framing replaced by the Option B framing. *Intent
   preserved*: the constants still enumerate exactly the steps each
   tree's generated executor must pair with.
2. **TestSchedulerPreStaging case** `("12.12", "qa", …)`: expected
   prestage identity `n8n-executor-g6` → `n8n-executor-g7`. *Intent
   preserved*: scheduler prestages under the identity of the executor
   that actually serves the operation — now the g7 executor.
3. **TestExecutorIdentityMapping.test_step_boundaries**: expected map
   `12: "g6"` → `12: "g7"` (11: "g6" added); the trailing "D-H1 nuance"
   assertion (`12.12 → n8n-executor-g6`) replaced by the agreement
   assertion (`12.12 → n8n-executor-g7`, step routing == station
   routing). *Intent preserved*: boundary steps resolve to the tree
   that serves them; the special case it documented no longer exists.
4. **NEW — test_step_and_station_routing_agree_all_operations**: for
   all 192 seed operations, `executor_worker_id_for_operation(op)`
   must equal the identity of the tree its registry station assigns
   (stations 1,2→g4; 3→g5; 4→g6; 5→g7; 6→g8). This is the Gate 03 PASS
   condition in executable form. G2 suite count 68 → 69.

## video-factory-g6/tests/test_g6_station.py (3 tests, count unchanged)

5. **test_chain_references_and_rule_of_six → test_chain_references**:
   the 12.12 unit is no longer planned in this suite and the
   edit_timeline / Rule-of-Six assertions were removed — they are
   re-homed verbatim in the G7 suite (item 8), where 12.12 now
   executes. *Intent preserved*: the same content properties are
   checked on the same produced artifact, one tree over.
6. **Chain artifact set**: `edit_timeline` removed from the required
   CURRENT set; ADDED `assertNotIn("edit_timeline", cur)` — Station 4
   must produce no step-12 output (ruling point 8 in suite form).
7. **Budget**: `spent_cents == 4 * 90` → `3 * 90`. *Intent preserved*:
   per-unit measured actual (90) × units this tree executes; the
   fourth unit's spend is asserted in the G7 suite (item 9).

## video-factory-g7/tests/test_g7_station.py (2 tests, count unchanged)

8. **NEW helper — Base.drive_edit**: plans 12.12 in this tree, drives
   it to ACCEPTED, asserts the accepting attempt's `worker_id` is
   `n8n-executor-g7` (DB read), and returns the produced
   edit_timeline. The Rule-of-Six assertions from the old G6 chain
   test (dimension weights {51,23,10,7,5,4}, sum 100, recomputed
   weighted_total) run on it in TestStation5, plus the segment
   shot_ref set equality against the suite's SHOTS.
9. **TestStation5 chain**: 13.12 now consumes the REAL produced
   edit_timeline (previously a registered fixture copy) — master
   reference assertions unchanged in form, now checked against a
   genuine upstream output. Budget `3 * 90` → `4 * 90` (one more unit
   executed by this tree). *Intent preserved throughout.*
10. **Planning-pattern correction (disclosed failure)**: the first
    version of drive_edit planned 12.12 with
    `inputs=[registry artifact]` ("11.12 output registered as
    input"). The unit landed in REPAIR_REQUIRED and the suite FAILED
    (evidence: gate-03/evidence/logs/g7.log, "unit stuck at
    REPAIR_REQUIRED"; the evaluation record shows continuity FAIL —
    "output does not declare all planned inputs"). The step-12
    deliverable declares shot references, not artifact references,
    and the Gate E continuity layer correctly requires outputs to
    declare their planned inputs; every previously verified 12.12
    execution (G6 suite, G9 full run) planned it with the upstream
    dependency and NO input_artifact_ids. drive_edit was corrected to
    that pattern: the asset_registry fixture stays registered in the
    production as 11.12's exit stand-in and remains 13.12's declared
    input; the registry id is still passed on the dispatch payload
    channel (inputs_by_unit). Re-run: 2/2 OK (logs/g7_rerun.log).
    The same correction was applied to the Gate 03 negatives harness
    (unit B) and to the G9 full-run plan (item 11), which the first
    edit had also given a declared registry input.

## video-factory-g9/tests/test_g9_fullrun.py (9 tests, count unchanged)

11. **Station-4 block split**: the chain loop now plans only
    09.12 → 10.12 → 11.12 under `drive(4, …)`; 12.12 is planned after
    (depends on the 11.12 unit, no input_artifact_ids — its original
    planning shape) and driven via `drive(5, …)` (the G7 tree's
    driver/webhook). All downstream assertions (timeline/registry
    refs, gates, 18 ACCEPTED, 18 × 90 budget) are unchanged and pass:
    the full run still lands 18 ACCEPTED / 1620¢, with 12.12's spend
    now settled through the Station 5 tree.

## Not changed (read-only, verified)

Registry seed + contracts (definition_hash asserted
`ea4503f5…` by the routing checker and the G1 suite), migrations,
worker-service payload builders (12.12's builder is operation-keyed),
Gate 02 adoption code, g6/g7 drivers (operation-generic; spans are
enforced in the generated executors), g7 setup_env.py (the STATION-5
binding covers 12.12 through normal resolution — nothing to remove),
g9 setup_fullrun.py (already seeds STATION bindings 1–6; no
step-12 OPERATION-scope special case existed there).
