# PHASE 3 VERIFIER REPORT — Gate 03 (Option B) + Gate 02 final-state + Gate 01 spot-checks + Gate 00 closure

**Verifier**: independent Phase 3 pass, 2026-10-29. Read-only on product trees; all live work on the verifier's own scratch DB (`p3_verify_scratch`) or the suites' own scratch DBs; everything run SERIALLY on an exclusive environment. Logs: `gate-03/evidence/logs/verify/` (suite logs, probe logs, T02-H console, registry validate log). Probe scripts retained at `/tmp/verify03/` (`routing_check.py`, `probe_1c_webhook.py`, `probe_a_adopt.py`, `scope_diff.py`, `hygiene*.py`).

## Verdicts (summary)

| Question | Verdict |
|---|---|
| Gate 03 mandatory PASS condition | **MET** |
| Gate 02 verified on final (post-B) code | **VERIFIED** |
| Gate 01 audit spot-checks | **STAND** (one MINOR documentation staleness, §3d) |
| Gate 00 closure runs | **CLEAN** (g4 2/2, g6 3/3, g7 2/2, g9 9/9) |

Defects found by this pass: **one MINOR** (documentation only, §3d). No product defects. The previously registered Gate 01 finding D07 is **confirmed live** and remains a Gate 05 input (§3b) — it is not a defect of the Gate 02/03 work.

---

## 1. Gate 03 PASS condition — CONFIRMED

### 1(a) Routing: independent derivation vs three live sources — 192/192, 0 mismatches

Expectation rebuilt from the registry seed alone (`operations.json`: per-operation `station`, cross-checked against the seed's own stations table — internally consistent on all 192 rows), mapped station→tree by the approved architecture (S1/S2→g4, S3→g5, S4→g6, S5→g7, S6→g8). Compared against:

1. **Coordinator step→identity table** (`g2/coordinator/coordinator.py`: `EXECUTOR_WORKER_IDS` + `_EXECUTOR_STEP_RANGES` = (1–4,g4),(5–8,g5),(9–11,g6),(12–14,g7),(15–16,g8)): **agrees with the registry-station expectation on all 192 operations, 0 mismatches.**
2. **Tree generators**: identity constants `n8n-executor-g4…g8`, one per tree; `SERVED_STEPS` on the corrected seam — **g6 = (9,10,11), g7 = (12,13,14)** — exactly the registry station spans; the generated `unit-executor.json` files carry the same guard values and the same single identity literal per tree. (g4/g5/g8 executors carry no step guard — their spans were never contested; their routing is fixed by their station workflows and setup bindings, below.)
3. **Setup station bindings**: `STATIONS` seeded per tree — g4 (1,2), g5 (3), g6 (4), g7 (5), g8 (6) — matching registry spans; config resolution keys STATION scope by registry station, so every step-12 operation resolves the Station-5 binding seeded by the g7 setup.

**Step-12 rows (all 12 operations 12.01–12.12) → g7 / `n8n-executor-g7` in every source.**

### 1(b) Registry integrity — CONFIRMED
`registry_tool.py validate` → **PASS**, `definition_hash ea4503f516fc4f7940f187f5cd9dac38c57f0d239726cac90e2d0a18a8bc9d73`, source_sha256 `0f3f3871…`, no errors/warnings. Seed file SHA-256 `8bc567a6…` is **identical to the Gate 00 manifest entry** (workflow 1.0.0 and its definitions untouched, ruling point 1).

### 1(c) Ruling point 8 negatives — CONFIRMED (verifier's own runs)
On the live G9 stack (own production `feb304e0…`, unit `76517032…`, log `probe_1c_webhook.log`):
- Dispatch of the READY 12.12 unit to the **G6 webhook** → after the execution window: **0 attempts, 0 artifacts, unit still READY** — the Station 4 worker cannot execute a Chapter 12 operation.
- The same unit dispatched to the **G7 webhook** → **ACCEPTED**, exactly **1 attempt under `n8n-executor-g7`**, one CURRENT `edit_timeline`.

On the verifier's own scratch DB + API instance (log `probe_a_adopt.log`):
- `scheduler_claim` prestaged the 12.12 unit under **`n8n-executor-g7`** (single attempt, scheduler as claim actor).
- Adopt as `n8n-executor-g6` → **409 `adoption refused: identity_mismatch`**, with a committed `adopt_refused` audit event (payload reason `identity_mismatch`).
- Adopt as `n8n-executor-g7` → **200**, fresh adoption, fencing token + resolved config returned.

### 1(d) G9 full-run facts — CONFIRMED from the persisted DB
Full-run production `d65ee868…` ("G9 full run") in `g9_fullrun_scratch` after the verifier's own fresh suite run: **18 units, 18 ACCEPTED; ledger CHARGE total exactly 1620¢; max attempts per unit = 1**; boundary attempts — 11.12 under `n8n-executor-g6`, **12.12 under `n8n-executor-g7`**, 13.12 under `n8n-executor-g7`.

## 2. Gate 02 final-state — VERIFIED on post-B code

- **T02-H re-run** (harness `fix_dh1_t09.py`, console in `logs/verify/t02h_console.log`): **PASS 12/12** — unattended Station-3 chain ACCEPTED; exactly one attempt per unit under `n8n-executor-g5`; `resumed=true` ×4 (the executors adopted the scheduler-prestaged claims — D-H1 stays fixed under the final routing code); claim audit actor = scheduler for all 4 units; budget settled exactly once (4 × 90 = 360¢, nothing held); negatives N1 (wrong-identity claim not adopted) and N2 (started attempt not adopted) hold.
- **T02-B independently reproduced** (verifier's own concurrent probe, `probe_a_adopt.log`): two parallel adopts with different idempotency keys → **one 200 + one 409**; winner-key replay → **200, `fresh=false`**; loser-key replay → **409**; exactly one adopted attempt row; completion with the adopted credentials → **exactly one FINALIZED evidence row and one CHARGE (90¢)** — single-winner, idempotent, settle-once all hold on final code.
- **Fencing hygiene**: `GET /units/{id}/attempts` on a real prestaged unit contains **no `fencing_token` key anywhere** in the response; the adopt response is the only fencing disclosure and is identity-gated (g6 refused, g7 issued) — the programme guardrail (no broadened fencing visibility) holds after the alignment revert.
- **V-H1 closure**: in all five generated `unit-executor.json` files, every `worker_id` (Resume decision, Prepare adoption, Claim unit, submit-candidate) is the tree's **identity literal**; no `worker_id` is derived from any trigger/`$json` field; no `n8n-station*` string exists in any executor; exactly **one identity literal per tree**.

## 3. Gate 01 spot-checks — STAND

- **(a) D02 CONFIRMED**: `capability_versions` / `capability_execution_plans` have **zero references** in the runtime trees (coordinator, API server, worker service, evaluation service). The only writer/counter is the G1 registry loader (`registry_tool.py`). No test files reference them either. The capability layer remains decorative at runtime, exactly as the audit recorded (remediation owned by Gate 04).
- **(b) D07 CONFIRMED — source + live.** Source: `video-factory-g3/api/server.py:427–431` — `POST /units/{id}/events` allows roles `OPERATOR, SCHEDULER, WORKER` and passes the body's `event` string unchecked to `Coordinator.event()`; the transition table (`coordinator.py:27–28`) includes `(VALIDATING, validation_needs_human) → AWAITING_HUMAN` and `(AWAITING_HUMAN, human_approved) → ACCEPTED`. Live (verifier's throwaway DB only): a **WORKER** role token fired `validation_needs_human` (200 → AWAITING_HUMAN) and then **`human_approved` (200 → ACCEPTED)** on a unit it had executed. A non-operator role can accept a unit through this endpoint. Recorded as a **Gate 05 input** (severity HIGH per the Gate 01 register); no shared state was touched.
- **(c) Classification integrity CONFIRMED**: `operation_classification.json` has **192 rows**; counts block = genuine L2 **19**, `DISPATCHABLE_GENERIC_ONLY` **173** (each generic row carries the owner-correction `readiness_label`: "technically dispatchable; lacking operation-specific implementation evidence…"), L3 **20**, L4 **0**; the L3 set is **exactly equal** to `executed_union.json`'s 20 operations.
- **(d) MINOR documentation defect (new, this pass)**: the classification JSON's `serving_tree` column still records **g6 for all 12 step-12 rows** (tree totals g6 48 / g7 24; post-B truth is g6 36 / g7 36). The audit predates Option B; the terminology correction was applied to this file but the routing column was not re-derived. Product routing is correct everywhere (§1a) — this is staleness in the Gate 01 evidence artifact only. **Severity MINOR.** Remediation: amend the register/classification `serving_tree` for step-12 rows to g7 with a dated amendment note (the audit's historical narrative may stand).

## 4. Gate 00 closure runs — CLEAN

Run serially by this verifier, counts read from the logs in `logs/verify/`:

| Suite | Result |
|---|---|
| g4 | **2/2 OK** (rc=0) |
| g6 | **3/3 OK** (rc=0) — with step 12 removed; asserts no `edit_timeline` is produced by Station 4 |
| g7 | **2/2 OK** (rc=0) — with 12.12 executed in-tree under `n8n-executor-g7` |
| g9 | **9/9 OK** (rc=0) — full run re-homed; facts in §1d |

The four suites Gate 00 never got cleanly are now reproduced green on the final code; Gate 00's completion step is satisfied.

## 5. Scope — CONFIRMED with two explained bookkeeping notes

Manifest diff vs `gate-00/evidence/source_manifest.json` (1,535 files): 51 files changed since capture, **none missing**. Classification of every change:

- **21** inside the Phase 2 ownership set (g6/g7 trees, coordinator + `test_fix_dh1.py`, g9).
- **21** inside the Gate 02 seam (g3 API + contract, g4/g5/g8 generators + regenerated workflows) — the pre-B fix work the seam snapshot anticipated.
- **9** outside both, **all explained by record, none unexplained**:
  - `video-factory-g2/tools/setup_db.py` and `video-factory-g3/tests/test_api_contract.py` — Gate 02 adoption work documented in the FIX_DH1 addendum (migration 014 chaining; the `/adopt` contract tests). The Gate 00 seam list undercounted these two; the changes themselves are in-scope and documented. *(Bookkeeping note, not a violation.)*
  - `video-factory-g4|g5|g8/driver/dispatch-state.json` — mutable driver state files, rewritten by any suite run.
  - `controller/STATE.md` — the controller's own register (controller-owned).
  - `gate-h/evidence/FIX_DH1_CHANGED_ASSERTIONS.md`, `logs/fix_dh1_runner.log`, `results/fix-dh1/t9_rerun.json` — Gate 02's own build-record/evidence files written during its Phase 1 window.

- **Migrations**: runtime chain max = **014** (`014_attempt_adoption.sql`, the owner-locked Gate 02 migration); registry chain = 001; **no migration files beyond 014** and none chained in either setup script.
- **Gate 02 evidence integrity**: all `t02*.json` mtimes fall in the Phase 1 window (03:36:57–04:00:36 UTC, 2026-10-29) and **precede Phase 2's first product edit** (g6 generator, 04:04:19 UTC) — Phase 2 did not rewrite Gate 02 evidence. (The one later write to `t9_rerun.json` is this verifier's own authorized T02-H re-run in §2; its pre-rerun SHA-256 `1f280a18…` is recorded in the working notes, and the rerun also returned PASS.)

## Defect register (this pass)

| ID | Severity | Finding | Owner |
|---|---|---|---|
| P3-V1 | MINOR | Gate 01 classification JSON `serving_tree` stale for step-12 rows (says g6; truth g7) — documentation only | Gate 01 register amendment |
| (carried) D07 | HIGH (per Gate 01 register) | Events endpoint lets WORKER/SCHEDULER fire any transition incl. `human_approved`; confirmed source + live by this pass | Gate 05 |

**Gate 03's mandatory PASS condition is met; Gate 02's protections are verified intact on the final code.**
