#!/usr/bin/env python3
"""Gate 03 Option B — builder negatives (LOCK_GATE_03B ruling point 8).

Run against the G9 full-run environment (video-factory-g9
tools/setup_fullrun.py): one DB, one n8n holding every tree's
workflows, STATION bindings seeded for stations 1-6.

  (a) scheduler_claim on a READY 12.12 unit prestages it under
      n8n-executor-g7 (attempt + lease rows asserted in the DB).
  (c) adopting that prestaged claim through the API with the g6
      identity is refused (409, identity_mismatch evidence); with the
      g7 identity it succeeds (200).
  (b) a second READY 12.12 unit dispatched to the G6 dispatch webhook
      produces NO execution — no attempt, no worker call, no artifact,
      unit still READY — and is afterwards executed to ACCEPTED via
      the G7 driver (routable via g7).

Writes negatives_g03b.json beside this script; exit code = failures.
"""
import hashlib
import json
import sys
import time
import urllib.request
import urllib.error
from pathlib import Path

import psycopg
from psycopg.rows import dict_row

HERE = Path(__file__).resolve().parent
WS = Path.home() / "workspace"
sys.path.insert(0, str(WS / "video-factory-g2" / "coordinator"))
sys.path.insert(0, str(WS / "video-factory-g9" / "tests"))
from coordinator import Coordinator  # noqa: E402
from g9_common import DRIVERS, call, make_production, plan, unit_state  # noqa: E402

API = "http://127.0.0.1:8730"
DSN = ("host=127.0.0.1 dbname=g9_fullrun_scratch "
       "user=factory password=factory_dev_local")
SHOTS = ["SH1", "SH2", "SH3"]
REGISTRY = {"kind": "asset_registry", "assets": [
    {"id": f"A-{sh}", "shot_ref": sh, "payload": f"g6-asset-payload-{sh}",
     "sha256": hashlib.sha256(f"g6-asset-payload-{sh}".encode()).hexdigest()}
    for sh in SHOTS]}
RESULTS = {}


def db(sql, args=()):
    with psycopg.connect(DSN, row_factory=dict_row, autocommit=True) as conn:
        return conn.execute(sql, args).fetchall()


def adopt(unit_id, attempt_id, worker_id, key):
    req = urllib.request.Request(
        API + f"/units/{unit_id}/adopt", method="POST",
        data=json.dumps({"worker_id": worker_id, "attempt_id": attempt_id,
                         "idempotency_key": key}).encode(),
        headers={"Content-Type": "application/json", "X-Role": "WORKER",
                 "X-Role-Token": "dev-worker-token"})
    try:
        with urllib.request.urlopen(req, timeout=15) as r:
            return r.status, json.loads(r.read() or b"{}")
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read() or b"{}")


def post_webhook(url, payload):
    req = urllib.request.Request(url, method="POST",
                                 data=json.dumps(payload).encode(),
                                 headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=15) as r:
        return r.status


def check(name, ok, detail=""):
    RESULTS[name] = {"ok": bool(ok), "detail": str(detail)}
    print(f"{'PASS' if ok else 'FAIL'} {name}: {detail}")


def main():
    pid, run = make_production("Gate 03 Option B negatives")
    content = json.dumps(REGISTRY, sort_keys=True)
    reg = call("POST", f"/productions/{pid}/artifacts",
               {"artifact_type": "asset_registry", "content": content,
                "storage_uri": "mock-store://gate03-negatives-registry"})
    reg_id = reg["artifact_id"]

    # ---------- (a) scheduler prestages 12.12 under the g7 identity
    uid_a = plan(pid, run, "12.12", key="neg-a", inputs=[reg_id])
    sched = Coordinator(DSN, actor="scheduler-service")
    claimed = sched.scheduler_claim()
    sched.close()
    check("a_claimed_by_scheduler", uid_a in [c["unit_id"] for c in claimed],
          f"claimed={[c['unit_id'] for c in claimed]}")
    att = db("SELECT worker_id FROM action_attempts WHERE unit_id=%s"
             " ORDER BY attempt_no DESC LIMIT 1", (uid_a,))
    lease = db("SELECT worker_id FROM worker_leases WHERE unit_id=%s",
               (uid_a,))
    check("a_prestaged_g7_identity",
          att and att[0]["worker_id"] == "n8n-executor-g7"
          and lease and lease[0]["worker_id"] == "n8n-executor-g7",
          f"attempt={att and att[0]['worker_id']} lease={lease and lease[0]['worker_id']}")
    check("a_unit_claimed", unit_state(pid, uid_a)["state"] == "CLAIMED",
          unit_state(pid, uid_a)["state"])

    # ---------- (c) adopt: g6 identity refused, g7 identity succeeds
    attempts = call("GET", f"/units/{uid_a}/attempts")["attempts"]
    attempt_id = attempts[-1]["attempt_id"]
    status, body = adopt(uid_a, attempt_id, "n8n-executor-g6", "gate03-neg-c1")
    refused = db("SELECT payload FROM audit_events WHERE unit_id=%s"
                 " AND event_type='adopt_refused'", (uid_a,))
    payload_txt = json.dumps([r["payload"] for r in refused])
    check("c_g6_adopt_refused", status == 409 and "identity_mismatch" in payload_txt,
          f"status={status} refusals={payload_txt[:200]}")
    status, body = adopt(uid_a, attempt_id, "n8n-executor-g7", "gate03-neg-c2")
    check("c_g7_adopt_succeeds", status == 200 and body.get("adopted") is True,
          f"status={status} body={str(body)[:160]}")

    # ---------- (b) dispatch of a READY 12.12 to the g6 webhook: no execution
    # Planned with no input_artifact_ids, exactly as the station suites
    # plan 12.12 (its deliverable declares no artifact references, so a
    # declared planned input would fail evaluation continuity).
    uid_b = plan(pid, run, "12.12", key="neg-b")
    post_webhook("http://127.0.0.1:5678/webhook/dispatch-g6",
                 {"production_id": pid, "unit_id": uid_b,
                  "operation_id": "12.12", "station": 4,
                  "input_artifact_ids": [reg_id],
                  "idempotency_key": f"dispatch:{uid_b}:g6neg"})
    time.sleep(25)
    att_b = db("SELECT count(*) AS n FROM action_attempts WHERE unit_id=%s",
               (uid_b,))
    state_b = unit_state(pid, uid_b)["state"]
    check("b_g6_dispatch_no_attempt", att_b[0]["n"] == 0,
          f"attempts={att_b[0]['n']}")
    check("b_g6_dispatch_unit_untouched", state_b == "READY", f"state={state_b}")

    # ... and the same unit then executes via g7 to ACCEPTED
    deadline = time.time() + 240
    while time.time() < deadline:
        DRIVERS[5].run_once(pid, inputs_by_unit={uid_b: [reg_id]})
        if unit_state(pid, uid_b)["state"] == "ACCEPTED":
            break
        time.sleep(2)
    att_b = db("SELECT worker_id FROM action_attempts WHERE unit_id=%s"
               " ORDER BY attempt_no DESC LIMIT 1", (uid_b,))
    check("b_routable_via_g7",
          unit_state(pid, uid_b)["state"] == "ACCEPTED"
          and att_b and att_b[0]["worker_id"] == "n8n-executor-g7",
          f"state={unit_state(pid, uid_b)['state']} "
          f"worker={att_b and att_b[0]['worker_id']}")

    failures = sum(1 for r in RESULTS.values() if not r["ok"])
    (HERE / "negatives_g03b.json").write_text(json.dumps(
        {"production_id": pid, "results": RESULTS,
         "failures": failures}, indent=1))
    print(f"negatives complete: {len(RESULTS) - failures}/{len(RESULTS)} pass")
    return failures


if __name__ == "__main__":
    sys.exit(main())
