# MM-10 FIX CYCLE — F-MM10-01, F-MM10-02, B6 cascade readiness

Fix-builder record for the three defects the MM-10 battery surfaced
(findings_media_and_reference.md + B6 evidence). Battery DB
mm10_scratch and its master production are preserved evidence: they
are mutated only through the factory's own repair mechanisms in the
re-run step. Serial execution, port hygiene + DSN assertion (OBS-1)
throughout. Results JSONs in evidence/results/fix/.

## FIX 1 — F-MM10-02: references_resolve treats computed digests as artifact references

### Evidence base (from the preserved battery DB, before the fix)

All 46 sha values that failed `references_resolve` with
`sha_not_current` across the 13 blocked operations were checked
against every artifact row in mm10_scratch (152 rows, all states):
**zero** of them is any artifact's recorded sha256. The failing
paths are exactly four digest positions:

- `derived.records.attest.attestation_sha256` (14) — a digest the
  hash_attest action COMPUTED over its inputs (`_sha_text` of the
  joined input shas); it is no artifact's sha by construction.
- `derived.records.attest.input_sha256[i]` (22) — the attest list
  mixes input artifact shas (which resolved fine and never appear
  in the failures) with `_content_sha()` digests of the inputs'
  parsed content (which can never be an artifact's recorded sha:
  the recorded sha covers the artifact's full bytes, not a
  re-serialized content projection).
- `derived.content.analyze.analyses[i].sha256` (6) — analyze_content
  records the CONTENT sha of each analyzed input beside its
  artifact_id/artifact_type; the old extractor's "manifest-like"
  rule (bare `sha256` counts when the object carries
  artifact_id+artifact_type) misread it as an artifact reference.
- `derived.media_generate.media_output.storage_uri` (4) — the sha
  embedded in a `store://objects/<sha>` URI naming the media
  OBJECT in the Gate D store, extracted from any string anywhere.

### The rule as implemented (gate-e evaluation_service/refs.py)

A string counts as an artifact reference **only in a reference
position**, decided by key/position, never by value shape:

- **Artifact ids** (unchanged): UUID strings under `artifact_id`,
  `*_artifact_id`, `*_ref`, `*_refs` keys (and list elements under
  them).
- **Artifact shas** — a 64-hex string only when:
  1. it is the value (or a list element) of an ID key or of
     `depends_on` — a reference field carrying a sha instead of a
     UUID; or a `store://`/`mock-store://` URI in such a field
     contributes its embedded sha; or
  2. it is the value of a **paired pin field**: a `<stem>_sha256`
     (or `<stem>_sha`) key whose containing object also carries
     `<stem>_ref` or `<stem>_artifact_id` with a UUID value — the
     13.12 master_package pattern (`timeline_ref` +
     `timeline_sha256`, `registry_sha256`), the one place factory
     payloads pin a referenced artifact by sha.
- **Never references** (digest/data positions): bare `sha256` keys
  in any object (including manifest-shaped analysis entries);
  `*_sha256` / `*_sha` / `*_hash` / `*_hashes` fields without the
  pair (`attestation_sha256`, `input_sha256`, `source_sha256`,
  `content_sha256`, `asset_hashes`); sha strings under any other
  key; store-object URIs in data fields (`media_output.storage_uri`
  — those bytes are fetched and probe-validated by the
  media-technical check, a stronger check than artifact currency).
- Manifest entries (`output_artifacts` / `input_artifacts`) keep
  the existing treatment: an entry's own `artifact_id`/`sha256` are
  manifest data, skipped; other keys inside an entry are walked
  under the same position rules.
- `null_refs` counting follows the same positions (None under an ID
  key, `depends_on`, or a paired pin field).

The technical layer's resolution semantics are unchanged: extracted
id references must exist, be CURRENT, and belong to the production;
extracted sha references must be the recorded sha of a CURRENT
artifact of the production (the artifact's own sha exempted as a
self-reference). `sha256_match` (MM-07 N4) is a different check and
is untouched; the continuity layer consumes only the id arm, whose
extraction is unchanged.

### Changed pre-existing assertion (recorded per gate discipline)

- gate-e `test_evaluation_service.py::test_dangling_sha_blocked`:
  the dangling sha's POSITION changes from `source_sha256` (a digest
  field under the new rule — the real factory shape emits it only
  as a digest list in compose_document) to a paired pin
  (`timeline_ref` = a real input artifact's id, `timeline_sha256` =
  the dangling value). The property asserted is identical: a sha in
  a reference position that names no CURRENT artifact FAILs
  references_resolve with reason `sha_not_current` and the unit
  BLOCKs.
- gate-e `test_evaluation_service.py::test_worker_verdict_is_advisory_only`:
  same position change for its blocking defect (the property under
  test — a worker PASS verdict changes nothing — is untouched).
- gate-e golden SEED case `seed-03-technical-dangling-sha.json`:
  the dangling sha moves from `source_sha256` in the manifest entry
  to a paired pin (`timeline_ref` + `timeline_sha256` = f*64)
  against a newly declared `extra_current_artifacts` row (the
  timeline artifact, sha d*64), and `planned_input_ids` names that
  artifact so the continuity expectation (PASS) still isolates the
  technical layer. The case's expectations are unchanged
  (deterministic FAIL / schema PASS / continuity PASS) and it still
  tests exactly what its name says: a dangling sha reference.
  Provenance stays SEED; the arming counts (7 SEED / 0 EXPERT) are
  unchanged.
No other pre-existing assertion was changed by FIX 1. The full
evaluation suite passes 57/57 (46 pre-existing + 11 new).

### Tests (FIX 1)

- New gate-e suite `tests/test_mm10_refs.py`: extraction-level cases
  for every digest position above (zero shas extracted), paired-pin
  extraction, ref-field sha extraction; layer-level cases on
  synthetic contexts (test_mm07_checks pattern): digest-in-data-field
  PASSes references_resolve; a dangling UUID in a ref field FAILs
  naming the value (`artifact_not_found`); a CURRENT artifact's sha
  in a paired pin PASSes; the same pin with a wrong sha FAILs
  `sha_not_current`.
- MM-07 negative battery subset N1/N2/N4/N10/N11 re-run on the
  battery's own harness (mm07_eval_scratch, its own stack).
- Full evaluation suite re-run.

## FIX 2 — F-MM10-01: media data plane

Root cause: media actions resolved input media by artifact sha
(`_media_inputs` fetched store bytes by the input artifact's
recorded sha256 and probed them). A worker-produced artifact's
recorded sha covers its composed JSON bytes; the media bytes live
in the store under their own sha, which appeared only inside the
producing action's output, nested at an unstable position
(`derived.<action_key>.media_output`) of the producer's content.

Fix (worker service only; no coordinator schema change):
- **Stable field `media_ref`** — compose_document hoists the LAST
  media-bearing action output's store reference
  {sha256, storage_uri, size, source_action} into the composed
  document's top level. All 14 media-bearing plans end in
  engine.compose_document (verified programmatically over
  plans.json), so every media-bearing plan completion records it.
- **Resolver** (`_media_inputs`): per input ref, (1) the artifact's
  own bytes probe as media -> direct; else (2) declarations from
  the artifact's payload — searched in the ref's resolved content,
  then the artifact bytes (raw doc, then envelope entry content) —
  at positions media_ref, top-level media_output,
  derived.*.media_output (the pre-fix position, so the preserved
  battery DB's artifacts resolve), and store_reference (a doc whose
  storage_uri names its sha256 — the flite adapter's shape); the
  first declared sha whose store bytes probe as media wins.
  ffmpeg_process/ffmpeg_render consume the resolved bytes and
  record media_sha256 + resolved_via in their media_input evidence.
  The actions' named failure ("no input artifact resolves to media
  bytes in the artifact store") is unchanged when nothing resolves.
- Tests: new suite test_mm10_media_chain.py (7 tests: hoist on
  generate + process completions; generate->process and
  generate->render chains via media_ref with ffprobe-valid outputs;
  legacy derived position; direct media; named failure for a text
  artifact). MM-06 media subset 31/31; full worker suite 105/105.

## FIX 3 — B6 cascade readiness

Root cause: `Coordinator.invalidate_artifact` planned its
replacement units inside its transaction but never recomputed
readiness; replacements sat PENDING until an unrelated completion
triggered `recompute_readiness` (in the battery, the driver had to
call it by hand through the service surface).

Fix (coordinator library, mirroring the existing pattern):
`invalidate_artifact` now captures its result, and after the
transaction commits calls `self.recompute_readiness(production_id)`
before returning — the same post-commit placement `plan_unit` uses.
Test: TestCascade.test_cascade_replacements_ready_and_claimable
(B6 in miniature: supersede an input; the replacement is READY and
claimable immediately, with no manual recompute in the test).
One pre-existing assertion adjusted for test hygiene and recorded:
test_selective_invalidation_recursive's supersedes-row count was
DB-wide, silently assuming no sibling test cascades; it is now
scoped to the test's own production (same property — this cascade
created exactly the replacements it reported). Coordinator module
14/14 OK.

## RE-RUN on the preserved battery DB

Driver: harness/fix_rerun_driver.py (the battery driver's own
machinery; checkpoints redirected into evidence/results/fix/).
Stack restarted against mm10_scratch with the battery's env (OBS-1
hygiene: ports killed, DSN asserted by behavior — the master
production reads back through the API). Repairs ran through the
factory's own surfaces only: one fresh PARTIAL_REPAIR run
(aab67123-e566-4a61-bdda-75046b9543b7), units planned via the API
with inputs = CURRENT versions of the artifact types the original
units consumed, media consumers additionally fed the repaired
media producers' outputs in step order; driven by SchedulerService
prestage + station dispatch + service cycles; 5 AWAITING_HUMAN
units approved via the API; no gates needed deciding; no raw SQL
state edits.

Per-op outcomes: evidence/results/fix/rerun_repairs.json.
Summary: **20 of 23 repaired to ACCEPTED** (all 13 F-MM10-02 ops;
media ops 12.07, 12.08, 13.03, 13.05, 13.08, 14.07, 14.08 through
the repaired media chain). **3 remain BLOCKED_EXECUTION on
evidence-named declared-input absences, not on either defect** —
the media plane now resolves; the transforms refuse to invent
edits:
- 12.05 — "cuts: inputs declare no cut segments (segments[] with
  start_s/end_s) — the tool applies declared edits, it does not
  invent them" (verified: no CURRENT artifact in the production
  declares numeric segments);
- 12.06 — "sync: no audio offset declared (spec.audio_offset_ms
  or an input's audio_offset_ms/sync_offset_ms) — the tool applies
  a declared offset, it does not guess one";
- 14.06 — "reedit: inputs declare no cut segments …" (same absence).
These stay blocked honestly; unblocking them needs an upstream
artifact that declares edit segments/an offset (a content decision,
not a repair action).

Updated 192-row classification (harness/fix_classification.py —
sweep.py's logic replicated exactly; battery file untouched;
evidence/results/fix/classification_after_fix.json):

| class | before | after |
|---|---|---|
| EXECUTED_REAL | 59 | 75 |
| EXECUTED_SIMULATED | 55 | 59 |
| HUMAN_COMPLETED | 0 | 0 |
| BLOCKED_UNBOUND | 55 | 55 |
| BLOCKED_EVAL_DETERMINISTIC | 13 | 0 |
| BLOCKED_EXECUTION | 10 | 3 |
| **total** | **192** | **192** |

Operations reaching ACCEPTED: 114 → 134.

## REGRESSION

Serial, standalone suites, port hygiene (8730/8795/8796 killed)
between suites, battery-canonical invocations:

| suite | result | note |
|---|---|---|
| worker (gate-c) | 105/105 OK | 98 pre-fix + 7 new media-chain tests |
| evaluation (gate-e) | 57/57 OK | 46 pre-fix + 11 new refs tests |
| storage (gate-d) | 5/5 OK | unchanged |
| runtime (gate-f) | 10/10 OK | unchanged |
| g2 coordinator | 97/97 OK | 96 pre-fix + 1 new cascade test |
| g3 API/dashboard | 54/54 OK | unchanged |
| g9 full run | 10/10 OK | persisted "G9 full run" production: 18 ACCEPTED / 1620¢ FINALIZED (read back by SQL, scoped per production) |
| MM-07 negative battery (fix copy) | 12/12 PASS | run under FIX 1 |

**Total: 338/338 + the 12-case negative battery.** (The remaining
station suites g1/g4–g8 were outside this fix cycle's brief list;
the g9 suite exercises all six station executors end-to-end.)

## Changed files (complete list)

- gate-e/evaluation_service/refs.py — rewritten reference rule.
- gate-e/evaluation_service/tests/test_mm10_refs.py — NEW (11).
- gate-e/evaluation_service/tests/test_layers.py — two tests'
  dangling-sha position moved to a paired pin (properties same).
- gate-e/golden/cases/seed-03-technical-dangling-sha.json — same
  repositioning (expectations unchanged; still SEED; 7/0).
- gate-c/worker_service/actions.py — media_ref hoist + resolver.
- gate-c/worker_service/tests/test_mm10_media_chain.py — NEW (7).
- video-factory-g2/coordinator/coordinator.py — cascade recompute.
- video-factory-g2/tests/test_coordinator.py — new cascade test +
  one count query scoped to its own production.
- mm-gate-10/harness/fix_rerun_driver.py,
  fix_classification.py, run_negative_battery_fixcopy.py — NEW
  harness (battery harness untouched).
- Evidence: this file; results/fix/fix1_references.json,
  fix2_media_plane.json, fix3_cascade.json, rerun_repairs.json,
  rerun_summary.json, classification_after_fix.json,
  regression.json, mm07_subset/.

No STATE.md / MEMORY.md changes. No coordinator schema change.
mm10_scratch preserved (repairs only through factory mechanisms).
Independent verification of this fix cycle is still owed (the
gate's verifier pass) — this record is the builder's evidence.
