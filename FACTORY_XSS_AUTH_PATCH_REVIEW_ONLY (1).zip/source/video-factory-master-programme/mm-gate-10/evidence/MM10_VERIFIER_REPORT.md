# GATE MM-10 — INDEPENDENT VERIFIER REPORT

**Verdict (summary): PASS WITH A RECORDED EVIDENCE EXCEPTION.** Every element
of the gate that could be independently executed passes — the three fixes
are verified with my own fixtures, chains, and probes; the regression spot
is green with the G9 full run re-read from its persisted DB; the plans
accounting and the simulation marking are verified from files and stored
bytes. One verification surface was destroyed before I could use it: the
preserved battery DB `mm10_scratch` no longer exists (environment loss,
§0), so the DB-rebuild items (1, 2, and parts of 6) are completed by
recorded-evidence consistency analysis instead of live SQL. That
substitution is stated wherever it applies and is **not** upgraded to
"verified from SQL" anywhere in this report.

Verifier environment: own scratch DB `mm10_verify_scratch`, own tokens/
fixtures/values throughout; serial execution with port hygiene
(8730/8795/8796/5678 killed between suites; API DSN asserted by behavior
before trusting a stack — OBS-1). Probes and logs:
`evidence/verify/` (`probe_fix1_refs.py`, `probe_fix2_media.py`,
`probe_fix3_cascade.py`, `probe_b7_lane_cap.py`, `*_results.json`,
`logs/`).

---

## 0. Environment event — the preserved battery DB is gone (D-MM10-V1, MAJOR, evidence/process)

At verification start (2026-10-30 ~00:33Z, minutes after the fix cycle
completed at 00:29:41Z) PostgreSQL was **entirely absent** from this
machine: no packages installed, no `pg_ctl`, and a filesystem-wide search
found no `PG_VERSION` or `postgresql.conf` anywhere — the cluster that
held `mm10_scratch` did not survive. No dump of `mm10_scratch` exists in
the workspace (searched: whole home tree for dump/backup files, the
mm-gate-10 tree, /tmp). The Gate D artifact store, all harness files and
all evidence JSONs live under `~/workspace` and **did** survive intact.

I restored PostgreSQL per the recorded MM-00 procedure — dpkg from the
apt cache, **exactly PostgreSQL 16.15 (Ubuntu 16.15-0ubuntu0.24.04.1)** —
and the setup chain rebuilt scratch DBs cleanly (migrations through 018).
The fresh cluster contains only the default databases. This is the same
environment event class recorded at MM-00 (VM replacement), **not** a
product defect and not a gate-actor action: the battery and fix cycle ran
against a live DB whose loss post-dates their completion.

Consequence map: items 1, 2, 6(a), 6(d) and the DB half of 6(e) cannot be
re-derived from live SQL. For those, I verified the recorded evidence
for internal consistency against everything that *does* survive (plans,
registry, the content-addressed store, witness files, repair records).
Everywhere else I executed independently.

**Recommendation (standing rule, O-1 class):** at every future gate
close, dump the battery/scratch DBs into the gate's evidence directory.
The plans-snapshot rule existed; the database itself was the one
evidence artifact with no snapshot.

---

## 1. Classification from SQL — NOT VERIFIABLE as specified; recorded classification CONFIRMED-BY-CONSISTENCY

The live rebuild is impossible (§0). What I verified instead, from
surviving sources, all independently:

- **Counts arithmetic:** pre-fix rows sum to 192 (REAL 59, SIMULATED 55,
  UNBOUND 55, EVAL 13, EXECUTION 10); post-fix rows sum to 192
  (REAL 75, SIMULATED 59, UNBOUND 55, EXECUTION 3, EVAL 0). Accepted
  114 → 134. The claimed post-fix counts are reproduced exactly by the
  recorded rows.
- **The 55 BLOCKED_UNBOUND are exactly the plan-derived unbound set:**
  I recomputed the unbound set from the current `plans.json` — 55 ops,
  28 `human.decision` + 27 `semantic.evaluate` — and the op-id set is
  **identical** to the classification's BLOCKED_UNBOUND rows.
- **Pre→post row diff:** exactly **20 rows changed class**, and they are
  precisely the 20 ops `rerun_repairs.json` records as repair-ACCEPTED.
  All 13 BLOCKED_EVAL_DETERMINISTIC rows became EXECUTED_* (the 9
  attest/analyze ops → REAL, the 4 AI_MEDIA ops 10.10/11.04/11.06/11.11
  → SIMULATED, matching each op's binding class); 7 of 10
  BLOCKED_EXECUTION rows became EXECUTED_REAL; the other 172 rows are
  unchanged. REAL +16 = 9 eval + 7 media; SIMULATED +4 = the AI_MEDIA
  four. The deltas reconcile to the row.
- **The 3 EXECUTION residuals are genuine residuals, not fix misses:**
  12.05 (cuts), 12.06 (sync), 14.06 (reedit) refuse with named
  declared-input absences — no upstream artifact declares cut segments
  or an audio offset. I corroborated the absence at the byte level:
  **zero** objects in the entire surviving store (2,202 objects) declare
  `segments[]` with `start_s`, and zero declare `audio_offset_ms` /
  `sync_offset_ms`. Unblocking them requires an upstream editorial
  declaration (a content decision), or teaching the transforms to
  invent edits — which the factory's no-fabrication rule correctly
  forbids. They block loudly, produce nothing false, and are correctly
  left blocked. Severity: none (correct refusal); class:
  content-declaration gap.

**Item 1 verdict: NOT VERIFIABLE (live rebuild) / recorded evidence
fully self-consistent.** The parent should treat the 75/59/55/3/0
counts and the 134-accepted figure as *confirmed-by-consistency*, not
*rebuilt-from-SQL*.

## 2. Mechanism coverage of the 55 unbound — factual report (no relabeling)

- **semantic.evaluate (27 ops): the evaluation FUNCTION was performed
  by the evaluation service on this production's artifacts.** Recorded
  evidence: the 13 pre-fix eval-blocked rows name `deterministic_checks`
  FAIL evaluations (the service evaluated those artifacts — that is how
  they blocked); 115 `human_approved` events are recorded for the
  production, and a unit reaches AWAITING_HUMAN only via a
  REVIEW_REQUIRED evaluation (the unarmed-golden-set posture), so the
  evaluation→human-approval path operated across the run's acceptances;
  every acceptance in the machinery routes through `validate()`. The 27
  unit rows themselves never executed — their plans are UNBOUND by
  design (evaluation is a service, not a worker action). Exact per-step
  evaluation counts vs the eval ops' steps: **not verifiable**
  (`quality_evaluations` was in the lost DB).
- **human.decision (28 ops): NOT covered per-op.** The factory's human
  mechanism is step-scoped: gate requirements produced exactly 5 gate
  artifacts (HG2, HG4, HG5 ×3), all APPROVED, all browser-witnessed
  (§6e), plus `human_approved` acceptance events. No per-operation
  human task exists in the machinery for mid-step decision ops, and
  those units BLOCK with the named class. This matches the builder's
  own recorded note and is a standing architecture fact (cf. MM-01
  C-09, "two unlinked human mechanisms"), not an MM-10 regression.

## 3. FIX 1 (references_resolve position rule) — PASS

My own probes (`verify/probe_fix1_refs.py`, fresh ids/digests, layer
level): **7/7 pass.**

- A digest-laden deliverable in the battery's exact failing shapes
  (attestation_sha256; input_sha256 mixing a content digest **and** a
  real artifact sha; analyses[] entries carrying artifact_id +
  content sha256; media_output.storage_uri store sha; bare sha256;
  source_sha256; content_sha256) → `references_resolve` **PASS** with
  **zero** sha refs extracted, overall verdict PASS.
- Dangling UUID in a reference-position field (`master_ref`) → FAIL
  naming the value, reason `artifact_not_found` (MM-07 **N10** property
  bites).
- Paired pin (`timeline_ref` + `timeline_sha256`): wrong sha → FAIL
  `sha_not_current` naming the sha; the CURRENT artifact's sha → PASS
  with exactly 1 sha ref.
- Tampered output bytes → `sha256_match` FAIL, verdict FAIL (MM-07
  **N4** property bites; the check is untouched, as required).
- `depends_on` carrying a sha: CURRENT artifact's sha resolves; an
  unknown sha FAILs `sha_not_current`.
- Service level: the evaluation suite passes **57/57** on my run,
  including the two tests whose dangling-sha position FIX 1 moved
  (`test_dangling_sha_blocked`, `test_worker_verdict_is_advisory_only`
  — re-run by name, both ok) and the builder's 11 new
  `test_mm10_refs` tests (ok standalone). The moved assertions assert
  the same properties at the corrected position; the golden seed case
  remains SEED and the arming counts (7 SEED / 0 EXPERT) are unchanged.

## 4. FIX 2 (media data plane) — PASS

My own chain (`verify/probe_fix2_media.py`, own temp store, ops the
builder's chain test did not use): **7/7 pass**, all media probed with
the **ffprobe CLI** (not the factory's own prober).

- 11.06 via MockAdapter → composed doc carries top-level `media_ref`
  whose sha equals the media object's sha and **differs** from the
  artifact's recorded (composed-JSON) sha; labeling present
  (`simulated: true`, `label: SIMULATED_MEDIA`); generated bytes probe
  as h264.
- 12.08 (loudnorm mix, deterministic-local) consumes that artifact:
  `resolved_via == "media_ref"`, the resolved media sha is the
  generator's media sha while the input artifact sha is the composed
  sha — the F-MM10-01 discontinuity is closed. Output probes with an
  AAC audio stream.
- Two-hop: 13.03 render consumes the 12.08 output via `media_ref` →
  **1280×720 h264 + AAC 48000**, probed by me.
- A non-media JSON artifact (canon_manifest) into 12.08 → the media
  action FAILs with the named reason ("no input artifact resolves to
  media bytes in the artifact store").
- Discipline: 11.06 under a deterministic-local binding refuses
  fail-closed (`BlockedError`: "runs only under a pinned 'mock'
  binding … refusing rather than producing simulated output under a
  non-mock label"). Simulation cannot leak under a real label.

## 5. FIX 3 (cascade readiness) — PASS

My own miniature (`verify/probe_fix3_cascade.py`, own ops/types:
story_architecture → 05.12 → scene_set): after `invalidate_artifact`
returns — with **no** `recompute_readiness` call and no service cycle
anywhere in the probe — the replacement unit reads **READY on three
consecutive fresh-connection polls**, `claim()` succeeds on a fourth
fresh connection, and SQL shows the replacement linked
(`supersedes_unit_id` = original, run kind PARTIAL_REPAIR). The B6
defect (replacements parked PENDING until an unrelated completion) is
closed.

## 6. Battery spot-checks — mixed by necessity (§0)

- **(a) Derivatives count 18 — NOT VERIFIABLE** (needs the artifacts
  table). Recorded in `b2_derivatives.json` (18 CURRENT step-14/15
  artifacts, each recorded hash_verified); the ≥11 target is met by
  the recorded count with margin. Recorded-only.
- **(b) 15.12 simulated marking — PASS, from the stored bytes.** I
  located the battery's actual distribution record object
  (sha `95db687f…`, the sha carried by the artifact `aebe6efd…` that
  b8 names) and read its bytes directly: `simulated: true`, provider
  `mock-platform-publisher`, **all 3 publications status SIMULATED**.
  Stronger than the builder's recorded boolean — the marking is in
  the artifact content itself.
- **(c) Hash sweep — PASS (store level).** All **2,202** objects in
  the Gate D store hash-verify against their content addresses (the
  single apparent exception is a `.json`-suffixed sidecar whose stem
  is the correct sha). The production's per-artifact CURRENT sweep
  (128/128) is recorded-only, but the bytes those records point at
  are independently proven intact and correctly addressed.
- **(d) Ledger invariants — NOT VERIFIABLE** (battery DB lost).
  Recorded: 0 reservations with >1 CHARGE, every accepted unit with a
  FINALIZED row (b3/b5a). The ledger machinery itself is re-proven
  live by §7 (my G9 read-back: 18 FINALIZED = 1620¢, 0 UNRESOLVED).
- **(e) Gates — PASS (witness half) / recorded (DB half).** All 5
  witness files exist on disk (`browser/`, `browser_r1/`,
  `browser_r2/`), each `witnessed: true` with UI approval results and
  before/after screenshots for HG2, HG4, HG5 ×3. The APPROVED /
  `decided_by = operator` state is recorded in `b1_summary.json`.

**Supporting check — B7 mechanism (mine):** the battery's concurrency
evidence was internally mixed (state sampler and attempt-interval
measures read 2 under cap 1; the RUNNING-interval micro-run read 1).
I settled the mechanism directly (`verify/probe_b7_lane_cap.py`):
with lane `text` capped at baseline+1, three `scheduler_claim` passes
admitted exactly one of two cross-production READY units and held the
other READY; raising the cap admitted the second. The cap limits
simultaneous CLAIMED+RUNNING per lane **across productions** (the
count is global per lane — my probe's baseline included a leftover
claim from my own FIX 3 probe in a different production, and the cap
accounted for it). The battery's higher readings counted VALIDATING /
attempt lifetimes, which hold no lane slot — consistent with the
builder's addendum. **Mechanism: PASS.**

## 7. Regression spot — PASS

Serial, port hygiene, canonical invocations, counts from my logs
(`verify/logs/`):

| suite | result | claimed |
|---|---|---|
| evaluation (gate-e) | **57/57 OK** | 57 |
| worker (gate-c) | **105/105 OK** | 105 |
| g2 coordinator (additional — FIX 3 surface) | **97/97 OK** | 97 |
| g9 | **10/10 OK** | 10 |

G9 persisted read-back (SQL, scoped to the 'G9 full run' production
of my run): **18/18 units ACCEPTED; 18 FINALIZED totalling 1620¢
(18 ESTIMATED = 1800¢); 0 UNRESOLVED rows in the DB.**

Plans state (file-level, independent): current `plans.json` has
**FULLY_BOUND 137**; diff vs `plans_snapshot_pre_mm10.json` =
**exactly 58 changed / 134 byte-identical**; the 58 are precisely the
four mockable classes (creative.generate 43, external.platform 9,
media.generate 4, external.provider 2), each now bound and carrying
its simulation note; `plans_hash` = `9fa67675…`; registry
**definition_hash `ea4503f5…` intact**. Snapshot discipline (O-1) was
followed.

*Verifier-side incident (disclosed):* my first G9 attempt was cut off
mid-drive — the exec wrapper reported completion while the suite's
unittest process was still running detached (8/10 tests, full-run
production left at 3 ACCEPTED). I killed the orphan, re-ran setup +
suite cleanly, and the results above are from that complete run
(`logs/g9b.log`: Ran 10, OK, rc recorded in-file). No product impact.

---

## Criterion mapping (prompt MM-10: "all credential-independent E2E checks pass with persistent evidence, zero unresolved critical defects")

**Met:**
- Complete factory through real n8n + persistent services with mock
  providers, six stations / 16 steps; master path end-to-end;
  selective regeneration (B6 + FIX 3 verified by me); production
  pinning (workflow 1.0.0; definition_hash verified intact);
  retries/recovery (n8n kill with exactly-once settlement recorded;
  B5b's original claim was *withdrawn in writing by the builder* and
  cleanly re-exercised — battery integrity, not a gap); human
  approvals (5/5 gates, browser-witnessed, files verified); real
  local rendering/media validation (FIX 2 chain probed by me);
  mock media + simulated receipts explicitly marked (verified from
  stored bytes; mock actions fail closed under non-mock bindings —
  verified by me); no real quality/cost/publishing claim made from
  simulation anywhere in the record (B4 claims bookkeeping
  consistency only); zero unresolved critical defects — both battery
  defects (F-MM10-01, F-MM10-02) and the cascade defect are fixed and
  independently verified above.

**Met with recorded exceptions:**
- "Every required operation": 134/192 accepted; 55 unbound-by-design
  (27 semantic.evaluate functionally performed by the evaluation
  service without executing their unit rows; **28 human.decision
  with no per-op human mechanism in the current architecture** —
  humans act at step gates, not per mid-step op); 3 blocked on
  declared-input absences (correct refusals, corroborated).
- Hashes/provenance: hashes verify everywhere checkable;
  **provenance exception** — `artifact_dependencies` carries 0 rows
  by machinery design (executor completions pass no
  depends_on_artifact_ids; lineage lives in unit_inputs + plan
  action records + produced_by chains). Recorded by the builder in
  the LOCK before the run; stated, not papered over.
- Concurrent production limits: no production-count knob exists;
  the mapped per-lane mechanism is verified (my probe), the
  battery's own samplers were confounded and self-corrected in its
  addendum.
- Persistent evidence: the evidence *files* persist and are
  consistent; the battery **database did not persist** to
  verification (§0, D-MM10-V1).

**Unmet:** none in product scope. The only unmet item is procedural:
the live-SQL rebuild the brief asked for, made impossible by the
environment loss.

## Defects

- **D-MM10-V1 (MAJOR — evidence/process, environment-caused):**
  `mm10_scratch` destroyed by VM replacement between the fix cycle
  and verification; DB-dependent verification completed by
  consistency analysis only. Recommendation: dump scratch DBs into
  gate evidence at gate close (standing rule).
- No product defects found. F-MM10-01, F-MM10-02 and the B6 cascade
  defect are fixed and independently verified (§§3–5). The 3 residual
  blocked ops are correct refusals on absent declared inputs, not
  defects.

## Final MM-10 verdict

**PASS WITH A RECORDED EVIDENCE EXCEPTION** — the factory ran the
complete 192-operation production end to end; every independently
executable check passes; the two product defects the battery existed
to find were found, fixed, and re-verified; the surviving recorded
evidence is internally consistent at row level. The exception: the
post-fix classification counts (REAL 75 / SIMULATED 59 / UNBOUND 55 /
EXECUTION 3 / EVAL 0; 134 accepted) stand as **confirmed-by-
consistency**, not rebuilt-from-SQL, because the preserved battery DB
was lost to a VM replacement before verification (D-MM10-V1). If the
programme requires a live-DB rebuild as a hard condition, the remedy
is a battery re-run on a fresh DB — an evidence-regeneration exercise,
not a product repair; nothing in the product evidence suggests its
outcome would differ.
