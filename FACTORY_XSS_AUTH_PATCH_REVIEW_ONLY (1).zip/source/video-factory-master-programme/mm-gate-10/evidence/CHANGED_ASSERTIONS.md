# MM-10 — changed assertions register

Every pre-existing assertion this gate's enabling build moved, with
the reason. Nothing else in the pre-existing suites was touched;
additions are in the NEW suite test_mm10_mock_actions.py.

## 1. test_worker_service.py — TestGate04Plans.test_all_192_plans_resolve

- Was: `len(fully) == 79` (MM-06 comment: 69 + 10 local-FFmpeg plans).
- Now: `len(fully) == 137`, with an MM-10 comment.
- Reason: the MM-10 enabling build (brief item 1) binds the 58 plans
  whose single UNBOUND action class is served by an explicitly
  simulated mock implementation (creative.generate 43,
  external.platform 9, media.generate 4, external.provider 2):
  79 + 58 = 137 FULLY_BOUND. The 58 are executable ONLY under a
  pinned 'mock' binding — the mock implementations refuse under any
  other binding (asserted in the new suite) — so genuinely bound
  stays 79; the MM-10 accounting reports both numbers.
- Same precedent as MM-06 (69 → 79), recorded the same way.
- The plan-hash self-consistency assertions in the same test are
  unchanged and pass: exactly the 58 expected plans changed vs the
  O-1 snapshot (evidence/results/plans_regeneration_diff.json); the
  other 134 plans are byte-identical; registry validate and
  plans-validate PASS; definition_hash ea4503f5… untouched.

## 2. test_worker_service.py — TestGate04Plans.test_unbound_plan_refuses_without_artifact

- Was: subject op 08.05; refused action_key "creative_generate".
- Now: subject op 01.02; refused action_key "semantic_evaluate".
- Reason: 08.05's creative.generate action is BOUND since MM-10
  (to the simulated mock implementation). The test's property —
  "a plan carrying an UNBOUND action refuses with UNBOUND_OPERATION
  and zero artifact" — now needs a still-unbound subject; 01.02's
  semantic.evaluate remains UNBOUND (an evaluation-side concern,
  never a worker action). Assertion shape identical (error class,
  exactly one REFUSED record, its action_key).
- 08.05's new behavior (executes under mock binding; refuses under
  deterministic-local / credentialed / absent binding) is asserted
  in the new suite test_mm10_mock_actions.py.

## 3. gate-c action_implementations.json (generated manifest)

- Regenerated from actions.py (it is a byte-exact dump of the
  registry's INPUT_SPECS/OUTPUT_SPECS by construction). The 19
  pre-existing entries are byte-identical after regeneration
  (verified programmatically: changed pre-existing entries = []);
  4 entries added for the mock implementations; total 23.

## Defect found and fixed during the enabling build (recorded)

- The four mock implementation registry keys were initially written
  with an underscore in the kind segment (mock.creative_generate)
  while the plan generator constructs the dotted form
  (mock.creative.generate), so plans regeneration failed with a
  KeyError. Root-caused at the byte level (the two strings render
  near-identically); fixed by literal replacement in actions.py
  (24 occurrences: registry keys, spec keys, binding-refusal labels,
  and in-band generator fields) and in LOCK_MM10.md / OWNERSHIP.md
  prose (4 each). After the fix: manifest regenerated, plans
  regenerated, validate + plans-validate PASS, worker suite 98/98.
