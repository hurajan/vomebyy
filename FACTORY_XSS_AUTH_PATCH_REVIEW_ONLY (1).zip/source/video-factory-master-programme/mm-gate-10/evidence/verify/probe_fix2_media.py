"""MM-10 VERIFIER probe — FIX 2 (F-MM10-01 media data plane).

Own chain, ops the builder's chain test did not use:
  11.06 (mock.media.generate, MockAdapter) -> composed doc artifact
  12.08 (media.ffmpeg_process 'mix', deterministic-local) consumes it
        via the declared media_ref; output probed with the ffprobe CLI
  13.03 (media.ffmpeg_render) consumes the 12.08 output (two-hop);
        output probed with the ffprobe CLI: 1280x720 h264 + aac 48k
  a non-media JSON artifact into 12.08 -> named refusal
  11.06 under a deterministic-local binding -> fail-closed refusal
        (simulation cannot run under a non-mock label)
Own temp store; no DB, no service ports. Exit 0 iff all cases pass.
"""
import hashlib
import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path

TMP = Path(tempfile.mkdtemp(prefix="mm10v-media-"))
os.environ["FACTORY_STORAGE_ROOT"] = str(TMP / "store")
os.environ["FACTORY_STORAGE_BACKEND"] = "local"

WS = Path.home() / "workspace/video-factory-real-ai-programme/gate-c/worker_service"
sys.path.insert(0, str(WS))
import adapters as adapters_mod  # noqa: E402
import plan_exec  # noqa: E402

HERE = Path(__file__).resolve().parent
MOCK = {"provider": "mock", "params": {"test_only": True}}
DET = {"provider": "deterministic-local", "est_cost_cents": 100, "params": {}}
SHOT_REF = {"artifact_type": "shot_manifest", "artifact_id": "mm10v-sm",
            "sha256": "unused",
            "content": {"shots": [{"id": "V1"}, {"id": "V2"}, {"id": "V3"}]}}
results = {}


def store_bytes(data: bytes) -> str:
    from storage_service import factory_from_env
    store = factory_from_env()
    staged = store.put_candidate(data)
    store.promote(staged["uri"])
    assert staged["sha256"] == hashlib.sha256(data).hexdigest()
    return staged["sha256"]


def fetch(sha: str) -> bytes:
    import media_tools as mt
    data = mt.fetch_media_bytes(sha)
    assert data is not None, f"store object {sha} missing"
    return data


def ffprobe(data: bytes) -> dict:
    p = TMP / "probe.bin"
    p.write_bytes(data)
    out = subprocess.run(
        ["ffprobe", "-v", "error", "-show_streams", "-show_format",
         "-of", "json", str(p)], check=True, capture_output=True)
    return json.loads(out.stdout)


def run(binding, op, refs, adapter_cls):
    adapter = adapter_cls()
    result = adapter.execute(binding, {
        "operation_id": op, "production_id": "mm10v-media-prod",
        "unit_id": f"mm10v-{op}", "attempt_id": None,
        "provider_binding": binding, "input_artifact_refs": refs})
    summary = result["plan_execution"]
    assert [a["status"] for a in summary["actions"]] == \
        ["SUCCEEDED"] * len(summary["actions"]), summary
    return json.loads(result["content"]), summary


# --- 1. generate via 11.06 ---------------------------------------------
doc_gen, _ = run(MOCK, "11.06", [SHOT_REF], adapters_mod.MockAdapter)
raw_gen = json.dumps(doc_gen, sort_keys=True).encode()
art_sha_gen = store_bytes(raw_gen)
gen_media = doc_gen["derived"]["media_generate"]["media_output"]
gen_action = doc_gen["derived"]["media_generate"]
results["generate"] = {
    "media_ref_present": "media_ref" in doc_gen,
    "media_ref_sha": doc_gen.get("media_ref", {}).get("sha256"),
    "media_output_sha": gen_media["sha256"],
    "artifact_sha": art_sha_gen,
    "simulated_label": gen_action.get("simulated"),
    "label_field": gen_action.get("label"),
    "generator": gen_action.get("generator"),
    "pass": doc_gen.get("media_ref", {}).get("sha256") == gen_media["sha256"]
            and art_sha_gen != gen_media["sha256"]
            and gen_action.get("simulated") is True
            and gen_action.get("label") == "SIMULATED_MEDIA"}
probe_gen = ffprobe(fetch(gen_media["sha256"]))
gv = [s for s in probe_gen["streams"] if s["codec_type"] == "video"][0]
results["generate_probe"] = {
    "codec": gv["codec_name"], "size": f"{gv['width']}x{gv['height']}",
    "pass": gv["codec_name"] == "h264"}

# --- 2. chain into 12.08 (mix) -------------------------------------------
ref_gen = {"artifact_type": doc_gen["kind"], "artifact_id": "mm10v-gen-1",
           "sha256": art_sha_gen, "content": doc_gen}
doc_mix, _ = run(DET, "12.08", [ref_gen],
                 adapters_mod.DeterministicLocalAdapter)
mix = doc_mix["derived"]["media_process"]
results["chain_process"] = {
    "resolved_via": mix["media_input"]["resolved_via"],
    "media_sha256": mix["media_input"]["media_sha256"],
    "input_artifact_sha": mix["media_input"]["sha256"],
    "pass": mix["media_input"]["resolved_via"] == "media_ref"
            and mix["media_input"]["media_sha256"] == gen_media["sha256"]
            and mix["media_input"]["sha256"] == art_sha_gen}
probe_mix = ffprobe(fetch(mix["media_output"]["sha256"]))
ma = [s for s in probe_mix["streams"] if s["codec_type"] == "audio"]
results["chain_process_probe"] = {
    "audio_streams": len(ma),
    "audio_codec": ma[0]["codec_name"] if ma else None,
    "duration_s": float(probe_mix["format"]["duration"]),
    "pass": len(ma) == 1 and ma[0]["codec_name"] == "aac"}

# --- 3. two-hop into 13.03 render -----------------------------------------
raw_mix = json.dumps(doc_mix, sort_keys=True).encode()
art_sha_mix = store_bytes(raw_mix)
ref_mix = {"artifact_type": doc_mix["kind"], "artifact_id": "mm10v-mix-1",
           "sha256": art_sha_mix, "content": doc_mix}
doc_render, _ = run(DET, "13.03", [ref_mix],
                    adapters_mod.DeterministicLocalAdapter)
render = doc_render["derived"]["media_render"]
probe_r = ffprobe(fetch(render["media_output"]["sha256"]))
rv = [s for s in probe_r["streams"] if s["codec_type"] == "video"][0]
ra = [s for s in probe_r["streams"] if s["codec_type"] == "audio"][0]
results["chain_render"] = {
    "resolved_via": render["media_input"]["resolved_via"],
    "video": f"{rv['codec_name']} {rv['width']}x{rv['height']}",
    "audio": f"{ra['codec_name']} {ra['sample_rate']}",
    "pass": render["media_input"]["resolved_via"] == ["media_ref"]
            and rv["codec_name"] == "h264"
            and (rv["width"], rv["height"]) == (1280, 720)
            and ra["codec_name"] == "aac" and ra["sample_rate"] == "48000"}

# --- 4. non-media JSON artifact -> named refusal ---------------------------
doc_text = {"kind": "canon_manifest", "mm10v": "plain json, no media",
            "entries": [{"id": "C1"}]}
raw_text = json.dumps(doc_text, sort_keys=True).encode()
sha_text = store_bytes(raw_text)
ref_text = {"artifact_type": "canon_manifest", "artifact_id": "mm10v-txt",
            "sha256": sha_text, "content": doc_text}
records = []
err = None
try:
    plan_exec.execute_operation(
        {"operation_id": "12.08", "production_id": "mm10v-media-prod",
         "unit_id": "mm10v-neg", "input_artifact_refs": [ref_text],
         "provider_binding": DET}, sink=records.append)
except adapters_mod.ProviderError as exc:
    err = str(exc)
failed = [r for r in records if r["status"] in ("FAILED", "REFUSED")]
results["non_media_named_refusal"] = {
    "error": err, "failed_actions": [f["action_key"] for f in failed],
    "failed_error": failed[0]["error"] if failed else None,
    "pass": bool(failed) and failed[0]["action_key"] == "media_process"
            and "no input artifact resolves to media bytes"
            in failed[0]["error"]}

# --- 5. mock generation under a non-mock binding refuses -------------------
records5 = []
err5 = None
try:
    plan_exec.execute_operation(
        {"operation_id": "11.06", "production_id": "mm10v-media-prod",
         "unit_id": "mm10v-discipline", "input_artifact_refs": [SHOT_REF],
         "provider_binding": DET}, sink=records5.append)
except Exception as exc:  # BlockedError/ProviderError both = refusal
    err5 = f"{type(exc).__name__}: {exc}"
bad5 = [r for r in records5 if r["status"] in ("FAILED", "REFUSED")]
results["mock_fail_closed_under_real_label"] = {
    "error": err5,
    "bad_actions": [(r["action_key"], r["status"]) for r in bad5],
    "bad_error": bad5[0]["error"] if bad5 else None,
    "pass": (err5 is not None and "only under a pinned 'mock' binding"
             in err5) or (bool(bad5) and any(
                 "mock" in (r.get("error") or "") for r in bad5))}

all_pass = all(v.get("pass") for v in results.values())
out = {"probe": "FIX2 media data plane (verifier)", "all_pass": all_pass,
       "cases": results, "tmp": str(TMP)}
(HERE / "fix2_probe_results.json").write_text(json.dumps(out, indent=1))
print(json.dumps(out, indent=1))
sys.exit(0 if all_pass else 1)
