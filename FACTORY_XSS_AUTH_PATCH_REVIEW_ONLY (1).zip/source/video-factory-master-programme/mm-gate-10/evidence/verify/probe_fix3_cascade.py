"""MM-10 VERIFIER probe — FIX 3 (B6 cascade readiness).

Own miniature on the verifier scratch DB (mm10_verify_scratch),
different ops/types from the builder's test:
  A = story_architecture (operator-registered)
  U1 = unit for 05.12 consuming A; B = scene_set produced by U1,
       depends_on A
  invalidate A -> cascade supersedes U1 and plans a replacement.
  WITHOUT any recompute_readiness call or service cycle from this
  probe, poll the replacement's state through FRESH coordinator
  connections: it must already be READY, and claim() must succeed.
Exit 0 iff all assertions pass. Password sourced from the canonical
fixture (never printed).
"""
import json
import re
import sys
from pathlib import Path

HOME = Path.home() / "workspace"
sys.path.insert(0, str(HOME / "video-factory-g2/coordinator"))
_pw = re.search(r"password=([^\s\"']+)",
                (HOME / "video-factory-g9/tools/setup_fullrun.py")
                .read_text()).group(1)
DSN = f"host=127.0.0.1 dbname=mm10_verify_scratch user=factory password={_pw}"
from coordinator import Coordinator  # noqa: E402

results = {}
c = Coordinator(DSN)
pid = c.create_production("MM10V cascade probe", 100_00, 80_00, "mm10v")
run = c.start_run(pid, "FULL", "mm10v")
a = c.register_artifact(pid, "story_architecture", b"mm10v-arch-v1",
                        "local://mm10v/arch1")
u1 = c.plan_unit(pid, run, "05.12", "main", "text", (), (a["artifact_id"],))
b = c.register_artifact(pid, "scene_set", b"mm10v-scenes-v1",
                        "local://mm10v/scenes1", produced_by_unit=u1,
                        depends_on_artifact_ids=(a["artifact_id"],))
results["setup"] = {"production_id": str(pid), "unit_u1": str(u1),
                    "artifact_a": str(a["artifact_id"]),
                    "artifact_b": str(b["artifact_id"])}

out = c.invalidate_artifact(a["artifact_id"], "mm10v correction", "mm10v")
results["cascade_out"] = {
    "affected": [str(x) for x in out["affected_artifact_ids"]],
    "new_unit_ids": [str(x) for x in out["new_unit_ids"]]}
assert len(out["new_unit_ids"]) == 1, out
replacement = out["new_unit_ids"][0]
c.close()

# Poll through fresh connections only — no recompute call anywhere.
states = []
for _ in range(3):
    fresh = Coordinator(DSN)
    states.append(fresh.get_unit(replacement)["state"])
    fresh.close()
results["polled_states_fresh_connections"] = states
results["ready_without_manual_recompute"] = {
    "pass": states == ["READY", "READY", "READY"]}

# Claimable through a fresh connection.
fresh = Coordinator(DSN)
claim = fresh.claim(replacement, "mm10v-worker", 100)
results["claim"] = {"claimed_unit": str(claim["unit_id"]),
                    "pass": str(claim["unit_id"]) == str(replacement)}
# SQL-level: replacement linkage + run kind.
import psycopg  # noqa: E402
with psycopg.connect(DSN) as conn:
    row = conn.execute(
        "SELECT u.state, u.supersedes_unit_id, r.kind FROM execution_units u"
        " JOIN production_runs r ON r.run_id=u.run_id WHERE u.unit_id=%s",
        (replacement,)).fetchone()
results["sql_linkage"] = {"state": row[0],
                          "supersedes_is_original": str(row[1]) == str(u1),
                          "run_kind": row[2],
                          "pass": str(row[1]) == str(u1)
                          and row[2] == "PARTIAL_REPAIR"}
fresh.close()

all_pass = (results["ready_without_manual_recompute"]["pass"]
            and results["claim"]["pass"] and results["sql_linkage"]["pass"])
outj = {"probe": "FIX3 cascade readiness (verifier)", "all_pass": all_pass,
        "cases": results}
(Path(__file__).parent / "fix3_probe_results.json").write_text(
    json.dumps(outj, indent=1, default=str))
print(json.dumps(outj, indent=1, default=str))
sys.exit(0 if all_pass else 1)
