"""MM-10 VERIFIER probe — B7 mechanism (per-lane capacity cap).

The battery mapped the brief's 'concurrent production limit' onto
capacity_policies (no production-count knob exists). This probe
verifies the mapped mechanism itself on the verifier scratch DB:
lane 'text' cap = 1; two productions each with one READY text unit;
scheduler_claim passes must never let CLAIMED+RUNNING on the lane
exceed 1 across BOTH productions; raising the cap to 4 lets the
second production's unit claim. State read via SQL (fresh queries),
not via the claiming connection's cache. Exit 0 iff all pass.
"""
import json
import re
import sys
from pathlib import Path

HOME = Path.home() / "workspace"
sys.path.insert(0, str(HOME / "video-factory-g2/coordinator"))
_pw = re.search(r"password=([^\s\"']+)",
                (HOME / "video-factory-g9/tools/setup_fullrun.py")
                .read_text()).group(1)
DSN = f"host=127.0.0.1 dbname=mm10_verify_scratch user=factory password={_pw}"
import psycopg  # noqa: E402
from coordinator import Coordinator  # noqa: E402


def sql(q, args=()):
    with psycopg.connect(DSN) as conn:
        return conn.execute(q, args).fetchall()


def exec_sql(q, args=()):
    with psycopg.connect(DSN) as conn:
        conn.execute(q, args)
        conn.commit()


results = {}
c = Coordinator(DSN)
# Baseline: lane inflight from OTHER work in this scratch DB (the
# verifier's own FIX 3 probe left one text-lane unit CLAIMED). The
# scheduler counts lane inflight globally, so caps are set relative
# to the measured baseline: cap = baseline+1 must admit exactly one
# of this probe's two units.
baseline = sql("SELECT count(*) FROM execution_units WHERE lane='text'"
               " AND state IN ('CLAIMED','RUNNING')")[0][0]
results["baseline_lane_inflight"] = baseline
cap_low = baseline + 1
exec_sql("UPDATE capacity_policies SET max_concurrency=%s WHERE lane='text'",
         (cap_low,))
p1 = c.create_production("MM10V lane probe A", 100_00, 80_00, "mm10v")
p2 = c.create_production("MM10V lane probe B", 100_00, 80_00, "mm10v")
r1 = c.start_run(p1, "FULL", "mm10v")
r2 = c.start_run(p2, "FULL", "mm10v")
u1 = c.plan_unit(p1, r1, "01.01", "main", "text")
u2 = c.plan_unit(p2, r2, "01.01", "main", "text")
states0 = dict(sql("SELECT unit_id::text, state FROM execution_units"
                   " WHERE unit_id IN (%s,%s)", (u1, u2)))
results["initial"] = {"states": states0,
                      "pass": states0 == {str(u1): "READY",
                                          str(u2): "READY"}}

inflight_hist = []
claimed_passes = []
for i in range(3):
    claimed = c.scheduler_claim()
    claimed_passes.append([str(x["unit_id"]) for x in claimed])
    n = sql("SELECT count(*) FROM execution_units WHERE lane='text'"
            " AND state IN ('CLAIMED','RUNNING')"
            " AND production_id IN (%s,%s)", (p1, p2))[0][0]
    inflight_hist.append(n)
results["cap1_passes"] = {"cap": cap_low,
                          "claimed_per_pass": claimed_passes,
                          "lane_inflight_after_each_pass": inflight_hist,
                          "pass": max(inflight_hist) == 1
                          and sum(len(x) for x in claimed_passes) == 1}
states1 = dict(sql("SELECT unit_id::text, state FROM execution_units"
                   " WHERE unit_id IN (%s,%s)", (u1, u2)))
results["cap1_states"] = {"states": states1,
                          "pass": sorted(states1.values())
                          == ["CLAIMED", "READY"]}

cap_high = baseline + 4
exec_sql("UPDATE capacity_policies SET max_concurrency=%s WHERE lane='text'",
         (cap_high,))
claimed2 = c.scheduler_claim()
n2 = sql("SELECT count(*) FROM execution_units WHERE lane='text'"
         " AND state IN ('CLAIMED','RUNNING')"
         " AND production_id IN (%s,%s)", (p1, p2))[0][0]
prods = dict(sql("SELECT unit_id::text, production_id::text FROM"
                 " execution_units WHERE unit_id IN (%s,%s)", (u1, u2)))
results["cap4_pass"] = {
    "newly_claimed": [str(x["unit_id"]) for x in claimed2],
    "lane_inflight": n2,
    "claimed_units_span_both_productions":
        set(prods.values()) == {str(p1), str(p2)},
    "pass": n2 == 2 and set(prods.values()) == {str(p1), str(p2)}}
c.close()
exec_sql("UPDATE capacity_policies SET max_concurrency=4 WHERE lane='text'")

all_pass = all(v.get("pass") for k, v in results.items()
               if isinstance(v, dict) and "pass" in v)
out = {"probe": "B7 lane-cap mechanism (verifier)", "all_pass": all_pass,
       "cases": results}
(Path(__file__).parent / "b7_probe_results.json").write_text(
    json.dumps(out, indent=1, default=str))
print(json.dumps(out, indent=1, default=str))
sys.exit(0 if all_pass else 1)
