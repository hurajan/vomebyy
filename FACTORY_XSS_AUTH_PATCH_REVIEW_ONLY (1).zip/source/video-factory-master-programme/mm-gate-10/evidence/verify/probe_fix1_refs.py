"""MM-10 VERIFIER probe — FIX 1 (F-MM10-02 references_resolve rule).

Independent fixtures (own ids/digests/values), layer-level contexts in
the test_mm07_checks style. Asserts:
  A. digest-laden deliverable (attest/content-analyze/media_output
     shapes from the battery findings) -> references_resolve PASS,
     zero sha refs extracted.
  B. dangling UUID in a reference-position field -> FAIL naming the
     value (artifact_not_found). [MM-07 N10 property]
  C. paired pin (timeline_ref + timeline_sha256): wrong sha -> FAIL
     sha_not_current naming the sha; correct sha -> PASS.
  D. tampered output bytes -> sha256_match FAIL. [MM-07 N4 property]
  E. source_sha256 digest field -> not extracted.
  F. depends_on carrying a sha: CURRENT artifact's sha -> PASS;
     unknown sha -> FAIL sha_not_current.
Writes JSON results next to this file; exit 0 iff all cases pass.
"""
import hashlib
import json
import sys
import uuid
from pathlib import Path

HERE = Path(__file__).resolve().parent
PKG = Path.home() / "workspace/video-factory-real-ai-programme/gate-e/evaluation_service"
sys.path.insert(0, str(PKG))
import layers  # noqa: E402
import refs as refs_mod  # noqa: E402

PID = "mm10v-fix1-production"


def _sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def digest_of(tag: str) -> str:
    return _sha(f"mm10v-digest-{tag}".encode())


def art(aid, atype, content=None, state="CURRENT"):
    row = {"artifact_id": aid, "artifact_type": atype, "version": 1,
           "state": state, "production_id": PID,
           "sha256": _sha(content) if content is not None else "0" * 64,
           "storage_uri": "mm10v://artifact"}
    if content is not None:
        row["content_bytes"] = content
    return row


def make_ctx(op, content, artifact_type, inputs=(), extras=(),
             recorded_sha=None):
    out = art("22222222-2222-4222-8222-222222222222", artifact_type, content)
    if recorded_sha is not None:
        out["sha256"] = recorded_sha
    all_by_id = {out["artifact_id"]: out}
    for row in list(inputs) + list(extras):
        all_by_id[row["artifact_id"]] = row
    current_by_sha = {r["sha256"]: r for r in all_by_id.values()
                      if r["state"] == "CURRENT"}
    return {
        "production_id": PID,
        "unit": {"unit_id": "mm10v-unit", "operation_id": op,
                 "current_attempt": 1},
        "operation": {"operation_id": op, "step_id": op.split(".")[0],
                      "capability_slot": "mm10v",
                      "validator_policy": ["schema_validation",
                                           "dependency_integrity",
                                           "named_check"]},
        "output_artifact": out, "output_bytes": content,
        "input_artifacts": list(inputs),
        "planned_input_ids": [r["artifact_id"] for r in inputs],
        "all_by_id": all_by_id, "current_by_sha": current_by_sha,
        "environment": "test",
        "resolve_qa_binding": lambda: None,
        "fetch_bytes_by_sha": lambda sha: None,
    }


def check_named(result, name):
    for c in result["report"]["checks"]:
        if c["check"] == name:
            return c
    return None


results = {}

# --- shared input artifact (CURRENT, in production) -------------------
INPUT_ID = str(uuid.uuid4())
input_content = json.dumps({"kind": "edit_timeline", "mm10v": True},
                           sort_keys=True).encode()
input_row = art(INPUT_ID, "edit_timeline", input_content)
INPUT_SHA = input_row["sha256"]

# --- A: digest-laden deliverable --------------------------------------
doc_a = {
    "kind": "archive_attestation",
    "derived": {
        "records": {"attest": {
            "attestation_sha256": digest_of("attest"),
            "input_sha256": [digest_of("content-proj"), INPUT_SHA]}},
        "content": {"analyze": {"analyses": [
            {"artifact_id": INPUT_ID, "artifact_type": "edit_timeline",
             "sha256": digest_of("analysis")}] }},
        "media_generate": {"media_output": {
            "storage_uri": f"store://objects/{digest_of('media')}",
            "sha256": digest_of("media")}},
    },
    "sha256": digest_of("bare"),
    "source_sha256": digest_of("source"),
    "content_sha256": digest_of("content"),
}
content_a = json.dumps(doc_a, sort_keys=True).encode()
res_a = layers.technical_layer(make_ctx("13.10", content_a,
                                        "hash_approved_master_and_store_immutable",
                                        inputs=[input_row]))
rr_a = check_named(res_a, "references_resolve")
results["A_digest_laden_passes"] = {
    "references_resolve_ok": rr_a["ok"], "sha_refs": rr_a["sha_refs"],
    "id_refs": rr_a["id_refs"], "failures": rr_a["failures"],
    "verdict": res_a["report"]["verdict"],
    "pass": rr_a["ok"] is True and rr_a["sha_refs"] == 0
            and res_a["report"]["verdict"] == "PASS"}

# --- B: dangling UUID in a ref field -----------------------------------
DANGLING = str(uuid.uuid4())
doc_b = {"kind": "package", "master_ref": DANGLING, "note": "mm10v"}
content_b = json.dumps(doc_b, sort_keys=True).encode()
res_b = layers.technical_layer(make_ctx("13.10", content_b, "master_package",
                                        inputs=[input_row]))
rr_b = check_named(res_b, "references_resolve")
named_b = [f for f in rr_b["failures"] if f["value"] == DANGLING
           and f["reason"] == "artifact_not_found"]
results["B_dangling_ref_uuid_fails_named"] = {
    "references_resolve_ok": rr_b["ok"], "failures": rr_b["failures"],
    "verdict": res_b["report"]["verdict"],
    "pass": rr_b["ok"] is False and len(named_b) == 1
            and res_b["report"]["verdict"] == "FAIL"}

# --- C: paired pin ------------------------------------------------------
WRONG_SHA = digest_of("pin-wrong")
doc_c_bad = {"kind": "master_package",
             "timeline_ref": INPUT_ID, "timeline_sha256": WRONG_SHA}
content_c_bad = json.dumps(doc_c_bad, sort_keys=True).encode()
res_c_bad = layers.technical_layer(make_ctx("13.12", content_c_bad,
                                            "master_package",
                                            inputs=[input_row]))
rr_c_bad = check_named(res_c_bad, "references_resolve")
pin_fail = [f for f in rr_c_bad["failures"] if f["value"] == WRONG_SHA
            and f["reason"] == "sha_not_current"]
doc_c_ok = {"kind": "master_package",
            "timeline_ref": INPUT_ID, "timeline_sha256": INPUT_SHA}
content_c_ok = json.dumps(doc_c_ok, sort_keys=True).encode()
res_c_ok = layers.technical_layer(make_ctx("13.12", content_c_ok,
                                           "master_package",
                                           inputs=[input_row]))
rr_c_ok = check_named(res_c_ok, "references_resolve")
results["C_paired_pin"] = {
    "wrong_sha_failures": rr_c_bad["failures"],
    "correct_sha_ok": rr_c_ok["ok"], "correct_sha_refs": rr_c_ok["sha_refs"],
    "pass": len(pin_fail) == 1 and rr_c_ok["ok"] is True
            and rr_c_ok["sha_refs"] == 1}

# --- D: tampered bytes (N4) ---------------------------------------------
original = json.dumps({"kind": "script", "mm10v": "original"},
                      sort_keys=True).encode()
tampered = json.dumps({"kind": "script", "mm10v": "TAMPERED"},
                      sort_keys=True).encode()
ctx_d = make_ctx("13.10", tampered, "script", inputs=[input_row],
                 recorded_sha=_sha(original))
res_d = layers.technical_layer(ctx_d)
sm_d = check_named(res_d, "sha256_match")
results["D_tampered_bytes_sha256_match_fails"] = {
    "sha256_match_ok": sm_d["ok"], "verdict": res_d["report"]["verdict"],
    "pass": sm_d["ok"] is False and res_d["report"]["verdict"] == "FAIL"}

# --- E: extraction-level digest positions --------------------------------
extracted = refs_mod.extract_refs(doc_a)
results["E_extraction_digest_positions"] = {
    "shas_extracted_from_doc_a": extracted["shas"],
    "pass": extracted["shas"] == []}
ext_pin = refs_mod.extract_refs(doc_c_bad)
results["E2_extraction_paired_pin"] = {
    "shas": ext_pin["shas"], "ids": ext_pin["artifact_ids"],
    "pass": [s["value"] for s in ext_pin["shas"]] == [WRONG_SHA]}

# --- F: depends_on sha positions -----------------------------------------
doc_f_ok = {"kind": "pkg", "depends_on": [INPUT_SHA]}
res_f_ok = layers.technical_layer(make_ctx(
    "13.10", json.dumps(doc_f_ok, sort_keys=True).encode(), "pkg",
    inputs=[input_row]))
rr_f_ok = check_named(res_f_ok, "references_resolve")
doc_f_bad = {"kind": "pkg", "depends_on": [digest_of("dep-unknown")]}
res_f_bad = layers.technical_layer(make_ctx(
    "13.10", json.dumps(doc_f_bad, sort_keys=True).encode(), "pkg",
    inputs=[input_row]))
rr_f_bad = check_named(res_f_bad, "references_resolve")
results["F_depends_on_sha"] = {
    "current_sha_ok": rr_f_ok["ok"],
    "unknown_sha_failures": rr_f_bad["failures"],
    "pass": rr_f_ok["ok"] is True and rr_f_bad["ok"] is False
            and any(f["reason"] == "sha_not_current"
                    for f in rr_f_bad["failures"])}

all_pass = all(v.get("pass") for v in results.values())
out = {"probe": "FIX1 references_resolve position rule (verifier)",
       "all_pass": all_pass, "cases": results}
(HERE / "fix1_probe_results.json").write_text(json.dumps(out, indent=1))
print(json.dumps(out, indent=1))
sys.exit(0 if all_pass else 1)
