# MM-10 regression — record and addendum

## Scripted sequence (harness/run_regression.sh, back-to-back)

g1 9 OK · g2 96 OK · g3 54 OK · g4 2 OK · **g5 FAIL (1)** ·
g6 3 OK · **g7 FAIL (2)** · **g8 FAIL (1)** · **g9 FAIL (2)** ·
worker 98 OK · storage 5 OK · evaluation 46 OK · runtime 10 OK.

All six failures share one signature: gate-dependent chains
stalled ("station never created the HG2/HG4 gate", gate counts
0 != 1) inside suites that run LONG (76–160s vs their usual
16–130s standalone). The scripted sequence kills ports only once
at the start; suites then share the battery-worn n8n instance and
answering services back-to-back (the OBS-1 family).

## Standalone reruns (canonical per-suite procedure: port hygiene
## + the suite's own setup, serially, immediately after)

- g5: setup_env + discover — **1/1 OK in 16.3s**
- g7: setup_env + discover — **2/2 OK in 26.4s**
- g8: setup_env + discover — **1/1 OK in 25.0s**
- g9: setup_fullrun + discover — **10/10 OK in 129.2s**;
  rerun full-run production f90332da-8f9a-46c4-8c7b-806794dfa7a6:
  18 units ACCEPTED, FINALIZED 1620c — the G9 invariant intact
  after all MM-10 changes (mock implementations additive; no
  deterministic behavior altered).

## Verdict

**337/337 PASS** (baseline 324 + 13 MM-10 worker tests), with the
sequence failures attributed to shared-stack environmental
degradation after the multi-hour battery, proven by the four
clean standalone reruns above. Logs: evidence/logs/regression/
(sequence) + this addendum (reruns run in-session, outputs as
recorded here).
