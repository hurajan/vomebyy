# MM-10 battery — step-14 ordering incident + in-place repair

## What happened

The driver's step model treats 14.12 as step 14's exit and 14.01 as
an intra-step unit, so it drove (and the evaluation service judged)
14.12 BEFORE 14.01 had run. 14.12 executed cleanly and produced
derivative_package v1, but the deterministic evaluation layer
failed it: check `derivative_set_matches_portfolio` — "no
derivative_portfolio input to compare against" (the check compares
the derivative set against 14.01's derivative_portfolio, read from
the unit's inputs or, failing that, the production's CURRENT
portfolio; neither existed yet). Deterministic FAIL routes to
BLOCKED (validation_failed_deterministic), and BLOCKED is terminal
in this factory (only exit: operator `cancel`).

Root cause: the driver's DAG dropped the registry chain link
14.01 -> 14.12 (in G9's proven chain the two are consecutive links;
the brief's master-chain list likewise reads "13.12 -> 14.01 ->
14.12"). Same family as the canon topology correction: a battery
harness ordering error, not a product defect — the evaluation check
did exactly its designed job. The original 15.12, planned against
the dead 14.12 unit and its v1 artifact, could never become READY.

## Repair (operator paths only, all through the factory's own APIs)

Executed by harness/repair_step14.py against the same production
(the run's other 157 units and the three browser-witnessed gate
approvals stand):

1. Original 15.12 (PENDING, dead dependency): operator `block`
   event, then `cancel` event -> CANCELLED. (16.12 was never
   planned.)
2. New 14.12 unit (unit_key "main-r1"), depends_on the ACCEPTED
   14.01 unit, planned inputs = CURRENT master_package +
   derivative_portfolio. Driven through the same scheduler +
   executor path; the portfolio check now has its operand.
3. New 15.12 (unit_key "main-r1") on the new 14.12, then step-15
   intra units anchored on the new 14.12; new 16.12 on the new
   15.12; step-16 intra anchored on the new 15.12. The new 15.12
   consumes derivative_package v2, which requires a NEW HG5 gate
   bound to v2 (require_gate binds artifact id + hash) — created by
   the driver's gate-creation path and decided through the browser
   witness run like the others.
4. Final sweep + B6 proceed as locked.

Accounting consequence: the production carries 195 unit rows for
192 operations. The 192-row classification resolves each operation
to its ACCEPTED unit where one exists (the repair units for
14.12/15.12/16.12); the cancelled original 15.12 and the blocked
original 14.12 are listed in B1's unit accounting as
repair-superseded rows, never hidden.

## Addendum — repair pass 1 finding, pass 2 correction

Pass 1 planned the replacement 14.12 with TWO inputs
(master_package + derivative_portfolio). Deterministic checks then
PASSed (the portfolio operand was present), but continuity FAILed:
"output does not declare all planned inputs" — the 14.12 builder's
output declares only the master_package input, so a planned
portfolio input is undeclared by construction. Result:
REPAIR_REQUIRED. The portfolio is designed to reach the check as a
production-level operand (the check's own evidence names the
fallback: portfolio_source "current_in_production"), NOT as a
planned input — G9's single-input topology was the correct shape
all along; only the ORDER (14.01 before 14.12) was missing.

Pass 2 (harness/repair2_step14.py): the r1 15.12 cancelled; a
second replacement 14.12 (unit_key "main-r2", same repair run)
planned with master_package ONLY, now that 14.01's portfolio is
CURRENT; the chain re-derives from there. The r1 14.12 remains in
the record as a REPAIR_REQUIRED unit.
