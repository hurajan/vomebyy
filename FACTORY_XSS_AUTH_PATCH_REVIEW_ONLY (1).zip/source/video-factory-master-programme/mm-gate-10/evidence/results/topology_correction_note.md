# MM-10 battery — topology correction (recorded before the clean run)

The battery's first attempt (discarded; battery DB rebuilt) planned
the operator-registered canon_manifest as an input to exits
03.12–08.12, following the lock's shorthand "station-3 exits take
canon artifact". Observed behavior, from the evaluation records:

- 03.12 executed and its output — itself a `canon_manifest` —
  became CURRENT v2, SUPERSEDING the operator canon v1 that was its
  own planned input.
- The evaluation service's continuity layer then FAILed the unit:
  "planned inputs no longer CURRENT" / "output does not declare all
  planned inputs" (superseded_inputs named the canon v1), landing
  03.12 in REPAIR_REQUIRED. Schema and deterministic layers PASSed;
  the semantic layer was REVIEW_REQUIRED as designed.
- REPAIR_REQUIRED's only exit transition is `repair_ready`, and a
  re-claim would refuse with StaleInput (coordinator
  verify_inputs_current): redispatch of the same unit cannot repair
  this mode. Every later unit planned against canon v1 (04.12–08.12
  exits, step 3–8 intra units) would have hit the same refusal.

This is the factory behaving as designed (the continuity guard
caught a genuinely stale input). The defect was in the battery's
planned topology, not the product. Cross-check against the
persisted G9 full-run DB showed G9's proven topology: 03.12 and
04.12 carried NO planned inputs; only 05.12–08.12 took the canon —
the self-supersession never arose.

Correction applied to the driver for the clean run:
- 03.12 / 04.12 exits: no canon input (G9 topology).
- 05.12–08.12 exits and step 3–8 intra units: the CURRENT
  canon_manifest resolved at plan time (never a pinned stale id).
- drive_until treats REPAIR_REQUIRED as drive-terminal and logs
  every occurrence into progress.repair_required_seen; any
  REPAIR_REQUIRED outcome in the clean run is reported in the B1
  accounting with its evaluation evidence, not repaired away.
