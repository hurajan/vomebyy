# MM-10 findings — media data-plane + reference-check breaks

Surfaced only at full 192-operation chain scale (MM-06 verified
media actions in isolation; MM-07 verified the reference check on
text artifacts; no prior gate ran media-bearing or attest-bearing
artifacts through the whole chain). Both are recorded as battery
findings with stored evidence; neither was worked around.

## F-MM10-01 — media data-plane discontinuity (10 ops BLOCKED_EXECUTION)

The MM-06 media actions resolve inputs by artifact sha256 -> store
bytes -> ffprobe (`_media_inputs`). Worker-produced artifacts are
registered with the sha of their composed JSON content, so a media
operation downstream of ANY worker-produced artifact can never
resolve a media input through the executor path: the bytes it
needs live in the store under the media object's own sha, which no
artifact row carries. Operator registration cannot fix it through
the API (content is a JSON string; register_artifact hashes the
content bytes). All ten MEDIA_TOOL operations (12.05, 12.06,
12.07, 12.08, 13.03, 13.05, 13.08, 14.06, 14.07, 14.08) refused
with "no input artifact resolves to media bytes in the artifact
store" on every attempt and dead-lettered. Evidence:
plan_action_attempts FAILED rows (error text), classification
rows BLOCKED_EXECUTION.

## F-MM10-02 — references_resolve vs worker-computed digests (13 ops BLOCKED_EVAL_DETERMINISTIC)

The evaluation service's deterministic references_resolve check
requires every 64-hex string in an output's content to be the sha
of a CURRENT artifact in the production (or the artifact's own
sha). Two legitimate worker outputs can never satisfy that:

- media outputs embed the store object's sha (media_output
  storage_uri / sha256) — a store digest, not an artifact sha:
  the four AI_MEDIA operations (10.10, 11.04, 11.06, 11.11)
  EXECUTED (real lavfi bytes generated, stored, probe-valid) and
  were then BLOCKED on sha_not_current.
- hash-attest / content-analyze actions embed digests they
  computed (derived.records.attest.attestation_sha256;
  derived.content.analyze.analyses[i].sha256): nine operations
  (06.02, 09.01, 10.01, 11.01, 13.01, 13.10, 15.01, 15.03, 15.05)
  executed, composed, and were BLOCKED on the same rule.

Evidence: quality_evaluations deterministic_checks FAIL rows
naming the exact paths/values (reproduced in the classification
detail). The check's intent (no dangling artifact references) is
sound; its treatment of computed digests and store shas as
artifact references is the break. Any fix is a product decision
for a later gate (e.g. exempting store:// URIs and known digest
fields, or registering media objects as artifacts) — out of
MM-10's enabling scope and deliberately not patched mid-battery.
