"""MM-10 battery setup: build the mm10_scratch stack and seed the
test-mode mock policy set (LOCK_MM10 sections 3-4).

- station trees g4..g8 setup_env.py (workflow sync; each leaves the
  shared services pointed at its own scratch DB)
- mm10_scratch built via the g3 wrapper over the g2 setup (registry
  1.0.0 + migrations through 018 + plans at the MM-10 plans_hash)
- API (8730) + worker service (8795) + evaluation service (8796)
  restarted onto mm10_scratch
- MM-03 registry seeder run for real (catalog + PROPOSED policies —
  inert for claims), then the MM-10 mock fixtures: provider 'mock',
  four fixture models, ACTIVE mock policies + ACTIVE mock assignments
  for the 78 AI-class operations, policy_events recording the fixture
  activation and why the promotion path was not used
- STATION deterministic-local bindings x6 (est 100, reported 90)
- OPERATION mock bindings x89 (78 AI-class + 11 EXTERNAL_SERVICE),
  est = MM-01 max_cost_cents, params {test_only: true}

The DB password is regex-extracted from the canonical fixture
(g2 tools/setup_db.py) and never printed.
"""
import json
import re
import subprocess
import sys
import time
import urllib.request
from pathlib import Path

HOME = Path.home() / "workspace"
PROG = HOME / "video-factory-real-ai-programme"
MM = HOME / "video-factory-master-programme"
DBNAME = "mm10_scratch"
API = "http://127.0.0.1:8730"
TOKENS = {"FACTORY_OPERATOR_TOKEN": "dev-operator-token",
          "FACTORY_WORKER_TOKEN": "dev-worker-token",
          "FACTORY_SCHEDULER_TOKEN": "dev-scheduler-token",
          "FACTORY_VALIDATOR_TOKEN": "dev-validator-token",
          "FACTORY_CALLBACK_TOKEN": "dev-callback-token"}

_pw = re.search(r"password=([^\s\"']+)",
                (HOME / "video-factory-g9/tools/setup_fullrun.py")
                .read_text()).group(1)
DSN = f"host=127.0.0.1 dbname={DBNAME} user=factory password={_pw}"


def run(cmd, **kw):
    print("+", " ".join(str(c) for c in cmd), flush=True)
    subprocess.run(cmd, check=True, **kw)


def up(url):
    try:
        with urllib.request.urlopen(url, timeout=3) as r:
            return r.status == 200
    except Exception:
        return False


def wait_up(url, timeout=40):
    for _ in range(timeout):
        if up(url):
            return
        time.sleep(1)
    raise SystemExit(f"{url} did not come up")


def api_call(method, path, body=None):
    req = urllib.request.Request(API + path, method=method)
    req.add_header("X-Operator-Token", TOKENS["FACTORY_OPERATOR_TOKEN"])
    data = None
    if body is not None:
        data = json.dumps(body).encode()
        req.add_header("Content-Type", "application/json")
    with urllib.request.urlopen(req, data=data, timeout=30) as r:
        return json.loads(r.read() or b"{}")


def main():
    subprocess.run(["pg_ctlcluster", "16", "main", "start"],
                   capture_output=True)
    for tree in ("video-factory-g4", "video-factory-g5",
                 "video-factory-g6", "video-factory-g7",
                 "video-factory-g8"):
        run([sys.executable, str(HOME / tree / "tools" / "setup_env.py")])
    run([sys.executable,
         str(HOME / "video-factory-g3/tools/setup_db.py"), DBNAME])

    # MM-03 registry seeder (real catalog + PROPOSED governance data).
    run([sys.executable,
         str(MM / "mm-gate-03/tools/seed_registry.py"), DBNAME])

    # Restart the three services onto mm10_scratch.
    for port in (8730, 8795, 8796):
        subprocess.run(["fuser", "-k", f"{port}/tcp"], capture_output=True)
    time.sleep(1)
    base_env = {"PATH": "/usr/bin:/bin:/usr/local/bin",
                "HOME": str(Path.home()), "USER": "root"}
    subprocess.Popen(
        [str(HOME / "video-factory-g3/.venv/bin/python"),
         str(HOME / "video-factory-g3/api/server.py")],
        stdout=open("/tmp/mm10-api.log", "wb"), stderr=subprocess.STDOUT,
        start_new_session=True,
        env={**base_env, "FACTORY_DSN": DSN, "FACTORY_PORT": "8730",
             **TOKENS})
    wait_up(API + "/health")
    print("api: up (mm10_scratch)", flush=True)
    venv_py = str(HOME / "video-factory-g2/.venv/bin/python")
    subprocess.Popen(
        [venv_py, str(PROG / "gate-c/worker_service/service.py")],
        stdout=open("/tmp/mm10-worker.log", "wb"),
        stderr=subprocess.STDOUT, start_new_session=True,
        env={**base_env, "WORKER_SERVICE_PORT": "8795",
             "WORKER_ENVIRONMENT": "test", "WORKER_DSN": DSN,
             "FACTORY_API_URL": API,
             "FACTORY_WORKER_TOKEN": TOKENS["FACTORY_WORKER_TOKEN"]})
    subprocess.Popen(
        [venv_py, str(PROG / "gate-e/evaluation_service/service.py")],
        stdout=open("/tmp/mm10-eval.log", "wb"),
        stderr=subprocess.STDOUT, start_new_session=True,
        env={**base_env, "FACTORY_DSN": DSN, "FACTORY_API_URL": API,
             "FACTORY_VALIDATOR_TOKEN": TOKENS["FACTORY_VALIDATOR_TOKEN"],
             "FACTORY_EVAL_PORT": "8796"})
    wait_up("http://127.0.0.1:8795/health")
    wait_up("http://127.0.0.1:8796/health")
    print("worker + evaluation: up (mm10_scratch)", flush=True)

    # STATION bindings (deterministic-local, G9 accounting shape).
    for station in (1, 2, 3, 4, 5, 6):
        api_call("POST", "/configs", {
            "scope": "STATION", "station": station, "environment": "test",
            "provider": "deterministic-local", "est_cost_cents": 100,
            "params": {"reported_actual_cents": 90}})
    print("station bindings seeded", flush=True)

    # OPERATION mock bindings for the 89 mock-bound operations.
    classification = json.loads(
        (MM / "mm-gate-01/evidence/classification.json").read_text())
    by_op = {r["operation_id"]: r for r in classification["rows"]}
    mock_ops = [op for op, r in by_op.items()
                if r["execution_class"] in
                ("AI_TEXT", "AI_MEDIA", "AI_EVAL", "MIXED",
                 "EXTERNAL_SERVICE")]
    assert len(mock_ops) == 89, len(mock_ops)
    for op in sorted(mock_ops):
        api_call("POST", "/configs", {
            "scope": "OPERATION", "operation_id": op,
            "environment": "test", "provider": "mock",
            "est_cost_cents": by_op[op]["max_cost_cents"],
            "params": {"test_only": True, "source": "mm10-mock-policy"}})
    print(f"operation mock bindings seeded: {len(mock_ops)}", flush=True)

    # MM-03-style registry fixtures for the mock policy set (SQL —
    # promotion hardcodes the OpenRouter provider and is reserved
    # for MM-12; see LOCK_MM10 section 4).
    sys.path.insert(0, str(HOME / "video-factory-g2"))
    import psycopg
    selection = json.loads(
        (MM / "mm-gate-02/evidence/selection.json").read_text())
    sel = {r["operation_id"]: r
           for r in selection["assignments"] + selection["null_assignments"]}
    ai_ops = [op for op in mock_ops
              if by_op[op]["execution_class"] != "EXTERNAL_SERVICE"]
    assert len(ai_ops) == 78, len(ai_ops)

    def role_of(op):
        role = sel.get(op, {}).get("assigned_role")
        if role and role != "none":
            return role
        cls = by_op[op]["execution_class"]
        if cls == "AI_EVAL":
            return "EVALUATION"
        if cls == "AI_MEDIA":
            return "MM06_SPECIALIZED_PROVIDER"
        return f"STATION_0{by_op[op]['station']}"

    def model_of(op):
        if role_of(op) == "EVALUATION":
            return "mock/eval-1"
        if op == "10.10":
            return "mock/media-image-1"
        if role_of(op) == "MM06_SPECIALIZED_PROVIDER":
            return "mock/media-video-1"
        return "mock/creative-text-1"

    roles = sorted({role_of(op) for op in ai_ops})
    with psycopg.connect(DSN) as conn, conn.cursor() as cur:
        cur.execute(
            "INSERT INTO providers(name, adapter, credential_ref, status)"
            " VALUES ('mock', 'mock', NULL, 'enabled')"
            " ON CONFLICT (name) DO NOTHING")
        for mid, mod in (("mock/creative-text-1", "text"),
                         ("mock/media-image-1", "image"),
                         ("mock/media-video-1", "video"),
                         ("mock/eval-1", "text")):
            cur.execute(
                "INSERT INTO models(model_id, provider, name,"
                " context_length, modalities, catalog_version,"
                " provenance) VALUES (%s, 'mock', %s, 8192, %s,"
                " 'mm10-mock-1.0.0', %s) ON CONFLICT (model_id)"
                " DO NOTHING",
                (mid, mid,
                 json.dumps({"input": ["text"], "output": [mod]}),
                 "MM-10 battery fixture model — SIMULATED provider; "
                 "no such hosted model exists or is contacted."))
        for role in roles:
            pid = f"mm10-mock-policy-{role}"
            primary = ("mock/eval-1" if role == "EVALUATION" else
                       "mock/media-video-1"
                       if role == "MM06_SPECIALIZED_PROVIDER" else
                       "mock/creative-text-1")
            cur.execute(
                "INSERT INTO model_policies(policy_id, role, station,"
                " primary_model, fallback_model, evaluation_model,"
                " version, status, created_by) VALUES (%s, %s, %s,"
                " %s, NULL, 'mock/eval-1', 'mm10-mock-1.0.0', 'ACTIVE',"
                " 'mm10-battery-fixture') ON CONFLICT (role, version)"
                " DO NOTHING",
                (pid, role,
                 int(role[-1]) if role.startswith("STATION_0") else None,
                 primary))
            cur.execute(
                "INSERT INTO policy_events(policy_id, action, actor,"
                " note, payload) VALUES (%s, 'PROMOTE',"
                " 'mm10-battery-fixture', %s, %s)",
                (pid,
                 "MM-10 battery fixture activation (test DB only). "
                 "NOT an owner promotion: the registry promotion path "
                 "hardcodes provider openrouter-compatible + credential "
                 "OPENROUTER_API_KEY and is reserved for MM-12 owner "
                 "approval (MULTI_MODEL Rule 11). This row records a "
                 "simulated policy set bound to the 'mock' provider "
                 "for the MM-10 mock acceptance battery.",
                 json.dumps({"matrix_version": "mm10-mock-1.0.0",
                             "simulated": True})))
        for op in ai_ops:
            cur.execute(
                "INSERT INTO operation_model_assignments(operation_id,"
                " role, policy_id, station, execution_class,"
                " primary_model, fallback_model, evaluation_model,"
                " matrix_version, max_cost_cents, cost_source, status)"
                " VALUES (%s, %s, %s, %s, %s, %s, NULL, 'mock/eval-1',"
                " 'mm10-mock-1.0.0', %s, 'MM10_FIXTURE', 'ACTIVE')",
                (op, role_of(op), f"mm10-mock-policy-{role_of(op)}",
                 by_op[op]["station"], by_op[op]["execution_class"],
                 model_of(op), by_op[op]["max_cost_cents"]))
        conn.commit()
        n = cur.execute(
            "SELECT count(*) FROM operation_model_assignments"
            " WHERE status='ACTIVE' AND matrix_version="
            " 'mm10-mock-1.0.0'").fetchone()[0]
    print(f"mock registry fixtures: {len(roles)} policies, "
          f"{n} ACTIVE assignments", flush=True)
    print("SETUP COMPLETE", flush=True)


if __name__ == "__main__":
    main()
