"""MM-10 repair wave 3 — records-fixture inputs for starved
generic plans. Census (from plan_action_attempts): a family of
FULLY_BOUND deterministic operations dead-lettered on input shape
— records.extract 'no input artifact yields records',
records.metrics 'no numeric values', records.index 'record 0 has
no id field', records.project 'cannot project a non-object
record'. Their registry input contracts describe source-material
records; the battery fed them only a step-anchor artifact (a
composed document). This wave registers ONE operator source-records
fixture (the canon-manifest pattern: operator-provided source
material) and replans those operations with it as an input.

Excluded by design: plans carrying an UNBOUND action (semantic /
human — unrepairable by inputs) and the media family (a separate
data-plane finding; see results/media_dataplane_finding.md).
Also settles unit 09.11 (left CLAIMED at sweep time)."""
import json
import sys
import time
from pathlib import Path

MM10 = Path.home() / "workspace/video-factory-master-programme/mm-gate-10"
sys.path.insert(0, str(MM10 / "harness"))
import mm10_driver as D  # noqa: E402

RESULTS = D.RESULTS
PID = "8aa4e602-d1ee-4034-99a3-75f86416f8e0"
D.PID = PID
D.DRIVE_TERMINAL = D.DRIVE_TERMINAL + ("CANCELLED",)
REPAIR_RUN = "fabc3936-6e7e-49c3-adad-67cba20e3ef6"
PLANS = {p["operation_id"]: p for p in json.loads(
    (Path.home() / "workspace/video-factory-g1/seed-definitions"
     / "workflow-1.0.0/plans.json").read_text())["plans"]}

FIXTURE = {"records": [
    {"id": f"R{i:02d}", "title": f"Harbour record {i}",
     "topic": topic, "day": i, "date": f"2026-03-{i:02d}",
     "duration_s": 20 + 5 * i, "amount_cents": 100 * i,
     "score": 50 + i, "status": "logged"}
    for i, topic in enumerate(
        ["premise", "canon", "character", "location", "beat",
         "shot", "sound", "edit", "rights", "derivative",
         "archive", "release"], start=1)]}


def main():
    # Settle 09.11 (CLAIMED, attempt 3, human.decision UNBOUND):
    # dispatch its live claim so the refusal lands and the unit
    # reaches its terminal BLOCKED state.
    stuck = D.sql("SELECT unit_id FROM execution_units WHERE"
                  " production_id=%s AND operation_id='09.11' AND"
                  " state='CLAIMED'", (PID,))
    for u in stuck:
        for _ in range(6):
            D.dispatch(u["unit_id"], "09.11", 4)
            D.service_cycles()
            st = D.unit_states(PID)[u["unit_id"]]["state"]
            if st not in ("CLAIMED", "RUNNING", "VALIDATING"):
                break
            time.sleep(2)
    print("09.11 settled:",
          [u["state"] for u in D.unit_states(PID).values()
           if u["operation_id"] == "09.11"], flush=True)

    # Register the source-records fixture (operator source material).
    s, a = D.call("POST", f"/productions/{PID}/artifacts",
                  {"artifact_type": "source_records",
                   "content": json.dumps(FIXTURE),
                   "storage_uri": "local://mm10-source-records"})
    assert s == 201, f"fixture register {s}: {a}"
    fixture_id = a["artifact_id"]
    print("fixture:", fixture_id, flush=True)

    # Candidate ops: final unit BLOCKED + plan FULLY_BOUND.
    states = D.unit_states(PID)
    by_op = {}
    for u in states.values():
        by_op.setdefault(u["operation_id"], []).append(u)
    candidates = []
    for op, us in by_op.items():
        if any(u["state"] == "ACCEPTED" for u in us):
            continue
        if not any(u["state"] == "BLOCKED" for u in us):
            continue
        if PLANS[op]["binding_status"] != "FULLY_BOUND":
            continue
        # media family excluded (data-plane finding): MM-06 media
        # actions and the MM-10 mock media generator alike
        if any((act.get("implementation") or "").startswith(
                ("media.", "mock.media"))
               for act in PLANS[op]["actions"]):
            continue
        candidates.append(op)
    candidates.sort()
    print("candidates:", len(candidates), candidates, flush=True)

    canon = D.current_artifact(PID, "canon_manifest")
    exit_art = {}
    for step in range(1, 17):
        ss = f"{step:02d}"
        row = D.sql("SELECT a.artifact_id FROM artifacts a JOIN"
                    " execution_units u ON u.unit_id="
                    " a.produced_by_unit WHERE u.production_id=%s"
                    " AND u.operation_id=%s AND u.state='ACCEPTED'"
                    " AND a.state='CURRENT'",
                    (PID, D.EXITS[ss]), one=True)
        if row:
            exit_art[ss] = row["artifact_id"]
    planned = {}
    existing_r3 = {r["operation_id"]: r["unit_id"] for r in D.sql(
        "SELECT operation_id, unit_id FROM execution_units WHERE"
        " production_id=%s AND unit_key='main-r3'", (PID,))}
    for op in candidates:
        if op in existing_r3:
            planned[op] = existing_r3[op]
            continue
        step = D.OPS[op]["step_id"]
        inputs = [fixture_id]
        if exit_art.get(step):
            inputs.append(exit_art[step])
        if step in ("03", "04", "05", "06", "07", "08") and canon:
            inputs.append(canon["artifact_id"])
        inputs = list(dict.fromkeys(inputs))
        s, u = D.call("POST", f"/productions/{PID}/units",
                      {"operation_id": op, "run_id": REPAIR_RUN,
                       "unit_key": "main-r3", "depends_on": [],
                       "input_artifact_ids": inputs})
        assert s == 201, f"plan r3 {op}: {s} {u}"
        planned[op] = u["unit_id"]
    print("planned:", len(planned), flush=True)
    D.drive_until(PID, set(candidates), max_rounds=120,
                  label="repair3-records")
    after = {}
    for op in candidates:
        u = [x for x in D.unit_states(PID).values()
             if x["unit_id"] == planned[op]][0]
        after[op] = u["state"]
    (RESULTS / "repair3_records.json").write_text(json.dumps({
        "fixture_artifact_id": fixture_id,
        "candidates": candidates, "states_after": after,
        "accepted": sorted(op for op, st in after.items()
                           if st == "ACCEPTED"),
        "still_blocked": sorted(op for op, st in after.items()
                                if st != "ACCEPTED")}, indent=1))
    print("after:", after, flush=True)
    print("REPAIR3 DONE", flush=True)


if __name__ == "__main__":
    main()
