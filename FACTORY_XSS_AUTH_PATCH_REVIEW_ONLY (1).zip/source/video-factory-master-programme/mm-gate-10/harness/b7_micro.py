"""MM-10 B7 micro-run: two one-unit productions under lane cap 1,
interleaved prestage+dispatch rounds with recorded wall-clock
bounds; concurrency measured on unit RUNNING intervals from
audit_events (state transitions), the precise notion of execution
overlap. Cap restored to 4 afterwards."""
import json
import sys
import time
from pathlib import Path

MM10 = Path.home() / "workspace/video-factory-master-programme/mm-gate-10"
sys.path.insert(0, str(MM10 / "harness"))
import mm10_driver as D  # noqa: E402

RESULTS = D.RESULTS
D.DRIVE_TERMINAL = D.DRIVE_TERMINAL + ("CANCELLED",)


def mkprod(title):
    s, p = D.call("POST", "/productions",
                  {"title": title, "hard_ceiling_cents": 50000,
                   "soft_ceiling_cents": 45000})
    pid = p["production_id"]
    s, r = D.call("POST", f"/productions/{pid}/runs", {"kind": "FULL"})
    return pid, r["run_id"]


def running_intervals(pid):
    rows = D.sql(
        "SELECT unit_id, old_state, new_state, created_at FROM"
        " audit_events WHERE production_id=%s ORDER BY created_at",
        (pid,))
    intervals = []
    open_since = {}
    for r in rows:
        if r["new_state"] == "RUNNING":
            open_since[r["unit_id"]] = r["created_at"]
        elif r["old_state"] == "RUNNING" and r["unit_id"] in open_since:
            intervals.append((open_since.pop(r["unit_id"]),
                              r["created_at"]))
    return intervals


def max_overlap(intervals):
    events = []
    for s_, f_ in intervals:
        events.append((s_, 1))
        events.append((f_, -1))
    events.sort(key=lambda e: (e[0], -e[1]))
    cur = mx = 0
    for _t, d_ in events:
        cur += d_
        mx = max(mx, cur)
    return mx


def main():
    pa, ra = mkprod("MM-10 B7 micro A")
    pb, rb = mkprod("MM-10 B7 micro B")
    for pid, run in ((pa, ra), (pb, rb)):
        s, u = D.call("POST", f"/productions/{pid}/units",
                      {"operation_id": "01.01", "run_id": run,
                       "unit_key": "main", "depends_on": [],
                       "input_artifact_ids": []})
        assert s == 201, u
    D.sql_exec("UPDATE capacity_policies SET max_concurrency=1"
               " WHERE lane='text'")
    t0 = time.time()
    for _ in range(12):
        D.prestage()
        for pid in (pa, pb):
            D.PID = pid
            for uid, u in D.unit_states(pid).items():
                if u["state"] in ("READY", "CLAIMED"):
                    D.dispatch(uid, u["operation_id"], 1)
        D.service_cycles()
        D.handle_humans(pa)
        D.handle_humans(pb)
        time.sleep(0.5)
    t1 = time.time()
    D.sql_exec("UPDATE capacity_policies SET max_concurrency=4"
               " WHERE lane='text'")
    iv = running_intervals(pa) + running_intervals(pb)
    ivw = [(s_, f_) for s_, f_ in iv
           if s_.timestamp() <= t1 and f_.timestamp() >= t0]
    out = {"window": {"t0": t0, "t1": t1, "cap": 1},
           "running_intervals_in_window": len(ivw),
           "max_simultaneous_running": max_overlap(ivw),
           "a_states": {u["operation_id"]: u["state"]
                        for u in D.unit_states(pa).values()},
           "b_states": {u["operation_id"]: u["state"]
                        for u in D.unit_states(pb).values()},
           "method": "unit RUNNING intervals from audit_events"
                     " state transitions within the recorded window"
                     " — the precise execution-overlap measure"
                     " (attempt lifetimes and VALIDATING periods"
                     " excluded)"}
    (RESULTS / "b7_micro.json").write_text(json.dumps(out, indent=1,
                                                      default=str))
    print(json.dumps(out, indent=1, default=str), flush=True)
    print("B7 MICRO DONE", flush=True)


if __name__ == "__main__":
    main()
