"""MM-10 B6 follow-up: the cascade-planned replacement 12.12 sat in
PENDING because the invalidate path never calls
recompute_readiness (plan_unit and the acceptance path do). Promote
readiness through the coordinator service surface (the same call
the Gate F services make), then drive the replacement to ACCEPTED
and refresh the B6 record."""
import json
import sys
from pathlib import Path

MM10 = Path.home() / "workspace/video-factory-master-programme/mm-gate-10"
sys.path.insert(0, str(MM10 / "harness"))
sys.path.insert(0, str(Path.home() / "workspace/video-factory-g2"))
import mm10_driver as D  # noqa: E402

RESULTS = D.RESULTS
old = json.loads((RESULTS / "progress.json").read_text())
PID = old["master_production_id"]
D.PID = PID
D.DRIVE_TERMINAL = D.DRIVE_TERMINAL + ("CANCELLED",)

sys.path.insert(0, str(Path.home()
                       / "workspace/video-factory-g2/coordinator"))
import coordinator as _coord_mod  # noqa: E402
coord = _coord_mod.Coordinator(D.DSN, actor="operator",
                               environment="test")
coord.recompute_readiness(PID)
repl = D.sql("SELECT unit_id, state FROM execution_units WHERE"
             " production_id=%s AND operation_id='12.12' AND"
             " state='READY'", (PID,))
print("replacements READY after recompute:", repl, flush=True)
D.drive_until(PID, {"12.12"}, label="b6-replacement-drive")
rec = json.loads((RESULTS / "b6_selective_regeneration.json")
                 .read_text())
rid = rec["cascade_replacements"][0]["unit_id"]
rec["replacement_final"] = D.unit_states(PID)[rid]
rec["replacement_readiness_note"] = (
    "The cascade-planned replacement sat in PENDING: the invalidate"
    " path does not call recompute_readiness (plan_unit and the"
    " acceptance transition do). Readiness was promoted via the"
    " coordinator's recompute_readiness (service surface), then the"
    " replacement was driven normally.")
rec["timeline_current_after"] = D.current_artifact(PID,
                                                   "edit_timeline")
(RESULTS / "b6_selective_regeneration.json").write_text(
    json.dumps(rec, indent=1, default=str))
print("replacement final:", rec["replacement_final"], flush=True)
print("timeline current:", rec["timeline_current_after"], flush=True)
print("B6 FOLLOWUP DONE", flush=True)
