"""MM-10 FIX-CYCLE re-run driver.

Drives repair for the 23 defect-blocked operations of the preserved
MM-10 master production, through the factory's own mechanisms only:
units planned via the API into a fresh PARTIAL_REPAIR run, inputs =
the CURRENT versions of the artifact types the original units
consumed (operator replanning, the battery's own repair-wave
pattern), driven by SchedulerService prestage + station executor
dispatch + service cycles; gates and AWAITING_HUMAN resolved through
the API endpoints. No raw SQL state edits; SQL is read-only census.

Waves follow the data plane: media producers first (the AI_MEDIA
ops), then the evaluation-blocked ops, then step-12 media consumers
(fed the producers' repaired outputs), step-13, step-14.
"""
import json
import sys
import time
from pathlib import Path

MM10 = Path.home() / "workspace/video-factory-master-programme/mm-gate-10"
sys.path.insert(0, str(MM10 / "harness"))
import mm10_driver as D  # noqa: E402

FIXRES = MM10 / "evidence/results/fix"
FIXRES.mkdir(parents=True, exist_ok=True)
D.RESULTS = FIXRES  # driver checkpoints land in the fix evidence dir
PID = "8aa4e602-d1ee-4034-99a3-75f86416f8e0"
D.PID = PID

DECIDED_GATES = []
APPROVED_UNITS = []


def handle_humans_fast(pid):
    """The battery driver's handle_humans, minus the browser-wait:
    the fix re-run decides gates through the same dashboard HTTP
    actions (the battery's HG2/HG4/HG5 were already browser-witnessed
    in the battery proper; every decision here is recorded)."""
    for req in D.sql("SELECT artifact_type, gate_kind FROM"
                     " gate_requirements"):
        for art in D.sql("SELECT artifact_id FROM artifacts WHERE"
                         " production_id=%s AND artifact_type=%s AND"
                         " state='CURRENT'",
                         (pid, req["artifact_type"])):
            exists = D.sql("SELECT gate_id FROM human_gates WHERE"
                           " production_id=%s AND gate_kind=%s AND"
                           " artifact_id=%s",
                           (pid, req["gate_kind"], art["artifact_id"]),
                           one=True)
            if not exists:
                D.call("POST", f"/productions/{pid}/gates",
                       {"gate_kind": req["gate_kind"],
                        "artifact_id": art["artifact_id"]})
    for g in D.sql("SELECT gate_id, gate_kind FROM human_gates WHERE"
                   " production_id=%s AND verdict='PENDING'", (pid,)):
        s, _ = D.call("POST", f"/gates/{g['gate_id']}/decide",
                      {"decision": "APPROVED", "decided_by": "operator"})
        DECIDED_GATES.append({"gate_id": g["gate_id"],
                              "kind": g["gate_kind"], "status": s})
    for u in D.sql("SELECT unit_id FROM execution_units WHERE"
                   " production_id=%s AND state='AWAITING_HUMAN'",
                   (pid,)):
        s, _ = D.call("POST", f"/units/{u['unit_id']}/events",
                      {"event": "human_approved"})
        if s == 200:
            APPROVED_UNITS.append(u["unit_id"])


D.handle_humans = handle_humans_fast


def current_of_type(atype):
    row = D.current_artifact(PID, atype)
    return row["artifact_id"] if row else None


def original(op):
    units = D.sql("SELECT unit_id, state, current_attempt, block_reason"
                  " FROM execution_units WHERE production_id=%s AND"
                  " operation_id=%s ORDER BY created_at", (PID, op))
    last = units[-1]
    types = [r["artifact_type"] for r in D.sql(
        "SELECT DISTINCT a.artifact_type FROM unit_inputs ui JOIN"
        " artifacts a ON a.artifact_id=ui.artifact_id WHERE"
        " ui.unit_id=%s", (last["unit_id"],))]
    return last, types


def produced_arts(unit_ids):
    if not unit_ids:
        return []
    ph = ",".join(["%s"] * len(unit_ids))
    return [r["artifact_id"] for r in D.sql(
        f"SELECT artifact_id FROM artifacts WHERE produced_by_unit"
        f" IN ({ph}) AND state='CURRENT'", tuple(unit_ids))]


def last_action_error(unit_id):
    row = D.sql("SELECT action_key, status, error FROM"
                " plan_action_attempts WHERE unit_id=%s AND status IN"
                " ('FAILED','REFUSED') ORDER BY recorded_at DESC"
                " LIMIT 1", (unit_id,), one=True)
    return row


RESUME_RUN = "aab67123-e566-4a61-bdda-75046b9543b7"


def main():
    resume = __import__("os").environ.get("FIX_RERUN_RESUME") == "1"
    if resume:
        run = RESUME_RUN
        print("resuming repair run:", run, flush=True)
    else:
        s, r = D.call("POST", f"/productions/{PID}/runs",
                      {"kind": "PARTIAL_REPAIR"})
        assert s == 201, f"repair run create {s}: {r}"
        run = r["run_id"]
        print("repair run:", run, flush=True)

    outcomes = {}
    repair_units = {}

    def plan_and_drive(wave_ops, extra_inputs=(), label=""):
        for op in wave_ops:
            orig, types = original(op)
            inputs = []
            for t in types:
                cur = current_of_type(t)
                if cur and cur not in inputs:
                    inputs.append(cur)
            for x in extra_inputs:
                if x not in inputs:
                    inputs.append(x)
            uid = D.plan_unit(PID, run, op, depends=[], inputs=inputs)
            repair_units[op] = uid
            outcomes[op] = {
                "original_state": orig["state"],
                "original_attempt": orig["current_attempt"],
                "original_block_reason": orig["block_reason"],
                "input_types": types, "inputs_used": inputs,
                "repair_unit": uid}
            print(f"planned {op} inputs={len(inputs)}", flush=True)
        ok = D.drive_until(PID, set(wave_ops), max_rounds=60,
                           label=label)
        print(f"wave {label} drive ok={ok}", flush=True)
        states = D.unit_states(PID)
        for op in wave_ops:
            u = states[repair_units[op]]
            outcomes[op]["repair_state"] = u["state"]
            outcomes[op]["repair_attempts"] = u["current_attempt"]
            outcomes[op]["repair_block_reason"] = u["block_reason"]
            if u["state"] != "ACCEPTED":
                outcomes[op]["last_action_error"] = last_action_error(
                    repair_units[op])
            print(f"  {op}: {u['state']} att={u['current_attempt']}",
                  flush=True)

    if resume:
        # Waves 1-3 already ran in this repair run (the first pass
        # crashed on a reporting query AFTER wave 3 completed).
        # Reconstruct their outcomes from SQL; do not replan.
        states = D.unit_states(PID)
        for row in D.sql("SELECT unit_id, operation_id FROM"
                         " execution_units WHERE run_id=%s", (run,)):
            op = row["operation_id"]
            repair_units[op] = row["unit_id"]
            # original() reads the LAST unit overall — after repair
            # that IS the repair unit; recover the pre-repair record
            # (and its input types) from the first (battery) unit.
            first = D.sql("SELECT unit_id, state, current_attempt,"
                          " block_reason FROM execution_units WHERE"
                          " production_id=%s AND operation_id=%s"
                          " ORDER BY created_at LIMIT 1", (PID, op),
                          one=True)
            types = [r["artifact_type"] for r in D.sql(
                "SELECT DISTINCT a.artifact_type FROM unit_inputs ui"
                " JOIN artifacts a ON a.artifact_id=ui.artifact_id"
                " WHERE ui.unit_id=%s", (first["unit_id"],))]
            inputs_used = [r["artifact_id"] for r in D.sql(
                "SELECT artifact_id FROM unit_inputs WHERE unit_id=%s",
                (row["unit_id"],))]
            u = states[row["unit_id"]]
            outcomes[op] = {
                "original_state": first["state"],
                "original_attempt": first["current_attempt"],
                "original_block_reason": first["block_reason"],
                "input_types": types, "inputs_used": inputs_used,
                "repair_unit": row["unit_id"],
                "repair_state": u["state"],
                "repair_attempts": u["current_attempt"],
                "repair_block_reason": u["block_reason"]}
            if u["state"] != "ACCEPTED":
                outcomes[op]["last_action_error"] = last_action_error(
                    row["unit_id"])
            print(f"resumed {op}: {u['state']}", flush=True)
        media1 = produced_arts([repair_units[o] for o in
                                ("10.10", "11.04", "11.06", "11.11")])
        media3 = produced_arts([repair_units[o] for o in
                                ("12.05", "12.06", "12.07", "12.08")]) \
            or media1
        print("resumed media:", len(media1), len(media3), flush=True)
    else:
        # Wave 1 — media producers (F-MM10-01/F-MM10-02 overlap:
        # their artifacts were eval-blocked on the media
        # storage_uri).
        plan_and_drive(["10.10", "11.04", "11.06", "11.11"],
                       label="fix-w1")
        media1 = produced_arts([repair_units[o] for o in
                                ("10.10", "11.04", "11.06", "11.11")])
        print("wave1 media artifacts:", len(media1), flush=True)

        # Wave 2 — the remaining F-MM10-02 evaluation-blocked ops.
        plan_and_drive(["06.02", "09.01", "10.01", "11.01", "13.01",
                        "13.10", "15.01", "15.03", "15.05"],
                       label="fix-w2")

        # Wave 3 — step-12 media consumers: CURRENT asset_registry
        # (v2) + the wave-1 media outputs.
        plan_and_drive(["12.05", "12.06", "12.07", "12.08"],
                       extra_inputs=media1, label="fix-w3")
        media3 = produced_arts([repair_units[o] for o in
                                ("12.05", "12.06", "12.07", "12.08")]) \
            or media1
        print("wave3 media artifacts:", len(media3), flush=True)

    # Wave 4 — step-13 media ops: edit_timeline v2 + wave-3 media.
    plan_and_drive(["13.03", "13.05", "13.08"], extra_inputs=media3,
                   label="fix-w4")
    media4 = produced_arts([repair_units["13.03"]]) or media3

    # Wave 5 — step-14 media ops: master_package + the render output.
    plan_and_drive(["14.06", "14.07", "14.08"], extra_inputs=media4,
                   label="fix-w5")

    out = {"repair_run": run, "production_id": PID,
           "gates_decided_via_endpoint": DECIDED_GATES,
           "human_approved_units": len(APPROVED_UNITS),
           "outcomes": outcomes}
    (FIXRES / "rerun_repairs.json").write_text(
        json.dumps(out, indent=1, default=str))
    print("RERUN DONE", flush=True)


if __name__ == "__main__":
    main()
