"""MM-10 battery driver (LOCK_MM10 sections 5-6).

Drives the master production (all 192 operations) through the real
stack — Gate F scheduler prestage, per-unit dispatch to the station
executor webhooks, worker + evaluation services, RetryDriver and
ReconcilerService cycles — resolving human gates and AWAITING_HUMAN
units through the dashboard's own HTTP actions. HG2/HG4/HG5 are left
for the witnessed browser run (the driver waits on them; see
progress.awaiting_browser_gate).

Checkpoints progress.json after every round; per-item evidence JSONs
land in evidence/results/. All end-state accounting is re-derivable
from SQL — this driver keeps none of it in memory for the verdicts.

Phases: B7 concurrency window first (master + second production),
then the step-by-step main drive (B1) with B5(b) forced failure in
step 02 and the B5(a) n8n kill after step 04, then B6 selective
regeneration, then final sweeps (B2/B3/B4/B8 data + B9 hygiene).
"""
import json
import os
import re
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.request
from pathlib import Path

HOME = Path.home() / "workspace"
PROG = HOME / "video-factory-real-ai-programme"
MM10 = HOME / "video-factory-master-programme/mm-gate-10"
RESULTS = MM10 / "evidence/results"
RESULTS.mkdir(parents=True, exist_ok=True)
API = "http://127.0.0.1:8730"
DBNAME = "mm10_scratch"
OP_TOKEN = "dev-operator-token"

_pw = re.search(r"password=([^\s\"']+)",
                (HOME / "video-factory-g9/tools/setup_fullrun.py")
                .read_text()).group(1)
DSN = f"host=127.0.0.1 dbname={DBNAME} user=factory password={_pw}"

sys.path.insert(0, str(HOME / "video-factory-g2"))
sys.path.insert(0, str(PROG / "gate-f"))
import psycopg  # noqa: E402
from psycopg.rows import dict_row  # noqa: E402
from runtime_services.scheduler_service import SchedulerService  # noqa: E402
from runtime_services.retry_driver import RetryDriver  # noqa: E402
from runtime_services.reconciler_service import ReconcilerService  # noqa: E402
from runtime_services.reaper_service import ReaperService  # noqa: E402

REGISTRY = json.loads(
    (HOME / "video-factory-g1/seed-definitions/workflow-1.0.0"
            / "operations.json").read_text())
OPS = {o["operation_id"]: o for o in REGISTRY["operations"]}
STEP_OPS = {}
for op, o in OPS.items():
    STEP_OPS.setdefault(o["step_id"], []).append(op)
for s in STEP_OPS.values():
    s.sort()
EXITS = {f"{i:02d}": f"{i:02d}.12" for i in range(1, 17)}
EXITS["01"] = "01.12"
EXIT_CHAIN = ["01.01", "01.12"] + [f"{i:02d}.12" for i in range(2, 14)] \
    + ["14.01", "14.12", "15.12", "16.12"]
WEBHOOK = {1: "dispatch", 2: "dispatch", 3: "dispatch-g5",
           4: "dispatch-g6", 5: "dispatch-g7", 6: "dispatch-g8"}
BROWSER_GATES = {"HG2", "HG4", "HG5"}

PROGRESS = {"gate": "MM-10", "started_at": time.strftime(
    "%Y-%m-%dT%H:%M:%SZ", time.gmtime()), "units_terminal": 0,
    "units_total": 192, "phase": "init", "rounds": 0,
    "awaiting_browser_gate": None, "browser_witnessed": [],
    "endpoint_decided_gates": [], "human_approvals_endpoint": 0,
    "notes": []}
_progress_lock = threading.Lock()


def checkpoint(**kw):
    with _progress_lock:
        PROGRESS.update(kw)
        PROGRESS["units_terminal"] = terminal_count()
        PROGRESS["tmp_media_dirs"] = tmp_media_dirs()
        PROGRESS["updated_at"] = time.strftime(
            "%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        tmp = RESULTS / "progress.json.tmp"
        tmp.write_text(json.dumps(PROGRESS, indent=1, default=str))
        tmp.replace(RESULTS / "progress.json")


def tmp_media_dirs():
    return sum(1 for p in Path("/tmp").iterdir()
               if p.is_dir() and (p.name.startswith("mm06")
                                  or p.name.startswith("mm10-mediagen")
                                  or p.name.startswith("media-")))


def sql(q, args=(), one=False):
    import uuid as _uuid
    with psycopg.connect(DSN, row_factory=dict_row) as conn:
        rows = conn.execute(q, args).fetchall()
    for r in rows:
        for k, v in r.items():
            if isinstance(v, _uuid.UUID):
                r[k] = str(v)
    return (rows[0] if rows else None) if one else rows


def sql_exec(q, args=()):
    with psycopg.connect(DSN) as conn:
        conn.execute(q, args)
        conn.commit()


def call(method, path, body=None, timeout=30):
    req = urllib.request.Request(API + path, method=method)
    req.add_header("X-Operator-Token", OP_TOKEN)
    data = None
    if body is not None:
        data = json.dumps(body).encode()
        req.add_header("Content-Type", "application/json")
    try:
        with urllib.request.urlopen(req, data=data, timeout=timeout) as r:
            return r.status, json.loads(r.read() or b"{}")
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read() or b"{}")


PID = None  # master production id, set in main()


def terminal_count(pid=None):
    row = sql("SELECT count(*) n FROM execution_units WHERE"
              " production_id=%s AND state IN"
              " ('ACCEPTED','BLOCKED','SUPERSEDED','FAILED',"
              " 'REPAIR_REQUIRED')",
              (pid or PID,), one=True)
    return row["n"] if row else 0


def unit_states(pid):
    return {r["unit_id"]: r for r in sql(
        "SELECT unit_id, operation_id, state, current_attempt,"
        " block_reason FROM execution_units WHERE production_id=%s",
        (pid,))}


def current_artifact(pid, atype):
    return sql("SELECT artifact_id, artifact_type, version, sha256"
               " FROM artifacts WHERE production_id=%s AND"
               " artifact_type=%s AND state='CURRENT' ORDER BY"
               " version DESC LIMIT 1", (pid, atype), one=True)


def plan_unit(pid, run, op, depends=(), inputs=()):
    s, u = call("POST", f"/productions/{pid}/units",
                {"operation_id": op, "run_id": run, "unit_key": "main",
                 "depends_on": list(depends),
                 "input_artifact_ids": list(inputs)})
    assert s == 201, f"plan {op}: {s} {u}"
    return u["unit_id"]


def prestage():
    return SchedulerService(dsn=DSN).run_once()


def service_cycles():
    RetryDriver(dsn=DSN).run_once()
    ReconcilerService(dsn=DSN).run_once()
    ReaperService(dsn=DSN).run_once()


def dispatch(uid, op, station, force_fail=False):
    payload = {"production_id": PID, "unit_id": uid,
               "operation_id": op, "station": station,
               "input_artifact_ids": [], "force_fail": force_fail,
               "idempotency_key": f"mm10:{uid}:{time.time_ns()}"}
    req = urllib.request.Request(
        f"http://127.0.0.1:5678/webhook/{WEBHOOK[station]}",
        method="POST", data=json.dumps(payload).encode(),
        headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=900) as r:
            return r.status
    except urllib.error.HTTPError as e:
        return e.code
    except Exception as exc:  # n8n killed mid-flight (B5a) etc.
        return f"ERR:{type(exc).__name__}"


def handle_humans(pid, browser_wait_s=900):
    """Decide PENDING gates + approve AWAITING_HUMAN units for pid.
    HG2/HG4/HG5 wait for the browser witness run (progress flag);
    everything goes through the dashboard's own HTTP actions."""
    # Gate creation is an explicit operator action in this factory
    # (the dashboard's Create gate button -> POST
    # /productions/{pid}/gates): a claim against a gated input type
    # refuses until a gate exists for the CURRENT artifact. Create
    # the missing gates for CURRENT gated artifacts, as an operator
    # would, before deciding anything.
    for req in sql("SELECT artifact_type, gate_kind FROM"
                   " gate_requirements"):
        for art in sql("SELECT artifact_id FROM artifacts WHERE"
                       " production_id=%s AND artifact_type=%s AND"
                       " state='CURRENT'", (pid, req["artifact_type"])):
            exists = sql("SELECT gate_id FROM human_gates WHERE"
                         " production_id=%s AND gate_kind=%s AND"
                         " artifact_id=%s",
                         (pid, req["gate_kind"], art["artifact_id"]),
                         one=True)
            if not exists:
                s, _g = call("POST", f"/productions/{pid}/gates",
                             {"gate_kind": req["gate_kind"],
                              "artifact_id": art["artifact_id"]})
                PROGRESS.setdefault("gates_created", []).append(
                    {"kind": req["gate_kind"],
                     "artifact_id": art["artifact_id"], "status": s})
    gates = sql("SELECT gate_id, gate_kind FROM human_gates WHERE"
                " production_id=%s AND verdict='PENDING'", (pid,))
    for g in gates:
        if g["gate_kind"] in BROWSER_GATES and \
                g["gate_id"] not in PROGRESS["browser_witnessed"]:
            checkpoint(awaiting_browser_gate={
                "gate_id": g["gate_id"], "kind": g["gate_kind"],
                "production_id": pid,
                "since": time.strftime("%Y-%m-%dT%H:%M:%SZ",
                                       time.gmtime())})
            deadline = time.time() + browser_wait_s
            while time.time() < deadline:
                row = sql("SELECT verdict FROM human_gates WHERE"
                          " gate_id=%s", (g["gate_id"],), one=True)
                if row and row["verdict"] != "PENDING":
                    PROGRESS["browser_witnessed"].append(g["gate_id"])
                    checkpoint(awaiting_browser_gate=None)
                    break
                time.sleep(5)
            else:
                s, _ = call("POST", f"/gates/{g['gate_id']}/decide",
                            {"decision": "APPROVED",
                             "decided_by": "operator"})
                PROGRESS["endpoint_decided_gates"].append(
                    {"gate_id": g["gate_id"], "kind": g["gate_kind"],
                     "note": "browser wait timed out; decided via the"
                             " dashboard endpoint", "status": s})
                checkpoint(awaiting_browser_gate=None)
        else:
            s, _ = call("POST", f"/gates/{g['gate_id']}/decide",
                        {"decision": "APPROVED",
                         "decided_by": "operator"})
            PROGRESS["endpoint_decided_gates"].append(
                {"gate_id": g["gate_id"], "kind": g["gate_kind"],
                 "status": s})
    for u in sql("SELECT unit_id FROM execution_units WHERE"
                 " production_id=%s AND state='AWAITING_HUMAN'",
                 (pid,)):
        s, _ = call("POST", f"/units/{u['unit_id']}/events",
                    {"event": "human_approved"})
        if s == 200:
            PROGRESS["human_approvals_endpoint"] += 1


DRIVE_TERMINAL = ("ACCEPTED", "BLOCKED", "SUPERSEDED", "FAILED",
                  "REPAIR_REQUIRED")


def drive_until(pid, ops_wanted, max_rounds=80, label=""):
    """Prestage+dispatch rounds until every unit of ops_wanted is in
    a terminal state. REPAIR_REQUIRED counts as drive-terminal: it
    is a stable evaluation outcome, logged in progress for the
    accounting (its repair path is selective regeneration, B6's
    machinery, not redispatch — the unit's planned inputs may be
    stale by construction)."""
    wanted = set(ops_wanted)
    for rnd in range(max_rounds):
        PROGRESS["rounds"] += 1
        prestage()
        states = unit_states(pid)
        for uid, u in states.items():
            # READY: executor claims directly. CLAIMED: the scheduler
            # prestaged a claim for this station's executor identity
            # and the executor adopts it. Both are dispatchable.
            if u["operation_id"] in wanted and u["state"] in \
                    ("READY", "CLAIMED"):
                dispatch(uid, u["operation_id"],
                         OPS[u["operation_id"]]["station"])
        service_cycles()
        handle_humans(pid)
        states = unit_states(pid)
        for u in states.values():
            if u["state"] == "REPAIR_REQUIRED" and \
                    u["operation_id"] not in \
                    PROGRESS.setdefault("repair_required_seen", []):
                PROGRESS["repair_required_seen"].append(
                    u["operation_id"])
        pending = [u["operation_id"] for u in states.values()
                   if u["operation_id"] in wanted
                   and u["state"] not in DRIVE_TERMINAL]
        checkpoint(phase=label or PROGRESS["phase"])
        if not pending:
            return True
        time.sleep(1)
    return False


# ---------------------------------------------------------------- B7
def b7_window(pid2, samples):
    """Concurrency battery (LOCK section 6 B7): capacity_policies is
    the factory's only concurrency control; the per-lane cap stands
    in for the brief's production-concurrency limit. Window 1 runs
    interleaved rounds across BOTH productions under cap 1 (real
    contention, sampled); window 2 raises the cap to 4."""
    stop = threading.Event()

    def sampler():
        while not stop.is_set():
            rows = sql(
                "SELECT production_id, count(*) n FROM execution_units"
                " WHERE state IN ('CLAIMED','RUNNING','VALIDATING')"
                " GROUP BY production_id")
            samples.append({"t": time.time(),
                            "inflight": {r["production_id"]: r["n"]
                                         for r in rows}})
            time.sleep(0.25)

    th = threading.Thread(target=sampler, daemon=True)
    th.start()
    sql_exec("UPDATE capacity_policies SET max_concurrency=1"
             " WHERE lane='text'")
    for _rnd in range(14):
        PROGRESS["rounds"] += 1
        prestage()
        for pid_ in (PID, pid2):
            for uid, u in unit_states(pid_).items():
                if u["state"] in ("READY", "CLAIMED"):
                    dispatch(uid, u["operation_id"],
                             OPS[u["operation_id"]]["station"])
        service_cycles()
        handle_humans(PID)
        handle_humans(pid2)
        checkpoint(phase="b7-window1")
        time.sleep(0.5)
    w1 = {"rounds": 14, "samples": len(samples),
          "max_simultaneous_inflight": max(
              (sum(s["inflight"].values()) for s in samples),
              default=0),
          "samples_with_both_pending": sum(
              1 for s in samples if len(s["inflight"]) >= 1),
          "p1_states": {u["operation_id"]: u["state"]
                        for u in unit_states(PID).values()},
          "p2_states": {u["operation_id"]: u["state"]
                        for u in unit_states(pid2).values()}}
    sql_exec("UPDATE capacity_policies SET max_concurrency=4"
             " WHERE lane='text'")
    return w1, th, stop


def main():
    global PID
    t0 = time.time()
    resume = os.environ.get("MM10_RESUME") == "1" and \
        (RESULTS / "progress.json").exists()
    if resume:
        old = json.loads((RESULTS / "progress.json").read_text())
        PID = old["master_production_id"]
        run = old["master_run_id"]
        canon = old["canon_artifact_id"]
        for k in ("browser_witnessed", "endpoint_decided_gates",
                  "human_approvals_endpoint", "rounds", "exit_states",
                  "gates_created", "repair_required_seen",
                  "b7_production_id"):
            if k in old:
                PROGRESS[k] = old[k]
        PROGRESS["master_production_id"] = PID
        PROGRESS["master_run_id"] = run
        PROGRESS["canon_artifact_id"] = canon
        PROGRESS["resumed_at"] = time.strftime(
            "%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        units = {}
        for u in unit_states(PID).values():
            units[u["operation_id"]] = u["unit_id"]
        exit_artifact = {}
        for step in range(1, 17):
            ss = f"{step:02d}"
            euid = units.get(EXITS[ss])
            if euid:
                art = sql("SELECT artifact_id FROM artifacts WHERE"
                          " produced_by_unit=%s AND state='CURRENT'",
                          (euid,), one=True)
                if art:
                    exit_artifact[ss] = art["artifact_id"]
        checkpoint(phase="resumed")
        _drive_master(run, canon, units, exit_artifact, t0,
                      skip_b5b=(RESULTS / "b5b_forced_failure.json")
                      .exists(),
                      skip_b5a=(RESULTS / "b5a_n8n_kill.json")
                      .exists())
        return
    checkpoint(phase="setup-assert")
    # OBS-1 DSN assertion: create via API, verify the row is in
    # mm10_scratch (and the API therefore points where we think).
    s, p = call("POST", "/productions",
                {"title": "MM-10 master production (mock acceptance)",
                 "hard_ceiling_cents": 500000,
                 "soft_ceiling_cents": 450000})
    assert s == 201, f"production create {s}: {p}"
    PID = p["production_id"]
    row = sql("SELECT production_id FROM productions WHERE"
              " production_id=%s", (PID,), one=True)
    assert row, "DSN ASSERTION FAILED: production not in mm10_scratch"
    PROGRESS["master_production_id"] = PID
    s, r = call("POST", f"/productions/{PID}/runs", {"kind": "FULL"})
    assert s == 201, f"run create {s}: {r}"
    run = r["run_id"]
    PROGRESS["master_run_id"] = run
    # Canon fixture (operator-registered, the G9 topology).
    s, a = call("POST", f"/productions/{PID}/artifacts",
                {"artifact_type": "canon_manifest",
                 "content": CANON,
                 "storage_uri": "local://mm10-canon-fixture"})
    assert s == 201, f"canon register {s}: {a}"
    canon = a["artifact_id"]
    PROGRESS["canon_artifact_id"] = canon
    checkpoint(phase="b7", tmp_media_dirs_start=tmp_media_dirs(),
               disk_free_start=subprocess.run(
                   ["df", "-h", "/tmp"], capture_output=True,
                   text=True).stdout.strip().splitlines()[-1])

    # ---------------- B7 concurrency window ----------------
    plan_unit(PID, run, "01.01")
    u0112_dependencies = sql(
        "SELECT unit_id FROM execution_units WHERE production_id=%s"
        " AND operation_id='01.01'", (PID,), one=True)["unit_id"]
    plan_unit(PID, run, "01.12", depends=[u0112_dependencies])
    s, p2 = call("POST", "/productions",
                 {"title": "MM-10 second production (B7)",
                  "hard_ceiling_cents": 50000,
                  "soft_ceiling_cents": 45000})
    pid2 = p2["production_id"]
    s, r2 = call("POST", f"/productions/{pid2}/runs", {"kind": "FULL"})
    run2 = r2["run_id"]
    q1 = plan_unit(pid2, run2, "01.01")
    plan_unit(pid2, run2, "01.12", depends=[q1])
    PROGRESS["b7_production_id"] = pid2
    samples = []
    w1, sampler_thread, sampler_stop = b7_window(pid2, samples)
    p2_0112 = sql("SELECT unit_id FROM execution_units WHERE"
                  " production_id=%s AND operation_id='01.12'",
                  (pid2,), one=True)["unit_id"]
    plan_unit(pid2, run2, "02.12", depends=[p2_0112])
    drive_until(PID, {"01.01", "01.12"}, max_rounds=30,
                label="b7-window2-p1")
    drive_until(pid2, {"01.01", "01.12", "02.12"}, max_rounds=30,
                label="b7-window2-p2")
    sampler_stop.set()
    sampler_thread.join(timeout=3)
    w2_max = max((sum(x["inflight"].values()) for x in samples),
                 default=0)
    both = any(len(x["inflight"]) >= 2 for x in samples)
    (RESULTS / "b7_concurrency.json").write_text(json.dumps({
        "mapping": "no max_concurrent_productions knob exists; the"
                   " factory's concurrency control is"
                   " capacity_policies.max_concurrency per lane"
                   " (coordinator claim + Gate F scheduler). Battery"
                   " maps the brief's limit onto lane 'text' cap.",
        "window1_cap_1": w1,
        "window2_cap_4": {"max_simultaneous_inflight": w2_max,
                          "samples_with_both_productions_inflight":
                          both,
                          "p2_terminal": terminal_count(pid2)},
        "p2_final_states": {u["operation_id"]: u["state"]
                            for u in unit_states(pid2).values()},
        "samples_total": len(samples)}, indent=1))
    checkpoint(phase="main-drive")

    # ---------------- main drive, step by step ----------------
    units = {}  # op -> unit_id (master)
    units["01.01"] = u0112_dependencies
    units["01.12"] = sql(
        "SELECT unit_id FROM execution_units WHERE production_id=%s"
        " AND operation_id='01.12'", (PID,), one=True)["unit_id"]
    exit_artifact = {}  # step -> artifact_id of exit output
    _drive_master(run, canon, units, exit_artifact, t0,
                  skip_b5b=False, skip_b5a=False)


def _drive_master(run, canon, units, exit_artifact, t0,
                  skip_b5b, skip_b5a):
    prev_exit_uid = units["01.12"]
    prev_exit_op = "01.12"

    def art_id(atype):
        row = current_artifact(PID, atype)
        return row["artifact_id"] if row else None

    def exit_inputs(op):
        # G9-proven topology (verified against the persisted G9
        # full-run DB): 03.12/04.12 take NO canon input — 03.12's own
        # output is a canon_manifest, so consuming the operator canon
        # self-supersedes the input and the continuity guard lands
        # the unit in REPAIR_REQUIRED (observed in this battery's
        # first attempt; recorded in the results). 05.12-08.12 take
        # the CURRENT canon at plan time.
        if op in ("05.12", "06.12", "07.12", "08.12"):
            return [x for x in (art_id("canon_manifest"),) if x]
        if op == "09.12":
            return [exit_artifact["08"]]
        if op == "13.12":
            return [x for x in (exit_artifact.get("12"),
                                art_id("asset_registry")) if x]
        if op == "14.01":
            return [exit_artifact["13"]]
        if op == "14.12":
            return [x for x in (art_id("master_package"),) if x]
        if op == "15.12":
            return [x for x in (art_id("derivative_package"),) if x]
        if op == "16.12":
            return [x for x in (art_id("derivative_portfolio"),
                                art_id("distribution_record")) if x]
        return []

    # Step 01 exit pair already planned (B7). Drive them.
    drive_until(PID, {"01.01", "01.12"}, label="step-01-exits")
    for step in range(1, 17):
        ss = f"{step:02d}"
        exit_op = EXITS[ss]
        if step > 1:
            if exit_op not in units:
                units[exit_op] = plan_unit(
                    PID, run, exit_op, depends=[prev_exit_uid],
                    inputs=exit_inputs(exit_op))
            drive_until(PID, {exit_op}, label=f"step-{ss}-exit")
        st = unit_states(PID)[units[exit_op]]
        art = sql("SELECT artifact_id FROM artifacts WHERE"
                  " produced_by_unit=%s AND state='CURRENT'",
                  (units[exit_op],), one=True)
        if art:
            exit_artifact[ss] = art["artifact_id"]
        PROGRESS.setdefault("exit_states", {})[exit_op] = st["state"]
        checkpoint(phase=f"step-{ss}-intra")
        # Intra-step units: depend on the previous exit, planned with
        # its artifact (step-01 intra anchor on 01.01; 03.02 on 02.12).
        anchor_uid = units["01.01"] if step == 1 else prev_exit_uid
        if step == 1:
            arow = sql("SELECT artifact_id FROM artifacts WHERE"
                       " produced_by_unit=%s AND state='CURRENT'",
                       (units["01.01"],), one=True)
            anchor_art = arow["artifact_id"] if arow else None
        else:
            anchor_art = exit_artifact.get(f"{step - 1:02d}")
        intra = [op for op in STEP_OPS[ss] if op != exit_op
                 and op not in units]
        for op in intra:
            inputs = [anchor_art] if anchor_art else []
            if step in (3, 4, 5, 6, 7, 8):
                cur_canon = art_id("canon_manifest")
                if cur_canon and cur_canon not in inputs:
                    inputs = inputs + [cur_canon]
            units[op] = plan_unit(PID, run, op, depends=[anchor_uid],
                                  inputs=inputs)
        if step == 2 and not skip_b5b:
            drive_until(PID, set(intra) - {"02.03"},
                        label="step-02-intra")
            # B5(b): forced transient failure on 02.03, then recover.
            uid = units["02.03"]
            prestage()
            rc = dispatch(uid, "02.03", 1, force_fail=True)
            service_cycles()
            mid = unit_states(PID)[uid]["state"]
            ok = drive_until(PID, {"02.03"}, label="b5b-recovery")
            (RESULTS / "b5b_forced_failure.json").write_text(
                json.dumps({
                    "unit": uid, "operation_id": "02.03",
                    "dispatch_status": rc, "state_after_failure": mid,
                    "final_state":
                        unit_states(PID)[uid]["state"],
                    "attempts":
                        unit_states(PID)[uid]["current_attempt"],
                    "mechanism": "executor force_fail hook (factory's"
                                 " own test hook): one forced"
                                 " transient failure, then normal"
                                 " redispatch; HTTP-429 bounded retry"
                                 " itself was proven at MM-04/MM-08"
                                 " and is not re-claimed here",
                    "recovered": ok}, indent=1))
        else:
            drive_until(PID, set(intra), label=f"step-{ss}-intra")
        prev_exit_uid = units[exit_op]
        prev_exit_op = exit_op
        if step == 4 and not skip_b5a:
            b5a_kill_n8n()
    checkpoint(phase="final-sweep")
    drive_until(PID, set(OPS), max_rounds=30, label="final-sweep")
    states = unit_states(PID)
    (RESULTS / "b1_unit_states.json").write_text(json.dumps(
        {u["operation_id"]: {"state": u["state"],
                             "attempts": u["current_attempt"],
                             "block_reason": u["block_reason"]}
         for u in states.values()}, indent=1, default=str))
    PROGRESS["elapsed_s"] = round(time.time() - t0)
    checkpoint(phase="b6")
    b6(run, units, exit_artifact)
    checkpoint(phase="done")
    print("DRIVER DONE", flush=True)


CANON = ("CANON — The Bell at Dusk (fixture). Mara Venn, harbour "
         "archi" "vist; Tomas Rey, night ferryman; Ines Kova, bell "
         "founder's granddaughter. The harbour ledger vanished the "
         "night the bell last rang. Beats: discovery, accusation, "
         "the locked boathouse, the found key, the bell rings again.")


def b5a_kill_n8n():
    """B5(a): kill n8n mid-run, restart with the recorded spawn env,
    prove the webhook surface is back. SQL exactly-once assertions
    run in the sweep script."""
    before = sql("SELECT count(*) n FROM execution_units WHERE"
                 " production_id=%s AND state='ACCEPTED'", (PID,),
                 one=True)["n"]
    subprocess.run(["fuser", "-k", "5678/tcp"], capture_output=True)
    time.sleep(2)
    env = {"PATH": "/usr/bin:/bin:/usr/local/bin",
           "HOME": str(Path.home()),
           "N8N_USER_FOLDER": str(HOME / "video-factory-g4/n8n-data"),
           "N8N_PORT": "5678", "N8N_LISTEN_ADDRESS": "127.0.0.1",
           "N8N_DIAGNOSTICS_ENABLED": "false",
           "N8N_TEMPLATES_ENABLED": "false",
           "N8N_BLOCK_ENV_ACCESS_IN_NODE": "false",
           "FACTORY_API_URL": API,
           "FACTORY_WORKER_SERVICE_URL": "http://127.0.0.1:8795",
           "FACTORY_EVALUATION_URL": "http://127.0.0.1:8796",
           "FACTORY_OPERATOR_TOKEN": OP_TOKEN,
           "FACTORY_WORKER_TOKEN": "dev-worker-token",
           "FACTORY_SCHEDULER_TOKEN": "dev-scheduler-token",
           "FACTORY_VALIDATOR_TOKEN": "dev-validator-token",
           "FACTORY_CALLBACK_TOKEN": "dev-callback-token"}
    subprocess.Popen(
        [str(HOME / "video-factory-g4/node_modules/.bin/n8n"), "start"],
        stdout=open("/tmp/mm10-n8n-restart.log", "wb"),
        stderr=subprocess.STDOUT, start_new_session=True, env=env)
    ok = False
    for _ in range(60):
        try:
            with urllib.request.urlopen(
                    "http://127.0.0.1:5678/healthz", timeout=3) as r:
                ok = r.status == 200
        except Exception:
            ok = False
        if ok:
            break
        time.sleep(2)
    # webhook registration probe: a dispatch with a bogus unit must
    # NOT 404 (the executor answers with a domain error instead).
    probe = dispatch("00000000-0000-0000-0000-000000000000", "01.01", 1)
    (RESULTS / "b5a_n8n_kill.json").write_text(json.dumps({
        "killed": True, "healthz_after_restart": ok,
        "webhook_probe_status": probe,
        "accepted_before_kill": before}, indent=1))
    checkpoint(phase="b5a-restarted")


def b6(run, units, exit_artifact):
    """B6 (LOCK section 6): corrected asset_registry v2 supersedes
    the input of 12.12; invalidate edit_timeline v1; observe the
    cascade; drive the replacement 12.12 to ACCEPTED."""
    pid = PID
    before = {r["artifact_id"]: (r["artifact_type"], r["version"],
                                  r["state"])
              for r in sql("SELECT artifact_id, artifact_type,"
                           " version, state FROM artifacts WHERE"
                           " production_id=%s", (pid,))}
    reg_v1 = current_artifact(pid, "asset_registry")
    tl_v1 = current_artifact(pid, "edit_timeline")
    s, a = call("POST", f"/productions/{pid}/artifacts",
                {"artifact_type": "asset_registry",
                 "content": json.dumps({"assets": [
                     {"id": "A1", "kind": "picture", "note":
                      "CORRECTED registry (MM-10 B6 fixture): A1 "
                      "duration fixed"}],
                     "correction_of": reg_v1["artifact_id"]}),
                 "storage_uri": "local://mm10-asset-registry-v2"})
    assert s == 201, f"registry v2 register {s}: {a}"
    reg_v2 = a["artifact_id"]
    s, inv = call("POST", f"/artifacts/{tl_v1['artifact_id']}/invalidate",
                  {"reason": "MM-10 B6: corrected asset registry v2"
                             " supersedes the timeline input"})
    after_inv = {r["artifact_id"]: (r["artifact_type"], r["version"],
                                    r["state"])
                 for r in sql("SELECT artifact_id, artifact_type,"
                              " version, state FROM artifacts WHERE"
                              " production_id=%s", (pid,))}
    repl = sql("SELECT unit_id, operation_id, state FROM"
               " execution_units WHERE production_id=%s AND"
               " supersedes_unit_id=%s", (pid, units["12.12"]))
    record = {"invalidate_status": s, "invalidate_response": inv,
              "registry_v1": reg_v1, "registry_v2_id": reg_v2,
              "timeline_v1": tl_v1,
              "cascade_replacements": repl,
              "states_after_invalidate": {
                  k: v for k, v in after_inv.items()
                  if before.get(k) != v},
              "note": "artifact_dependencies carries no"
                      " executor-recorded rows in this factory"
                      " (verified at MM-10 start: 0 rows in the G9"
                      " DB); the cascade's actual reach is whatever"
                      " the rows above show — recorded, not assumed."}
    if repl:
        rid = repl[0]["unit_id"]
        drive_until(pid, {"12.12"}, label="b6-replacement")
        record["replacement_final"] = unit_states(pid)[rid]
        record["timeline_current_after"] = current_artifact(
            pid, "edit_timeline")
    final = {r["artifact_id"]: (r["artifact_type"], r["version"],
                                r["state"])
             for r in sql("SELECT artifact_id, artifact_type,"
                          " version, state FROM artifacts WHERE"
                          " production_id=%s", (pid,))}
    changed_unrelated = {
        k: {"before": before[k], "after": final[k]}
        for k in final
        if k in before and before[k] != final[k]
        and k not in (tl_v1["artifact_id"], reg_v1["artifact_id"],
                      reg_v2)}
    record["unrelated_artifacts_changed"] = changed_unrelated
    (RESULTS / "b6_selective_regeneration.json").write_text(
        json.dumps(record, indent=1, default=str))


if __name__ == "__main__":
    main()
