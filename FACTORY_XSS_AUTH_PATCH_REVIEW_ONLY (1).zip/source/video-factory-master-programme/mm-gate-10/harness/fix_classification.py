"""MM-10 fix cycle — post-repair 192-row classification.

Replicates harness/sweep.py's classification block EXACTLY (same
final-unit rule, same provider snapshot, same BLOCKED sub-labels),
run against the preserved mm10_scratch after the fix re-run, and
writes to evidence/results/fix/ — the battery's own
classification_192.json is NOT overwritten.
"""
import json
import re
from pathlib import Path

import psycopg
from psycopg.rows import dict_row

HOME = Path.home() / "workspace"
MM10 = HOME / "video-factory-master-programme/mm-gate-10"
FIXRES = MM10 / "evidence/results/fix"
PID = "8aa4e602-d1ee-4034-99a3-75f86416f8e0"
_pw = re.search(r"password=([^\s\"']+)",
                (HOME / "video-factory-g9/tools/setup_fullrun.py")
                .read_text()).group(1)
DSN = f"host=127.0.0.1 dbname=mm10_scratch user=factory password={_pw}"
plans = {p["operation_id"]: p for p in json.loads(
    (HOME / "video-factory-g1/seed-definitions/workflow-1.0.0"
            / "plans.json").read_text())["plans"]}


def sql(q, args=()):
    with psycopg.connect(DSN, row_factory=dict_row) as conn:
        return conn.execute(q, args).fetchall()


def one(q, args=()):
    rows = sql(q, args)
    return rows[0] if rows else None


units = sql("SELECT unit_id, operation_id, state, current_attempt,"
            " block_reason, created_at FROM execution_units WHERE"
            " production_id=%s ORDER BY created_at", (PID,))
by_op = {}
for u in units:
    by_op.setdefault(u["operation_id"], []).append(u)


def final_unit(op):
    us = by_op.get(op, [])
    if not us:
        return None
    for u in us:
        if u["state"] == "ACCEPTED":
            return u
    return us[-1]


def attempt_snapshot(unit_id):
    a = one("SELECT resolved_config FROM action_attempts WHERE"
            " unit_id=%s ORDER BY attempt_no DESC LIMIT 1",
            (unit_id,))
    if not a or not a["resolved_config"]:
        return {}
    cfg = a["resolved_config"]
    return cfg if isinstance(cfg, dict) else json.loads(cfg)


rows = []
counts = {}
for op in sorted(plans):
    u = final_unit(op)
    if u is None:
        cls, detail = "NOT_PLANNED", {}
    elif u["state"] == "ACCEPTED":
        provider = (attempt_snapshot(u["unit_id"]) or {}).get(
            "provider")
        if provider == "mock":
            cls = "EXECUTED_SIMULATED"
        elif provider == "deterministic-local":
            cls = "EXECUTED_REAL"
        else:
            cls = f"ACCEPTED_PROVIDER_{provider}"
        detail = {"provider": provider, "unit_id": u["unit_id"],
                  "attempts": u["current_attempt"]}
    elif u["state"] == "BLOCKED":
        unbound = [a["declared_implementation"]
                   for a in plans[op]["actions"]
                   if a["binding_status"] == "UNBOUND"]
        if unbound:
            cls = "BLOCKED_UNBOUND"
            detail = {"unbound_class": unbound,
                      "block_reason": u["block_reason"],
                      "attempts": u["current_attempt"]}
        else:
            cand = one("SELECT count(*) n FROM audit_events WHERE"
                       " unit_id=%s AND event_type="
                       " 'submit_candidate'", (u["unit_id"],))["n"]
            if cand:
                fails = sql(
                    "SELECT DISTINCT validator_id, verdict FROM"
                    " quality_evaluations WHERE artifact_id IN"
                    " (SELECT artifact_id FROM artifacts WHERE"
                    " produced_by_unit=%s) AND verdict IN"
                    " ('FAIL','BLOCKED')", (u["unit_id"],))
                cls = "BLOCKED_EVAL_DETERMINISTIC"
                detail = {"failing_layers": fails,
                          "block_reason": u["block_reason"],
                          "attempts": u["current_attempt"]}
            else:
                err = one("SELECT action_key, error FROM"
                          " plan_action_attempts WHERE unit_id=%s"
                          " AND status IN ('FAILED','REFUSED')"
                          " ORDER BY recorded_at DESC LIMIT 1",
                          (u["unit_id"],))
                cls = "BLOCKED_EXECUTION"
                detail = {"last_failed_action": err,
                          "block_reason": u["block_reason"],
                          "attempts": u["current_attempt"]}
    elif u["state"] == "REPAIR_REQUIRED":
        provider = (attempt_snapshot(u["unit_id"]) or {}).get(
            "provider")
        cls = "REPAIR_REQUIRED"
        detail = {"provider": provider, "unit_id": u["unit_id"]}
    else:
        cls = f"STATE_{u['state']}"
        detail = {"block_reason": u["block_reason"]}
    counts[cls] = counts.get(cls, 0) + 1
    rows.append({"operation_id": op, "class": cls, **detail})

before = json.loads((MM10 / "evidence/results/classification_192.json")
                    .read_text())
out = {"counts": counts, "total": sum(counts.values()),
       "human_completed": 0,
       "before_fix_counts": before["counts"],
       "note": "Post-fix re-run classification; identical logic to"
               " harness/sweep.py. Battery file"
               " classification_192.json untouched.",
       "rows": rows}
(FIXRES / "classification_after_fix.json").write_text(
    json.dumps(out, indent=1, default=str))
print(json.dumps(counts, indent=1), "total", sum(counts.values()))
