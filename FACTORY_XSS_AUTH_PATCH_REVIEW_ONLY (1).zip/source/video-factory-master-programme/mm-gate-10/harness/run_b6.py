"""MM-10: run B6 alone (the repair2 driver completed the drive and
the final sweep; its B6 call crashed on a content-encoding bug in
the harness's registration body — artifacts endpoint takes content
as a string. Fixed in mm10_driver.b6; this runner replays B6.)"""
import json
import sys
from pathlib import Path

MM10 = Path.home() / "workspace/video-factory-master-programme/mm-gate-10"
sys.path.insert(0, str(MM10 / "harness"))
import mm10_driver as D  # noqa: E402

RESULTS = D.RESULTS
old = json.loads((RESULTS / "progress.json").read_text())
PID = old["master_production_id"]
run = old["master_run_id"]
D.PID = PID
for k in ("browser_witnessed", "endpoint_decided_gates",
          "human_approvals_endpoint", "rounds", "exit_states",
          "gates_created", "repair_required_seen",
          "master_production_id", "master_run_id",
          "canon_artifact_id"):
    if k in old:
        D.PROGRESS[k] = old[k]
D.DRIVE_TERMINAL = D.DRIVE_TERMINAL + ("CANCELLED",)

states = D.unit_states(PID)
units = {}
for u in states.values():
    cur = units.get(u["operation_id"])
    if cur is None or u["state"] == "ACCEPTED":
        units[u["operation_id"]] = u["unit_id"]
exit_artifact = {}
for step in range(1, 17):
    ss = f"{step:02d}"
    euid = units.get(D.EXITS[ss])
    if euid:
        art = D.sql("SELECT artifact_id FROM artifacts WHERE"
                    " produced_by_unit=%s AND state='CURRENT'",
                    (euid,), one=True)
        if art:
            exit_artifact[ss] = art["artifact_id"]
D.checkpoint(phase="b6")
D.b6(run, units, exit_artifact)
D.checkpoint(phase="done")
print("B6 DONE", flush=True)
