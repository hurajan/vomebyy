"""MM-10 repair wave 4 — fixture-only inputs.
Wave 3's garnish (adding the step exit artifact as a second input)
backfired for ops whose extract takes the FIRST record-yielding
ref: executor refs order by artifact creation, so the exit
artifact's id-less internal records beat the fixture for
16.01/16.07, and the five wave-3 run-1 units sat READY forever on
the superseded fixture v1 (claim StaleInput refusals consume no
attempts). Wave 4: cancel those stuck READY units; register
fixture v3 (adds format/age_group for 16.07's group spec); replan
the seven affected ops with the fixture as the ONLY input."""
import json
import sys
from pathlib import Path

MM10 = Path.home() / "workspace/video-factory-master-programme/mm-gate-10"
sys.path.insert(0, str(MM10 / "harness"))
import mm10_driver as D  # noqa: E402

RESULTS = D.RESULTS
PID = "8aa4e602-d1ee-4034-99a3-75f86416f8e0"
D.PID = PID
D.DRIVE_TERMINAL = D.DRIVE_TERMINAL + ("CANCELLED",)
REPAIR_RUN = "fabc3936-6e7e-49c3-adad-67cba20e3ef6"
OPS4 = ["01.05", "01.08", "01.09", "02.01", "02.07", "16.01", "16.07"]

FIXTURE = {"records": [
    {"id": f"R{i:02d}", "title": f"Harbour record {i}",
     "topic": topic, "day": i, "date": f"2026-03-{i:02d}",
     "duration_s": 20 + 5 * i, "amount_cents": 100 * i,
     "score": 50 + i, "status": "logged",
     "format": fmt, "age_group": age}
    for i, (topic, fmt, age) in enumerate([
        ("premise", "vertical", "18-24"), ("canon", "square", "25-34"),
        ("character", "landscape", "35-44"),
        ("location", "vertical", "25-34"), ("beat", "square", "18-24"),
        ("shot", "landscape", "45+"), ("sound", "vertical", "35-44"),
        ("edit", "square", "45+"), ("rights", "landscape", "18-24"),
        ("derivative", "vertical", "25-34"),
        ("archive", "square", "35-44"), ("release", "landscape", "45+")],
        start=1)]}


def main():
    # Cancel the stuck READY r3 units (stale fixture input).
    stuck = D.sql("SELECT unit_id, operation_id FROM execution_units"
                  " WHERE production_id=%s AND unit_key='main-r3'"
                  " AND state='READY'", (PID,))
    for u in stuck:
        D.call("POST", f"/units/{u['unit_id']}/events",
               {"event": "block"})
        D.call("POST", f"/units/{u['unit_id']}/events",
               {"event": "cancel"})
        print("cancelled stuck r3:", u["operation_id"], flush=True)
    s, a = D.call("POST", f"/productions/{PID}/artifacts",
                  {"artifact_type": "source_records",
                   "content": json.dumps(FIXTURE),
                   "storage_uri": "local://mm10-source-records-v3"})
    assert s == 201, f"fixture v3 {s}: {a}"
    fixture_id = a["artifact_id"]
    print("fixture v3:", fixture_id, flush=True)
    planned = {}
    for op in OPS4:
        s, u = D.call("POST", f"/productions/{PID}/units",
                      {"operation_id": op, "run_id": REPAIR_RUN,
                       "unit_key": "main-r4", "depends_on": [],
                       "input_artifact_ids": [fixture_id]})
        assert s == 201, f"plan r4 {op}: {s} {u}"
        planned[op] = u["unit_id"]
    D.drive_until(PID, set(OPS4), max_rounds=120, label="repair4")
    after = {}
    for op in OPS4:
        after[op] = D.unit_states(PID)[planned[op]]["state"]
    (RESULTS / "repair4_records.json").write_text(json.dumps({
        "fixture_artifact_id": fixture_id, "states_after": after},
        indent=1))
    print("after:", after, flush=True)
    print("REPAIR4 DONE", flush=True)


if __name__ == "__main__":
    main()
