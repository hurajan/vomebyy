"""MM-10 repair: step-14 ordering incident (see
evidence/results/step14_ordering_incident.md). Replans the
14.12 -> 15.12 -> 16.12 chain in registry order inside the SAME
master production, drives steps 15/16 intra units, runs the final
sweep and B6. Reuses mm10_driver's machinery (imported, not run)."""
import json
import sys
import time
from pathlib import Path

MM10 = Path.home() / "workspace/video-factory-master-programme/mm-gate-10"
sys.path.insert(0, str(MM10 / "harness"))
import mm10_driver as D  # noqa: E402

RESULTS = D.RESULTS
old = json.loads((RESULTS / "progress.json").read_text())
PID = old["master_production_id"]
run = old["master_run_id"]
D.PID = PID
for k in ("browser_witnessed", "endpoint_decided_gates",
          "human_approvals_endpoint", "rounds", "exit_states",
          "gates_created", "repair_required_seen", "b7_production_id",
          "master_production_id", "master_run_id", "canon_artifact_id"):
    if k in old:
        D.PROGRESS[k] = old[k]
D.PROGRESS["repair"] = "step14-ordering: chain replanned in place"
# The cancelled original 15.12 must count as drive-terminal.
D.DRIVE_TERMINAL = D.DRIVE_TERMINAL + ("CANCELLED",)


def call(method, path, body=None):
    return D.call(method, path, body)


def unit_of(op, prefer=None):
    rows = [u for u in D.unit_states(PID).values()
            if u["operation_id"] == op]
    if prefer:
        for u in rows:
            if u["state"] == prefer:
                return u
    return rows[-1] if rows else None


def art_id(atype):
    row = D.current_artifact(PID, atype)
    return row["artifact_id"] if row else None


REPAIR_RUN = None


def plan_r1(op, depends=(), inputs=()):
    """Plan a repair unit: own run + unit_key 'main-r1' (the unique
    index on (production, operation, unit_key, run) forbids a second
    'main' unit in the original run)."""
    s, u = D.call("POST", f"/productions/{PID}/units",
                  {"operation_id": op, "run_id": REPAIR_RUN,
                   "unit_key": "main-r1", "depends_on": list(depends),
                   "input_artifact_ids": list(inputs)})
    assert s == 201, f"plan repair {op}: {s} {u}"
    return u["unit_id"]


def main():
    global REPAIR_RUN
    t0 = time.time()
    s, r = call("POST", f"/productions/{PID}/runs",
                {"kind": "PARTIAL_REPAIR"})
    assert s == 201, f"repair run create {s}: {r}"
    REPAIR_RUN = r["run_id"]
    print("repair run:", REPAIR_RUN, flush=True)
    # 1. Cancel the dead-end original 15.12.
    orig1512 = unit_of("15.12")
    if orig1512 and orig1512["state"] not in ("ACCEPTED", "BLOCKED",
                                              "CANCELLED"):
        s1, _ = call("POST", f"/units/{orig1512['unit_id']}/events",
                     {"event": "block"})
        s2, _ = call("POST", f"/units/{orig1512['unit_id']}/events",
                     {"event": "cancel"})
        print("cancel original 15.12:", s1, s2, flush=True)
    u1401 = unit_of("14.01", prefer="ACCEPTED")
    # 2. New 14.12 in registry order (after 14.01).
    new1412 = plan_r1(
        "14.12", depends=[u1401["unit_id"]],
        inputs=[x for x in (art_id("master_package"),
                            art_id("derivative_portfolio")) if x])
    print("new 14.12:", new1412, flush=True)
    D.drive_until(PID, {"14.12"}, label="repair-14.12")
    print("14.12 state:", D.unit_states(PID)[new1412]["state"],
          flush=True)
    dpkg = art_id("derivative_package")
    # 3. New 15.12 + step-15 intra (anchor: new 14.12). Intra units
    # are first-of-op: they go into the ORIGINAL run with key "main"
    # via the driver's planner; the chain exits use the repair run.
    new1512 = plan_r1("15.12", depends=[new1412],
                      inputs=[dpkg] if dpkg else [])
    print("new 15.12:", new1512, flush=True)
    D.drive_until(PID, {"15.12"}, label="repair-15.12")
    print("15.12 state:", D.unit_states(PID)[new1512]["state"],
          flush=True)
    intra15 = [op for op in D.STEP_OPS["15"] if op != "15.12"]
    for op in intra15:
        D.plan_unit(PID, run, op, depends=[new1412],
                    inputs=[dpkg] if dpkg else [])
    D.drive_until(PID, set(intra15), label="step-15-intra")
    # 4. New 16.12 + step-16 intra (anchor: new 15.12).
    inputs16 = [x for x in (art_id("derivative_portfolio"),
                            art_id("distribution_record")) if x]
    new1612 = plan_r1("16.12", depends=[new1512], inputs=inputs16)
    print("new 16.12:", new1612, flush=True)
    D.drive_until(PID, {"16.12"}, label="repair-16.12")
    print("16.12 state:", D.unit_states(PID)[new1612]["state"],
          flush=True)
    art1512 = D.sql("SELECT artifact_id FROM artifacts WHERE"
                    " produced_by_unit=%s AND state='CURRENT'",
                    (new1512,), one=True)
    intra16 = [op for op in D.STEP_OPS["16"] if op != "16.12"]
    for op in intra16:
        D.plan_unit(PID, run, op, depends=[new1512],
                    inputs=[art1512["artifact_id"]] if art1512 else [])
    D.drive_until(PID, set(intra16), label="step-16-intra")
    # 5. Final sweep across every operation.
    D.drive_until(PID, set(D.OPS), max_rounds=30, label="final-sweep")
    states = D.unit_states(PID)
    (RESULTS / "b1_unit_states.json").write_text(json.dumps(
        {u["unit_id"]: {"operation_id": u["operation_id"],
                        "state": u["state"],
                        "attempts": u["current_attempt"],
                        "block_reason": u["block_reason"]}
         for u in states.values()}, indent=1, default=str))
    # 6. B6 with the original 12.12.
    units = {}
    for u in states.values():
        cur = units.get(u["operation_id"])
        if cur is None or u["state"] == "ACCEPTED":
            units[u["operation_id"]] = u["unit_id"]
    exit_artifact = {}
    for step in range(1, 17):
        ss = f"{step:02d}"
        euid = units.get(D.EXITS[ss])
        if euid:
            art = D.sql("SELECT artifact_id FROM artifacts WHERE"
                        " produced_by_unit=%s AND state='CURRENT'",
                        (euid,), one=True)
            if art:
                exit_artifact[ss] = art["artifact_id"]
    D.PROGRESS["elapsed_s"] = round(time.time() - t0)
    D.checkpoint(phase="b6")
    D.b6(run, units, exit_artifact)
    D.checkpoint(phase="done")
    print("REPAIR DRIVER DONE", flush=True)


if __name__ == "__main__":
    main()
