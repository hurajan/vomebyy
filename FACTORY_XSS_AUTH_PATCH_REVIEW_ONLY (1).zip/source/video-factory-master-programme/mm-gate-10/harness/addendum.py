"""MM-10 addendum battery (post-main-drive):
A. Finish the B7 second production (its 02.12 was left CLAIMED
   when the B7 window closed).
B. B5(b) clean exercise on P2: a deterministic unit, one forced
   transient failure via the executor's force_fail hook, then
   normal redispatch to ACCEPTED — the original exercise unit
   (02.03) was an AI_EVAL op destined to BLOCK on its UNBOUND
   semantic action, so its 'recovered' flag is withdrawn and
   replaced by this unconfounded run.
C. B7 focused re-run with attempt-interval evidence: two fresh
   productions under lane cap 1 (interleaved rounds, sampled +
   interval overlap computed from action_attempts.started_at/
   finished_at), then cap 4.
"""
import json
import sys
import time
from pathlib import Path

MM10 = Path.home() / "workspace/video-factory-master-programme/mm-gate-10"
sys.path.insert(0, str(MM10 / "harness"))
import mm10_driver as D  # noqa: E402

RESULTS = D.RESULTS
old = json.loads((RESULTS / "progress.json").read_text())
PID2 = old.get("b7_production_id") or D.sql(
    "SELECT production_id FROM productions WHERE title LIKE %s"
    " ORDER BY created_at LIMIT 1",
    ("%second production%",), one=True)["production_id"]
D.PID = old["master_production_id"]
D.DRIVE_TERMINAL = D.DRIVE_TERMINAL + ("CANCELLED",)


def plan(pid, run, op, key="main", depends=(), inputs=()):
    s, u = D.call("POST", f"/productions/{pid}/units",
                  {"operation_id": op, "run_id": run, "unit_key": key,
                   "depends_on": list(depends),
                   "input_artifact_ids": list(inputs)})
    assert s == 201, f"plan {op}: {s} {u}"
    return u["unit_id"]


def drive(pid, ops, label, rounds=90):
    """drive_until takes pid explicitly, but dispatch() reads the
    module-global PID for its payload — point it at the target
    production first (the B7 window in the main driver carried the
    master's id on P2 dispatches and the executors tolerated it,
    since they resolve the unit by id; here we send the correct
    production id)."""
    D.PID = pid
    return D.drive_until(pid, set(ops), max_rounds=rounds, label=label)


def main():
    # ---- A. finish P2's 02.12
    run2 = D.sql("SELECT run_id FROM production_runs WHERE"
                 " production_id=%s LIMIT 1", (PID2,), one=True)
    run2 = run2["run_id"] if run2 else D.sql(
        "SELECT run_id FROM execution_units WHERE production_id=%s"
        " LIMIT 1", (PID2,), one=True)["run_id"]
    drive(PID2, {"02.12"}, "b7-p2-finish")
    p2_states = {u["operation_id"]: u["state"]
                 for u in D.unit_states(PID2).values()}
    print("P2 final:", p2_states, flush=True)

    # ---- B. B5(b) clean exercise on P2 (op 01.01, deterministic)
    uid = plan(PID2, run2, "01.01", key="b5b")
    D.PID = PID2
    D.prestage()
    rc = D.dispatch(uid, "01.01", 1, force_fail=True)
    D.service_cycles()
    mid = D.unit_states(PID2)[uid]
    att1 = D.sql("SELECT attempt_no, status, error_class FROM"
                 " action_attempts WHERE unit_id=%s ORDER BY"
                 " attempt_no", (uid,))
    ok = drive(PID2, {"01.01"}, "b5b-clean")
    fin = D.unit_states(PID2)[uid]
    att2 = D.sql("SELECT attempt_no, status, error_class FROM"
                 " action_attempts WHERE unit_id=%s ORDER BY"
                 " attempt_no", (uid,))
    (RESULTS / "b5b_addendum.json").write_text(json.dumps({
        "supersedes": "b5b_forced_failure.json — its unit (02.03) is"
                      " an AI_EVAL operation whose plan is UNBOUND"
                      " (semantic.evaluate); it was destined to"
                      " BLOCK regardless of the forced failure, so"
                      " its 'recovered: true' is WITHDRAWN. The"
                      " forced failure did fire (attempt 1 FAILED)"
                      " but recovery was never testable on that"
                      " unit.",
        "unit": uid, "operation_id": "01.01",
        "production_id": PID2, "dispatch_status": rc,
        "state_after_forced_failure": mid["state"],
        "attempts_after_forced_failure": att1,
        "final_state": fin["state"], "attempts_final": att2,
        "recovered": fin["state"] == "ACCEPTED" and len(att2) >= 2,
        "mechanism": "executor force_fail hook (the factory's own"
                     " test hook): attempt 1 forced transient"
                     " failure -> RETRY_WAIT -> RetryDriver requeue"
                     " -> normal redispatch -> ACCEPTED. The"
                     " HTTP-429 bounded-retry path itself was"
                     " proven at MM-04/MM-08 and is not re-claimed."},
        indent=1, default=str))
    print("B5b addendum:", fin["state"], att2, flush=True)

    # ---- C. B7 focused re-run with interval evidence
    def mkprod(title):
        s, p = D.call("POST", "/productions",
                      {"title": title, "hard_ceiling_cents": 50000,
                       "soft_ceiling_cents": 45000})
        pid = p["production_id"]
        s, r = D.call("POST", f"/productions/{pid}/runs",
                      {"kind": "FULL"})
        return pid, r["run_id"]

    pa, ra = mkprod("MM-10 B7 rerun A")
    pb, rb = mkprod("MM-10 B7 rerun B")
    ua1 = plan(pa, ra, "01.01")
    ua2 = plan(pa, ra, "01.12", depends=[ua1])
    ub1 = plan(pb, rb, "01.01")
    ub2 = plan(pb, rb, "01.12", depends=[ub1])
    D.sql_exec("UPDATE capacity_policies SET max_concurrency=1"
               " WHERE lane='text'")
    w1_start = time.time()
    for _ in range(16):
        D.prestage()
        for pid_ in (pa, pb):
            D.PID = pid_
            for uidd, u in D.unit_states(pid_).items():
                if u["state"] in ("READY", "CLAIMED"):
                    D.dispatch(uidd, u["operation_id"],
                               D.OPS[u["operation_id"]]["station"])
        D.service_cycles()
        D.handle_humans(pa)
        D.handle_humans(pb)
        time.sleep(0.5)
    w1_end = time.time()
    D.sql_exec("UPDATE capacity_policies SET max_concurrency=4"
               " WHERE lane='text'")
    drive(pa, {"01.01", "01.12"}, "b7r-a")
    drive(pb, {"01.01", "01.12"}, "b7r-b")

    def max_overlap(pid_list, t0, t1):
        rows = D.sql(
            "SELECT started_at, finished_at FROM action_attempts"
            " WHERE unit_id IN (SELECT unit_id FROM execution_units"
            " WHERE production_id = ANY(%s)) AND started_at IS NOT"
            " NULL AND extract(epoch from started_at) >= %s AND"
            " extract(epoch from started_at) <= %s",
            (pid_list, t0, t1))
        events = []
        for r in rows:
            s_ = r["started_at"].timestamp()
            f_ = (r["finished_at"].timestamp() if r["finished_at"]
                  else t1)
            events.append((s_, 1))
            events.append((f_, -1))
        events.sort(key=lambda e: (e[0], -e[1]))
        cur = mx = 0
        for _t, d_ in events:
            cur += d_
            mx = max(mx, cur)
        return mx, len(rows)

    ov1, n1 = max_overlap([pa, pb], w1_start, w1_end)
    (RESULTS / "b7_addendum.json").write_text(json.dumps({
        "purpose": "The original B7 window's sampler counted unit"
                   " states (CLAIMED/RUNNING/VALIDATING); VALIDATING"
                   " units no longer hold a lane slot, inflating the"
                   " simultaneous count to 2 under cap 1. This re-run"
                   " measures attempt EXECUTION intervals"
                   " (action_attempts.started_at/finished_at).",
        "window1_cap_1": {
            "max_overlapping_attempt_executions": ov1,
            "attempts_started_in_window": n1,
            "a_states": {u["operation_id"]: u["state"]
                         for u in D.unit_states(pa).values()},
            "b_states": {u["operation_id"]: u["state"]
                         for u in D.unit_states(pb).values()}},
        "p2_final_states": p2_states,
        "verdict_mapping": "No max_concurrent_productions control"
                           " exists in the factory; the mapped"
                           " mechanism (per-lane capacity cap,"
                           " enforced in coordinator claim) limits"
                           " simultaneous EXECUTION, not production"
                           " admission — under cap 1 the second"
                           " production's units execute only in the"
                           " first production's gaps, and both"
                           " complete. Reported as the mechanism's"
                           " actual behavior, not as the brief's"
                           " literal knob."}, indent=1, default=str))
    print("B7 rerun overlap cap1:", ov1, "attempts:", n1, flush=True)
    print("ADDENDUM DONE", flush=True)


if __name__ == "__main__":
    main()
