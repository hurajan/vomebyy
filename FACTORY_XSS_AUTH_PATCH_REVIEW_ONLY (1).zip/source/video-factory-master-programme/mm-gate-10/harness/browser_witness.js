/* MM-10 browser witness: approve ONE human gate through the real
   dashboard UI (Playwright + Chromium headless shell), the same
   surface a human operator uses. The token field ships empty since
   the MM-09 D-MM09-V1 fix, so the script types it explicitly.
   Env: MM10_GATE_ID, MM10_PID, MM10_KIND, MM10_SHOTS. */
const { chromium } = require("/home/hatch/workspace/video-factory-g4/node_modules/playwright");
const fs = require("fs");
const path = require("path");

const GATE_ID = process.env.MM10_GATE_ID;
const PID = process.env.MM10_PID;
const KIND = process.env.MM10_KIND || "gate";
const SHOTS = process.env.MM10_SHOTS;
const SHELL = process.env.HOME +
  "/.cache/ms-playwright/chromium_headless_shell-1248/chrome-headless-shell-linux64/chrome-headless-shell";
const BASE = "http://127.0.0.1:8730";

const results = [];
function check(name, ok, detail) {
  results.push({ name, ok: !!ok, detail: String(detail || "") });
  console.log(`${ok ? "PASS" : "FAIL"} ${name} ${detail || ""}`);
}

(async () => {
  fs.mkdirSync(SHOTS, { recursive: true });
  const browser = await chromium.launch({ executablePath: SHELL, headless: true });
  const page = await browser.newPage({ viewport: { width: 1440, height: 1000 } });
  page.on("pageerror", e => check("no_pageerror", false, e.message));
  await page.goto(BASE + "/", { waitUntil: "load" });
  await page.fill("#token", "dev-operator-token");
  await page.click("#refreshBtn");
  await page.waitForFunction(
    (pid) => [...document.querySelectorAll("#prodSel option")]
      .some(o => o.value === pid),
    PID, { timeout: 30000 });
  check("production_listed", true, PID);
  await page.selectOption("#prodSel", PID);
  await page.waitForTimeout(800);
  await page.click("button[data-view='gates']");
  const rowSel = `#gateRows tr:has(button[onclick*="${GATE_ID}"])`;
  await page.waitForSelector(rowSel, { state: "attached", timeout: 30000 });
  const rowText = await page.locator(rowSel).textContent();
  check("gate_row_visible", rowText.includes(KIND), rowText.slice(0, 120));
  await page.screenshot({ path: path.join(SHOTS, `gate_${KIND}_pending.png`) });
  await page.locator(`${rowSel} button[onclick*="'APPROVED'"]`).click();
  await page.waitForFunction(
    (gid) => {
      const btn = document.querySelector(
        `#gateRows button[onclick*="${gid}"]`);
      if (btn) return false; // still pending (buttons re-render away)
      return [...document.querySelectorAll("#gateRows tr")]
        .some(tr => tr.textContent.includes("APPROVED"));
    },
    GATE_ID, { timeout: 30000 });
  check("gate_approved_via_ui", true, GATE_ID);
  await page.screenshot({ path: path.join(SHOTS, `gate_${KIND}_approved.png`) });
  await browser.close();
  const out = { gate_id: GATE_ID, kind: KIND, production_id: PID,
                witnessed: results.every(r => r.ok), results };
  fs.writeFileSync(path.join(SHOTS, `witness_${KIND}.json`),
                   JSON.stringify(out, null, 1));
  console.log(JSON.stringify(out));
  process.exit(out.witnessed ? 0 : 1);
})().catch(e => { console.error("WITNESS ERROR", e.message); process.exit(2); });
