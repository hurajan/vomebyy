# LOCK MM-10 — Full Mock End-to-End Acceptance (Multi-Model Gate 10)

Builder lock, taken 2026-10-29 before any product edit. Authority:
MULTI_MODEL_EXECUTION_PROMPT.md Gate MM-10 + the controller's MM-10
builder brief (B1–B9 battery items). Ownership seam appended to
gate-00/OWNERSHIP.md in the same action.

## Starting state (measured, not assumed)

- plans.json: 192 plans; FULLY_BOUND 79 / PARTIALLY_BOUND 113.
  plans_hash `a71d77c6…` (MM-00/MM-06 anchor lineage; MM-06 snapshot at
  mm-gate-06/evidence/plans_snapshot_post_mm06.json).
- Every partially-bound plan carries exactly ONE unbound action kind:
  creative.generate 43, human.decision 28, semantic.evaluate 27,
  external.platform 9, media.generate 4, external.provider 2
  (counted from plans.json, 2026-10-29).
- MM-01 classes cross-tab exactly: DETERMINISTIC 68 + MEDIA_TOOL 10
  fully bound; AI_TEXT 43 (42 creative-unbound + 08.12 bound);
  AI_MEDIA 4 (media.generate); AI_EVAL 24 (semantic); EXTERNAL_SERVICE
  11 (9 platform + 2 provider); HUMAN_DECISION 25 (human);
  MIXED 7 (1 creative, 3 human, 3 semantic).
- Worker action registry: 19 implementations; action_implementations.json
  is a byte-exact dump of actions.py INPUT_SPECS/OUTPUT_SPECS (verified
  programmatically before edits).
- MM-03 promotion hardcodes PROVIDER=openrouter-compatible +
  CREDENTIAL_REF=OPENROUTER_API_KEY (model_registry.py) — registry
  promotion therefore CANNOT write mock bindings and stays reserved
  for MM-12. Mock bindings are seeded as provider_configs rows through
  the established POST /configs API (MM-05 precedent), and mock
  operation_model_assignments are seeded as battery-DB fixture data
  (status ACTIVE, matrix_version mm10-mock-1.0.0) with policy_events
  rows recording the fixture activation and its reason.
- artifact_dependencies in the G9 full-run DB: 0 rows. Executor
  completions pass no depends_on_artifact_ids; the factory's recorded
  provenance for unit outputs is unit_inputs + plan action records +
  content-internal refs + produced_by_unit/version chains. B3 verifies
  provenance through those records and states the table's state
  plainly. The B6 cascade follows artifact_dependencies — its actual
  reach is recorded as observed behavior.
- Concurrency control in the factory is capacity_policies
  (per-lane max_concurrency), enforced inside claim() and by the
  Gate F scheduler service across all productions. There is no
  production-count knob. B7 is executed against this mechanism with
  the mapping declared here, before the run: lane cap = the
  concurrent-execution limit shared by concurrent productions.

## Enabling build (additive only)

1. Four explicitly-simulated action implementations in
   worker_service/actions.py (+ INPUT_SPECS/OUTPUT_SPECS + manifest
   regeneration, additive):
   - mock.creative.generate, mock.media.generate,
     mock.external.platform, mock.external.provider.
   - Dispatch discipline (fail-closed): each implementation runs ONLY
     when the attempt's pinned binding provider is 'mock'. Any other
     binding (deterministic-local, openrouter-compatible, none)
     raises ActionRefused with a named reason — a refusal is BLOCKED
     evidence, never a silent fallback and never a simulated result
     under a non-mock label.
   - Every output carries simulated: true + the generator name;
     media.generate produces REAL lavfi media bytes via the MM-06
     local tooling (stored + probe-validated, labeled simulated);
     external.platform produces receipts in the MM-06 15.12 labeling
     style (simulated: true, status SIMULATED).
2. generate_plans.py: the four mockable unbound kinds become bound
   "simulate" cores (same action_keys); plan classification for such
   plans records class simulated_mock with an explanatory note.
   human.decision / semantic.evaluate cores are NOT touched.
   Expected effect: exactly 58 plans change; the other 134 plans stay
   byte-identical (proven by diff against the O-1 snapshot); genuine
   FULLY_BOUND 79 unchanged in content; new FULLY_BOUND total 137, of
   which 58 are executable ONLY via simulation (reported as two
   numbers everywhere: genuinely bound 79, mock-executable 58).
3. Worker tests: new test_mm10_mock_actions.py; two pinned assertions
   move legitimately and are recorded in CHANGED_ASSERTIONS.md
   (FULLY_BOUND count 79 -> 137 in test_worker_service.py;
   test_unbound_plan_refuses_without_artifact moves its subject op
   from 08.05 to a still-unbound op, 01.02 semantic.evaluate).

## Battery design (mm10_scratch DB; harness/mm10_driver.py)

- Setup mirrors g9 setup_fullrun: five tree setups (workflow sync),
  fresh DB, API + worker + evaluation services re-pointed at
  mm10_scratch, DSN asserted before any test traffic (OBS-1).
- Bindings (battery DB only): STATION deterministic-local x6
  (est 100 / reported_actual 90, G9 topology); OPERATION mock bindings
  (provider 'mock', params.test_only=true) for 89 ops = every
  AI_TEXT/AI_MEDIA/AI_EVAL/MIXED op (78, with MM-03 mock assignments
  ACTIVE) + every EXTERNAL_SERVICE op (11, no model assignment —
  external services carry no model in MM-02/MM-03 either).
- DAG: the G9 master chain for the 19 specific ops (exits chained);
  every intra-step unit depends on the previous step's exit unit
  (step-01 intra units on 01.01) and is planned with that exit's
  artifact as its input when the exit lands. A blocked intra unit can
  therefore never freeze the master path or its siblings.
- Drive: Gate F SchedulerService prestage cycles + per-unit dispatch
  to the station-correct n8n webhook + RetryDriver/Reconciler cycles;
  gates decided via POST /gates/{id}/decide; AWAITING_HUMAN units
  approved via POST /units/{id}/events human_approved (the dashboard's
  own API actions). Browser-witnessed subset: the HG2/HG4/HG5 gate
  approvals are clicked through the real dashboard UI (Playwright,
  g4 node_modules) and recorded as witnessed; all other approvals are
  endpoint calls and recorded as such.
- B5(a): n8n killed once mid-run (fuser -k 5678/tcp) and restarted
  with the recorded spawn env; uniqueness of settlements/action
  records asserted from SQL afterwards.
- B5(b): one unit dispatched once with force_fail=true (the factory's
  own test hook, honored by the worker service) -> transient failure
  -> RETRY_WAIT -> normal redispatch succeeds. Recorded precisely as
  a forced-failure-hook exercise; HTTP-429 bounded retry was proven
  at MM-04/MM-08 against stubs and is not re-claimed here.
- B6 (after B1-B4 snapshots): corrected asset_registry v2 registered
  as CURRENT; edit_timeline v1 invalidated; cascade outcome recorded;
  replacement 12.12 unit driven to ACCEPTED (edit_timeline v2);
  unrelated artifact versions asserted unchanged.
- B7: second production driven concurrently with the master under
  lane cap 1 (sampled in-flight proof), then cap raised to 4
  (sampled concurrency rises; both productions progress).
- Progress checkpointed to evidence/results/progress.json throughout;
  final classification table built from SQL only.

## Honesty rules (from the brief, binding)

- Classification from SQL (attempt snapshot provider + action
  records): EXECUTED_REAL / EXECUTED_SIMULATED / HUMAN_COMPLETED /
  BLOCKED_UNBOUND(named class); counts sum to 192. Human approvals
  are reported as a separate counted dimension (units accepted via
  human_approved; gates decided), never merged into execution class.
- Mock semantic evaluation never impersonates the evaluation service:
  the REVIEW_REQUIRED -> AWAITING_HUMAN posture stands; operator
  approvals are human acceptance of simulated content, labeled so.
- No quality/cost/publishing figure is reported without its
  simulated/real class. Mock actuals equal binding-reported values by
  construction; B4 claims bookkeeping consistency only.

## Out of scope

No coordinator, API, migration, workflow-JSON, evaluation-service, or
dashboard changes. No STATE.md/MEMORY.md edits. No gate report (the
verifier writes it). No real provider call; no credential exists or
is requested (MM-12 owns that).
