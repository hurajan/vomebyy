# Gate 01 — Call-graph notes (static reachability)

**Method.** AST parse of every Python file in the nine factory trees plus the
programme service trees (gate-c worker_service, gate-d storage_service,
gate-e evaluation_service, gate-f runtime_services, gate-h harness),
excluding `__pycache__` and the n8n runtime data directory. Two passes:

1. **Call-name pass** — every `ast.Call` target name counted across all
   trees (tests included). Raw output: 339 distinct defined names, 108
   defined names with zero call sites. Most of the 108 are framework-invoked
   and are **not** findings: `unittest` methods (`test_*`, `setUp`,
   `tearDown`, `tearDownClass`), `BaseHTTPRequestHandler` methods
   (`do_GET`, `do_POST`, `do_PUT`, `do_HEAD`, `do_DELETE`, `log_message`),
   property accessors (`Coordinator.storage`, `ContextLoader.storage` —
   invoked by attribute access, not calls), and the runner's
   `handle_signal` (registered with the `signal` module).
2. **Any-reference pass** — every `ast.Name`/`ast.Attribute` load plus
   string-literal tokens (routes, event names), product (non-test)
   definitions only: 428 definitions scanned, exactly **1** with zero
   references of any kind: `runtime_services/lanes.py:68
   capacity_max_in_flight` (a descriptive alias).

Because name-based counting over-credits common names (`run_once`,
`execute`, `main` collide across modules), every candidate finding from
the passes was then **verified individually by targeted grep** across all
product + test + harness trees. The verified zero-/test-only-caller list
below is the audit's claim; nothing else is claimed uncalled.

## Verified zero-caller / test-only-caller functions

| Function | Location | Callers found |
|---|---|---|
| `Coordinator.heartbeat` | g2/coordinator/coordinator.py:930 | **none anywhere** (no API route, no service, no test). Lease extension is unreachable; long work relies on TTL + reaper. |
| `Coordinator.submit_provider_job` (legacy v1) | coordinator.py:1279 | one **test** (gate-f runtime_services tests). Product code uses `submit_provider_job_v2` only. |
| `Coordinator.attach_provider_job_id` | coordinator.py:1367 | one **test** (gate-f runtime_services tests). No product caller — the v2 job's `provider_job_id` is never replaced with a real provider id in the composed flow. |
| `Coordinator.provider_timeout` | coordinator.py:1374 | one **test** + the Gate H T6 **harness** (which called it directly to reach UNKNOWN). No product caller. |
| `Coordinator.cleanup_candidates` | coordinator.py:1021 | one **test** (g2 test_gated.py). No API route, no runtime-service loop — operationally unwired. |
| `Adapter.estimate` | gate-c/worker_service/adapters.py:78 | no product caller (estimates come from provider_configs, never from adapters). |
| `Adapter.validate_config` | adapters.py:72 (+ subclass override :159) | subclass `super()` call + one test assertion. Never invoked on binding creation (API `_create_config`) or at execution time. |
| `Adapter.capabilities` | adapters.py:66 | subclass `super()` call only. `/health` reads adapter fields directly. |
| `lanes.capacity_max_in_flight` | gate-f/runtime_services/lanes.py:68 | **zero references of any kind** (pass 2). Dead alias. |
| `StorageClient.head` (Local/S3) | gate-d/storage_service/storage.py | storage **tests** only; evaluation context and worker service use `get`. |

## False positives explicitly cleared

- `evaluation_service/context.py:106 resolve_qa_binding` — flagged by the
  call-name pass; it is stored in the evaluation context dict and invoked
  as `ctx["resolve_qa_binding"]()` by `layers.semantic_layer`. **Called.**
- All HTTP handler methods, unittest methods, properties, and the signal
  handler above. **Framework-invoked.**
- `Coordinator.storage` property — invoked constantly via attribute
  access. **Called.**
- `submit_provider_job_v2`, `reconcile_once`, `scheduler_claim`,
  `retry_unit`, `settle_provider_charge`, `invalidate_artifact`,
  `handle_callback` — all have product callers (API routes, runtime
  services, or executors via the API). **Called.**

## Runtime call chain (webhook → acceptance), as traced

1. **Outbox/dispatch**: `Coordinator._claim_txn` writes an outbox
   `dispatch` event in the claim transaction → Gate F
   `DispatcherService.run_once` POSTs it to `FACTORY_DISPATCH_URL`
   (the tree's n8n `dispatch-receiver` webhook) and records a
   `dispatch_handoffs` row in the same transaction it marks the event
   published.
2. **n8n**: `dispatch-receiver` (webhook → Normalize dispatch) →
   `station-NN` workflow → per-unit `unit-executor`:
   Load unit → RETRY_WAIT pre-step (`POST /units/{id}/retry`, F-G9-03) →
   **Gate 02 seam (in flux at audit time)**: Fetch attempts + Fetch
   provider jobs → Resume decision (adopt a scheduler-pre-staged claim)
   or Claim unit → Fetch attempt snapshot → Assemble worker payload →
   `call-worker` sub-workflow → HTTP `POST {WORKER_SERVICE_URL}/work`.
3. **Worker service** (`gate-c/worker_service/service.py:run_work`):
   resolves input refs (Gate D store by sha, envelope unwrap) →
   adapter `execute` (deterministic-local → `payloads.build`; credential
   adapters → real HTTP or `BlockedError`) → envelope wrap for `.12`
   exits → response `{status: COMPLETED, artifact_type, content, usage,
   actual_cost_cents}`. The executor then calls the coordinator API
   `POST /units/{id}/complete` (**submit-candidate**) — the worker
   service itself never touches the coordinator.
4. **Coordinator completion** (`complete_attempt`): staging + hash
   verification → fencing gate → GB-SEC-01 worker-binding check →
   register artifact CURRENT → FINALIZED selection → settle reservation
   → unit VALIDATING.
5. **Evaluation**: executor `POST {EVALUATION_URL}/evaluate` →
   evaluation service loads context SELECT-only, runs schema /
   technical / continuity / semantic layers, submits verdicts via API
   `POST /units/{id}/validate` as VALIDATOR → `Coordinator.validate`
   maps verdicts to ACCEPTED / REPAIR_REQUIRED / BLOCKED /
   AWAITING_HUMAN.
6. **Human path**: AWAITING_HUMAN → (harness/operator) `human_approved`
   event → ACCEPTED closes the parked attempt and promotes dependents
   (`Coordinator.event`, Gate G behavior); station workflows create
   HG2/HG4/HG5 gates at their exits; `decide` is OPERATOR-only at the
   API; claim-time enforcement is `_verify_input_gates`.

**Breaks in the chain found by this trace** (register IDs): the async
branch of step 3 is not composed (D11/D19); the reconciler in the
standing runner polls the test MockProvider (D11); heartbeat has no
caller (D10); no code materializes the 192-operation graph that the
chain would execute (D03).

## Unreachable / dead branches provable statically

- `submit_provider_job_v2` pre-fills `provider_job_id = f"local-{job_id}"`
  and the only function that could replace it (`attach_provider_job_id`)
  has no product caller → in the composed flow the column is always the
  synthetic value.
- `semantic_layer`: the branch for a credential-bearing real provider
  returns BLOCKED (`real_semantic_judging_not_in_scope_gate_e`) — real
  judging is unreachable by construction in this gate's scope.
- `capability_execution_plans` (registry DB): no INSERT exists in the
  loader and no SELECT exists anywhere → the table is permanently empty;
  the op→capability→action plan layer is unimplemented, not merely
  unpopulated (D02).
- Per-tree mock worker servers (g4–g8): retired from all generated flows
  at Gate G; files remain on disk (D20).
- `gate-b/migrations-draft/006–009` (+ `.down.sql`): superseded drafts;
  the applied chain is g2 migrations 006–013 (D20).
