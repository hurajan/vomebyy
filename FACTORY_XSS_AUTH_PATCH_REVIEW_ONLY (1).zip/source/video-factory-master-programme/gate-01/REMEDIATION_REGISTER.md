# Gate 01 — Remediation Register

Every item verified by source-level trace in this audit (file:line in AUDIT_REPORT.md). Live exploitation/behavior tests were NOT run (Gate 02 battery in flight; serialization rule) — each item names the gate that owns remediation and the test that will prove it.

| ID | Severity | Deficiency | Owner gate | Proving test |
|---|---|---|---|---|
| G01-D01 | CRITICAL | Generic success fallthrough for 173 of 192 operations | 04 | Gate 04 binding-resolution test: every operation resolves to a declared implementation plan or fails explicitly (no step_output artifact can be produced); Gate 10 per-operation contract tests. |
| G01-D02 | CRITICAL | Capability layer is decorative: 29 PROPOSED records, execution_plan null, never read at runtime | 04 | Gate 04: op->capability->action resolution test over all 192 operations reading the same records the runtime reads; a capability with no execution plan fails resolution explicitly. |
| G01-D03 | HIGH | No registry-driven graph materialization: dependency_templates never read by planning/execution code | 04 | Gate 04/12: materialization test — planning a production from the registry produces units+dependencies equal to the templates for the production's unit_keys; Gate 10 dependency-relationship tests per operation. |
| G01-D04 | HIGH | 12.12 routing divergence: registry station 5 vs serving tree g6 (steps 09-12, labelled station 4) | 03 | Gate 03: route test for all 192 operations (registry station == serving tree station == scheduler executor mapping) after the owner's 12.12 ruling; registry hash impact recorded. |
| G01-D05 | HIGH | Semantic validation is nominal: 44 named policy checks collapse to 2 rubrics; all other named checks unimplemented | 06 | Gate 06: per-policy-name coverage test — each named validator in the seed maps to an implemented check or an explicit unimplemented record; Gate 08 calibration on EXPERT cases. |
| G01-D06 | HIGH | Approval policies unenforced for 8 of 11 policy values | 05 | Gate 05/06: policy-enforcement matrix test — for each approval_policy value, a claim against a gated input without the required approval is refused, or the policy is formally retired by owner decision. |
| G01-D07 | HIGH | POST /units/{id}/events lets WORKER and SCHEDULER roles fire human_approved (and any TRANSITIONS event) | 05 | Gate 05 T-test: WORKER and SCHEDULER tokens POST human_approved -> 403; OPERATOR -> 200; same matrix for cancel/block; audit evidence rows asserted. |
| G01-D08 | MEDIUM | Identity is self-asserted: X-Identity header + body worker_id are unauthenticated claims | 05 | Gate 05/11: identity-binding test — a completion whose authenticated identity differs from the attempt's worker identity is refused even with a valid role token; secret-scan test asserts no credential literals in source defaults. |
| G01-D09 | MEDIUM | Attempts endpoint exposes fencing_token to every read role (Gate 02 seam, in flux) | 02 | Gate 02 T02-C/D extended: fencing token not returned to non-worker roles; completion with a token obtained via a VALIDATOR read is refused (or the exposure is owner-accepted with the rationale recorded). |
| G01-D10 | MEDIUM | Zero-caller / test-only coordinator and adapter surface (dead or unwired code) | 05 | Gate 05: reachability re-run of this call graph in CI; each listed function either gains a product caller with a behavior test or is removed/retired by an owner-visible change record. |
| G01-D11 | MEDIUM | Async provider path is service-tested but not composed: reconciler's standing poller is the test MockProvider; v2 jobs carry synthetic provider ids | 05 | Gate 05/07: composed async test — an async-mode binding executes through executor -> worker /jobs -> coordinator job -> reconciler with the REAL poller wiring (no harness-injected poller) to ACCEPTED; T02-G crash-after-adoption variant. |
| G01-D12 | MEDIUM | All executed content is simulated fixture data; several specific builders ignore their declared inputs | 10 | Gate 10: per-operation input-sensitivity test — varying a declared input changes the output in the contractually specified way (or the operation's plan records input-independence explicitly). Gate 07 replaces fixture content with provider output per modality. |
| G01-D13 | MEDIUM | reported_actual_cents: 90 is a seeded fixture datum presented as measured cost in every budget total | 09 | Gate 09: measured-cost test — a priced execution's FINALIZED amount equals the pricing-rule computation from recorded usage (basis 'calculated'), and the 90c datum is absent from any production-environment binding. |
| G01-D14 | MEDIUM | Golden set: 7 SEED / 0 EXPERT — semantic layer permanently unarmed; factory set smaller than earlier programme summaries stated | 08 | Gate 08: 50+ EXPERT cases with provenance records; arming test (49 EXPERT unarmed, 50 armed) re-run; holdout accuracy report for the two implemented rubrics before any new rubric arms. |
| G01-D15 | MEDIUM | S3 storage is stub-tested only; the running stack uses LocalStorage on the same host | 09 | Gate 09: storage battery re-run against a real S3-compatible endpoint (put/promote/get/hash/delete + outage case), evidence recorded with endpoint identity. |
| G01-D16 | LOW | Library-mode claim() lets the caller estimate win over the resolved binding (D-C1 correction is API-path only) | 05 | Gate 05: library-caller inventory test — every in-process claim caller passes either no estimate or the resolved binding's estimate; divergence requires a recorded exception. |
| G01-D17 | LOW | register_artifact is an unvalidated CURRENT-promotion surface (OPERATOR and WORKER roles) | 05 | Gate 05: WORKER-role register attempt -> 403 (or owner-accepted with rationale); OPERATOR registration writes an audit-distinguishable provenance marker asserted in test. |
| G01-D18 | LOW | Legacy single-verdict POST /units/{id}/validate lets OPERATOR bypass the evaluation service | 06 | Gate 06: provenance test — every ACCEPTED unit's quality_evaluations show either evaluation-service layer rows or an explicit operator-override record; dashboard acceptance counts reported separately. |
| G01-D19 | LOW | Worker-service async job map is in-memory and service-local; a worker-service restart orphans submitted jobs | 05 | Gate 05: kill worker service between submit and poll in a composed async run; the job still reaches a terminal coordinator state exactly once. |
| G01-D20 | LOW | Dead/legacy code carried in product trees | 05 | Gate 14 evidence lock: change manifest lists each retired file; regression battery green after removal. |

## G01-D01 — Generic success fallthrough for 173 of 192 operations (CRITICAL, owner: Gate 04)

**Files:** gate-c/worker_service/payloads.py:217 (build fallthrough); gate-c/worker_service/adapters.py DeterministicLocalAdapter/MockAdapter

**Finding:** payloads.build() returns ('step_output', {kind:'step_output', operation_id}) for every operation without a specific builder — a successful, valid-looking result with no operation semantics. 173 operations (all except the 19 SPECIFIC) execute only through this fallthrough via the deterministic-local/mock adapters. Non-exit operations have no deliverable schema, so evaluation cannot detect the emptiness (schema layer is step_exit_only).

**Proving test:** Gate 04 binding-resolution test: every operation resolves to a declared implementation plan or fails explicitly (no step_output artifact can be produced); Gate 10 per-operation contract tests.

## G01-D02 — Capability layer is decorative: 29 PROPOSED records, execution_plan null, never read at runtime (CRITICAL, owner: Gate 04)

**Files:** video-factory-g1/seed-definitions/workflow-1.0.0/capabilities.json; video-factory-g1/tools/registry_tool.py:207-218 (loads capability_versions only); video-factory-g1/database/migrations/001_g1_registry.sql:60-82 (capability_versions + capability_execution_plans skeleton)

**Finding:** All 29 capability records (8 creative + 5 narrative-intelligence + 16 step slots) are status PROPOSED with execution_plan=null. The loader inserts them into capability_versions (registry DB); capability_execution_plans is never populated by any code. Verified by grep: NO runtime tree (coordinator, API, worker, evaluation, runtime services, storage) reads capability_versions or capability_execution_plans. The only runtime use of 'capability' is the capability_slot STRING as a provider_configs scope key in Coordinator._resolve_config (coordinator.py:296-306) and evaluation context.py:110. The programme hierarchy Operations->Capabilities->Atomic Actions does not exist in code: there are no atomic-action records at all; an 'attempt' is per-unit, not per-action.

**Proving test:** Gate 04: op->capability->action resolution test over all 192 operations reading the same records the runtime reads; a capability with no execution plan fails resolution explicitly.

## G01-D03 — No registry-driven graph materialization: dependency_templates never read by planning/execution code (HIGH, owner: Gate 04)

**Files:** video-factory-g2/coordinator/coordinator.py:373 plan_unit (caller-supplied depends_on/input_artifact_ids); video-factory-g9/tools/accounting.py + upgrade_rehearsal.py (only readers of dependency_templates: counters)

**Finding:** The 191 REQUIRED dependency templates form a single linear chain 01.01->...->16.12 in the seed. No planning, scheduling, or execution code reads them. Every executed chain (station suites, G9 full run = 18 hand-planned units) is hand-built in driver/test code via plan_unit(depends_on=..., input_artifact_ids=...). A production therefore executes whatever a caller hand-plans; nothing materializes or checks the 192-operation graph (Gate 12 prerequisite missing).

**Proving test:** Gate 04/12: materialization test — planning a production from the registry produces units+dependencies equal to the templates for the production's unit_keys; Gate 10 dependency-relationship tests per operation.

## G01-D04 — 12.12 routing divergence: registry station 5 vs serving tree g6 (steps 09-12, labelled station 4) (HIGH, owner: Gate 03)

**Files:** video-factory-g1/seed-definitions/workflow-1.0.0/operations.json (12.12 station=5, step 12 in station 5); video-factory-g6 (station-04 workflows serve 12.12; OPERATION-scope binding workaround in g6/tools/setup_env.py); video-factory-g2/coordinator/coordinator.py EXECUTOR_STEP_RANGES (Gate 02 seam, in flux: step-based 09-12->g6)

**Finding:** All step-12 operations carry registry station 5, but the g6 tree serves steps 09-12 and its station workflow is station-04. Config resolution (STATION scope) uses the REGISTRY station (5), while executor routing/bindings use the serving tree — the Gate G OPERATION-scope binding for 12.12 is a workaround, and the Gate 02 fix's step-based executor mapping is an undocumented special case relative to the registry. No owner approval resolving the discrepancy exists (Gate 03 expects the decision-package route).

**Proving test:** Gate 03: route test for all 192 operations (registry station == serving tree station == scheduler executor mapping) after the owner's 12.12 ruling; registry hash impact recorded.

## G01-D05 — Semantic validation is nominal: 44 named policy checks collapse to 2 rubrics; all other named checks unimplemented (HIGH, owner: Gate 06)

**Files:** gate-e/evaluation_service/layers.py semantic_layer + RUBRICS={12.12: rule_of_six, 08.12: script_canon_coverage}; video-factory-g1 seed validator_policy (44 distinct names across 192 ops)

**Finding:** Every operation names 2-4 step-specific validators (44 distinct names: canon_validation, causality_check, identity_continuity, ...). The evaluation service maps ALL of them to 'the semantic layer'; the semantic layer implements exactly two deterministic rubrics (12.12, 08.12). For every other operation it returns REVIEW_REQUIRED (NO_RUBRIC / no_qa_binding / BLOCKED). With a credential-bearing provider binding it returns BLOCKED 'real_semantic_judging_not_in_scope_gate_e' — real judging is deliberately unimplemented. Net effect: no operation can be semantically PASSed today; acceptance routes through human approval (by design while unarmed, but the named-check coverage claimed by the registry does not exist).

**Proving test:** Gate 06: per-policy-name coverage test — each named validator in the seed maps to an implemented check or an explicit unimplemented record; Gate 08 calibration on EXPERT cases.

## G01-D06 — Approval policies unenforced for 8 of 11 policy values (HIGH, owner: Gate 05)

**Files:** video-factory-g1 seed approval_policy (11 values); video-factory-g2/database/migrations/003/004/005 (gate_requirements: script->HG2, master_package->HG4, derivative_package->HG5 only); video-factory-g2/coordinator/coordinator.py _verify_input_gates

**Finding:** Registry declares 11 approval policies (EDITORIAL x60, DIRECTOR x24, PRODUCER_AND_BUDGET_OWNER, RIGHTS_OWNER, CANON_STEWARD, PRODUCER, LEARNING_OWNER, HUMAN_GATE_* x4). Runtime gate enforcement exists only for three artifact types via gate_requirements (HG2/HG4/HG5). The other policies have no table, no check, and no caller — claim() enforces only gate_requirements rows. HUMAN_GATE_DERIVATIVE/HUMAN_GATE_RELEASE map to HG5/HG4 by migration for derivative_package/master_package; HUMAN_GATE_SCRIPT->HG2; the remaining seven values are dead declarations.

**Proving test:** Gate 05/06: policy-enforcement matrix test — for each approval_policy value, a claim against a gated input without the required approval is refused, or the policy is formally retired by owner decision.

## G01-D07 — POST /units/{id}/events lets WORKER and SCHEDULER roles fire human_approved (and any TRANSITIONS event) (HIGH, owner: Gate 05)

**Files:** video-factory-g3/api/server.py events route (_allow OPERATOR, SCHEDULER, WORKER); video-factory-g2/coordinator/coordinator.py event() (no per-event role concept)

**Finding:** The generic events route is the path by which human_approved moves AWAITING_HUMAN->ACCEPTED. It authorizes OPERATOR, SCHEDULER and WORKER role tokens alike, for ANY event name in TRANSITIONS (cancel, block, human_approved, human_rejected, retry-adjacent events). A worker-token holder can therefore approve its own unit's human gate — a coordinator-authority bypass at the API surface (TRANSITIONS still guards state, so the unit must be AWAITING_HUMAN). Live exploitation test deliberately NOT run (Gate 02 battery in flight); recorded as an audit test for Gate 05.

**Proving test:** Gate 05 T-test: WORKER and SCHEDULER tokens POST human_approved -> 403; OPERATOR -> 200; same matrix for cancel/block; audit evidence rows asserted.

## G01-D08 — Identity is self-asserted: X-Identity header + body worker_id are unauthenticated claims (MEDIUM, owner: Gate 05)

**Files:** video-factory-g3/api/server.py _authenticate (identity from X-Identity, default role name); video-factory-g3/api/server.py claim/complete routes (worker_id from request body)

**Finding:** Role tokens are shared per role (env vars); the identity string is whatever the caller puts in X-Identity, and worker_id is a body field. GB-SEC-01 binds completion to the claim's worker_id string, but any holder of the WORKER role token can present any worker_id. This is the recorded local single-operator model (Gate H T11 section 17) — acceptable locally, not a production identity model. Also: server.py carries a default DSN with the dev database password literal and a default dev operator token literal as code fallbacks.

**Proving test:** Gate 05/11: identity-binding test — a completion whose authenticated identity differs from the attempt's worker identity is refused even with a valid role token; secret-scan test asserts no credential literals in source defaults.

## G01-D09 — Attempts endpoint exposes fencing_token to every read role (Gate 02 seam, in flux) (MEDIUM, owner: Gate 02)

**Files:** video-factory-g3/api/server.py attempts route (_allow READ_ROLES incl. VALIDATOR; fencing_token added by the D-H1 fix)

**Finding:** The D-H1 design-(b) fix the Gate 02 builder is implementing exposes the current attempt's fencing_token on GET /units/{id}/attempts to OPERATOR/WORKER/SCHEDULER/VALIDATOR alike. Programme Gate 02 task 6 requires that only the authorized executor can obtain its attempt's execution credentials. Combined with D08 (worker_id is a body claim), a VALIDATOR-token holder could read a fencing token and complete as the claiming worker_id. Flagged for the Gate 02 verifier to rule on; not independently a Gate 01 blocker.

**Proving test:** Gate 02 T02-C/D extended: fencing token not returned to non-worker roles; completion with a token obtained via a VALIDATOR read is refused (or the exposure is owner-accepted with the rationale recorded).

## G01-D10 — Zero-caller / test-only coordinator and adapter surface (dead or unwired code) (MEDIUM, owner: Gate 05)

**Files:** video-factory-g2/coordinator/coordinator.py:930 heartbeat (zero callers anywhere, no API route); coordinator.py:1279 submit_provider_job legacy v1 (only a runtime-services TEST calls it); coordinator.py:1367 attach_provider_job_id (test-only caller); coordinator.py:1374 provider_timeout (test-only caller; the Gate H T6 harness called it directly); coordinator.py:1021 cleanup_candidates (one G2 test calls it; no API route, no runtime service loop — STAGED candidates are never cleaned in operation); gate-c/worker_service/adapters.py: Adapter.estimate (no product caller), Adapter.validate_config (never invoked when bindings are created or used), Adapter.capabilities (no product caller); gate-f/runtime_services/lanes.py:68 capacity_max_in_flight (zero references — dead alias); gate-d/storage_service/storage.py StorageClient.head (test-only caller)

**Finding:** Static call-graph (AST over all factory + programme Python trees, name+string references) plus targeted grep verification per name. Full method and false-positive discipline in evidence/callgraph_notes.md. Operationally significant: heartbeat (lease extension has no path — long executions rely on TTL+reaper), provider_timeout (nothing in the composed product flow ever marks a timed-out job UNKNOWN; the reconciler-service default poller is the G2 MockProvider, see D11), cleanup_candidates (candidate store grows unbounded in operation).

**Proving test:** Gate 05: reachability re-run of this call graph in CI; each listed function either gains a product caller with a behavior test or is removed/retired by an owner-visible change record.

## G01-D11 — Async provider path is service-tested but not composed: reconciler's standing poller is the test MockProvider; v2 jobs carry synthetic provider ids (MEDIUM, owner: Gate 05)

**Files:** gate-f/runtime_services/reconciler_service.py:40 (poller defaults to mock_provider.MockProvider; runner.py constructs ReconcilerService() with no provider); video-factory-g2/coordinator/mock_provider.py (docstring: 'Simulated provider for G2 tests only'); video-factory-g2/coordinator/coordinator.py submit_provider_job_v2 (provider_job_id pre-filled f'local-{job_id}'); gate-c/worker_service/service.py _JOBS (async jobs live in the worker service's in-memory map; no workflow polls /jobs and no caller invokes attach_provider_job_id in product code)

**Finding:** In the composed stack (Gate F runner), reconciliation polls the G2 test MockProvider, which answers not_found for any real job — Gate H T6 passed only because its harness injected a stub poller and called provider_timeout itself. No n8n executor submits an async binding or polls the worker service's /jobs; the executor flow is synchronous /work + complete. Async is therefore IMPLEMENTED at service level and UNCOMPOSED at system level.

**Proving test:** Gate 05/07: composed async test — an async-mode binding executes through executor -> worker /jobs -> coordinator job -> reconciler with the REAL poller wiring (no harness-injected poller) to ACCEPTED; T02-G crash-after-adoption variant.

## G01-D12 — All executed content is simulated fixture data; several specific builders ignore their declared inputs (MEDIUM, owner: Gate 10)

**Files:** gate-c/worker_service/payloads.py (G4_OUTPUTS fixed strings; STORY_NODES/BEATS/SCENES/LINES/SHOTS constants; RULE_OF_SIX scores 8.6/8.2/7.4/7.9/7.1/6.8; DERIVATIVES/PREDICTIONS constants; 08.12 fixed script lines naming 'Mara'/'Tobin')

**Finding:** Input-faithfulness by builder (source trace): G4 six builders and 11.12 ignore ALL inputs (fixed text + id interpolation). 05.12/06.12/07.12/08.12/09.12/10.12 use only an upstream artifact ID as a reference string. 13.12/14.12/15.12/16.12 genuinely derive structure from input content, but 15.12 fabricates platform_post_id 'mock-<id>-001' and 16.12 fabricates actual_views = midpoint+500 (its own content carries the 'Mock actuals' disclaimer). The 08.12 script is one fixed story — as fixture data for a story-agnostic pipeline it must never be mistaken for generated content. Nothing here is a defect of honesty (all labelled deterministic/mock in code) — it is the precise boundary of what 'executed' means for L3.

**Proving test:** Gate 10: per-operation input-sensitivity test — varying a declared input changes the output in the contractually specified way (or the operation's plan records input-independence explicitly). Gate 07 replaces fixture content with provider output per modality.

## G01-D13 — reported_actual_cents: 90 is a seeded fixture datum presented as measured cost in every budget total (MEDIUM, owner: Gate 09)

**Files:** gate-c/worker_service/adapters.py DeterministicLocalAdapter.execute (params.reported_actual_cents else estimate); video-factory-g4..g9 tools/setup_env.py + g9 setup (STATION bindings seed reported_actual_cents: 90 against est 100)

**Finding:** Every accepted budget figure in the programme's evidence (4x90, 18x90=1620c) is this binding datum, not a measured cost: the deterministic adapter performs no metering, and pricing rules (CALCULATED) match only when usage keys exist — deterministic usage is {'deterministic': true}, which matches no pricing rule, so FINALIZED always falls to 'reported_actual'. Programme Gate 09 guardrail explicitly bars treating this value as measured AI-provider spending. The mechanism is honest and recorded in code comments; the deficiency is that no measured-cost path exists yet for the only adapter that executes.

**Proving test:** Gate 09: measured-cost test — a priced execution's FINALIZED amount equals the pricing-rule computation from recorded usage (basis 'calculated'), and the 90c datum is absent from any production-environment binding.

## G01-D14 — Golden set: 7 SEED / 0 EXPERT — semantic layer permanently unarmed; factory set smaller than earlier programme summaries stated (MEDIUM, owner: Gate 08)

**Files:** gate-e/evaluation_service/golden.py (ARM_THRESHOLD=50, EXPERT only); gate-e/evaluation_service/golden_cases/ (7 seed-*.json files)

**Finding:** On disk there are exactly 7 SEED cases (seed-01..07; seed-07 added at Gate G) and 0 EXPERT. Arming is correctly EXPERT-only in code, so the semantic layer cannot arm; every unit's acceptance routes via AWAITING_HUMAN -> human_approved. (The Gate A-era figure '6 SEED' in some summaries predates seed-07.) No holdout separation exists because there is nothing to hold out.

**Proving test:** Gate 08: 50+ EXPERT cases with provenance records; arming test (49 EXPERT unarmed, 50 armed) re-run; holdout accuracy report for the two implemented rubrics before any new rubric arms.

## G01-D15 — S3 storage is stub-tested only; the running stack uses LocalStorage on the same host (MEDIUM, owner: Gate 09)

**Files:** gate-d/storage_service/storage.py S3Storage (stdlib SigV4); gate-d/storage_service/tests (in-process stub S3 handler)

**Finding:** S3Storage mechanics (signing, PUT/GET/HEAD/DELETE, promote) are verified only against an in-process stub HTTP handler in the storage tests. factory_from_env defaults to LocalStorage; no setup in any tree configures a real S3 endpoint. Artifact durability claims are therefore local-disk claims. (Gate 09 owns a real S3-compatible backend in the test environment.)

**Proving test:** Gate 09: storage battery re-run against a real S3-compatible endpoint (put/promote/get/hash/delete + outage case), evidence recorded with endpoint identity.

## G01-D16 — Library-mode claim() lets the caller estimate win over the resolved binding (D-C1 correction is API-path only) (LOW, owner: Gate 05)

**Files:** video-factory-g2/coordinator/coordinator.py claim/_claim_txn (estimate_mode='library' default: caller estimate wins)

**Finding:** Recorded and owner-ruled at Gate D (correction at the API path), but the library surface remains: any in-process caller (scheduler passes the resolved config estimate; tests pass deliberate estimates) can reserve below/above the binding estimate. No current product caller abuses it; the invariant 'config is authoritative' holds only at the HTTP boundary.

**Proving test:** Gate 05: library-caller inventory test — every in-process claim caller passes either no estimate or the resolved binding's estimate; divergence requires a recorded exception.

## G01-D17 — register_artifact is an unvalidated CURRENT-promotion surface (OPERATOR and WORKER roles) (LOW, owner: Gate 05)

**Files:** video-factory-g3/api/server.py productions/{id}/artifacts POST (_allow OPERATOR, WORKER); video-factory-g2/coordinator/coordinator.py register_artifact (supersedes prior CURRENT of the type; no validation, no gate check)

**Finding:** By design this registers operator fixtures/inputs, and Gate H T1 verified a planted same-type artifact does not substitute for a unit's validated output in dependency checks. It remains true that a WORKER-role caller can supersede the CURRENT artifact of any type in a production outside any unit's completion — downstream claim currency checks will then see the planted artifact as CURRENT input. Recorded as a surface to fence at Gate 05, not as an observed exploit.

**Proving test:** Gate 05: WORKER-role register attempt -> 403 (or owner-accepted with rationale); OPERATOR registration writes an audit-distinguishable provenance marker asserted in test.

## G01-D18 — Legacy single-verdict POST /units/{id}/validate lets OPERATOR bypass the evaluation service (LOW, owner: Gate 06)

**Files:** video-factory-g3/api/server.py validate route (legacy body: verdict + deterministic flag, validator defaults to 'dashboard')

**Finding:** Alongside the Gate E evaluations-array path, the pre-Gate-E single-verdict body still works for OPERATOR: one call with verdict PASS accepts a VALIDATING unit without any evaluation-service layer running. It is the operator's own authority (OPERATOR is the human), so this is a governance note, not a vulnerability: acceptance provenance recorded in quality_evaluations cannot distinguish a layered evaluation from a bare operator verdict except by validator/method strings ('dashboard'/'operator_review').

**Proving test:** Gate 06: provenance test — every ACCEPTED unit's quality_evaluations show either evaluation-service layer rows or an explicit operator-override record; dashboard acceptance counts reported separately.

## G01-D19 — Worker-service async job map is in-memory and service-local; a worker-service restart orphans submitted jobs (LOW, owner: Gate 05)

**Files:** gate-c/worker_service/service.py _JOBS dict + module docstring (acknowledged: 'A restart loses the map')

**Finding:** Acknowledged in the service's own docstring with recovery assigned to the coordinator reconciler — but per D11 the reconciler's standing poller cannot poll these jobs, so the acknowledged recovery path does not exist in the composed stack. Recorded separately from D11 because the fix may land in either gate (durable job registry at Gate 05, or real poller wiring at Gate 07).

**Proving test:** Gate 05: kill worker service between submit and poll in a composed async run; the job still reaches a terminal coordinator state exactly once.

## G01-D20 — Dead/legacy code carried in product trees (LOW, owner: Gate 05)

**Files:** video-factory-g2/coordinator/mock_provider.py (test double living in the coordinator package; imported by the production reconciler service — see D11); video-factory-real-ai-programme/gate-b/migrations-draft/ (superseded drafts 006-009 kept beside applied migrations); video-factory-g4..g8 per-tree mock worker servers (retired from flows at Gate G, files remain); gate-f/runtime_services/lanes.py capacity_max_in_flight alias (zero references)

**Finding:** None of these execute in the composed flow except mock_provider (D11). They are recorded so Gate 05/14 can retire them deliberately rather than by drift; the migration drafts in particular sit one directory away from applied migrations and invite misreading of the applied chain (Gate 00 manifest already separates them).

**Proving test:** Gate 14 evidence lock: change manifest lists each retired file; regression battery green after removal.
