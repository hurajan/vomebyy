# GATE 01 — Architecture Audit Report

**Nature of this audit:** source-level tracing + existing-evidence analysis,
executed from source (registry seed, contracts, coordinator, API, worker /
evaluation / runtime / storage services, workflow JSONs) — **not** a re-check
of the Gate A report's conclusions. **No live test batteries were run and no
services were started** (Gate 02's battery was in flight; the environment
serialization rule forbids concurrent batteries). Where a fact needs a live
check, it is recorded as a deficiency with the test its owner gate must run.
Gate 02's files (the D-H1 seam: coordinator executor-identity mapping,
attempts-endpoint fencing exposure, executor resume branches) were **in flux
during the audit** and are flagged wherever this report touches them.

**PASS condition (programme):** all 192 operations individually accounted
for, every gap with an owner and remediation path, nothing labelled
production-ready without evidence. The accounting is complete
(`evidence/operation_classification.json`, 192 rows); the register
(`REMEDIATION_REGISTER.md/.json`, 20 deficiencies) assigns every gap an
owner gate and a proving test.

## Classification summary (programme §2 levels)

| Level | Count | Basis |
|---|---|---|
| L1 DEFINED | **192** | All registered in seed workflow 1.0.0, definition_hash ea4503f5…, with step contracts |
| L2 EXECUTABLE (specific binding) | **19** | Operation-specific builders in `payloads.py` SPECIFIC_OPS |
| L2 EXECUTABLE (generic binding only) | **173** | Callable only via the generic fallthrough (D01) |
| L3 TESTED (individually executed, retained evidence) | **20** | Reconciled in §4 below |
| L4 PRODUCTION-VERIFIED | **0** | No real provider execution (OD-A3), no production-equivalent deployment (Gate 11 / G0.6), no measured costs (D13). Stated plainly: **no operation is production-verified.** |

## 1. Registry enumeration (task 1)

Seed `video-factory-g1/seed-definitions/workflow-1.0.0/operations.json`:
192 operations (12 per step × 16 steps; stations 24/24/48/36/36/24) and
191 dependency templates — verified by direct parse, matching Gate 00's
`registry_validate` PASS (hash ea4503f516fc…, contracts_checked 50).
Every operation records: station, step, title, responsibility,
`capability_slot` (16 distinct slots), `validator_policy`
(schema_validation + dependency_integrity + 2–4 step-specific names;
44 distinct names), `approval_policy` (11 distinct values),
`resource_ceiling` (max_attempts 3 everywhere; per-unit cost ceilings are
null, `cost_policy: PIN_AT_PRODUCTION`), and `unit_key` (12 production,
12 each of scene/shot/asset/claim/person/story/beat/sequence/master/
derivative/release in their steps).

Findings inside the enumeration itself:

- **The 191 templates are a single linear chain** (01.01→01.02→…→16.12,
  all REQUIRED, no branching, no artifact types). They cannot express the
  per-unit_key graph (e.g. per-scene units) and **no planning or execution
  code reads them** — only G9 accounting/upgrade tools count them (D03).
- **Contracts are step-level, not operation-level.** Input/output schemas
  exist per step (32 files); deliverable schemas exist only for the 16
  step exits (`.12`) plus `op-14.01` (Gate G). The other 175 operations
  have no typed output contract of their own; the one
  `deliverables/generic-fallback.schema.json` is never selected by any
  code path per-operation.
- **Required inputs are not in the registry.** Runtime planned inputs are
  artifact IDs a caller supplies to `Coordinator.plan_unit`
  (coordinator.py:373); the registry carries no operation→input-artifact-
  type mapping. "Required inputs" for an operation exist only implicitly,
  in the hand-built chains of drivers/tests.

## 2. Capabilities (task 2) — the hierarchy does not reach the runtime

29 capability records in `capabilities.json`: 8 creative capabilities,
5 narrative-intelligence components, 16 step capability slots — **all
status PROPOSED, all `execution_plan: null`** (verified by parse). The G1
loader writes them into the registry DB's `capability_versions`
(registry_tool.py:207–218); `capability_execution_plans` (migration 001)
is never populated and **never read**: a verified grep across the
coordinator, API, worker, evaluation, runtime, and storage trees finds
zero reads of either table. The sole runtime trace of the capability
layer is the `capability_slot` *string* used as a scope key when
resolving provider configs (`Coordinator._resolve_config`,
coordinator.py:296–306; evaluation `context.py:110`).

Consequence, stated exactly: the programme hierarchy
*Operations → Versioned Capabilities → Atomic Actions → Attempts* exists
only for its first and last elements. There are no atomic-action records,
no action-level attempts (an attempt is per execution-unit), and no
capability approval/activation state beyond PROPOSED. Gate 04 owns the
repair (D02).

## 3. Execution paths (tasks 3–4)

**Worker binding.** Every operation is callable through the
deterministic-local (and fenced mock) adapter → `payloads.build`
(worker_service/payloads.py). 19 operations have specific builders
(SPECIFIC_OPS: the six G4 text outputs, the twelve station-chain exits
05.12–16.12 minus none, plus 03.02 and 14.01 — full list in the
classification JSON). **The other 173 fall through to**
`return "step_output", {"kind": "step_output", "operation_id": ...}` —
a generic success payload with no operation semantics (D01). Credential
adapters (openrouter-compatible, direct-http-text, http-{image, video,
speech, transcription, stock}) are operation-agnostic: they return
provider content under a generic artifact type and never consult
payloads or deliverable contracts; with no credential they raise
BlockedError — verified in source, no fabrication path exists.

**Simulated content.** All 19 specific builders emit fixture data
(constants in payloads.py; sampled and characterized builder-by-builder
in D12): fixed premise/script text (08.12's script names Mara and Tobin
and a brass key), fixed Rule-of-Six scores, fixed derivative predictions,
fabricated `platform_post_id`s, and 16.12's fabricated actuals (its
content carries its own "Mock actuals" disclaimer). Six builders ignore
their inputs entirely. This is honestly-labelled deterministic fixture
behavior — and it is the entire current meaning of "executed".

**Envelope production** applies only to `.12` exits and only for the
payload-backed adapters (envelope.py `wrap`: provider must be
deterministic-local or mock). A provider-adapter exit result stays bare
and would meet the evaluation schema layer as a non-envelope — recorded
here as a Gate 06/07 composition question, not exercised live.

**Runtime chain** (full trace in `evidence/callgraph_notes.md`):
claim → outbox dispatch → n8n receiver/station/executor → worker service
→ API complete → coordinator VALIDATING → evaluation service →
`/validate` → ACCEPTED or AWAITING_HUMAN → `human_approved`. Breaks:
async branch uncomposed (D11), standing reconciler polls the test
MockProvider (D11), heartbeat unreachable (D10).

**Uncalled functions:** verified zero-/test-only-caller list of 10
functions (callgraph_notes.md), including `Coordinator.heartbeat` (zero
callers anywhere), `provider_timeout` and `attach_provider_job_id`
(test-only), `cleanup_candidates` (test-only, operationally unwired),
and the adapter interface's `estimate`/`validate_config`/`capabilities`
(never invoked in product code — bindings are never validated).

## 4. Reconciliation of the Gate H 20/172 accounting (task 6)

**Verdict: CONFIRMED, with one classification refinement.** My trace of
`gate-h/evidence/results/executed_union.json` against source and the
underlying evidence files supports exactly 20 individually executed
operations and 172 never individually executed:

- **19 via the worker path** (n8n executor → worker service →
  deterministic adapter → completion → evaluation): the G9 full run's 18
  (all 16 exits + 01.01 + 14.01) and 03.02 from the G4 suite. These are
  precisely the 19 SPECIFIC-binding operations — every operation with a
  specific builder has been executed at least once, and no generic-only
  operation was executed through the worker path.
- **1 via a different path — 11.06** (Gate H T6 Part A): executed through
  the worker service's `/jobs` async path with the direct-http-text
  adapter against a local stub provider, driven UNKNOWN, and completed
  by the reconciler with a harness-injected poller (settled 450¢,
  ACCEPTED). Its payload was stub-provider content — **not** the generic
  builder's output, and no n8n executor participated. It counts as L3
  (individually executed with retained evidence) with
  `execution_path: async_stub_provider_reconciler` recorded in the
  classification JSON so the distinction is never lost.
- The coordinator-level fixture completions in Gate H T1/T4/T5/T7
  (05.12, 11.06, 12.12) add no new operations beyond the union and are
  not counted separately — the executor's own accounting already handled
  this correctly.

No operation in the 20 rests solely on a coordinator fixture completion.
The 172 figure is exact: 173 generic-binding operations minus 11.06.

## 5. Contract-surface audit (task 5) — checklist

Each item: enforced where claimed? File:line evidence in the register
and callgraph notes.

| Surface | Verdict | Notes |
|---|---|---|
| Reserve/settle/release | **Enforced** | claim reserves + RESERVE ledger in one txn (coordinator.py _claim_txn); settlement only via `_settle_reservation` (HELD→SETTLED, rowcount-guarded) from sync completion, provider-job completion, or `settle_provider_charge`; release only via `retry_unit` with RELEASE rows. Duplicate settle refused by rowcount/state guards (Gate H T4 evidence). |
| Pricing / FINALIZED selection | **Enforced, with a structural gap** | `_finalize_amount` selection order exactly as Gate D locked; `_calculated_amount` never invents a price. But deterministic usage `{deterministic: true}` matches no pricing rule, so every executed unit finalizes on `reported_actual` — the D13 fixture datum. |
| settle_provider_charge | **Enforced** | FOR UPDATE lock, PROVIDER_REPORTED + requires_reconciliation precondition, FINALIZED-citation double-settle refusal, hard-ceiling check. |
| Artifact staging/promotion | **Enforced** | Stage → hash-verify (`_prepare_completion_content`, mismatch commits audit + refuses) → promote on registration; STAGED cleanup exists but is operationally unwired (D10). |
| Invalidation cascade | **Enforced** | Recursive dependency cascade (depth 50), fencing bump + lease deletion for affected units, PARTIAL_REPAIR replacement units; master_package requires APPROVED HG4 on the exact artifact or a distinct co-authorizer (GB-SEC-02), refusals audited. |
| Validation layers | **Partially enforced** | Schema (exits + 14.01 only; mid-step ops get PASS with `applied: False`), technical (sha/refs), continuity (planned-vs-declared) are real. Semantic: D05 — 44 named checks, 2 rubrics, real judging unreachable. Worker verdicts are advisory-only (context loads them as report fields; layers never read them — verified in layers.py/context.py). |
| Arming | **Enforced** | `golden.armed()` counts EXPERT only, threshold 50 (golden.py:35,56–58). State: 7 SEED / 0 EXPERT → NOT ARMED (D14). |
| Human gates | **Enforced at claim; one API surface open** | Binding = gate row snapshots artifact id+sha at creation; `decide_gate` refuses non-PENDING and (via API) requires the bound sha still match; claim-time `_verify_input_gates` refuses gated inputs without APPROVED gates. Open surface: the generic events route lets WORKER/SCHEDULER fire `human_approved` (D07). Only 3 of 11 approval policies map to gates at all (D06). |
| Fencing/leases | **Enforced** | Monotonic fencing per unit; completion checks token + lease worker + attempt worker (GB-SEC-01); stale outcomes recorded as FAILED/STALE_FENCING with flagged evidence, never settled. Reaper moves expired CLAIMED/RUNNING to RETRY_WAIT, or UNKNOWN when a provider job is outstanding. Exposure note: fencing token now readable by all read roles on the attempts endpoint (D09, Gate 02 seam in flux). |
| Recovery | **Enforced at service level; composition gaps** | Retry driver: classification order, registry attempt cap 3, dead-letter via (RETRY_WAIT, block) with audit + outbox. Reconciler: attempt-linked jobs only, legacy reported untouched. Gaps: standing poller is the test MockProvider (D11); `provider_timeout` has no product caller (D10). |
| Coordinator authority | **Holds in code, with the D07/D08/D17/D18 surfaces** | Workers/services hold no DB write path except through the coordinator API/library; n8n holds no state; scheduler claims are coordinator claims. The surfaces in D07/D08/D17/D18 are role-model looseness at the API, recorded for Gate 05 — none was live-tested in this audit. |

## 6. Deficiency register summary

20 deficiencies (2 CRITICAL, 5 HIGH, 8 MEDIUM, 5 LOW) in
`REMEDIATION_REGISTER.md/.json`, each with files, the owning gate
(02: 1 · 03: 1 · 04: 3 · 05: 9 · 06: 2 · 08: 1 · 09: 2 · 10: 1 — D12 is
owned by Gate 10 with Gate 07 noted) and the test that will prove the
fix. The CRITICAL pair: **D01** generic success fallthrough (173 ops)
and **D02** the decorative capability layer. The HIGH set: no
graph materialization (D03), 12.12 routing (D04, Gate 03 decision
package), nominal semantic validation (D05), unenforced approval
policies (D06), and the events-route human-approval surface (D07).

## 7. Audit tests recorded for later gates (not run here)

Per the serialization rule, the following live checks are recorded, not
executed: D07's role-matrix exploitation test (Gate 05); D09's
fencing-exposure test (Gate 02 verifier); D11/D19's composed async +
worker-restart test (Gate 05); D17's worker-role registration test
(Gate 05); D16's library-caller inventory (Gate 05). Each appears in the
register with its proving test.

## 8. What this audit did not do

No live batteries, no DB reads against live scratch databases, no
service starts. Statements about runtime *behavior* rest on prior gates'
retained evidence (cited per item) plus source; statements about source
are this audit's own trace. Gate 02's in-flight changes were read as
found on disk at audit time and are identified as in-flux wherever used.

## Amendment — owner terminology correction (2026-10-28, Raj's Gate 03 ruling)
The table above (§ classification) is superseded in terminology: the 173 operations whose only binding is the generic fallthrough are **not genuinely L2 EXECUTABLE**. They are recorded as **technically dispatchable but lacking operation-specific implementation evidence** until Gate 04 establishes the required capability/action bindings. Genuine L2 = **19**. L1 (192), L3 (20), and L4 (0) are unchanged. `evidence/operation_classification.json` carries the correction per-row (`L2_kind: DISPATCHABLE_GENERIC_ONLY`, `L2_EXECUTABLE: false`, readiness label) and in its counts block. Historical documents that cited "L2 192" (including Gate H-era summaries) are superseded by this amendment wherever cited.
