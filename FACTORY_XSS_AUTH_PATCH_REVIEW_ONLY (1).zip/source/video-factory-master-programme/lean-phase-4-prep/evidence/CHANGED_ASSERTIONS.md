# Changed assertions — Lean Phase 4 prep

**Product code: NONE changed. Product test assertions: NONE changed.**
This prep was preparation-only per its brief; the two blockers found
(FINDING.md F-P4P-01 / F-P4P-02) were reported, not fixed.

Harness-level changes (this prep's own harness only):
1. The prep harness's initial `plan_0812` planned 08.12 with planned
   inputs [canon, story_architecture, beat_graph, scene_set] — the
   harness author's misreading of the Phase 2 spec §3.2 mechanics
   note. The spec's frozen fixture planning is [canon] only, and the
   Gate G continuity contract requires declared == planned in both
   directions. Corrected after the decisive probe: the probe and
   P4P-3 use [canon]-only planning. The original 4-input run is
   preserved as probe Case A evidence (it is half of the finding's
   proof, not a discarded failure).
2. Configuration seeding into the prep scratch DB (data, not code):
   the slice OPERATION binding with the recorded stub endpoint
   override (base_url=http://127.0.0.1:8799) via Phase 3's
   setup_slice.py, plus a STATION 4 deterministic-local binding
   (g6 setup shape) so P4P-5's 09.12 claim could reach the gate
   check. The canonical slice binding (no base_url) is untouched.
