#!/usr/bin/env python3
"""INDEPENDENT VERIFIER harness — F-P4P-01 / F-P4P-02 fix (Lean P4).

Written independently of the fix battery's harness. Assertions read
the DATABASE directly (artifacts / execution_units / action_attempts /
plan_action_attempts / financial_evidence / human_gates / audit_events)
rather than trusting harness-side bookkeeping; the API is used for
driving and cross-checked against DB rows.

Verifier's own fixtures:
  - scratch DB lean4_fixverify_scratch (G3 setup chain)
  - own stub provider on :8899 (vfy_stub.py): usage 12345 in / 6789
    out, request id chatcmpl-fixverify-7f3, distinct script text.
    Hand-computed expectation at the seeded pricing rows
    (input 0.0001 c/tok, output 0.0005 c/tok, ROUND_HALF_UP):
      12345*0.0001 + 6789*0.0005 = 1.2345 + 3.3945 = 4.6290 -> 5c
    CALCULATED must be 5, FINALIZED must be 5 (basis calculated),
    and neither may be the 25c claim estimate.

Scenarios:
  setup     build the stack (API 8730 / worker 8795 / eval 8796 /
            n8n 5678 with g5+g6 workflows synced / slice seeded with
            the OPERATION 08.12 binding endpoint overridden to the
            verifier stub / STATION 4 binding for the 09.12 leg)
  v1        P4P-1 reproduction + item-4 gating probe on the
            deterministic chain units (06.12 / 07.12 manifest
            inputs_hash must equal the planned-only refs hash)
  v2        P4P-2 spot: duplicate dispatch
  v3        P4P-5 spot: HG2 PENDING -> 09.12 refused via scheduler
            skip, direct API claim (409 + audit), and the fixed g6
            executor (zero attempts)
  teardown  stop 8730/8795/8796/8899 (n8n left running, shared)

STUB_TESTED throughout; no real provider call is attempted.
"""
import hashlib
import json
import re
import subprocess
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path

import psycopg
from psycopg.rows import dict_row

HERE = Path(__file__).resolve().parent
LOGS = HERE / "logs"
RESULTS = HERE / "results"
HOME = Path.home()
G2 = HOME / "workspace/video-factory-g2"
G3 = HOME / "workspace/video-factory-g3"
G4T = HOME / "workspace/video-factory-g4"
G5 = HOME / "workspace/video-factory-g5"
G6 = HOME / "workspace/video-factory-g6"
PROG = HOME / "workspace/video-factory-real-ai-programme"
PHASE3 = HOME / "workspace/video-factory-master-programme/lean-phase-3"
VENV_PY = str(G2 / ".venv/bin/python")
STORE = PROG / "gate-d/storage_service/.store"
DB = "lean4_fixverify_scratch"
API = "http://127.0.0.1:8730"
WORKER = "http://127.0.0.1:8795"
EVAL = "http://127.0.0.1:8796"
N8N = "http://127.0.0.1:5678"
STUB_PORT = 8899
STUB_URL = f"http://127.0.0.1:{STUB_PORT}"
EXPECT_CALC_CENTS = 5
EXPECT_IN, EXPECT_OUT = 12345, 6789
EXPECT_REQ_ID = "chatcmpl-fixverify-7f3"
CANON_TEXT = ("CANON MANIFEST v1 — universe, chronology, world rules, "
              "knowledge boundaries released.")


def _fixture(name, pattern):
    src = (G5 / "tools/setup_env.py").read_text()
    return re.search(pattern, src).group(1)


TOKENS = {k: _fixture(k, rf'"{k}": *"([^"]+)"') for k in (
    "FACTORY_API_TOKEN", "FACTORY_WORKER_TOKEN", "FACTORY_SCHEDULER_TOKEN",
    "FACTORY_VALIDATOR_TOKEN", "FACTORY_CALLBACK_TOKEN")}
OPERATOR = TOKENS["FACTORY_API_TOKEN"]


def _db_password():
    src = (G2 / "tools/setup_db.py").read_text()
    return re.search(r"CREATE ROLE factory LOGIN PASSWORD '([^']+)'",
                     src).group(1)


DSN = (f"host=127.0.0.1 dbname={DB} user=factory "
       f"password={_db_password()}")


def call(base, method, path, body=None, role=None):
    req = urllib.request.Request(base + path, method=method)
    data = None
    if role == "OPERATOR":
        req.add_header("X-Operator-Token", OPERATOR)
    if body is not None:
        data = json.dumps(body).encode()
        req.add_header("Content-Type", "application/json")
    try:
        with urllib.request.urlopen(req, data=data, timeout=30) as r:
            return r.status, json.loads(r.read() or b"{}")
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read() or b"{}")


def db(sql, args=()):
    with psycopg.connect(DSN, row_factory=dict_row, autocommit=True) as c:
        cur = c.execute(sql, args)
        try:
            return cur.fetchall()
        except psycopg.errors.ProgrammingError:
            return []


def kill_port(port):
    subprocess.run(["fuser", "-k", f"{port}/tcp"], capture_output=True)
    time.sleep(0.5)


def spawn(cmd, env, log_name):
    import os
    e = dict(os.environ)
    e.update(env)
    out = open(LOGS / log_name, "ab")
    return subprocess.Popen(cmd, env=e, stdout=out, stderr=out,
                            start_new_session=True)


def wait_url(url, seconds=60):
    deadline = time.time() + seconds
    while time.time() < deadline:
        try:
            with urllib.request.urlopen(url, timeout=2) as r:
                return True
        except urllib.error.HTTPError:
            return True
        except Exception:  # noqa: BLE001
            pass
        time.sleep(0.5)
    return False


class Scenario:
    def __init__(self, name):
        self.name = name
        self.checks = []

    def check(self, name, ok, detail=""):
        self.checks.append({"name": name, "pass": bool(ok),
                            "detail": str(detail)[:700]})
        print(f"  [{'PASS' if ok else 'FAIL'}] {name} — "
              f"{str(detail)[:220]}", flush=True)

    def finish(self, extra=None):
        ok = all(c["pass"] for c in self.checks)
        doc = {"scenario": self.name, "label": "STUB_TESTED",
               "verdict": "PASS" if ok else "FAIL",
               "checks": self.checks, **(extra or {})}
        RESULTS.mkdir(parents=True, exist_ok=True)
        (RESULTS / f"{self.name}.json").write_text(
            json.dumps(doc, indent=1, sort_keys=True, default=str))
        print(f"{self.name}: {'PASS' if ok else 'FAIL'} "
              f"({sum(1 for c in self.checks if c['pass'])}/"
              f"{len(self.checks)})", flush=True)
        return 0 if ok else 1


# ------------------------------------------------------------ db reads
def unit_db(uid):
    rows = db("SELECT * FROM execution_units WHERE unit_id=%s", (uid,))
    return rows[0] if rows else {}


def wait_unit_state(uid, states, timeout=300):
    deadline = time.time() + timeout
    state = None
    while time.time() < deadline:
        state = unit_db(uid).get("state")
        if state in states:
            return state
        time.sleep(2)
    raise AssertionError(f"unit {uid} stuck in {state}, wanted {states}")


def artifacts_db(pid):
    return db("SELECT artifact_id, artifact_type, version, state, "
              "sha256, produced_by_unit FROM artifacts "
              "WHERE production_id=%s ORDER BY artifact_type, version",
              (pid,))


def manifest_record(uid):
    rows = db("SELECT inputs_hash, output_summary FROM "
              "plan_action_attempts WHERE unit_id=%s AND "
              "action_key='inputs.manifest' ORDER BY recorded_at DESC",
              (uid,))
    return rows[0] if rows else {}


def canon_json(value):
    return json.dumps(value, sort_keys=True, default=str)


def inputs_hash(refs):
    material = {"refs": [{"artifact_type": r["artifact_type"],
                          "artifact_id": r["artifact_id"],
                          "sha256": r["sha256"]} for r in refs],
                "prior": {}}
    return hashlib.sha256(canon_json(material).encode()).hexdigest()


def expected_refs_db(pid, uid):
    """Refs the fixed executor must have sent, reconstructed from DB
    rows only: planned inputs (unit_inputs, in API-returned order —
    the set is asserted equal to the DB's unit_inputs rows), then the
    production's CURRENT artifacts (artifacts-table order
    artifact_type, version) whose produced_by_unit is an ACCEPTED
    unit of the same run, excluding the unit itself and dupes."""
    me = unit_db(uid)
    planned_ids = [str(r["artifact_id"]) for r in db(
        "SELECT artifact_id FROM unit_inputs WHERE unit_id=%s", (uid,))]
    _, uout = call(API, "GET", f"/productions/{pid}/units",
                   role="OPERATOR")
    api_me = [u for u in uout["units"] if u["unit_id"] == uid][0]
    api_planned = api_me.get("input_artifact_ids", [])
    assert sorted(api_planned) == sorted(planned_ids), \
        "API planned inputs disagree with unit_inputs table"
    arts = artifacts_db(pid)
    by_id = {str(a["artifact_id"]): a for a in arts}
    units = {str(u["unit_id"]): u for u in db(
        "SELECT unit_id, state, run_id FROM execution_units "
        "WHERE production_id=%s", (pid,))}
    refs, seen = [], set()
    for aid in api_planned:
        a = by_id[aid]
        refs.append({"artifact_type": a["artifact_type"],
                     "artifact_id": str(a["artifact_id"]),
                     "sha256": a["sha256"]})
        seen.add(aid)
    for a in arts:
        if a["state"] != "CURRENT" or not a["produced_by_unit"]:
            continue
        if str(a["produced_by_unit"]) == uid or str(a["artifact_id"]) in seen:
            continue
        producer = units.get(str(a["produced_by_unit"]))
        if not producer or producer["state"] != "ACCEPTED":
            continue
        if str(producer["run_id"]) != str(me["run_id"]):
            continue
        refs.append({"artifact_type": a["artifact_type"],
                     "artifact_id": str(a["artifact_id"]),
                     "sha256": a["sha256"]})
        seen.add(str(a["artifact_id"]))
    return refs


# -------------------------------------------------------------- driving
def scheduler_prestage():
    sys.path.insert(0, str(PROG / "gate-f"))
    from runtime_services.scheduler_service import SchedulerService
    return SchedulerService(dsn=DSN).run_once()


def post_dispatch(pid, uid, op, station=3, webhook=None):
    payload = {"production_id": pid, "unit_id": uid, "operation_id": op,
               "station": station, "input_artifact_ids": [],
               "force_fail": False, "idempotency_key": f"dispatch:{uid}:1"}
    req = urllib.request.Request(
        webhook or (N8N + "/webhook/dispatch-g5"), method="POST",
        data=json.dumps(payload).encode(),
        headers={"Content-Type": "application/json"})
    deadline = time.time() + 60
    while True:
        try:
            with urllib.request.urlopen(req, timeout=120) as r:
                return r.status
        except urllib.error.HTTPError as e:
            if e.code == 404 and time.time() < deadline:
                time.sleep(3)
                continue
            raise


def make_production(title):
    s, p = call(API, "POST", "/productions",
                {"title": title, "hard_ceiling_cents": 500,
                 "soft_ceiling_cents": 250}, role="OPERATOR")
    assert s == 201, f"production {s}: {p}"
    pid = p["production_id"]
    s, r = call(API, "POST", f"/productions/{pid}/runs", {"kind": "FULL"},
                role="OPERATOR")
    assert s == 201, f"run {s}: {r}"
    s, a = call(API, "POST", f"/productions/{pid}/artifacts",
                {"artifact_type": "canon_manifest", "content": CANON_TEXT,
                 "storage_uri": "local://canon-fixture"}, role="OPERATOR")
    assert s == 201, f"canon {s}: {a}"
    return pid, r["run_id"], a["artifact_id"]


def plan_unit(pid, run, op, depends=(), inputs=()):
    s, u = call(API, "POST", f"/productions/{pid}/units",
                {"operation_id": op, "run_id": run, "unit_key": "main",
                 "depends_on": list(depends),
                 "input_artifact_ids": list(inputs)}, role="OPERATOR")
    assert s == 201, f"plan {op} {s}: {u}"
    return u["unit_id"]


def drive(pid, uid, op, approve=True):
    wait_unit_state(uid, {"READY"})
    scheduler_prestage()
    post_dispatch(pid, uid, op)
    state = wait_unit_state(uid, {"AWAITING_HUMAN", "ACCEPTED", "FAILED",
                                  "BLOCKED", "RETRY_WAIT"})
    if state == "AWAITING_HUMAN" and approve:
        s, _ = call(API, "POST", f"/units/{uid}/events",
                    {"event": "human_approved"}, role="OPERATOR")
        assert s == 200, f"human_approved {op} -> {s}"
        state = wait_unit_state(uid, {"ACCEPTED"})
    return state


def start_stub(tag):
    kill_port(STUB_PORT)
    record = LOGS / f"vfy_stub_requests_{tag}.jsonl"
    if record.exists():
        record.unlink()
    spawn([sys.executable, str(HERE / "vfy_stub.py"), str(STUB_PORT),
           str(record)], {}, f"vfy_stub_{tag}.log")
    if not wait_url(STUB_URL + "/chat/completions", seconds=15):
        raise SystemExit("verifier stub did not come up")
    record.write_text("")
    return record


def stub_calls(record):
    if not record.exists():
        return []
    return [json.loads(l) for l in record.read_text().splitlines() if l]


STATE_FILE = HERE / "vfy_state.json"


def save_state(**kw):
    cur = {}
    if STATE_FILE.exists():
        cur = json.loads(STATE_FILE.read_text())
    cur.update(kw)
    STATE_FILE.write_text(json.dumps(cur))


def load_state():
    return json.loads(STATE_FILE.read_text())


# ------------------------------------------------------------- scenarios
def v1():
    sc = Scenario("v1_p4p1_reproduction")
    record = start_stub("v1")
    pid, run, canon = make_production("VFY P4P-1 reproduction")
    u05 = plan_unit(pid, run, "05.12", inputs=[canon])
    u06 = plan_unit(pid, run, "06.12", depends=[u05], inputs=[canon])
    u07 = plan_unit(pid, run, "07.12", depends=[u06], inputs=[canon])
    for op, uid in (("05.12", u05), ("06.12", u06), ("07.12", u07)):
        st = drive(pid, uid, op)
        sc.check(f"chain {op} ACCEPTED via n8n", st == "ACCEPTED", st)
    # ITEM 4 (behavioral half): the deterministic chain units ran
    # under deterministic-local bindings while ACCEPTED producers'
    # CURRENT outputs existed. Their manifest inputs_hash must equal
    # the PLANNED-ONLY refs hash - no context extras may leak.
    arts = {a["artifact_type"]: a for a in artifacts_db(pid)
            if a["state"] == "CURRENT"}
    canon_ref = {"artifact_type": "canon_manifest",
                 "artifact_id": canon, "sha256": arts["canon_manifest"]["sha256"]}
    planned_only = inputs_hash([canon_ref])
    for uid, extra_type in ((u06, "story_architecture"),
                            (u07, "beat_graph")):
        rec = manifest_record(uid)
        extra = {"artifact_type": extra_type,
                 "artifact_id": str(arts[extra_type]["artifact_id"]),
                 "sha256": arts[extra_type]["sha256"]}
        with_extra = inputs_hash([canon_ref, extra])
        sc.check(f"ITEM4: {extra_type}-era unit manifest hash == "
                 f"planned-only refs (no extras on deterministic path)",
                 rec.get("inputs_hash") == planned_only
                 and rec.get("inputs_hash") != with_extra,
                 f"stored={str(rec.get('inputs_hash'))[:16]} "
                 f"planned={planned_only[:16]} extra={with_extra[:16]}")
    # 08.12 planned [canon] only
    u08 = plan_unit(pid, run, "08.12", depends=[u07], inputs=[canon])
    planned_db = [str(r["artifact_id"]) for r in db(
        "SELECT artifact_id FROM unit_inputs WHERE unit_id=%s", (u08,))]
    sc.check("08.12 planned inputs in DB == [canon] only",
             planned_db == [canon], str(planned_db))
    state = drive(pid, u08, "08.12", approve=False)
    sc.check("08.12 ends AWAITING_HUMAN", state == "AWAITING_HUMAN", state)
    calls = stub_calls(record)
    sc.check("exactly 1 provider call to the verifier stub",
             len(calls) == 1, f"calls={len(calls)}")
    if calls:
        prompt = calls[0]["messages"][0]["content"]
        sc.check("prompt grounded in CURRENT contents (canon id + "
                 "canon text + SC1/SC2)",
                 canon in prompt and "CANON MANIFEST v1" in prompt
                 and "SC1" in prompt and "SC2" in prompt,
                 f"len={len(prompt)}")
    # refs proof from DB reconstruction
    refs = expected_refs_db(pid, u08)
    sc.check("DB-reconstructed refs == [canon_manifest, beat_graph, "
             "scene_set, story_architecture]",
             [r["artifact_type"] for r in refs] == [
                 "canon_manifest", "beat_graph", "scene_set",
                 "story_architecture"],
             str([r["artifact_type"] for r in refs]))
    man = manifest_record(u08)
    sc.check("worker inputs_hash == DB-reconstructed refs hash",
             man.get("inputs_hash") == inputs_hash(refs),
             f"stored={str(man.get('inputs_hash'))[:16]} "
             f"recon={inputs_hash(refs)[:16]}")
    osum = man.get("output_summary") or {}
    if isinstance(osum, str):
        osum = json.loads(osum)
    exp_out = {"inputs": refs, "count": len(refs),
               "input_sha256": [r["sha256"] for r in refs]}
    exp_digest = hashlib.sha256(canon_json(exp_out).encode()).hexdigest()
    sc.check("manifest output digest matches reconstructed refs",
             osum.get("sha256") == exp_digest, "")
    # script artifact from DB + store bytes
    scripts = [a for a in artifacts_db(pid)
               if a["artifact_type"] == "script"]
    sc.check("exactly one script artifact, CURRENT, produced by 08.12",
             len(scripts) == 1 and scripts[0]["state"] == "CURRENT"
             and str(scripts[0]["produced_by_unit"]) == u08,
             json.dumps(scripts, default=str)[:300])
    script = scripts[0]
    raw = (STORE / "objects" / script["sha256"]).read_bytes()
    deliverable = json.loads(raw)["output_artifacts"][0]["content"]
    texts = [l["text"] for l in deliverable["lines"]]
    sc.check("stored script is the VERIFIER stub's text, worker-shaped "
             "(canon_refs == [canon id] on every line)",
             deliverable.get("kind") == "script"
             and any("silver compass" in t for t in texts)
             and all(l["canon_refs"] == [canon]
                     for l in deliverable["lines"])
             and all(l.get("beat_ref") and l.get("story_ref")
                     for l in deliverable["lines"]),
             f"lines={len(texts)}")
    # financial evidence from DB
    ev = db("SELECT charge_class, amount_cents, usage, "
            "provider_request_id, pricing_version FROM "
            "financial_evidence WHERE unit_id=%s ORDER BY created_at",
            (u08,))
    est = [e for e in ev if e["charge_class"] == "ESTIMATED"]
    calc = [e for e in ev if e["charge_class"] == "CALCULATED"]
    fin = [e for e in ev if e["charge_class"] == "FINALIZED"]
    sc.check("ESTIMATED row is the 25c claim estimate",
             len(est) == 1 and est[0]["amount_cents"] == 25,
             json.dumps(ev, default=str)[:300])
    sc.check("CALCULATED == 5c (verifier hand arithmetic: "
             "12345*0.0001 + 6789*0.0005 = 4.629 -> 5)",
             len(calc) == 1 and calc[0]["amount_cents"] == EXPECT_CALC_CENTS,
             json.dumps(calc, default=str))
    fusage = fin[0]["usage"] if fin else {}
    if isinstance(fusage, str):
        fusage = json.loads(fusage)
    sc.check("FINALIZED == 5c, basis calculated, carries verifier "
             "usage (12345/6789) + provider_request_id",
             len(fin) == 1 and fin[0]["amount_cents"] == EXPECT_CALC_CENTS
             and fin[0]["amount_cents"] != 25
             and fusage.get("input_tokens") == EXPECT_IN
             and fusage.get("output_tokens") == EXPECT_OUT
             and fusage.get("_finalization_basis") == "calculated"
             and fin[0]["provider_request_id"] == EXPECT_REQ_ID,
             json.dumps(fin, default=str)[:400])
    gates = db("SELECT * FROM human_gates WHERE production_id=%s "
               "AND gate_kind='HG2'", (pid,))
    sc.check("HG2 gate PENDING in DB, bound to script id + sha256",
             len(gates) == 1 and gates[0]["verdict"] == "PENDING"
             and str(gates[0]["artifact_id"]) == str(script["artifact_id"])
             and gates[0]["artifact_sha256"] == script["sha256"],
             json.dumps(gates, default=str)[:300])
    _, budget = call(API, "GET", f"/productions/{pid}/budget",
                     role="OPERATOR")
    sc.check("budget spent == 275 (270 chain + 5 FINALIZED), "
             "reserved 0",
             budget.get("spent_cents") == 275
             and budget.get("reserved_cents") == 0,
             json.dumps(budget))
    save_state(pid_a=pid, run_a=run, u08_a=u08,
               script_a=str(script["artifact_id"]))
    return sc.finish({"production_id": pid, "unit_08_12": u08})


def v2():
    sc = Scenario("v2_p4p2_duplicate_spot")
    record = start_stub("v2")
    pid, run, canon = make_production("VFY P4P-2 duplicate dispatch")
    u05 = plan_unit(pid, run, "05.12", inputs=[canon])
    u06 = plan_unit(pid, run, "06.12", depends=[u05], inputs=[canon])
    u07 = plan_unit(pid, run, "07.12", depends=[u06], inputs=[canon])
    for op, uid in (("05.12", u05), ("06.12", u06), ("07.12", u07)):
        drive(pid, uid, op)
    u08 = plan_unit(pid, run, "08.12", depends=[u07], inputs=[canon])
    wait_unit_state(u08, {"READY"})
    scheduler_prestage()
    sc.check("claim prestaged", unit_db(u08)["state"] == "CLAIMED",
             unit_db(u08)["state"])
    post_dispatch(pid, u08, "08.12")
    post_dispatch(pid, u08, "08.12")
    state = wait_unit_state(u08, {"AWAITING_HUMAN", "ACCEPTED"})
    time.sleep(10)
    calls = stub_calls(record)
    atts = db("SELECT * FROM action_attempts WHERE unit_id=%s", (u08,))
    scripts = [a for a in artifacts_db(pid)
               if a["artifact_type"] == "script"]
    fin = db("SELECT * FROM financial_evidence WHERE unit_id=%s AND "
             "charge_class='FINALIZED'", (u08,))
    gates = db("SELECT * FROM human_gates WHERE production_id=%s AND "
               "gate_kind='HG2'", (pid,))
    sc.check("duplicate dispatch: unit AWAITING_HUMAN",
             state == "AWAITING_HUMAN", state)
    sc.check("duplicate dispatch: exactly 1 provider call",
             len(calls) == 1, f"calls={len(calls)}")
    sc.check("duplicate dispatch: 1 attempt / 1 script / 1 FINALIZED "
             "(5c) / 1 HG2 gate",
             len(atts) == 1 and len(scripts) == 1 and len(fin) == 1
             and fin[0]["amount_cents"] == EXPECT_CALC_CENTS
             and len(gates) == 1,
             f"atts={len(atts)} scripts={len(scripts)} "
             f"fin={len(fin)} gates={len(gates)}")
    return sc.finish({"production_id": pid, "unit_08_12": u08})


def v3():
    sc = Scenario("v3_p4p5_downstream_spot")
    st = load_state()
    pid, u08, script_id = st["pid_a"], st["u08_a"], st["script_a"]
    s, _ = call(API, "POST", f"/units/{u08}/events",
                {"event": "human_approved"}, role="OPERATOR")
    state = wait_unit_state(u08, {"ACCEPTED"})
    sc.check("08.12 unit ACCEPTED via harness-as-human unit event "
             "(NOT an HG2 decision)", s == 200 and state == "ACCEPTED",
             f"event_status={s} state={state}")
    gates = db("SELECT * FROM human_gates WHERE production_id=%s AND "
               "gate_kind='HG2'", (pid,))
    sc.check("HG2 still PENDING after the unit-level approval",
             len(gates) == 1 and gates[0]["verdict"] == "PENDING",
             json.dumps(gates, default=str)[:200])
    u09 = plan_unit(pid, st["run_a"], "09.12", depends=[u08],
                    inputs=[script_id])
    st9 = wait_unit_state(u09, {"READY"}, timeout=60)
    sc.check("09.12 reaches READY", st9 == "READY", st9)
    report = scheduler_prestage()
    sc.check("scheduler prestage skips gate-refused 09.12",
             all(c["unit_id"] != u09 for c in report["claimed"])
             and unit_db(u09)["state"] == "READY",
             f"claimed={[c['unit_id'][:8] for c in report['claimed']]}")
    s, out = call(API, "POST", f"/units/{u09}/claim",
                  {"worker_id": "n8n-executor-g6"}, role="OPERATOR")
    sc.check("direct API claim of 09.12 refused 409",
             s == 409, f"status={s}")
    audit = db("SELECT event_type FROM audit_events WHERE unit_id=%s",
               (u09,))
    sc.check("gate_claim_refused audit row recorded for 09.12",
             any(a["event_type"] == "gate_claim_refused" for a in audit),
             json.dumps(audit))
    post_dispatch(pid, u09, "09.12", station=4,
                  webhook=N8N + "/webhook/dispatch-g6")
    time.sleep(45)
    atts = db("SELECT * FROM action_attempts WHERE unit_id=%s", (u09,))
    sc.check("fixed g6 executor leg: zero attempts for 09.12, unit "
             "still READY",
             len(atts) == 0 and unit_db(u09)["state"] == "READY",
             f"attempts={len(atts)} state={unit_db(u09)['state']}")
    gates = db("SELECT * FROM human_gates WHERE production_id=%s AND "
               "gate_kind='HG2'", (pid,))
    sc.check("HG2 remains PENDING at the end",
             len(gates) == 1 and gates[0]["verdict"] == "PENDING", "")
    return sc.finish({"production_id": pid, "unit_09_12": u09})


# ----------------------------------------------------------------- setup
def setup():
    subprocess.run(["pg_ctlcluster", "16", "main", "start"],
                   capture_output=True)
    r = subprocess.run(["python3", str(G3 / "tools/setup_db.py"), DB],
                       capture_output=True, text=True)
    if r.returncode != 0:
        raise SystemExit(f"scratch DB setup failed: {r.stderr[-400:]}")
    print(f"db: {DB} built")
    kill_port(8730)
    spawn([str(G3 / ".venv/bin/python"), str(G3 / "api/server.py")],
          {"FACTORY_DSN": DSN, "FACTORY_PORT": "8730", **TOKENS},
          "vfy_api.log")
    if not wait_url(API + "/health"):
        raise SystemExit("API did not come up")
    print("api up")
    kill_port(8795)
    spawn([VENV_PY, str(PROG / "gate-c/worker_service/service.py")],
          {"WORKER_SERVICE_PORT": "8795", "WORKER_ENVIRONMENT": "test",
           "WORKER_DSN": DSN, "FACTORY_API_URL": API,
           "FACTORY_WORKER_TOKEN": TOKENS["FACTORY_WORKER_TOKEN"],
           "WORKER_CREDENTIAL_REFS": "OPENROUTER_API_KEY",
           "OPENROUTER_API_KEY": "stub-local-key"}, "vfy_worker.log")
    if not wait_url(WORKER + "/health"):
        raise SystemExit("worker did not come up")
    print("worker up")
    kill_port(8796)
    spawn([VENV_PY, str(PROG / "gate-e/evaluation_service/service.py")],
          {"FACTORY_DSN": DSN, "FACTORY_API_URL": API,
           "FACTORY_VALIDATOR_TOKEN": TOKENS["FACTORY_VALIDATOR_TOKEN"],
           "FACTORY_EVAL_PORT": "8796"}, "vfy_eval.log")
    if not wait_url(EVAL + "/health"):
        raise SystemExit("eval did not come up")
    print("eval up")
    kill_port(5678)
    time.sleep(1)
    spawn([str(G4T / "node_modules/.bin/n8n"), "start"],
          {"N8N_USER_FOLDER": str(G4T / "n8n-data"), "N8N_PORT": "5678",
           "N8N_LISTEN_ADDRESS": "127.0.0.1",
           "N8N_DIAGNOSTICS_ENABLED": "false",
           "N8N_TEMPLATES_ENABLED": "false",
           "N8N_BLOCK_ENV_ACCESS_IN_NODE": "false", **TOKENS,
           "FACTORY_API_URL": API, "FACTORY_WORKER_SERVICE_URL": WORKER,
           "FACTORY_EVALUATION_URL": EVAL}, "vfy_n8n.log")
    if not wait_url(N8N + "/healthz", seconds=120):
        raise SystemExit("n8n did not come up")
    sys.path.insert(0, str(G5 / "tools"))
    import setup_env as g5_setup
    g5_setup.sync_workflows()
    print("g5 workflows synced")
    import importlib.util
    spec6 = importlib.util.spec_from_file_location(
        "g6_setup_env", str(G6 / "tools/setup_env.py"))
    g6_setup = importlib.util.module_from_spec(spec6)
    spec6.loader.exec_module(g6_setup)
    g6_setup.sync_workflows()
    print("g6 workflows synced")
    r = subprocess.run([sys.executable,
                        str(PHASE3 / "tools/setup_slice.py"),
                        "--base-url", STUB_URL],
                       capture_output=True, text=True)
    if r.returncode != 0:
        raise SystemExit(f"slice seeding failed: {r.stdout} {r.stderr}")
    print("slice seed:", r.stdout.strip().replace("\n", " | "))
    s, out = call(API, "POST", "/configs",
                  {"scope": "STATION", "station": 4, "environment": "test",
                   "provider": "deterministic-local", "est_cost_cents": 100,
                   "params": {"reported_actual_cents": 90}}, role="OPERATOR")
    if s not in (200, 201):
        _, cfgs = call(API, "GET", "/configs", role="OPERATOR")
        have = any(c.get("scope") == "STATION" and c.get("station") == 4
                   and c.get("active", True)
                   for c in cfgs.get("configs", []))
        if not have:
            raise SystemExit(f"STATION 4 binding failed: {s} {out}")
    print("station 4 binding present")
    return 0


def teardown():
    for port in (8730, 8795, 8796, STUB_PORT):
        kill_port(port)
    print("teardown: 8730/8795/8796/8899 stopped (n8n left running)")
    return 0


if __name__ == "__main__":
    LOGS.mkdir(parents=True, exist_ok=True)
    RESULTS.mkdir(parents=True, exist_ok=True)
    cmd = sys.argv[1] if len(sys.argv) > 1 else ""
    sys.exit({"setup": setup, "v1": v1, "v2": v2, "v3": v3,
              "teardown": teardown}[cmd]())
