#!/usr/bin/env python3
"""INDEPENDENT VERIFIER stub provider (Lean Phase 4 fix verification).

STUB_TESTED only. Deliberately DIFFERENT from the fix battery's stub:
  - provider_request_id "chatcmpl-fixverify-7f3"
  - usage 12345 prompt / 6789 completion tokens
    -> hand-computed CALCULATED at the seeded prices
       (input 0.0001 c/tok, output 0.0005 c/tok):
       12345*0.0001 + 6789*0.0005 = 1.2345 + 3.3945 = 4.6290
       -> 5 cents under ROUND_HALF_UP. Distinct from the fix
       battery's 1c and from the 25c claim estimate.
  - script text authored here ("silver compass"), with the same
    shaping traps: L2 carries a bogus canon_ref, L3 omits
    beat_ref/story_ref - the worker must set/derive them.

Usage: vfy_stub.py <port> <record_file>
Every request body is appended to <record_file> as one JSON line.
"""
import json
import sys
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

PORT = int(sys.argv[1])
RECORD = Path(sys.argv[2])

SCRIPT = {
    "kind": "script",
    "lines": [
        {"id": "L1", "scene_ref": "SC1", "beat_ref": "B1",
         "story_ref": "S1", "canon_refs": ["verifier-stub-placeholder"],
         "text": "Ines lifts the silver compass; its needle swings "
                 "toward the sealed stair."},
        {"id": "L2", "scene_ref": "SC2", "beat_ref": "B2",
         "story_ref": "S2", "canon_refs": ["bogus-model-ref"],
         "text": "Rook wedges the chapel door and hides the tide chart."},
        {"id": "L3", "scene_ref": "SC1",
         "text": "The tide chart is missing; only chalk dust remains."},
    ],
    "trace": {
        "clues": [{"id": "CL1", "planted": "L1", "payoff": "L3"}],
        "knowledge": [{"character": "Ines", "learns": "CL1", "at": "L2"}],
        "payoffs": [{"id": "PO1", "clue": "CL1", "line": "L3"}]},
    "canon_refs": ["bogus-model-ref"],
}


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def do_POST(self):
        raw = self.rfile.read(int(self.headers.get("Content-Length") or 0))
        try:
            body = json.loads(raw or b"{}")
        except json.JSONDecodeError:
            body = {"_unparsed": raw.decode("utf-8", errors="replace")}
        body["_path"] = self.path
        with RECORD.open("a") as fh:
            fh.write(json.dumps(body) + "\n")
        payload = json.dumps({
            "id": "chatcmpl-fixverify-7f3",
            "choices": [{"message": {"role": "assistant",
                                     "content": json.dumps(SCRIPT)}}],
            "usage": {"prompt_tokens": 12345, "completion_tokens": 6789,
                      "total_tokens": 19134}}).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(payload)))
        self.end_headers()
        self.wfile.write(payload)


if __name__ == "__main__":
    RECORD.parent.mkdir(parents=True, exist_ok=True)
    ThreadingHTTPServer(("127.0.0.1", PORT), Handler).serve_forever()
