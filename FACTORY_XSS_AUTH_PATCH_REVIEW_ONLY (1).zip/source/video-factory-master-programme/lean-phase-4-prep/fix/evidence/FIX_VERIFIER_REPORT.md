# FIX VERIFIER REPORT — F-P4P-01 / F-P4P-02 (Lean Phase 4 preparation)

**Verdict: FIX VERIFIED — defects NONE.**
**Phase 4 acceptance remains BLOCKED_EXTERNAL** (no provider
credential exists; no real provider call was attempted by the builder
or by this verifier; everything provider-related below is
STUB_TESTED).

Independence: this verifier ran its own scratch stack (DB
`lean4_fixverify_scratch`, since dropped), its own stub provider
(usage 12345 in / 6789 out, request id `chatcmpl-fixverify-7f3`,
distinct script text), and its own harness
(`evidence/verify/vfy_harness.py`, `vfy_stub.py`; scenario results in
`evidence/verify/results/`, logs in `evidence/verify/logs/`).
Assertions were read from the database directly (artifacts,
execution_units, unit_inputs, action_attempts, plan_action_attempts,
financial_evidence, human_gates, audit_events) and cross-checked
against the API — not taken from the fix battery's bookkeeping.

## Item 1 — Confinement: PASS

- Reproduced the snapshot diff independently: `baseline_normalized/`
  vs `fixed_normalized/` differ in **exactly the 5 unit-executor
  files**; the other 21 workflow files are byte-identical after
  normalization.
- Re-normalized the **current on-disk** workflows of all five trees
  myself (UUID-regex scrub): all 26 files **MATCH** the fix's
  post-fix snapshots exactly — the shipped workflows are the recorded
  fixed workflows.
- Per-node structural diff (baseline → fixed, all five trees):
  added node = `Load production artifacts` only; removed = none;
  changed nodes = exactly `Assemble worker payload` (jsCode),
  `Unit state` (jsCode — adds `unit_run_id`), `submit-candidate`
  (jsonBody); connections changed only for the inserted node; no
  other top-level field changed. Within the changed parameters, the
  g5 textual diff shows only: the refs-assembly rewrite (with its
  explanatory comment), the snapshot read via
  `$('Fetch attempt snapshot')`, and the submit-candidate body
  gaining `usage: $json.usage, provider_request_id:
  $json.provider_request_id`.
- Generator sources: all five `tools/gen_workflows.py` carry the
  identical change, including the gating expression reading
  `(attempt.resolved_config || {}).provider`.
- **No other difference found.**

## Item 2 — P4P-1 reproduction (own stack, own stub): PASS 19/19

- Exactly **1 provider call**; the prompt contained the canon
  artifact id, the canon text, and SC1/SC2 (grounded in CURRENT
  upstream contents).
- Refs proven from the DB, not the harness: reconstructed the
  expected refs from `unit_inputs` + the `artifacts` table
  (CURRENT, produced by ACCEPTED same-run units) =
  `[canon_manifest, beat_graph, scene_set, story_architecture]`;
  the worker's persisted `inputs_hash` and the inputs.manifest
  output digest both **match** the reconstruction exactly.
- The stored script bytes (read from the content-addressed store by
  sha) are the verifier stub's own text ("silver compass"), shaped
  worker-side: every line's `canon_refs == [real canon id]` despite
  the stub sending bogus/absent refs; beat/story refs derived.
- Money, from `financial_evidence`: ESTIMATED = 25¢ (the claim
  estimate, present and distinct); **CALCULATED = 5¢** — my hand
  arithmetic from my stub's usage at the seeded pricing rows
  (12345×0.0001 + 6789×0.0005 = 4.6290 → 5, ROUND_HALF_UP);
  **FINALIZED = 5¢**, basis `calculated`, carrying usage
  {input 12345, output 6789} and `provider_request_id =
  chatcmpl-fixverify-7f3`. The 25¢ estimate nowhere poses as a
  measured cost (F-P4P-02 closed on the live n8n path).
- Unit AWAITING_HUMAN; **HG2 gate row in the DB: PENDING, bound to
  the script's artifact_id + sha256**; production budget spent
  **275¢** (270 chain + 5), reserved 0.

## Item 3 — P4P-2 + P4P-5 spots: PASS (4/4 and 8/8)

- Duplicate dispatch: 1 provider call, 1 attempt, 1 script, 1
  FINALIZED (5¢), 1 HG2 gate; unit AWAITING_HUMAN.
- Downstream: after a unit-level `human_approved` (explicitly not an
  HG2 decision — HG2 stayed PENDING in the DB throughout), 09.12
  reached READY; the scheduler prestage **skipped it**; a direct API
  claim returned **409** with `gate_claim_refused` audit rows
  recorded; the **fixed g6 executor** run via its dispatch webhook
  produced **zero attempts** and left the unit READY.

## Item 4 — Provider-gating of context refs: PASS

- Source half: in all five generators the extras are gated on
  `pinnedProvider = (attempt.resolved_config || {}).provider` with
  `generationPath = pinnedProvider !== null && !==
  'deterministic-local' && !== 'mock'` — i.e. the gate reads the
  **attempt's pinned binding**, not the request, the station, or the
  operation.
- Behavioral half (decisive): in the V1 production, chain units
  06.12 and 07.12 ran under deterministic-local bindings **while
  ACCEPTED producers' CURRENT outputs existed** (story_architecture
  resp. beat_graph were CURRENT at their dispatch). Their persisted
  manifest `inputs_hash` equals the hash of the **planned-only** refs
  ([canon]) and differs from the with-extras hash — no context refs
  leaked into the deterministic path.
- The G9 full run (item 5) re-proves this at scale: 10.12's
  declared==planned continuity intact, all 18 units ACCEPTED.

## Item 5 — Regression spot (serial, counts from logs): PASS

- Worker service suite: **40/40 OK** (`logs/reg_worker.log`).
- G5 suite: **1/1 OK** (`logs/reg_g5.log`).
- G9 suite: **10/10 OK** (`logs/reg_g9.log`); the persisted full-run
  production checked directly in `g9_fullrun_scratch`: **18 units,
  18 ACCEPTED, 18 FINALIZED rows totaling 1620¢, every basis
  `reported_actual`**, 3 human gates APPROVED — the deterministic
  settlement path is untouched by the fix.

## Item 6 — Alternative-implementation assessment: ACCEPTABLE-WITH-NOTE

The fix assembles context refs from "CURRENT artifacts of ACCEPTED
same-run producers" instead of walking `depends_on` (no read endpoint
exposes `unit_dependencies`; the disclosure in CHANGED_ASSERTIONS.md
is accurate).

- **Why it is exact for the slice:** a unit becomes dispatchable only
  once its dependencies are ACCEPTED, so in any strict chain the set
  of ACCEPTED same-run producers at dispatch time *is* the unit's
  transitive ancestor set. Empirically confirmed: 08.12's refs were
  exactly the four intended artifacts, ids and hashes verified.
- **Where it can over-include:** a run with parallel branches. If
  branch B has ACCEPTED units when a generation operation in branch
  A is dispatched, B's CURRENT artifacts join A's refs. Bounded
  consequences: (i) contract safety — none; refs never enter the
  deliverable's declared set (worker shaping declares only the
  planned canon), so continuity is untouched — the pre-fix Case A
  failure came from *planned* inputs, not refs; (ii) financial /
  authority — none; refs do not affect claims, budgets, or gates;
  (iii) grounding quality — real but modest: off-branch narrative
  content in the prompt, and the sharpest sub-risk is a **same-type
  collision** (two CURRENT `scene_set` artifacts from two branches;
  type-keyed ref resolution could ground generation on the wrong
  branch's scenes); (iv) auditability — exact: `inputs_hash` records
  precisely what was sent, so any over-inclusion is detectable.
- **Under-inclusion:** none against the spec — the rule is a superset
  of the in-run transitive-dependency outputs.
- **Mitigations already present:** same-run scoping, CURRENT-only,
  own-output exclusion, dedupe by artifact id, and the provider gate
  (deterministic path byte-identical to pre-fix).
- **Note (not a defect):** before branched generation productions
  are introduced (none exist in the factory today; the only
  generation operation is 08.12 in a strict chain), add a
  `unit_dependencies` read surface — or expose `depends_on` on the
  unit read — and narrow the join to the transitive closure, with
  same-type collision handling in ref resolution. Recorded here as a
  Phase 10/11 expansion precondition, not as a repair item.

## Verifier's own disclosed error

The first V1 run crashed after 9 live checks had passed — a bug in
**my** harness (psycopg returns UUID objects; a string comparison
against API ids asserted falsely). The product behavior in that run
was correct (chain ACCEPTED, 1 provider call, grounded prompt); the
assertion code was fixed (str() normalization) and V1 re-ran clean,
19/19, on a fresh production. No product file was touched by this
verifier.

## Defects

**NONE.** (Item 6's note is a forward-looking expansion
precondition, not a defect in the fix as scoped.)

## Bottom line

The F-P4P-01/F-P4P-02 fix is **VERIFIED**: confined to the five
unit-executor workflows, behaviorally exact on the provider path
(refs, usage, and request id now flow end-to-end through n8n), and
provably inert on the deterministic path. Phase 4 itself remains
**BLOCKED_EXTERNAL** on the owner credential + cap confirmation,
exactly as READINESS.md states.
