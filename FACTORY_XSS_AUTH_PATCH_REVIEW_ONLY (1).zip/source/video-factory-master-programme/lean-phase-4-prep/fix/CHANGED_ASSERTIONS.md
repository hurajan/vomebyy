# CHANGED ASSERTIONS — F-P4P-01 / F-P4P-02 fix (Lean Phase 4 prep)

Scope discipline: the fix touched ONLY the five station trees'
`tools/gen_workflows.py` (unit-executor section) and the regenerated
`workflows/*.json`. No coordinator, API-server, worker-service,
registry, contract, or test file was modified. No test assertion in
any existing suite was changed.

## Product changes (per tree: g4, g5, g6, g7, g8 — identical shape)

In each tree's `tools/gen_workflows.py`, unit-executor workflow only:

1. **F-P4P-01 — refs assembly.** New HTTP node `Load production
   artifacts` (GET /productions/{pid}/artifacts, WORKER read role)
   inserted between `Fetch attempt snapshot` and
   `Assemble worker payload`; connections rewired accordingly.
   `Assemble worker payload` now (a) reads the attempt snapshot via
   `$('Fetch attempt snapshot')` instead of `$input` (whose payload
   is now the artifacts response), and (b) builds
   `input_artifact_refs` = planned inputs (unchanged, first) + the
   production's CURRENT artifacts whose producing unit (joined via
   the existing `Load unit` units read) is ACCEPTED and in the same
   run as the dispatched unit, excluding the unit's own output,
   deduped by artifact_id. The `Unit state` code node additionally
   emits `unit_run_id` for the same-run join.
2. **F-P4P-02 — completion forwarding.** The `submit-candidate`
   node's /complete body additionally forwards `usage` and
   `provider_request_id` from the worker-call result verbatim. The
   body is wrapped in JSON.stringify by the generator's http()
   helper, so absent fields are dropped and the deterministic path's
   body is byte-identical in effect.

Workflow regeneration: every tree regenerated; normalized diffs
(all UUIDs scrubbed) prove the changes are confined to
`unit-executor.json` in each tree — the other 21 workflow files are
identical modulo generated ids (evidence/baseline_normalized/ vs
evidence/fixed_normalized/; g5_unit_executor_normalized.diff).

## Deviations from the brief's literal shape (recorded, not hidden)

- The brief's primary mechanism — "walk the unit's depends_on set" —
  is **not expressible on the existing API read surface**: no read
  endpoint exposes `unit_dependencies` (only the plan_unit write
  path takes depends_on). Per the brief's own fallback instruction,
  the narrowest correct alternative the surface supports was used:
  CURRENT artifacts of the production filtered to those produced by
  ACCEPTED units of the same run (dependencies are exactly the
  ACCEPTED in-run producers at dispatch time; a unit only becomes
  dispatchable once its dependencies are ACCEPTED). This includes
  transitive dependency outputs (e.g. for 08.12: beat_graph and
  story_architecture, produced by its dependencies' dependencies),
  which the battery's content criterion requires. Broader than a
  direct-dependency walk in one respect: a same-run ACCEPTED
  non-dependency producer's CURRENT artifact would also be included.
  No such producer exists in the slice or in any station suite's
  planning shape (strict chains); the full regression below is the
  guard. Flagged for the report as the one place the fix is broader
  than the finding's minimal shape.

## Refinement forced by regression evidence (G9 full run, 10.12)

The first regression run of the un-gated fix FAILED g9's full run
(9/10; log preserved as evidence/logs/suite_g9.log): unit 10.12 went
REPAIR_REQUIRED. Mechanism, proven from the persisted DB: 10.12 is
planned with **zero** planned inputs in the G9 graph, and its
deterministic payload builder emits `script_ref` from whatever
`script` ref it is fed (`payloads.build("10.12")`). Pre-fix it was
fed nothing → `script_ref: null` → declared nothing → continuity
(declared == planned) passed. With the extras it was fed the real
script artifact and declared its id against an empty planned set →
continuity FAIL ("output declares inputs that were not planned").

Lesson: the deterministic payload builders treat refs as their
declared-input contract. Context refs beyond planned are sanctioned
by the frozen spec (§3.2/§3.3) ONLY for the provider-generation
path, whose worker-side shaping declares just the planned canon id.
The fix was therefore narrowed, still generator-only: **the extras
are added only when the attempt's pinned binding
(`attempt.resolved_config.provider`) names a real provider** —
never for `deterministic-local`, `mock`, or an unbound attempt,
where refs remain exactly the planned inputs (pre-fix behavior).
This provider gate is the one deliberate narrowing relative to the
finding's minimal shape, and it is recorded in the Assemble node's
own comment. The slice battery was re-run in full after the
refinement (all five scenarios PASS, counts unchanged) and the
regression below is the post-refinement regression.

## Harness notes (fix battery only; no product impact)

- Environmental incident during regression (not a product defect):
  the first post-refinement g4 suite rerun FAILED with units stuck
  VALIDATING/BLOCKED because the API process never restarted onto
  g4_station_scratch (a stale process held :8730 from the preceding
  g8 run and the setup health check answered from it) — the suite
  ran against g8_station_scratch and its bindings; its units are
  persisted there as evidence. After a port kill and an API↔DB
  identity probe (API-created production verified present in
  g4_station_scratch), the clean rerun passed 2/2 in 36.5s.
  Logs: suite_g4_rerun2.log (polluted) vs suite_g4_rerun3.log
  (clean), setup_g4_rerun3.log.

- P4P-1 run 1 scored 22/23: the single FAIL was a harness parsing
  error — the refs check tried to read the refs list out of the
  inputs.manifest action record's output_summary, but the worker's
  API sink stores only a digest summary ({kind, keys, sha256}) of
  action outputs. The check was rewritten to verify the refs
  CRYPTOGRAPHICALLY: recompute plan_exec._inputs_hash over the
  expected ordered refs and the manifest output digest
  (sha256 of the canonical {inputs, count, input_sha256}) and
  compare against the stored record. Run 2: PASS 23/23 with both
  digests matched. Run 1's result file is preserved as
  evidence/results/p4p1_run1_harness_parse_fail.json.
- The fix battery harness (fix/harness/fix_harness.py) is adapted
  from the prep harness with: contract-correct [canon]-only planning
  for 08.12 (the prep's extended planning is now unnecessary and
  would again trip the continuity layer), the digest-based refs
  proof, FINALIZED usage/provider_request_id assertions, a g6
  workflow sync in setup, and a P4P-5 leg that runs the FIXED g6
  unit-executor against 09.12 via the dispatch-g6 webhook.
