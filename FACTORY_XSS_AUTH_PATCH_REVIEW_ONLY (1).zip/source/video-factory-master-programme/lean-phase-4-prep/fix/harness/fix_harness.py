#!/usr/bin/env python3
"""Lean Phase 4 prep FIX battery — F-P4P-01 / F-P4P-02 repair,
re-run against the Phase 3 local stub provider through the FIXED
unit-executor workflows (all five trees regenerated).

THE FIX under test (generators only; no coordinator/worker/registry/
contract change):
  F-P4P-01  the executor's Assemble node now sends refs = planned
            inputs (first) + the CURRENT output artifacts of the
            unit's dependency units (production artifacts joined to
            ACCEPTED same-run producer units). 08.12 is therefore
            planned CONTRACT-CORRECTLY with inputs=[canon] only, and
            the chain contents (story_architecture / beat_graph /
            scene_set) must still reach the generation prompt.
  F-P4P-02  submit-candidate forwards the worker response's usage +
            provider_request_id, so settlement must be CALCULATED
            from real (stub) usage — never the 25c estimate.

STUB_TESTED evidence only. Phase 4 cannot PASS without the real
provider: no credential exists (BLOCKED_EXTERNAL) and no real call is
attempted here. What this battery proves is that the EXISTING n8n leg
(dispatch webhook -> g5-station-03 -> g5-unit-executor -> adopt ->
g5-call-worker -> worker service /work -> evaluation) carries the
provider-bound 08.12 path end to end with zero product-code changes,
so the genuine Phase 4 run is: swap the binding endpoint back to the
adapter default + start the worker with the real credential + rerun.

Tests (each an independent production on the shared fix DB):
  p4p1  HAPPY PATH VIA N8N — 08.12 planned with inputs=[canon]
        ONLY; scheduler-prestaged claim adopted by the executor;
        exactly ONE stub provider call; the inputs.manifest action
        record proves the worker refs were [canon, story_architecture,
        beat_graph, scene_set] (planned + dependency CURRENT outputs);
        script CURRENT with stub-authored worker-shaped content; 3
        action records SUCCEEDED; evaluation ran; unit AWAITING_HUMAN;
        HG2 gate bound to the script's id+sha, verdict PENDING;
        settlement = CALCULATED 1c with the FINALIZED evidence row
        carrying the stub usage + provider_request_id (F-P4P-02).
  p4p2  DUPLICATE DISPATCH — two webhook dispatches of the same unit:
        still 1 provider call, 1 attempt, 1 script artifact, 1
        FINALIZED settlement, 1 HG2 gate.
  p4p3  CLAIM REFUSAL => NO PROVIDER CALL — claim prestaged under a
        wrong identity ("someone-else"); executor takes the
        claim-refused branch: 0 stub calls, 0 script artifacts, unit
        still CLAIMED under the foreign attempt.
  p4p4  PROVIDER FAILURE + RECOVERY VIA N8N — stub 500: unit lands
        RETRY_WAIT with a FAILED generation record, no settlement;
        stub healthy + redispatch: unit completes to AWAITING_HUMAN;
        exactly 2 provider calls total; exactly one FINALIZED charge
        (the successful attempt only).
  p4p5  DOWNSTREAM PREP (refusal half only) — in its own production,
        08.12's UNIT is accepted via the established harness-as-human
        unit event (NOT an HG2 decision: the HG2 gate is never decided
        in this prep and stays PENDING — an HG2 decision on stub
        content would be meaningless). 09.12 planned against the
        script reaches READY; the scheduler skips it (gate-refused
        candidates are not prestaged); a direct API claim is refused
        409 with a gate_claim_refused audit row; AND the FIXED g6
        unit-executor is run against it via the dispatch-g6 webhook:
        its own claim is refused the same way — zero attempts, zero
        provider-side effects, unit still READY.

Setup: scratch DB lean4_fix_scratch (G3 chain) -> API :8730, worker
:8795 (slice credential env: dummy key + WORKER_CREDENTIAL_REFS, as
Phase 3 run-b), evaluation :8796, n8n :5678 restarted fresh with the
station env + g5 workflows synced via the g5 setup module, slice
seeding via lean-phase-3/tools/setup_slice.py --base-url <stub>
(OPERATION 08.12 binding endpoint override -> local stub; the
canonical binding carries no base_url), plus a STATION 4
deterministic-local binding (g6 setup shape) so P4P-5's 09.12 claim
reaches the gate check instead of failing config resolution.

Run with the factory venv python:
  fix_harness.py setup | p4p1 | p4p2 | p4p3 | p4p4 | p4p5 | teardown
"""
import json
import os
import re
import subprocess
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path

import psycopg
from psycopg.rows import dict_row

ROOT = Path(__file__).resolve().parent.parent
LOGS = ROOT / "evidence" / "logs"
RESULTS = ROOT / "evidence" / "results"
HOME = Path.home()
G2 = HOME / "workspace/video-factory-g2"
G3 = HOME / "workspace/video-factory-g3"
G4T = HOME / "workspace/video-factory-g4"
G5 = HOME / "workspace/video-factory-g5"
PROG = HOME / "workspace/video-factory-real-ai-programme"
PHASE3 = HOME / "workspace/video-factory-master-programme/lean-phase-3"
VENV_PY = str(G2 / ".venv/bin/python")
STORE = PROG / "gate-d/storage_service/.store"

DB = "lean4_fix_scratch"


def _fixture_password():
    """Dev scratch role password from the canonical fixture (g2
    tools/setup_db.py) — never re-typed as a literal here."""
    src = (G2 / "tools/setup_db.py").read_text()
    return re.search(
        r"CREATE ROLE factory LOGIN PASSWORD '([^']+)'", src).group(1)


DSN = ("host=127.0.0.1 dbname=" + DB + " user=factory password="
       + _fixture_password())
API = "http://127.0.0.1:8730"
WORKER = "http://127.0.0.1:8795"
EVAL = "http://127.0.0.1:8796"
N8N = "http://127.0.0.1:5678"
WEBHOOK = N8N + "/webhook/dispatch-g5"
WEBHOOK_G6 = N8N + "/webhook/dispatch-g6"
STUB_PORT = 8799
STUB_URL = f"http://127.0.0.1:{STUB_PORT}"
TOKENS = {"FACTORY_API_TOKEN": "dev-operator-token",
          "FACTORY_WORKER_TOKEN": "dev-worker-token",
          "FACTORY_SCHEDULER_TOKEN": "dev-scheduler-token",
          "FACTORY_VALIDATOR_TOKEN": "dev-validator-token",
          "FACTORY_CALLBACK_TOKEN": "dev-callback-token"}
OPERATOR = TOKENS["FACTORY_API_TOKEN"]
CANON_TEXT = ("CANON MANIFEST v1 — universe, chronology, world rules, "
              "knowledge boundaries released.")
MODEL = "anthropic/claude-haiku-4.5"
EXECUTOR = "n8n-executor-g5"
LABEL = "STUB_TESTED"


# ------------------------------------------------------------------ http
def call(base, method, path, body=None, role=None):
    req = urllib.request.Request(base + path, method=method)
    data = None
    if role == "OPERATOR":
        req.add_header("X-Operator-Token", OPERATOR)
    if body is not None:
        data = json.dumps(body).encode()
        req.add_header("Content-Type", "application/json")
    try:
        with urllib.request.urlopen(req, data=data, timeout=30) as r:
            return r.status, json.loads(r.read() or b"{}")
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read() or b"{}")


def db(sql, args=()):
    with psycopg.connect(DSN, row_factory=dict_row, autocommit=True) as conn:
        cur = conn.execute(sql, args)
        try:
            return cur.fetchall()
        except psycopg.errors.ProgrammingError:
            return []


# -------------------------------------------------------------- processes
def kill_port(port):
    subprocess.run(["fuser", "-k", f"{port}/tcp"], capture_output=True)
    time.sleep(0.5)


def spawn(cmd, env, log_name):
    e = dict(os.environ)
    e.update(env)
    out = open(LOGS / log_name, "ab")
    return subprocess.Popen(cmd, env=e, stdout=out, stderr=out,
                            start_new_session=True)


def wait_url(url, seconds=60, ok_statuses=(200,)):
    deadline = time.time() + seconds
    while time.time() < deadline:
        try:
            with urllib.request.urlopen(url, timeout=2) as r:
                if r.status in ok_statuses:
                    return True
        except urllib.error.HTTPError:
            return True  # any HTTP answer = serving
        except Exception:  # noqa: BLE001
            pass
        time.sleep(0.5)
    return False


def start_stub(mode, tag):
    kill_port(STUB_PORT)
    record = LOGS / f"stub_requests_{tag}.jsonl"
    if record.exists():
        record.unlink()
    spawn([sys.executable, str(ROOT / "harness/stub_provider.py"),
           str(STUB_PORT), mode, str(record)], {}, f"stub_{tag}.log")
    if not wait_url(STUB_URL + "/chat/completions", seconds=15):
        raise SystemExit("stub provider did not come up")
    record.write_text("")  # drop the readiness-probe line
    return record


def stub_calls(record):
    if not record.exists():
        return []
    return [json.loads(l) for l in record.read_text().splitlines() if l]


# ---------------------------------------------------------------- driver
class Scenario:
    def __init__(self, name):
        self.name = name
        self.checks = []

    def check(self, name, ok, detail=""):
        self.checks.append({"name": name, "pass": bool(ok),
                            "detail": str(detail)[:600]})
        print(f"  [{'PASS' if ok else 'FAIL'}] {name} — {str(detail)[:200]}")

    def finish(self, extra=None):
        verdict = all(c["pass"] for c in self.checks)
        doc = {"scenario": self.name,
               "verdict": "PASS" if verdict else "FAIL",
               "label": LABEL, "checks": self.checks, **(extra or {})}
        RESULTS.mkdir(parents=True, exist_ok=True)
        (RESULTS / f"{self.name}.json").write_text(
            json.dumps(doc, indent=1, sort_keys=True))
        print(f"{self.name}: {'PASS' if verdict else 'FAIL'} "
              f"({sum(1 for c in self.checks if c['pass'])}/{len(self.checks)})")
        return 0 if verdict else 1


def unit_row(pid, uid):
    _, out = call(API, "GET", f"/productions/{pid}/units", role="OPERATOR")
    return [u for u in out["units"] if u["unit_id"] == uid][0]


def wait_state(pid, uid, states, timeout=300):
    deadline = time.time() + timeout
    state = None
    while time.time() < deadline:
        state = unit_row(pid, uid)["state"]
        if state in states:
            return state
        time.sleep(2)
    raise AssertionError(f"unit {uid} stuck in {state}, wanted {states}")


def current_artifacts(pid):
    _, out = call(API, "GET", f"/productions/{pid}/artifacts", role="OPERATOR")
    return {a["artifact_type"]: a for a in out["artifacts"]
            if a["state"] == "CURRENT"}


def scheduler_prestage():
    """One Gate F SchedulerService cycle: claims READY units through
    Coordinator.scheduler_claim under actor 'scheduler-service' (the
    coordinator derives the executor worker_id from each unit's step).
    Returns the service report."""
    sys.path.insert(0, str(PROG / "gate-f"))
    from runtime_services.scheduler_service import SchedulerService
    return SchedulerService(dsn=DSN).run_once()


def post_dispatch(pid, uid, op, station=3, webhook=None):
    payload = {"production_id": pid, "unit_id": uid, "operation_id": op,
               "station": station, "input_artifact_ids": [],
               "force_fail": False, "idempotency_key": f"dispatch:{uid}:1"}
    req = urllib.request.Request(webhook or WEBHOOK, method="POST",
                                 data=json.dumps(payload).encode(),
                                 headers={"Content-Type": "application/json"})
    deadline = time.time() + 60  # webhook registration can lag a re-sync
    while True:
        try:
            with urllib.request.urlopen(req, timeout=120) as r:
                return r.status
        except urllib.error.HTTPError as e:
            if e.code == 404 and time.time() < deadline:
                time.sleep(3)
                continue
            raise


def make_production(sc, title):
    s, p = call(API, "POST", "/productions",
                {"title": title, "hard_ceiling_cents": 500,
                 "soft_ceiling_cents": 250}, role="OPERATOR")
    assert s == 201, f"production create {s}: {p}"
    pid = p["production_id"]
    s, r = call(API, "POST", f"/productions/{pid}/runs", {"kind": "FULL"},
                role="OPERATOR")
    assert s == 201, f"run create {s}: {r}"
    s, a = call(API, "POST", f"/productions/{pid}/artifacts",
                {"artifact_type": "canon_manifest", "content": CANON_TEXT,
                 "storage_uri": "local://canon-fixture"}, role="OPERATOR")
    assert s == 201, f"canon register {s}: {a}"
    return pid, r["run_id"], a["artifact_id"]


def plan_unit(pid, run, op, depends=(), inputs=()):
    s, u = call(API, "POST", f"/productions/{pid}/units",
                {"operation_id": op, "run_id": run, "unit_key": "main",
                 "depends_on": list(depends),
                 "input_artifact_ids": list(inputs)}, role="OPERATOR")
    assert s == 201, f"plan {op} {s}: {u}"
    return u["unit_id"]


def drive_via_n8n(sc, pid, uid, op, approve=True):
    """Scheduler prestage -> webhook dispatch -> (optional) harness
    human approval of the UNIT -> ACCEPTED. Returns the end state."""
    wait_state(pid, uid, {"READY"})
    report = scheduler_prestage()
    claimed = [c for c in report["claimed"] if c["unit_id"] == uid]
    sc.check(f"{op}: scheduler prestaged the claim",
             len(claimed) == 1
             and unit_row(pid, uid)["state"] == "CLAIMED",
             f"claimed={claimed}")
    post_dispatch(pid, uid, op)
    state = wait_state(pid, uid, {"AWAITING_HUMAN", "ACCEPTED", "FAILED",
                                  "BLOCKED", "RETRY_WAIT"})
    if state == "AWAITING_HUMAN" and approve:
        s, _ = call(API, "POST", f"/units/{uid}/events",
                    {"event": "human_approved"}, role="OPERATOR")
        assert s == 200, f"human_approved {op} -> {s}"
        state = wait_state(pid, uid, {"ACCEPTED"})
    return state


def build_chain(sc, pid, run, canon):
    """Plan + drive 05.12 -> 06.12 -> 07.12 (deterministic STATION
    binding) through n8n to ACCEPTED."""
    u05 = plan_unit(pid, run, "05.12", inputs=[canon])
    u06 = plan_unit(pid, run, "06.12", depends=[u05], inputs=[canon])
    u07 = plan_unit(pid, run, "07.12", depends=[u06], inputs=[canon])
    for op, uid in (("05.12", u05), ("06.12", u06), ("07.12", u07)):
        state = drive_via_n8n(sc, pid, uid, op)
        sc.check(f"{op} ACCEPTED via n8n (scheduler prestage + adopt)",
                 state == "ACCEPTED", f"state={state}")
    return u05, u06, u07


def plan_0812(sc, pid, run, canon, u07):
    """Plan 08.12 CONTRACT-CORRECTLY per spec §3.2: planned inputs =
    [canon] ONLY (the script deliverable declares only the canon id;
    planning the chain outputs was the pre-fix workaround that the
    continuity layer refused). Post F-P4P-01 the executor itself adds
    the dependency units' CURRENT outputs to the worker refs."""
    return plan_unit(pid, run, "08.12", depends=[u07],
                     inputs=[canon]), current_artifacts(pid)


def attempts_of(uid):
    return db("SELECT attempt_no, worker_id, status, adopted_by, "
              "adopted_at FROM action_attempts "
              "WHERE unit_id=%s ORDER BY attempt_no", (uid,))


def audit_of(uid):
    return db("SELECT event_type AS event, actor FROM audit_events "
              "WHERE unit_id=%s ORDER BY created_at", (uid,))


def action_records(uid):
    return db("SELECT action_key, status, output_summary, error, "
              "inputs_hash FROM plan_action_attempts WHERE unit_id=%s "
              "ORDER BY seq, recorded_at", (uid,))


def _canon(value):
    """plan_exec._canon — the worker's canonical JSON for digests."""
    return json.dumps(value, sort_keys=True, default=str)


def expected_refs(pid, uid):
    """Reconstruct the refs the FIXED executor must have sent for
    this unit: planned inputs first (unit_inputs order as the API
    returns them on the unit row), then the production's CURRENT
    artifacts produced by ACCEPTED units of the same run, in the
    artifacts endpoint's own order (artifact_type, version)."""
    _, uout = call(API, "GET", f"/productions/{pid}/units", role="OPERATOR")
    units = {u["unit_id"]: u for u in uout["units"]}
    me = units[uid]
    _, aout = call(API, "GET", f"/productions/{pid}/artifacts",
                   role="OPERATOR")
    by_id = {a["artifact_id"]: a for a in aout["artifacts"]}
    refs = []
    seen = set()
    for aid in me.get("input_artifact_ids", []):
        a = by_id[aid]
        refs.append({"artifact_type": a["artifact_type"],
                     "artifact_id": a["artifact_id"],
                     "sha256": a["sha256"]})
        seen.add(aid)
    for a in aout["artifacts"]:
        if a["state"] != "CURRENT" or not a.get("produced_by_unit"):
            continue
        if a["produced_by_unit"] == uid or a["artifact_id"] in seen:
            continue
        producer = units.get(a["produced_by_unit"])
        if not producer or producer["state"] != "ACCEPTED":
            continue
        if producer.get("run_id") != me.get("run_id"):
            continue
        refs.append({"artifact_type": a["artifact_type"],
                     "artifact_id": a["artifact_id"],
                     "sha256": a["sha256"]})
        seen.add(a["artifact_id"])
    return refs


def evidence_of(uid):
    return db("SELECT e.charge_class, e.amount_cents, e.pricing_version, "
              "e.usage, e.provider_request_id "
              "FROM financial_evidence e JOIN action_attempts a "
              "ON a.attempt_id=e.attempt_id WHERE a.unit_id=%s "
              "ORDER BY e.created_at", (uid,))


def script_artifacts(pid):
    _, out = call(API, "GET", f"/productions/{pid}/artifacts", role="OPERATOR")
    return [a for a in out["artifacts"] if a["artifact_type"] == "script"]


def hg2_gates(pid):
    _, out = call(API, "GET", f"/productions/{pid}/gates", role="OPERATOR")
    return [g for g in out["gates"] if g["gate_kind"] == "HG2"]


def wait_hg2(pid, timeout=120):
    deadline = time.time() + timeout
    while time.time() < deadline:
        gates = hg2_gates(pid)
        if gates:
            return gates
        time.sleep(2)
    return []


def check_slice_outcome(sc, pid, uid, record, expect_calls=1):
    """The shared happy-path assertions for a provider-bound 08.12 run
    driven through n8n. Returns the CURRENT script artifact row."""
    calls = stub_calls(record)
    sc.check("exactly ONE stub provider call",
             len(calls) == expect_calls, f"calls={len(calls)}")
    if calls:
        prompt = calls[0]["messages"][0]["content"]
        _, arts = call(API, "GET", f"/productions/{pid}/artifacts",
                       role="OPERATOR")
        canon = [a for a in arts["artifacts"]
                 if a["artifact_type"] == "canon_manifest"][0]
        sc.check("provider prompt grounded in CURRENT canon + chain "
                 "contents (canon id + text, SC1/SC2)",
                 canon["artifact_id"] in prompt and "CANON MANIFEST v1" in prompt
                 and "SC1" in prompt and "SC2" in prompt,
                 f"prompt_len={len(prompt)}")
    atts = attempts_of(uid)
    sc.check("one attempt, worker identity n8n-executor-g5 throughout",
             len(atts) == 1 and atts[0]["worker_id"] == EXECUTOR,
             json.dumps(atts, default=str))
    sc.check("attempt ADOPTED by the executor (Gate 02 path)",
             bool(atts) and atts[0].get("adopted_at") is not None
             and atts[0].get("adopted_by") == EXECUTOR,
             json.dumps(atts, default=str))
    audit = audit_of(uid)
    sc.check("audit: claim actor is scheduler-service; attempt_adopted "
             "recorded",
             any("scheduler-service" in (a["actor"] or "") for a in audit)
             and any(a["event"] == "attempt_adopted" for a in audit),
             json.dumps(audit))
    records = {r["action_key"]: r["status"] for r in action_records(uid)}
    sc.check("action records: 3 SUCCEEDED (manifest/build/emit)",
             records == {"inputs.manifest": "SUCCEEDED",
                         "op.build": "SUCCEEDED",
                         "output.emit": "SUCCEEDED"},
             json.dumps(records))
    # F-P4P-01: cryptographic refs proof. The worker digests the
    # exact refs it received into every action record's inputs_hash
    # (plan_exec._inputs_hash over the ordered refs, prior={} at
    # seq 1) and digests the manifest action's full output
    # ({inputs, count, input_sha256}) into output_summary.sha256.
    # Recompute both from the refs the FIXED executor must have sent
    # and compare — an exact, ordered, content-level match.
    import hashlib
    man = [r for r in action_records(uid)
           if r["action_key"] == "inputs.manifest"]
    man = man[-1] if man else {}
    refs = expected_refs(pid, uid)
    want_types = ["canon_manifest", "beat_graph", "scene_set",
                  "story_architecture"]
    exp_inputs_hash = hashlib.sha256(_canon(
        {"refs": refs, "prior": {}}).encode()).hexdigest()
    exp_output = {"inputs": refs, "count": len(refs),
                  "input_sha256": [r["sha256"] for r in refs]}
    exp_output_hash = hashlib.sha256(
        _canon(exp_output).encode()).hexdigest()
    osum = man.get("output_summary") or {}
    if isinstance(osum, str):
        osum = json.loads(osum)
    sc.check("F-P4P-01: worker refs == planned [canon] + dependency "
             "CURRENT outputs (inputs_hash + manifest output digest "
             "recomputed and matched)",
             [r["artifact_type"] for r in refs] == want_types
             and man.get("inputs_hash") == exp_inputs_hash
             and osum.get("sha256") == exp_output_hash,
             f"types={[r['artifact_type'] for r in refs]} "
             f"inputs_hash_match={man.get('inputs_hash') == exp_inputs_hash} "
             f"output_digest_match={osum.get('sha256') == exp_output_hash}")
    scripts = script_artifacts(pid)
    cur = [a for a in scripts if a["state"] == "CURRENT"]
    sc.check("exactly one script artifact, CURRENT",
             len(scripts) == 1 and len(cur) == 1,
             f"scripts={[(a['artifact_id'][:8], a['state']) for a in scripts]}")
    script = cur[0] if cur else {}
    if script:
        raw = (STORE / "objects" / script["sha256"]).read_bytes()
        envelope = json.loads(raw)
        deliverable = envelope["output_artifacts"][0]["content"]
        _, arts = call(API, "GET", f"/productions/{pid}/artifacts",
                       role="OPERATOR")
        canon_id = [a for a in arts["artifacts"]
                    if a["artifact_type"] == "canon_manifest"][0]["artifact_id"]
        texts = [l["text"] for l in deliverable["lines"]]
        sc.check("script content is the stub-authored text, worker-"
                 "shaped (canon_refs set from the real canon id)",
                 deliverable.get("kind") == "script"
                 and all(l["canon_refs"] == [canon_id]
                         for l in deliverable["lines"])
                 and "brass key" in texts[0],
                 f"lines={len(deliverable.get('lines', []))}")
    gates = wait_hg2(pid)
    sc.check("station flow created the HG2 gate bound to the script "
             "id+sha, verdict PENDING",
             len(gates) == 1 and bool(script)
             and gates[0]["artifact_id"] == script["artifact_id"]
             and gates[0]["artifact_sha256"] == script["sha256"]
             and gates[0]["verdict"] == "PENDING",
             json.dumps(gates))
    ev = evidence_of(uid)
    fin = [e for e in ev if e["charge_class"] == "FINALIZED"]
    calc = [e for e in ev if e["charge_class"] == "CALCULATED"]
    sc.check("settlement: exactly one FINALIZED == CALCULATED 1c from "
             "the seeded pricing rows (not the 25c estimate)",
             len(fin) == 1 and fin[0]["amount_cents"] == 1
             and len(calc) == 1 and calc[0]["amount_cents"] == 1,
             json.dumps(ev))
    # F-P4P-02: the FINALIZED row must carry the forwarded usage +
    # provider_request_id (pre-fix both were dropped by the executor
    # and FINALIZED settled the 25c estimate as 'reported_actual').
    fusage = fin[0]["usage"] if fin else None
    if isinstance(fusage, str):
        fusage = json.loads(fusage)
    fusage = fusage or {}
    sc.check("F-P4P-02: FINALIZED evidence carries the stub usage "
             "(1500 in / 700 out) + provider_request_id, basis "
             "calculated",
             fusage.get("input_tokens") == 1500
             and fusage.get("output_tokens") == 700
             and fusage.get("_finalization_basis") == "calculated"
             and fin and fin[0]["provider_request_id"] == "chatcmpl-stub-1",
             json.dumps(fin, default=str))
    return script


# -------------------------------------------------------------- scenarios
def p4p1():
    sc = Scenario("p4p1_happy_path_via_n8n")
    record = start_stub("ok", "p4p1")
    pid, run, canon = make_production(sc, "Lean P4P-1 happy path via n8n")
    _, _, u07 = build_chain(sc, pid, run, canon)
    u08, _ = plan_0812(sc, pid, run, canon, u07)
    row = unit_row(pid, u08)
    _, arts_now = call(API, "GET", f"/productions/{pid}/artifacts",
                       role="OPERATOR")
    canon_id = [a["artifact_id"] for a in arts_now["artifacts"]
                if a["artifact_type"] == "canon_manifest"][0]
    sc.check("08.12 planned inputs == [canon] ONLY (contract-correct "
             "planning; no chain outputs planned)",
             row.get("input_artifact_ids") == [canon_id],
             f"planned={row.get('input_artifact_ids')}")
    state = drive_via_n8n(sc, pid, u08, "08.12", approve=False)
    sc.check("08.12 parks at AWAITING_HUMAN (QA-interaction posture: "
             "semantic layer does not judge the credentialed binding; "
             "human gate is the bar)",
             state == "AWAITING_HUMAN", f"state={state}")
    script = check_slice_outcome(sc, pid, u08, record)
    evals = db("SELECT verdict, method FROM quality_evaluations "
               "WHERE artifact_id=%s", (script.get("artifact_id"),))
    sc.check("evaluation ran for the script artifact (quality_"
             "evaluations rows recorded)",
             len(evals) >= 1, json.dumps(evals))
    _, budget = call(API, "GET", f"/productions/{pid}/budget", role="OPERATOR")
    sc.check("production budget: spent 271 (chain 270 + FINALIZED 1), "
             "nothing reserved",
             budget.get("spent_cents") == 271
             and budget.get("reserved_cents") == 0,
             json.dumps(budget))
    return sc.finish({"production_id": pid, "unit_08_12": u08,
                      "script_artifact": script.get("artifact_id")})


def p4p2():
    sc = Scenario("p4p2_duplicate_dispatch")
    record = start_stub("ok", "p4p2")
    pid, run, canon = make_production(sc, "Lean P4P-2 duplicate dispatch")
    _, _, u07 = build_chain(sc, pid, run, canon)
    u08, _ = plan_0812(sc, pid, run, canon, u07)
    wait_state(pid, u08, {"READY"})
    scheduler_prestage()
    sc.check("claim prestaged before the duplicate dispatches",
             unit_row(pid, u08)["state"] == "CLAIMED",
             f"state={unit_row(pid, u08)['state']}")
    post_dispatch(pid, u08, "08.12")
    post_dispatch(pid, u08, "08.12")  # the duplicate
    state = wait_state(pid, u08, {"AWAITING_HUMAN", "ACCEPTED"})
    sc.check("unit reached AWAITING_HUMAN after duplicate dispatch",
             state == "AWAITING_HUMAN", f"state={state}")
    time.sleep(10)  # let any duplicate execution tail finish
    script = check_slice_outcome(sc, pid, u08, record)
    return sc.finish({"production_id": pid, "unit_08_12": u08,
                      "script_artifact": script.get("artifact_id")})


def p4p3():
    sc = Scenario("p4p3_claim_refusal_no_provider_call")
    record = start_stub("ok", "p4p3")
    pid, run, canon = make_production(sc, "Lean P4P-3 claim refusal")
    _, _, u07 = build_chain(sc, pid, run, canon)
    # contract-correct planning ([canon] only — see the probe finding);
    # planning shape is immaterial to the claim-refusal branch itself
    u08 = plan_unit(pid, run, "08.12", depends=[u07], inputs=[canon])
    wait_state(pid, u08, {"READY"})
    s, claim = call(API, "POST", f"/units/{u08}/claim",
                    {"worker_id": "someone-else"}, role="OPERATOR")
    sc.check("claim prestaged under the WRONG identity (someone-else)",
             s == 200 and unit_row(pid, u08)["state"] == "CLAIMED",
             f"status={s}")
    post_dispatch(pid, u08, "08.12")
    time.sleep(45)  # executor runs and takes the claim-refused branch
    calls = stub_calls(record)
    sc.check("stub provider call count stays 0 for the refused unit",
             len(calls) == 0, f"calls={len(calls)}")
    scripts = script_artifacts(pid)
    sc.check("zero script artifacts produced",
             len(scripts) == 0, f"scripts={len(scripts)}")
    atts = attempts_of(u08)
    sc.check("unit still CLAIMED under the single foreign attempt",
             unit_row(pid, u08)["state"] == "CLAIMED"
             and len(atts) == 1
             and atts[0]["worker_id"] == "someone-else"
             and atts[0].get("adopted_at") is None,
             json.dumps(atts, default=str))
    audit = audit_of(u08)
    sc.check("executor never called the worker (no start / "
             "submit_candidate events for the unit)",
             not any(a["event"] in ("start", "submit_candidate")
                     for a in audit),
             json.dumps(audit))
    return sc.finish({"production_id": pid, "unit_08_12": u08,
                      "audit_events": audit})


def p4p4():
    sc = Scenario("p4p4_provider_failure_recovery")
    record = start_stub("error500", "p4p4")
    pid, run, canon = make_production(sc, "Lean P4P-4 failure + recovery")
    _, _, u07 = build_chain(sc, pid, run, canon)
    u08, _ = plan_0812(sc, pid, run, canon, u07)
    wait_state(pid, u08, {"READY"})
    scheduler_prestage()
    post_dispatch(pid, u08, "08.12")
    state = wait_state(pid, u08, {"RETRY_WAIT", "FAILED", "BLOCKED"},
                       timeout=300)
    sc.check("provider 500: unit lands in RETRY_WAIT (recovery state)",
             state == "RETRY_WAIT", f"state={state}")
    records = {r["action_key"]: r for r in action_records(u08)}
    sc.check("generation action record FAILED with the provider error",
             records.get("op.build", {}).get("status") == "FAILED"
             and "500" in (records["op.build"].get("error") or ""),
             json.dumps({k: v["status"] for k, v in records.items()}))
    ev1 = evidence_of(u08)
    sc.check("failed run: no CALCULATED/FINALIZED evidence (no charge)",
             not any(e["charge_class"] in ("CALCULATED", "FINALIZED")
                     for e in ev1), json.dumps(ev1))
    sc.check("failed run consumed exactly 1 provider call",
             len(stub_calls(record)) == 1,
             f"calls={len(stub_calls(record))}")
    # stub healthy again -> redispatch (RETRY_WAIT pre-step retries,
    # executor claims anew — the F-G9-03 recovery design)
    record2 = start_stub("ok", "p4p4_recovery")
    post_dispatch(pid, u08, "08.12")
    state = wait_state(pid, u08, {"AWAITING_HUMAN", "ACCEPTED"}, timeout=300)
    sc.check("redispatch after recovery: unit completes to "
             "AWAITING_HUMAN", state == "AWAITING_HUMAN", f"state={state}")
    total_calls = len(stub_calls(record)) + len(stub_calls(record2))
    sc.check("exactly 2 provider calls across both runs",
             total_calls == 2, f"total={total_calls}")
    atts = attempts_of(u08)
    sc.check("two attempts recorded (failed + recovered)",
             len(atts) == 2, json.dumps(atts, default=str))
    ev = evidence_of(u08)
    fin = [e for e in ev if e["charge_class"] == "FINALIZED"]
    sc.check("exactly one FINALIZED charge (the successful run only)",
             len(fin) == 1 and fin[0]["amount_cents"] == 1, json.dumps(ev))
    _, budget = call(API, "GET", f"/productions/{pid}/budget", role="OPERATOR")
    sc.check("budget: spent 271 (no charge for the failed run), "
             "nothing reserved",
             budget.get("spent_cents") == 271
             and budget.get("reserved_cents") == 0, json.dumps(budget))
    scripts = script_artifacts(pid)
    sc.check("exactly one script artifact (from the recovered run)",
             len(scripts) == 1 and scripts[0]["state"] == "CURRENT",
             f"scripts={len(scripts)}")
    return sc.finish({"production_id": pid, "unit_08_12": u08})


def p4p5():
    sc = Scenario("p4p5_downstream_refusal_prep")
    record = start_stub("ok", "p4p5")
    pid, run, canon = make_production(sc, "Lean P4P-5 downstream prep")
    _, _, u07 = build_chain(sc, pid, run, canon)
    u08, _ = plan_0812(sc, pid, run, canon, u07)
    state = drive_via_n8n(sc, pid, u08, "08.12", approve=True)
    sc.check("08.12 ACCEPTED (unit-level harness-as-human approval — "
             "NOT an HG2 decision)", state == "ACCEPTED", f"state={state}")
    script = current_artifacts(pid)["script"]
    gates = wait_hg2(pid)
    sc.check("HG2 gate exists and is STILL PENDING (never decided in "
             "this prep)",
             len(gates) == 1 and gates[0]["verdict"] == "PENDING"
             and gates[0]["artifact_id"] == script["artifact_id"],
             json.dumps(gates))
    s, req = call(API, "GET",
                  f"/gates/require?production_id={pid}&gate_kind=HG2"
                  f"&artifact_id={script['artifact_id']}", role="OPERATOR")
    sc.check("gate requirement unsatisfied while HG2 PENDING",
             s == 200 and req.get("satisfied") is False, json.dumps(req))
    u09 = plan_unit(pid, run, "09.12", depends=[u08],
                    inputs=[script["artifact_id"]])
    state9 = wait_state(pid, u09, {"READY"}, timeout=60)
    sc.check("09.12 planned against the script reaches READY",
             state9 == "READY", f"state={state9}")
    report = scheduler_prestage()
    sc.check("scheduler prestage SKIPS the gate-refused 09.12 (no "
             "claim staged for it)",
             all(c["unit_id"] != u09 for c in report["claimed"])
             and unit_row(pid, u09)["state"] == "READY",
             f"claimed={[c['unit_id'][:8] for c in report['claimed']]}")
    s, out = call(API, "POST", f"/units/{u09}/claim",
                  {"worker_id": "n8n-executor-g6"}, role="OPERATOR")
    sc.check("09.12 direct API claim refused 409 while HG2 PENDING",
             s == 409, f"status={s} out={out}")
    audit9 = audit_of(u09)
    sc.check("gate_claim_refused audit recorded for 09.12 (HG2/script)",
             any(a["event"] == "gate_claim_refused" for a in audit9),
             json.dumps(audit9))
    # The FIXED g6 unit-executor, run end-to-end via its dispatch
    # webhook: span guard passes (step 09), its own claim is refused
    # by the same gate, and it must stop cleanly — no attempt, no
    # worker call, no state change.
    calls_before = len(stub_calls(record))
    post_dispatch(pid, u09, "09.12", station=4, webhook=WEBHOOK_G6)
    time.sleep(45)  # executor runs and takes the claim-refused branch
    atts9 = attempts_of(u09)
    sc.check("zero attempts created for 09.12 (API + g6 executor legs)",
             len(atts9) == 0, f"attempts={len(atts9)}")
    sc.check("09.12 still READY after the g6 executor's refused claim",
             unit_row(pid, u09)["state"] == "READY",
             f"state={unit_row(pid, u09)['state']}")
    sc.check("zero provider-side effects from the refused 09.12 leg "
             "(stub call count unchanged)",
             len(stub_calls(record)) == calls_before,
             f"calls {calls_before} -> {len(stub_calls(record))}")
    audit9 = audit_of(u09)
    sc.check("no start / submit_candidate events for 09.12 (executor "
             "never reached the worker)",
             not any(a["event"] in ("start", "submit_candidate")
                     for a in audit9),
             json.dumps(audit9))
    gates_after = hg2_gates(pid)
    sc.check("HG2 gate remains PENDING at the end of the prep",
             len(gates_after) == 1
             and gates_after[0]["verdict"] == "PENDING",
             json.dumps(gates_after))
    return sc.finish({"production_id": pid, "unit_08_12": u08,
                      "unit_09_12": u09,
                      "note": "refusal half only; the HG2 decision + "
                              "consumption leg is genuine Phase 7/8"})


# ------------------------------------------------------------------ main
def setup():
    subprocess.run(["pg_ctlcluster", "16", "main", "start"],
                   capture_output=True)
    r = subprocess.run(["python3", str(G3 / "tools/setup_db.py"), DB],
                       capture_output=True, text=True)
    if r.returncode != 0:
        raise SystemExit(f"scratch DB setup failed: {r.stderr[-400:]}")
    print(f"db: {DB} built (registry + plans loaded by the G3 chain)")
    kill_port(8730)
    spawn([str(G3 / ".venv/bin/python"), str(G3 / "api/server.py")],
          {"FACTORY_DSN": DSN, "FACTORY_PORT": "8730", **TOKENS}, "api.log")
    if not wait_url(API + "/health"):
        raise SystemExit("API did not come up (see logs/api.log)")
    print("api: up on 8730")
    # worker service WITH the slice credential env (Phase 3 run-b
    # shape): dummy key value, ref named — adapter READY, and its
    # calls resolve the OPERATION binding's credential_ref from env.
    kill_port(8795)
    spawn([VENV_PY, str(PROG / "gate-c/worker_service/service.py")],
          {"WORKER_SERVICE_PORT": "8795", "WORKER_ENVIRONMENT": "test",
           "WORKER_DSN": DSN, "FACTORY_API_URL": API,
           "FACTORY_WORKER_TOKEN": TOKENS["FACTORY_WORKER_TOKEN"],
           "WORKER_CREDENTIAL_REFS": "OPENROUTER_API_KEY",
           "OPENROUTER_API_KEY": "stub-local-key"}, "worker.log")
    if not wait_url(WORKER + "/health"):
        raise SystemExit("worker service did not come up (see logs/worker.log)")
    _, health = call(WORKER, "GET", "/health")
    print(f"worker: up on 8795, openrouter-compatible="
          f"{health['adapters']['openrouter-compatible']['status']}")
    kill_port(8796)
    spawn([VENV_PY, str(PROG / "gate-e/evaluation_service/service.py")],
          {"FACTORY_DSN": DSN, "FACTORY_API_URL": API,
           "FACTORY_VALIDATOR_TOKEN": TOKENS["FACTORY_VALIDATOR_TOKEN"],
           "FACTORY_EVAL_PORT": "8796"}, "eval.log")
    if not wait_url(EVAL + "/health"):
        raise SystemExit("evaluation service did not come up (see logs/eval.log)")
    print("evaluation service: up on 8796")
    # n8n restarted fresh with the known station env, then the g5
    # workflows synced through the g5 setup module (REST path).
    kill_port(5678)
    time.sleep(1)
    spawn([str(G4T / "node_modules/.bin/n8n"), "start"],
          {"N8N_USER_FOLDER": str(G4T / "n8n-data"), "N8N_PORT": "5678",
           "N8N_LISTEN_ADDRESS": "127.0.0.1",
           "N8N_DIAGNOSTICS_ENABLED": "false",
           "N8N_TEMPLATES_ENABLED": "false",
           "N8N_BLOCK_ENV_ACCESS_IN_NODE": "false",
           **TOKENS,
           "FACTORY_API_URL": API,
           "FACTORY_WORKER_SERVICE_URL": WORKER,
           "FACTORY_EVALUATION_URL": EVAL}, "n8n.log")
    if not wait_url(N8N + "/healthz", seconds=120):
        raise SystemExit("n8n did not come up (see logs/n8n.log)")
    sys.path.insert(0, str(G5 / "tools"))
    import setup_env as g5_setup  # noqa: E402
    g5_setup.sync_workflows()
    print("n8n: up on 5678, g5 workflows synced + active")
    import importlib.util  # noqa: E402
    spec6 = importlib.util.spec_from_file_location(
        "g6_setup_env", str(HOME / "workspace/video-factory-g6/tools/setup_env.py"))
    g6_setup = importlib.util.module_from_spec(spec6)
    spec6.loader.exec_module(g6_setup)
    g6_setup.sync_workflows()
    print("n8n: g6 workflows synced + active (fixed executor for P4P-5)")
    # slice seeding: OPERATION 08.12 binding endpoint overridden to
    # the local stub (recorded override; canonical binding has no
    # base_url). Also seeds STATION 3 det-local + pricing rows.
    r = subprocess.run([sys.executable,
                        str(PHASE3 / "tools/setup_slice.py"),
                        "--base-url", STUB_URL],
                       capture_output=True, text=True)
    if r.returncode != 0:
        raise SystemExit(f"slice seeding failed: {r.stdout} {r.stderr}")
    print("slice seed:", r.stdout.strip().replace("\n", " | "))
    # STATION 4 binding (g6 setup shape) so P4P-5's 09.12 claim reaches
    # config resolution and then the HG2 gate check.
    s, out = call(API, "POST", "/configs",
                  {"scope": "STATION", "station": 4, "environment": "test",
                   "provider": "deterministic-local", "est_cost_cents": 100,
                   "params": {"reported_actual_cents": 90}}, role="OPERATOR")
    if s not in (200, 201):
        # already present from an earlier setup run on this DB is fine
        _, cfgs = call(API, "GET", "/configs", role="OPERATOR")
        have = any(c.get("scope") == "STATION" and c.get("station") == 4
                   and c.get("active", True) for c in cfgs.get("configs", []))
        if not have:
            raise SystemExit(f"STATION 4 binding seed failed: {s} {out}")
    print("bindings: STATION 4 deterministic-local present")
    return 0


def teardown():
    for port in (8730, 8795, 8796, STUB_PORT):
        kill_port(port)
    print("teardown: 8730/8795/8796/8799 stopped (n8n left running: "
          "shared instance, workflows remain synced)")
    return 0


if __name__ == "__main__":
    cmd = sys.argv[1] if len(sys.argv) > 1 else ""
    LOGS.mkdir(parents=True, exist_ok=True)
    RESULTS.mkdir(parents=True, exist_ok=True)
    sys.exit({"setup": setup, "p4p1": p4p1, "p4p2": p4p2, "p4p3": p4p3,
              "p4p4": p4p4, "p4p5": p4p5, "teardown": teardown}[cmd]())
