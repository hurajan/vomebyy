# FIX REPORT — F-P4P-01 / F-P4P-02 (Lean Phase 4 unblocking repair)

**Status: FIX COMPLETE. Prep battery green on the fixed executors;
deterministic regression green. Phase 4 itself remains
BLOCKED_EXTERNAL on the owner credential — this fix removes the two
product defects the prep found; it does not (and cannot) supply the
credential or the spend-cap confirmation.**

All provider-involved evidence is **STUB_TESTED** (local stub at
:8799; the canonical OPERATION binding carries no base_url — the
stub endpoint was a per-DB seeding override only).

## The generator change (identical shape in all five trees)

In each of `video-factory-g{4,5,6,7,8}/tools/gen_workflows.py`,
unit-executor workflow only (regenerated `workflows/` JSON diffs are
confined to `unit-executor.json` in every tree — normalized-diff
proof in `evidence/`):

1. **New node `Load production artifacts`** — GET
   /productions/{pid}/artifacts (WORKER read role), inserted between
   `Fetch attempt snapshot` and `Assemble worker payload`.
2. **F-P4P-01 — `Assemble worker payload`** now builds
   `input_artifact_refs` as planned inputs (unchanged, first) **plus,
   only on the provider-generation path**, the CURRENT output
   artifacts of the unit's dependency units — identified without any
   new API surface: production artifacts (each carries
   `produced_by_unit` + `state`) joined to the production's units
   (existing `Load unit` read); an artifact qualifies when its
   producer unit is ACCEPTED, in the same run as the dispatched unit
   (`Unit state` now also emits `unit_run_id` for the join), is
   CURRENT, and is not the unit's own output. "Provider-generation
   path" = the attempt's pinned binding
   (`attempt.resolved_config.provider`) names a real provider —
   never `deterministic-local`, `mock`, or unbound. Assemble now
   reads the attempt snapshot via `$('Fetch attempt snapshot')`
   (its `$input` is the artifacts response).
3. **F-P4P-02 — `submit-candidate`** additionally forwards `usage`
   and `provider_request_id` from the worker-call result verbatim.
   The generator's http() helper wraps bodies in JSON.stringify, so
   absent fields are dropped: the deterministic completion body is
   unchanged in effect.

Why the provider gate (regression-forced, recorded in
CHANGED_ASSERTIONS.md): the un-gated version failed the G9 full run
— 10.12 is planned with zero inputs and its payload builder declares
`script_ref` from any script ref it is fed, so the extras broke the
declared == planned continuity contract (REPAIR_REQUIRED). Payload
builders treat refs as their declared-input contract; context refs
beyond planned are sanctioned by the frozen spec (§3.2/§3.3) only
for generation, whose shaping declares just the planned canon. The
gate is the one deliberate narrowing vs the finding's minimal shape;
the brief's literal depends_on walk is additionally not expressible
(no read endpoint exposes unit_dependencies), so the sanctioned
fallback (CURRENT artifacts of ACCEPTED same-run producers) is used
— it covers the transitive chain (05.12/06.12 outputs for 08.12).

## Battery verdicts (fixed executors, stub provider, [canon]-only planning)

| Test | Verdict | Decisive counts |
|---|---|---|
| P4P-1 happy path via n8n | **PASS 23/23** | 1 provider call; refs proven cryptographically (inputs_hash + manifest output digest recomputed & matched: [canon, beat_graph, scene_set, story_architecture]); CALCULATED 1¢; FINALIZED 1¢ basis *calculated* carrying usage 1500/700 + provider_request_id `chatcmpl-stub-1`; unit AWAITING_HUMAN; HG2 PENDING bound to script id+sha; budget spent 271¢, reserved 0 |
| P4P-2 duplicate dispatch | **PASS 20/20** | 1 provider call, 1 attempt, 1 script artifact, 1 FINALIZED, 1 HG2 gate |
| P4P-3 claim refusal ⇒ no provider call | **PASS 11/11** | 0 provider calls, 0 artifacts, unit CLAIMED under the foreign attempt |
| P4P-4 provider failure + recovery | **PASS 16/16** | stub 500 → RETRY_WAIT, FAILED generation record, 0 charges; redispatch → AWAITING_HUMAN; 2 provider calls total; exactly 1 FINALIZED (1¢); spent 271¢ |
| P4P-5 downstream refusal (g6 executor run) | **PASS 19/19** | scheduler skips gate-refused 09.12; direct claim 409 + gate_claim_refused audit; fixed g6 executor's own claim refused — 0 attempts, 0 provider effects, unit READY; HG2 PENDING throughout (never decided) |

## Deterministic regression (post-refinement, serial, counts from logs)

g9 **10/10 OK** — full-run DB independently verified: 18 units
ACCEPTED, 18 FINALIZED rows = **1620¢**, every basis
`reported_actual` (no CALCULATED invented, settlement path
untouched). g4 **2/2**, g5 **1/1**, g6 **3/3**, g7 **2/2**, g8
**1/1** — all OK. T02-H **PASS 12/12**. Worker service **40/40 OK**.
G3 API **36/36 OK**.

One environmental incident, recorded honestly: the first g4 rerun
FAILED (units stuck VALIDATING/BLOCKED) because the API process
never restarted onto g4_station_scratch — the suite ran against the
previous tree's DB (its units are persisted in g8_station_scratch).
After a port kill + an API↔DB identity probe, the clean rerun
passed 2/2 in 36.5s. Both logs are preserved; this is the known
shared-port setup fragility, not a product defect.

## Updated Phase 4 readiness delta

Both executor defects are FIXED and regression-proven. What remains
for the genuine Phase 4 run is exactly the original READINESS.md
list, unchanged:

1. Owner supplies `OPENROUTER_API_KEY` in the worker service env
   (secrets path only) and confirms the PROPOSED cap set
   (claude-haiku-4.5 pin, 25¢ estimate, soft 250¢ / hard 500¢).
2. Re-seed the slice binding WITHOUT the stub `base_url` override
   (canonical binding already carries none — adapter default
   applies); start the worker with the key (/health READY).
3. Re-run this same battery genuinely (Phases 4–9 evidence):
   n8n dispatch → adopt → one real provider call → genuine script
   artifact → CALCULATED/FINALIZED from real usage → evaluation →
   HG2 human decision → downstream consumption proof.
