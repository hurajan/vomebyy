#!/usr/bin/env python3
"""Diagnostic probe for the P4P-1 finding (Lean Phase 4 prep).

Case A: re-derive the recorded facts of the original P4P-1 run
(production planned with 4 inputs) from the DB + stub record.
Case B: the decisive experiment — 08.12 planned contract-correctly
([canon_manifest] only, per the Phase 2 spec §3.2 frozen fixture and
the Gate G continuity contract) and driven through n8n under the
OPERATION provider binding. Expectation from source: the executor
delivers only the planned input as worker refs; op.generate_script
fails explicitly on the missing scene_set BEFORE any provider call.
"""
import json
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import prep_harness as H  # noqa: E402

sc = H.Scenario("probe_planning_contract")

# ---------------------------------------------------------------- Case A
A_PID = "daac2ab9-e3ec-474c-97f5-c3e0677c39a3"
A_UID = "e83c82f4-d4c4-424d-b995-b9766ab933d2"
state_a = H.unit_row(A_PID, A_UID)["state"]
ev_a = H.db("SELECT q.verdict, q.method, q.evidence FROM "
            "quality_evaluations q JOIN artifacts a "
            "ON a.artifact_id=q.artifact_id WHERE a.artifact_id IN "
            "(SELECT artifact_id FROM artifacts WHERE production_id=%s "
            "AND artifact_type='script') ORDER BY q.created_at",
            (A_PID,))
cont_a = [e for e in ev_a if e["method"] == "continuity"]
calls_a = H.stub_calls(H.LOGS / "stub_requests_p4p1.jsonl")
sc.check("CASE A (planned inputs = canon+story+beats+scenes): unit "
         "ended REPAIR_REQUIRED on the continuity layer",
         state_a == "REPAIR_REQUIRED" and bool(cont_a)
         and cont_a[0]["verdict"] == "FAIL"
         and "output does not declare all planned inputs"
         in json.dumps(cont_a[0]["evidence"]),
         f"state={state_a} continuity={json.dumps(cont_a)[:300]}")
sc.check("CASE A: the provider WAS called once and a shaped script "
         "WAS produced + CURRENT before evaluation refused it "
         "(generation leg works when refs carry the chain contents)",
         len(calls_a) == 1
         and len([a for a in H.script_artifacts(A_PID)
                  if a["state"] == "CURRENT"]) == 1,
         f"stub_calls={len(calls_a)}")

# ---------------------------------------------------------------- Case B
record = H.start_stub("ok", "probe")
pid, run, canon = H.make_production(sc, "Lean P4P probe (canon-only)")
_, _, u07 = H.build_chain(sc, pid, run, canon)
u08 = H.plan_unit(pid, run, "08.12", depends=[u07], inputs=[canon])
H.wait_state(pid, u08, {"READY"})
report = H.scheduler_prestage()
sc.check("CASE B: scheduler prestaged the 08.12 claim",
         any(c["unit_id"] == u08 for c in report["claimed"])
         and H.unit_row(pid, u08)["state"] == "CLAIMED",
         f"claimed={[c['unit_id'][:8] for c in report['claimed']]}")
H.post_dispatch(pid, u08, "08.12")
state = H.wait_state(pid, u08, {"RETRY_WAIT", "FAILED", "BLOCKED",
                                "REPAIR_REQUIRED", "AWAITING_HUMAN",
                                "ACCEPTED"}, timeout=300)
calls = H.stub_calls(record)
records = {r["action_key"]: r for r in H.action_records(u08)}
gen = records.get("op.build", {})
sc.check("CASE B (planned inputs = [canon] only): ZERO provider "
         "calls — the failure precedes the call (prompt assembly "
         "requires scene_set content the executor never delivered)",
         len(calls) == 0, f"calls={len(calls)}")
sc.check("CASE B: op.build record FAILED with the explicit "
         "scene_set error (Phase 3 design: no grounding, no shaping)",
         gen.get("status") in ("FAILED", "REFUSED")
         and "scene_set" in (gen.get("error") or ""),
         f"status={gen.get('status')} error={gen.get('error')}")
sc.check("CASE B: zero script artifacts; unit in a failure/recovery "
         "state, not ACCEPTED",
         len(H.script_artifacts(pid)) == 0
         and state in ("RETRY_WAIT", "FAILED", "BLOCKED"),
         f"state={state} scripts={len(H.script_artifacts(pid))}")
audit = H.audit_of(u08)
sc.check("CASE B: audit shows adopt + start, then the failure path "
         "(no submit_candidate)",
         any(a["event"] == "attempt_adopted" for a in audit)
         and not any(a["event"] == "submit_candidate" for a in audit),
         json.dumps(audit))

sys.exit(sc.finish({"production_id": pid, "unit_08_12": u08,
                    "end_state": state,
                    "finding": "n8n executor delivers only PLANNED "
                               "inputs as worker refs; continuity "
                               "contract bars planning the chain "
                               "outputs; op.generate_script requires "
                               "scene_set content => provider path "
                               "cannot run through n8n as shipped"}))
