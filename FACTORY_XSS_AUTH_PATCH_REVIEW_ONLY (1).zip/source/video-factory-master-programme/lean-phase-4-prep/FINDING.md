# FINDING — the n8n leg cannot carry the provider path as shipped

**Status: TWO blocking findings, both in the Gate G unit-executor
workflow layer. NO product code was changed by this prep (per brief:
stop and report). All evidence STUB_TESTED; Phase 4 remains
BLOCKED_EXTERNAL on the credential AND now on these two fixes.**

## F-P4P-01 — generation inputs never reach the worker through n8n

Three individually-correct components compose into a dead end:

1. The n8n unit-executor builds the worker request's
   `input_artifact_refs` from the unit's **planned** inputs only
   (Gate G design: G3 `api/server.py` — "the n8n executor assembles
   the worker request's input_artifact_refs from these [planned input
   refs]"; executor node "Assemble worker payload" maps
   `unitState.input_artifacts`).
2. The Gate E continuity layer requires the set of artifact ids a
   step-exit deliverable **declares** in its content to match the
   planned inputs in both directions ("output does not declare all
   planned inputs" / "output declares inputs that were not
   planned"). The 08.12 script declares exactly one artifact id: the
   canon (canon_refs). Planning the chain outputs
   (story_architecture / beat_graph / scene_set) as inputs is
   therefore contractually barred — and dependency outputs are never
   auto-added to `unit_inputs` (coordinator `plan_unit` writes only
   the caller's `input_artifact_ids`).
3. The Phase 3 generation action (`op.generate_script`) hard-requires
   `scene_set` content among the worker refs — by design ("generation
   without them cannot be shaped"): it fails explicitly BEFORE any
   provider call.

Proven live, both directions (probe_planning_contract.json, 13/13):
- **Case B** (contract-correct planning, inputs=[canon]): scheduler
  prestage + executor adopt work; op.build FAILED with
  `op.generate_script: scene_set input yields no scenes`;
  **0 provider calls**; 0 script artifacts; unit → RETRY_WAIT.
- **Case A** (the P4P-1 run, inputs=[canon+story+beats+scenes]): the
  generation leg itself worked — exactly 1 stub call, prompt grounded
  in the chain contents, shaped script CURRENT, HG2 gate created —
  then evaluation **continuity FAIL → REPAIR_REQUIRED**
  ("output does not declare all planned inputs",
  missing_declared = the three chain artifacts).

The Phase 2 spec §3.2 anticipated the fix mechanism ("the executor
including the production's CURRENT artifacts of those types in
input_artifact_refs") — the shipped Gate G executor does not
implement that half; it implements refs = planned only. Phase 3's
harness masked the gap because its driver hand-built refs as
planned + transitive dependency outputs (the worker contract already
supports refs ⊋ planned: run-b passed evaluation that way).

**Minimal fix (for an owner lock; NOT done here):** in the
unit-executor workflow(s) — g5's for the slice, all five trees for
consistency — the "Assemble worker payload" node additionally
includes the CURRENT output artifacts of the unit's dependency units
(or the production's CURRENT artifacts of the upstream types) in
`input_artifact_refs`. Planned inputs stay [canon]; the continuity
contract is untouched; the worker and coordinator need no change.

## F-P4P-02 — usage + provider_request_id never reach /complete

The executor's `submit-candidate` node posts /complete with
`{worker_id, fencing_token, artifact_type, content,
actual_cost_cents}` only. The /work response's `usage` and
`provider_request_id` — which the worker returns, and DID record in
the op.build action record's output_summary — are dropped.

Consequence, proven in Case A: the coordinator produces **no
CALCULATED evidence** (nothing to price) and **FINALIZED settles at
25¢ — the claim estimate presented as the final cost**. That is
exactly the spec C-3 / Phase 6 hazard ("the estimate must never be
presented as a measured cost"; "seeded mock values cannot count as
real billing measurements"). Phase 3's harness driver forwarded
usage manually, which masked this; the genuine Phase 4/6 acceptance
("settlement == CALCULATED from real usage") cannot pass through n8n
until it is fixed.

**Minimal fix (same lock as F-P4P-01):** forward `usage` and
`provider_request_id` from the worker-call result in the
submit-candidate body. The /complete API already accepts both
(Phase 3 run-b proved the API path end to end).

## What this prep DID prove (STUB_TESTED)

- Scheduler-prestage → executor-adopt → worker → evaluation drives
  the full Station 03 chain to ACCEPTED through n8n in four separate
  productions; the adopt path works under the slice's OPERATION
  provider binding (attempt under n8n-executor-g5, claim audit actor
  scheduler-service, attempt_adopted recorded).
- P4P-3 PASS (11/11): a claim prestaged under a wrong identity →
  executor claim-refused branch → **0 provider calls**, 0 artifacts,
  unit still CLAIMED under the foreign attempt.
- The generation leg itself, when refs carry the chain contents:
  exactly 1 provider call, canon/scene-grounded prompt, worker-shaped
  schema-valid script CURRENT, HG2 gate created by the station flow
  bound to the script id+sha (PENDING).
- Worker-side provider evidence is complete: the op.build action
  record carries provider_request_id + token usage.
- The worker failure path via n8n (probe Case B incidentally):
  /work failure → error-handler transient_error → RETRY_WAIT.

## Battery disposition

| Test | Verdict |
|---|---|
| P4P-1 happy path via n8n | **FAIL** — 6/8 sub-checks pass; evaluation continuity refusal (F-P4P-01 planning horn) + settlement-at-estimate (F-P4P-02) |
| P4P-2 duplicate dispatch | NOT_RUN — presupposes the blocked happy path |
| P4P-3 claim refusal ⇒ no provider call | **PASS 11/11** |
| P4P-4 provider failure + recovery | NOT_RUN — presupposes a completable n8n provider run (the failure→RETRY_WAIT leg was observed in probe Case B) |
| P4P-5 downstream refusal prep | NOT_RUN — presupposes an ACCEPTED n8n-driven 08.12 under the binding (HG2 mechanics themselves remain proven: Gate 05 verification + the PENDING gate created in the P4P-1 run) |
| Probe (planning contract, Cases A+B) | PASS 13/13 — the finding's decisive experiment |

## Updated Phase 4 readiness delta

The credential is no longer the only blocker. Before the genuine
run can pass, in order:

1. **Owner lock + fix for F-P4P-01 and F-P4P-02** — both are
   unit-executor workflow changes (one node's ref assembly; one
   node's completion body), g5 tree minimally, five trees for
   consistency. No coordinator / worker / registry / contract
   change. This is a product-code change and therefore outside this
   prep's authorization.
2. Re-run this prep battery against the stub (P4P-1/2/4/5) to green
   on the fixed executor.
3. THEN the original READINESS.md steps: owner supplies
   `OPENROUTER_API_KEY` in the worker env + confirms the PROPOSED
   cap set; re-seed the slice binding WITHOUT the base_url override
   (adapter default applies); start the worker with the key; rerun
   the same battery genuinely and collect the Phase 4–9 evidence.
