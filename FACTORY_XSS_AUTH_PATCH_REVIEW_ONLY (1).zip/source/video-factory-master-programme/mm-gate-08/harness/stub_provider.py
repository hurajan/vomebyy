#!/usr/bin/env python3
"""MM-08 stub OpenRouter-compatible provider (STUB_TESTED only).

Modes (argv[2]):
  usage      every chat completion returns content + a usage object
  nousage    every chat completion returns content and NO usage field
             at all (the MM-08 missing-usage fixture)
  failmodel  requests whose model == argv[5] get HTTP 500 with NO usage
             in the error body (the MM-05 fallback shape); other models
             are served with usage

Usage: stub_provider.py <record.jsonl> <mode> <port> <in_tokens> <out_tokens>
       [fail_model]

Every request is appended to the record file as one JSON line
{model, path} so batteries can count calls per model. The completion
content is a schema-shaped step-08 script JSON (same shape the MM-05
stub serves) so the worker's shaping path accepts it.
"""
import json
import sys
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

RECORD = sys.argv[1]
MODE = sys.argv[2]
PORT = int(sys.argv[3])
IN_TOKENS = int(sys.argv[4])
OUT_TOKENS = int(sys.argv[5])
FAIL_MODEL = sys.argv[6] if len(sys.argv) > 6 else None

SCRIPT = {
    "kind": "script",
    "lines": [
        {"id": "L1", "scene_ref": "SC1", "beat_ref": "B1",
         "story_ref": "S1", "canon_refs": [], "text": "Stub line one."},
        {"id": "L2", "scene_ref": "SC2", "beat_ref": "B2",
         "story_ref": "S2", "canon_refs": [], "text": "Stub line two."},
        {"id": "L3", "scene_ref": "SC2", "beat_ref": "B2",
         "story_ref": "S2", "canon_refs": [], "text": "Stub line three."},
    ],
    "trace": {
        "clues": [{"id": "C1", "planted": "L1", "payoff": "L3"}],
        "knowledge": [{"character": "A", "learns": "C1", "at": "L2"}],
        "payoffs": [{"id": "P1", "clue": "C1", "line": "L3"}],
    },
    "canon_refs": [],
}


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *args):  # silence
        pass

    def _send(self, code, obj):
        body = json.dumps(obj).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_POST(self):
        length = int(self.headers.get("Content-Length") or 0)
        raw = self.rfile.read(length) if length else b"{}"
        try:
            req = json.loads(raw or b"{}")
        except json.JSONDecodeError:
            req = {}
        model = req.get("model")
        with open(RECORD, "a") as fh:
            fh.write(json.dumps({"model": model, "path": self.path}) + "\n")
        if MODE == "failmodel" and model == FAIL_MODEL:
            return self._send(500, {"error": {"message": "stub primary "
                                               "failure",
                                              "code": 500}})
        resp = {
            "id": f"chatcmpl-mm08-{model}",
            "object": "chat.completion",
            "model": model,
            "choices": [{"index": 0,
                         "message": {"role": "assistant",
                                     "content": json.dumps(SCRIPT)},
                         "finish_reason": "stop"}],
        }
        if MODE != "nousage":
            resp["usage"] = {"prompt_tokens": IN_TOKENS,
                             "completion_tokens": OUT_TOKENS,
                             "total_tokens": IN_TOKENS + OUT_TOKENS}
        return self._send(200, resp)

    def do_GET(self):
        if self.path == "/health":
            return self._send(200, {"status": "ok"})
        return self._send(404, {"error": "not found"})


if __name__ == "__main__":
    ThreadingHTTPServer(("127.0.0.1", PORT), Handler).serve_forever()
