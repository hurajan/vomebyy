#!/usr/bin/env python3
"""MM-08 gate harness — batteries (a)-(f) from LOCK_MM08.

Every provider interaction is a local stub (STUB_TESTED); no real
credential exists and none is used (the worker env carries a dummy
value for the credential NAME so the credentialed path is live against
the stub). Ports are killed before/after every scenario (OBS-1
hygiene) and each scenario asserts the API it talks to serves THIS
harness's scratch DB before trusting a result.

Usage: mm08_battery.py <a|b|c|d|e|f> — writes
evidence/results/<scenario>.json and exits non-zero on any failure.
"""
import json
import os
import re
import signal
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.request
from pathlib import Path

import psycopg
from psycopg.rows import dict_row

HOME = Path.home()
G2 = HOME / "workspace/video-factory-g2"
G3 = HOME / "workspace/video-factory-g3"
RP = HOME / "workspace/video-factory-real-ai-programme"
GATE = HOME / "workspace/video-factory-master-programme/mm-gate-08"
PY = str(G2 / ".venv/bin/python")
DB = "mm08_harness_scratch"
_pw = re.search(r"password=([^\s\"]+)",
                (G2 / "tests/test_gatec.py").read_text()).group(1)
DSN = f"host=127.0.0.1 dbname={DB} user=factory password={_pw}"
API = "http://127.0.0.1:8730"
WORKER = "http://127.0.0.1:8795"
STUB_PORT = 8899
TOKENS = {"FACTORY_API_TOKEN": "mm08-operator-token",
          "FACTORY_WORKER_TOKEN": "mm08-worker-token",
          "FACTORY_SCHEDULER_TOKEN": "mm08-scheduler-token",
          "FACTORY_VALIDATOR_TOKEN": "mm08-validator-token",
          "FACTORY_CALLBACK_TOKEN": "mm08-callback-token"}
RESULTS = GATE / "evidence/results"
LOGS = GATE / "evidence/logs/harness"
RESULTS.mkdir(parents=True, exist_ok=True)
LOGS.mkdir(parents=True, exist_ok=True)

sys.path.insert(0, str(G2 / "coordinator"))
sys.path.insert(0, str(RP / "gate-f"))
from coordinator import Coordinator  # noqa: E402
from runtime_services.reconciler_service import ReconcilerService  # noqa: E402


def call(base, method, path, body=None, role="OPERATOR", expect=None):
    req = urllib.request.Request(base + path, method=method)
    if role == "OPERATOR":
        req.add_header("X-Operator-Token", TOKENS["FACTORY_API_TOKEN"])
    elif role:
        req.add_header("X-Role", role)
        req.add_header("X-Role-Token", TOKENS[f"FACTORY_{role}_TOKEN"])
        req.add_header("X-Identity", role.lower() + "-harness")
    data = None
    if body is not None:
        data = json.dumps(body).encode()
        req.add_header("Content-Type", "application/json")
    try:
        with urllib.request.urlopen(req, data=data, timeout=30) as r:
            out = json.loads(r.read() or b"{}")
            status = r.status
    except urllib.error.HTTPError as e:
        status = e.code
        try:
            out = json.loads(e.read() or b"{}")
        except Exception:
            out = {}
    if expect is not None and status != expect:
        raise AssertionError(f"{method} {path} -> {status} (want {expect}): {out}")
    return status, out


def db(sql, args=()):
    with psycopg.connect(DSN, row_factory=dict_row, autocommit=True) as conn:
        cur = conn.execute(sql, args)
        if cur.description is None:  # INSERT/UPDATE without RETURNING
            return []
        return cur.fetchall()


def db1(sql, args=()):
    rows = db(sql, args)
    return rows[0] if rows else None


def kill_port(port):
    subprocess.run(["fuser", "-k", f"{port}/tcp"], capture_output=True)
    time.sleep(0.3)


def spawn(cmd, env, log_name, cwd=None):
    LOGS.mkdir(parents=True, exist_ok=True)
    fh = open(LOGS / log_name, "wb")
    proc = subprocess.Popen(cmd, env=env, cwd=cwd, stdout=fh,
                            stderr=subprocess.STDOUT)
    return proc


def wait_url(url, seconds=60):
    deadline = time.time() + seconds
    while time.time() < deadline:
        try:
            with urllib.request.urlopen(url, timeout=3) as r:
                if r.status == 200:
                    return True
        except Exception:
            time.sleep(0.3)
    return False


def build_db():
    r = subprocess.run(["python3", str(G3 / "tools/setup_db.py"), DB],
                       capture_output=True, text=True)
    if r.returncode != 0:
        raise RuntimeError(f"setup_db failed: {r.stdout[-300:]} {r.stderr[-300:]}")


def start_api(log="api.log"):
    kill_port(8730)
    env = dict(os.environ, FACTORY_DSN=DSN, FACTORY_PORT="8730",
               FACTORY_STORAGE_ROOT="/tmp/mm08-storage", **TOKENS)
    proc = spawn([PY, str(G3 / "api/server.py")], env, log)
    if not wait_url(API + "/health"):
        raise RuntimeError("API did not come up")
    # OBS-1: prove this API serves THIS harness's DB — a marker
    # production created over HTTP must be visible in our SQL view.
    _, out = call(API, "POST", "/productions",
                  {"title": "mm08-dsn-probe", "hard_ceiling_cents": 1,
                   "soft_ceiling_cents": 1}, expect=201)
    row = db1("SELECT title FROM productions WHERE production_id=%s",
              (out["production_id"],))
    assert row and row["title"] == "mm08-dsn-probe", "API/DSN mismatch (OBS-1)"
    return proc


def stop(proc):
    if proc and proc.poll() is None:
        proc.terminate()
        try:
            proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            proc.kill()


class Scenario:
    def __init__(self, name):
        self.name = name
        self.checks = []

    def check(self, name, ok, detail=""):
        self.checks.append({"name": name, "pass": bool(ok),
                            "detail": str(detail)[:600]})
        print(("PASS " if ok else "FAIL ") + name +
              (f" :: {str(detail)[:200]}" if detail else ""))

    def finish(self, extra=None):
        out = {"scenario": self.name,
               "verdict": "PASS" if all(c["pass"] for c in self.checks)
               else "FAIL",
               "checks": self.checks}
        if extra:
            out.update(extra)
        (RESULTS / f"{self.name}.json").write_text(json.dumps(out, indent=1))
        print(f"== {self.name}: {out['verdict']} "
              f"({sum(c['pass'] for c in self.checks)}/{len(self.checks)})")
        return 0 if out["verdict"] == "PASS" else 1


def seed_config(scope, provider, est, op=None, station=None, model=None,
                cred=None, params=None):
    db("UPDATE provider_configs SET active=false WHERE scope=%s"
       " AND environment='test' AND active"
       " AND COALESCE(station,-1)=COALESCE(%s,-1)"
       " AND COALESCE(operation_id,'')=COALESCE(%s,'')",
       (scope, station, op))
    db("INSERT INTO provider_configs(scope, station, operation_id,"
       " environment, provider, model, est_cost_cents, credential_ref,"
       " params, created_by) VALUES (%s,%s,%s,'test',%s,%s,%s,%s,%s,"
       " 'mm08-harness')",
       (scope, station, op, provider, model, est, cred,
        json.dumps(params or {})))


def seed_pricing(provider, model, in_price, out_price, version="mm08-1"):
    for kind, price in (("input_token", in_price), ("output_token", out_price)):
        db("INSERT INTO pricing_rules(provider, model, unit_kind,"
           " unit_price_cents, pricing_version, created_by) VALUES"
           " (%s,%s,%s,%s,%s,'mm08-harness')",
           (provider, model, kind, price, version))


# ---------------------------------------------------------------- (a) caps
def scenario_a():
    sc = Scenario("a_provider_cap")
    build_db()
    api = start_api("api_a.log")
    try:
        seed_config("OPERATION", "cap-provider", 100, op="01.01")
        db("INSERT INTO provider_spend_limits(provider, cap_cents,"
           " created_by) VALUES ('cap-provider', 150, 'mm08-harness')")

        def make_unit(title):
            _, p = call(API, "POST", "/productions",
                        {"title": title, "hard_ceiling_cents": 100000,
                         "soft_ceiling_cents": 90000}, expect=201)
            _, r = call(API, "POST", f"/productions/{p['production_id']}/runs",
                        {"kind": "FULL"}, expect=201)
            _, u = call(API, "POST", f"/productions/{p['production_id']}/units",
                        {"operation_id": "01.01", "run_id": r["run_id"],
                         "unit_key": "main"}, expect=201)
            return p["production_id"], u["unit_id"]

        pid_a, ua = make_unit("cap A")
        status, out = call(API, "POST", f"/units/{ua}/claim",
                           {"worker_id": "w-a"}, expect=200)
        sc.check("first claim succeeds under the cap", status == 200, out)
        pid_b, ub = make_unit("cap B")
        status, out = call(API, "POST", f"/units/{ub}/claim",
                           {"worker_id": "w-b"})
        sc.check("second claim refused 409 by the provider cap",
                 status == 409 and "provider spend cap" in out.get("error", ""),
                 out)
        row = db1("SELECT state FROM execution_units WHERE unit_id=%s", (ub,))
        sc.check("refused unit stays READY", row["state"] == "READY", row)
        rows = db("SELECT payload FROM audit_events WHERE unit_id=%s"
                  " AND event_type='provider_cap_refused'", (ub,))
        sc.check("provider_cap_refused audit committed with figures",
                 len(rows) == 1
                 and rows[0]["payload"]["window_held_cents"] == 100
                 and rows[0]["payload"]["cap_cents"] == 150, rows)
        return sc.finish()
    finally:
        stop(api)
        kill_port(8730)


# ------------------------------------------------------- (d) concurrency
def scenario_d():
    sc = Scenario("d_concurrency")
    build_db()
    coord = Coordinator(DSN)

    def race(claims):
        barrier = threading.Barrier(len(claims))
        results = [None] * len(claims)

        def run(i, fn):
            barrier.wait(timeout=30)
            try:
                results[i] = ("ok", fn())
            except Exception as exc:  # noqa: BLE001
                results[i] = ("err", f"{type(exc).__name__}: {exc}")
        threads = [threading.Thread(target=run, args=(i, fn))
                   for i, fn in enumerate(claims)]
        for t in threads:
            t.start()
        for t in threads:
            t.join(timeout=60)
        return results

    # provider cap race: fresh provider per round, cap admits exactly one
    for rnd in range(5):
        provider = f"race-provider-{rnd}"
        seed_config("OPERATION", provider, 100, op="01.01")
        db("INSERT INTO provider_spend_limits(provider, cap_cents,"
           " created_by) VALUES (%s, 150, 'mm08-harness')", (provider,))
        units = []
        for k in range(2):
            pid = coord.create_production(f"race {rnd}-{k}", 100000, 90000,
                                          "mm08-harness")
            run = coord.start_run(pid, "FULL", "mm08-harness")
            units.append(coord.plan_unit(pid, run, "01.01", "main"))
        samples = []
        stop_sampling = threading.Event()

        def sample():
            with psycopg.connect(DSN, row_factory=dict_row,
                                 autocommit=True) as conn:
                cur = conn.cursor()
                while not stop_sampling.is_set():
                    pos = Coordinator._provider_window_position(cur, provider)
                    samples.append(pos["total_cents"])
                    time.sleep(0.005)

        sampler = threading.Thread(target=sample)
        sampler.start()
        results = race([
            (lambda u=u, k=k: Coordinator(DSN).claim(u, f"racer-{k}", 100))
            for k, u in enumerate(units)])
        stop_sampling.set()
        sampler.join(timeout=10)
        winners = [r for r in results if r and r[0] == "ok"]
        losers = [r for r in results
                  if r and r[0] == "err" and "ProviderCapExceeded" in r[1]]
        sc.check(f"round {rnd}: exactly one winner under the provider cap",
                 len(winners) == 1 and len(losers) == 1, results)
        sc.check(f"round {rnd}: cap never exceeded at any sampled read",
                 all(s <= 150 for s in samples) and len(samples) > 0,
                 f"samples={len(samples)} max={max(samples) if samples else None}")
    # production hard-cap race: one production, ceiling admits one.
    # Isolate it: lift the provider cap left active by the rounds above.
    db("UPDATE provider_spend_limits SET active=false")
    for rnd in range(3):
        pid = coord.create_production(f"hard race {rnd}", 150, 150,
                                      "mm08-harness")
        run = coord.start_run(pid, "FULL", "mm08-harness")
        units = [coord.plan_unit(pid, run, "01.01", f"u{k}") for k in range(2)]
        results = race([
            (lambda u=u, k=k: Coordinator(DSN).claim(u, f"racer-{k}", 100))
            for k, u in enumerate(units)])
        winners = [r for r in results if r and r[0] == "ok"]
        losers = [r for r in results
                  if r and r[0] == "err" and "BudgetExceeded" in r[1]]
        sc.check(f"hard-cap round {rnd}: exactly one winner",
                 len(winners) == 1 and len(losers) == 1, results)
        pos = coord.budget_position(pid)
        sc.check(f"hard-cap round {rnd}: settled+held within ceiling",
                 pos["projected_cents"] <= 150, pos)
    coord.close()
    return sc.finish()


# ------------------------------------------- (e) duplicate completions
def scenario_e():
    sc = Scenario("e_duplicate_callbacks")
    build_db()
    api = start_api("api_e.log")
    try:
        seed_config("OPERATION", "cred-provider", 100, op="01.02",
                    model="m1", cred="SOME_KEY")
        seed_pricing("cred-provider", "m1", "1.0", "2.0")
        coord = Coordinator(DSN)
        pid = coord.create_production("dup cb", 100000, 90000, "mm08-harness")
        run = coord.start_run(pid, "FULL", "mm08-harness")
        uid = coord.plan_unit(pid, run, "01.02", "main")
        claim = coord.claim(uid, "w-e", 100)
        coord.event(uid, "start")
        status, out = call(API, "POST", "/provider-jobs",
                           {"unit_id": uid, "attempt_id": claim["attempt_id"],
                            "fencing_token": claim["fencing_token"],
                            "idempotency_key": "mm08-dup-1"}, role="WORKER",
                           expect=201)
        job_id = out["job_id"]
        body = {"content": "result-bytes", "usage": {"input_tokens": 40},
                "provider_request_id": "req-dup-1", "model": "m1",
                "actual_cost_cents": 100}
        s1, o1 = call(API, "POST", f"/provider-jobs/{job_id}/callback",
                      body, role="CALLBACK", expect=200)
        s2, o2 = call(API, "POST", f"/provider-jobs/{job_id}/callback",
                      body, role="CALLBACK", expect=200)
        sc.check("first callback completes, second is the recorded duplicate",
                 o1["duplicate"] is False and o2["duplicate"] is True
                 and o1["result"] == o2["result"], (o1, o2))
        ev = db("SELECT charge_class, amount_cents FROM financial_evidence"
                " WHERE attempt_id=%s ORDER BY created_at",
                (claim["attempt_id"],))
        sc.check("exactly one FINALIZED (at the MM-04 model field's pricing)",
                 [e["charge_class"] for e in ev]
                 == ["ESTIMATED", "CALCULATED", "FINALIZED"]
                 and ev[-1]["amount_cents"] == 40, ev)
        charges = db("SELECT count(*) AS n FROM budget_transactions"
                     " WHERE reservation_id=%s AND kind='CHARGE'",
                     (claim["reservation_id"],))
        sc.check("exactly one CHARGE for the reservation",
                 charges[0]["n"] == 1, charges)
        coord.close()
        return sc.finish()
    finally:
        stop(api)
        kill_port(8730)


# ------------------------------------------------- shared slice driving
DRIVER = "mm08-driver"
CANON_TEXT = json.dumps({"canon": "MM-08 fixture canon: the bell keeper "
                                  "crosses the river at dawn.",
                         "characters": ["keeper"]})


def start_worker(extra_env, log="worker.log"):
    kill_port(8795)
    env = dict(os.environ, WORKER_SERVICE_PORT="8795",
               WORKER_ENVIRONMENT="test", WORKER_DSN=DSN,
               FACTORY_API_URL=API,
               FACTORY_WORKER_TOKEN=TOKENS["FACTORY_WORKER_TOKEN"],
               FACTORY_STORAGE_ROOT="/tmp/mm08-storage",
               WORKER_CREDENTIAL_REFS="OPENROUTER_API_KEY")
    env.update(extra_env)
    proc = spawn([PY, "service.py"], env, log,
                 cwd=str(RP / "gate-c/worker_service"))
    if not wait_url(WORKER + "/health"):
        raise RuntimeError("worker service did not come up")
    return proc


def start_stub(mode, in_toks, out_toks, fail_model=None, tag="stub"):
    kill_port(STUB_PORT)
    record = LOGS / f"stub_calls_{tag}.jsonl"
    record.unlink(missing_ok=True)
    cmd = ["python3", str(GATE / "harness/stub_provider.py"), str(record),
           mode, str(STUB_PORT), str(in_toks), str(out_toks)]
    if fail_model:
        cmd.append(fail_model)
    proc = spawn(cmd, dict(os.environ), f"stub_{tag}.log")
    if not wait_url(f"http://127.0.0.1:{STUB_PORT}/health"):
        raise RuntimeError("stub did not come up")
    return proc, record


def stub_calls(record):
    if not record.exists():
        return []
    return [json.loads(l) for l in record.read_text().splitlines() if l.strip()]


def make_production(title, hard=500, soft=250):
    _, p = call(API, "POST", "/productions",
                {"title": title, "hard_ceiling_cents": hard,
                 "soft_ceiling_cents": soft}, expect=201)
    _, r = call(API, "POST", f"/productions/{p['production_id']}/runs",
                {"kind": "FULL"}, expect=201)
    return p["production_id"], r["run_id"]


def plan_api(pid, run, op, depends=(), canon=None):
    body = {"operation_id": op, "run_id": run, "unit_key": "main",
            "depends_on": list(depends),
            "input_artifact_ids": [canon] if canon else []}
    _, u = call(API, "POST", f"/productions/{pid}/units", body, expect=201)
    return u["unit_id"]


def current_artifacts(pid):
    return db("SELECT artifact_id, artifact_type, sha256 FROM artifacts"
              " WHERE production_id=%s AND state='CURRENT'", (pid,))


def wire_refs(pid):
    return [{"artifact_type": a["artifact_type"],
             "artifact_id": str(a["artifact_id"]),
             "sha256": a["sha256"]} for a in current_artifacts(pid)]


def wait_state(uid, states, timeout=90):
    deadline = time.time() + timeout
    while time.time() < deadline:
        row = db1("SELECT state FROM execution_units WHERE unit_id=%s", (uid,))
        if row and row["state"] in states:
            return row["state"]
        time.sleep(0.3)
    raise AssertionError(f"unit {uid} never reached {states}")


def claim_api(uid):
    _, claim = call(API, "POST", f"/units/{uid}/claim",
                    {"worker_id": DRIVER}, expect=200)
    _, attempts = call(API, "GET", f"/units/{uid}/attempts")
    return claim, attempts["attempts"][0]["resolved_config"]


def work(uid, op, pid, claim, binding, refs):
    body = {"provider_binding": binding, "operation_id": op,
            "production_id": pid, "unit_id": uid,
            "attempt_id": claim["attempt_id"],
            "fencing_token": claim["fencing_token"], "worker_id": DRIVER,
            "input_artifact_refs": refs}
    return call(WORKER, "POST", "/work", body)


def complete_api(uid, claim, out):
    body = {"worker_id": DRIVER, "fencing_token": claim["fencing_token"],
            "artifact_type": out["artifact_type"],
            "content": out["content"],
            "actual_cost_cents": out["actual_cost_cents"]}
    if out.get("usage") is not None:
        body["usage"] = out["usage"]
    if out.get("provider_request_id") is not None:
        body["provider_request_id"] = out["provider_request_id"]
    if out.get("model") is not None:
        body["model"] = out["model"]
    return call(API, "POST", f"/units/{uid}/complete", body, expect=200)


def drive_chain_unit(sc, pid, uid, op):
    wait_state(uid, {"READY"})
    claim, binding = claim_api(uid)
    status, out = work(uid, op, pid, claim, binding, wire_refs(pid))
    sc.check(f"{op} /work COMPLETED (deterministic chain)",
             status == 200 and out.get("status") == "COMPLETED",
             f"status={status} out={str(out)[:200]}")
    complete_api(uid, claim, out)
    call(API, "POST", f"/units/{uid}/validate", {"verdict": "PASS"},
         expect=200)
    state = wait_state(uid, {"ACCEPTED"})
    sc.check(f"{op} ACCEPTED", state == "ACCEPTED", state)


def build_chain(sc, pid, run, canon):
    units = {}
    units["05.12"] = plan_api(pid, run, "05.12", canon=canon)
    units["06.12"] = plan_api(pid, run, "06.12", [units["05.12"]], canon)
    units["07.12"] = plan_api(pid, run, "07.12", [units["06.12"]], canon)
    units["08.12"] = plan_api(pid, run, "08.12", [units["07.12"]], canon)
    for op in ("05.12", "06.12", "07.12"):
        drive_chain_unit(sc, pid, units[op], op)
    return units


def seed_station3_deterministic():
    seed_config("STATION", "deterministic-local", 100, station=3)


def register_canon(pid):
    _, a = call(API, "POST", f"/productions/{pid}/artifacts",
                {"artifact_type": "canon_manifest", "content": CANON_TEXT,
                 "storage_uri": "local://canon-fixture"}, expect=201)
    return a["artifact_id"]


# ------------------------------------------- (b) missing usage end-to-end
def scenario_b():
    sc = Scenario("b_missing_usage")
    build_db()
    api = start_api("api_b.log")
    stub = worker = None
    try:
        seed_station3_deterministic()
        seed_config("OPERATION", "openrouter-compatible", 25, op="08.12",
                    model="anthropic/claude-haiku-4.5",
                    cred="OPENROUTER_API_KEY",
                    params={"base_url": f"http://127.0.0.1:{STUB_PORT}"})
        seed_pricing("openrouter-compatible", "anthropic/claude-haiku-4.5",
                     "0.0001", "0.0005", version="mm08-1")
        stub, record = start_stub("nousage", 2000, 1000, tag="b")
        worker = start_worker({"OPENROUTER_API_KEY": "mm08-dummy-key"},
                              "worker_b.log")
        pid, run = make_production("MM-08 missing usage")
        canon = register_canon(pid)
        units = build_chain(sc, pid, run, canon)
        uid = units["08.12"]
        wait_state(uid, {"READY"})
        claim, binding = claim_api(uid)
        sc.check("08.12 claim pins the credentialed OPERATION binding",
                 binding.get("provider") == "openrouter-compatible"
                 and binding.get("credential_ref") == "OPENROUTER_API_KEY",
                 {k: binding.get(k) for k in ("provider", "credential_ref")})
        status, out = work(uid, "08.12", pid, claim, binding, wire_refs(pid))
        sc.check("08.12 /work COMPLETED against the no-usage stub",
                 status == 200 and out.get("status") == "COMPLETED",
                 f"status={status}")
        sc.check("stub received exactly one provider call",
                 len(stub_calls(record)) == 1, stub_calls(record))
        sc.check("/work carries no measured usage (the fixture's point)",
                 not out.get("usage")
                 or all(v is None for v in out["usage"].values()),
                 out.get("usage"))
        complete_api(uid, claim, out)
        ev = db("SELECT charge_class, amount_cents, requires_reconciliation"
                " FROM financial_evidence WHERE attempt_id=%s"
                " ORDER BY created_at", (claim["attempt_id"],))
        sc.check("completion leaves the charge UNRESOLVED, no FINALIZED",
                 [e["charge_class"] for e in ev] == ["ESTIMATED", "UNRESOLVED"]
                 and ev[1]["amount_cents"] == 25
                 and ev[1]["requires_reconciliation"], ev)
        unres_id = db1("SELECT evidence_id FROM financial_evidence"
                       " WHERE attempt_id=%s AND charge_class='UNRESOLVED'",
                       (claim["attempt_id"],))["evidence_id"]
        res = db1("SELECT state FROM budget_reservations"
                  " WHERE reservation_id=%s", (claim["reservation_id"],))
        pos = db1("SELECT COALESCE(SUM(settled_cents),0) AS s"
                  " FROM budget_reservations WHERE production_id=%s"
                  " AND state='SETTLED'", (pid,))
        sc.check("reservation HELD; production settled excludes the charge"
                 " (chain settled 300 only)",
                 res["state"] == "HELD" and pos["s"] == 300,
                 {"reservation": res, "settled": pos})
        audits = db("SELECT count(*) AS n FROM audit_events WHERE unit_id=%s"
                    " AND event_type='charge_unresolved'", (uid,))
        sc.check("charge_unresolved audit present", audits[0]["n"] == 1, audits)
        # reconciler detection surface (Gate F service)
        db("UPDATE financial_evidence SET created_at = now() - interval"
           " '2 hours' WHERE evidence_id=%s", (unres_id,))
        report = ReconcilerService(dsn=DSN).run_once()
        listed = [r for r in report["unresolved_charges"]
                  if r["evidence_id"] == str(unres_id)]
        sc.check("reconciler cycle reports the aged unresolved charge",
                 report["unresolved_charge_count"] >= 1 and len(listed) == 1,
                 {"count": report["unresolved_charge_count"]})
        # operator resolution over HTTP
        status, _ = call(API, "POST",
                         f"/financial-evidence/{unres_id}/resolve",
                         {"usage": {"input_tokens": 2000,
                                    "output_tokens": 1000}},
                         role="WORKER")
        sc.check("WORKER resolution refused 403", status == 403, status)
        status, out = call(API, "POST",
                           f"/financial-evidence/{unres_id}/resolve",
                           {"usage": {"input_tokens": 2000,
                                      "output_tokens": 1000}},
                           expect=200)
        sc.check("operator resolution settles CALCULATED 1c"
                 " (2000x0.0001 + 1000x0.0005 = 0.7 -> 1)",
                 out["amount_cents"] == 1 and out["basis"] == "calculated",
                 out)
        res = db1("SELECT state, settled_cents FROM budget_reservations"
                  " WHERE reservation_id=%s", (claim["reservation_id"],))
        charges = db("SELECT count(*) AS n FROM budget_transactions"
                     " WHERE reservation_id=%s AND kind='CHARGE'",
                     (claim["reservation_id"],))
        held = db1("SELECT COALESCE(SUM(estimated_cents),0) AS h"
                   " FROM budget_reservations WHERE production_id=%s"
                   " AND state='HELD'", (pid,))
        sc.check("reservation SETTLED once at 1c; nothing left held",
                 res["state"] == "SETTLED" and res["settled_cents"] == 1
                 and charges[0]["n"] == 1 and held["h"] == 0,
                 {"reservation": res, "charges": charges, "held": held})
        status, _ = call(API, "POST",
                         f"/financial-evidence/{unres_id}/resolve",
                         {"usage": {"input_tokens": 1}})
        sc.check("duplicate resolution refused 409", status == 409, status)
        return sc.finish()
    finally:
        stop(worker)
        stop(stub)
        stop(api)
        for p in (8730, 8795, STUB_PORT):
            kill_port(p)


# ------------------------------------------------- (f) fallback charges
def scenario_f():
    sc = Scenario("f_fallback_charges")
    build_db()
    api = start_api("api_f.log")
    stub = worker = None
    try:
        seed_station3_deterministic()
        seed_config("OPERATION", "openrouter-compatible", 25, op="08.12",
                    model="anthropic/claude-opus-4.8",
                    cred="OPENROUTER_API_KEY",
                    params={"base_url": f"http://127.0.0.1:{STUB_PORT}"})
        # MM-03 ACTIVE assignment: primary opus, fallback gpt-5.5
        db("INSERT INTO operation_model_assignments(operation_id, role,"
           " primary_model, fallback_model, matrix_version, status)"
           " VALUES ('08.12','PRIMARY','anthropic/claude-opus-4.8',"
           " 'openai/gpt-5.5','mm08-1','ACTIVE')")
        # distinguishable rates: fallback prices 3900/2100 to 8c,
        # primary would price the same usage to 12c
        seed_pricing("openrouter-compatible", "openai/gpt-5.5",
                     "0.0005", "0.0030", version="mm08-1")
        seed_pricing("openrouter-compatible", "anthropic/claude-opus-4.8",
                     "0.0020", "0.0020", version="mm08-1")
        stub, record = start_stub("failmodel", 3900, 2100,
                                  fail_model="anthropic/claude-opus-4.8",
                                  tag="f")
        worker = start_worker({"OPENROUTER_API_KEY": "mm08-dummy-key"},
                              "worker_f.log")
        pid, run = make_production("MM-08 fallback")
        canon = register_canon(pid)
        units = build_chain(sc, pid, run, canon)
        uid = units["08.12"]
        wait_state(uid, {"READY"})
        claim, binding = claim_api(uid)
        status, out = work(uid, "08.12", pid, claim, binding, wire_refs(pid))
        sc.check("08.12 /work COMPLETED via the fallback segment",
                 status == 200 and out.get("status") == "COMPLETED",
                 f"status={status}")
        calls = stub_calls(record)
        by_model = {}
        for c_ in calls:
            by_model[c_["model"]] = by_model.get(c_["model"], 0) + 1
        sc.check("gateway shape: primary retried bounded (3 calls),"
                 " fallback executed once",
                 by_model.get("anthropic/claude-opus-4.8") == 3
                 and by_model.get("openai/gpt-5.5") == 1, by_model)
        sc.check("executed model is the fallback",
                 out.get("model") == "openai/gpt-5.5", out.get("model"))
        complete_api(uid, claim, out)
        ev = db("SELECT charge_class, amount_cents, usage"
                " FROM financial_evidence WHERE attempt_id=%s"
                " ORDER BY created_at", (claim["attempt_id"],))
        fin = [e for e in ev if e["charge_class"] == "FINALIZED"]
        sc.check("one FINALIZED at FALLBACK rates (8c, not primary's 12c),"
                 " carrying only the fallback call's usage",
                 len(fin) == 1 and fin[0]["amount_cents"] == 8
                 and fin[0]["usage"].get("input_tokens") == 3900
                 and fin[0]["usage"].get("output_tokens") == 2100, ev)
        recs = db("SELECT output_summary FROM plan_action_attempts"
                  " WHERE attempt_id=%s AND action_key='op.build'",
                  (claim["attempt_id"],))
        summary = recs[0]["output_summary"] if recs else {}
        lines = (summary or {}).get("usage_lines") or []
        sc.check("failed primary segments recorded as action-record"
                 " evidence (usage lines with error outcomes + the"
                 " fallback event)",
                 any(l.get("outcome") == "error"
                     and l.get("model") == "anthropic/claude-opus-4.8"
                     for l in lines)
                 and (summary or {}).get("fallback_event", {}).get(
                     "fallback_model") == "openai/gpt-5.5",
                 str(summary)[:300])
        charges = db("SELECT count(*) AS n FROM budget_transactions"
                     " WHERE reservation_id=%s AND kind='CHARGE'",
                     (claim["reservation_id"],))
        res = db1("SELECT state, settled_cents FROM budget_reservations"
                  " WHERE reservation_id=%s", (claim["reservation_id"],))
        sc.check("settled exactly once, no double charge",
                 charges[0]["n"] == 1 and res["state"] == "SETTLED"
                 and res["settled_cents"] == 8,
                 {"charges": charges, "reservation": res})
        return sc.finish()
    finally:
        stop(worker)
        stop(stub)
        stop(api)
        for p in (8730, 8795, STUB_PORT):
            kill_port(p)


# ------------------------------------------------------- (c) crash battery
def ledger_invariants(sc, pid, label):
    rows = db(
        "SELECT r.reservation_id, r.state, r.settled_cents,"
        " (SELECT count(*) FROM budget_transactions t"
        "   WHERE t.reservation_id=r.reservation_id AND t.kind='CHARGE')"
        "   AS charges,"
        " (SELECT amount_cents FROM budget_transactions t"
        "   WHERE t.reservation_id=r.reservation_id AND t.kind='CHARGE'"
        "   LIMIT 1) AS charge_amount,"
        " (SELECT count(*) FROM budget_transactions t"
        "   WHERE t.reservation_id=r.reservation_id AND t.kind='RELEASE')"
        "   AS releases"
        " FROM budget_reservations r WHERE r.production_id=%s", (pid,))
    ok = True
    for r in rows:
        if r["charges"] > 1:
            ok = False
        if r["state"] == "SETTLED" and not (
                r["charges"] == 1
                and r["charge_amount"] == r["settled_cents"]):
            ok = False
        if r["state"] == "RELEASED" and not (
                r["releases"] == 1 and r["charges"] == 0):
            ok = False
        if r["state"] == "HELD" and r["charges"] != 0:
            ok = False
    sc.check(f"{label}: per-attempt ledger invariants hold"
             " (settled-once XOR released-once XOR held, never"
             " double-charged)", ok and len(rows) > 0,
             [{"state": r["state"], "charges": r["charges"],
               "releases": r["releases"]} for r in rows])
    return rows


def scenario_c():
    sc = Scenario("c_crash_battery")
    build_db()
    branches = {}
    api = start_api("api_c1.log")
    try:
        # ---- Run 1: kill after reserve, before any completion
        pid, run = make_production("crash 1", hard=100000, soft=90000)
        uid = plan_api(pid, run, "01.01", canon=None)
        _, claim = call(API, "POST", f"/units/{uid}/claim",
                        {"worker_id": "w-c1"}, expect=200)
        api.kill()
        api.wait(timeout=5)
        res = db1("SELECT state FROM budget_reservations"
                  " WHERE reservation_id=%s", (claim["reservation_id"],))
        txns = db("SELECT kind, count(*) AS n FROM budget_transactions"
                  " WHERE reservation_id=%s GROUP BY kind",
                  (claim["reservation_id"],))
        sc.check("run 1: killed after reserve — HELD, RESERVE only,"
                 " nothing charged or vanished",
                 res["state"] == "HELD"
                 and txns == [{"kind": "RESERVE", "n": 1}], txns)
        api = start_api("api_c1_restart.log")
        db("UPDATE worker_leases SET expires_at = now() - interval"
           " '1 minute' WHERE unit_id=%s", (uid,))
        coord = Coordinator(DSN)
        coord.reap_expired_leases()
        state = db1("SELECT state FROM execution_units WHERE unit_id=%s",
                    (uid,))["state"]
        sc.check("run 1: after restart the reaper parks the unit"
                 " RETRY_WAIT", state == "RETRY_WAIT", state)
        call(API, "POST", f"/units/{uid}/retry", {}, expect=200)
        res = db1("SELECT state FROM budget_reservations"
                  " WHERE reservation_id=%s", (claim["reservation_id"],))
        sc.check("run 1: retry releases the reservation exactly once",
                 res["state"] == "RELEASED", res)
        ledger_invariants(sc, pid, "run 1")
        report = ReconcilerService(dsn=DSN).run_once()
        sc.check("run 1: reconciler cycle runs clean after restart",
                 isinstance(report.get("unresolved_charge_count"), int),
                 {"count": report.get("unresolved_charge_count")})
        coord.close()

        # ---- Run 2: kill DURING an in-flight completion (callback)
        seed_config("OPERATION", "cred-provider", 100, op="01.02",
                    model="m1", cred="SOME_KEY")
        seed_pricing("cred-provider", "m1", "1.0", "2.0")
        for attempt_no in range(3):
            coord = Coordinator(DSN)
            pid2 = coord.create_production(f"crash 2-{attempt_no}",
                                           100000, 90000, "mm08-harness")
            run2 = coord.start_run(pid2, "FULL", "mm08-harness")
            uid2 = coord.plan_unit(pid2, run2, "01.02", "main")
            claim2 = coord.claim(uid2, "w-c2", 100)
            coord.event(uid2, "start")
            job = coord.submit_provider_job_v2(
                uid2, claim2["attempt_id"], claim2["fencing_token"],
                f"mm08-crash2-{attempt_no}")
            coord.close()
            holder = {}

            def fire():
                try:
                    holder["result"] = call(
                        API, "POST", f"/provider-jobs/{job}/callback",
                        {"content": "crash-bytes",
                         "usage": {"input_tokens": 40},
                         "provider_request_id": f"req-crash2-{attempt_no}",
                         "model": "m1", "actual_cost_cents": 100},
                        role="CALLBACK")
                except Exception as exc:  # killed mid-flight: expected
                    holder["error"] = f"{type(exc).__name__}: {exc}"
            t = threading.Thread(target=fire)
            t.start()
            time.sleep(0.03 + 0.05 * attempt_no)
            api.kill()
            api.wait(timeout=5)
            t.join(timeout=10)
            api = start_api(f"api_c2_restart{attempt_no}.log")
            res = db1("SELECT state, settled_cents FROM budget_reservations"
                      " WHERE reservation_id=%s", (claim2["reservation_id"],))
            fin = db("SELECT count(*) AS n FROM financial_evidence"
                     " WHERE attempt_id=%s AND charge_class='FINALIZED'",
                     (claim2["attempt_id"],))
            branch = ("settled" if res["state"] == "SETTLED"
                      else "untouched" if res["state"] == "HELD"
                      else res["state"])
            branches[f"run2-{attempt_no}"] = branch
            sc.check(f"run 2.{attempt_no}: completion is atomic under"
                     f" SIGKILL (branch: {branch})",
                     (branch == "settled" and fin[0]["n"] == 1)
                     or (branch == "untouched" and fin[0]["n"] == 0),
                     {"reservation": res, "finalized": fin})
            ledger_invariants(sc, pid2, f"run 2.{attempt_no}")

        # ---- Run 3: kill DURING an in-flight standalone settle
        coord = Coordinator(DSN)
        pid3 = coord.create_production("crash 3", 100000, 90000,
                                       "mm08-harness")
        run3 = coord.start_run(pid3, "FULL", "mm08-harness")
        uid3 = coord.plan_unit(pid3, run3, "01.02", "main")
        claim3 = coord.claim(uid3, "w-c3", 100)
        coord.event(uid3, "start")
        job3 = coord.submit_provider_job_v2(
            uid3, claim3["attempt_id"], claim3["fencing_token"],
            "mm08-crash3")
        coord.handle_callback("mm08-crash3", "media", b"", "local://f", 0,
                              reported_cost_cents=30, status="FAILED")
        ev = db1("SELECT evidence_id FROM financial_evidence"
                 " WHERE attempt_id=%s AND charge_class='PROVIDER_REPORTED'",
                 (claim3["attempt_id"],))
        coord.close()
        holder = {}

        def fire_settle():
            try:
                holder["result"] = call(
                    API, "POST",
                    f"/financial-evidence/{ev['evidence_id']}/settle", {})
            except Exception as exc:  # killed mid-flight: expected
                holder["error"] = f"{type(exc).__name__}: {exc}"
        t = threading.Thread(target=fire_settle)
        t.start()
        time.sleep(0.05)
        api.kill()
        api.wait(timeout=5)
        t.join(timeout=10)
        api = start_api("api_c3_restart.log")
        charges = db("SELECT count(*) AS n FROM budget_transactions"
                     " WHERE production_id=%s AND kind='CHARGE'"
                     " AND reservation_id IS NULL", (pid3,))
        flag = db1("SELECT requires_reconciliation FROM financial_evidence"
                   " WHERE evidence_id=%s", (ev["evidence_id"],))
        fin = db("SELECT count(*) AS n FROM financial_evidence"
                 " WHERE attempt_id=%s AND charge_class='FINALIZED'",
                 (claim3["attempt_id"],))
        branch = "settled" if charges[0]["n"] == 1 else "untouched"
        branches["run3"] = branch
        sc.check(f"run 3: settle is atomic under SIGKILL (branch: {branch})",
                 (branch == "settled" and fin[0]["n"] == 1
                  and flag["requires_reconciliation"] is False)
                 or (branch == "untouched" and fin[0]["n"] == 0
                     and flag["requires_reconciliation"] is True),
                 {"charges": charges, "finalized": fin, "flag": flag})
        if branch == "untouched":
            call(API, "POST",
                 f"/financial-evidence/{ev['evidence_id']}/settle", {},
                 expect=200)
        status, _ = call(API, "POST",
                         f"/financial-evidence/{ev['evidence_id']}/settle",
                         {})
        charges = db("SELECT count(*) AS n FROM budget_transactions"
                     " WHERE production_id=%s AND kind='CHARGE'"
                     " AND reservation_id IS NULL", (pid3,))
        sc.check("run 3: settle completes exactly once overall;"
                 " a further settle is refused",
                 status == 409 and charges[0]["n"] == 1,
                 {"status": status, "charges": charges})
        report = ReconcilerService(dsn=DSN).run_once()
        sc.check("run 3: reconciler cycle runs clean after restart",
                 isinstance(report.get("unresolved_charge_count"), int),
                 {"count": report.get("unresolved_charge_count")})
        return sc.finish({"branches_observed": branches})
    finally:
        stop(api)
        kill_port(8730)


SCENARIOS = {"a": scenario_a, "b": scenario_b, "c": scenario_c,
             "d": scenario_d, "e": scenario_e, "f": scenario_f}

if __name__ == "__main__":
    name = sys.argv[1]
    for p in (8730, 8795, STUB_PORT):
        kill_port(p)
    try:
        sys.exit(SCENARIOS[name]())
    finally:
        for p in (8730, 8795, STUB_PORT):
            kill_port(p)
