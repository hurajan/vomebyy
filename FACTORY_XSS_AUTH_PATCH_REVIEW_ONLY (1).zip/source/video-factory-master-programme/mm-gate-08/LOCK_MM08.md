# LOCK — GATE MM-08: Financial Controls Completion

**Gate:** MM-08 (Multi-Model programme, MULTI_MODEL_EXECUTION_PROMPT.md)
**Builder:** MM-08 builder agent (this session)
**Date:** 2026-10-29
**Status at lock:** LOCKED → IMPLEMENTING

## Starting state (verified from source at lock time, not from summaries)

Existing machinery, re-proved by the regression baseline + targeted
batteries, NOT rebuilt: per-operation reservations; production soft/hard
ceilings with claim-time refusal (`_claim_txn` production-row lock +
`_BudgetBlocked`); model pricing → CALCULATED (migration 012);
FINALIZED selection with basis + tolerance (Gate D `_finalize_amount`);
append-only `budget_transactions` ledger; exactly-once settlement
(`_settle_reservation`, one HELD→SETTLED path shared by sync + async
completion); retry cost accounting per attempt; soft-crossing audit +
outbox notification; failed-job reported charges as PROVIDER_REPORTED
evidence with `requires_reconciliation` + OPERATOR `settle_provider_charge`
(Gate D); duplicate-callback exactly-once (migration 007 claim-first
deliveries).

Two genuine gaps in the MM-08 line, both confirmed absent in source:

1. **No provider-level spend limit exists anywhere** — ceilings are
   per-production and per-assignment (MM-03) only. Nothing aggregates
   spend by the attempt's pinned provider.
2. **Missing usage settles as if measured** — a credentialed-provider
   completion carrying no usage and no provider-reported cost falls
   through `_finalize_amount` to basis `reported_actual` (the caller's
   integer, on the real path the estimate) and settles. There is no
   UNRESOLVED charge state (`financial_evidence.charge_class` CHECK is
   ESTIMATED/CALCULATED/PROVIDER_REPORTED/FINALIZED) and no
   missing-usage detection; the Gate F reconciler reports nothing
   about unresolved charges.

## Scope (exactly the MM-08 brief, nothing more)

1. **Migration 018** (`018_mm08_financial_controls.sql`, additive):
   - `provider_spend_limits` — data-driven per-provider caps
     (provider, environment, window_kind `calendar_day_utc`, cap_cents,
     active; one ACTIVE row per provider+environment). A dedicated
     table, not FACTORY-binding params: caps are per-provider
     operational policy needing their own rows, history, and clean
     aggregation; the FACTORY params blob is a single shared row and
     already carries unrelated keys (finalization tolerance).
   - `financial_evidence.charge_class` CHECK widened with
     `'UNRESOLVED'` via the migration-017 pattern (discover the inline
     CHECK by definition, replace with a named constraint; original
     four values preserved).
   - `video-factory-g2/tools/setup_db.py` gains the 018 apply line
     (the established per-migration pattern).

2. **Provider spend limits (coordinator)**:
   - Window position: SETTLED (settled_cents) + HELD (estimated_cents)
     reservations attributed to the provider of the attempts' pinned
     bindings (`action_attempts.resolved_config->>'provider'`),
     windowed on the reservation's `created_at` within the current
     UTC calendar day; plus standalone provider-charge settlements
     (FINALIZED rows with basis `provider_charge_settled`, which have
     no reservation) windowed on the evidence row's `created_at`.
     Fallback executions attribute to the provider (the executed model
     is recorded in evidence as today; the model is not the provider).
   - Enforcement inside `_claim_txn` after the production budget
     check, before the reservation insert, only when an ACTIVE cap
     row exists for the resolved provider in this environment:
     a transaction advisory lock keyed on the provider serializes
     concurrent claims across productions; window total + estimate
     over the cap raises the internal refusal → `claim()` commits a
     `provider_cap_refused` audit row (gate-refusal pattern: no unit
     state change) and raises `ProviderCapExceeded`;
     `scheduler_claim` skips the candidate like other refusals.
   - No cap row → zero behavior change (every existing suite is the
     proof).

3. **Unresolved charges + missing-usage detection (coordinator)**:
   - Detection (both completion paths — sync `_complete_attempt_txn`
     and async `_complete_provider_job_txn`): the attempt's pinned
     binding carries a `credential_ref` (a credentialed provider) AND
     the completion carries no usage lines (usage dict empty or all
     numeric values zero/absent) AND no provider-reported cost.
     Deterministic-local / mock / unbound bindings are never flagged
     (their reported actual is binding data, not missing usage).
   - On detection: NO `_finalize_amount`, NO settlement. An
     `UNRESOLVED` financial-evidence row is written (amount = the
     reservation's estimate — the amount at risk, explicitly not a
     measured cost; `requires_reconciliation=true`; usage carries
     `_unresolved_reason: 'missing_usage'`), the reservation stays
     HELD, the attempt's `actual_cost_cents` stays NULL, a
     `charge_unresolved` audit row + outbox notification are
     committed, and the content path (artifact, VALIDATING) proceeds
     exactly as a normal completion. Settled totals never include
     the amount (it was never settled).
   - Operator resolution: `Coordinator.resolve_unresolved_charge(
     evidence_id, usage=None, reported_cost_cents=None,
     provider_request_id=None, actor=None)` — refuses with no usage
     and no reported amount (a resolution may not invent a number);
     refuses a non-UNRESOLVED row and an already-resolved row
     (requires_reconciliation cleared) and a non-HELD reservation;
     runs the normal `_finalize_amount` selection with the
     reconciled inputs, checks the production hard ceiling
     (breach → typed refusal, transaction rolls back, charge stays
     unresolved), settles the reservation exactly once, stamps the
     attempt's actual, clears the flag, audits `charge_resolved`,
     runs the soft-ceiling notification.
   - API: `POST /financial-evidence/{evidence_id}/resolve`,
     OPERATOR only (WORKER → 403), contract 1.9.0 → **1.10.0**.
   - Reconciler: `Coordinator.reconcile_once` gains
     `unresolved_threshold_s=3600`; its report
     (`last_reconcile_report`) gains `unresolved_charges` (rows:
     evidence/production/unit/attempt/provider/amount/age) +
     `unresolved_charge_count` for UNRESOLVED rows still requiring
     reconciliation older than the threshold. The Gate F
     `ReconcilerService.run_once` passes both through into its cycle
     output. Detection/reporting only — never auto-resolution.

4. **Tests**:
   - Permanent suites: `video-factory-g2/tests/test_mm08.py`
     (provider cap battery incl. window boundary + absent-cap
     invariance; missing-usage at library level for both completion
     paths; resolution exactly-once + refusals; reconciler report)
     and `video-factory-g3/tests/test_mm08_api.py` (resolve endpoint:
     OPERATOR succeeds, WORKER 403, duplicate resolution 409,
     unknown evidence 404).
   - Gate harness `mm-gate-08/harness/` (results JSON in
     `evidence/results/`): (a) provider-cap battery through the API;
     (b) missing-usage end-to-end — worker service against a stub
     provider whose response carries NO usage field → UNRESOLVED →
     operator resolution via the API → exactly one CHARGE;
     (c) crash battery — API/worker processes SIGKILLed at three
     seams (after reserve; during an in-flight completion; during an
     in-flight standalone settle), restart + reconciler cycle, then
     per-attempt ledger invariants (settled-once XOR released-once
     XOR unresolved-flagged; never double-charged, never vanished);
     (d) concurrency — barrier-synchronized claims racing one
     production hard cap and one provider cap, caps never exceeded
     in settled+held at any sampled read point, exactly one winner
     where the cap admits one; (e) duplicate completion callbacks
     (same completion twice, incl. the MM-04 `model` field) → one
     settlement; (f) MM-05 fallback-charge regression at the
     worker+API level (primary 500s with no usage, fallback
     executes; failed segments recorded as action-record evidence,
     one FINALIZED at fallback rates carrying the fallback usage,
     one CHARGE); (g) full serial regression with port hygiene
     (baseline established pre-change; G9 full run 18 ACCEPTED /
     1620¢, FINALIZED basis `reported_actual` unchanged).

## Out of scope / guardrails

- No changes to FINALIZED selection rules, pricing, the ledger
  schema, transitions, plans, registry definitions, workflows, or
  the dashboard. No new charge classes beyond `UNRESOLVED`. No
  auto-resolution of unresolved charges. No real provider call; no
  credential exists or is requested (MM-12 owns that); every
  provider execution in tests is a local stub, labeled STUB_TESTED.
- Paid calls remain disabled; estimates are never settled as
  measured — that is precisely gap 2's repair.
- Environment: serial batteries only, strict port hygiene (kill
  8730/8795/8796 between suites; assert the API's FACTORY_DSN
  before trusting a run — OBS-1).
