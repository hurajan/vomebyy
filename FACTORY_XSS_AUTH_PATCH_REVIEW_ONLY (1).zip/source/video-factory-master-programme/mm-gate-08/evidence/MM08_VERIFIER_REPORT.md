# GATE MM-08 — INDEPENDENT VERIFIER REPORT

**Verdict: PASS — defects NONE.**
Criterion check: *"concurrent spending, crash recovery, duplicate
callbacks, fallback charges, and hard-limit tests pass"* — every element
is supported by evidence below; the fallback element is supported at
worker-suite level plus the builder's E2E record (see §6, stated
plainly).

**Method.** Everything ran on the verifier's own environment: scratch
DB `mm08_verify_scratch`, API on port 8751 (builder used 8730), worker
on 8797, stub on 8897, own role tokens, own storage root
(`/tmp/mm08v-storage`), own providers/models/prices/figures
throughout. Every terminal state was read by raw SQL, never from a
service response alone. Serial execution only; ports
8730/8795/8796 (+ own ports) killed between parts and between suites,
and every API start was DSN-probed (a marker production created over
HTTP had to be visible in the verifier's SQL view — OBS-1 discipline).
Verifier harness, per-part result JSONs, and logs:
`mm-gate-08/evidence/verify/` (`vrf_part_a.py`, `vrf_part_b.py`,
`vrf_part_c.py`, `vrf_stub.py`, `run_regression.sh`, `part_*.json`,
`logs/`).

## 1. Provider cap — PASS (Part A, 29 checks incl. items below)

Own configuration: provider `vrf-cap-alpha`, **cap 175¢, estimate
100¢** (builder used 150¢).

- First claim admitted (reservation HELD 100); second claim (separate
  production) refused with `ProviderCapExceeded`; the refused unit
  stayed READY.
- The `provider_cap_refused` audit row was read in SQL: exactly one,
  payload `cap_cents=175`, `window_held_cents=100`,
  `window_settled_cents=0`, `estimate_cents=100`.
- Deactivating the cap row (`active=false`) made the identical claim
  succeed immediately.
- **Race:** 12 barrier-synchronized claimants against provider
  `vrf-cap-race`, cap 250¢ / est 100¢ (admits exactly 2). Result:
  exactly **2 admitted, 10 cap-refused, 0 other errors**. A sampler
  thread read the window position in SQL every 2 ms during the race:
  max observed total **200¢ ≤ 250¢** (5 samples landed inside the short
  contention window; the hard evidence is the admission count + SQL
  state). Final SQL: exactly 2 HELD reservations for the provider.
- **Window boundary:** with provider `vrf-cap-boundary` (cap 175), a
  reservation backdated 2 days was excluded from the window (next
  claim admitted), and a third claim against today's held 100¢ was
  refused.

## 2. Missing usage — PASS (Parts A, B, C)

Detection and resolution were exercised at three levels with three
different figure sets.

**Library level (Part A)** — provider `vrf-cred`, est 100¢, pricing
input_token 0.5¢: a credentialed completion with `usage=None` left
financial_evidence exactly `[ESTIMATED 100, UNRESOLVED 100]`,
`requires_reconciliation=true`, `usage._unresolved_reason =
'missing_usage'`; reservation HELD; `budget_position` = 0 settled /
100 held (settled totals exclude the charge); attempt
`actual_cost_cents` NULL; one `charge_unresolved` audit row.

**End-to-end (Part C)** — the verifier's own stub (`vrf_stub.py`,
own script content, ids V1–V3/CV1/PV1) behind the real worker service:
the claim pinned `openrouter-compatible` + `credential_ref
OPENROUTER_API_KEY` + model `vrf/model-x` (est 40¢); the stub omitted
the usage field entirely; `/work` output usage was all-None; the
completion produced `[ESTIMATED 40, UNRESOLVED 40]`, reservation HELD,
production settled = **300¢ (deterministic chain only)**,
`charge_unresolved` audit ×1. OPERATOR resolution with usage
3000 in / 500 out at 0.001¢/0.002¢ per token settled **4¢**
(`basis=calculated`), reservation SETTLED 4¢, exactly 1 CHARGE,
nothing left HELD.

**Counter-case (Parts A + C)** — the same bindings with positive
usage settle normally: `[ESTIMATED, CALCULATED, FINALIZED]`, no
UNRESOLVED (60¢ in Part A; 4¢ in Part C run 2, production settled
304¢).

**Resolution matrix (Part B, over HTTP):**

| Case | Result |
|---|---|
| WORKER role resolves | **403**; charge still unresolved in SQL |
| OPERATOR resolves (120 in-tokens × 0.5¢) | **200**, `amount_cents=60`, `basis=calculated`, response keys exactly `{evidence_id, production_id, amount_cents, basis}` |
| Post-resolution SQL | reservation SETTLED 60, exactly 1 CHARGE, flag cleared |
| Second resolution | **409** (library duplicate also refused, Part A) |
| Unknown evidence id | **404** |
| Empty body `{}` | **409** |
| Resolution pricing to nothing | **TESTED** (not just code-read): API `{"usage":{"requests":5}}` → **409** with the refusal message, charge stays unresolved; library equivalents (no inputs; unpriced usage kind) → `ChargeSettlementError`, reservation stays HELD |

## 3. Crash recovery — PASS (Part B, 19 checks)

- **(a) Kill after claim, before completion:** SIGKILLed the API with
  a HELD reservation outstanding. Post-kill SQL: reservation HELD,
  ledger exactly `[RESERVE ×1]` — nothing charged, nothing vanished.
  After restart + one `ReconcilerService.run_once()` cycle + lease
  expiry/reap, the unit sat in RETRY_WAIT; API retry released the
  reservation exactly once (RELEASED, 1 RELEASE, 0 CHARGE).
- **(b) Kill during in-flight completion callbacks:** three rounds,
  SIGKILL at 20/70/120 ms after firing the callback. **Both atomic
  branches genuinely observed:** round 0 landed *untouched* (client
  saw `RemoteDisconnected`; reservation HELD, 0 FINALIZED, 0 CHARGE),
  rounds 1–2 landed *settled* (SETTLED 60¢, exactly 1 FINALIZED,
  exactly 1 CHARGE). No round produced a torn state.
- **Post-crash DB-wide invariants (SQL, whole scratch DB):** zero
  reservations with >1 CHARGE; every SETTLED reservation has exactly
  one CHARGE whose amount equals `settled_cents`; every RELEASED
  reservation has zero CHARGEs. Per-attempt state is always
  settled-once XOR released-once XOR still-HELD — never
  double-charged, never silently gone.

## 4. Reconciler reporting — PASS (Part A)

Two UNRESOLVED charges were created in one production; one was
backdated 2 hours. Observed vs stated defaults:

- `ReconcilerService` default `unresolved_threshold_s` = **3600**
  (instance attribute), and `Coordinator.reconcile_once`'s signature
  default = **3600** — the code's stated default is real.
- Default-threshold cycle output listed **exactly the aged charge**
  (evidence_id match; amount 100¢; reported age ≥ 3600 s); the fresh
  charge was **not** listed.
- A cycle with `unresolved_threshold_s=0` listed **both** charges.
  Detection/reporting only — no auto-resolution occurred (both charges
  remained UNRESOLVED after the cycles until explicitly resolved in
  other tests).

## 5. Regression spot — PASS (Part D)

Serial, ports killed between suites; counts from the suites' own
summaries (logs in `evidence/verify/logs/regression/`):

| Suite | Expected | Observed |
|---|---|---|
| g2 `test_mm08.py` only | 15 new | **15 OK** |
| g2 full | 96 | **96 OK** |
| g3 full | 41 | **41 OK** |
| worker (`gate-c/worker_service/tests`) | 85 | **85 OK** |
| g9 (after `setup_fullrun.py`) | 10 | **10 OK** |

Persisted G9 DB (`g9_fullrun_scratch`), production "G9 full run",
read by SQL: **18 units ACCEPTED; 18 FINALIZED rows totalling
1620¢, basis `reported_actual`; 0 UNRESOLVED rows** in that
production and 0 in the whole DB — deterministic completions are
unaffected by the missing-usage rule, exactly as the lock requires.

Anchors: migrations on disk max at **018**
(`018_mm08_financial_controls.sql`); a fresh verifier scratch DB
built by `setup_db.py` contains `provider_spend_limits` and the
widened charge_class CHECK including `UNRESOLVED`. Contract file
`video-factory-g3/contracts/api_contract.json` reports
**contract_version 1.10.0 with 47 endpoints**, including
`POST /financial-evidence/{evidence_id}/resolve`.

## 6. Criterion elements covered outside items 1–5

- **Duplicate callbacks** — independently reproduced (Part B): the
  same provider-job callback posted twice (including the MM-04
  `model` field) returned `duplicate=false` then `duplicate=true`
  with identical results; evidence exactly `[ESTIMATED, CALCULATED,
  FINALIZED 60]`; exactly 1 CHARGE.
- **Hard limits** — production hard-cap behavior is exercised by the
  g2 suite (96 OK, incl. the pre-existing budget batteries) and by
  the resolution hard-ceiling rollback test inside `test_mm08.py`
  (15 OK in my run).
- **Fallback charges** — stated precisely: I did **not** re-run a
  bespoke fallback E2E. Fallback pricing is covered by (i) the worker
  suite's gateway fallback tests (`test_gateway.py`, 2 fallback
  tests; `test_worker_service.py`, 1) — all green in my 85/85 worker
  run — and (ii) the builder's scenario-(f) record (FINALIZED 8¢ at
  fallback rates vs 12¢ at primary, failed-primary usage lines as
  action-record evidence, settled exactly once), whose figures are
  internally consistent with the pricing rows it seeded. No
  contradicting evidence found.

## 7. Verifier-side incidents (own harness, no product impact)

- Part C's first runs failed on my own fixture errors, each diagnosed
  and corrected: an invented provider label has no registered adapter
  (`UNKNOWN_PROVIDER` — the adapter name `openrouter-compatible` is a
  product registry key); my stub's scene refs had to match the
  deterministic scene_set's ids (SC1/SC2, B1/B2 — the shaping
  validation correctly refused unknown scenes); and one arithmetic
  mismatch (expected 4¢, system calculated 8¢) traced to **my**
  duplicated active pricing rows from repeated seed runs being summed
  by the calculator — resolved by making the seed delete my prior
  fixture rows; the clean run then produced exactly 4¢. None of these
  touched product code.

## Defects

**NONE.** No product defect was found in any item. Migration 018 is
additive as claimed, the contract is 1.10.0 / 47 endpoints, provider
caps refuse with committed audit and never oversubscribe under
concurrency, missing usage parks as UNRESOLVED with the reservation
held until an OPERATOR reconciles it exactly once, crash recovery is
atomic at both seams tested, and the deterministic baseline
(1620¢ / `reported_actual`) is untouched.
