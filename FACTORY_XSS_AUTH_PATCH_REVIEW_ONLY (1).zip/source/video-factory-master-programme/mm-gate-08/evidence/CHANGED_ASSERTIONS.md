# MM-08 — CHANGED_ASSERTIONS

Every pre-existing assertion/behavior touched by the MM-08 build, with the
reason. Nothing here weakens a prior check; additions are additive.

## Product-code behavior changes (all additive / no-cap-no-effect)

1. **Coordinator.claim** — a new refusal class exists: when an ACTIVE row
   in `provider_spend_limits` covers the claim's pinned provider for the
   coordinator's environment, the claim is refused (`ProviderCapExceeded`)
   if window settled+held + estimate would exceed the cap. With no cap
   row, claim behavior is byte-for-byte the prior path (proven by the
   absent-cap invariance test and the unchanged 291-test baseline).
   `ProviderCapExceeded` was added to `scheduler_claim`'s skip tuple, so
   the scheduler skips capped candidates exactly like budget refusals.

2. **Coordinator completion paths (sync + async)** — a credentialed
   attempt completing with NO usage evidence at all (no usage values, no
   provider-reported cost) no longer finalizes on the estimate: it records
   an UNRESOLVED charge, keeps the reservation HELD, and leaves
   `actual_cost_cents` NULL. Attempts WITH any usage evidence (including
   deterministic-local reported actuals) follow the prior path unchanged —
   the G9 full run still settles 18 units / 1620¢ on basis
   `reported_actual` (regression g9 suite + DB check).
   `handle_callback`'s result dict gains `unresolved_evidence_id` ONLY
   when a charge was recorded unresolved (key absent otherwise — no
   existing consumer sees a shape change on the normal path).

3. **Gate F ReconcilerService.run_once** — the cycle dict gains
   `unresolved_charges` + `unresolved_charge_count` keys (additive;
   existing keys untouched).

4. **API contract 1.9.0 → 1.10.0** — one new endpoint
   `POST /financial-evidence/{evidence_id}/resolve` (OPERATOR only).
   No existing endpoint changed shape.

## Test changes

5. **`video-factory-g3/tests/test_api_contract.py`** (+5 lines): the suite
   asserts EVERY contract endpoint is exercised by the run; the new
   resolve endpoint is exercised with a 409 case (resolve attempted on a
   non-UNRESOLVED evidence row) and registered in the coverage set. No
   existing assertion edited.

6. **In-pass fixes inside the NEW suites/harness only** (no pre-existing
   test touched):
   - `handle_callback` initially dropped `unresolved_evidence_id` in its
     result projection — fixed in the coordinator before the suites ran.
   - Cap tests in `test_mm08.py` polluted each other's provider windows
     through the shared class database → per-test unique provider names.
   - `_provider_window_position` returned Decimal sums that the audit
     serializer stringified — amounts are now cast to int at the source,
     so audit payloads carry exact integers.
   - Harness (b)/(f) initially failed on ref enrichment: the API's
     `FACTORY_STORAGE_ROOT` (/tmp/mm08-storage) was not mirrored into the
     worker service env, so the worker resolved input content from the
     wrong store (the OBS-1 class of trap). Harness-only fix.

## Explicitly NOT changed

- TRANSITIONS (still exactly 30), the migrations 001–017, the registry
  (workflow 1.0.0 / definition_hash ea4503f5…), any station tree, the
  executor generators, pricing math, the FINALIZED selection order, and
  the settlement single-path (`_settle_reservation` is shared by sync
  completion, async completion, and the new resolution path — resolution
  settles through it, never around it).
- STATE.md / MEMORY.md untouched (parent's register).
