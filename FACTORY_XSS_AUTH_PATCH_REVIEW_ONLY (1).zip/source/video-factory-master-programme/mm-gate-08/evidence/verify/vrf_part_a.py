#!/usr/bin/env python3
"""MM-08 INDEPENDENT VERIFIER — Part A (library level).

Own scratch DB (mm08_verify_scratch), own providers/caps/figures —
nothing copied from the builder's batteries except the product's
public fixture mechanics (provider_configs / pricing_rules rows).

Covers brief items 1 (provider cap), 2 (missing usage + resolution,
library level), 4 (reconciler reporting).
"""
import inspect
import json
import re
import sys
import threading
import time
from pathlib import Path

import psycopg
from psycopg.rows import dict_row

HOME = Path.home()
G2 = HOME / "workspace/video-factory-g2"
RP = HOME / "workspace/video-factory-real-ai-programme"
GATE = HOME / "workspace/video-factory-master-programme/mm-gate-08"
sys.path.insert(0, str(G2 / "coordinator"))
sys.path.insert(0, str(RP / "gate-f"))
DB = "mm08_verify_scratch"
_pw = re.search(r"password=([^\s\"]+)",
                (G2 / "tests/test_gatec.py").read_text()).group(1)
DSN = f"host=127.0.0.1 dbname={DB} user=factory password={_pw}"

from coordinator import (  # noqa: E402
    ChargeSettlementError, Coordinator, ProviderCapExceeded)
from mock_provider import MockProvider  # noqa: E402
from runtime_services.reconciler_service import ReconcilerService  # noqa: E402

CHECKS = []


def check(name, ok, detail=""):
    CHECKS.append({"name": name, "pass": bool(ok),
                   "detail": str(detail)[:800]})
    print(("PASS " if ok else "FAIL ") + name +
          (f" :: {str(detail)[:260]}" if detail else ""))


def db(sql, args=()):
    with psycopg.connect(DSN, row_factory=dict_row, autocommit=True) as conn:
        cur = conn.execute(sql, args)
        return cur.fetchall() if cur.description else []


def db1(sql, args=()):
    rows = db(sql, args)
    return rows[0] if rows else None


CB = "mm08-verify"


def add_config(est, provider, op, cred=None, model=None):
    # provider_configs_one_active: one ACTIVE row per operation —
    # supersede the previous fixture config (claims pin at claim time,
    # so earlier reservations keep their attribution)
    db("UPDATE provider_configs SET active=false WHERE scope='OPERATION'"
       " AND operation_id=%s AND environment='test' AND active", (op,))
    return db("INSERT INTO provider_configs(scope, operation_id,"
              " environment, provider, model, est_cost_cents,"
              " credential_ref, created_by) VALUES ('OPERATION',%s,"
              " 'test',%s,%s,%s,%s,%s) RETURNING config_id",
              (op, provider, model, est, cred, CB))[0]["config_id"]


def add_cap(provider, cap_cents):
    return db("INSERT INTO provider_spend_limits(provider, cap_cents,"
              " created_by) VALUES (%s,%s,%s) RETURNING limit_id",
              (provider, cap_cents, CB))[0]["limit_id"]


def add_pricing(provider, model, kind, price, version="vrf-1"):
    db("INSERT INTO pricing_rules(provider, model, unit_kind,"
       " unit_price_cents, pricing_version, created_by) VALUES"
       " (%s,%s,%s,%s,%s,%s)", (provider, model, kind, price, version, CB))


def new_prod(c, hard=100000, soft=90000):
    pid = c.create_production("vrf production", hard, soft, CB)
    return pid, c.start_run(pid, "FULL", CB)


def evidence(attempt_id):
    return db("SELECT * FROM financial_evidence WHERE attempt_id=%s"
              " ORDER BY created_at", (attempt_id,))


def reservation(rid):
    return db1("SELECT * FROM budget_reservations WHERE reservation_id=%s",
               (rid,))


def main():
    # ---- migration 018 objects present in MY scratch DB
    row = db1("SELECT pg_get_constraintdef(oid) AS d FROM pg_constraint"
              " WHERE conrelid='financial_evidence'::regclass"
              " AND pg_get_constraintdef(oid) LIKE %s", ("%FINALIZED%",))
    check("mig018: charge_class CHECK includes UNRESOLVED",
          bool(row) and "UNRESOLVED" in row["d"], row)
    check("mig018: provider_spend_limits table exists",
          db1("SELECT to_regclass('provider_spend_limits') AS t")["t"]
          is not None)

    c = Coordinator(DSN)

    # ================= Item 1: provider cap (cap 175, est 100) =====
    add_config(100, "vrf-cap-alpha", "01.01")
    add_cap("vrf-cap-alpha", 175)
    pid1, run1 = new_prod(c)
    u1 = c.plan_unit(pid1, run1, "01.01", "one")
    cl1 = c.claim(u1, "vrf-w1", 100)
    check("cap175: first claim admitted (HELD 100)",
          reservation(cl1["reservation_id"])["state"] == "HELD"
          and reservation(cl1["reservation_id"])["estimated_cents"] == 100,
          reservation(cl1["reservation_id"]))
    pid2, run2 = new_prod(c)
    u2 = c.plan_unit(pid2, run2, "01.01", "two")
    refused = False
    try:
        c.claim(u2, "vrf-w2", 100)
    except ProviderCapExceeded:
        refused = True
    check("cap175: second claim refused (100 held + 100 est > 175)",
          refused)
    check("cap175: refused unit stays READY (no state change)",
          c.get_unit(u2)["state"] == "READY", c.get_unit(u2)["state"])
    aud = db("SELECT payload FROM audit_events WHERE unit_id=%s"
             " AND event_type='provider_cap_refused'", (u2,))
    check("cap175: provider_cap_refused audit committed in SQL,"
          " payload cap_cents=175 window_held_cents=100",
          len(aud) == 1 and aud[0]["payload"]["cap_cents"] == 175
          and aud[0]["payload"]["window_held_cents"] == 100, aud)
    # deactivate -> claims flow again
    db("UPDATE provider_spend_limits SET active=false"
       " WHERE provider='vrf-cap-alpha'")
    cl2 = c.claim(u2, "vrf-w2", 100)
    check("cap deactivated: the same claim now succeeds",
          reservation(cl2["reservation_id"])["state"] == "HELD")

    # ================= Item 1: race, 6 claimants, cap admits 2 =====
    add_config(100, "vrf-cap-race", "01.01")
    add_cap("vrf-cap-race", 250)
    units = []
    for k in range(12):
        pidk, runk = new_prod(c)
        units.append(c.plan_unit(pidk, runk, "01.01", "main"))
    barrier = threading.Barrier(12)
    results = [None] * 12

    def racer(i, u):
        cc = Coordinator(DSN)
        try:
            barrier.wait(timeout=30)
            results[i] = ("ok", cc.claim(u, f"vrf-racer-{i}", 100))
        except ProviderCapExceeded:
            results[i] = ("cap", None)
        except Exception as exc:  # noqa: BLE001
            results[i] = ("err", f"{type(exc).__name__}: {exc}")
        finally:
            cc.close()

    samples = []
    stop_flag = threading.Event()

    def sampler():
        while not stop_flag.is_set():
            r = db1(
                "SELECT COALESCE(SUM(CASE WHEN r.state='SETTLED'"
                " THEN r.settled_cents WHEN r.state='HELD'"
                " THEN r.estimated_cents ELSE 0 END),0) AS total"
                " FROM budget_reservations r JOIN action_attempts a"
                " ON a.reservation_id=r.reservation_id"
                " WHERE a.resolved_config->>'provider'='vrf-cap-race'"
                " AND r.created_at >= (date_trunc('day',"
                " now() AT TIME ZONE 'UTC') AT TIME ZONE 'UTC')")
            samples.append(int(r["total"]))
            time.sleep(0.002)

    st = threading.Thread(target=sampler)
    st.start()
    threads = [threading.Thread(target=racer, args=(i, u))
               for i, u in enumerate(units)]
    for t in threads:
        t.start()
    for t in threads:
        t.join(timeout=60)
    stop_flag.set()
    st.join(timeout=10)
    oks = [r for r in results if r and r[0] == "ok"]
    caps = [r for r in results if r and r[0] == "cap"]
    errs = [r for r in results if r and r[0] == "err"]
    check("race cap250/est100 x12: exactly 2 admitted, 10 cap-refused,"
          " 0 other errors", len(oks) == 2 and len(caps) == 10
          and len(errs) == 0,
          {"ok": len(oks), "cap": len(caps), "err": errs})
    check("race: sampled window total never above cap 250",
          len(samples) >= 5 and max(samples) <= 250,
          f"samples={len(samples)} max={max(samples) if samples else None}")
    held = db1("SELECT count(*) AS n FROM budget_reservations r"
               " JOIN action_attempts a"
               " ON a.reservation_id=r.reservation_id"
               " WHERE a.resolved_config->>'provider'='vrf-cap-race'"
               " AND r.state='HELD'")
    check("race: exactly 2 HELD reservations for the provider in SQL",
          held["n"] == 2, held)

    # ================= Item 1: window boundary =====================
    add_config(100, "vrf-cap-boundary", "01.01")
    add_cap("vrf-cap-boundary", 175)
    pidb, runb = new_prod(c)
    ub1 = c.plan_unit(pidb, runb, "01.01", "old")
    clb = c.claim(ub1, "vrf-wb", 100)
    db("UPDATE budget_reservations SET created_at="
       " now() - interval '2 days' WHERE reservation_id=%s",
       (clb["reservation_id"],))
    pidb2, runb2 = new_prod(c)
    ub2 = c.plan_unit(pidb2, runb2, "01.01", "new")
    clb2 = c.claim(ub2, "vrf-wb", 100)  # must NOT raise
    check("window: backdated (2d) reservation excluded — claim admitted",
          reservation(clb2["reservation_id"])["state"] == "HELD")
    pidb3, runb3 = new_prod(c)
    ub3 = c.plan_unit(pidb3, runb3, "01.01", "third")
    refused = False
    try:
        c.claim(ub3, "vrf-wb", 100)
    except ProviderCapExceeded:
        refused = True
    check("window: today's held 100 + est 100 > 175 — third claim refused",
          refused)

    # ================= Item 2: missing usage (library) =============
    add_config(100, "vrf-cred", "01.02", cred="VRF_KEY", model="vm1")
    add_pricing("vrf-cred", "vm1", "input_token", "0.5")
    pidm, runm = new_prod(c)
    um = c.plan_unit(pidm, runm, "01.02", "cred")
    clm = c.claim(um, "vrf-wcred", 100)
    c.complete_attempt(um, "vrf-wcred", clm["fencing_token"],
                       "research_brief", b"vrf-content", "local://vrf",
                       100, usage=None, provider_request_id="vrf-req-1")
    ev = evidence(clm["attempt_id"])
    check("nousage: evidence is [ESTIMATED 100, UNRESOLVED 100]",
          [(e["charge_class"], int(e["amount_cents"])) for e in ev]
          == [("ESTIMATED", 100), ("UNRESOLVED", 100)], ev)
    unres = [e for e in ev if e["charge_class"] == "UNRESOLVED"][0]
    check("nousage: UNRESOLVED requires_reconciliation + reason"
          " missing_usage",
          bool(unres["requires_reconciliation"])
          and (unres["usage"] or {}).get("_unresolved_reason")
          == "missing_usage", unres["usage"])
    check("nousage: reservation stays HELD",
          reservation(clm["reservation_id"])["state"] == "HELD")
    pos = c.budget_position(pidm)
    check("nousage: production settled excludes charge (0 settled,"
          " 100 held)", pos["settled_cents"] == 0
          and pos["held_cents"] == 100, pos)
    att = db1("SELECT actual_cost_cents FROM action_attempts"
              " WHERE attempt_id=%s", (clm["attempt_id"],))
    audn = db1("SELECT count(*) AS n FROM audit_events WHERE unit_id=%s"
               " AND event_type='charge_unresolved'", (um,))
    check("nousage: attempt actual_cost_cents NULL + charge_unresolved"
          " audit x1", att["actual_cost_cents"] is None
          and audn["n"] == 1, {"att": att, "audits": audn})

    # resolution refusals: no inputs; inputs that price to nothing
    for label, kwargs in (("no inputs at all", {}),
                          ("usage kind with no pricing rule",
                           {"usage": {"requests": 7}})):
        refused = False
        try:
            c.resolve_unresolved_charge(unres["evidence_id"], **kwargs)
        except ChargeSettlementError:
            refused = True
        check(f"resolve refused (TESTED): {label}", refused)
    check("refusals leave charge unresolved + reservation HELD",
          bool(db1("SELECT requires_reconciliation FROM"
                   " financial_evidence WHERE evidence_id=%s",
                   (unres["evidence_id"],))["requires_reconciliation"])
          and reservation(clm["reservation_id"])["state"] == "HELD")

    # resolution success: 120 input tokens x 0.5c = 60c calculated
    out = c.resolve_unresolved_charge(unres["evidence_id"],
                                      usage={"input_tokens": 120})
    check("resolve: FINALIZED 60c basis=calculated",
          out["amount_cents"] == 60 and out["basis"] == "calculated", out)
    res = reservation(clm["reservation_id"])
    chg = db1("SELECT count(*) AS n FROM budget_transactions"
              " WHERE reservation_id=%s AND kind='CHARGE'",
              (clm["reservation_id"],))
    pos = c.budget_position(pidm)
    check("resolve: reservation SETTLED 60, exactly 1 CHARGE,"
          " held back to 0", res["state"] == "SETTLED"
          and int(res["settled_cents"]) == 60 and chg["n"] == 1
          and pos["held_cents"] == 0 and pos["settled_cents"] == 60,
          {"res": res["state"], "charges": chg, "pos": pos})
    refused = False
    try:
        c.resolve_unresolved_charge(unres["evidence_id"],
                                    usage={"input_tokens": 120})
    except ChargeSettlementError:
        refused = True
    check("resolve: duplicate resolution refused", refused)

    # counter-case: completion WITH positive usage settles normally
    pidu, runu = new_prod(c)
    uu = c.plan_unit(pidu, runu, "01.02", "withusage")
    clu = c.claim(uu, "vrf-wcred", 100)
    c.complete_attempt(uu, "vrf-wcred", clu["fencing_token"],
                       "research_brief", b"vrf-content-2", "local://vrf2",
                       100, usage={"input_tokens": 120})
    evu = evidence(clu["attempt_id"])
    check("counter-case: usage present -> [ESTIMATED, CALCULATED,"
          " FINALIZED 60], no UNRESOLVED",
          [e["charge_class"] for e in evu]
          == ["ESTIMATED", "CALCULATED", "FINALIZED"]
          and int(evu[-1]["amount_cents"]) == 60
          and reservation(clu["reservation_id"])["state"] == "SETTLED",
          [(e["charge_class"], int(e["amount_cents"])) for e in evu])

    # ================= Item 4: reconciler reporting ================
    pidr, runr = new_prod(c)
    pair = []
    for key in ("aged", "fresh"):
        ur = c.plan_unit(pidr, runr, "01.02", key)
        clr = c.claim(ur, "vrf-wcred", 100)
        c.complete_attempt(ur, "vrf-wcred", clr["fencing_token"],
                           "research_brief", b"x", "local://x", 100,
                           usage=None)
        row = [e for e in evidence(clr["attempt_id"])
               if e["charge_class"] == "UNRESOLVED"][0]
        pair.append(str(row["evidence_id"]))
    aged_id, fresh_id = pair
    db("UPDATE financial_evidence SET created_at="
       " now() - interval '2 hours' WHERE evidence_id=%s", (aged_id,))
    svc = ReconcilerService(dsn=DSN)
    check("reconciler: service default threshold is 3600s",
          svc.unresolved_threshold_s == 3600, svc.unresolved_threshold_s)
    sig_default = inspect.signature(
        Coordinator.reconcile_once).parameters[
            "unresolved_threshold_s"].default
    check("reconciler: Coordinator.reconcile_once default is 3600",
          sig_default == 3600, sig_default)
    rep = svc.run_once()
    mine = [r for r in rep["unresolved_charges"]
            if r["production_id"] == str(pidr)]
    check("reconciler: default-threshold cycle names the AGED charge"
          " only (fresh one below threshold not listed)",
          len(mine) == 1 and mine[0]["evidence_id"] == aged_id
          and fresh_id not in [r["evidence_id"]
                               for r in rep["unresolved_charges"]],
          {"count": rep["unresolved_charge_count"],
           "mine": [r["evidence_id"] for r in mine]})
    check("reconciler: aged row carries amount 100 + age >= 3600s",
          mine and int(mine[0]["amount_cents"]) == 100
          and float(mine[0]["age_s"]) >= 3600, mine)
    c2 = Coordinator(DSN)
    c2.reconcile_once(MockProvider(), unresolved_threshold_s=0)
    rep2 = c2.last_reconcile_report
    mine2 = [r for r in rep2["unresolved_charges"]
             if r["production_id"] == str(pidr)]
    check("reconciler: threshold=0 reports both charges",
          len(mine2) == 2, rep2["unresolved_charge_count"])
    c2.close()
    c.close()

    out = {"part": "A", "checks": CHECKS,
           "verdict": "PASS" if all(x["pass"] for x in CHECKS)
           else "FAIL"}
    (GATE / "evidence/verify/part_a.json").write_text(
        json.dumps(out, indent=1))
    print(f"== Part A: {out['verdict']} "
          f"({sum(x['pass'] for x in CHECKS)}/{len(CHECKS)})")
    return 0 if out["verdict"] == "PASS" else 1


if __name__ == "__main__":
    sys.exit(main())
