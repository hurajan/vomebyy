#!/usr/bin/env python3
"""MM-08 INDEPENDENT VERIFIER — Part C (end-to-end through the worker
service against the verifier's OWN stub provider).

Chain 05.12 -> 06.12 -> 07.12 (deterministic) -> 08.12 pinned to a
credential_ref-carrying binding whose base_url is the verifier stub.
Run 1: stub omits usage entirely -> UNRESOLVED end-to-end, then API
resolution. Run 2 (fresh production): stub returns usage -> settles
normally, no UNRESOLVED. Own figures: 08.12 est 40c; pricing
0.001c/input-token + 0.002c/output-token; usage 3000/500 -> 4c.
"""
import json
import os
import re
import subprocess
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path

import psycopg
from psycopg.rows import dict_row

HOME = Path.home()
G2 = HOME / "workspace/video-factory-g2"
G3 = HOME / "workspace/video-factory-g3"
RP = HOME / "workspace/video-factory-real-ai-programme"
GATE = HOME / "workspace/video-factory-master-programme/mm-gate-08"
VDIR = GATE / "evidence/verify"
DB = "mm08_verify_scratch"
_pw = re.search(r"password=([^\s\"]+)",
                (G2 / "tests/test_gatec.py").read_text()).group(1)
DSN = f"host=127.0.0.1 dbname={DB} user=factory password={_pw}"
PY = str(G2 / ".venv/bin/python")
APORT, WPORT, SPORT = 8751, 8797, 8897
API = f"http://127.0.0.1:{APORT}"
WORKER = f"http://127.0.0.1:{WPORT}"
TOKENS = {"FACTORY_API_TOKEN": "vrf-operator-token",
          "FACTORY_WORKER_TOKEN": "vrf-worker-token",
          "FACTORY_SCHEDULER_TOKEN": "vrf-scheduler-token",
          "FACTORY_VALIDATOR_TOKEN": "vrf-validator-token",
          "FACTORY_CALLBACK_TOKEN": "vrf-callback-token"}
DRIVER = "vrf-driver"
CANON_TEXT = json.dumps(
    {"canon": "Verifier fixture canon: the warden keeps the north"
              " gate; a lantern signals from the wall.",
     "characters": ["warden"]})

CHECKS = []


def check(name, ok, detail=""):
    CHECKS.append({"name": name, "pass": bool(ok),
                   "detail": str(detail)[:800]})
    print(("PASS " if ok else "FAIL ") + name +
          (f" :: {str(detail)[:260]}" if detail else ""))


def db(sql, args=()):
    with psycopg.connect(DSN, row_factory=dict_row, autocommit=True) as conn:
        cur = conn.execute(sql, args)
        return cur.fetchall() if cur.description else []


def db1(sql, args=()):
    rows = db(sql, args)
    return rows[0] if rows else None


def call(base, method, path, body=None, role="OPERATOR", expect=None):
    req = urllib.request.Request(base + path, method=method)
    if role == "OPERATOR":
        req.add_header("X-Operator-Token", TOKENS["FACTORY_API_TOKEN"])
    elif role:
        req.add_header("X-Role", role)
        req.add_header("X-Role-Token", TOKENS[f"FACTORY_{role}_TOKEN"])
        req.add_header("X-Identity", role.lower() + "-verify")
    data = None
    if body is not None:
        data = json.dumps(body).encode()
        req.add_header("Content-Type", "application/json")
    try:
        with urllib.request.urlopen(req, data=data, timeout=60) as r:
            out = json.loads(r.read() or b"{}")
            status = r.status
    except urllib.error.HTTPError as e:
        status = e.code
        try:
            out = json.loads(e.read() or b"{}")
        except Exception:
            out = {}
    if expect is not None and status != expect:
        raise AssertionError(f"{method} {path} -> {status}"
                             f" (want {expect}): {out}")
    return status, out


def kill_port(port):
    subprocess.run(["fuser", "-k", f"{port}/tcp"], capture_output=True)
    time.sleep(0.3)


def wait_url(url, seconds=60):
    deadline = time.time() + seconds
    while time.time() < deadline:
        try:
            with urllib.request.urlopen(url, timeout=3) as r:
                if r.status == 200:
                    return True
        except Exception:
            time.sleep(0.3)
    return False


def spawn(cmd, env, log_name, cwd=None):
    fh = open(VDIR / "logs" / log_name, "wb")
    return subprocess.Popen(cmd, env=env, cwd=cwd, stdout=fh,
                            stderr=subprocess.STDOUT)


def stop(proc):
    if proc and proc.poll() is None:
        proc.terminate()
        try:
            proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            proc.kill()


def start_api():
    kill_port(APORT)
    env = dict(os.environ, FACTORY_DSN=DSN, FACTORY_PORT=str(APORT),
               FACTORY_STORAGE_ROOT="/tmp/mm08v-storage", **TOKENS)
    proc = spawn([PY, str(G3 / "api/server.py")], env, "api_c.log")
    if not wait_url(API + "/health"):
        raise RuntimeError("API did not come up")
    _, out = call(API, "POST", "/productions",
                  {"title": "vrf-c-dsn-probe", "hard_ceiling_cents": 1,
                   "soft_ceiling_cents": 1}, expect=201)
    row = db1("SELECT title FROM productions WHERE production_id=%s",
              (out["production_id"],))
    assert row and row["title"] == "vrf-c-dsn-probe", "API/DSN mismatch"
    return proc


def start_stub(mode, tag):
    kill_port(SPORT)
    record = VDIR / "logs" / f"stub_calls_{tag}.jsonl"
    record.unlink(missing_ok=True)
    proc = spawn(["python3", str(VDIR / "vrf_stub.py"), str(record),
                  mode, str(SPORT), "3000", "500"], dict(os.environ),
                 f"stub_{tag}.log")
    if not wait_url(f"http://127.0.0.1:{SPORT}/health"):
        raise RuntimeError("stub did not come up")
    return proc, record


def start_worker():
    kill_port(WPORT)
    env = dict(os.environ, WORKER_SERVICE_PORT=str(WPORT),
               WORKER_ENVIRONMENT="test", WORKER_DSN=DSN,
               FACTORY_API_URL=API,
               FACTORY_WORKER_TOKEN=TOKENS["FACTORY_WORKER_TOKEN"],
               FACTORY_STORAGE_ROOT="/tmp/mm08v-storage",
               WORKER_CREDENTIAL_REFS="OPENROUTER_API_KEY",
               OPENROUTER_API_KEY="vrf-dummy-key")
    proc = spawn([PY, "service.py"], env, "worker_c.log",
                 cwd=str(RP / "gate-c/worker_service"))
    if not wait_url(WORKER + "/health"):
        raise RuntimeError("worker service did not come up")
    return proc


def seed_configs():
    db("UPDATE provider_configs SET active=false"
       " WHERE environment='test' AND active")
    # pricing rows are summed per kind by the calculator: keep exactly
    # one active set of MY fixture rows across harness re-runs
    db("DELETE FROM pricing_rules WHERE created_by='mm08-verify'")
    db("INSERT INTO provider_configs(scope, station, operation_id,"
       " environment, provider, model, est_cost_cents, credential_ref,"
       " params, created_by) VALUES ('STATION',3,NULL,'test',"
       " 'deterministic-local',NULL,100,NULL,'{}','mm08-verify')")
    db("INSERT INTO provider_configs(scope, station, operation_id,"
       " environment, provider, model, est_cost_cents, credential_ref,"
       " params, created_by) VALUES ('OPERATION',NULL,'08.12','test',"
       " 'openrouter-compatible','vrf/model-x',40,'OPENROUTER_API_KEY',%s,"
       " 'mm08-verify')",
       (json.dumps({"base_url": f"http://127.0.0.1:{SPORT}"}),))
    for kind, price in (("input_token", "0.001"),
                        ("output_token", "0.002")):
        db("INSERT INTO pricing_rules(provider, model, unit_kind,"
           " unit_price_cents, pricing_version, created_by) VALUES"
           " ('openrouter-compatible','vrf/model-x',%s,%s,'vrf-1',"
           " 'mm08-verify')", (kind, price))


def make_production(title):
    _, p = call(API, "POST", "/productions",
                {"title": title, "hard_ceiling_cents": 500,
                 "soft_ceiling_cents": 250}, expect=201)
    _, r = call(API, "POST", f"/productions/{p['production_id']}/runs",
                {"kind": "FULL"}, expect=201)
    return p["production_id"], r["run_id"]


def plan_api(pid, run, op, depends=(), canon=None):
    body = {"operation_id": op, "run_id": run, "unit_key": "main",
            "depends_on": list(depends),
            "input_artifact_ids": [canon] if canon else []}
    _, u = call(API, "POST", f"/productions/{pid}/units", body,
                expect=201)
    return u["unit_id"]


def wait_state(uid, states, timeout=120):
    deadline = time.time() + timeout
    while time.time() < deadline:
        row = db1("SELECT state FROM execution_units WHERE unit_id=%s",
                  (uid,))
        if row and row["state"] in states:
            return row["state"]
        time.sleep(0.3)
    raise AssertionError(f"unit {uid} never reached {states}")


def wire_refs(pid):
    return [{"artifact_type": a["artifact_type"],
             "artifact_id": str(a["artifact_id"]),
             "sha256": a["sha256"]}
            for a in db("SELECT artifact_id, artifact_type, sha256"
                        " FROM artifacts WHERE production_id=%s"
                        " AND state='CURRENT'", (pid,))]


def claim_api(uid):
    _, claim = call(API, "POST", f"/units/{uid}/claim",
                    {"worker_id": DRIVER}, expect=200)
    _, attempts = call(API, "GET", f"/units/{uid}/attempts")
    return claim, attempts["attempts"][0]["resolved_config"]


def work(uid, op, pid, claim, binding):
    body = {"provider_binding": binding, "operation_id": op,
            "production_id": pid, "unit_id": uid,
            "attempt_id": claim["attempt_id"],
            "fencing_token": claim["fencing_token"],
            "worker_id": DRIVER, "input_artifact_refs": wire_refs(pid)}
    return call(WORKER, "POST", "/work", body)


def complete_api(uid, claim, out):
    body = {"worker_id": DRIVER,
            "fencing_token": claim["fencing_token"],
            "artifact_type": out["artifact_type"],
            "content": out["content"],
            "actual_cost_cents": out["actual_cost_cents"]}
    for k in ("usage", "provider_request_id", "model"):
        if out.get(k) is not None:
            body[k] = out[k]
    return call(API, "POST", f"/units/{uid}/complete", body, expect=200)


def drive_chain_unit(pid, uid, op, accept=True):
    wait_state(uid, {"READY"})
    claim, binding = claim_api(uid)
    status, out = work(uid, op, pid, claim, binding)
    assert status == 200 and out.get("status") == "COMPLETED", \
        f"{op} /work -> {status}: {str(out)[:300]}"
    complete_api(uid, claim, out)
    if accept:
        call(API, "POST", f"/units/{uid}/validate",
             {"verdict": "PASS"}, expect=200)
        wait_state(uid, {"ACCEPTED"})
    return claim, binding, out


def run_production(title, expect_unresolved):
    pid, run = make_production(title)
    _, a = call(API, "POST", f"/productions/{pid}/artifacts",
                {"artifact_type": "canon_manifest",
                 "content": CANON_TEXT,
                 "storage_uri": "local://vrf-canon"}, expect=201)
    canon = a["artifact_id"]
    units = {}
    units["05.12"] = plan_api(pid, run, "05.12", canon=canon)
    units["06.12"] = plan_api(pid, run, "06.12", [units["05.12"]], canon)
    units["07.12"] = plan_api(pid, run, "07.12", [units["06.12"]], canon)
    units["08.12"] = plan_api(pid, run, "08.12", [units["07.12"]], canon)
    for op in ("05.12", "06.12", "07.12"):
        drive_chain_unit(pid, units[op], op)
    uid = units["08.12"]
    wait_state(uid, {"READY"})
    claim, binding = claim_api(uid)
    check(f"{title}: 08.12 claim pins credentialed binding"
          " (openrouter-compatible / OPENROUTER_API_KEY)",
          binding.get("provider") == "openrouter-compatible"
          and binding.get("credential_ref") == "OPENROUTER_API_KEY",
          {k: binding.get(k) for k in ("provider", "credential_ref")})
    status, out = work(uid, "08.12", pid, claim, binding)
    check(f"{title}: 08.12 /work COMPLETED via the verifier stub",
          status == 200 and out.get("status") == "COMPLETED",
          f"status={status} out={str(out)[:400]}")
    complete_api(uid, claim, out)
    ev = db("SELECT charge_class, amount_cents,"
            " requires_reconciliation FROM financial_evidence"
            " WHERE attempt_id=%s ORDER BY created_at",
            (claim["attempt_id"],))
    res = db1("SELECT state, settled_cents FROM budget_reservations"
              " WHERE reservation_id=%s", (claim["reservation_id"],))
    settled = db1("SELECT COALESCE(SUM(settled_cents),0) AS s"
                  " FROM budget_reservations WHERE production_id=%s"
                  " AND state='SETTLED'", (pid,))["s"]
    return pid, uid, claim, ev, res, int(settled), out


def main():
    api = start_api()
    stub = worker = None
    try:
        seed_configs()
        # ---------- Run 1: stub returns NO usage -------------------
        stub, record = start_stub("nousage", "c1")
        worker = start_worker()
        pid, uid, claim, ev, res, settled, out = run_production(
            "vrf e2e nousage", expect_unresolved=True)
        calls = [json.loads(l) for l in
                 record.read_text().splitlines() if l.strip()]
        check("run1: stub received exactly 1 provider call",
              len(calls) == 1, calls)
        check("run1: /work output carries no usage",
              not out.get("usage")
              or all(v is None for v in out["usage"].values()),
              out.get("usage"))
        check("run1: evidence [ESTIMATED 40, UNRESOLVED 40],"
              " no FINALIZED",
              [(e["charge_class"], int(e["amount_cents"])) for e in ev]
              == [("ESTIMATED", 40), ("UNRESOLVED", 40)]
              and bool(ev[1]["requires_reconciliation"]), ev)
        check("run1: reservation HELD; production settled = 300"
              " (deterministic chain only, charge excluded)",
              res["state"] == "HELD" and settled == 300,
              {"res": res, "settled": settled})
        audn = db1("SELECT count(*) AS n FROM audit_events"
                   " WHERE unit_id=%s AND event_type='charge_unresolved'",
                   (uid,))
        check("run1: charge_unresolved audit x1", audn["n"] == 1, audn)
        unres_id = str(db1(
            "SELECT evidence_id FROM financial_evidence"
            " WHERE attempt_id=%s AND charge_class='UNRESOLVED'",
            (claim["attempt_id"],))["evidence_id"])
        status, rout = call(
            API, "POST", f"/financial-evidence/{unres_id}/resolve",
            {"usage": {"input_tokens": 3000, "output_tokens": 500}},
            expect=200)
        check("run1: OPERATOR resolve -> 4c calculated"
              " (3000x0.001 + 500x0.002)",
              rout["amount_cents"] == 4 and rout["basis"] == "calculated",
              rout)
        res = db1("SELECT state, settled_cents FROM budget_reservations"
                  " WHERE reservation_id=%s", (claim["reservation_id"],))
        chg = db1("SELECT count(*) AS n FROM budget_transactions"
                  " WHERE reservation_id=%s AND kind='CHARGE'",
                  (claim["reservation_id"],))
        held = db1("SELECT COALESCE(SUM(estimated_cents),0) AS h"
                   " FROM budget_reservations WHERE production_id=%s"
                   " AND state='HELD'", (pid,))
        check("run1: reservation SETTLED 4c, exactly 1 CHARGE,"
              " nothing held", res["state"] == "SETTLED"
              and int(res["settled_cents"]) == 4 and chg["n"] == 1
              and int(held["h"]) == 0,
              {"res": res, "charges": chg, "held": held})
        stop(stub)
        stop(worker)
        stub = worker = None

        # ---------- Run 2: stub returns usage ----------------------
        stub, record = start_stub("usage", "c2")
        worker = start_worker()
        pid2, uid2, claim2, ev2, res2, settled2, out2 = run_production(
            "vrf e2e withusage", expect_unresolved=False)
        check("run2: /work output carries positive usage",
              bool(out2.get("usage"))
              and any(isinstance(v, (int, float)) and v > 0
                      for v in out2["usage"].values()),
              out2.get("usage"))
        check("run2: evidence [ESTIMATED, CALCULATED, FINALIZED 4],"
              " NO UNRESOLVED",
              [e["charge_class"] for e in ev2]
              == ["ESTIMATED", "CALCULATED", "FINALIZED"]
              and int(ev2[-1]["amount_cents"]) == 4, ev2)
        check("run2: reservation SETTLED 4c; production settled 304",
              res2["state"] == "SETTLED"
              and int(res2["settled_cents"]) == 4 and settled2 == 304,
              {"res": res2, "settled": settled2})
        return finish()
    finally:
        stop(worker)
        stop(stub)
        stop(api)
        for p in (APORT, WPORT, SPORT):
            kill_port(p)


def finish():
    out = {"part": "C", "checks": CHECKS,
           "verdict": "PASS" if all(x["pass"] for x in CHECKS)
           else "FAIL"}
    (GATE / "evidence/verify/part_c.json").write_text(
        json.dumps(out, indent=1))
    print(f"== Part C: {out['verdict']} "
          f"({sum(x['pass'] for x in CHECKS)}/{len(CHECKS)})")
    return 0 if out["verdict"] == "PASS" else 1


if __name__ == "__main__":
    sys.exit(main())
