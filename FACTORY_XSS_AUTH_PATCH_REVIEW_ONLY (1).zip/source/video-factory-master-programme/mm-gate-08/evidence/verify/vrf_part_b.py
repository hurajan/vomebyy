#!/usr/bin/env python3
"""MM-08 INDEPENDENT VERIFIER — Part B (API level + crash battery).

Own API instance (port 8751), own tokens, own storage root, same
verifier scratch DB as Part A. Covers brief item 2 (resolve endpoint
over HTTP), duplicate callbacks, and item 3 (crash recovery with
SIGKILL: (a) after claim before completion; (b) during in-flight
completion callbacks), finishing with DB-wide ledger invariants.
"""
import json
import os
import re
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.request
from pathlib import Path

import psycopg
from psycopg.rows import dict_row

HOME = Path.home()
G2 = HOME / "workspace/video-factory-g2"
G3 = HOME / "workspace/video-factory-g3"
RP = HOME / "workspace/video-factory-real-ai-programme"
GATE = HOME / "workspace/video-factory-master-programme/mm-gate-08"
VDIR = GATE / "evidence/verify"
sys.path.insert(0, str(G2 / "coordinator"))
sys.path.insert(0, str(RP / "gate-f"))
DB = "mm08_verify_scratch"
_pw = re.search(r"password=([^\s\"]+)",
                (G2 / "tests/test_gatec.py").read_text()).group(1)
DSN = f"host=127.0.0.1 dbname={DB} user=factory password={_pw}"
PY = str(G2 / ".venv/bin/python")
PORT = 8751
API = f"http://127.0.0.1:{PORT}"
TOKENS = {"FACTORY_API_TOKEN": "vrf-operator-token",
          "FACTORY_WORKER_TOKEN": "vrf-worker-token",
          "FACTORY_SCHEDULER_TOKEN": "vrf-scheduler-token",
          "FACTORY_VALIDATOR_TOKEN": "vrf-validator-token",
          "FACTORY_CALLBACK_TOKEN": "vrf-callback-token"}

from coordinator import Coordinator  # noqa: E402
from runtime_services.reconciler_service import ReconcilerService  # noqa: E402

CHECKS = []


def check(name, ok, detail=""):
    CHECKS.append({"name": name, "pass": bool(ok),
                   "detail": str(detail)[:800]})
    print(("PASS " if ok else "FAIL ") + name +
          (f" :: {str(detail)[:260]}" if detail else ""))


def db(sql, args=()):
    with psycopg.connect(DSN, row_factory=dict_row, autocommit=True) as conn:
        cur = conn.execute(sql, args)
        return cur.fetchall() if cur.description else []


def db1(sql, args=()):
    rows = db(sql, args)
    return rows[0] if rows else None


def call(method, path, body=None, role="OPERATOR", expect=None):
    req = urllib.request.Request(API + path, method=method)
    if role == "OPERATOR":
        req.add_header("X-Operator-Token", TOKENS["FACTORY_API_TOKEN"])
    elif role:
        req.add_header("X-Role", role)
        req.add_header("X-Role-Token", TOKENS[f"FACTORY_{role}_TOKEN"])
        req.add_header("X-Identity", role.lower() + "-verify")
    data = None
    if body is not None:
        data = json.dumps(body).encode()
        req.add_header("Content-Type", "application/json")
    try:
        with urllib.request.urlopen(req, data=data, timeout=30) as r:
            out = json.loads(r.read() or b"{}")
            status = r.status
    except urllib.error.HTTPError as e:
        status = e.code
        try:
            out = json.loads(e.read() or b"{}")
        except Exception:
            out = {}
    if expect is not None and status != expect:
        raise AssertionError(f"{method} {path} -> {status}"
                             f" (want {expect}): {out}")
    return status, out


def kill_port(port):
    subprocess.run(["fuser", "-k", f"{port}/tcp"], capture_output=True)
    time.sleep(0.3)


def wait_url(url, seconds=60):
    deadline = time.time() + seconds
    while time.time() < deadline:
        try:
            with urllib.request.urlopen(url, timeout=3) as r:
                if r.status == 200:
                    return True
        except Exception:
            time.sleep(0.3)
    return False


def start_api(log_name):
    kill_port(PORT)
    env = dict(os.environ, FACTORY_DSN=DSN, FACTORY_PORT=str(PORT),
               FACTORY_STORAGE_ROOT="/tmp/mm08v-storage", **TOKENS)
    fh = open(VDIR / "logs" / log_name, "wb")
    proc = subprocess.Popen([PY, str(G3 / "api/server.py")], env=env,
                            stdout=fh, stderr=subprocess.STDOUT)
    if not wait_url(API + "/health"):
        raise RuntimeError("API did not come up")
    _, out = call("POST", "/productions",
                  {"title": "vrf-dsn-probe", "hard_ceiling_cents": 1,
                   "soft_ceiling_cents": 1}, expect=201)
    row = db1("SELECT title FROM productions WHERE production_id=%s",
              (out["production_id"],))
    assert row and row["title"] == "vrf-dsn-probe", "API/DSN mismatch"
    return proc


def stop(proc):
    if proc and proc.poll() is None:
        proc.terminate()
        try:
            proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            proc.kill()


CB = "mm08-verify"


def add_config(est, provider, op, cred=None, model=None):
    db("UPDATE provider_configs SET active=false WHERE scope='OPERATION'"
       " AND operation_id=%s AND environment='test' AND active", (op,))
    db("INSERT INTO provider_configs(scope, operation_id, environment,"
       " provider, model, est_cost_cents, credential_ref, created_by)"
       " VALUES ('OPERATION',%s,'test',%s,%s,%s,%s,%s)",
       (op, provider, model, est, cred, CB))


def add_pricing(provider, model, kind, price, version="vrf-1"):
    db("INSERT INTO pricing_rules(provider, model, unit_kind,"
       " unit_price_cents, pricing_version, created_by) VALUES"
       " (%s,%s,%s,%s,%s,%s)", (provider, model, kind, price, version, CB))


def make_unresolved(c, op="01.02"):
    pid = c.create_production("vrf api", 100000, 90000, CB)
    run = c.start_run(pid, "FULL", CB)
    uid = c.plan_unit(pid, run, op, "main")
    claim = c.claim(uid, "vrf-wapi", 100)
    c.complete_attempt(uid, "vrf-wapi", claim["fencing_token"],
                       "research_brief", b"vrf-api-content", "local://d",
                       100, usage=None)
    row = db1("SELECT evidence_id FROM financial_evidence"
              " WHERE attempt_id=%s AND charge_class='UNRESOLVED'",
              (claim["attempt_id"],))
    return pid, uid, claim, str(row["evidence_id"])


def evidence(attempt_id):
    return db("SELECT * FROM financial_evidence WHERE attempt_id=%s"
              " ORDER BY created_at", (attempt_id,))


def global_invariants(label):
    multi = db("SELECT reservation_id, count(*) AS n"
               " FROM budget_transactions WHERE kind='CHARGE'"
               " GROUP BY reservation_id HAVING count(*) > 1")
    bad_settled = db(
        "SELECT r.reservation_id FROM budget_reservations r"
        " WHERE r.state='SETTLED' AND (SELECT count(*)"
        " FROM budget_transactions t WHERE t.reservation_id="
        " r.reservation_id AND t.kind='CHARGE' AND t.amount_cents="
        " r.settled_cents) != 1")
    bad_released = db(
        "SELECT r.reservation_id FROM budget_reservations r"
        " WHERE r.state='RELEASED' AND EXISTS (SELECT 1"
        " FROM budget_transactions t WHERE t.reservation_id="
        " r.reservation_id AND t.kind='CHARGE')")
    check(f"{label}: DB-wide invariants — no reservation with >1"
          " CHARGE; every SETTLED has exactly 1 CHARGE at settled_cents;"
          " every RELEASED has 0 CHARGE",
          not multi and not bad_settled and not bad_released,
          {"multi": len(multi), "bad_settled": len(bad_settled),
           "bad_released": len(bad_released)})


def main():
    # isolate fixture configs from Part A
    db("UPDATE provider_configs SET active=false WHERE created_by=%s",
       (CB,))
    add_config(100, "vrf-cred-api", "01.02", cred="VRF_KEY", model="vm1")
    add_pricing("vrf-cred-api", "vm1", "input_token", "0.5")

    api = start_api("api_b.log")
    try:
        # ---------- Item 2: resolve endpoint over HTTP -------------
        c = Coordinator(DSN)
        pid, uid, claim, unres_id = make_unresolved(c)
        status, _ = call("POST", f"/financial-evidence/{unres_id}/resolve",
                         {"usage": {"input_tokens": 120}}, role="WORKER")
        check("resolve: WORKER role -> 403", status == 403, status)
        check("resolve: 403 leaves the charge unresolved",
              bool(db1("SELECT requires_reconciliation FROM"
                       " financial_evidence WHERE evidence_id=%s",
                       (unres_id,))["requires_reconciliation"]))
        status, out = call("POST",
                           f"/financial-evidence/{unres_id}/resolve",
                           {"usage": {"input_tokens": 120}}, expect=200)
        check("resolve: OPERATOR 200, amount 60 (120 x 0.5c), basis"
              " calculated, exact contract keys",
              status == 200 and out["amount_cents"] == 60
              and out["basis"] == "calculated"
              and set(out) == {"evidence_id", "production_id",
                               "amount_cents", "basis"}
              and out["evidence_id"] == unres_id, out)
        res = db1("SELECT state, settled_cents FROM budget_reservations"
                  " WHERE reservation_id=%s", (claim["reservation_id"],))
        chg = db1("SELECT count(*) AS n FROM budget_transactions"
                  " WHERE reservation_id=%s AND kind='CHARGE'",
                  (claim["reservation_id"],))
        check("resolve: SQL — reservation SETTLED 60, exactly 1 CHARGE,"
              " flag cleared", res["state"] == "SETTLED"
              and int(res["settled_cents"]) == 60 and chg["n"] == 1
              and not db1("SELECT requires_reconciliation FROM"
                          " financial_evidence WHERE evidence_id=%s",
                          (unres_id,))["requires_reconciliation"],
              {"res": res, "charges": chg})
        status, _ = call("POST", f"/financial-evidence/{unres_id}/resolve",
                         {"usage": {"input_tokens": 120}})
        check("resolve: second resolution -> 409", status == 409, status)
        status, _ = call(
            "POST",
            "/financial-evidence/00000000-0000-0000-0000-000000000000"
            "/resolve", {"reported_cost_cents": 1})
        check("resolve: unknown evidence id -> 404", status == 404,
              status)
        # fresh unresolved row: empty body + price-to-nothing via API
        _, _, claim2, unres2 = make_unresolved(c)
        status, _ = call("POST", f"/financial-evidence/{unres2}/resolve",
                         {})
        check("resolve: empty body -> 409", status == 409, status)
        status, out = call("POST",
                           f"/financial-evidence/{unres2}/resolve",
                           {"usage": {"requests": 5}})
        check("resolve (TESTED via API): usage pricing to nothing"
              " -> 409, charge stays unresolved",
              status == 409
              and bool(db1("SELECT requires_reconciliation FROM"
                           " financial_evidence WHERE evidence_id=%s",
                           (unres2,))["requires_reconciliation"]),
              {"status": status, "out": out})
        c.close()

        # ---------- Duplicate provider-job callbacks ---------------
        c = Coordinator(DSN)
        pid = c.create_production("vrf dup", 100000, 90000, CB)
        run = c.start_run(pid, "FULL", CB)
        uid = c.plan_unit(pid, run, "01.02", "main")
        claim = c.claim(uid, "vrf-wdup", 100)
        c.event(uid, "start")
        status, out = call("POST", "/provider-jobs",
                           {"unit_id": uid,
                            "attempt_id": claim["attempt_id"],
                            "fencing_token": claim["fencing_token"],
                            "idempotency_key": "vrf-dup-1"},
                           role="WORKER", expect=201)
        job_id = out["job_id"]
        body = {"content": "vrf-result-bytes",
                "usage": {"input_tokens": 120},
                "provider_request_id": "vrf-req-dup", "model": "vm1",
                "actual_cost_cents": 100}
        _, o1 = call("POST", f"/provider-jobs/{job_id}/callback", body,
                     role="CALLBACK", expect=200)
        _, o2 = call("POST", f"/provider-jobs/{job_id}/callback", body,
                     role="CALLBACK", expect=200)
        check("dup callbacks: first completes, second flagged duplicate,"
              " identical result", o1["duplicate"] is False
              and o2["duplicate"] is True and o1["result"] == o2["result"],
              {"d1": o1["duplicate"], "d2": o2["duplicate"]})
        ev = evidence(claim["attempt_id"])
        chg = db1("SELECT count(*) AS n FROM budget_transactions"
                  " WHERE reservation_id=%s AND kind='CHARGE'",
                  (claim["reservation_id"],))
        check("dup callbacks: evidence [ESTIMATED, CALCULATED,"
              " FINALIZED 60], exactly 1 CHARGE",
              [e["charge_class"] for e in ev]
              == ["ESTIMATED", "CALCULATED", "FINALIZED"]
              and int(ev[-1]["amount_cents"]) == 60 and chg["n"] == 1,
              [(e["charge_class"], int(e["amount_cents"])) for e in ev])
        c.close()

        # ---------- Crash (a): kill after claim, before completion -
        _, p = call("POST", "/productions",
                    {"title": "vrf crash a", "hard_ceiling_cents": 100000,
                     "soft_ceiling_cents": 90000}, expect=201)
        pid_a = p["production_id"]
        _, r = call("POST", f"/productions/{pid_a}/runs",
                    {"kind": "FULL"}, expect=201)
        add_config(100, "vrf-plain", "01.01")  # non-credentialed
        _, u = call("POST", f"/productions/{pid_a}/units",
                    {"operation_id": "01.01", "run_id": r["run_id"],
                     "unit_key": "main"}, expect=201)
        uid_a = u["unit_id"]
        _, claim_a = call("POST", f"/units/{uid_a}/claim",
                          {"worker_id": "vrf-ca"}, expect=200)
        api.kill()
        api.wait(timeout=5)
        res = db1("SELECT state FROM budget_reservations"
                  " WHERE reservation_id=%s", (claim_a["reservation_id"],))
        txns = db("SELECT kind, count(*) AS n FROM budget_transactions"
                  " WHERE reservation_id=%s GROUP BY kind",
                  (claim_a["reservation_id"],))
        check("crash(a): SIGKILL after claim — reservation HELD,"
              " RESERVE txn only, nothing charged or vanished",
              res["state"] == "HELD"
              and txns == [{"kind": "RESERVE", "n": 1}],
              {"res": res, "txns": txns})
        api = start_api("api_b_restart_a.log")
        db("UPDATE worker_leases SET expires_at = now() - interval"
           " '1 minute' WHERE unit_id=%s", (uid_a,))
        report = ReconcilerService(dsn=DSN).run_once()
        check("crash(a): reconciler cycle runs after restart",
              isinstance(report.get("unresolved_charge_count"), int),
              {"count": report.get("unresolved_charge_count")})
        c = Coordinator(DSN)
        c.reap_expired_leases()
        c.close()
        state = db1("SELECT state FROM execution_units WHERE unit_id=%s",
                    (uid_a,))["state"]
        check("crash(a): expired lease reaped -> RETRY_WAIT",
              state == "RETRY_WAIT", state)
        call("POST", f"/units/{uid_a}/retry", {}, expect=200)
        res = db1("SELECT state FROM budget_reservations"
                  " WHERE reservation_id=%s", (claim_a["reservation_id"],))
        rel = db1("SELECT count(*) AS n FROM budget_transactions"
                  " WHERE reservation_id=%s AND kind='RELEASE'",
                  (claim_a["reservation_id"],))
        chg = db1("SELECT count(*) AS n FROM budget_transactions"
                  " WHERE reservation_id=%s AND kind='CHARGE'",
                  (claim_a["reservation_id"],))
        check("crash(a): retry releases exactly once (RELEASED,"
              " 1 RELEASE, 0 CHARGE)", res["state"] == "RELEASED"
              and rel["n"] == 1 and chg["n"] == 0,
              {"res": res, "rel": rel, "chg": chg})

        # ---------- Crash (b): kill during in-flight callbacks -----
        branches = {}
        for i, delay in enumerate((0.02, 0.07, 0.12)):
            c = Coordinator(DSN)
            pid_i = c.create_production(f"vrf crash b{i}", 100000,
                                        90000, CB)
            run_i = c.start_run(pid_i, "FULL", CB)
            uid_i = c.plan_unit(pid_i, run_i, "01.02", "main")
            claim_i = c.claim(uid_i, "vrf-cb", 100)
            c.event(uid_i, "start")
            job_i = c.submit_provider_job_v2(
                uid_i, claim_i["attempt_id"], claim_i["fencing_token"],
                f"vrf-crash-b-{i}")
            c.close()
            holder = {}

            def fire(job=job_i, i=i):
                try:
                    holder["result"] = call(
                        "POST", f"/provider-jobs/{job}/callback",
                        {"content": "vrf-crash-bytes",
                         "usage": {"input_tokens": 120},
                         "provider_request_id": f"vrf-req-cb-{i}",
                         "model": "vm1", "actual_cost_cents": 100},
                        role="CALLBACK")
                except Exception as exc:  # killed mid-flight: expected
                    holder["error"] = f"{type(exc).__name__}: {exc}"
            t = threading.Thread(target=fire)
            t.start()
            time.sleep(delay)
            api.kill()
            api.wait(timeout=5)
            t.join(timeout=10)
            api = start_api(f"api_b_restart_b{i}.log")
            res = db1("SELECT state, settled_cents FROM"
                      " budget_reservations WHERE reservation_id=%s",
                      (claim_i["reservation_id"],))
            fin = db1("SELECT count(*) AS n FROM financial_evidence"
                      " WHERE attempt_id=%s AND charge_class='FINALIZED'",
                      (claim_i["attempt_id"],))["n"]
            chg = db1("SELECT count(*) AS n FROM budget_transactions"
                      " WHERE reservation_id=%s AND kind='CHARGE'",
                      (claim_i["reservation_id"],))["n"]
            branch = ("settled" if res["state"] == "SETTLED"
                      else "untouched" if res["state"] == "HELD"
                      else res["state"])
            branches[f"b{i}"] = branch
            check(f"crash(b{i}): completion atomic under SIGKILL"
                  f" (branch: {branch})",
                  (branch == "settled" and fin == 1 and chg == 1
                   and int(res["settled_cents"]) == 60)
                  or (branch == "untouched" and fin == 0 and chg == 0),
                  {"res": res, "finalized": fin, "charges": chg,
                   "client": holder.get("error", "completed")})
        report = ReconcilerService(dsn=DSN).run_once()
        check("crash(b): reconciler cycle clean after restarts",
              isinstance(report.get("unresolved_charge_count"), int),
              {"count": report.get("unresolved_charge_count"),
               "branches": branches})
        global_invariants("post-crash")
        return finish()
    finally:
        stop(api)
        kill_port(PORT)


def finish():
    out = {"part": "B", "checks": CHECKS,
           "verdict": "PASS" if all(x["pass"] for x in CHECKS)
           else "FAIL"}
    (GATE / "evidence/verify/part_b.json").write_text(
        json.dumps(out, indent=1))
    print(f"== Part B: {out['verdict']} "
          f"({sum(x['pass'] for x in CHECKS)}/{len(CHECKS)})")
    return 0 if out["verdict"] == "PASS" else 1


if __name__ == "__main__":
    sys.exit(main())
