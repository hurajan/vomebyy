#!/usr/bin/env python3
"""Verifier's own OpenRouter-compatible stub (STUB_TESTED only).

Usage: vrf_stub.py <record.jsonl> <nousage|usage> <port> <in> <out>
nousage: completions carry content and NO usage field at all.
usage:   completions carry a usage object with the given token counts.
Content is the verifier's own script-shaped JSON (ids V*/SV*/BV*).
"""
import json
import sys
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

RECORD = sys.argv[1]
MODE = sys.argv[2]
PORT = int(sys.argv[3])
IN_TOKENS = int(sys.argv[4])
OUT_TOKENS = int(sys.argv[5])

SCRIPT = {
    "kind": "script",
    "lines": [
        {"id": "V1", "scene_ref": "SC1", "beat_ref": "B1",
         "story_ref": "S1", "canon_refs": [],
         "text": "Verifier line one: the warden locks the north gate."},
        {"id": "V2", "scene_ref": "SC2", "beat_ref": "B2",
         "story_ref": "S2", "canon_refs": [],
         "text": "Verifier line two: a lantern moves along the wall."},
        {"id": "V3", "scene_ref": "SC2", "beat_ref": "B2",
         "story_ref": "S2", "canon_refs": [],
         "text": "Verifier line three: the gate opens from inside."},
    ],
    "trace": {
        "clues": [{"id": "CV1", "planted": "V1", "payoff": "V3"}],
        "knowledge": [{"character": "warden", "learns": "CV1",
                       "at": "V2"}],
        "payoffs": [{"id": "PV1", "clue": "CV1", "line": "V3"}],
    },
    "canon_refs": [],
}


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def _send(self, code, obj):
        body = json.dumps(obj).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_POST(self):
        length = int(self.headers.get("Content-Length") or 0)
        raw = self.rfile.read(length) if length else b"{}"
        try:
            req = json.loads(raw or b"{}")
        except json.JSONDecodeError:
            req = {}
        with open(RECORD, "a") as fh:
            fh.write(json.dumps({"model": req.get("model"),
                                 "path": self.path}) + "\n")
        resp = {
            "id": "chatcmpl-vrf-1",
            "object": "chat.completion",
            "model": req.get("model"),
            "choices": [{"index": 0,
                         "message": {"role": "assistant",
                                     "content": json.dumps(SCRIPT)},
                         "finish_reason": "stop"}],
        }
        if MODE == "usage":
            resp["usage"] = {"prompt_tokens": IN_TOKENS,
                             "completion_tokens": OUT_TOKENS,
                             "total_tokens": IN_TOKENS + OUT_TOKENS}
        return self._send(200, resp)

    def do_GET(self):
        if self.path == "/health":
            return self._send(200, {"status": "ok"})
        return self._send(404, {"error": "not found"})


if __name__ == "__main__":
    ThreadingHTTPServer(("127.0.0.1", PORT), Handler).serve_forever()
