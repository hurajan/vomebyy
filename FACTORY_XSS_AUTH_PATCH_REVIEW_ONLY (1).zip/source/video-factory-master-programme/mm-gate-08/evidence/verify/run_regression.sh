#!/usr/bin/env bash
# MM-08 verifier regression spot-checks — SERIALLY, port hygiene
# (kill 8730/8795/8796 + own ports) between every suite.
set -u
W="$HOME/workspace"
VDIR="$W/video-factory-master-programme/mm-gate-08/evidence/verify"
LOGS="$VDIR/logs/regression"
mkdir -p "$LOGS"
PY="$W/video-factory-g2/.venv/bin/python"
RP="$W/video-factory-real-ai-programme"
SUMMARY="$LOGS/SUMMARY.txt"
: > "$SUMMARY"

killports() { for p in 8730 8795 8796 8751 8797 8897; do fuser -k ${p}/tcp 2>/dev/null; done; sleep 1; }

run_suite() {
  local name="$1"; shift
  killports
  echo "=== $name : $*" | tee -a "$SUMMARY"
  "$@" > "$LOGS/$name.log" 2>&1
  local rc=$?
  local line verdict
  line=$(grep -E "^Ran [0-9]+ tests" "$LOGS/$name.log" | tail -1)
  verdict=$(grep -E "^(OK|FAILED)" "$LOGS/$name.log" | tail -1)
  echo "$name rc=$rc $line $verdict" | tee -a "$SUMMARY"
}

run_suite g2_mm08 bash -c "cd '$W/video-factory-g2' && '$PY' -m unittest discover -s tests -p 'test_mm08.py'"
run_suite g2 bash -c "cd '$W/video-factory-g2' && '$PY' -m unittest discover -s tests"
run_suite g3 bash -c "cd '$W/video-factory-g3' && '$PY' -m unittest discover -s tests"
run_suite worker bash -c "cd '$RP/gate-c' && '$PY' -m unittest discover -s worker_service/tests"
run_suite g9 bash -c "python3 '$W/video-factory-g9/tools/setup_fullrun.py' && cd '$W/video-factory-g9' && '$PY' -m unittest discover -s tests"
killports
echo "REGRESSION SPOT DONE" | tee -a "$SUMMARY"
