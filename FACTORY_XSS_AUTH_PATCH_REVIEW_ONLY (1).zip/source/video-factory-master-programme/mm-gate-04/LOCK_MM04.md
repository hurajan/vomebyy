# LOCK — GATE MM-04: Provider Gateway

**Gate:** MM-04 (Multi-Model programme, MULTI_MODEL_EXECUTION_PROMPT.md)
**Builder:** MM-04 builder agent (this session)
**Date:** 2026-10-29
**Status at lock:** LOCKED → IMPLEMENTING

## Scope (exactly the MM-04 brief, nothing more)

Complete the provider gateway behind the existing Coordinator-authorized
execution path. The gateway is a **new module inside the existing worker
service** (`gateway.py`) wrapping adapter execution — no new service, no
new orchestrator, no Coordinator bypass. All provider contact in this
gate is against LOCAL STUBS (STUB_TESTED evidence only); no credential
exists and none is requested (MM-12 owns that).

### Existing machinery (read, not rebuilt)
Adapters incl. OpenRouter-compatible; claim-bound provider_jobs;
per-attempt config/plan pinning (incl. the MM-03 `model_assignment`
snapshot pin); pricing lookup → CALCULATED/FINALIZED
(`_finalize_amount`); typed BlockedError/ProviderError failures;
credential_ref secret isolation; Gate F coordinator-level retry driver
(cross-attempt — distinct from this gate's in-attempt gateway retries).

### Deliverables
1. **Context-limit check** (gateway): before any provider call, estimate
   the assembled prompt at chars/4 (recorded as an estimate) and compare
   against the pinned model's `context_length` in the MM-03 `models`
   table, read via the worker's existing DB access (WORKER_DSN — the
   same arming condition as plan-pin verification). Over-limit → typed
   `CONTEXT_LIMIT` refusal before any HTTP call. Registry armed but
   model absent (or `context_length` NULL) → typed `MODEL_UNKNOWN`
   refusal — a limit is never guessed.
   **Arming rule (recorded interpretation):** the check arms only when
   the worker has DB access AND the MM-03 registry is seeded in that
   database (models table non-empty). An unseeded registry is the
   "feature not engaged" state — identical in shape to plan-pin being
   unarmed without WORKER_DSN — so every pre-MM-04 database (incl. the
   Lean Phase 3 slice DB, whose worker runs with WORKER_DSN against an
   unseeded registry) behaves exactly as before. Where the registry IS
   seeded, an unknown model refuses.
2. **Bounded gateway retries**: retryable classes (HTTP 429, HTTP 5xx,
   connection/unreachable incl. timeouts) retry within the attempt —
   max 2 retries, backoff `min(base_s × 2^(k−1), max_s)` from the
   binding's `retry_policy` (top-level snapshot field, then
   `params.retry_policy`; gateway-local defaults base 1.0s / max 30s
   when the binding names none — distinct from Gate F's cross-attempt
   30/900 driver defaults). Non-retryable (other 4xx, bad-response,
   config) → immediate typed failure. The binding `timeout_s` budget
   (min with the request deadline) covers ALL tries: each call's
   deadline is the remaining budget, and no retry starts past it.
   Usage reported on an error response is captured (ProviderError gains
   the parsed error body) and recorded as its own usage-evidence line;
   the completion usage is the SUM over all lines.
3. **Authorized fallback**: only when the attempt's pinned MM-03
   assignment (`model_assignment` in the binding snapshot) names a
   `fallback_model`, and only when the primary segment fails with a
   provider-side class (429/5xx/connection/timeout) after its retries —
   never for context refusals, other 4xx, or bad responses. The
   fallback segment executes **once** (one call, no retries) with
   identical task/params under the fallback model. A fallback event
   {primary_model, fallback_model, trigger_class, correlation_id} is
   recorded in the action record + the completion evidence; the
   completion's model is the fallback model and pricing lookup prices
   at the fallback model's rows. No ACTIVE assignment / no fallback
   named → the primary failure stands; the gateway never swaps models
   silently (negative-tested).
4. **Correlation IDs**: one uuid per call-chain, generated at the first
   call, sent as the `X-Correlation-Id` request header on every call,
   recorded in the action record (provider evidence), in all
   usage-evidence lines (retries + fallback share the chain id; each
   call also carries its own call index), and in the provider job on
   the async path (worker job context + poll/result payloads; the
   coordinator callback merges it into the job's `raw_response`).
5. **Rate/concurrency controls**: per-provider in-service limiter
   around adapter execution — `max_concurrency` (binding params, else
   the binding's `concurrency_limit` column, else default 4) and
   `min_interval_ms` (binding params, else 0). Limiter parameters are
   taken from the first binding seen per provider per process
   (documented; a service restart picks up new values). Observable via
   the stub's max simultaneous in-flight count.
6. **Cancellation**: coordinator provider-job cancellation for the
   ASYNC path — `Coordinator.cancel_provider_job` + API
   `POST /provider-jobs/{job_id}/cancel` (contract **1.9.0**),
   OPERATOR/WORKER with the /complete identity discipline (WORKER must
   present the attempt's claim identity + current fencing; mismatch →
   committed `provider_job_cancel_refused` audit + typed `CancelRefused`
   → 403). Effects: job → `CANCELLED` (migration **017** widens the
   status CHECK additively), attempt → FAILED with error_class
   `CANCELLED`, unit leaves AWAITING_PROVIDER/UNKNOWN/RUNNING via the
   same transitions the provider-failure path uses (reservations are
   released only by the retry path — never silently); an optional
   reported charge becomes PROVIDER_REPORTED reconciliation evidence,
   mirroring the failure path. Repeat cancel of a CANCELLED job is
   idempotent; cancel of a COMPLETED/FAILED job refuses (409). The
   gateway checks cancellation (via the coordinator's unit
   provider-jobs read, when the API is configured) before each retry
   and before the fallback step — a cancelled chain stops with typed
   error_class `CANCELLED`. SYNC-path cancellation stays the existing
   unit `cancel` event; the gateway deadline bounds the in-flight
   chain — documented mapping, no second mechanism.
7. **Provider health writes**: each gateway chain outcome (success →
   `ok`, provider failure → `error`, refusal → `refused`) inserts one
   `provider_health` row (provider, status, timestamp, short detail —
   model + error class + call count; never secrets, never prompt
   content) via the worker's DB access when configured. Best-effort
   telemetry: a health-write failure never fails the execution.
8. **No-bypass test surface**: explicit tests that /work refuses
   without a valid claim context (missing binding/ids → 400; a bogus
   attempt under the production API-sink wiring aborts with
   ACTION_RECORD_FAILED and produces nothing) and that the service's
   route table exposes no other adapter entry point (unknown routes →
   404).

### Minimal coordinator surface beyond the gateway (recorded)
Item 3 is impossible without the coordinator learning the executed
model: `complete_attempt` prices from the attempt snapshot's model
today. MM-04 therefore adds ONE optional additive parameter —
`complete_attempt(..., model=None)` (API /complete body field `model?`,
contract-noted) — effective pricing model = the presented executed
model when given, else the snapshot model (every existing caller
byte-identical). `handle_callback` gains the same optional model +
the correlation_id passthrough of item 4. No other coordinator
behavior changes.

### Write ownership (claimed here + in gate-00/OWNERSHIP.md before edits)
- `video-factory-real-ai-programme/gate-c/worker_service/gateway.py` (new)
- `video-factory-real-ai-programme/gate-c/worker_service/adapters.py` — `_http_json` headers + error-body capture; adapters forward `_gateway_headers`
- `video-factory-real-ai-programme/gate-c/worker_service/service.py` — gateway wiring (direct + submit/poll paths, per-request gateway context, result payload passthrough)
- `video-factory-real-ai-programme/gate-c/worker_service/actions.py` — `op.generate_script` routes its provider call through the gateway; provider evidence extended
- `video-factory-real-ai-programme/gate-c/worker_service/plan_exec.py` — ActionContext gateway pass-through; provider evidence (incl. FAILED-record gateway summary) extension
- `video-factory-real-ai-programme/gate-c/worker_service/tests/test_gateway.py` (new)
- `video-factory-g2/coordinator/coordinator.py` — MM-04 surface only: `CancelRefused`, `cancel_provider_job`, executed-model + correlation threading in complete/callback paths
- `video-factory-g2/database/migrations/017_mm04_provider_job_cancel.sql` (new, additive) — **migration 017 claimed by MM-04**
- `video-factory-g2/tools/setup_db.py` — one added apply line for 017
- `video-factory-g3/api/server.py` — MM-04 routes only (job cancel; callback/complete optional fields)
- `video-factory-g3/contracts/api_contract.json` — version 1.9.0, +1 endpoint, +2 optional fields
- `video-factory-g3/tests/test_api_contract.py` — exercise the cancel endpoint (contract coverage; recorded in CHANGED_ASSERTIONS.md)
- `video-factory-master-programme/mm-gate-04/**` — lock, battery, evidence

### Out of scope / guardrails
No registry-definition, plan, workflow, evaluation/runtime-service, or
dashboard changes. Deterministic + mock adapters are NOT gateway-wrapped
(they execute plans locally; the Phase 3 slice path is unchanged when
gateway features are not engaged). No real provider call; no credential
exists or is requested. Additive migrations only; migration history is
never edited.

## Tests (mm-gate-04/evidence/results/, serial; all STUB_TESTED)
(a) Phase 3 slice battery re-run (run-a no-credential + run-b stub
mechanics still green) · (b) context-limit refusal before HTTP ·
(c) bounded retries (500,500→200; 400 immediate) · (d) authorized
fallback priced at fallback rates · (e) no-fallback negative ·
(f) context refusal does not trigger fallback · (g) concurrency cap
observed at the stub · (h) async-job cancellation stops a queued retry ·
(i) provider_health rows after success + failure · (j) full serial
regression (baseline 225 + MM-04 additions; G9 full run 18/1620).
