#!/usr/bin/env python3
"""MM-04 full-stack battery (STUB_TESTED throughout).

Scenarios (each writes evidence/results/<name>.json):
  d_fallback_pricing  08.12 through the real stack: ACTIVE assignment
                      names acme/fallback; the stub 500s the primary
                      (usage on every error) and answers the fallback.
                      Asserts: stub counts (primary 3 = 1+2 retries,
                      fallback 1), the generation action record
                      (executed model, fallback event, correlation id,
                      4 usage lines, summed usage 1030/515), and the
                      completion priced at the FALLBACK model's rates
                      (CALCULATED 2c at 0.001/0.002 per token) not the
                      primary's (would be 21c at 0.01/0.02).
  c_failure_battery   run-c semantics with a test-scaled retry policy:
                      stub 500s everything -> /work 502 typed, FAILED
                      generation record with 3 usage lines, zero
                      artifacts, zero settlement, RETRY_WAIT recovery.
  b_context_limit     08.12 binding re-seeded to a tiny-context model
                      (context_length 10): /work fails CONTEXT_LIMIT,
                      the stub sees ZERO calls, the FAILED record
                      carries the refusal line + estimate.
  h_cancellation      async path: coordinator job registered for a
                      direct-http-text unit; the worker's submit chain
                      is in flight against a slow-failing stub submit;
                      OPERATOR cancel lands -> job CANCELLED, attempt
                      FAILED/error_class CANCELLED, unit RETRY_WAIT,
                      the worker chain stops (502 CANCELLED) and the
                      queued retry never fires (stub count frozen).
  i_health            provider_health rows accumulated across the
                      battery: ok + error + refused outcomes present,
                      details free of credential/prompt content.

Ports are battery-local (API 8830, worker 8895, evaluation 8896);
the stub is in-process on an ephemeral port. Scratch DB:
mm04_gateway_scratch (G3 setup chain: migrations through 017 +
MM-03 registry tables). Run serially with the factory venv python.
"""
import json
import os
import re
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

import psycopg
from psycopg.rows import dict_row

MM04 = Path(__file__).resolve().parent.parent
LOGS = MM04 / "evidence" / "logs"
RESULTS = MM04 / "evidence" / "results"
HOME = Path.home()
G2 = HOME / "workspace/video-factory-g2"
G3 = HOME / "workspace/video-factory-g3"
PROG = HOME / "workspace/video-factory-real-ai-programme"
VENV_PY = str(G2 / ".venv/bin/python")

DB = "mm04_gateway_scratch"


def _fixture_password():
    src = (G2 / "tools/setup_db.py").read_text()
    return re.search(r"CREATE ROLE factory LOGIN PASSWORD '([^']+)'",
                     src).group(1)


DSN = ("host=127.0.0.1 dbname=" + DB + " user=factory password="
       + _fixture_password())
API = "http://127.0.0.1:8830"
WORKER = "http://127.0.0.1:8895"
EVAL = "http://127.0.0.1:8896"
TOKENS = {"FACTORY_API_TOKEN": "mm04-operator-token",
          "FACTORY_WORKER_TOKEN": "mm04-worker-token",
          "FACTORY_SCHEDULER_TOKEN": "mm04-scheduler-token",
          "FACTORY_VALIDATOR_TOKEN": "mm04-validator-token",
          "FACTORY_CALLBACK_TOKEN": "mm04-callback-token"}
OPERATOR = TOKENS["FACTORY_API_TOKEN"]
DRIVER = "mm04-driver"
CANON_TEXT = ("CANON MANIFEST v1 — universe, chronology, world rules, "
              "knowledge boundaries released.")
PRIMARY, FALLBACK, TINY = "acme/primary", "acme/fallback", "acme/tiny"
PRICING_VERSION = "mm04-battery"
# fallback: 1030 in x 0.001 + 515 out x 0.002 = 2.06 -> HALF_UP 2
EXPECTED_CALCULATED_FALLBACK = 2
# primary counterfactual: 1030 x 0.01 + 515 x 0.02 = 20.6 -> 21
PRIMARY_RATE_CALCULATED = 21


# ------------------------------------------------------------------ stub
class Stub:
    """In-process provider stub: /chat/completions (OpenAI-shaped) and
    /submit + /poll/{id} (direct-http async). Behavior is steered by
    self.mode ('fallback', 'fail_all') and per-model rules; every call
    is counted and timestamped."""

    def __init__(self):
        self.mode = "fallback"
        self.chat = []       # (model, at)
        self.submits = []    # at
        self.lock = threading.Lock()
        stub = self

        class H(BaseHTTPRequestHandler):
            def log_message(self, *a):
                pass

            def _send(self, status, obj):
                raw = json.dumps(obj).encode()
                self.send_response(status)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(raw)))
                self.end_headers()
                self.wfile.write(raw)

            def do_POST(self):
                n = int(self.headers.get("Content-Length") or 0)
                body = json.loads(self.rfile.read(n) or b"{}")
                if self.path == "/submit":
                    with stub.lock:
                        stub.submits.append(time.time())
                    time.sleep(1.5)  # slow AND failing: the cancel
                    return self._send(500, {"error": "submit down"})
                if self.path != "/chat/completions":
                    return self._send(404, {"error": "no route"})
                model = body.get("model")
                with stub.lock:
                    stub.chat.append((model, time.time()))
                if stub.mode == "fail_all" or model == PRIMARY:
                    return self._send(500, {
                        "error": {"message": "primary down"},
                        "usage": {"prompt_tokens": 10,
                                  "completion_tokens": 5}})
                if model == FALLBACK:
                    canned = {
                        "kind": "script",
                        "lines": [
                            {"id": "L1", "scene_ref": "SC1",
                             "beat_ref": "B1", "story_ref": "S1",
                             "canon_refs": ["stub-will-be-replaced"],
                             "text": "Mara turns the brass key."},
                            {"id": "L2", "scene_ref": "SC2",
                             "beat_ref": "B2", "story_ref": "S2",
                             "canon_refs": ["stub-will-be-replaced"],
                             "text": "Tobin bars the archive door."},
                            {"id": "L3", "scene_ref": "SC1",
                             "text": "The ledger is gone."}],
                        "trace": {
                            "clues": [{"id": "CL1", "planted": "L1",
                                       "payoff": "L3"}],
                            "knowledge": [{"character": "Mara",
                                           "learns": "CL1", "at": "L2"}],
                            "payoffs": [{"id": "PO1", "clue": "CL1",
                                         "line": "L3"}]},
                        "canon_refs": ["stub-will-be-replaced"]}
                    return self._send(200, {
                        "id": "req-fb-1",
                        "choices": [{"message": {
                            "content": json.dumps(canned)}}],
                        "usage": {"prompt_tokens": 1000,
                                  "completion_tokens": 500}})
                return self._send(200, {
                    "id": "req-other",
                    "choices": [{"message": {"content": "text"}}],
                    "usage": {"prompt_tokens": 1, "completion_tokens": 1}})

            def do_GET(self):
                return self._send(200, {"status": "PROCESSING"})

        self.httpd = ThreadingHTTPServer(("127.0.0.1", 0), H)
        self.port = self.httpd.server_address[1]
        threading.Thread(target=self.httpd.serve_forever,
                         daemon=True).start()

    @property
    def url(self):
        return f"http://127.0.0.1:{self.port}"

    def chat_count(self, model=None):
        with self.lock:
            return len([c for c in self.chat
                        if model is None or c[0] == model])

    def submit_count(self):
        with self.lock:
            return len(self.submits)


STUB = Stub()


# ------------------------------------------------------------------ http
def call(base, method, path, body=None, role=None, expect=None):
    req = urllib.request.Request(base + path, method=method)
    data = None
    if role == "OPERATOR":
        req.add_header("X-Operator-Token", OPERATOR)
    elif role == "WORKER":
        req.add_header("X-Role", "WORKER")
        req.add_header("X-Role-Token", TOKENS["FACTORY_WORKER_TOKEN"])
        req.add_header("X-Identity", DRIVER)
    if body is not None:
        data = json.dumps(body).encode()
        req.add_header("Content-Type", "application/json")
    try:
        with urllib.request.urlopen(req, data=data, timeout=60) as r:
            status, out = r.status, json.loads(r.read() or b"{}")
    except urllib.error.HTTPError as e:
        status, out = e.code, json.loads(e.read() or b"{}")
    if expect is not None and status != expect:
        raise AssertionError(f"{method} {path} -> {status} (want {expect}): {out}")
    return status, out


def db(sql, args=()):
    with psycopg.connect(DSN, row_factory=dict_row, autocommit=True) as conn:
        cur = conn.execute(sql, args)
        try:
            return cur.fetchall()
        except psycopg.errors.ProgrammingError:
            return []


# -------------------------------------------------------------- processes
def kill_port(port):
    subprocess.run(["fuser", "-k", f"{port}/tcp"], capture_output=True)
    time.sleep(0.5)


def spawn(cmd, env, log_name):
    e = dict(os.environ)
    e.update(env)
    out = open(LOGS / log_name, "ab")
    return subprocess.Popen(cmd, env=e, stdout=out, stderr=out,
                            start_new_session=True)


def wait_url(url, seconds=60):
    deadline = time.time() + seconds
    while time.time() < deadline:
        try:
            with urllib.request.urlopen(url, timeout=2) as r:
                if r.status == 200:
                    return True
        except Exception:  # noqa: BLE001
            pass
        time.sleep(0.5)
    return False


# ---------------------------------------------------------------- driver
class Scenario:
    def __init__(self, name):
        self.name = name
        self.checks = []

    def check(self, name, ok, detail=""):
        self.checks.append({"name": name, "pass": bool(ok),
                            "detail": str(detail)})
        print(f"  [{'PASS' if ok else 'FAIL'}] {name} — {detail}")

    def finish(self, extra=None):
        verdict = all(c["pass"] for c in self.checks)
        doc = {"scenario": self.name,
               "verdict": "PASS" if verdict else "FAIL",
               "label": "STUB_TESTED", "checks": self.checks,
               **(extra or {})}
        RESULTS.mkdir(parents=True, exist_ok=True)
        (RESULTS / f"{self.name}.json").write_text(
            json.dumps(doc, indent=1, sort_keys=True))
        print(f"{self.name}: {'PASS' if verdict else 'FAIL'} "
              f"({sum(1 for c in self.checks if c['pass'])}/"
              f"{len(self.checks)})")
        return 0 if verdict else 1


def unit_row(pid, uid):
    _, out = call(API, "GET", f"/productions/{pid}/units", role="OPERATOR")
    return [u for u in out["units"] if u["unit_id"] == uid][0]


def wait_state(pid, uid, states, timeout=90):
    deadline = time.time() + timeout
    state = None
    while time.time() < deadline:
        state = unit_row(pid, uid)["state"]
        if state in states:
            return state
        time.sleep(0.5)
    raise AssertionError(f"unit {uid} stuck in {state}, wanted {states}")


def current_artifacts(pid):
    _, out = call(API, "GET", f"/productions/{pid}/artifacts",
                  role="OPERATOR")
    return {a["artifact_type"]: a for a in out["artifacts"]
            if a["state"] == "CURRENT"}


def wire_ref(art):
    return {"artifact_type": art["artifact_type"],
            "artifact_id": art["artifact_id"], "sha256": art["sha256"]}


def make_fixture(sc):
    _, p = call(API, "POST", "/productions",
                {"title": f"MM-04 battery ({sc.name})",
                 "hard_ceiling_cents": 5000, "soft_ceiling_cents": 4500},
                role="OPERATOR", expect=201)
    pid = p["production_id"]
    _, r = call(API, "POST", f"/productions/{pid}/runs", {"kind": "FULL"},
                role="OPERATOR", expect=201)
    run = r["run_id"]
    _, a = call(API, "POST", f"/productions/{pid}/artifacts",
                {"artifact_type": "canon_manifest", "content": CANON_TEXT,
                 "storage_uri": "local://canon-fixture"},
                role="OPERATOR", expect=201)
    canon = a["artifact_id"]

    def plan(op, depends=()):
        _, u = call(API, "POST", f"/productions/{pid}/units",
                    {"operation_id": op, "run_id": run, "unit_key": "main",
                     "depends_on": list(depends),
                     "input_artifact_ids": [canon]},
                    role="OPERATOR", expect=201)
        return u["unit_id"]

    units = {}
    units["05.12"] = plan("05.12")
    units["06.12"] = plan("06.12", [units["05.12"]])
    units["07.12"] = plan("07.12", [units["06.12"]])
    units["08.12"] = plan("08.12", [units["07.12"]])
    return pid, canon, units


def claim_and_binding(pid, uid):
    _, claim = call(API, "POST", f"/units/{uid}/claim",
                    {"worker_id": DRIVER}, role="OPERATOR", expect=200)
    _, attempts = call(API, "GET", f"/units/{uid}/attempts", role="OPERATOR")
    return claim, attempts["attempts"][0]["resolved_config"]


def work(pid, uid, op, claim, binding, refs):
    body = {"provider_binding": binding, "operation_id": op,
            "production_id": pid, "unit_id": uid,
            "attempt_id": claim["attempt_id"],
            "fencing_token": claim["fencing_token"], "worker_id": DRIVER,
            "input_artifact_refs": refs}
    return call(WORKER, "POST", "/work", body)


def evaluate_and_approve(sc, pid, uid):
    _, report = call(EVAL, "POST", "/evaluate", {"unit_id": uid},
                     expect=200)
    state = wait_state(pid, uid, {"ACCEPTED", "AWAITING_HUMAN", "FAILED",
                                  "BLOCKED", "RETRY_WAIT"})
    if state == "AWAITING_HUMAN":
        call(API, "POST", f"/units/{uid}/events",
             {"event": "human_approved"}, role="OPERATOR", expect=200)
        state = wait_state(pid, uid, {"ACCEPTED"})
    return report, state


def drive_chain_unit(sc, pid, uid, op, refs):
    wait_state(pid, uid, {"READY"})
    claim, binding = claim_and_binding(pid, uid)
    status, out = work(pid, uid, op, claim, binding, refs)
    sc.check(f"{op} /work 200 (deterministic chain)",
             status == 200 and out.get("status") == "COMPLETED",
             f"status={status}")
    body = {"worker_id": DRIVER, "fencing_token": claim["fencing_token"],
            "artifact_type": out["artifact_type"],
            "content": out["content"],
            "actual_cost_cents": out["actual_cost_cents"]}
    call(API, "POST", f"/units/{uid}/complete", body, role="OPERATOR",
         expect=200)
    _, state = evaluate_and_approve(sc, pid, uid)
    sc.check(f"{op} ACCEPTED", state == "ACCEPTED", f"state={state}")
    return current_artifacts(pid)


def drive_fixture_chain(sc, pid, canon_id, units):
    _, arts = call(API, "GET", f"/productions/{pid}/artifacts",
                   role="OPERATOR")
    canon_row = [a for a in arts["artifacts"]
                 if a["artifact_id"] == canon_id][0]
    have = {"canon_manifest": canon_row}
    refs = [wire_ref(canon_row)]
    for op in ("05.12", "06.12", "07.12"):
        have = drive_chain_unit(sc, pid, units[op], op, refs)
        refs = [wire_ref(have[t]) for t in
                ("canon_manifest", "story_architecture", "beat_graph",
                 "scene_set") if t in have]
    return have, refs


def action_records(uid):
    return db("SELECT action_key, status, output_summary, error "
              "FROM plan_action_attempts WHERE unit_id=%s ORDER BY seq",
              (uid,))


def gen_record(uid):
    rows = [r for r in action_records(uid)
            if r["action_key"] == "op.build"]
    return rows[0] if rows else {}


# ---------------------------------------------------------------- seeding
def seed_all():
    # models + the ACTIVE assignment for 08.12 (registry fixtures)
    db("DELETE FROM operation_model_assignments WHERE operation_id='08.12'")
    db("DELETE FROM models WHERE model_id LIKE 'acme/%%'")
    for mid, ctx in ((PRIMARY, 100000), (FALLBACK, 100000), (TINY, 10)):
        db("INSERT INTO models(model_id, provider, context_length)"
           " VALUES (%s, 'acme', %s)", (mid, ctx))
    db("INSERT INTO operation_model_assignments"
       "(operation_id, role, primary_model, fallback_model,"
       " matrix_version, status) VALUES ('08.12', 'generation', %s, %s,"
       " '1.0.0', 'ACTIVE')", (PRIMARY, FALLBACK))

    def config(want):
        status, out = call(API, "POST", "/configs", want, role="OPERATOR")
        assert status in (200, 201), (status, out)

    config({"scope": "STATION", "station": 3, "environment": "test",
            "provider": "deterministic-local", "est_cost_cents": 100,
            "params": {"reported_actual_cents": 90}})
    config({"scope": "OPERATION", "operation_id": "08.12",
            "environment": "test", "provider": "openrouter-compatible",
            "model": PRIMARY, "modality": "text",
            "credential_ref": "MM04_BATTERY_KEY", "est_cost_cents": 25,
            "timeout_s": 60, "params": {"base_url": STUB.url},
            "retry_policy": {"base_s": 0.05, "max_s": 0.2}})
    config({"scope": "OPERATION", "operation_id": "01.04",
            "environment": "test", "provider": "direct-http-text",
            "modality": "text", "credential_ref": "MM04_BATTERY_KEY",
            "est_cost_cents": 100, "timeout_s": 60,
            "params": {"submit_endpoint": STUB.url + "/submit",
                       "poll_endpoint": STUB.url + "/poll/{job_id}",
                       "mode": "async"},
            "retry_policy": {"base_s": 3, "max_s": 30}})
    for model, rin, rout in ((PRIMARY, "0.01", "0.02"),
                             (FALLBACK, "0.001", "0.002")):
        for unit_kind, price in (("input_token", rin),
                                 ("output_token", rout)):
            status, out = call(API, "POST", "/pricing-rules",
                               {"provider": "openrouter-compatible",
                                "model": model, "modality": "text",
                                "unit_kind": unit_kind,
                                "unit_price_cents": price,
                                "pricing_version": PRICING_VERSION},
                               role="OPERATOR")
            assert status in (200, 201), (status, out)
    print("seeded: models, ACTIVE assignment (08.12 + fallback), "
          "bindings (STATION 3, 08.12, 01.04), pricing (distinct rates)")


# -------------------------------------------------------------- scenarios
def scenario_d():
    sc = Scenario("d_fallback_pricing")
    STUB.mode = "fallback"
    pid, canon_id, units = make_fixture(sc)
    drive_fixture_chain(sc, pid, canon_id, units)
    uid = units["08.12"]
    wait_state(pid, uid, {"READY"})
    claim, binding = claim_and_binding(pid, uid)
    sc.check("claim snapshot carries the ACTIVE assignment pin",
             (binding.get("model_assignment") or {}).get(
                 "fallback_model") == FALLBACK,
             f"assignment={binding.get('model_assignment')}")
    before_p, before_f = STUB.chat_count(PRIMARY), STUB.chat_count(FALLBACK)
    _, arts = call(API, "GET", f"/productions/{pid}/artifacts",
                   role="OPERATOR")
    canon_row = [a for a in arts["artifacts"]
                 if a["artifact_id"] == canon_id][0]
    have = current_artifacts(pid)
    refs = [wire_ref(have[t]) for t in
            ("canon_manifest", "story_architecture", "beat_graph",
             "scene_set") if t in have]
    status, out = work(pid, uid, "08.12", claim, binding, refs)
    sc.check("/work 200 COMPLETED via fallback", status == 200
             and out.get("status") == "COMPLETED", f"status={status}")
    got_p = STUB.chat_count(PRIMARY) - before_p
    got_f = STUB.chat_count(FALLBACK) - before_f
    sc.check("stub calls: primary 3 (1 + 2 bounded retries), fallback 1",
             got_p == 3 and got_f == 1, f"primary={got_p} fallback={got_f}")
    rec = gen_record(uid)
    summ = rec.get("output_summary") or {}
    if isinstance(summ, str):
        summ = json.loads(summ)
    lines = summ.get("usage_lines") or []
    sc.check("generation record: executed model = fallback; fallback "
             "event (primary, fallback, trigger PROVIDER_HTTP_500); "
             "correlation id; 4 usage lines",
             summ.get("model") == FALLBACK
             and (summ.get("fallback_event") or {}).get(
                 "primary_model") == PRIMARY
             and (summ.get("fallback_event") or {}).get(
                 "trigger_class") == "PROVIDER_HTTP_500"
             and bool(summ.get("correlation_id")) and len(lines) == 4,
             json.dumps(summ)[:300])
    usage = out.get("usage") or {}
    sc.check("completion usage summed across the chain "
             "(3x error usage + fallback usage = 1030 in / 515 out)",
             usage.get("input_tokens") == 1030
             and usage.get("output_tokens") == 515, f"usage={usage}")
    body = {"worker_id": DRIVER, "fencing_token": claim["fencing_token"],
            "artifact_type": out["artifact_type"],
            "content": out["content"],
            "actual_cost_cents": out["actual_cost_cents"],
            "usage": usage,
            "provider_request_id": out.get("provider_request_id"),
            "model": summ.get("model")}
    _, done = call(API, "POST", f"/units/{uid}/complete", body,
                   role="OPERATOR", expect=200)
    ev = db("SELECT charge_class, amount_cents, pricing_version "
            "FROM financial_evidence WHERE attempt_id=%s "
            "ORDER BY created_at", (claim["attempt_id"],))
    by_class = {r["charge_class"]: r for r in ev}
    calc = by_class.get("CALCULATED", {})
    fin = by_class.get("FINALIZED", {})
    sc.check("CALCULATED priced at FALLBACK rates (1030x0.001 + "
             "515x0.002 = 2.06 -> 2c), not primary rates (21c); "
             "FINALIZED = CALCULATED",
             calc.get("amount_cents") == EXPECTED_CALCULATED_FALLBACK
             and calc.get("amount_cents") != PRIMARY_RATE_CALCULATED
             and fin.get("amount_cents") == EXPECTED_CALCULATED_FALLBACK
             and calc.get("pricing_version") == PRICING_VERSION,
             json.dumps({k: v.get("amount_cents")
                         for k, v in by_class.items()}))
    return sc.finish({"production_id": pid, "unit_08_12": uid,
                      "calculated_cents": EXPECTED_CALCULATED_FALLBACK,
                      "primary_rate_counterfactual_cents":
                          PRIMARY_RATE_CALCULATED,
                      "stub_calls": {"primary": got_p, "fallback": got_f},
                      "summed_usage": usage})


def scenario_c():
    sc = Scenario("c_failure_battery")
    STUB.mode = "fail_all"
    try:
        pid, canon_id, units = make_fixture(sc)
        drive_fixture_chain(sc, pid, canon_id, units)
        uid = units["08.12"]
        wait_state(pid, uid, {"READY"})
        claim, binding = claim_and_binding(pid, uid)
        have = current_artifacts(pid)
        refs = [wire_ref(have[t]) for t in
                ("canon_manifest", "story_architecture", "beat_graph",
                 "scene_set") if t in have]
        before = STUB.chat_count()
        status, out = work(pid, uid, "08.12", claim, binding, refs)
        got = STUB.chat_count() - before
        # the ACTIVE assignment from scenario (d) is still pinned, so
        # the gateway ALSO tries the fallback once after the primary's
        # retries — the stub fails it too: 3 primary + 1 fallback.
        sc.check("/work 502 typed PROVIDER_HTTP_500 after bounded "
                 "retries + one authorized fallback attempt "
                 "(4 stub calls, test-scaled policy)",
                 status == 502
                 and out.get("error_class") == "PROVIDER_HTTP_500"
                 and got == 4, f"status={status} calls={got}")
        lines = out.get("usage_lines") or []
        sc.check("error response carries the chain correlation id + "
                 "4 usage-evidence lines (fallback attempt visible)",
                 bool(out.get("correlation_id")) and len(lines) == 4
                 and lines[-1].get("kind") == "fallback",
                 f"lines={len(lines)}")
        rec = gen_record(uid)
        sc.check("generation action record FAILED (provider error)",
                 rec.get("status") == "FAILED"
                 and "provider HTTP 500" in (rec.get("error") or ""),
                 f"status={rec.get('status')}")
        _, arts = call(API, "GET", f"/productions/{pid}/artifacts",
                       role="OPERATOR")
        sc.check("zero script artifacts",
                 not any(a["artifact_type"] == "script"
                         for a in arts["artifacts"]), "")
        ev = db("SELECT charge_class FROM financial_evidence "
                "WHERE attempt_id=%s", (claim["attempt_id"],))
        classes = sorted(r["charge_class"] for r in ev)
        sc.check("zero settlement (only the claim-time ESTIMATED row)",
                 classes == ["ESTIMATED"], f"classes={classes}")
        call(API, "POST", f"/units/{uid}/events",
             {"event": "transient_error", "worker_id": DRIVER},
             role="WORKER", expect=200)
        state = wait_state(pid, uid, {"RETRY_WAIT"})
        sc.check("unit in recovery state RETRY_WAIT",
                 state == "RETRY_WAIT", f"state={state}")
        return sc.finish({"production_id": pid, "unit_08_12": uid,
                          "stub_calls": got})
    finally:
        STUB.mode = "fallback"


def scenario_b():
    sc = Scenario("b_context_limit")
    # re-seed the 08.12 binding onto the tiny-context model (new
    # config version supersedes via POST /configs)
    status, out = call(API, "POST", "/configs",
                       {"scope": "OPERATION", "operation_id": "08.12",
                        "environment": "test",
                        "provider": "openrouter-compatible",
                        "model": TINY, "modality": "text",
                        "credential_ref": "MM04_BATTERY_KEY",
                        "est_cost_cents": 25, "timeout_s": 60,
                        "params": {"base_url": STUB.url},
                        "retry_policy": {"base_s": 0.05, "max_s": 0.2}},
                       role="OPERATOR")
    sc.check("08.12 binding re-seeded to the tiny-context model",
             status in (200, 201), f"status={status}")
    pid, canon_id, units = make_fixture(sc)
    drive_fixture_chain(sc, pid, canon_id, units)
    uid = units["08.12"]
    wait_state(pid, uid, {"READY"})
    claim, binding = claim_and_binding(pid, uid)
    sc.check("claim resolves the tiny model binding",
             binding.get("model") == TINY, f"model={binding.get('model')}")
    have = current_artifacts(pid)
    refs = [wire_ref(have[t]) for t in
            ("canon_manifest", "story_architecture", "beat_graph",
             "scene_set") if t in have]
    before = STUB.chat_count()
    status, out = work(pid, uid, "08.12", claim, binding, refs)
    got = STUB.chat_count() - before
    sc.check("/work fails typed CONTEXT_LIMIT; stub saw ZERO calls "
             "(refusal before any HTTP)",
             status in (409, 502)
             and out.get("error_class") in ("CONTEXT_LIMIT", "BLOCKED")
             and got == 0, f"status={status} calls={got} out={out}")
    rec = gen_record(uid)
    summ = rec.get("output_summary") or {}
    if isinstance(summ, str):
        summ = json.loads(summ)
    lines = summ.get("usage_lines") or []
    sc.check("FAILED generation record carries the refusal: "
             "error_class CONTEXT_LIMIT, one 'refused' usage line "
             "with the recorded estimate (> 10 tokens)",
             rec.get("status") == "FAILED"
             and summ.get("error_class") == "CONTEXT_LIMIT"
             and len(lines) == 1
             and lines[0].get("outcome") == "refused"
             and (lines[0].get("estimated_prompt_tokens") or 0) > 10,
             json.dumps(summ)[:300])
    _, arts = call(API, "GET", f"/productions/{pid}/artifacts",
                   role="OPERATOR")
    sc.check("zero script artifacts",
             not any(a["artifact_type"] == "script"
                     for a in arts["artifacts"]), "")
    return sc.finish({"production_id": pid, "unit_08_12": uid,
                      "stub_calls": got})


def scenario_h():
    sc = Scenario("h_cancellation")
    _, p = call(API, "POST", "/productions",
                {"title": "MM-04 battery (h_cancellation)",
                 "hard_ceiling_cents": 5000, "soft_ceiling_cents": 4500},
                role="OPERATOR", expect=201)
    pid = p["production_id"]
    _, r = call(API, "POST", f"/productions/{pid}/runs", {"kind": "FULL"},
                role="OPERATOR", expect=201)
    _, u = call(API, "POST", f"/productions/{pid}/units",
                {"operation_id": "01.04", "run_id": r["run_id"],
                 "unit_key": "main"}, role="OPERATOR", expect=201)
    uid = u["unit_id"]
    wait_state(pid, uid, {"READY"})
    claim, binding = claim_and_binding(pid, uid)
    call(API, "POST", f"/units/{uid}/events",
         {"event": "start", "worker_id": DRIVER}, role="WORKER",
         expect=200)
    _, job = call(API, "POST", "/provider-jobs",
                  {"unit_id": uid, "attempt_id": claim["attempt_id"],
                   "fencing_token": claim["fencing_token"],
                   "idempotency_key": "mm04-cancel-1"},
                  role="WORKER", expect=201)
    job_id = job["job_id"]
    sc.check("provider job registered; unit AWAITING_PROVIDER",
             unit_row(pid, uid)["state"] == "AWAITING_PROVIDER",
             f"job={job_id}")
    outcome = {}

    def worker_call():
        body = {"provider_binding": binding, "operation_id": "01.04",
                "production_id": pid, "unit_id": uid,
                "attempt_id": claim["attempt_id"],
                "fencing_token": claim["fencing_token"],
                "idempotency_key": "mm04-cancel-work"}
        outcome["result"] = call(WORKER, "POST", "/jobs", body)
    t = threading.Thread(target=worker_call)
    t.start()
    deadline = time.time() + 15
    while STUB.submit_count() < 1 and time.time() < deadline:
        time.sleep(0.05)
    sc.check("worker submit chain in flight (stub submit count 1)",
             STUB.submit_count() == 1, f"count={STUB.submit_count()}")
    status, out = call(API, "POST", f"/provider-jobs/{job_id}/cancel",
                       {"correlation_id": "mm04-h-cancel"},
                       role="OPERATOR")
    sc.check("OPERATOR cancel accepted; job CANCELLED",
             status == 200 and out.get("job_status") == "CANCELLED",
             f"status={status} out={out}")
    t.join(timeout=30)
    wstatus, wout = outcome.get("result", (None, {}))
    sc.check("worker chain stopped with typed CANCELLED (no retry "
             "fired)", wstatus == 502
             and wout.get("error_class") == "CANCELLED",
             f"status={wstatus} out={wout}")
    frozen = STUB.submit_count()
    time.sleep(4)  # > one 3s backoff: a queued retry would fire here
    sc.check("stub submit count frozen after the backoff window",
             STUB.submit_count() == frozen == 1,
             f"count={STUB.submit_count()}")
    _, jobs = call(API, "GET", f"/units/{uid}/provider-jobs",
                   role="OPERATOR")
    job_row = [j for j in jobs["provider_jobs"]
               if j["job_id"] == job_id][0]
    raw = job_row.get("raw_response") or {}
    if isinstance(raw, str):
        raw = json.loads(raw)
    attempts = db("SELECT status, error_class FROM action_attempts "
                  "WHERE attempt_id=%s", (claim["attempt_id"],))
    audits = db("SELECT count(*) AS n FROM audit_events "
                "WHERE unit_id=%s AND event_type='provider_job_cancelled'",
                (uid,))
    sc.check("job CANCELLED with the caller's correlation id in "
             "raw_response; attempt FAILED/error_class CANCELLED; "
             "unit RETRY_WAIT; cancel audit committed",
             job_row["status"] == "CANCELLED"
             and raw.get("correlation_id") == "mm04-h-cancel"
             and raw.get("failure_code") == "CANCELLED"
             and attempts and attempts[0]["status"] == "FAILED"
             and attempts[0]["error_class"] == "CANCELLED"
             and unit_row(pid, uid)["state"] == "RETRY_WAIT"
             and audits[0]["n"] == 1,
             f"job={job_row['status']} raw={raw} attempts={attempts} "
             f"audits={audits[0]['n'] if audits else 0}")
    return sc.finish({"production_id": pid, "unit_id": uid,
                      "job_id": job_id, "stub_submits": STUB.submit_count()})


def scenario_i():
    sc = Scenario("i_health")
    rows = db("SELECT provider, status, detail FROM provider_health "
              "ORDER BY checked_at")
    pairs = {(r["provider"], r["status"]) for r in rows}
    sc.check("provider_health accumulated across the battery: "
             "openrouter-compatible ok (fallback success) + error "
             "(failure battery) + refused (context refusal / cancel)",
             ("openrouter-compatible", "ok") in pairs
             and ("openrouter-compatible", "error") in pairs
             and ("openrouter-compatible", "refused") in pairs,
             f"pairs={sorted(pairs)}")
    dirty = [r for r in rows
             if "MM04_BATTERY_KEY" in (r["detail"] or "")
             or "CANON MANIFEST" in (r["detail"] or "")
             or "mm04-battery-dummy" in (r["detail"] or "")]
    sc.check("health details carry no credential value and no prompt "
             "content", not dirty, f"rows={len(rows)}")
    return sc.finish({"provider_health_rows": len(rows),
                      "pairs": sorted(map(list, pairs))})


# ------------------------------------------------------------------ main
def setup():
    subprocess.run(["pg_ctlcluster", "16", "main", "start"],
                   capture_output=True)
    r = subprocess.run(["python3", str(G3 / "tools/setup_db.py"), DB],
                       capture_output=True, text=True)
    if r.returncode != 0:
        raise SystemExit(f"scratch DB setup failed: {r.stderr[-400:]}")
    print(f"db: {DB} built")
    for port in (8830, 8895, 8896):
        kill_port(port)
    spawn([str(G3 / ".venv/bin/python"), str(G3 / "api/server.py")],
          {"FACTORY_DSN": DSN, "FACTORY_PORT": "8830", **TOKENS},
          "battery_api.log")
    if not wait_url(API + "/health"):
        raise SystemExit("API did not come up (see logs)")
    spawn([VENV_PY, str(PROG / "gate-c/worker_service/service.py")],
          {"WORKER_SERVICE_PORT": "8895", "WORKER_ENVIRONMENT": "test",
           "WORKER_DSN": DSN, "FACTORY_API_URL": API,
           "FACTORY_WORKER_TOKEN": TOKENS["FACTORY_WORKER_TOKEN"],
           "WORKER_CREDENTIAL_REFS": "MM04_BATTERY_KEY",
           "MM04_BATTERY_KEY": "mm04-battery-dummy"}, "battery_worker.log")
    if not wait_url(WORKER + "/health"):
        raise SystemExit("worker did not come up (see logs)")
    spawn([VENV_PY, str(PROG / "gate-e/evaluation_service/service.py")],
          {"FACTORY_DSN": DSN, "FACTORY_API_URL": API,
           "FACTORY_VALIDATOR_TOKEN": TOKENS["FACTORY_VALIDATOR_TOKEN"],
           "FACTORY_EVAL_PORT": "8896"}, "battery_eval.log")
    if not wait_url(EVAL + "/health"):
        raise SystemExit("evaluation service did not come up (see logs)")
    print("stack: api 8830, worker 8895, eval 8896, stub", STUB.url)
    seed_all()
    return 0


def teardown():
    for port in (8830, 8895, 8896):
        kill_port(port)
    STUB.httpd.shutdown()
    print("teardown: battery stack stopped")
    return 0


def run_all():
    rc = setup()
    if rc:
        return rc
    try:
        for fn in (scenario_d, scenario_c, scenario_b, scenario_h,
                   scenario_i):
            r = fn()
            if r:
                rc = r
    finally:
        teardown()
    return rc


if __name__ == "__main__":
    cmd = sys.argv[1] if len(sys.argv) > 1 else ""
    LOGS.mkdir(parents=True, exist_ok=True)
    RESULTS.mkdir(parents=True, exist_ok=True)
    sys.exit({"setup": setup, "teardown": teardown, "all": run_all,
              "d": scenario_d, "c": scenario_c, "b": scenario_b,
              "h": scenario_h, "i": scenario_i}[cmd]())
