# GATE MM-04 — INDEPENDENT VERIFIER REPORT

**Verdict: MM-04 PASS — defects NONE.** Every item below was executed
on the verifier's own stack (scratch DBs `mm04_verify_scratch` /
`mm04_verify_unseeded`, API 8930/8931, worker 8995/8997, eval
8996/8998, verifier-owned stub on an ephemeral port, own tokens and
credential `VERIFY_MM04_KEY`), with verifier-owned fixture models
(`verify/primary`, `verify/fallback`, `verify/tiny`, `verify/ghost`,
`verify/slice-model`) and usage figures chosen independently of the
builder's. All provider contact was against the verifier's stub
(STUB_TESTED). Harness: `evidence/verify/verify_mm04.py`; per-item
results: `evidence/verify/results/*.json`; logs:
`evidence/verify/logs/`.

Environment note (not a product finding): this VM had lost
PostgreSQL entirely on arrival (no packages/cluster/user — the
recorded VM-replacement failure mode). It was restored from the
cached 16.15 debs per the standing recovery procedure before any
verification ran; no product file was touched by the verifier.

## Item 1 — Context limit (seeded registry), unknown model, unseeded baseline — PASS (6/6 + 3/3)

Seeded stack (MM-03 seeder run for real: 460 model rows incl.
fixtures):
- Binding model `verify/tiny` (context_length 10): `/work` refused
  with typed `CONTEXT_LIMIT` and the stub recorded **0 calls** —
  refusal strictly before any HTTP. The generation action record is
  FAILED with exactly one `refused` usage line carrying
  `estimated_prompt_tokens: 508` (> the limit of 10) and the chain
  correlation id. Zero script artifacts.
- Binding model `verify/ghost` (absent from `models`): typed
  `MODEL_UNKNOWN` refusal, 0 stub calls, refusal present in the
  action record.
- Unseeded stack (registry tables exist, `models` count = 0): the
  Phase 3 slice mechanics behave exactly as the pre-MM-04 baseline —
  provider `/work` executed with **exactly one** stub call (no
  MODEL_UNKNOWN/CONTEXT_LIMIT refusal, no spurious retry), and the
  completion priced `CALCULATED = 2¢` (500×0.002 + 250×0.004) with
  `FINALIZED = CALCULATED` from the seeded pricing rows.

## Item 2 — Bounded retries + usage sum + correlation — PASS (5/5)

Stub scripted 500/500/200 for the primary model with verifier usage
figures (111/22, 111/22, 333/44): `/work` succeeded after **exactly
3 calls**; the `X-Correlation-Id` header was **identical across all
three** stub-received requests; the completion usage equals the sum
of all three usage bodies (input 555, output 88); the action record
holds the three usage lines (error, error, success) under the same
correlation id. A scripted **400** produced exactly **1 call** and an
immediate typed `PROVIDER_HTTP_400` failure (0.1 s — no retry).

## Item 3 — Authorized fallback, money path — PASS (7/7)

With an ACTIVE assignment naming `verify/fallback` and the primary
permanently 500ing (usage on every error):
- Calls: primary 3 (1 + 2 bounded retries), fallback exactly 1;
  completion via the fallback.
- The generation record's fallback event names
  `{primary_model: verify/primary, fallback_model: verify/fallback,
  trigger_class: PROVIDER_HTTP_500}` and its executed model is the
  fallback; chain usage summed to 2030 in / 715 out.
- Money: `CALCULATED = 4¢` at the **fallback** rates
  (2030×0.0011 + 715×0.0022 = 3.806 → 4), explicitly **not** the 90¢
  the same usage would price at the primary rates; `FINALIZED = 4¢`.
- Negative (i) — assignment removed: typed `PROVIDER_HTTP_500`
  failure; the stub saw only the 3 primary calls, **fallback calls
  0** (no silent swap).
- Negative (ii) — fallback named but the primary refuses on context
  limit: `CONTEXT_LIMIT`, **primary calls 0 and fallback calls 0**
  (refusals never trigger fallback).

## Item 4 — Cancellation + migration 017 — PASS (9/9)

- Migration 017 read directly: an idempotent DO block that discovers
  the inline CHECK from migration 002 and replaces it with a named
  constraint carrying the original seven values plus `CANCELLED` —
  a widening only, no data rewrite, no history edited. Migrations on
  disk max at **017**, and the built DB's live constraint reads
  `status = ANY (ARRAY['SUBMITTED','PROCESSING','COMPLETED','FAILED',
  'TIMEOUT','UNKNOWN','NOT_FOUND','CANCELLED'])`.
- Async job (direct-http-text) registered, unit AWAITING_PROVIDER:
  a **wrong-identity WORKER cancel was refused 403** with a committed
  `provider_job_cancel_refused` audit row and the job still
  SUBMITTED; the **OPERATOR cancel** then marked the job `CANCELLED`
  (attempt FAILED/error_class `CANCELLED`, unit RETRY_WAIT, worker
  submit chain stopped with typed `CANCELLED`, stub submit count
  frozen at 1 across the backoff window); a **repeat cancel returned
  200 with `already_cancelled=true`** and the job still CANCELLED.

## Item 5 — Concurrency limit — PASS (2/2)

Fresh worker process (limiter parameters come from the first binding
seen per provider per process, as documented); binding params
`max_concurrency: 2`; six parallel slow-stub (1.2 s) `/work` calls:
**stub-observed max simultaneous in-flight = 2**, all six completed
successfully, exactly six provider calls.

## Item 6 — Provider health + no-bypass — PASS (5/5)

- `provider_health` rows for `openrouter-compatible` accumulated
  `ok`, `error`, and `refused` outcomes across the battery (9 gateway
  rows; the set also contains the MM-03 seeder's initial
  `BLOCKED_NO_CREDENTIAL` row, which is seeder data, not a gateway
  write). **No detail text contains the verifier's canon/prompt
  marker, prompt content, or the credential value** (grepped for the
  marker string, script text fragments, and the dummy credential).
- `/work` with no binding/ids → **400**. `/work` with a fully
  fabricated claim context (random unit/attempt ids, fencing 999) →
  refused (`ACTION_RECORD_FAILED` — the API sink rejects the action
  record for the nonexistent attempt) with **stub call delta 0**:
  no adapter call is reachable without a Coordinator-issued claim.
  Unknown worker route → 404.

## Item 7 — Run-C terminal state (production retry policy) — PASS (5/5)

The Phase 3 run-c scenario shape reproduced with the production
retry policy (`base_s 30 / max_s 900`) and a patient client: the
chain ran the full backoff (**elapsed 90 s, exactly 3 stub calls**)
and returned the typed `502 PROVIDER_HTTP_500` to the client — the
builder's "harness-client timeout" is confirmed to be purely the old
harness's 30 s client timeout, not a product behavior. Terminal DB
state verified directly: generation action record FAILED (provider
HTTP 500), **zero script artifacts**, financial evidence for the
attempt is **ESTIMATED only** (zero settlement), and the unit sits in
**RETRY_WAIT** after the transient-error transition.

## Item 8 — Regression spot — PASS

From the verifier's own serial runs (logs in `evidence/verify/logs/`):
- Worker service suite: **Ran 54 tests — OK** (40 baseline + 14
  gateway tests, as claimed).
- G3 suite: **Ran 36 tests — OK**; the contract file reads
  `contract_version 1.9.0` with **46 endpoints** (confirmed by direct
  read).
- G9 suite: **Ran 10 tests — OK**; the persisted full-run production
  in `g9_fullrun_scratch` independently shows **18 ACCEPTED units and
  18 FINALIZED rows totaling exactly 1620¢**.

## Verdict against the gate PASS condition

"Mocked gateway tests demonstrate correct routing, failures,
fallback, cancellation, usage, and no unauthorized calls" — **met on
independent evidence**: routing and bounded retries (item 2),
failure classes incl. pre-HTTP refusals (items 1, 7), authorized
fallback priced at the fallback model with both no-swap negatives
(item 3), async cancellation incl. idempotence and identity refusal
(item 4), usage summed across every call in the chain (item 2),
concurrency limiting (item 5), health telemetry without secret or
prompt leakage, and refusal of every unauthenticated/unclaimed
execution path (item 6). The unseeded-registry baseline behavior is
byte-for-byte the Phase 3 mechanics (item 1c), so the gateway engages
only where the MM-03 registry is seeded, exactly as locked.

**MM-04: PASS recommended. Defects: NONE.** (All evidence is
STUB_TESTED; no real provider was contacted and no credential exists
in this environment — the genuine-provider acceptance remains
MM-12/MM-13 scope, as the programme prescribes.)
