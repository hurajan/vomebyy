# MM-04 — Changed assertions & behavior deltas

Everything below is additive or a direct consequence of the briefed
MM-04 behavior. No pre-existing assertion was weakened or deleted;
suite counts moved only by ADDITION (worker 40 → 54, the 14 new
gateway tests in `worker_service/tests/test_gateway.py`).

## Contract (g3 `contracts/api_contract.json`): 1.8.0 → 1.9.0

- NEW endpoint `POST /provider-jobs/{job_id}/cancel` (OPERATOR/WORKER;
  WORKER identity-bound to the attempt's claim; mismatch → committed
  `provider_job_cancel_refused` audit + 403; COMPLETED/FAILED →
  409; repeat cancel idempotent with `already_cancelled=true`).
- `POST /units/{uid}/complete` request gains `model?`: when presented
  it is the EXECUTED model the pricing lookup uses (authorized-fallback
  completions price at the fallback model's rows); absent, pricing
  uses the attempt snapshot's pinned model exactly as before. All
  existing callers are byte-identical in behavior.
- `POST /provider-jobs/{job_id}/callback` request gains
  `correlation_id?` (merged into the job's `raw_response`) and
  `model?` (same executed-model pricing rule as /complete).
- The g3 contract test exercises the cancel endpoint inside
  `test_all_endpoints` (fresh unit + job; wrong-identity WORKER cancel
  → 403; OPERATOR cancel → CANCELLED + unit RETRY_WAIT; repeat →
  already_cancelled). The suite's endpoint-coverage assertion
  (`want - covered == set()`) passes at 46 endpoints.

## Migration 017 (additive)

`017_mm04_provider_job_cancel.sql` widens the `provider_jobs.status`
CHECK to add `'CANCELLED'` (the Gate B design had deliberately not
widened it; the MM-04 brief requires the job be marked CANCELLED).
Idempotent DO block; applied by one added line in g2
`tools/setup_db.py`. No existing row or value changed.

## Behavior changes a verifier will observe

1. **Provider 5xx/429/connection failures now retry inside the
   attempt** (max 2 retries, backoff from the binding's
   `retry_policy`; defaults base 1s / max 30s when the binding names
   none). Consequences:
   - The worker suite's pre-existing error500 generate_script test now
     takes ~3s (default backoff) and still passes unchanged.
   - The Lean Phase 3 harness scenario run-c (stub 500 against the
     production-shaped slice binding, retry_policy base_s 30) now runs
     ~90s before failing typed — beyond the harness's fixed 30s HTTP
     client timeout, so run-c ends in a harness-client TimeoutError
     instead of its /work assertions. The terminal outcome is
     unchanged in kind and is asserted in the MM-04 battery
     (c_failure_battery, test-scaled policy). run-a and run-b re-ran
     fully green (15/15, 24/24) — see
     `evidence/results/a_slice_rerun.json`.
2. **Error responses from /work and /jobs carry gateway evidence**
   (additive keys: `correlation_id`, `usage_lines`, `fallback_event`
   when present). Success payloads likewise gain `model`,
   `correlation_id`, `usage_lines`, `fallback_event` only when a
   gateway chain produced them; every other payload is byte-identical.
3. **A completion may now be priced at a non-snapshot model** — ONLY
   when the caller presents the executed model and a gateway fallback
   actually executed it (the worker payload's `model` originates in
   the chain metadata, never in caller invention on the worker side;
   executors pass it through). With no `model` presented, pricing is
   exactly the pre-MM-04 behavior.
4. **Refusals carry evidence**: CONTEXT_LIMIT / MODEL_UNKNOWN
   exceptions now carry `.gateway` metadata (correlation id + the
   refused usage line with `estimated_prompt_tokens`), so plan action
   records evidence refusals, not just failures. Previously these
   exceptions propagated without chain metadata.
5. **provider_health rows** are written per gateway chain outcome
   (ok / error / refused) when the registry is armed; unarmed
   (pre-MM-03-seed) databases see no writes and no behavior change —
   the same arming rule as plan-pin verification (DSN present AND
   models table seeded).

## Recorded interpretations (from LOCK_MM04.md)

- Fallback executes exactly ONE call (no retries on the fallback
  segment).
- The models-table context check arms only when the worker has DB
  access AND the registry is seeded; an unseeded registry is the
  feature-not-engaged state (protects the verified Phase 3 slice
  battery, whose scratch DB has an empty models table).
- Async poll calls are not correlation-header-wrapped (polling is the
  Coordinator reconciler's surface); submit calls are.
- Sync-path cancellation = the existing unit `cancel` event (no
  second mechanism built); the gateway's binding-timeout budget
  bounds any in-flight sync chain.

## Regression (test j)

Serial full regression (`mm-gate-04/tests/run_regression.sh`, logs in
`evidence/logs/regression/`): all 13 suites rc=0 — g1 9, g2 81,
g3 36, g4 2, g5 1, g6 3, g7 2, g8 1, g9 10, worker 54, storage 5,
evaluation 25, runtime 10 = **239** (baseline 225 + 14 new gateway
tests). The g9 suite's full-production run test passed with its
standing assertions (18 units ACCEPTED, budget exactly 1620¢).
