#!/usr/bin/env python3
"""MM-04 INDEPENDENT VERIFIER battery (all provider contact = own stub).

Own scratch DBs (mm04_verify_scratch = MM-03-registry-seeded,
mm04_verify_unseeded = registry tables present but models EMPTY),
own ports (API 8930 / worker 8995 / eval 8996; stack2 API 8931 /
worker 8997), own tokens/credential, own fixture models
(verify/primary, verify/fallback, verify/tiny, verify/ghost,
verify/slice-model) and own usage figures throughout.
"""
import json
import os
import re
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.request
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

import psycopg
from psycopg.rows import dict_row

HOME = Path.home()
G2 = HOME / "workspace/video-factory-g2"
G3 = HOME / "workspace/video-factory-g3"
PROG = HOME / "workspace/video-factory-real-ai-programme"
MM = HOME / "workspace/video-factory-master-programme"
VDIR = MM / "mm-gate-04/evidence/verify"
RESULTS = VDIR / "results"
LOGS = VDIR / "logs"
VENV_PY = str(G2 / ".venv/bin/python")


def _fixture_password():
    src = (G2 / "tools/setup_db.py").read_text()
    return re.search(r"CREATE ROLE factory LOGIN PASSWORD '([^']+)'",
                     src).group(1)


PW = _fixture_password()
DB1, DB2 = "mm04_verify_scratch", "mm04_verify_unseeded"
DSN1 = f"host=127.0.0.1 dbname={DB1} user=factory password={PW}"
DSN2 = f"host=127.0.0.1 dbname={DB2} user=factory password={PW}"
API, WORKER, EVAL = ("http://127.0.0.1:8930", "http://127.0.0.1:8995",
                     "http://127.0.0.1:8996")
API2, WORKER2 = "http://127.0.0.1:8931", "http://127.0.0.1:8997"
EVAL2 = "http://127.0.0.1:8998"
TOKENS = {"FACTORY_API_TOKEN": "mm04v-operator-token",
          "FACTORY_WORKER_TOKEN": "mm04v-worker-token",
          "FACTORY_SCHEDULER_TOKEN": "mm04v-scheduler-token",
          "FACTORY_VALIDATOR_TOKEN": "mm04v-validator-token",
          "FACTORY_CALLBACK_TOKEN": "mm04v-callback-token"}
OPERATOR = TOKENS["FACTORY_API_TOKEN"]
DRIVER = "mm04v-driver"
CRED_VALUE = "mm04v-dummy-credential-9d2"
CANON_TEXT = ("MM04V-CANON-SECRET-MARKER-7f3 verifier canon fixture: "
              "the Wren archive, its keepers, and the north stair.")
PRIMARY, FALLBACK, TINY, GHOST = ("verify/primary", "verify/fallback",
                                  "verify/tiny", "verify/ghost")
SLICE_MODEL = "verify/slice-model"
PVERSION = "verify-mm04"

SCRIPT_JSON = {
    "kind": "script",
    "lines": [
        {"id": "L1", "scene_ref": "SC1", "beat_ref": "B1",
         "story_ref": "S1", "canon_refs": ["bogus-from-stub"],
         "text": "Wren lifts the lantern on the north stair."},
        {"id": "L2", "scene_ref": "SC2", "beat_ref": "B2",
         "story_ref": "S2", "canon_refs": ["bogus-from-stub"],
         "text": "Pell seals the archive with black wax."},
        {"id": "L3", "scene_ref": "SC1",
         "text": "The north stair is empty."}],
    "trace": {
        "clues": [{"id": "CL1", "planted": "L1", "payoff": "L3"}],
        "knowledge": [{"character": "Wren", "learns": "CL1", "at": "L2"}],
        "payoffs": [{"id": "PO1", "clue": "CL1", "line": "L3"}]},
    "canon_refs": ["bogus-from-stub"]}


# ------------------------------------------------------------------ stub
class Stub:
    """Verifier-owned provider stub. Records every chat call (model,
    X-Correlation-Id header), submit calls, and chat in-flight max.
    Behavior: self.script[model] = list of (status, usage) consumed in
    order; self.fail_models = {model: usage} -> always 500 with usage;
    otherwise 200 with self.ok_usage and the script content."""

    def __init__(self):
        self.chat = []          # {model, corr, at}
        self.submits = []       # at
        self.script = {}
        self.fail_models = {}
        self.ok_usage = {"prompt_tokens": 40, "completion_tokens": 15}
        self.slow_s = 0.0
        self.inflight = 0
        self.max_inflight = 0
        self.lock = threading.Lock()
        stub = self

        class H(BaseHTTPRequestHandler):
            def log_message(self, *a):
                pass

            def _send(self, status, obj):
                raw = json.dumps(obj).encode()
                self.send_response(status)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(raw)))
                self.end_headers()
                self.wfile.write(raw)

            def do_POST(self):
                n = int(self.headers.get("Content-Length") or 0)
                body = json.loads(self.rfile.read(n) or b"{}")
                if self.path == "/submit":
                    with stub.lock:
                        stub.submits.append(time.time())
                    time.sleep(1.5)
                    return self._send(500, {"error": "submit down"})
                if self.path != "/chat/completions":
                    return self._send(404, {"error": "no route"})
                model = body.get("model")
                with stub.lock:
                    stub.inflight += 1
                    stub.max_inflight = max(stub.max_inflight,
                                            stub.inflight)
                    stub.chat.append(
                        {"model": model,
                         "corr": self.headers.get("X-Correlation-Id"),
                         "at": time.time()})
                try:
                    if stub.slow_s:
                        time.sleep(stub.slow_s)
                    with stub.lock:
                        queue = stub.script.get(model) or []
                        step = queue.pop(0) if queue else None
                        failing = model in stub.fail_models
                        fail_usage = stub.fail_models.get(model)
                    if failing:
                        return self._send(500, {
                            "error": {"message": "verify stub: down"},
                            "usage": fail_usage})
                    if step is not None:
                        status, usage = step
                        if status != 200:
                            return self._send(status, {
                                "error": {"message":
                                          f"verify stub: http {status}"},
                                "usage": usage})
                        return self._send(200, {
                            "id": "req-verify-ok",
                            "choices": [{"message": {
                                "content": json.dumps(SCRIPT_JSON)}}],
                            "usage": usage})
                    return self._send(200, {
                        "id": "req-verify-default",
                        "choices": [{"message": {
                            "content": json.dumps(SCRIPT_JSON)}}],
                        "usage": stub.ok_usage})
                finally:
                    with stub.lock:
                        stub.inflight -= 1

            def do_GET(self):
                return self._send(200, {"status": "PROCESSING"})

        self.httpd = ThreadingHTTPServer(("127.0.0.1", 0), H)
        self.port = self.httpd.server_address[1]
        threading.Thread(target=self.httpd.serve_forever,
                         daemon=True).start()

    @property
    def url(self):
        return f"http://127.0.0.1:{self.port}"

    def chat_count(self, model=None):
        with self.lock:
            return len([c for c in self.chat
                        if model is None or c["model"] == model])

    def chat_since(self, idx, model=None):
        with self.lock:
            return [c for c in self.chat[idx:]
                    if model is None or c["model"] == model]

    def submit_count(self):
        with self.lock:
            return len(self.submits)


STUB = Stub()


# ------------------------------------------------------------------ http
def call(base, method, path, body=None, role=None, identity=None,
         timeout=60):
    req = urllib.request.Request(base + path, method=method)
    data = None
    if role == "OPERATOR":
        req.add_header("X-Operator-Token", OPERATOR)
    elif role == "WORKER":
        req.add_header("X-Role", "WORKER")
        req.add_header("X-Role-Token", TOKENS["FACTORY_WORKER_TOKEN"])
        req.add_header("X-Identity", identity or DRIVER)
    if body is not None:
        data = json.dumps(body).encode()
        req.add_header("Content-Type", "application/json")
    try:
        with urllib.request.urlopen(req, data=data, timeout=timeout) as r:
            return r.status, json.loads(r.read() or b"{}")
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read() or b"{}")


def db(dsn, sql, args=()):
    with psycopg.connect(dsn, row_factory=dict_row, autocommit=True) as c:
        cur = c.execute(sql, args)
        try:
            return cur.fetchall()
        except psycopg.errors.ProgrammingError:
            return []


def kill_port(port):
    subprocess.run(["fuser", "-k", f"{port}/tcp"], capture_output=True)
    time.sleep(0.5)


def spawn(cmd, env, log_name):
    e = dict(os.environ)
    e.update(env)
    out = open(LOGS / log_name, "ab")
    return subprocess.Popen(cmd, env=e, stdout=out, stderr=out,
                            start_new_session=True)


def wait_url(url, seconds=60):
    deadline = time.time() + seconds
    while time.time() < deadline:
        try:
            with urllib.request.urlopen(url, timeout=2) as r:
                if r.status == 200:
                    return True
        except Exception:  # noqa: BLE001
            pass
        time.sleep(0.5)
    return False


# ---------------------------------------------------------------- checks
class Scenario:
    def __init__(self, name):
        self.name = name
        self.checks = []

    def check(self, name, ok, detail=""):
        self.checks.append({"name": name, "pass": bool(ok),
                            "detail": str(detail)[:600]})
        print(f"  [{'PASS' if ok else 'FAIL'}] {name} - {detail}",
              flush=True)

    def finish(self, extra=None):
        verdict = all(c["pass"] for c in self.checks)
        doc = {"scenario": self.name,
               "verdict": "PASS" if verdict else "FAIL",
               "label": "STUB_TESTED", "checks": self.checks,
               **(extra or {})}
        RESULTS.mkdir(parents=True, exist_ok=True)
        (RESULTS / f"{self.name}.json").write_text(
            json.dumps(doc, indent=1, sort_keys=True))
        print(f"{self.name}: {'PASS' if verdict else 'FAIL'} "
              f"({sum(1 for c in self.checks if c['pass'])}/"
              f"{len(self.checks)})", flush=True)
        return 0 if verdict else 1


# ---------------------------------------------------------------- driver
def unit_row(api, pid, uid):
    _, out = call(api, "GET", f"/productions/{pid}/units", role="OPERATOR")
    return [u for u in out["units"] if u["unit_id"] == uid][0]


def wait_state(api, pid, uid, states, timeout=90):
    deadline = time.time() + timeout
    state = None
    while time.time() < deadline:
        state = unit_row(api, pid, uid)["state"]
        if state in states:
            return state
        time.sleep(0.5)
    raise AssertionError(f"unit {uid} stuck in {state}, wanted {states}")


def current_artifacts(api, pid):
    _, out = call(api, "GET", f"/productions/{pid}/artifacts",
                  role="OPERATOR")
    return {a["artifact_type"]: a for a in out["artifacts"]
            if a["state"] == "CURRENT"}


def wire_ref(art):
    return {"artifact_type": art["artifact_type"],
            "artifact_id": art["artifact_id"], "sha256": art["sha256"]}


FIXTURE_RUNS = {}


def make_fixture(api, tag):
    _, p = call(api, "POST", "/productions",
                {"title": f"MM-04 verifier ({tag})",
                 "hard_ceiling_cents": 5000, "soft_ceiling_cents": 4500},
                role="OPERATOR")
    pid = p["production_id"]
    _, r = call(api, "POST", f"/productions/{pid}/runs", {"kind": "FULL"},
                role="OPERATOR")
    run = r["run_id"]
    FIXTURE_RUNS[pid] = run
    _, a = call(api, "POST", f"/productions/{pid}/artifacts",
                {"artifact_type": "canon_manifest", "content": CANON_TEXT,
                 "storage_uri": "local://canon-fixture"}, role="OPERATOR")
    canon = a["artifact_id"]

    def plan(op, key, depends=()):
        _, u = call(api, "POST", f"/productions/{pid}/units",
                    {"operation_id": op, "run_id": run, "unit_key": key,
                     "depends_on": list(depends),
                     "input_artifact_ids": [canon]}, role="OPERATOR")
        return u["unit_id"]

    units = {}
    units["05.12"] = plan("05.12", "main")
    units["06.12"] = plan("06.12", "main", [units["05.12"]])
    units["07.12"] = plan("07.12", "main", [units["06.12"]])
    units["08.12"] = plan("08.12", "main", [units["07.12"]])
    return pid, canon, units


def claim_and_binding(api, uid):
    _, claim = call(api, "POST", f"/units/{uid}/claim",
                    {"worker_id": DRIVER}, role="OPERATOR")
    _, attempts = call(api, "GET", f"/units/{uid}/attempts",
                       role="OPERATOR")
    return claim, attempts["attempts"][0]["resolved_config"]


def work(worker, pid, uid, op, claim, binding, refs):
    body = {"provider_binding": binding, "operation_id": op,
            "production_id": pid, "unit_id": uid,
            "attempt_id": claim["attempt_id"],
            "fencing_token": claim["fencing_token"], "worker_id": DRIVER,
            "input_artifact_refs": refs}
    return call(worker, "POST", "/work", body)


def evaluate_and_approve(api, pid, uid, eval_base=None):
    call(eval_base or EVAL, "POST", "/evaluate", {"unit_id": uid})
    state = wait_state(api, pid, uid, {"ACCEPTED", "AWAITING_HUMAN",
                                       "FAILED", "BLOCKED", "RETRY_WAIT"})
    if state == "AWAITING_HUMAN":
        call(api, "POST", f"/units/{uid}/events",
             {"event": "human_approved"}, role="OPERATOR")
        state = wait_state(api, pid, uid, {"ACCEPTED"})
    return state


def drive_chain_unit(api, worker, pid, uid, op, refs, eval_base=None):
    wait_state(api, pid, uid, {"READY"})
    claim, binding = claim_and_binding(api, uid)
    status, out = work(worker, pid, uid, op, claim, binding, refs)
    assert status == 200 and out.get("status") == "COMPLETED", (op, out)
    body = {"worker_id": DRIVER, "fencing_token": claim["fencing_token"],
            "artifact_type": out["artifact_type"],
            "content": out["content"],
            "actual_cost_cents": out["actual_cost_cents"]}
    call(api, "POST", f"/units/{uid}/complete", body, role="OPERATOR")
    state = evaluate_and_approve(api, pid, uid, eval_base)
    assert state == "ACCEPTED", (op, state)
    return current_artifacts(api, pid)


def drive_fixture_chain(api, worker, pid, canon_id, units,
                        eval_base=None):
    _, arts = call(api, "GET", f"/productions/{pid}/artifacts",
                   role="OPERATOR")
    canon_row = [a for a in arts["artifacts"]
                 if a["artifact_id"] == canon_id][0]
    have = {"canon_manifest": canon_row}
    refs = [wire_ref(canon_row)]
    for op in ("05.12", "06.12", "07.12"):
        have = drive_chain_unit(api, worker, pid, units[op], op, refs,
                                eval_base)
        refs = [wire_ref(have[t]) for t in
                ("canon_manifest", "story_architecture", "beat_graph",
                 "scene_set") if t in have]
    return have, refs


def gen_record(dsn, uid):
    rows = db(dsn, "SELECT action_key, status, output_summary, error "
                   "FROM plan_action_attempts WHERE unit_id=%s "
                   "ORDER BY seq", (uid,))
    rows = [r for r in rows if r["action_key"] == "op.build"]
    if not rows:
        return {}
    rec = dict(rows[0])
    summ = rec.get("output_summary") or {}
    if isinstance(summ, str):
        summ = json.loads(summ)
    rec["output_summary"] = summ
    return rec


def evidence_by_class(dsn, attempt_id):
    rows = db(dsn, "SELECT charge_class, amount_cents, pricing_version "
                   "FROM financial_evidence WHERE attempt_id=%s "
                   "ORDER BY created_at", (attempt_id,))
    return {r["charge_class"]: r for r in rows}


# ---------------------------------------------------------------- seeding
def post_config(api, want):
    status, out = call(api, "POST", "/configs", want, role="OPERATOR")
    assert status in (200, 201), (status, out)


def binding_0812(api, model, retry_policy=None, params_extra=None,
                 timeout_s=60):
    params = {"base_url": STUB.url}
    params.update(params_extra or {})
    post_config(api, {"scope": "OPERATION", "operation_id": "08.12",
                      "environment": "test",
                      "provider": "openrouter-compatible",
                      "model": model, "modality": "text",
                      "credential_ref": "VERIFY_MM04_KEY",
                      "est_cost_cents": 25, "timeout_s": timeout_s,
                      "params": params,
                      "retry_policy": retry_policy or
                      {"base_s": 0.05, "max_s": 0.2}})


def seed_stack1():
    db(DSN1, "DELETE FROM operation_model_assignments "
             "WHERE operation_id='08.12'")
    db(DSN1, "DELETE FROM models WHERE model_id LIKE 'verify/%%'")
    for mid, ctx in ((PRIMARY, 100000), (FALLBACK, 100000), (TINY, 10)):
        db(DSN1, "INSERT INTO models(model_id, provider, context_length)"
                 " VALUES (%s, 'verify', %s)", (mid, ctx))
    post_config(API, {"scope": "STATION", "station": 3,
                      "environment": "test",
                      "provider": "deterministic-local",
                      "est_cost_cents": 100,
                      "params": {"reported_actual_cents": 90}})
    binding_0812(API, PRIMARY)
    post_config(API, {"scope": "OPERATION", "operation_id": "01.04",
                      "environment": "test", "provider": "direct-http-text",
                      "modality": "text",
                      "credential_ref": "VERIFY_MM04_KEY",
                      "est_cost_cents": 100, "timeout_s": 60,
                      "params": {"submit_endpoint": STUB.url + "/submit",
                                 "poll_endpoint":
                                     STUB.url + "/poll/{job_id}",
                                 "mode": "async"},
                      "retry_policy": {"base_s": 3, "max_s": 30}})
    for model, rin, rout in ((PRIMARY, "0.03", "0.04"),
                             (FALLBACK, "0.0011", "0.0022")):
        for unit_kind, price in (("input_token", rin),
                                 ("output_token", rout)):
            status, out = call(API, "POST", "/pricing-rules",
                               {"provider": "openrouter-compatible",
                                "model": model, "modality": "text",
                                "unit_kind": unit_kind,
                                "unit_price_cents": price,
                                "pricing_version": PVERSION},
                               role="OPERATOR")
            assert status in (200, 201), (status, out)
    print("stack1 seeded: models/bindings/pricing (verifier fixtures)",
          flush=True)


def set_assignment(active, fallback=True):
    db(DSN1, "DELETE FROM operation_model_assignments "
             "WHERE operation_id='08.12'")
    if active:
        db(DSN1, "INSERT INTO operation_model_assignments"
                 "(operation_id, role, primary_model, fallback_model,"
                 " matrix_version, status) VALUES ('08.12', 'generation',"
                 " %s, %s, 'verify-1', 'ACTIVE')",
           (PRIMARY, FALLBACK if fallback else None))


# -------------------------------------------------------------- scenarios
def s_retries():
    """Item 2: 500,500,200 -> success, usage SUM, one correlation id;
    400 -> exactly 1 call + immediate typed failure."""
    sc = Scenario("v2_retries_usage_sum")
    set_assignment(False)
    binding_0812(API, PRIMARY)
    pid, canon_id, units = make_fixture(API, "retries")
    drive_fixture_chain(API, WORKER, pid, canon_id, units)
    uid = units["08.12"]
    wait_state(API, pid, uid, {"READY"})
    claim, binding = claim_and_binding(API, uid)
    have = current_artifacts(API, pid)
    refs = [wire_ref(have[t]) for t in
            ("canon_manifest", "story_architecture", "beat_graph",
             "scene_set") if t in have]
    STUB.script[PRIMARY] = [
        (500, {"prompt_tokens": 111, "completion_tokens": 22}),
        (500, {"prompt_tokens": 111, "completion_tokens": 22}),
        (200, {"prompt_tokens": 333, "completion_tokens": 44})]
    mark = STUB.chat_count()
    status, out = work(WORKER, pid, uid, "08.12", claim, binding, refs)
    calls = STUB.chat_since(mark, PRIMARY)
    sc.check("/work succeeds after exactly 3 scripted calls "
             "(500,500,200)", status == 200
             and out.get("status") == "COMPLETED"
             and len(calls) == 3,
             f"status={status} calls={len(calls)}")
    corrs = {c["corr"] for c in calls}
    sc.check("X-Correlation-Id identical across all 3 stub calls",
             len(corrs) == 1 and None not in corrs, f"corrs={corrs}")
    usage = out.get("usage") or {}
    sc.check("completion usage == SUM of all three usage bodies "
             "(111+111+333=555 in, 22+22+44=88 out)",
             usage.get("input_tokens") == 555
             and usage.get("output_tokens") == 88, f"usage={usage}")
    rec = gen_record(DSN1, uid)
    lines = (rec.get("output_summary") or {}).get("usage_lines") or []
    sc.check("action record: 3 usage lines (error,error,success), "
             "chain correlation matches the stub header",
             len(lines) == 3
             and [l.get("outcome") for l in lines] ==
             ["error", "error", "success"]
             and lines[0].get("correlation_id") in corrs,
             f"lines={[(l.get('outcome'), l.get('usage')) for l in lines]}")
    # 400 -> one call, immediate typed failure
    pid2, canon2, units2 = make_fixture(API, "http400")
    drive_fixture_chain(API, WORKER, pid2, canon2, units2)
    uid2 = units2["08.12"]
    wait_state(API, pid2, uid2, {"READY"})
    claim2, binding2 = claim_and_binding(API, uid2)
    have2 = current_artifacts(API, pid2)
    refs2 = [wire_ref(have2[t]) for t in
             ("canon_manifest", "story_architecture", "beat_graph",
              "scene_set") if t in have2]
    STUB.script[PRIMARY] = [(400, {"prompt_tokens": 5,
                                   "completion_tokens": 1})]
    mark = STUB.chat_count()
    t0 = time.time()
    status, out = work(WORKER, pid2, uid2, "08.12", claim2, binding2, refs2)
    elapsed = time.time() - t0
    delta = len(STUB.chat_since(mark, PRIMARY))
    sc.check("400 -> exactly 1 call + immediate typed failure "
             "PROVIDER_HTTP_400 (no retry)",
             status != 200
             and out.get("error_class") == "PROVIDER_HTTP_400"
             and delta == 1 and elapsed < 10,
             f"status={status} class={out.get('error_class')} "
             f"calls={delta} elapsed={elapsed:.1f}s")
    return sc.finish({"production_id": pid, "unit_08_12": uid,
                      "summed_usage": usage,
                      "correlation_id": list(corrs)})


def s_fallback():
    """Item 3: fallback money path + the negative pair."""
    sc = Scenario("v3_fallback_money")
    set_assignment(True)
    binding_0812(API, PRIMARY)
    pid, canon_id, units = make_fixture(API, "fallback")
    drive_fixture_chain(API, WORKER, pid, canon_id, units)
    uid = units["08.12"]
    wait_state(API, pid, uid, {"READY"})
    claim, binding = claim_and_binding(API, uid)
    sc.check("claim snapshot pins the ACTIVE assignment (fallback "
             "named)", (binding.get("model_assignment") or {}).get(
                 "fallback_model") == FALLBACK,
             f"assignment={binding.get('model_assignment')}")
    have = current_artifacts(API, pid)
    refs = [wire_ref(have[t]) for t in
            ("canon_manifest", "story_architecture", "beat_graph",
             "scene_set") if t in have]
    STUB.fail_models[PRIMARY] = {"prompt_tokens": 10,
                                 "completion_tokens": 5}
    STUB.script[FALLBACK] = [(200, {"prompt_tokens": 2000,
                                    "completion_tokens": 700})]
    mark = STUB.chat_count()
    status, out = work(WORKER, pid, uid, "08.12", claim, binding, refs)
    got_p = len(STUB.chat_since(mark, PRIMARY))
    got_f = len(STUB.chat_since(mark, FALLBACK))
    sc.check("/work 200 via fallback: primary 3 calls (1+2 retries), "
             "fallback exactly 1", status == 200 and got_p == 3
             and got_f == 1,
             f"status={status} primary={got_p} fallback={got_f}")
    rec = gen_record(DSN1, uid)
    summ = rec.get("output_summary") or {}
    fev = summ.get("fallback_event") or {}
    sc.check("fallback event names primary + fallback + trigger; "
             "record model = fallback",
             fev.get("primary_model") == PRIMARY
             and fev.get("fallback_model") == FALLBACK
             and fev.get("trigger_class") == "PROVIDER_HTTP_500"
             and summ.get("model") == FALLBACK, f"event={fev}")
    usage = out.get("usage") or {}
    sc.check("chain usage summed (3x10+2000=2030 in, 3x5+700=715 out)",
             usage.get("input_tokens") == 2030
             and usage.get("output_tokens") == 715, f"usage={usage}")
    body = {"worker_id": DRIVER, "fencing_token": claim["fencing_token"],
            "artifact_type": out["artifact_type"],
            "content": out["content"],
            "actual_cost_cents": out["actual_cost_cents"],
            "usage": usage,
            "provider_request_id": out.get("provider_request_id"),
            "model": summ.get("model")}
    call(API, "POST", f"/units/{uid}/complete", body, role="OPERATOR")
    ev = evidence_by_class(DSN1, claim["attempt_id"])
    calc = (ev.get("CALCULATED") or {}).get("amount_cents")
    fin = (ev.get("FINALIZED") or {}).get("amount_cents")
    # fallback rates: 2030x0.0011 + 715x0.0022 = 2.233+1.573 = 3.806 -> 4
    # primary rates would be: 2030x0.03 + 715x0.04 = 60.9+28.6 = 89.5 -> 90
    sc.check("CALCULATED == 4c at FALLBACK rates (not 90c at primary "
             "rates); FINALIZED == CALCULATED",
             calc == 4 and calc != 90 and fin == 4,
             f"calc={calc} fin={fin} ev={ev}")
    # negative (i): no assignment -> failure, fallback never called
    set_assignment(False)
    pid2, canon2, units2 = make_fixture(API, "fallback-negative")
    drive_fixture_chain(API, WORKER, pid2, canon2, units2)
    uid2 = units2["08.12"]
    wait_state(API, pid2, uid2, {"READY"})
    claim2, binding2 = claim_and_binding(API, uid2)
    have2 = current_artifacts(API, pid2)
    refs2 = [wire_ref(have2[t]) for t in
             ("canon_manifest", "story_architecture", "beat_graph",
              "scene_set") if t in have2]
    mark = STUB.chat_count()
    status, out = work(WORKER, pid2, uid2, "08.12", claim2, binding2,
                       refs2)
    got_p = len(STUB.chat_since(mark, PRIMARY))
    got_f = len(STUB.chat_since(mark, FALLBACK))
    sc.check("NEGATIVE no-assignment: typed failure; stub saw ONLY "
             "primary calls (3), fallback calls 0",
             status != 200
             and out.get("error_class") == "PROVIDER_HTTP_500"
             and got_p == 3 and got_f == 0,
             f"status={status} primary={got_p} fallback={got_f}")
    # negative (ii): context refusal with a fallback named -> no calls
    set_assignment(True)
    binding_0812(API, TINY)
    pid3, canon3, units3 = make_fixture(API, "fallback-ctx-negative")
    drive_fixture_chain(API, WORKER, pid3, canon3, units3)
    uid3 = units3["08.12"]
    wait_state(API, pid3, uid3, {"READY"})
    claim3, binding3 = claim_and_binding(API, uid3)
    have3 = current_artifacts(API, pid3)
    refs3 = [wire_ref(have3[t]) for t in
             ("canon_manifest", "story_architecture", "beat_graph",
              "scene_set") if t in have3]
    mark = STUB.chat_count()
    status, out = work(WORKER, pid3, uid3, "08.12", claim3, binding3,
                       refs3)
    delta = len(STUB.chat_since(mark))
    sc.check("NEGATIVE context-limit with fallback named: refusal, "
             "primary calls 0 AND fallback calls 0",
             out.get("error_class") == "CONTEXT_LIMIT" and delta == 0,
             f"class={out.get('error_class')} calls={delta}")
    STUB.fail_models.pop(PRIMARY, None)
    return sc.finish({"production_id": pid, "unit_08_12": uid,
                      "calculated_cents": calc})


def s_context():
    """Item 1 (seeded registry): CONTEXT_LIMIT + MODEL_UNKNOWN, both
    before any HTTP, refusal evidence in the action record."""
    sc = Scenario("v1_context_and_unknown")
    rows = db(DSN1, "SELECT count(*) AS n FROM models")
    sc.check("MM-03 registry seeded in the worker DB (models > 0)",
             rows and rows[0]["n"] > 0, f"models={rows[0]['n']}")
    binding_0812(API, TINY)
    pid, canon_id, units = make_fixture(API, "context-limit")
    drive_fixture_chain(API, WORKER, pid, canon_id, units)
    uid = units["08.12"]
    wait_state(API, pid, uid, {"READY"})
    claim, binding = claim_and_binding(API, uid)
    sc.check("claim resolves the tiny-context model",
             binding.get("model") == TINY, f"model={binding.get('model')}")
    have = current_artifacts(API, pid)
    refs = [wire_ref(have[t]) for t in
            ("canon_manifest", "story_architecture", "beat_graph",
             "scene_set") if t in have]
    mark = STUB.chat_count()
    status, out = work(WORKER, pid, uid, "08.12", claim, binding, refs)
    delta = len(STUB.chat_since(mark))
    sc.check("CONTEXT_LIMIT refusal BEFORE any HTTP (stub calls 0)",
             out.get("error_class") == "CONTEXT_LIMIT" and delta == 0,
             f"status={status} class={out.get('error_class')} "
             f"calls={delta}")
    rec = gen_record(DSN1, uid)
    summ = rec.get("output_summary") or {}
    lines = summ.get("usage_lines") or []
    sc.check("action record carries the refusal evidence (FAILED, "
             "CONTEXT_LIMIT, one 'refused' line, estimate > 10)",
             rec.get("status") == "FAILED"
             and summ.get("error_class") == "CONTEXT_LIMIT"
             and len(lines) == 1
             and lines[0].get("outcome") == "refused"
             and (lines[0].get("estimated_prompt_tokens") or 0) > 10,
             f"rec_status={rec.get('status')} lines={lines}")
    _, arts = call(API, "GET", f"/productions/{pid}/artifacts",
                   role="OPERATOR")
    sc.check("zero script artifacts after the refusal",
             not any(a["artifact_type"] == "script"
                     for a in arts["artifacts"]), "")
    # unknown model
    binding_0812(API, GHOST)
    pid2, canon2, units2 = make_fixture(API, "model-unknown")
    drive_fixture_chain(API, WORKER, pid2, canon2, units2)
    uid2 = units2["08.12"]
    wait_state(API, pid2, uid2, {"READY"})
    claim2, binding2 = claim_and_binding(API, uid2)
    have2 = current_artifacts(API, pid2)
    refs2 = [wire_ref(have2[t]) for t in
             ("canon_manifest", "story_architecture", "beat_graph",
              "scene_set") if t in have2]
    mark = STUB.chat_count()
    status, out = work(WORKER, pid2, uid2, "08.12", claim2, binding2,
                       refs2)
    delta = len(STUB.chat_since(mark))
    rec2 = gen_record(DSN1, uid2)
    summ2 = rec2.get("output_summary") or {}
    sc.check("unknown model -> MODEL_UNKNOWN refusal, 0 stub calls, "
             "refusal in the action record",
             out.get("error_class") == "MODEL_UNKNOWN" and delta == 0
             and summ2.get("error_class") == "MODEL_UNKNOWN",
             f"class={out.get('error_class')} calls={delta}")
    binding_0812(API, PRIMARY)
    return sc.finish({"production_id": pid, "unit_08_12": uid})


def s_cancel():
    """Item 4: async job cancellation — OPERATOR, idempotent repeat,
    wrong-identity worker refusal + audit; migration 017 shape."""
    sc = Scenario("v4_cancellation")
    cons = db(DSN1, "SELECT pg_get_constraintdef(oid) AS def FROM "
                    "pg_constraint WHERE conrelid='provider_jobs'::regclass"
                    " AND contype='c'")
    defs = " ".join(r["def"] for r in cons)
    sc.check("provider_jobs status CHECK in the built DB includes "
             "CANCELLED alongside the original seven values",
             "CANCELLED" in defs and "SUBMITTED" in defs
             and "NOT_FOUND" in defs, defs[:200])
    _, p = call(API, "POST", "/productions",
                {"title": "MM-04 verifier (cancel)",
                 "hard_ceiling_cents": 5000, "soft_ceiling_cents": 4500},
                role="OPERATOR")
    pid = p["production_id"]
    _, r = call(API, "POST", f"/productions/{pid}/runs", {"kind": "FULL"},
                role="OPERATOR")
    _, u = call(API, "POST", f"/productions/{pid}/units",
                {"operation_id": "01.04", "run_id": r["run_id"],
                 "unit_key": "main"}, role="OPERATOR")
    uid = u["unit_id"]
    wait_state(API, pid, uid, {"READY"})
    claim, binding = claim_and_binding(API, uid)
    call(API, "POST", f"/units/{uid}/events",
         {"event": "start", "worker_id": DRIVER}, role="WORKER")
    _, job = call(API, "POST", "/provider-jobs",
                  {"unit_id": uid, "attempt_id": claim["attempt_id"],
                   "fencing_token": claim["fencing_token"],
                   "idempotency_key": "mm04v-cancel-1"}, role="WORKER")
    job_id = job["job_id"]
    sc.check("provider job registered; unit AWAITING_PROVIDER",
             unit_row(API, pid, uid)["state"] == "AWAITING_PROVIDER",
             f"job={job_id}")
    # wrong-identity worker cancel FIRST (job still live)
    status, out = call(API, "POST", f"/provider-jobs/{job_id}/cancel",
                       {"worker_id": "mallory-verify"}, role="WORKER",
                       identity="mallory-verify")
    audits = db(DSN1, "SELECT count(*) AS n FROM audit_events WHERE "
                      "unit_id=%s AND event_type="
                      "'provider_job_cancel_refused'", (uid,))
    _, jobs = call(API, "GET", f"/units/{uid}/provider-jobs",
                   role="OPERATOR")
    job_row = [j for j in jobs["provider_jobs"]
               if j["job_id"] == job_id][0]
    sc.check("wrong-identity WORKER cancel refused (403) + committed "
             "provider_job_cancel_refused audit; job NOT cancelled",
             status == 403 and audits[0]["n"] >= 1
             and job_row["status"] != "CANCELLED",
             f"status={status} audits={audits[0]['n']} "
             f"job={job_row['status']}")
    outcome = {}

    def worker_call():
        body = {"provider_binding": binding, "operation_id": "01.04",
                "production_id": pid, "unit_id": uid,
                "attempt_id": claim["attempt_id"],
                "fencing_token": claim["fencing_token"],
                "idempotency_key": "mm04v-cancel-work"}
        outcome["result"] = call(WORKER, "POST", "/jobs", body)
    t = threading.Thread(target=worker_call)
    t.start()
    deadline = time.time() + 15
    while STUB.submit_count() < 1 and time.time() < deadline:
        time.sleep(0.05)
    sc.check("worker submit chain in flight (stub submit count 1)",
             STUB.submit_count() == 1, f"count={STUB.submit_count()}")
    status, out = call(API, "POST", f"/provider-jobs/{job_id}/cancel",
                       {"correlation_id": "mm04v-cancel"},
                       role="OPERATOR")
    sc.check("OPERATOR cancel accepted; job CANCELLED",
             status == 200 and out.get("job_status") == "CANCELLED",
             f"status={status} out={out}")
    status2, out2 = call(API, "POST", f"/provider-jobs/{job_id}/cancel",
                         {"correlation_id": "mm04v-cancel-again"},
                         role="OPERATOR")
    sc.check("repeat cancel idempotent (200, already_cancelled, "
             "still CANCELLED)",
             status2 == 200 and out2.get("already_cancelled") is True
             and out2.get("job_status") == "CANCELLED",
             f"status={status2} out={out2}")
    t.join(timeout=30)
    wstatus, wout = outcome.get("result", (None, {}))
    sc.check("worker chain stopped with typed CANCELLED",
             wstatus == 502 and wout.get("error_class") == "CANCELLED",
             f"status={wstatus} class={wout.get('error_class')}")
    time.sleep(4)
    sc.check("stub submit count frozen after the backoff window "
             "(queued retry never fired)", STUB.submit_count() == 1,
             f"count={STUB.submit_count()}")
    attempts = db(DSN1, "SELECT status, error_class FROM action_attempts "
                        "WHERE attempt_id=%s", (claim["attempt_id"],))
    _, jobs = call(API, "GET", f"/units/{uid}/provider-jobs",
                   role="OPERATOR")
    job_row = [j for j in jobs["provider_jobs"]
               if j["job_id"] == job_id][0]
    sc.check("terminal rows: job CANCELLED; attempt FAILED/CANCELLED;"
             " unit RETRY_WAIT",
             job_row["status"] == "CANCELLED" and attempts
             and attempts[0]["status"] == "FAILED"
             and attempts[0]["error_class"] == "CANCELLED"
             and unit_row(API, pid, uid)["state"] == "RETRY_WAIT",
             f"job={job_row['status']} attempts={attempts} "
             f"unit={unit_row(API, pid, uid)['state']}")
    return sc.finish({"production_id": pid, "unit_id": uid,
                      "job_id": job_id})


def s_runc():
    """Item 7: Phase 3 run-c shape with PRODUCTION retry_policy
    (base_s 30) + patient client -> typed terminal failure in DB."""
    sc = Scenario("v7_runc_terminal_state")
    set_assignment(False)
    binding_0812(API, PRIMARY, retry_policy={"base_s": 30, "max_s": 900},
                 timeout_s=120)
    pid, canon_id, units = make_fixture(API, "run-c")
    drive_fixture_chain(API, WORKER, pid, canon_id, units)
    uid = units["08.12"]
    wait_state(API, pid, uid, {"READY"})
    claim, binding = claim_and_binding(API, uid)
    have = current_artifacts(API, pid)
    refs = [wire_ref(have[t]) for t in
            ("canon_manifest", "story_architecture", "beat_graph",
             "scene_set") if t in have]
    STUB.fail_models[PRIMARY] = {"prompt_tokens": 10,
                                 "completion_tokens": 5}
    mark = STUB.chat_count()
    t0 = time.time()
    status, out = call(WORKER, "POST", "/work",
                       {"provider_binding": binding,
                        "operation_id": "08.12", "production_id": pid,
                        "unit_id": uid, "attempt_id": claim["attempt_id"],
                        "fencing_token": claim["fencing_token"],
                        "worker_id": DRIVER, "input_artifact_refs": refs},
                       timeout=300)
    elapsed = time.time() - t0
    delta = len(STUB.chat_since(mark, PRIMARY))
    sc.check("patient client receives the typed failure (502 "
             "PROVIDER_HTTP_500) after the production-policy retries "
             "(3 calls, ~90s of backoff)",
             status == 502
             and out.get("error_class") == "PROVIDER_HTTP_500"
             and delta == 3 and elapsed >= 80,
             f"status={status} calls={delta} elapsed={elapsed:.0f}s")
    rec = gen_record(DSN1, uid)
    sc.check("generation action record FAILED (provider error)",
             rec.get("status") == "FAILED"
             and "500" in (rec.get("error") or ""),
             f"status={rec.get('status')} error={rec.get('error')}")
    _, arts = call(API, "GET", f"/productions/{pid}/artifacts",
                   role="OPERATOR")
    sc.check("zero script artifacts",
             not any(a["artifact_type"] == "script"
                     for a in arts["artifacts"]), "")
    ev = evidence_by_class(DSN1, claim["attempt_id"])
    sc.check("zero settlement (only the claim-time ESTIMATED row)",
             sorted(ev.keys()) == ["ESTIMATED"],
             f"classes={sorted(ev.keys())}")
    call(API, "POST", f"/units/{uid}/events",
         {"event": "transient_error", "worker_id": DRIVER}, role="WORKER")
    state = wait_state(API, pid, uid, {"RETRY_WAIT"})
    sc.check("unit terminal state RETRY_WAIT (recovery state, not "
             "ACCEPTED)", state == "RETRY_WAIT", f"state={state}")
    STUB.fail_models.pop(PRIMARY, None)
    binding_0812(API, PRIMARY)  # restore test-scaled policy
    return sc.finish({"production_id": pid, "unit_08_12": uid,
                      "elapsed_s": round(elapsed)})


def s_health_bypass():
    """Item 6: provider_health rows sane + secret-free; /work refuses
    without a valid claim context (no adapter call)."""
    sc = Scenario("v6_health_and_no_bypass")
    rows = db(DSN1, "SELECT provider, status, detail FROM "
                    "provider_health WHERE provider="
                    "'openrouter-compatible'")
    statuses = {r["status"] for r in rows}
    sc.check("provider_health rows exist for openrouter-compatible "
             "with ok + error + refused outcomes from this battery",
             {"ok", "error", "refused"} <= statuses,
             f"rows={len(rows)} statuses={sorted(statuses)}")
    dirty = [r for r in rows
             if "MM04V-CANON" in (r["detail"] or "")
             or CRED_VALUE in (r["detail"] or "")
             or "north stair" in (r["detail"] or "")
             or "Wren lifts" in (r["detail"] or "")]
    sc.check("no health detail carries prompt content or the "
             "credential value", not dirty, f"dirty={len(dirty)}")
    status, _ = call(WORKER, "POST", "/work", {})
    sc.check("/work with no binding/ids refused (400)",
             status == 400, f"status={status}")
    mark = STUB.chat_count()
    fake_binding = {"provider": "openrouter-compatible",
                    "model": PRIMARY, "modality": "text",
                    "credential_ref": "VERIFY_MM04_KEY",
                    "est_cost_cents": 25, "timeout_s": 30,
                    "params": {"base_url": STUB.url}}
    status, out = call(WORKER, "POST", "/work",
                       {"provider_binding": fake_binding,
                        "operation_id": "08.12",
                        "production_id": str(uuid.uuid4()),
                        "unit_id": str(uuid.uuid4()),
                        "attempt_id": str(uuid.uuid4()),
                        "fencing_token": 999, "worker_id": DRIVER,
                        "input_artifact_refs": []})
    delta = len(STUB.chat_since(mark))
    sc.check("/work with a fabricated claim context refused and the "
             "adapter never called (stub delta 0)",
             status != 200 and delta == 0,
             f"status={status} out={str(out)[:200]} calls={delta}")
    status, _ = call(WORKER, "GET", "/no-such-route")
    sc.check("worker exposes no other adapter entry point (unknown "
             "route 404)", status == 404, f"status={status}")
    return sc.finish({"provider_health_rows": len(rows)})


def s_concurrency():
    """Item 5: max_concurrency 2 (binding params) vs 6 parallel slow
    /work calls — stub-observed max in-flight <= 2, all complete.
    Runs against a FRESH worker process: limiter params come from the
    first binding seen per provider per process (documented)."""
    sc = Scenario("v5_concurrency_limit")
    kill_port(8995)
    spawn_worker(DSN1, WORKER, 8995, "verify_worker2.log")
    assert wait_url(WORKER + "/health"), "worker restart failed"
    binding_0812(API, PRIMARY,
                 params_extra={"max_concurrency": 2})
    pid, canon_id, units = make_fixture(API, "concurrency")
    drive_fixture_chain(API, WORKER, pid, canon_id, units)
    _, r = call(API, "GET", f"/productions/{pid}/runs", role="OPERATOR")
    have = current_artifacts(API, pid)
    refs = [wire_ref(have[t]) for t in
            ("canon_manifest", "story_architecture", "beat_graph",
             "scene_set") if t in have]
    canon = have["canon_manifest"]["artifact_id"]
    claims = []
    for i in range(6):
        _, u = call(API, "POST", f"/productions/{pid}/units",
                    {"operation_id": "08.12",
                     "run_id": units_run_id(pid),
                     "unit_key": f"c{i + 1}",
                     "depends_on": [units["07.12"]],
                     "input_artifact_ids": [canon]}, role="OPERATOR")
        uid = u["unit_id"]
        wait_state(API, pid, uid, {"READY"})
        claims.append((uid, *claim_and_binding(API, uid)))
    STUB.slow_s = 1.2
    STUB.max_inflight = 0
    STUB.script[PRIMARY] = []
    STUB.fail_models.pop(PRIMARY, None)
    mark = STUB.chat_count()
    results = {}

    def fire(idx, uid, claim, binding):
        results[idx] = work(WORKER, pid, uid, "08.12", claim, binding,
                            refs)
    threads = [threading.Thread(target=fire,
                                args=(i, uid, claim, binding))
               for i, (uid, claim, binding) in enumerate(claims)]
    t0 = time.time()
    for t in threads:
        t.start()
    for t in threads:
        t.join(timeout=120)
    elapsed = time.time() - t0
    STUB.slow_s = 0.0
    oks = sum(1 for s, o in results.values()
              if s == 200 and o.get("status") == "COMPLETED")
    calls = len(STUB.chat_since(mark, PRIMARY))
    sc.check("all six parallel /work calls complete successfully",
             oks == 6 and calls == 6,
             f"ok={oks}/6 calls={calls} elapsed={elapsed:.1f}s")
    sc.check("stub-observed max simultaneous in-flight <= 2 "
             "(max_concurrency 2 honored)",
             STUB.max_inflight <= 2,
             f"max_inflight={STUB.max_inflight}")
    return sc.finish({"max_inflight": STUB.max_inflight,
                      "elapsed_s": round(elapsed, 1)})


def units_run_id(pid):
    return FIXTURE_RUNS[pid]


def s_unseeded():
    """Item 1c: registry tables present but models EMPTY -> the
    Phase 3 slice mechanics behave exactly as the pre-MM-04 baseline
    (one stub call, CALCULATED from pricing rows, no refusal)."""
    sc = Scenario("v1c_unseeded_baseline")
    rows = db(DSN2, "SELECT count(*) AS n FROM models")
    sc.check("unseeded stack: models table EMPTY (feature not "
             "engaged)", rows[0]["n"] == 0, f"models={rows[0]['n']}")
    pid, canon_id, units = make_fixture(API2, "unseeded-slice")
    have, refs = drive_fixture_chain(API2, WORKER2, pid, canon_id,
                                     units, eval_base=EVAL2)
    uid = units["08.12"]
    wait_state(API2, pid, uid, {"READY"})
    claim, binding = claim_and_binding(API2, uid)
    mark = STUB.chat_count()
    status, out = work(WORKER2, pid, uid, "08.12", claim, binding, refs)
    delta = len(STUB.chat_since(mark, SLICE_MODEL))
    usage = out.get("usage") or {}
    sc.check("unseeded registry: provider /work executes with "
             "EXACTLY ONE stub call (no MODEL_UNKNOWN/CONTEXT_LIMIT "
             "refusal, no spurious retry)",
             status == 200 and delta == 1,
             f"status={status} calls={delta} "
             f"class={out.get('error_class')}")
    body = {"worker_id": DRIVER, "fencing_token": claim["fencing_token"],
            "artifact_type": out["artifact_type"],
            "content": out["content"],
            "actual_cost_cents": out["actual_cost_cents"],
            "usage": usage,
            "provider_request_id": out.get("provider_request_id")}
    call(API2, "POST", f"/units/{uid}/complete", body, role="OPERATOR")
    ev = evidence_by_class(DSN2, claim["attempt_id"])
    calc = (ev.get("CALCULATED") or {}).get("amount_cents")
    fin = (ev.get("FINALIZED") or {}).get("amount_cents")
    # slice-model usage 500/250 at 0.002/0.004 -> 1 + 1 = 2c
    sc.check("Phase 3 mechanics intact: CALCULATED == 2c from the "
             "pricing rows; FINALIZED == CALCULATED",
             calc == 2 and fin == 2, f"calc={calc} fin={fin}")
    return sc.finish({"production_id": pid, "unit_08_12": uid,
                      "stub_calls": delta})


# ------------------------------------------------------------------ setup
def build_db(dbname):
    r = subprocess.run(["python3", str(G3 / "tools/setup_db.py"), dbname],
                       capture_output=True, text=True)
    if r.returncode != 0:
        raise SystemExit(f"setup_db {dbname} failed: {r.stderr[-500:]}")
    print(f"db built: {dbname}", flush=True)


def spawn_api(dsn, base, port, log_name):
    spawn([str(G3 / ".venv/bin/python"), str(G3 / "api/server.py")],
          {"FACTORY_DSN": dsn, "FACTORY_PORT": str(port), **TOKENS},
          log_name)
    assert wait_url(base + "/health"), f"API {port} did not come up"


def spawn_worker(dsn, base, port, log_name):
    spawn([VENV_PY, str(PROG / "gate-c/worker_service/service.py")],
          {"WORKER_SERVICE_PORT": str(port), "WORKER_ENVIRONMENT": "test",
           "WORKER_DSN": dsn, "FACTORY_API_URL": API,
           "FACTORY_WORKER_TOKEN": TOKENS["FACTORY_WORKER_TOKEN"],
           "WORKER_CREDENTIAL_REFS": "VERIFY_MM04_KEY",
           "VERIFY_MM04_KEY": CRED_VALUE}, log_name)
    assert wait_url(base + "/health"), f"worker {port} did not come up"


def setup1():
    build_db(DB1)
    r = subprocess.run([VENV_PY, str(MM / "mm-gate-03/tools/"
                                     "seed_registry.py"), DB1],
                       capture_output=True, text=True)
    if r.returncode != 0:
        raise SystemExit(f"seed_registry failed: {r.stderr[-500:]}")
    print("MM-03 registry seeded into stack1 DB", flush=True)
    for port in (8930, 8995, 8996):
        kill_port(port)
    spawn_api(DSN1, API, 8930, "verify_api.log")
    spawn_worker(DSN1, WORKER, 8995, "verify_worker.log")
    spawn([VENV_PY, str(PROG / "gate-e/evaluation_service/service.py")],
          {"FACTORY_DSN": DSN1, "FACTORY_API_URL": API,
           "FACTORY_VALIDATOR_TOKEN": TOKENS["FACTORY_VALIDATOR_TOKEN"],
           "FACTORY_EVAL_PORT": "8996"}, "verify_eval.log")
    assert wait_url(EVAL + "/health"), "eval did not come up"
    seed_stack1()
    print("stack1 up: api 8930 worker 8995 eval 8996 stub", STUB.url,
          flush=True)


def setup2():
    build_db(DB2)
    for port in (8931, 8997):
        kill_port(port)
    spawn_api(DSN2, API2, 8931, "verify_api2.log")
    # worker2 must talk to API2 for action records: FACTORY_API_URL is
    # read from env at spawn; spawn_worker hardcodes API — spawn here.
    spawn([VENV_PY, str(PROG / "gate-c/worker_service/service.py")],
          {"WORKER_SERVICE_PORT": "8997", "WORKER_ENVIRONMENT": "test",
           "WORKER_DSN": DSN2, "FACTORY_API_URL": API2,
           "FACTORY_WORKER_TOKEN": TOKENS["FACTORY_WORKER_TOKEN"],
           "WORKER_CREDENTIAL_REFS": "VERIFY_MM04_KEY",
           "VERIFY_MM04_KEY": CRED_VALUE}, "verify_worker2b.log")
    assert wait_url(WORKER2 + "/health"), "worker2 did not come up"
    spawn([VENV_PY, str(PROG / "gate-e/evaluation_service/service.py")],
          {"FACTORY_DSN": DSN2, "FACTORY_API_URL": API2,
           "FACTORY_VALIDATOR_TOKEN": TOKENS["FACTORY_VALIDATOR_TOKEN"],
           "FACTORY_EVAL_PORT": "8998"}, "verify_eval2.log")
    assert wait_url(EVAL2 + "/health"), "eval2 did not come up"
    post_config(API2, {"scope": "STATION", "station": 3,
                       "environment": "test",
                       "provider": "deterministic-local",
                       "est_cost_cents": 100,
                       "params": {"reported_actual_cents": 90}})
    post_config(API2, {"scope": "OPERATION", "operation_id": "08.12",
                       "environment": "test",
                       "provider": "openrouter-compatible",
                       "model": SLICE_MODEL, "modality": "text",
                       "credential_ref": "VERIFY_MM04_KEY",
                       "est_cost_cents": 25, "timeout_s": 60,
                       "params": {"base_url": STUB.url},
                       "retry_policy": {"base_s": 0.05, "max_s": 0.2}})
    for unit_kind, price in (("input_token", "0.002"),
                             ("output_token", "0.004")):
        status, out = call(API2, "POST", "/pricing-rules",
                           {"provider": "openrouter-compatible",
                            "model": SLICE_MODEL, "modality": "text",
                            "unit_kind": unit_kind,
                            "unit_price_cents": price,
                            "pricing_version": PVERSION}, role="OPERATOR")
        assert status in (200, 201), (status, out)
    STUB.script[SLICE_MODEL] = [(200, {"prompt_tokens": 500,
                                       "completion_tokens": 250})]
    print("stack2 up: api 8931 worker 8997 (unseeded registry)",
          flush=True)


def teardown():
    for port in (8930, 8995, 8996, 8931, 8997, 8998):
        kill_port(port)
    STUB.httpd.shutdown()
    print("teardown done", flush=True)


def main():
    which = sys.argv[1] if len(sys.argv) > 1 else "all"
    RESULTS.mkdir(parents=True, exist_ok=True)
    LOGS.mkdir(parents=True, exist_ok=True)
    rc = 0
    if which in ("all", "stack1"):
        setup1()
        for fn in (s_retries, s_fallback, s_context, s_cancel, s_runc,
                   s_health_bypass, s_concurrency):
            try:
                rc |= fn()
            except Exception as exc:  # noqa: BLE001
                import traceback
                traceback.print_exc()
                print(f"{fn.__name__} CRASHED: {exc}", flush=True)
                rc = 1
    if which in ("all", "stack2"):
        setup2()
        try:
            rc |= s_unseeded()
        except Exception as exc:  # noqa: BLE001
            import traceback
            traceback.print_exc()
            print(f"s_unseeded CRASHED: {exc}", flush=True)
            rc = 1
    if which == "all":
        teardown()
    print(f"VERIFIER BATTERY rc={rc}", flush=True)
    return rc


if __name__ == "__main__":
    sys.exit(main())
