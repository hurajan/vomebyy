#!/usr/bin/env python3
"""MM-05 battery — local OpenRouter-shaped stub provider.

STUB_TESTED evidence only: implements the OpenRouter chat-completions
HTTP shape on localhost so the multi-model routing mechanics (registry
binding -> claim pin -> gateway -> adapter) can be exercised through
real n8n execution without a credential or a paid request. It is NOT a
provider and its responses are never presented as one.

Usage: stub_provider.py <port> <mode> <record_file> <in_tokens>
       <out_tokens> [fail_model]
  mode ok       -> 200 with the canned script completion + usage
  mode fallback -> requests whose body.model == fail_model get a 500
                   with NO usage in the error body; every other model
                   gets the 200 completion + usage
  mode error500 -> 500 on every request
Every request is appended to <record_file> as one JSON line (full
body, incl. the model the worker actually sent, plus the correlation
header when present). Responses carry id chatcmpl-mm05-<n> where n is
the 1-based request sequence number, so the harness can tie a
completion's provider_request_id to the exact request that earned it.

Stub authoring note (inherited from the Phase 3 stub): the canned
script's L2 line deliberately carries a WRONG canon_ref and L3 omits
beat_ref/story_ref — assertions prove the worker SETS canon_refs from
the actual canon input ref and derives beat/story refs from the
scene/beat inputs rather than trusting the model.
"""
import json
import sys
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

PORT = int(sys.argv[1])
MODE = sys.argv[2]
RECORD = Path(sys.argv[3])
IN_TOKENS = int(sys.argv[4])
OUT_TOKENS = int(sys.argv[5])
FAIL_MODEL = sys.argv[6] if len(sys.argv) > 6 else None

CANNED_SCRIPT = {
    "kind": "script",
    "lines": [
        {"id": "L1", "scene_ref": "SC1", "beat_ref": "B1",
         "story_ref": "S1", "canon_refs": ["stub-will-be-replaced"],
         "text": "Mara turns the brass key; the clock case swings open."},
        {"id": "L2", "scene_ref": "SC2", "beat_ref": "B2",
         "story_ref": "S2", "canon_refs": ["model-invented-ref"],
         "text": "Tobin bars the archive door and pockets the ledger."},
        {"id": "L3", "scene_ref": "SC1",
         "text": "The ledger is gone; only dust where it lay."},
    ],
    "trace": {
        "clues": [{"id": "CL1", "planted": "L1", "payoff": "L3"}],
        "knowledge": [{"character": "Mara", "learns": "CL1", "at": "L2"}],
        "payoffs": [{"id": "PO1", "clue": "CL1", "line": "L3"}]},
    "canon_refs": ["model-invented-ref"],
}

_count = {"n": 0}


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _send(self, code, obj):
        payload = json.dumps(obj).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(payload)))
        self.end_headers()
        self.wfile.write(payload)

    def do_POST(self):
        raw = self.rfile.read(int(self.headers.get("Content-Length") or 0))
        try:
            body = json.loads(raw or b"{}")
        except json.JSONDecodeError:
            body = {"_unparsed": raw.decode("utf-8", errors="replace")}
        _count["n"] += 1
        n = _count["n"]
        body["_path"] = self.path
        body["_seq"] = n
        corr = self.headers.get("X-Correlation-Id")
        if corr:
            body["_correlation_id"] = corr
        with RECORD.open("a") as fh:
            fh.write(json.dumps(body) + "\n")
        model = body.get("model")
        if MODE == "error500" or (MODE == "fallback"
                                  and model == FAIL_MODEL):
            # Provider-side failure. The error body deliberately
            # carries NO usage object: nothing may be summed into the
            # completion usage from a failed segment.
            self._send(500, {"error": {
                "message": f"stub provider failure for model {model}",
                "type": "stub_error", "code": 500}})
            return
        self._send(200, {
            "id": f"chatcmpl-mm05-{n}",
            "choices": [{"message": {"role": "assistant",
                                     "content": json.dumps(CANNED_SCRIPT)}}],
            "usage": {"prompt_tokens": IN_TOKENS,
                      "completion_tokens": OUT_TOKENS,
                      "total_tokens": IN_TOKENS + OUT_TOKENS}})


if __name__ == "__main__":
    RECORD.parent.mkdir(parents=True, exist_ok=True)
    ThreadingHTTPServer(("127.0.0.1", PORT), Handler).serve_forever()
