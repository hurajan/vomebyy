#!/usr/bin/env bash
# MM-05 M05-1 — six-station mock paths: every station suite + the G9
# full run, SERIALLY, on current code. Canonical per-suite commands
# (same as the programme regression drivers). Per-suite logs +
# SUMMARY.txt land in mm-gate-05/evidence/logs/m05_1/.
set -u
W="$HOME/workspace"
LOGS="$W/video-factory-master-programme/mm-gate-05/evidence/logs/m05_1"
mkdir -p "$LOGS"
PY="$W/video-factory-g2/.venv/bin/python"
SUMMARY="$LOGS/SUMMARY.txt"
: > "$SUMMARY"

run_suite() {
  local name="$1"; shift
  echo "=== $name : $*" | tee -a "$SUMMARY"
  "$@" > "$LOGS/$name.log" 2>&1
  local rc=$?
  local line verdict
  line=$(grep -E "^Ran [0-9]+ tests" "$LOGS/$name.log" | tail -1)
  verdict=$(grep -E "^(OK|FAILED)" "$LOGS/$name.log" | tail -1)
  echo "$name rc=$rc $line $verdict" | tee -a "$SUMMARY"
}

for t in g4 g5 g6 g7 g8; do
  run_suite $t bash -c "python3 '$W/video-factory-$t/tools/setup_env.py' && cd '$W/video-factory-$t' && '$PY' -m unittest discover -s tests"
done
run_suite g9 bash -c "python3 '$W/video-factory-g9/tools/setup_fullrun.py' && cd '$W/video-factory-g9' && '$PY' -m unittest discover -s tests"
echo "M05-1 SUITES DONE" | tee -a "$SUMMARY"
