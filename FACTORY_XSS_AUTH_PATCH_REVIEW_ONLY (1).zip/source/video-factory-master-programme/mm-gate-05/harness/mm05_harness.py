#!/usr/bin/env python3
"""MM-05 battery — n8n six-station execution integration.

Proves the multi-model execution path through REAL n8n workflow
execution (never direct worker-only calls for the paths under test):

  Coordinator authorizes -> scheduler prestages the claim (pinning the
  MM-03 model_assignment + plan + resolved binding) -> n8n dispatch
  webhook -> station workflow -> unit-executor adopts -> call-worker
  -> worker service /work (MM-04 gateway resolves the pinned model;
  authorized fallback) -> evaluation service -> Coordinator commits
  -> dependents unlock (HG2-gated downstream).

Registry composition (LOCK_MM05.md): the MM-03 registry is seeded in
the battery DB and the STATION_03 policy is PROMOTED through the API
(OPERATOR; a recorded test-fixture promotion). Promotion writes the
OPERATION bindings (08.12 -> anthropic/claude-opus-4.8 primary,
openai/gpt-5.5 fallback). The battery then seeds station 3's
established deterministic-local STATION binding via POST /configs —
superseding only promotion's station-scope row — so the plan-bound
deterministic chain (05.12/06.12/07.12, no assignments) keeps its
existing resolution; the OPERATION rows are untouched. The promoted
08.12 row's params receive a base_url override to the local stub
(per-DB test seeding; canonical promotion carries none).

All provider contact is against the local stub: STUB_TESTED evidence
only. No real credential exists; the worker runs with a dummy key
value in env so the credentialed adapter reports READY against the
stub. No real provider is contacted; no paid call is made.

Scenarios (each an independent production on the shared battery DB):
  m05_2 routing    — assignment pinned at claim; stub receives the
                     ASSIGNMENT's model (opus-4.8, not the old slice
                     haiku); F-P4P-01 refs proof; F-P4P-02 usage
                     forwarding proof; CALCULATED at opus rates.
  m05_3 fallback   — stub 500s the primary (no usage in error body),
                     serves the fallback; gateway retries bounded,
                     fallback segment completes; evidence names the
                     fallback model + event; CALCULATED at fallback
                     rates (8c, vs 7c at primary rates — distinct).
  m05_4 handoff    — 08.12 refs carry the four CURRENT contents;
                     OPERATOR HG2 approval (recorded human decision)
                     opens 09.12 through the g6 executor;
                     direction_package.script_ref == script id;
                     09.12 snapshot has NO model_assignment (no
                     cross-station leakage, live).
  m05_5 guards     — duplicate dispatch; step-12 unit to the g6
                     webhook; Station 03 unit to the g7 webhook.
  m05_6 gate       — HG2 PENDING: scheduler skip + direct-claim 409 +
                     executor refusal; approval opens the claim.
  m05_7 recovery   — n8n killed mid-chain, restarted, chain completes
                     with exactly one attempt + settlement per unit.
  m05_8 consistency— pin tabulation for the m05_2/m05_4 productions.

Run with the factory venv python:
  mm05_harness.py setup | m05_2 | m05_3 | m05_4 | m05_5 | m05_6 |
                  m05_7 | m05_8 | teardown
"""
import hashlib
import importlib.util
import json
import os
import re
import subprocess
import sys
import time
import urllib.error
import urllib.request
from decimal import ROUND_HALF_UP, Decimal
from pathlib import Path

import psycopg
from psycopg.rows import dict_row

ROOT = Path(__file__).resolve().parent.parent
LOGS = ROOT / "evidence" / "logs"
RESULTS = ROOT / "evidence" / "results"
HOME = Path.home()
G2 = HOME / "workspace/video-factory-g2"
G3 = HOME / "workspace/video-factory-g3"
G4T = HOME / "workspace/video-factory-g4"
G5 = HOME / "workspace/video-factory-g5"
PROG = HOME / "workspace/video-factory-real-ai-programme"
MM03 = HOME / "workspace/video-factory-master-programme/mm-gate-03"
VENV_PY = str(G2 / ".venv/bin/python")
STORE = PROG / "gate-d/storage_service/.store"

DB = "mm05_scratch"


def _fixture_password():
    """Dev scratch role password from the canonical fixture (g2
    tools/setup_db.py) — never re-typed as a literal here."""
    src = (G2 / "tools/setup_db.py").read_text()
    return re.search(
        r"CREATE ROLE factory LOGIN PASSWORD '([^']+)'", src).group(1)


DSN = ("host=127.0.0.1 dbname=" + DB + " user=factory password="
       + _fixture_password())
API = "http://127.0.0.1:8730"
WORKER = "http://127.0.0.1:8795"
EVAL = "http://127.0.0.1:8796"
N8N = "http://127.0.0.1:5678"
WEBHOOK = N8N + "/webhook/dispatch-g5"
WEBHOOK_G6 = N8N + "/webhook/dispatch-g6"
WEBHOOK_G7 = N8N + "/webhook/dispatch-g7"
STUB_PORT = 8799
STUB_URL = f"http://127.0.0.1:{STUB_PORT}"
TOKENS = {"FACTORY_API_TOKEN": "dev-operator-token",
          "FACTORY_WORKER_TOKEN": "dev-worker-token",
          "FACTORY_SCHEDULER_TOKEN": "dev-scheduler-token",
          "FACTORY_VALIDATOR_TOKEN": "dev-validator-token",
          "FACTORY_CALLBACK_TOKEN": "dev-callback-token"}
OPERATOR = TOKENS["FACTORY_API_TOKEN"]
CANON_TEXT = ("CANON MANIFEST v1 — universe, chronology, world rules, "
              "knowledge boundaries released.")
PRIMARY = "anthropic/claude-opus-4.8"
FALLBACK = "openai/gpt-5.5"
PROVIDER = "openrouter-compatible"
PRICING_VERSION = "mm05-2026-10-29"
# MM-02 catalog published prices, converted USD/token -> cents/token.
RATES = {PRIMARY: (Decimal("0.0005"), Decimal("0.0025")),
         FALLBACK: (Decimal("0.0005"), Decimal("0.0030"))}
USAGE_PRIMARY = (4200, 1600)    # -> 6.10c at opus rates -> 6c
USAGE_FALLBACK = (3900, 2100)   # -> 8.25c at gpt rates -> 8c (7c at opus)
EXECUTOR_G5 = "n8n-executor-g5"
EXECUTOR_G6 = "n8n-executor-g6"
LABEL = "STUB_TESTED"


def expected_calc(usage, model):
    """Coordinator-shaped CALCULATED: sum(usage x seeded rates),
    ROUND_HALF_UP to whole cents."""
    rin, rout = RATES[model]
    total = Decimal(usage[0]) * rin + Decimal(usage[1]) * rout
    return int(total.quantize(Decimal("1"), rounding=ROUND_HALF_UP)), total


# ------------------------------------------------------------------ http
def call(base, method, path, body=None, role=None):
    req = urllib.request.Request(base + path, method=method)
    data = None
    if role == "OPERATOR":
        req.add_header("X-Operator-Token", OPERATOR)
    if body is not None:
        data = json.dumps(body).encode()
        req.add_header("Content-Type", "application/json")
    try:
        with urllib.request.urlopen(req, data=data, timeout=30) as r:
            return r.status, json.loads(r.read() or b"{}")
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read() or b"{}")


def db(sql, args=()):
    with psycopg.connect(DSN, row_factory=dict_row, autocommit=True) as conn:
        cur = conn.execute(sql, args)
        try:
            return cur.fetchall()
        except psycopg.errors.ProgrammingError:
            return []


# -------------------------------------------------------------- processes
def kill_port(port):
    subprocess.run(["fuser", "-k", f"{port}/tcp"], capture_output=True)
    time.sleep(0.5)


def port_pid(port):
    r = subprocess.run(["fuser", f"{port}/tcp"], capture_output=True,
                       text=True)
    pids = (r.stdout + r.stderr).split()
    return pids[-1] if pids else None


def spawn(cmd, env, log_name):
    e = dict(os.environ)
    e.update(env)
    out = open(LOGS / log_name, "ab")
    return subprocess.Popen(cmd, env=e, stdout=out, stderr=out,
                            start_new_session=True)


def wait_url(url, seconds=60, ok_statuses=(200,)):
    deadline = time.time() + seconds
    while time.time() < deadline:
        try:
            with urllib.request.urlopen(url, timeout=2) as r:
                if r.status in ok_statuses:
                    return True
        except urllib.error.HTTPError:
            return True  # any HTTP answer = serving
        except Exception:  # noqa: BLE001
            pass
        time.sleep(0.5)
    return False


def start_stub(mode, tag, usage, fail_model=None):
    kill_port(STUB_PORT)
    record = LOGS / f"stub_requests_{tag}.jsonl"
    if record.exists():
        record.unlink()
    args = [sys.executable, str(ROOT / "harness/stub_provider.py"),
            str(STUB_PORT), mode, str(record), str(usage[0]),
            str(usage[1])]
    if fail_model:
        args.append(fail_model)
    spawn(args, {}, f"stub_{tag}.log")
    if not wait_url(STUB_URL + "/chat/completions", seconds=15):
        raise SystemExit("stub provider did not come up")
    record.write_text("")  # drop the readiness-probe line
    return record


def stub_calls(record):
    if not record.exists():
        return []
    return [json.loads(l) for l in record.read_text().splitlines() if l]


# ---------------------------------------------------------------- driver
class Scenario:
    def __init__(self, name):
        self.name = name
        self.checks = []

    def check(self, name, ok, detail=""):
        self.checks.append({"name": name, "pass": bool(ok),
                            "detail": str(detail)[:900]})
        print(f"  [{'PASS' if ok else 'FAIL'}] {name} — {str(detail)[:220]}")

    def finish(self, extra=None):
        verdict = all(c["pass"] for c in self.checks)
        doc = {"scenario": self.name,
               "verdict": "PASS" if verdict else "FAIL",
               "label": LABEL, "checks": self.checks, **(extra or {})}
        RESULTS.mkdir(parents=True, exist_ok=True)
        (RESULTS / f"{self.name}.json").write_text(
            json.dumps(doc, indent=1, sort_keys=True, default=str))
        print(f"{self.name}: {'PASS' if verdict else 'FAIL'} "
              f"({sum(1 for c in self.checks if c['pass'])}/"
              f"{len(self.checks)})")
        return 0 if verdict else 1


def unit_row(pid, uid):
    _, out = call(API, "GET", f"/productions/{pid}/units", role="OPERATOR")
    return [u for u in out["units"] if u["unit_id"] == uid][0]


def wait_state(pid, uid, states, timeout=300):
    deadline = time.time() + timeout
    state = None
    while time.time() < deadline:
        state = unit_row(pid, uid)["state"]
        if state in states:
            return state
        time.sleep(2)
    raise AssertionError(f"unit {uid} stuck in {state}, wanted {states}")


def current_artifacts(pid):
    _, out = call(API, "GET", f"/productions/{pid}/artifacts", role="OPERATOR")
    return {a["artifact_type"]: a for a in out["artifacts"]
            if a["state"] == "CURRENT"}


def scheduler_prestage():
    """One Gate F SchedulerService cycle (actor 'scheduler-service';
    the coordinator derives the executor worker_id per unit step and
    pins plan + binding + MM-03 assignment at claim)."""
    sys.path.insert(0, str(PROG / "gate-f"))
    from runtime_services.scheduler_service import SchedulerService
    return SchedulerService(dsn=DSN).run_once()


def post_dispatch(pid, uid, op, station=3, webhook=None):
    payload = {"production_id": pid, "unit_id": uid, "operation_id": op,
               "station": station, "input_artifact_ids": [],
               "force_fail": False, "idempotency_key": f"dispatch:{uid}:1"}
    req = urllib.request.Request(webhook or WEBHOOK, method="POST",
                                 data=json.dumps(payload).encode(),
                                 headers={"Content-Type": "application/json"})
    deadline = time.time() + 60  # webhook registration can lag a re-sync
    while True:
        try:
            with urllib.request.urlopen(req, timeout=120) as r:
                return r.status
        except urllib.error.HTTPError as e:
            if e.code == 404 and time.time() < deadline:
                time.sleep(3)
                continue
            raise


def make_production(title):
    s, p = call(API, "POST", "/productions",
                {"title": title, "hard_ceiling_cents": 500,
                 "soft_ceiling_cents": 250}, role="OPERATOR")
    assert s == 201, f"production create {s}: {p}"
    pid = p["production_id"]
    s, r = call(API, "POST", f"/productions/{pid}/runs", {"kind": "FULL"},
                role="OPERATOR")
    assert s == 201, f"run create {s}: {r}"
    s, a = call(API, "POST", f"/productions/{pid}/artifacts",
                {"artifact_type": "canon_manifest", "content": CANON_TEXT,
                 "storage_uri": "local://canon-fixture"}, role="OPERATOR")
    assert s == 201, f"canon register {s}: {a}"
    return pid, r["run_id"], a["artifact_id"]


def plan_unit(pid, run, op, depends=(), inputs=()):
    s, u = call(API, "POST", f"/productions/{pid}/units",
                {"operation_id": op, "run_id": run, "unit_key": "main",
                 "depends_on": list(depends),
                 "input_artifact_ids": list(inputs)}, role="OPERATOR")
    assert s == 201, f"plan {op} {s}: {u}"
    return u["unit_id"]


def drive_via_n8n(sc, pid, uid, op, approve=True):
    """Scheduler prestage -> webhook dispatch -> (optional) harness
    human approval of the UNIT -> ACCEPTED. Returns the end state."""
    wait_state(pid, uid, {"READY"})
    report = scheduler_prestage()
    claimed = [c for c in report["claimed"] if c["unit_id"] == uid]
    sc.check(f"{op}: scheduler prestaged the claim",
             len(claimed) == 1
             and unit_row(pid, uid)["state"] == "CLAIMED",
             f"claimed={claimed}")
    post_dispatch(pid, uid, op)
    state = wait_state(pid, uid, {"AWAITING_HUMAN", "ACCEPTED", "FAILED",
                                  "BLOCKED", "RETRY_WAIT"})
    if state == "AWAITING_HUMAN" and approve:
        s, _ = call(API, "POST", f"/units/{uid}/events",
                    {"event": "human_approved"}, role="OPERATOR")
        assert s == 200, f"human_approved {op} -> {s}"
        state = wait_state(pid, uid, {"ACCEPTED"})
    return state


def build_chain(sc, pid, run, canon):
    """Plan + drive 05.12 -> 06.12 -> 07.12 (deterministic STATION
    binding) through n8n to ACCEPTED."""
    u05 = plan_unit(pid, run, "05.12", inputs=[canon])
    u06 = plan_unit(pid, run, "06.12", depends=[u05], inputs=[canon])
    u07 = plan_unit(pid, run, "07.12", depends=[u06], inputs=[canon])
    for op, uid in (("05.12", u05), ("06.12", u06), ("07.12", u07)):
        state = drive_via_n8n(sc, pid, uid, op)
        sc.check(f"{op} ACCEPTED via n8n (scheduler prestage + adopt)",
                 state == "ACCEPTED", f"state={state}")
    return u05, u06, u07


def plan_0812(pid, run, canon, u07):
    """08.12 planned contract-correctly (spec §3.2): inputs = [canon]
    ONLY; the fixed executor adds dependency CURRENT outputs to the
    worker refs on the provider path (F-P4P-01)."""
    return plan_unit(pid, run, "08.12", depends=[u07], inputs=[canon])


def attempts_of(uid):
    return db("SELECT attempt_no, worker_id, status, adopted_by, "
              "adopted_at, config_id, resolved_config, "
              "resolved_config_hash, plan_id, plan_version, plan_hash "
              "FROM action_attempts WHERE unit_id=%s "
              "ORDER BY attempt_no", (uid,))


def audit_of(uid):
    return db("SELECT event_type AS event, actor FROM audit_events "
              "WHERE unit_id=%s ORDER BY created_at", (uid,))


def action_records(uid):
    return db("SELECT action_key, status, output_summary, error, "
              "inputs_hash FROM plan_action_attempts WHERE unit_id=%s "
              "ORDER BY seq, recorded_at", (uid,))


def _canon(value):
    return json.dumps(value, sort_keys=True, default=str)


def expected_refs(pid, uid):
    """Reconstruct the refs the FIXED executor must have sent:
    planned inputs first, then the production's CURRENT artifacts
    produced by ACCEPTED units of the same run (artifacts-endpoint
    order)."""
    _, uout = call(API, "GET", f"/productions/{pid}/units", role="OPERATOR")
    units = {u["unit_id"]: u for u in uout["units"]}
    me = units[uid]
    _, aout = call(API, "GET", f"/productions/{pid}/artifacts",
                   role="OPERATOR")
    by_id = {a["artifact_id"]: a for a in aout["artifacts"]}
    refs, seen = [], set()
    for aid in me.get("input_artifact_ids", []):
        a = by_id[aid]
        refs.append({"artifact_type": a["artifact_type"],
                     "artifact_id": a["artifact_id"],
                     "sha256": a["sha256"]})
        seen.add(aid)
    for a in aout["artifacts"]:
        if a["state"] != "CURRENT" or not a.get("produced_by_unit"):
            continue
        if a["produced_by_unit"] == uid or a["artifact_id"] in seen:
            continue
        producer = units.get(a["produced_by_unit"])
        if not producer or producer["state"] != "ACCEPTED":
            continue
        if producer.get("run_id") != me.get("run_id"):
            continue
        refs.append({"artifact_type": a["artifact_type"],
                     "artifact_id": a["artifact_id"],
                     "sha256": a["sha256"]})
        seen.add(a["artifact_id"])
    return refs


def check_refs_proof(sc, pid, uid):
    """F-P4P-01 cryptographic proof: the worker digests the exact
    refs it received into the manifest action record (inputs_hash +
    output digest). Recompute from the expected refs and compare."""
    man = [r for r in action_records(uid)
           if r["action_key"] == "inputs.manifest"]
    man = man[-1] if man else {}
    refs = expected_refs(pid, uid)
    exp_inputs_hash = hashlib.sha256(_canon(
        {"refs": refs, "prior": {}}).encode()).hexdigest()
    exp_output = {"inputs": refs, "count": len(refs),
                  "input_sha256": [r["sha256"] for r in refs]}
    exp_output_hash = hashlib.sha256(_canon(exp_output).encode()).hexdigest()
    osum = man.get("output_summary") or {}
    if isinstance(osum, str):
        osum = json.loads(osum)
    sc.check("F-P4P-01: worker refs == planned [canon] + dependency "
             "CURRENT outputs — four upstream contents, ids+shas "
             "verified (inputs_hash + manifest digest recomputed)",
             [r["artifact_type"] for r in refs] ==
             ["canon_manifest", "beat_graph", "scene_set",
              "story_architecture"]
             and man.get("inputs_hash") == exp_inputs_hash
             and osum.get("sha256") == exp_output_hash,
             f"types={[r['artifact_type'] for r in refs]} "
             f"inputs_hash_match={man.get('inputs_hash') == exp_inputs_hash} "
             f"output_digest_match={osum.get('sha256') == exp_output_hash}")
    return refs


def evidence_of(uid):
    return db("SELECT * FROM financial_evidence e JOIN action_attempts a "
              "ON a.attempt_id=e.attempt_id WHERE a.unit_id=%s "
              "ORDER BY e.created_at", (uid,))


def fin_rows(uid):
    out = []
    for e in evidence_of(uid):
        usage = e.get("usage")
        if isinstance(usage, str):
            usage = json.loads(usage)
        out.append({"charge_class": e.get("charge_class"),
                    "amount_cents": e.get("amount_cents"),
                    "pricing_version": e.get("pricing_version"),
                    "provider_request_id": e.get("provider_request_id"),
                    "usage": usage})
    return out


def script_artifacts(pid):
    _, out = call(API, "GET", f"/productions/{pid}/artifacts", role="OPERATOR")
    return [a for a in out["artifacts"] if a["artifact_type"] == "script"]


def hg2_gates(pid):
    _, out = call(API, "GET", f"/productions/{pid}/gates", role="OPERATOR")
    return [g for g in out["gates"] if g["gate_kind"] == "HG2"]


def wait_hg2(pid, timeout=120):
    deadline = time.time() + timeout
    while time.time() < deadline:
        gates = hg2_gates(pid)
        if gates:
            return gates
        time.sleep(2)
    return []


def read_store_artifact(artifact):
    raw = (STORE / "objects" / artifact["sha256"]).read_bytes()
    return json.loads(raw)


# ------------------------------------------------------------------ n8n
def start_n8n():
    kill_port(5678)
    time.sleep(1)
    spawn([str(G4T / "node_modules/.bin/n8n"), "start"],
          {"N8N_USER_FOLDER": str(G4T / "n8n-data"), "N8N_PORT": "5678",
           "N8N_LISTEN_ADDRESS": "127.0.0.1",
           "N8N_DIAGNOSTICS_ENABLED": "false",
           "N8N_TEMPLATES_ENABLED": "false",
           "N8N_BLOCK_ENV_ACCESS_IN_NODE": "false",
           **TOKENS,
           "FACTORY_API_URL": API,
           "FACTORY_WORKER_SERVICE_URL": WORKER,
           "FACTORY_EVALUATION_URL": EVAL}, "n8n.log")
    if not wait_url(N8N + "/healthz", seconds=120):
        raise SystemExit("n8n did not come up (see logs/n8n.log)")


def sync_tree(tree):
    spec = importlib.util.spec_from_file_location(
        f"{tree}_setup_env",
        str(HOME / f"workspace/video-factory-{tree}/tools/setup_env.py"))
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    mod.sync_workflows()


# ------------------------------------------------------------------ setup
def setup():
    subprocess.run(["pg_ctlcluster", "16", "main", "start"],
                   capture_output=True)
    r = subprocess.run(["python3", str(G3 / "tools/setup_db.py"), DB],
                       capture_output=True, text=True)
    if r.returncode != 0:
        raise SystemExit(f"scratch DB setup failed: {r.stderr[-400:]}")
    print(f"db: {DB} built (coordinator + registry schema + plans)")
    kill_port(8730)
    spawn([str(G3 / ".venv/bin/python"), str(G3 / "api/server.py")],
          {"FACTORY_DSN": DSN, "FACTORY_PORT": "8730", **TOKENS}, "api.log")
    if not wait_url(API + "/health"):
        raise SystemExit("API did not come up (see logs/api.log)")
    print("api: up on 8730")
    kill_port(8795)
    spawn([VENV_PY, str(PROG / "gate-c/worker_service/service.py")],
          {"WORKER_SERVICE_PORT": "8795", "WORKER_ENVIRONMENT": "test",
           "WORKER_DSN": DSN, "FACTORY_API_URL": API,
           "FACTORY_WORKER_TOKEN": TOKENS["FACTORY_WORKER_TOKEN"],
           "WORKER_CREDENTIAL_REFS": "OPENROUTER_API_KEY",
           "OPENROUTER_API_KEY": "stub-local-key"}, "worker.log")
    if not wait_url(WORKER + "/health"):
        raise SystemExit("worker service did not come up (see logs/worker.log)")
    _, health = call(WORKER, "GET", "/health")
    print(f"worker: up on 8795, openrouter-compatible="
          f"{health['adapters']['openrouter-compatible']['status']}")
    kill_port(8796)
    spawn([VENV_PY, str(PROG / "gate-e/evaluation_service/service.py")],
          {"FACTORY_DSN": DSN, "FACTORY_API_URL": API,
           "FACTORY_VALIDATOR_TOKEN": TOKENS["FACTORY_VALIDATOR_TOKEN"],
           "FACTORY_EVAL_PORT": "8796"}, "eval.log")
    if not wait_url(EVAL + "/health"):
        raise SystemExit("evaluation service did not come up (see logs/eval.log)")
    print("evaluation service: up on 8796")
    start_n8n()
    sys.path.insert(0, str(G5 / "tools"))
    import setup_env as g5_setup  # noqa: E402
    g5_setup.sync_workflows()
    print("n8n: up on 5678, g5 workflows synced + active")
    sync_tree("g6")
    print("n8n: g6 workflows synced + active")
    sync_tree("g7")
    print("n8n: g7 workflows synced + active")
    # --- MM-03 registry seed (idempotent) ---
    r = subprocess.run([VENV_PY, str(MM03 / "tools/seed_registry.py"), DB],
                       capture_output=True, text=True)
    if r.returncode != 0:
        raise SystemExit(f"registry seed failed: {r.stdout} {r.stderr}")
    print("registry seed:", r.stdout.strip().replace("\n", " | ")[:400])
    # --- pricing rows for the two matrix models (catalog prices) ---
    _, out = call(API, "GET", "/pricing-rules", role="OPERATOR")
    have = {(x["provider"], x.get("model"), x["unit_kind"],
             x["pricing_version"], str(x["unit_price_cents"]))
            for x in out.get("pricing_rules", []) if x.get("active", True)}
    for model, (rin, rout) in RATES.items():
        for kind, price in (("input_token", rin), ("output_token", rout)):
            key = (PROVIDER, model, kind, PRICING_VERSION, str(price))
            if key in have:
                print(f"pricing {model} {kind}: present")
                continue
            s, o = call(API, "POST", "/pricing-rules",
                        {"provider": PROVIDER, "model": model,
                         "modality": "text", "unit_kind": kind,
                         "unit_price_cents": float(price),
                         "pricing_version": PRICING_VERSION},
                        role="OPERATOR")
            if s not in (200, 201):
                raise SystemExit(f"pricing seed {model} {kind}: {s} {o}")
            print(f"pricing {model} {kind}: seeded @ {price} cents/token")
    # --- PROMOTE the Station 03 policy (OPERATOR; test fixture) ---
    s, out = call(API, "GET", "/model-policies", role="OPERATOR")
    policies = out.get("policies", out if isinstance(out, list) else [])
    pol = [p for p in policies if p.get("role") == "STATION_03"
           and p.get("status") == "PROPOSED"]
    if not pol:
        raise SystemExit(f"STATION_03 PROPOSED policy not found: {out}")
    policy_id = pol[0]["policy_id"]
    s, out = call(API, "POST", f"/model-policies/{policy_id}/promote",
                  {"approval_note": "MM-05 battery test-fixture "
                                    "promotion (Station 03 policy)"},
                  role="OPERATOR")
    if s != 200 or out.get("status") != "ACTIVE":
        raise SystemExit(f"promotion failed: {s} {out}")
    print(f"promotion: {policy_id} -> ACTIVE, "
          f"bindings_written={out.get('bindings_written')}")
    # --- stub endpoint override on the promoted 08.12 OPERATION row ---
    rows = db("UPDATE provider_configs SET params = params || %s::jsonb "
              "WHERE active AND scope='OPERATION' "
              "AND operation_id='08.12' RETURNING config_id",
              (json.dumps({"base_url": STUB_URL}),))
    if len(rows) != 1:
        raise SystemExit(f"base_url override hit {len(rows)} rows")
    print("stub override: base_url set on the promoted 08.12 OPERATION "
          "binding (per-DB test seeding; canonical promotion has none)")
    # --- station deterministic bindings (established station shape) ---
    for station in (3, 4):
        s, o = call(API, "POST", "/configs",
                    {"scope": "STATION", "station": station,
                     "environment": "test",
                     "provider": "deterministic-local",
                     "est_cost_cents": 100,
                     "params": {"reported_actual_cents": 90}},
                    role="OPERATOR")
        if s not in (200, 201):
            _, cfgs = call(API, "GET", "/configs", role="OPERATOR")
            ok = any(c.get("scope") == "STATION"
                     and c.get("station") == station
                     and c.get("active", True)
                     for c in cfgs.get("configs", []))
            if not ok:
                raise SystemExit(f"STATION {station} binding: {s} {o}")
        print(f"bindings: STATION {station} deterministic-local present "
              "(station-3 row supersedes ONLY promotion's station-scope "
              "row; OPERATION rows untouched)")
    active = db("SELECT scope, station, operation_id, provider, model, "
                "est_cost_cents FROM provider_configs WHERE active "
                "ORDER BY scope, station, operation_id")
    (RESULTS / "setup_summary.json").write_text(json.dumps(
        {"policy_promoted": policy_id, "active_bindings": active},
        indent=1, sort_keys=True, default=str))
    print(f"setup complete: {len(active)} active bindings recorded")
    return 0


def teardown():
    for port in (8730, 8795, 8796, STUB_PORT):
        kill_port(port)
    print("teardown: 8730/8795/8796/8799 stopped (n8n left running: "
          "shared instance, workflows remain synced)")
    return 0


# -------------------------------------------------------------- scenarios
def check_script_and_gate(sc, pid, uid):
    """Shared: exactly one CURRENT script + HG2 PENDING bound to it."""
    scripts = script_artifacts(pid)
    cur = [a for a in scripts if a["state"] == "CURRENT"]
    sc.check("exactly one script artifact, CURRENT",
             len(scripts) == 1 and len(cur) == 1,
             f"scripts={[(a['artifact_id'][:8], a['state']) for a in scripts]}")
    script = cur[0] if cur else {}
    if script:
        envelope = read_store_artifact(script)
        deliverable = envelope["output_artifacts"][0]["content"]
        _, arts = call(API, "GET", f"/productions/{pid}/artifacts",
                       role="OPERATOR")
        canon_id = [a["artifact_id"] for a in arts["artifacts"]
                    if a["artifact_type"] == "canon_manifest"][0]
        texts = [l["text"] for l in deliverable["lines"]]
        sc.check("script content is the stub-authored text, worker-"
                 "shaped (canon_refs set from the real canon id)",
                 deliverable.get("kind") == "script"
                 and all(l["canon_refs"] == [canon_id]
                         for l in deliverable["lines"])
                 and "brass key" in texts[0],
                 f"lines={len(deliverable.get('lines', []))}")
    gates = wait_hg2(pid)
    sc.check("station flow created the HG2 gate bound to the script "
             "id+sha, verdict PENDING",
             len(gates) == 1 and bool(script)
             and gates[0]["artifact_id"] == script["artifact_id"]
             and gates[0]["artifact_sha256"] == script["sha256"]
             and gates[0]["verdict"] == "PENDING",
             json.dumps(gates))
    return script


def m05_2():
    sc = Scenario("m05_2_routing")
    record = start_stub("ok", "m05_2", USAGE_PRIMARY)
    pid, run, canon = make_production("MM-05 M05-2 registry routing via n8n")
    _, _, u07 = build_chain(sc, pid, run, canon)
    u08 = plan_0812(pid, run, canon, u07)
    state = drive_via_n8n(sc, pid, u08, "08.12", approve=False)
    sc.check("08.12 parks at AWAITING_HUMAN (semantic layer does not "
             "judge the credentialed binding; human gate is the bar)",
             state == "AWAITING_HUMAN", f"state={state}")
    # --- the routing assertions: pin at claim + model at the stub ---
    atts = attempts_of(u08)
    sc.check("one attempt, worker identity n8n-executor-g5, ADOPTED "
             "(Gate 02 path)",
             len(atts) == 1 and atts[0]["worker_id"] == EXECUTOR_G5
             and atts[0].get("adopted_at") is not None
             and atts[0].get("adopted_by") == EXECUTOR_G5,
             json.dumps(atts, default=str)[:400])
    snap = atts[0]["resolved_config"] or {}
    if isinstance(snap, str):
        snap = json.loads(snap)
    ma = snap.get("model_assignment") or {}
    sc.check("attempt snapshot pins the MM-03 model_assignment "
             "(policy, matrix 1.0.0, opus-4.8 primary, gpt-5.5 fallback)",
             ma.get("primary_model") == PRIMARY
             and ma.get("fallback_model") == FALLBACK
             and ma.get("matrix_version") == "1.0.0"
             and str(ma.get("policy_id", "")).startswith(
                 "policy-station-03"),
             json.dumps(ma))
    sc.check("resolved binding is the promoted OPERATION row "
             "(openrouter-compatible + opus-4.8 — not the slice haiku)",
             snap.get("provider") == PROVIDER
             and snap.get("model") == PRIMARY,
             f"provider={snap.get('provider')} model={snap.get('model')}")
    calls = stub_calls(record)
    sc.check("exactly ONE provider call through n8n",
             len(calls) == 1, f"calls={len(calls)}")
    if calls:
        sc.check("the stub received the ASSIGNMENT's model "
                 "(anthropic/claude-opus-4.8) — registry -> claim pin "
                 "-> gateway -> adapter, through n8n",
                 calls[0].get("model") == PRIMARY,
                 f"model={calls[0].get('model')}")
        prompt = calls[0]["messages"][0]["content"]
        sc.check("provider prompt grounded in CURRENT canon + chain "
                 "contents (canon id + text, SC1/SC2)",
                 canon in prompt and "CANON MANIFEST v1" in prompt
                 and "SC1" in prompt and "SC2" in prompt,
                 f"prompt_len={len(prompt)}")
    check_refs_proof(sc, pid, u08)
    script = check_script_and_gate(sc, pid, u08)
    fin = fin_rows(u08)
    finz = [e for e in fin if e["charge_class"] == "FINALIZED"]
    calc = [e for e in fin if e["charge_class"] == "CALCULATED"]
    want, raw = expected_calc(USAGE_PRIMARY, PRIMARY)
    sc.check(f"settlement: one CALCULATED == one FINALIZED == {want}c "
             f"(4200x0.0005 + 1600x0.0025 = {raw} -> {want}; not the "
             "estimate)",
             len(calc) == 1 and calc[0]["amount_cents"] == want
             and len(finz) == 1 and finz[0]["amount_cents"] == want,
             json.dumps(fin))
    fu = (finz[0]["usage"] or {}) if finz else {}
    sc.check("F-P4P-02: FINALIZED evidence carries the forwarded usage "
             "(4200 in / 1600 out) + provider_request_id, basis "
             "calculated",
             fu.get("input_tokens") == USAGE_PRIMARY[0]
             and fu.get("output_tokens") == USAGE_PRIMARY[1]
             and fu.get("_finalization_basis") == "calculated"
             and bool(finz) and finz[0]["provider_request_id"]
             == "chatcmpl-mm05-1",
             json.dumps(finz, default=str))
    _, budget = call(API, "GET", f"/productions/{pid}/budget", role="OPERATOR")
    sc.check(f"production budget: spent {270 + want} (chain 270 + "
             "FINALIZED), nothing reserved",
             budget.get("spent_cents") == 270 + want
             and budget.get("reserved_cents") == 0,
             json.dumps(budget))
    # --- no cross-station leakage (registry state; live proof in m05_4)
    pol4 = db("SELECT status FROM model_policies WHERE role='STATION_04'")
    active_assign = db("SELECT DISTINCT role FROM "
                       "operation_model_assignments WHERE status='ACTIVE'")
    sc.check("no leakage: STATION_04 policy still PROPOSED; ACTIVE "
             "assignments exist only under STATION_03",
             pol4 and pol4[0]["status"] == "PROPOSED"
             and [r["role"] for r in active_assign] == ["STATION_03"],
             f"station04={pol4} active_roles={active_assign}")
    return sc.finish({"production_id": pid, "unit_08_12": u08,
                      "script_artifact": script.get("artifact_id")})


def m05_3():
    sc = Scenario("m05_3_fallback")
    record = start_stub("fallback", "m05_3", USAGE_FALLBACK,
                        fail_model=PRIMARY)
    pid, run, canon = make_production("MM-05 M05-3 fallback dispatch via n8n")
    _, _, u07 = build_chain(sc, pid, run, canon)
    u08 = plan_0812(pid, run, canon, u07)
    state = drive_via_n8n(sc, pid, u08, "08.12", approve=False)
    sc.check("08.12 completes to AWAITING_HUMAN via the fallback "
             "segment (primary failed provider-side)",
             state == "AWAITING_HUMAN", f"state={state}")
    calls = stub_calls(record)
    by_model = {}
    for c in calls:
        by_model[c.get("model")] = by_model.get(c.get("model"), 0) + 1
    sc.check("gateway shape at the stub: primary attempted with "
             "bounded retries (3 calls = 1 + 2 retries), fallback "
             "executed exactly once",
             by_model.get(PRIMARY) == 3 and by_model.get(FALLBACK) == 1
             and len(calls) == 4,
             f"by_model={by_model}")
    corr = {c.get("_correlation_id") for c in calls}
    sc.check("one correlation id spans the whole call chain "
             "(retries + fallback)",
             len(corr) == 1 and None not in corr, f"corr={corr}")
    recs = {r["action_key"]: r for r in action_records(u08)}
    build_sum = recs.get("op.build", {}).get("output_summary") or {}
    if isinstance(build_sum, str):
        build_sum = json.loads(build_sum)
    blob = json.dumps(build_sum)
    sc.check("generation action record carries the FALLBACK EVENT "
             "(primary + fallback models + trigger) and names the "
             "executed (fallback) model",
             "fallback" in blob and PRIMARY in blob
             and FALLBACK in blob,
             blob[:500])
    sc.check("action records: 3 SUCCEEDED (manifest/build/emit) on "
             "the fallback completion",
             {k: v["status"] for k, v in recs.items()} ==
             {"inputs.manifest": "SUCCEEDED", "op.build": "SUCCEEDED",
              "output.emit": "SUCCEEDED"},
             json.dumps({k: v["status"] for k, v in recs.items()}))
    fin = fin_rows(u08)
    finz = [e for e in fin if e["charge_class"] == "FINALIZED"]
    calc = [e for e in fin if e["charge_class"] == "CALCULATED"]
    want, raw = expected_calc(USAGE_FALLBACK, FALLBACK)
    at_primary, _ = expected_calc(USAGE_FALLBACK, PRIMARY)
    sc.check(f"CALCULATED at FALLBACK rates: 3900x0.0005 + 2100x0.0030 "
             f"= {raw} -> {want}c (at primary rates it would be "
             f"{at_primary}c — the amounts are distinguishable)",
             len(calc) == 1 and calc[0]["amount_cents"] == want
             and want != at_primary,
             json.dumps(fin))
    fu = (finz[0]["usage"] or {}) if finz else {}
    sc.check("FINALIZED == CALCULATED, carrying ONLY the fallback "
             "call's usage (3900/2100 — failed primary segments "
             "contributed no usage) + the fallback call's request id",
             len(finz) == 1 and finz[0]["amount_cents"] == want
             and fu.get("input_tokens") == USAGE_FALLBACK[0]
             and fu.get("output_tokens") == USAGE_FALLBACK[1]
             and finz[0]["provider_request_id"] == "chatcmpl-mm05-4",
             json.dumps(finz, default=str))
    script = check_script_and_gate(sc, pid, u08)
    return sc.finish({"production_id": pid, "unit_08_12": u08,
                      "script_artifact": script.get("artifact_id"),
                      "calls_by_model": by_model})


def drive_0912(sc, pid, u09, approve=True):
    """Prestage -> g6 dispatch -> end state for a gate-satisfied
    09.12. Returns the end state."""
    wait_state(pid, u09, {"READY"})
    report = scheduler_prestage()
    claimed = [c for c in report["claimed"] if c["unit_id"] == u09]
    sc.check("09.12: scheduler prestaged the claim once the gate was "
             "satisfied", len(claimed) == 1
             and unit_row(pid, u09)["state"] == "CLAIMED",
             f"claimed={claimed}")
    post_dispatch(pid, u09, "09.12", station=4, webhook=WEBHOOK_G6)
    state = wait_state(pid, u09, {"AWAITING_HUMAN", "ACCEPTED", "FAILED",
                                  "BLOCKED", "RETRY_WAIT"})
    if state == "AWAITING_HUMAN" and approve:
        s, _ = call(API, "POST", f"/units/{u09}/events",
                    {"event": "human_approved"}, role="OPERATOR")
        assert s == 200, f"human_approved 09.12 -> {s}"
        state = wait_state(pid, u09, {"ACCEPTED"})
    return state


def m05_4():
    sc = Scenario("m05_4_handoff")
    record = start_stub("ok", "m05_4", USAGE_PRIMARY)
    pid, run, canon = make_production("MM-05 M05-4 handoff to 09.12")
    _, _, u07 = build_chain(sc, pid, run, canon)
    u08 = plan_0812(pid, run, canon, u07)
    state = drive_via_n8n(sc, pid, u08, "08.12", approve=False)
    sc.check("08.12 at AWAITING_HUMAN", state == "AWAITING_HUMAN",
             f"state={state}")
    check_refs_proof(sc, pid, u08)
    script = check_script_and_gate(sc, pid, u08)
    s, _ = call(API, "POST", f"/units/{u08}/events",
                {"event": "human_approved"}, role="OPERATOR")
    state = wait_state(pid, u08, {"ACCEPTED"})
    sc.check("08.12 ACCEPTED (unit-level human approval)",
             s == 200 and state == "ACCEPTED", f"state={state}")
    gates = hg2_gates(pid)
    gid = gates[0]["gate_id"]
    s, out = call(API, "POST", f"/gates/{gid}/decide",
                  {"decision": "APPROVED",
                   "decided_by": "mm05-harness-operator"}, role="OPERATOR")
    grow = db("SELECT verdict, decided_by FROM human_gates "
              "WHERE gate_id=%s", (gid,))
    sc.check("HG2 APPROVED by a recorded OPERATOR human decision "
             "(test fixture decision on stub content)",
             s == 200 and out.get("status") == "APPROVED"
             and grow and grow[0]["verdict"] == "APPROVED"
             and grow[0]["decided_by"] == "mm05-harness-operator",
             f"api={s} {out} db={grow}")
    u09 = plan_unit(pid, run, "09.12", depends=[u08],
                    inputs=[script["artifact_id"]])
    state9 = drive_0912(sc, pid, u09)
    sc.check("09.12 ACCEPTED through the g6 executor after the HG2 "
             "approval", state9 == "ACCEPTED", f"state={state9}")
    dp = current_artifacts(pid).get("direction_package")
    sc.check("direction_package CURRENT exists", bool(dp), f"{dp}")
    if dp:
        content = read_store_artifact(dp)["output_artifacts"][0]["content"]
        sc.check("downstream consumption: direction_package.script_ref "
                 "== the genuine-stub script artifact id",
                 content.get("script_ref") == script["artifact_id"],
                 f"script_ref={content.get('script_ref')} "
                 f"script={script['artifact_id']}")
    man9 = [r for r in action_records(u09)
            if r["action_key"] == "inputs.manifest"]
    man9 = man9[-1] if man9 else {}
    osum9 = man9.get("output_summary") or {}
    if isinstance(osum9, str):
        osum9 = json.loads(osum9)
    # The record stores a digest wrapper {keys, kind, sha256} over the
    # manifest output — prove the refs cryptographically: 09.12 runs
    # the deterministic path, so its refs are its planned inputs ONLY
    # (the script), in order.
    refs9 = [{"artifact_type": "script",
              "artifact_id": script["artifact_id"],
              "sha256": script["sha256"]}]
    exp_out9 = {"inputs": refs9, "count": 1,
                "input_sha256": [script["sha256"]]}
    exp_hash9 = hashlib.sha256(_canon(exp_out9).encode()).hexdigest()
    exp_inputs9 = hashlib.sha256(_canon(
        {"refs": refs9, "prior": {}}).encode()).hexdigest()
    sc.check("09.12's worker refs were exactly the script (manifest "
             "output digest + inputs_hash recomputed and matched — "
             "the record stores a digest wrapper, not the raw list)",
             osum9.get("sha256") == exp_hash9
             and man9.get("inputs_hash") == exp_inputs9,
             f"digest_match={osum9.get('sha256') == exp_hash9} "
             f"inputs_hash_match={man9.get('inputs_hash') == exp_inputs9}")
    atts9 = attempts_of(u09)
    snap9 = atts9[0]["resolved_config"] or {} if atts9 else {}
    if isinstance(snap9, str):
        snap9 = json.loads(snap9)
    sc.check("NO LEAKAGE (live): 09.12's attempt — one attempt under "
             "n8n-executor-g6, adopted, deterministic-local resolution, "
             "NO model_assignment pinned (Station 4 unpromoted)",
             len(atts9) == 1 and atts9[0]["worker_id"] == EXECUTOR_G6
             and atts9[0].get("adopted_at") is not None
             and snap9.get("provider") == "deterministic-local"
             and "model_assignment" not in snap9,
             json.dumps(atts9, default=str)[:400])
    fin9 = fin_rows(u09)
    finz9 = [e for e in fin9 if e["charge_class"] == "FINALIZED"]
    sc.check("09.12 settlement untouched by the multi-model path: "
             "FINALIZED 90c (deterministic reported actual)",
             len(finz9) == 1 and finz9[0]["amount_cents"] == 90,
             json.dumps(fin9))
    return sc.finish({"production_id": pid, "unit_08_12": u08,
                      "unit_09_12": u09,
                      "script_artifact": script.get("artifact_id")})


def m05_5():
    sc = Scenario("m05_5_guards")
    record = start_stub("ok", "m05_5", USAGE_PRIMARY)
    pid, run, canon = make_production("MM-05 M05-5 duplicates + span guards")
    _, _, u07 = build_chain(sc, pid, run, canon)
    u08 = plan_0812(pid, run, canon, u07)
    wait_state(pid, u08, {"READY"})
    scheduler_prestage()
    sc.check("08.12 claim prestaged before the duplicate dispatches",
             unit_row(pid, u08)["state"] == "CLAIMED",
             f"state={unit_row(pid, u08)['state']}")
    post_dispatch(pid, u08, "08.12")
    post_dispatch(pid, u08, "08.12")  # the duplicate
    state = wait_state(pid, u08, {"AWAITING_HUMAN", "ACCEPTED"})
    time.sleep(10)
    calls = stub_calls(record)
    atts = attempts_of(u08)
    finz = [e for e in fin_rows(u08) if e["charge_class"] == "FINALIZED"]
    sc.check("duplicate dispatch: still exactly 1 provider call, 1 "
             "attempt, 1 script artifact, 1 FINALIZED, 1 HG2 gate",
             len(calls) == 1 and len(atts) == 1
             and len(script_artifacts(pid)) == 1 and len(finz) == 1
             and len(hg2_gates(pid)) == 1,
             f"calls={len(calls)} attempts={len(atts)} "
             f"fin={len(finz)} gates={len(hg2_gates(pid))}")
    # --- span guard: step-12 unit to the STATION 04 (g6) webhook ---
    u12 = plan_unit(pid, run, "12.12")
    st12 = unit_row(pid, u12)["state"]
    post_dispatch(pid, u12, "12.12", station=5, webhook=WEBHOOK_G6)
    time.sleep(45)
    atts12 = attempts_of(u12)
    sc.check("span guard (12.12 -> g6 webhook): zero attempts, unit "
             "state unchanged, zero provider calls added",
             len(atts12) == 0 and unit_row(pid, u12)["state"] == st12
             and len(stub_calls(record)) == 1,
             f"attempts={len(atts12)} state {st12} -> "
             f"{unit_row(pid, u12)['state']} calls={len(stub_calls(record))}")
    # --- span guard: Station 03 unit to the g7 webhook ---
    pid2, run2, canon2 = make_production("MM-05 M05-5 span guard g7")
    u08b = plan_unit(pid2, run2, "08.12", inputs=[canon2])
    st8 = unit_row(pid2, u08b)["state"]
    record2 = start_stub("ok", "m05_5_g7", USAGE_PRIMARY)
    post_dispatch(pid2, u08b, "08.12", station=3, webhook=WEBHOOK_G7)
    time.sleep(45)
    atts8 = attempts_of(u08b)
    sc.check("span guard (08.12 -> g7 webhook): zero attempts, unit "
             "state unchanged, zero provider calls",
             len(atts8) == 0 and unit_row(pid2, u08b)["state"] == st8
             and len(stub_calls(record2)) == 0,
             f"attempts={len(atts8)} state {st8} -> "
             f"{unit_row(pid2, u08b)['state']} "
             f"calls={len(stub_calls(record2))}")
    return sc.finish({"production_id": pid, "unit_08_12": u08,
                      "unit_12_12": u12, "production_id_2": pid2,
                      "unit_08_12_g7": u08b})


def m05_6():
    sc = Scenario("m05_6_gate")
    record = start_stub("ok", "m05_6", USAGE_PRIMARY)
    pid, run, canon = make_production("MM-05 M05-6 HG2 not bypassed")
    _, _, u07 = build_chain(sc, pid, run, canon)
    u08 = plan_0812(pid, run, canon, u07)
    state = drive_via_n8n(sc, pid, u08, "08.12", approve=True)
    sc.check("08.12 ACCEPTED (unit-level approval; HG2 gate itself "
             "never decided yet)", state == "ACCEPTED", f"state={state}")
    script = current_artifacts(pid)["script"]
    gates = wait_hg2(pid)
    sc.check("HG2 gate PENDING, bound to the script id+sha",
             len(gates) == 1 and gates[0]["verdict"] == "PENDING"
             and gates[0]["artifact_id"] == script["artifact_id"],
             json.dumps(gates))
    u09 = plan_unit(pid, run, "09.12", depends=[u08],
                    inputs=[script["artifact_id"]])
    wait_state(pid, u09, {"READY"}, timeout=60)
    report = scheduler_prestage()
    sc.check("refusal path 1 — scheduler SKIPS the gate-refused 09.12 "
             "(no claim staged)",
             all(c["unit_id"] != u09 for c in report["claimed"])
             and unit_row(pid, u09)["state"] == "READY",
             f"state={unit_row(pid, u09)['state']}")
    s, out = call(API, "POST", f"/units/{u09}/claim",
                  {"worker_id": EXECUTOR_G6}, role="OPERATOR")
    audit9 = audit_of(u09)
    sc.check("refusal path 2 — direct API claim refused 409 + "
             "gate_claim_refused audit",
             s == 409
             and any(a["event"] == "gate_claim_refused" for a in audit9),
             f"status={s} audit={audit9}")
    post_dispatch(pid, u09, "09.12", station=4, webhook=WEBHOOK_G6)
    time.sleep(45)
    sc.check("refusal path 3 — the g6 executor's own claim refused: "
             "zero attempts, unit still READY, zero provider effects",
             len(attempts_of(u09)) == 0
             and unit_row(pid, u09)["state"] == "READY",
             f"attempts={len(attempts_of(u09))} "
             f"state={unit_row(pid, u09)['state']}")
    gid = gates[0]["gate_id"]
    s, out = call(API, "POST", f"/gates/{gid}/decide",
                  {"decision": "APPROVED",
                   "decided_by": "mm05-harness-operator"}, role="OPERATOR")
    sc.check("OPERATOR HG2 decision recorded (APPROVED)",
             s == 200 and out.get("status") == "APPROVED", f"{s} {out}")
    state9 = drive_0912(sc, pid, u09)
    sc.check("after approval, exactly the gated claim opens: 09.12 "
             "executes through g6 to ACCEPTED with exactly 1 attempt",
             state9 == "ACCEPTED" and len(attempts_of(u09)) == 1,
             f"state={state9} attempts={len(attempts_of(u09))}")
    return sc.finish({"production_id": pid, "unit_08_12": u08,
                      "unit_09_12": u09})


def m05_7():
    sc = Scenario("m05_7_recovery")
    record = start_stub("ok", "m05_7", USAGE_PRIMARY)
    pid, run, canon = make_production("MM-05 M05-7 n8n interruption")
    u05 = plan_unit(pid, run, "05.12", inputs=[canon])
    u06 = plan_unit(pid, run, "06.12", depends=[u05], inputs=[canon])
    for op, uid in (("05.12", u05), ("06.12", u06)):
        state = drive_via_n8n(sc, pid, uid, op)
        sc.check(f"{op} ACCEPTED via n8n before the interruption",
                 state == "ACCEPTED", f"state={state}")
    old_pid = port_pid(5678)
    kill_port(5678)
    time.sleep(2)
    down = not wait_url(N8N + "/healthz", seconds=3)
    dispatch_failed = False
    try:
        post_dispatch(pid, u06, "06.12")
    except Exception:  # noqa: BLE001 — connection refused is the evidence
        dispatch_failed = True
    sc.check("n8n killed mid-chain: health endpoint down and a "
             "dispatch attempt fails (interruption is real)",
             down and dispatch_failed,
             f"down={down} dispatch_failed={dispatch_failed}")
    start_n8n()
    sync_tree("g5")
    new_pid = port_pid(5678)
    sc.check("n8n restarted (new process) + g5 workflows re-synced",
             new_pid is not None and new_pid != old_pid,
             f"pid {old_pid} -> {new_pid}")
    u07 = plan_unit(pid, run, "07.12", depends=[u06], inputs=[canon])
    u08 = plan_0812(pid, run, canon, u07)
    state7 = drive_via_n8n(sc, pid, u07, "07.12")
    state8 = drive_via_n8n(sc, pid, u08, "08.12", approve=False)
    sc.check("chain completes after recovery: 07.12 ACCEPTED, 08.12 "
             "AWAITING_HUMAN",
             state7 == "ACCEPTED" and state8 == "AWAITING_HUMAN",
             f"07={state7} 08={state8}")
    units = {"05.12": u05, "06.12": u06, "07.12": u07, "08.12": u08}
    att_counts = {op: len(attempts_of(u)) for op, u in units.items()}
    fin_counts = {op: len([e for e in fin_rows(u)
                            if e["charge_class"] == "FINALIZED"])
                  for op, u in units.items()}
    sc.check("no duplicates from the interruption: exactly one "
             "attempt + one FINALIZED settlement per unit",
             all(v == 1 for v in att_counts.values())
             and all(v == 1 for v in fin_counts.values()),
             f"attempts={att_counts} finalized={fin_counts}")
    sc.check("exactly one provider call for 08.12 across the "
             "interruption", len(stub_calls(record)) == 1,
             f"calls={len(stub_calls(record))}")
    return sc.finish({"production_id": pid, "units": units,
                      "n8n_pid_before": old_pid, "n8n_pid_after": new_pid})


def _recompute_hash(snap):
    raw = json.dumps(snap, sort_keys=True, default=str).encode()
    return hashlib.sha256(raw).hexdigest()


def m05_8():
    sc = Scenario("m05_8_consistency")
    table = []
    all_ok = True
    for src in ("m05_2_routing", "m05_4_handoff"):
        doc = json.loads((RESULTS / f"{src}.json").read_text())
        pid = doc["production_id"]
        _, uout = call(API, "GET", f"/productions/{pid}/units",
                       role="OPERATOR")
        for u in uout["units"]:
            for att in attempts_of(u["unit_id"]):
                snap = att["resolved_config"] or {}
                if isinstance(snap, str):
                    snap = json.loads(snap)
                plan = db("SELECT plan_hash FROM "
                          "operation_execution_plans WHERE "
                          "operation_id=%s AND plan_version=%s",
                          (u["operation_id"], att["plan_version"]))
                ma = snap.get("model_assignment")
                assign = None
                if ma:
                    assign = db("SELECT policy_id, matrix_version, "
                                "primary_model, fallback_model FROM "
                                "operation_model_assignments WHERE "
                                "operation_id=%s AND status='ACTIVE'",
                                (u["operation_id"],))
                cfg = db("SELECT provider, model FROM provider_configs "
                         "WHERE config_id=%s", (att["config_id"],))
                row = {
                    "source": src, "operation_id": u["operation_id"],
                    "attempt_no": att["attempt_no"],
                    "plan_hash_pin": att["plan_hash"],
                    "plan_hash_current": plan[0]["plan_hash"] if plan else None,
                    "plan_ok": bool(plan)
                    and plan[0]["plan_hash"] == att["plan_hash"],
                    "config_hash_pin": att["resolved_config_hash"],
                    "config_hash_recomputed": _recompute_hash(snap),
                    "config_hash_ok": _recompute_hash(snap)
                    == att["resolved_config_hash"],
                    "snapshot_provider": snap.get("provider"),
                    "snapshot_model": snap.get("model"),
                    "config_row_provider": cfg[0]["provider"] if cfg else None,
                    "config_row_model": cfg[0]["model"] if cfg else None,
                    "config_row_ok": bool(cfg)
                    and cfg[0]["provider"] == snap.get("provider")
                    and cfg[0]["model"] == snap.get("model"),
                    "assignment_pin": ma,
                    "assignment_active_row": assign[0] if assign else None,
                    "assignment_ok": (ma is None and not assign) or
                    (bool(ma) and bool(assign)
                     and ma["primary_model"] == assign[0]["primary_model"]
                     and ma["fallback_model"] == assign[0]["fallback_model"]
                     and ma["matrix_version"] == assign[0]["matrix_version"]
                     and ma["policy_id"] == assign[0]["policy_id"]),
                }
                row_ok = (row["plan_ok"] and row["config_hash_ok"]
                          and row["config_row_ok"] and row["assignment_ok"])
                row["row_ok"] = row_ok
                all_ok = all_ok and row_ok
                table.append(row)
    sc.check("every attempt in the M05-2 + M05-4 productions: "
             "plan_hash == current plans state, resolved_config_hash "
             "recomputes from the pinned snapshot, snapshot == the "
             "provider_configs row it pins, model_assignment == the "
             "ACTIVE registry row (or absent where none is ACTIVE)",
             all_ok and len(table) == 9,
             f"rows={len(table)} all_ok={all_ok}")
    return sc.finish({"attempt_pins": table})


if __name__ == "__main__":
    cmd = sys.argv[1] if len(sys.argv) > 1 else ""
    LOGS.mkdir(parents=True, exist_ok=True)
    RESULTS.mkdir(parents=True, exist_ok=True)
    sys.exit({"setup": setup, "m05_2": m05_2, "m05_3": m05_3,
              "m05_4": m05_4, "m05_5": m05_5, "m05_6": m05_6,
              "m05_7": m05_7, "m05_8": m05_8,
              "teardown": teardown}[cmd]())
