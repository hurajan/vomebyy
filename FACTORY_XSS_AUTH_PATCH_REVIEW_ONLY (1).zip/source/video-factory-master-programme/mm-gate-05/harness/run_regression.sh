#!/usr/bin/env bash
# MM-05 M05-9 — full serial regression (13 suites). Canonical
# commands (same as prior gates' drivers). Logs + SUMMARY in
# mm-gate-05/evidence/logs/regression/. Baseline 239 tests:
# g1 9, g2 81, g3 36, g4 2, g5 1, g6 3, g7 2, g8 1, g9 10,
# worker 54, storage 5, evaluation 25, runtime 10.
set -u
W="$HOME/workspace"
LOGS="$W/video-factory-master-programme/mm-gate-05/evidence/logs/regression"
mkdir -p "$LOGS"
PY="$W/video-factory-g2/.venv/bin/python"
RP="$W/video-factory-real-ai-programme"
SUMMARY="$LOGS/SUMMARY.txt"
: > "$SUMMARY"
run_suite() {
  local name="$1"; shift
  echo "=== $name : $*" | tee -a "$SUMMARY"
  "$@" > "$LOGS/$name.log" 2>&1
  local rc=$?
  local line verdict
  line=$(grep -E "^Ran [0-9]+ tests" "$LOGS/$name.log" | tail -1)
  verdict=$(grep -E "^(OK|FAILED)" "$LOGS/$name.log" | tail -1)
  echo "$name rc=$rc $line $verdict" | tee -a "$SUMMARY"
}
run_suite g1 bash -c "cd '$W/video-factory-g1' && '$PY' -m unittest discover -s tests"
run_suite g2 bash -c "cd '$W/video-factory-g2' && '$PY' -m unittest discover -s tests"
run_suite g3 bash -c "cd '$W/video-factory-g3' && '$PY' -m unittest discover -s tests"
for t in g4 g5 g6 g7 g8; do
  run_suite $t bash -c "python3 '$W/video-factory-$t/tools/setup_env.py' && cd '$W/video-factory-$t' && '$PY' -m unittest discover -s tests"
done
run_suite g9 bash -c "python3 '$W/video-factory-g9/tools/setup_fullrun.py' && cd '$W/video-factory-g9' && '$PY' -m unittest discover -s tests"
run_suite worker bash -c "cd '$RP/gate-c' && '$PY' -m unittest discover -s worker_service/tests"
run_suite storage bash -c "cd '$RP/gate-d' && '$PY' -m unittest discover -s storage_service/tests"
run_suite evaluation bash -c "cd '$RP/gate-e' && '$PY' -m unittest discover -s evaluation_service/tests"
run_suite runtime bash -c "cd '$RP/gate-f' && '$PY' -m unittest discover -s runtime_services/tests"
echo "REGRESSION DONE" | tee -a "$SUMMARY"
