# GATE MM-05 — INDEPENDENT VERIFIER REPORT

**Verifier:** independent verifier agent (own stack, own stub, own numbers)
**Date:** 2026-10-29
**Scope read:** LOCK_MM05.md (incl. Amendments 1–2), evidence/CHANGED_ASSERTIONS.md, evidence/results/*.json, evidence/repair_diff.json
**Verifier evidence:** `evidence/verify/` (confinement.py + results/confinement.json; vfy_stub.py; vfy_harness.py; results/{shape_probe,v1_fallback,v2_primary,v3_recovery,v4_guards,v5_handoff,v5b_handoff_clean}.json; logs/suite_{worker,g5,g6,g9}.log)

## Verdict: **MM-05 PASS** — defects **NONE**

All five verification items pass on independently built evidence. The
battery-proven defect D-MM05-01 is repaired, the repair is confined
exactly as claimed in both its layers, and the repaired behavior is
reproduced end-to-end through real n8n execution on the verifier's
own stack. Everything provider-facing remains STUB_TESTED: no real
credential exists, none was used, and no real provider was contacted.
This PASS is the gate's own criterion — authorized **mock** execution
paths through real n8n — not a genuine-provider claim (MM-12/MM-13).

Verifier independence: scratch DB `mm05_verify_scratch` (dropped
after use), verifier-authored stub on port 8899 (response ids
`chatcmpl-vfy-<seq>`, verifier-authored script content), verifier
usage **5000 input / 1500 output** tokens, and verifier-seeded pricing
rows under version `mm05-verify-2026-10-29` with rates chosen so the
two models price the same usage differently in both directions:
primary `anthropic/claude-opus-4.8` in 0.0006 / out 0.0020 ¢/token
(→ **6.00¢**), fallback `openai/gpt-5.5` in 0.0004 / out 0.0035
¢/token (→ **7.25¢ → 7¢**).

---

## Item 1 — D-MM05-01 repair: **PASS**

### 1a. Fallback through n8n, priced at the EXECUTED model (core reproduction)
Own stack: registry seeded, STATION_03 policy promoted via the API
(test fixture), 08.12 driven through the g5 executor against my stub
failing the primary (HTTP 500, no usage in the error body) and
serving the fallback. Result (v1_fallback, 20/20):
- Stub shape: primary attempted **3×** (1 + 2 bounded retries),
  fallback exactly **1×**; one correlation id spans the whole chain.
- **CALCULATED = FINALIZED = 7¢** — my arithmetic at the FALLBACK
  model's rates (5000×0.0004 + 1500×0.0035 = 7.25 → 7). At the pinned
  primary's rates the same usage prices 6¢, so the amounts are
  distinguishable and the defect (7¢ charged at primary rates in the
  builder's first run, under their numbers) does not recur.
- FINALIZED basis `calculated`, pricing_version
  `mm05-verify-2026-10-29` (my seeded rows), provider_request_id
  `chatcmpl-vfy-4` — my stub's fallback call specifically — and usage
  exactly 5000/1500 (failed primary segments contributed nothing).
- The completion evidence chain is complete: the generation action
  record names the executed model `openai/gpt-5.5` and carries the
  fallback event (primary + fallback + trigger), usage, and request
  id; all three plan action records SUCCEEDED; unit AWAITING_HUMAN;
  one CURRENT script (my stub's text, worker-shaped); HG2 PENDING
  bound to its id+sha; F-P4P-01 refs proof recomputed and matched.
- Primary-success variant (v2_primary, 19/19): the same usage prices
  **6¢** at the PRIMARY rates, evidence names the primary model, and
  **no fallback event** exists. The two-layer repair is confirmed as
  a composed path: plan summary → service.py gateway mapping → /work
  response → executor jsonBody forward → /complete pricing. Neither
  layer alone sufficed in the builder's runs; together they price
  correctly through n8n.

### 1b. Workflow confinement
My own normalization (UUID-regex scrub + canonical JSON) of all 26
current on-disk workflows against the F-P4P baseline snapshots
(lean-phase-4-prep/fix/evidence/fixed_normalized/):
- **Only the 5 unit-executor files differ**; the other 21 are
  identical after normalization.
- Field-level diff within each unit-executor: **exactly one field**,
  `.nodes[N].parameters.jsonBody` (N = 19/19/21/21/19 for g4–g8),
  matching repair_diff.json path-for-path.
- Full string diff of that field: the **only** change is the appended
  `, model: $json.model` before the closing of the JSON.stringify
  object — the F-P4P-02 fields (usage, provider_request_id) are
  untouched.
- All 26 current files also match the builder's repair_normalized
  snapshots (after harmonizing their `<uuid>` scrub token vs the
  F-P4P verifier's `UUID` — a cosmetic convention difference, zero
  content difference). All five `tools/gen_workflows.py` generators
  carry `model: $json.model` alongside the earlier forwards.

### 1c. service.py confinement
- Exactly **one** MM-05-tagged site exists in the file: the comment +
  `"gateway": {model, correlation_id, usage_lines, fallback_event}`
  mapping built from the plan summary in the provider-dispatch plan
  branch of `run_work` — precisely the Amendment 2 description.
  `_result_payload`, the payload-provider branch, and the
  direct-adapter branch carry no MM-05 change (source read).
- Empirical shape probe (direct API claim of a 06.12 unit under a
  probe identity + direct /work with the executor-shaped body): the
  deterministic response key set is
  `[actual_cost_cents, artifact_type, content, correlation_id,
  model, plan_execution, provider_request_id, status, usage,
  usage_lines]` with `model: null` and **no** `fallback_event` key —
  the MM-04 gateway-era shape (gateway metadata attached by
  `execute_chain`, line 451, MM-04 code), unchanged by this repair.
  The repair's response-shape effect is confined to the
  provider-dispatch plan path, which previously lacked these keys
  entirely — that absence was the defect's second layer.
- Supporting (not sufficient alone, per the brief): worker service
  suite **54/54 OK** on current code (Item 5).

## Item 2 — Routing spot (M05-2): **PASS**
With the policy promoted, the attempt snapshot pins the MM-03
assignment (primary `anthropic/claude-opus-4.8`, fallback
`openai/gpt-5.5`, matrix 1.0.0, policy-station-03) and my stub
received **exactly one call, model = the assignment's opus-4.8**,
its prompt grounded in the CURRENT canon + chain contents. The
unpromoted side keeps its prior resolution: STATION_04 policy still
PROPOSED, ACTIVE assignments exist only under STATION_03, and the
live 09.12 attempt (Item 4/v5b) resolved the STATION
deterministic-local binding with **no `model_assignment`** in its
snapshot.

## Item 3 — Recovery spot (M05-7): **PASS**
Mid-chain kill on the Station 03 chain (05.12 + 06.12 ACCEPTED, then
n8n killed — health endpoint down and a dispatch attempt provably
failed), restart as a new process + g5 re-sync, chain completed:
07.12 ACCEPTED, 08.12 AWAITING_HUMAN, **exactly one attempt and one
FINALIZED settlement per unit**, exactly one provider call.

## Item 4 — Guards spot (M05-5/6): **PASS**
- Duplicate dispatch of a prestaged 08.12: **1 provider call, 1
  attempt, 1 script, 1 FINALIZED, 1 HG2 gate**.
- Step-12 unit dispatched to the g6 webhook: **zero attempts**, unit
  state unchanged (READY → READY), no provider calls (span guard).
- 09.12 claim while HG2 PENDING: scheduler **skips** the unit (no
  claim staged), direct API claim refused **409**, and a
  `gate_claim_refused` audit event is committed.
- Handoff (v5 + clean re-run v5b, 16/16): the recorded OPERATOR HG2
  decision opens exactly the gated claim — 09.12 prestaged, adopted
  by `n8n-executor-g6`, ACCEPTED; `direction_package.script_ref`
  equals the script artifact id; FINALIZED 90¢ (deterministic
  reported actual, untouched by the multi-model path).

## Item 5 — Regression spot: **PASS** (serial, counts from my logs)
- worker service: **Ran 54 tests — OK**
- g5 suite: **Ran 1 test — OK**
- g6 suite: **Ran 3 tests — OK**
- g9 suite: **Ran 10 tests — OK**; the persisted full-run production
  in `g9_fullrun_scratch` reads **18 units, 18 ACCEPTED, 18
  FINALIZED rows summing exactly 1620¢** (queried directly, not
  taken from the suite verdict).

---

## Observations (non-blocking)

- **O1 — attempt status label while parked.** A unit at
  AWAITING_HUMAN shows its attempt as `FAILED`; the human decision
  flips both unit and attempt to ACCEPTED (probed live on the
  verifier's V1 unit). This is pre-existing lifecycle semantics from
  the Gate G / Gate 05 era — the repair touches nothing in attempt
  status handling, and settlement, gates, and approvals all behave
  correctly — but the label is counterintuitive in operator views.
  Recorded as a register note for production-identity/dashboard
  work, not a defect against MM-05.
- **O2 — verifier-side disclosures.** (i) My first v5 run reported
  two failed sub-checks (scheduler prestage missed 09.12; attempt
  not adopted). Root cause was my own scratch state: three abandoned
  shape-probe claims plus the span-guard unit filled the text
  lane's `capacity_policies.max_concurrency = 4`, so the scheduler
  skipped 09.12 by design and the executor used its own-claim path;
  every substantive handoff property still passed. The clean-DB
  re-run (v5b, 16/16) supersedes it with the prestage + adopt path
  exercised. (ii) The v2 scenario executed twice (command
  chaining); both runs passed 19/19 and the results file holds the
  second run. (iii) My shape probe's first attempt failed on a
  wrong assumption about the claim response (the resolved config
  rides the attempt snapshot, not the claim body) — a probe bug,
  corrected; product behavior was correct throughout.

## Gate verdict

Against the PASS condition — *"all six stations complete their
authorized mock execution paths through real n8n workflow
execution"* — **MM-05 PASSES**. The station mock paths are evidenced
by the builder's M05-1 (all station suites + G9 through n8n) and
independently corroborated here for g5/g6/g9 on current code; the
multi-model execution path the gate adds (registry-pinned routing,
authorized fallback priced at the executed model, CURRENT-upstream
loading, HG2-gated handoff, duplicate/span/gate guards, interruption
recovery) is independently reproduced through real n8n execution in
Items 1–4. The one defect the battery found (D-MM05-01) is fixed,
confined to the claimed seams in both layers, and verified fixed
with distinguishable arithmetic. No real-provider claim is made or
implied by this verdict.
