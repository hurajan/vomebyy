# MM-05 CHANGED ASSERTIONS

## D-MM05-01 repair (battery-proven defect; LOCK_MM05.md Amendment 1)

**Defect.** M05-3 first run (preserved:
`evidence/results/m05_3_fallback_run1_failed.json`, 15/17): a gateway
fallback completion driven through n8n was priced at the pinned
PRIMARY model's rates — CALCULATED/FINALIZED 7¢ (3900×0.0005 +
2100×0.0025, opus-4.8 rates) instead of 8¢ at the executed FALLBACK
model's rates (3900×0.0005 + 2100×0.0030, gpt-5.5 rates). Every other
fallback property held (bounded retries 3+1 calls, one correlation
id, fallback event + executed model in the action record, fallback
usage + request id forwarded). Root cause: the unit-executor's
submit-candidate node — the /complete caller on the n8n path — did
not forward the executed `model`, although MM-04 made /complete
accept it and the worker's /work response carries it
(`payload["model"]`). MM-04's battery priced fallback correctly via
the worker-direct completion path only; the n8n path was untested
until this gate.

**Repair (two layers — the first alone was insufficient, and the
re-run proved it).**
1. Executor layer: `video-factory-g{4,5,6,7,8}/tools/gen_workflows.py`
   — the submit-candidate body additionally forwards
   `model: $json.model` verbatim (the F-P4P-02 pattern; absent fields
   are dropped, so deterministic completions are unchanged in
   effect). Workflows regenerated in all five trees.
2. Worker layer (LOCK_MM05.md Amendment 2): after layer 1, the
   M05-3 re-run still priced 7¢ — on the plan-execution path the
   /work response carried no `model` at all. `_result_payload`
   surfaces gateway metadata only from `result["gateway"]`, which
   MM-04 populated for the direct adapter path; the provider-dispatch
   plan branch in `run_work` (worker_service/service.py) built its
   result from the plan summary — which already carries the executed
   `model`, `correlation_id`, `usage_lines`, `fallback_event` —
   without mapping them into `result["gateway"]`. The repair adds
   exactly that mapping (one dict entry, one branch). No change to
   `_result_payload`, plan_exec, the gateway, or any other branch.

After both layers: **M05-3 PASS 17/17** (CALCULATED = FINALIZED = 8¢
at fallback rates; fallback usage + request id carried) and
**M05-2 PASS 22/22** (primary path unchanged, 6¢ at primary rates).
Confinement for the workflow side is proven in
`evidence/repair_diff.json` (only the 5 unit-executor jsonBody
fields differ from the F-P4P baseline); the service.py change is a
single anchored block in one branch.

## Harness assertion correction (M05-4, run 1 — harness bug, not a product defect)

M05-4 run 1 (preserved: `evidence/results/m05_4_handoff_run1.json`,
20/21) failed one check: "09.12's worker refs carried the script".
The assertion read the manifest action record's `output_summary`
expecting the raw inputs list; the record actually stores plan_exec's
digest wrapper `{keys, kind, sha256}` over the manifest output.
Verified against the persisted run-1 production by hand: recomputing
the manifest output digest and the inputs_hash for refs == [script
id+sha] reproduces the stored values exactly
(9e1590f2… / 8b66a1b0…) — 09.12's worker received exactly the script
reference, and the direction_package's script_ref already proved
consumption. The assertion was rewritten to the same cryptographic
digest form the F-P4P-01 proof uses (planned-only refs for the
deterministic path). No product code was touched for this item.

## Harness threshold correction (M05-8, run 1 — harness bug, not a product defect)

M05-8 run 1 reported FAIL (0/1) while its own tabulation showed all
9 attempt rows fully consistent (`all_ok=True`: plan hashes, recomputed
config hashes, config-row equality, assignment pins). The check also
asserted `len(table) >= 10`; the two tabulated productions contain
exactly 9 attempts (M05-2: 4 units; M05-4: 5 units, one attempt each).
Threshold corrected to `== 9` and the scenario re-run. The full
9-row table is preserved in the result JSON either way.

## Test-fixture compositions (not product changes; recorded in LOCK_MM05.md)

- STATION_03 policy promoted via the API in the battery DB (OPERATOR,
  approval note recorded in policy_events) — a test-fixture promotion.
- Station 3's deterministic-local STATION binding seeded via
  POST /configs after promotion, superseding only promotion's
  station-scope row (plan-bound chain ops keep existing resolution);
  promotion's OPERATION rows untouched.
- The promoted 08.12 OPERATION row's params received a `base_url`
  override to the local stub via direct SQL in the scratch DB
  (per-DB test seeding; canonical promotion carries no base_url).
- Pricing rows for the two matrix models seeded via POST
  /pricing-rules at the MM-02 catalog's published prices converted to
  cents/token, pricing version `mm05-2026-10-29`.
