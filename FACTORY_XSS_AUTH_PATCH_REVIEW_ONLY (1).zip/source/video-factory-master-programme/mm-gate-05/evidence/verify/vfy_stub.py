#!/usr/bin/env python3
"""MM-05 VERIFIER stub — my own OpenRouter-shaped stub provider.

Independent implementation for verification only. Serves the
chat-completions shape on localhost; records every request (model,
correlation header, sequence) as JSON lines. Response ids are
chatcmpl-vfy-<seq> so evidence ties a completion's
provider_request_id to exactly one recorded request.

Usage: vfy_stub.py <port> <mode> <record_file> <in_tokens> <out_tokens>
       [fail_model]
  mode ok       -> 200 + canned script completion + usage, any model
  mode fallback -> model == fail_model gets HTTP 500 with NO usage in
                   the error body; any other model gets the 200

The canned script is my own fixture text. Its V2 line deliberately
carries a bogus canon_ref and V3 omits beat_ref/story_ref, so the
assertions prove worker-side shaping (canon_refs set from the real
canon artifact id; missing refs derived) rather than model trust.
"""
import json
import sys
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

PORT = int(sys.argv[1])
MODE = sys.argv[2]
RECORD = Path(sys.argv[3])
IN_TOKENS = int(sys.argv[4])
OUT_TOKENS = int(sys.argv[5])
FAIL_MODEL = sys.argv[6] if len(sys.argv) > 6 else None

CANNED = {
    "kind": "script",
    "lines": [
        {"id": "V1", "scene_ref": "SC1", "beat_ref": "B1",
         "story_ref": "S1", "canon_refs": ["vfy-stub-placeholder"],
         "text": "Wren holds the silver compass to the lamplight; "
                 "the needle points inland, toward the marsh road."},
        {"id": "V2", "scene_ref": "SC2", "beat_ref": "B2",
         "story_ref": "S2", "canon_refs": ["vfy-invented-ref"],
         "text": "Cas locks the boathouse and hides the tide log "
                 "beneath the loose board."},
        {"id": "V3", "scene_ref": "SC1",
         "text": "The tide log is missing; only wet footprints remain."},
    ],
    "trace": {
        "clues": [{"id": "CV1", "planted": "V1", "payoff": "V3"}],
        "knowledge": [{"character": "Wren", "learns": "CV1", "at": "V2"}],
        "payoffs": [{"id": "PV1", "clue": "CV1", "line": "V3"}]},
    "canon_refs": ["vfy-invented-ref"],
}

_count = {"n": 0}


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _send(self, code, obj):
        payload = json.dumps(obj).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(payload)))
        self.end_headers()
        self.wfile.write(payload)

    def do_POST(self):
        raw = self.rfile.read(int(self.headers.get("Content-Length") or 0))
        try:
            body = json.loads(raw or b"{}")
        except json.JSONDecodeError:
            body = {}
        _count["n"] += 1
        n = _count["n"]
        rec = {"seq": n, "model": body.get("model"),
               "correlation": self.headers.get("X-Correlation-Id"),
               "prompt": ((body.get("messages") or [{}])[0].get("content")
                          or "")}
        with RECORD.open("a") as fh:
            fh.write(json.dumps(rec) + "\n")
        if MODE == "fallback" and body.get("model") == FAIL_MODEL:
            self._send(500, {"error": {
                "message": f"vfy stub failure for {FAIL_MODEL}",
                "type": "vfy_stub_error", "code": 500}})
            return
        self._send(200, {
            "id": f"chatcmpl-vfy-{n}",
            "choices": [{"message": {"role": "assistant",
                                     "content": json.dumps(CANNED)}}],
            "usage": {"prompt_tokens": IN_TOKENS,
                      "completion_tokens": OUT_TOKENS,
                      "total_tokens": IN_TOKENS + OUT_TOKENS}})


if __name__ == "__main__":
    RECORD.parent.mkdir(parents=True, exist_ok=True)
    ThreadingHTTPServer(("127.0.0.1", PORT), Handler).serve_forever()
