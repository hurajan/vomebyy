#!/usr/bin/env python3
"""MM-05 INDEPENDENT VERIFIER battery.

My own stack (DB mm05_verify_scratch), my own stub (vfy_stub.py,
port 8899), my own usage numbers and MY OWN pricing rows:

  usage (both provider scenarios): 5000 input / 1500 output tokens
  rates (pricing version mm05-verify-2026-10-29, cents/token):
    primary  anthropic/claude-opus-4.8 : in 0.0006, out 0.0020
    fallback openai/gpt-5.5            : in 0.0004, out 0.0035
  => primary execution prices 5000*.0006 + 1500*.0020 = 6.00 -> 6c
  => fallback execution prices 5000*.0004 + 1500*.0035 = 7.25 -> 7c
  The two pricings are distinct in BOTH directions, so a completion
  priced at the wrong model's rates is arithmetically detectable.

Scenarios: setup | shape | v1 | v2 | v3 | v4 | v5 | teardown
  shape — deterministic /work response-shape probe (direct claim +
          direct /work, executor-shaped body; raw keys recorded).
  v1    — D-MM05-01 core: fallback through n8n priced at FALLBACK.
  v2    — primary through n8n priced at PRIMARY + routing (the stub
          receives the assignment's model) + no-leakage DB checks.
  v3    — mid-chain n8n kill / restart / completion, 1 attempt and
          1 settlement per unit.
  v4    — guards: duplicate dispatch, span guard (12.12 -> g6),
          HG2-PENDING claim refusal (scheduler skip + direct 409 +
          gate_claim_refused audit).
  v5    — handoff: HG2 approval opens 09.12 through g6; snapshot
          carries no model_assignment; FINALIZED 90.
All provider contact is against my local stub: STUB_TESTED only.
"""
import hashlib
import importlib.util
import json
import os
import re
import subprocess
import sys
import time
import urllib.error
import urllib.request
from decimal import ROUND_HALF_UP, Decimal
from pathlib import Path

import psycopg
from psycopg.rows import dict_row

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent.parent                      # mm-gate-05/
LOGS = HERE / "logs"
RESULTS = HERE / "results"
STATE = HERE / "vfy_state.json"
HOME = Path.home()
G2 = HOME / "workspace/video-factory-g2"
G3 = HOME / "workspace/video-factory-g3"
G4T = HOME / "workspace/video-factory-g4"
G5 = HOME / "workspace/video-factory-g5"
PROG = HOME / "workspace/video-factory-real-ai-programme"
MM03 = HOME / "workspace/video-factory-master-programme/mm-gate-03"
VENV_PY = str(G2 / ".venv/bin/python")
STORE = PROG / "gate-d/storage_service/.store"
DB = "mm05_verify_scratch"


def _fixture_password():
    src = (G2 / "tools/setup_db.py").read_text()
    return re.search(
        r"CREATE ROLE factory LOGIN PASSWORD '([^']+)'", src).group(1)


DSN = ("host=127.0.0.1 dbname=" + DB + " user=factory password="
       + _fixture_password())
API = "http://127.0.0.1:8730"
WORKER = "http://127.0.0.1:8795"
EVAL = "http://127.0.0.1:8796"
N8N = "http://127.0.0.1:5678"
WEBHOOK_G5 = N8N + "/webhook/dispatch-g5"
WEBHOOK_G6 = N8N + "/webhook/dispatch-g6"
STUB_PORT = 8899
STUB_URL = f"http://127.0.0.1:{STUB_PORT}"
TOKENS = {"FACTORY_API_TOKEN": "dev-operator-token",
          "FACTORY_WORKER_TOKEN": "dev-worker-token",
          "FACTORY_SCHEDULER_TOKEN": "dev-scheduler-token",
          "FACTORY_VALIDATOR_TOKEN": "dev-validator-token",
          "FACTORY_CALLBACK_TOKEN": "dev-callback-token"}
OPERATOR = TOKENS["FACTORY_API_TOKEN"]
CANON_TEXT = ("CANON MANIFEST v1 — universe, chronology, world rules, "
              "knowledge boundaries released.")
PRIMARY = "anthropic/claude-opus-4.8"
FALLBACK = "openai/gpt-5.5"
PROVIDER = "openrouter-compatible"
PRICING_VERSION = "mm05-verify-2026-10-29"
RATES = {PRIMARY: (Decimal("0.0006"), Decimal("0.0020")),
         FALLBACK: (Decimal("0.0004"), Decimal("0.0035"))}
USAGE = (5000, 1500)
EXECUTOR_G5 = "n8n-executor-g5"
EXECUTOR_G6 = "n8n-executor-g6"


def expected_calc(usage, model):
    rin, rout = RATES[model]
    total = Decimal(usage[0]) * rin + Decimal(usage[1]) * rout
    return int(total.quantize(Decimal("1"), rounding=ROUND_HALF_UP)), total


# ------------------------------------------------------------------ http
def call(base, method, path, body=None, role=None):
    req = urllib.request.Request(base + path, method=method)
    data = None
    if role == "OPERATOR":
        req.add_header("X-Operator-Token", OPERATOR)
    if body is not None:
        data = json.dumps(body).encode()
        req.add_header("Content-Type", "application/json")
    try:
        with urllib.request.urlopen(req, data=data, timeout=30) as r:
            return r.status, json.loads(r.read() or b"{}")
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read() or b"{}")


def db(sql, args=()):
    with psycopg.connect(DSN, row_factory=dict_row, autocommit=True) as conn:
        cur = conn.execute(sql, args)
        try:
            return cur.fetchall()
        except psycopg.errors.ProgrammingError:
            return []


# -------------------------------------------------------------- processes
def kill_port(port):
    subprocess.run(["fuser", "-k", f"{port}/tcp"], capture_output=True)
    time.sleep(0.5)


def port_pid(port):
    r = subprocess.run(["fuser", f"{port}/tcp"], capture_output=True,
                       text=True)
    pids = (r.stdout + r.stderr).split()
    return pids[-1] if pids else None


def spawn(cmd, env, log_name):
    e = dict(os.environ)
    e.update(env)
    out = open(LOGS / log_name, "ab")
    return subprocess.Popen(cmd, env=e, stdout=out, stderr=out,
                            start_new_session=True)


def wait_url(url, seconds=60):
    deadline = time.time() + seconds
    while time.time() < deadline:
        try:
            with urllib.request.urlopen(url, timeout=2) as r:
                if r.status == 200:
                    return True
        except urllib.error.HTTPError:
            return True
        except Exception:  # noqa: BLE001
            pass
        time.sleep(0.5)
    return False


def start_stub(mode, tag):
    kill_port(STUB_PORT)
    record = HERE / f"stub_requests_{tag}.jsonl"
    if record.exists():
        record.unlink()
    args = [sys.executable, str(HERE / "vfy_stub.py"), str(STUB_PORT),
            mode, str(record), str(USAGE[0]), str(USAGE[1])]
    if mode == "fallback":
        args.append(PRIMARY)
    spawn(args, {}, f"vfy_stub_{tag}.log")
    if not wait_url(STUB_URL + "/chat/completions", seconds=15):
        raise SystemExit("vfy stub did not come up")
    record.write_text("")
    return record


def stub_calls(record):
    if not record.exists():
        return []
    return [json.loads(l) for l in record.read_text().splitlines() if l]


# ---------------------------------------------------------------- driver
class Scenario:
    def __init__(self, name, label="STUB_TESTED"):
        self.name = name
        self.label = label
        self.checks = []

    def check(self, name, ok, detail=""):
        self.checks.append({"name": name, "pass": bool(ok),
                            "detail": str(detail)[:900]})
        print(f"  [{'PASS' if ok else 'FAIL'}] {name} — "
              f"{str(detail)[:200]}")

    def finish(self, extra=None):
        verdict = all(c["pass"] for c in self.checks)
        doc = {"scenario": self.name,
               "verdict": "PASS" if verdict else "FAIL",
               "label": self.label, "checks": self.checks,
               **(extra or {})}
        RESULTS.mkdir(parents=True, exist_ok=True)
        (RESULTS / f"{self.name}.json").write_text(
            json.dumps(doc, indent=1, sort_keys=True, default=str))
        print(f"{self.name}: {'PASS' if verdict else 'FAIL'} "
              f"({sum(1 for c in self.checks if c['pass'])}/"
              f"{len(self.checks)})")
        return 0 if verdict else 1


def unit_row(pid, uid):
    _, out = call(API, "GET", f"/productions/{pid}/units", role="OPERATOR")
    return [u for u in out["units"] if u["unit_id"] == uid][0]


def wait_state(pid, uid, states, timeout=420):
    deadline = time.time() + timeout
    state = None
    while time.time() < deadline:
        state = unit_row(pid, uid)["state"]
        if state in states:
            return state
        time.sleep(2)
    raise AssertionError(f"unit {uid} stuck in {state}, wanted {states}")


def current_artifacts(pid):
    _, out = call(API, "GET", f"/productions/{pid}/artifacts",
                  role="OPERATOR")
    return {a["artifact_type"]: a for a in out["artifacts"]
            if a["state"] == "CURRENT"}


def scheduler_prestage():
    sys.path.insert(0, str(PROG / "gate-f"))
    from runtime_services.scheduler_service import SchedulerService
    return SchedulerService(dsn=DSN).run_once()


def post_dispatch(pid, uid, op, station, webhook):
    payload = {"production_id": pid, "unit_id": uid, "operation_id": op,
               "station": station, "input_artifact_ids": [],
               "force_fail": False, "idempotency_key": f"dispatch:{uid}:1"}
    req = urllib.request.Request(webhook, method="POST",
                                 data=json.dumps(payload).encode(),
                                 headers={"Content-Type":
                                          "application/json"})
    deadline = time.time() + 60
    while True:
        try:
            with urllib.request.urlopen(req, timeout=120) as r:
                return r.status
        except urllib.error.HTTPError as e:
            if e.code == 404 and time.time() < deadline:
                time.sleep(3)
                continue
            raise


def make_production(title):
    s, p = call(API, "POST", "/productions",
                {"title": title, "hard_ceiling_cents": 500,
                 "soft_ceiling_cents": 250}, role="OPERATOR")
    assert s == 201, f"production create {s}: {p}"
    pid = p["production_id"]
    s, r = call(API, "POST", f"/productions/{pid}/runs", {"kind": "FULL"},
                role="OPERATOR")
    assert s == 201, f"run create {s}: {r}"
    s, a = call(API, "POST", f"/productions/{pid}/artifacts",
                {"artifact_type": "canon_manifest", "content": CANON_TEXT,
                 "storage_uri": "local://canon-fixture"}, role="OPERATOR")
    assert s == 201, f"canon register {s}: {a}"
    return pid, r["run_id"], a["artifact_id"]


def plan_unit(pid, run, op, depends=(), inputs=()):
    s, u = call(API, "POST", f"/productions/{pid}/units",
                {"operation_id": op, "run_id": run, "unit_key": "main",
                 "depends_on": list(depends),
                 "input_artifact_ids": list(inputs)}, role="OPERATOR")
    assert s == 201, f"plan {op} {s}: {u}"
    return u["unit_id"]


def drive_via_n8n(sc, pid, uid, op, approve=True, station=3,
                  webhook=None):
    wait_state(pid, uid, {"READY"})
    report = scheduler_prestage()
    claimed = [c for c in report["claimed"] if c["unit_id"] == uid]
    sc.check(f"{op}: scheduler prestaged the claim",
             len(claimed) == 1
             and unit_row(pid, uid)["state"] == "CLAIMED",
             f"claimed={claimed}")
    post_dispatch(pid, uid, op, station, webhook or WEBHOOK_G5)
    state = wait_state(pid, uid, {"AWAITING_HUMAN", "ACCEPTED", "FAILED",
                                  "BLOCKED", "RETRY_WAIT"})
    if state == "AWAITING_HUMAN" and approve:
        s, _ = call(API, "POST", f"/units/{uid}/events",
                    {"event": "human_approved"}, role="OPERATOR")
        assert s == 200, f"human_approved {op} -> {s}"
        state = wait_state(pid, uid, {"ACCEPTED"})
    return state


def build_chain(sc, pid, run, canon):
    u05 = plan_unit(pid, run, "05.12", inputs=[canon])
    u06 = plan_unit(pid, run, "06.12", depends=[u05], inputs=[canon])
    u07 = plan_unit(pid, run, "07.12", depends=[u06], inputs=[canon])
    for op, uid in (("05.12", u05), ("06.12", u06), ("07.12", u07)):
        state = drive_via_n8n(sc, pid, uid, op)
        sc.check(f"{op} ACCEPTED via n8n (prestage + adopt)",
                 state == "ACCEPTED", f"state={state}")
    return u05, u06, u07


def attempts_of(uid):
    return db("SELECT attempt_no, worker_id, status, adopted_by, "
              "adopted_at, resolved_config, resolved_config_hash, "
              "plan_hash FROM action_attempts WHERE unit_id=%s "
              "ORDER BY attempt_no", (uid,))


def audit_of(uid):
    return db("SELECT event_type AS event, actor FROM audit_events "
              "WHERE unit_id=%s ORDER BY created_at", (uid,))


def action_records(uid):
    return db("SELECT action_key, status, output_summary, error, "
              "inputs_hash FROM plan_action_attempts WHERE unit_id=%s "
              "ORDER BY seq, recorded_at", (uid,))


def fin_rows(uid):
    rows = db("SELECT e.charge_class, e.amount_cents, "
              "e.pricing_version, e.provider_request_id, e.usage "
              "FROM financial_evidence e JOIN action_attempts a "
              "ON a.attempt_id=e.attempt_id WHERE a.unit_id=%s "
              "ORDER BY e.created_at", (uid,))
    out = []
    for e in rows:
        usage = e.get("usage")
        if isinstance(usage, str):
            usage = json.loads(usage)
        out.append({**e, "usage": usage})
    return out


def script_artifacts(pid):
    _, out = call(API, "GET", f"/productions/{pid}/artifacts",
                  role="OPERATOR")
    return [a for a in out["artifacts"] if a["artifact_type"] == "script"]


def hg2_gates(pid):
    _, out = call(API, "GET", f"/productions/{pid}/gates", role="OPERATOR")
    return [g for g in out["gates"] if g["gate_kind"] == "HG2"]


def wait_hg2(pid, timeout=120):
    deadline = time.time() + timeout
    while time.time() < deadline:
        gates = hg2_gates(pid)
        if gates:
            return gates
        time.sleep(2)
    return []


def read_store_artifact(artifact):
    raw = (STORE / "objects" / artifact["sha256"]).read_bytes()
    return json.loads(raw)


def _canon(value):
    return json.dumps(value, sort_keys=True, default=str)


def expected_refs(pid, uid):
    _, uout = call(API, "GET", f"/productions/{pid}/units", role="OPERATOR")
    units = {u["unit_id"]: u for u in uout["units"]}
    me = units[uid]
    _, aout = call(API, "GET", f"/productions/{pid}/artifacts",
                   role="OPERATOR")
    by_id = {a["artifact_id"]: a for a in aout["artifacts"]}
    refs, seen = [], set()
    for aid in me.get("input_artifact_ids", []):
        a = by_id[aid]
        refs.append({"artifact_type": a["artifact_type"],
                     "artifact_id": a["artifact_id"],
                     "sha256": a["sha256"]})
        seen.add(aid)
    for a in aout["artifacts"]:
        if a["state"] != "CURRENT" or not a.get("produced_by_unit"):
            continue
        if a["produced_by_unit"] == uid or a["artifact_id"] in seen:
            continue
        producer = units.get(a["produced_by_unit"])
        if not producer or producer["state"] != "ACCEPTED":
            continue
        if producer.get("run_id") != me.get("run_id"):
            continue
        refs.append({"artifact_type": a["artifact_type"],
                     "artifact_id": a["artifact_id"],
                     "sha256": a["sha256"]})
        seen.add(a["artifact_id"])
    return refs


def check_refs_proof(sc, pid, uid):
    man = [r for r in action_records(uid)
           if r["action_key"] == "inputs.manifest"]
    man = man[-1] if man else {}
    refs = expected_refs(pid, uid)
    exp_inputs_hash = hashlib.sha256(_canon(
        {"refs": refs, "prior": {}}).encode()).hexdigest()
    exp_output = {"inputs": refs, "count": len(refs),
                  "input_sha256": [r["sha256"] for r in refs]}
    exp_output_hash = hashlib.sha256(_canon(exp_output).encode()).hexdigest()
    osum = man.get("output_summary") or {}
    if isinstance(osum, str):
        osum = json.loads(osum)
    sc.check("F-P4P-01 preserved: worker refs == planned [canon] + "
             "dependency CURRENT outputs (inputs_hash + manifest "
             "digest recomputed and matched)",
             [r["artifact_type"] for r in refs] ==
             ["canon_manifest", "beat_graph", "scene_set",
              "story_architecture"]
             and man.get("inputs_hash") == exp_inputs_hash
             and osum.get("sha256") == exp_output_hash,
             f"types={[r['artifact_type'] for r in refs]} "
             f"inputs_hash_match={man.get('inputs_hash') == exp_inputs_hash} "
             f"digest_match={osum.get('sha256') == exp_output_hash}")
    return refs


def check_script_and_gate(sc, pid):
    scripts = script_artifacts(pid)
    cur = [a for a in scripts if a["state"] == "CURRENT"]
    sc.check("exactly one script artifact, CURRENT",
             len(scripts) == 1 and len(cur) == 1,
             f"scripts={[(a['artifact_id'][:8], a['state']) for a in scripts]}")
    script = cur[0] if cur else {}
    if script:
        envelope = read_store_artifact(script)
        deliverable = envelope["output_artifacts"][0]["content"]
        _, arts = call(API, "GET", f"/productions/{pid}/artifacts",
                       role="OPERATOR")
        canon_id = [a["artifact_id"] for a in arts["artifacts"]
                    if a["artifact_type"] == "canon_manifest"][0]
        texts = [l["text"] for l in deliverable["lines"]]
        sc.check("script content is MY stub's text, worker-shaped "
                 "(canon_refs worker-set from the real canon id, "
                 "despite the stub's bogus/omitted refs)",
                 deliverable.get("kind") == "script"
                 and all(l["canon_refs"] == [canon_id]
                         for l in deliverable["lines"])
                 and any("silver compass" in t for t in texts),
                 f"lines={len(deliverable.get('lines', []))}")
    gates = wait_hg2(pid)
    sc.check("HG2 gate created by the station flow, PENDING, bound "
             "to the script id+sha",
             len(gates) == 1 and bool(script)
             and gates[0]["artifact_id"] == script["artifact_id"]
             and gates[0]["artifact_sha256"] == script["sha256"]
             and gates[0]["verdict"] == "PENDING",
             json.dumps(gates)[:300])
    return script


# ------------------------------------------------------------------ n8n
def start_n8n():
    kill_port(5678)
    time.sleep(1)
    spawn([str(G4T / "node_modules/.bin/n8n"), "start"],
          {"N8N_USER_FOLDER": str(G4T / "n8n-data"), "N8N_PORT": "5678",
           "N8N_LISTEN_ADDRESS": "127.0.0.1",
           "N8N_DIAGNOSTICS_ENABLED": "false",
           "N8N_TEMPLATES_ENABLED": "false",
           "N8N_BLOCK_ENV_ACCESS_IN_NODE": "false",
           **TOKENS,
           "FACTORY_API_URL": API,
           "FACTORY_WORKER_SERVICE_URL": WORKER,
           "FACTORY_EVALUATION_URL": EVAL}, "vfy_n8n.log")
    if not wait_url(N8N + "/healthz", seconds=120):
        raise SystemExit("n8n did not come up (see logs/vfy_n8n.log)")


def sync_tree(tree):
    spec = importlib.util.spec_from_file_location(
        f"{tree}_setup_env",
        str(HOME / f"workspace/video-factory-{tree}/tools/setup_env.py"))
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    mod.sync_workflows()


# ------------------------------------------------------------------ setup
def setup():
    subprocess.run(["pg_ctlcluster", "16", "main", "start"],
                   capture_output=True)
    r = subprocess.run(["python3", str(G3 / "tools/setup_db.py"), DB],
                       capture_output=True, text=True)
    if r.returncode != 0:
        raise SystemExit(f"scratch DB setup failed: {r.stderr[-400:]}")
    print(f"db: {DB} built")
    kill_port(8730)
    spawn([str(G3 / ".venv/bin/python"), str(G3 / "api/server.py")],
          {"FACTORY_DSN": DSN, "FACTORY_PORT": "8730", **TOKENS},
          "vfy_api.log")
    if not wait_url(API + "/health"):
        raise SystemExit("API did not come up")
    print("api: up")
    kill_port(8795)
    spawn([VENV_PY, str(PROG / "gate-c/worker_service/service.py")],
          {"WORKER_SERVICE_PORT": "8795", "WORKER_ENVIRONMENT": "test",
           "WORKER_DSN": DSN, "FACTORY_API_URL": API,
           "FACTORY_WORKER_TOKEN": TOKENS["FACTORY_WORKER_TOKEN"],
           "WORKER_CREDENTIAL_REFS": "OPENROUTER_API_KEY",
           "OPENROUTER_API_KEY": "vfy-dummy-key-not-a-credential"},
          "vfy_worker.log")
    if not wait_url(WORKER + "/health"):
        raise SystemExit("worker did not come up")
    _, health = call(WORKER, "GET", "/health")
    print(f"worker: up, openrouter-compatible="
          f"{health['adapters']['openrouter-compatible']['status']}")
    kill_port(8796)
    spawn([VENV_PY, str(PROG / "gate-e/evaluation_service/service.py")],
          {"FACTORY_DSN": DSN, "FACTORY_API_URL": API,
           "FACTORY_VALIDATOR_TOKEN": TOKENS["FACTORY_VALIDATOR_TOKEN"],
           "FACTORY_EVAL_PORT": "8796"}, "vfy_eval.log")
    if not wait_url(EVAL + "/health"):
        raise SystemExit("evaluation service did not come up")
    print("evaluation: up")
    start_n8n()
    for tree in ("g5", "g6", "g7"):
        sync_tree(tree)
        print(f"n8n: {tree} workflows synced")
    r = subprocess.run([VENV_PY, str(MM03 / "tools/seed_registry.py"), DB],
                       capture_output=True, text=True)
    if r.returncode != 0:
        raise SystemExit(f"registry seed failed: {r.stdout} {r.stderr}")
    print("registry seed ok")
    # MY pricing rows (distinct rates per model; my version string)
    for model, (rin, rout) in RATES.items():
        for kind, price in (("input_token", rin), ("output_token", rout)):
            s, o = call(API, "POST", "/pricing-rules",
                        {"provider": PROVIDER, "model": model,
                         "modality": "text", "unit_kind": kind,
                         "unit_price_cents": float(price),
                         "pricing_version": PRICING_VERSION},
                        role="OPERATOR")
            if s not in (200, 201):
                raise SystemExit(f"pricing {model} {kind}: {s} {o}")
            print(f"pricing {model} {kind} @ {price} seeded")
    # promote STATION_03 (test fixture, OPERATOR)
    s, out = call(API, "GET", "/model-policies", role="OPERATOR")
    policies = out.get("policies", out if isinstance(out, list) else [])
    pol = [p for p in policies if p.get("role") == "STATION_03"
           and p.get("status") == "PROPOSED"]
    if not pol:
        raise SystemExit(f"STATION_03 PROPOSED policy not found: {out}")
    policy_id = pol[0]["policy_id"]
    s, out = call(API, "POST", f"/model-policies/{policy_id}/promote",
                  {"approval_note": "MM-05 verifier test-fixture "
                                    "promotion (Station 03)"},
                  role="OPERATOR")
    if s != 200 or out.get("status") != "ACTIVE":
        raise SystemExit(f"promotion failed: {s} {out}")
    print(f"promotion: {policy_id} ACTIVE, "
          f"bindings_written={out.get('bindings_written')}")
    rows = db("UPDATE provider_configs SET params = params || %s::jsonb "
              "WHERE active AND scope='OPERATION' "
              "AND operation_id='08.12' RETURNING config_id",
              (json.dumps({"base_url": STUB_URL}),))
    if len(rows) != 1:
        raise SystemExit(f"base_url override hit {len(rows)} rows")
    print("stub override: base_url -> my stub on the 08.12 OPERATION row")
    for station in (3, 4):
        s, o = call(API, "POST", "/configs",
                    {"scope": "STATION", "station": station,
                     "environment": "test",
                     "provider": "deterministic-local",
                     "est_cost_cents": 100,
                     "params": {"reported_actual_cents": 90}},
                    role="OPERATOR")
        if s not in (200, 201):
            raise SystemExit(f"STATION {station} binding: {s} {o}")
        print(f"bindings: STATION {station} deterministic-local seeded")
    return 0


def teardown():
    for port in (8730, 8795, 8796, STUB_PORT):
        kill_port(port)
    print("teardown: api/worker/eval/stub stopped (n8n left running)")
    return 0


# ------------------------------------------------------------------ shape
def shape():
    """Deterministic /work response-shape probe: direct API claim of
    a 06.12 unit under a probe identity, then a direct /work call
    with the executor-shaped body. Records the raw response keys —
    the MM-05 repair touched only the provider-dispatch plan branch,
    so this path's payload shape must be exactly the pre-repair one
    (base keys + the MM-04 gateway keys with model null)."""
    sc = Scenario("shape_probe", label="DETERMINISTIC_PROBE")
    pid, run, canon = make_production("MM-05 verifier shape probe")
    uid = plan_unit(pid, run, "06.12", inputs=[canon])
    wait_state(pid, uid, {"READY"}, timeout=60)
    s, claim = call(API, "POST", f"/units/{uid}/claim",
                    {"worker_id": "vfy-probe"}, role="OPERATOR")
    sc.check("probe claim succeeds (200) and returns attempt + "
             "fencing (the resolved config rides the attempt "
             "snapshot, as the executor reads it)",
             s == 200 and bool(claim.get("attempt_id"))
             and bool(claim.get("fencing_token")),
             f"status={s} keys={sorted(claim) if isinstance(claim, dict) else claim}")
    att = attempts_of(uid)[0]
    binding = att["resolved_config"]
    if isinstance(binding, str):
        binding = json.loads(binding)
    _, aout = call(API, "GET", f"/productions/{pid}/artifacts",
                   role="OPERATOR")
    canon_row = [a for a in aout["artifacts"]
                 if a["artifact_type"] == "canon_manifest"][0]
    body = {"unit_id": uid, "attempt_id": claim.get("attempt_id"),
            "fencing_token": claim.get("fencing_token"),
            "operation_id": "06.12", "production_id": pid,
            "idempotency_key": f"dispatch:{uid}",
            "provider_binding": binding,
            "config_hash": att.get("resolved_config_hash"),
            "input_artifact_refs": [{
                "artifact_id": canon_row["artifact_id"],
                "artifact_type": "canon_manifest",
                "sha256": canon_row["sha256"],
                "storage_uri": canon_row.get("storage_uri")}],
            "inputs": {}, "worker_id": "vfy-probe", "force_fail": False}
    req = urllib.request.Request(WORKER + "/work", method="POST",
                                 data=json.dumps(body).encode(),
                                 headers={"Content-Type":
                                          "application/json"})
    with urllib.request.urlopen(req, timeout=120) as r:
        resp = json.loads(r.read())
    keys = sorted(resp)
    sc.check("/work deterministic response carries plan_execution + "
             "the deterministic content (path executed end to end)",
             resp.get("status") == "COMPLETED"
             and isinstance(resp.get("plan_execution"), dict)
             and resp.get("artifact_type") == "beat_graph",
             f"status={resp.get('status')} type={resp.get('artifact_type')}")
    sc.check("response key set recorded (see extra.response_keys) — "
             "gateway keys present with model null on the "
             "deterministic path, exactly the MM-04-era shape the "
             "repair was forbidden to change",
             resp.get("model") is None
             and "fallback_event" not in resp,
             f"keys={keys} model={resp.get('model')!r}")
    return sc.finish({"response_keys": keys,
                      "claim_keys": sorted(claim),
                      "production_id": pid, "unit": uid})


# --------------------------------------------------------------------- v1
def v1():
    """D-MM05-01 core: fallback through n8n, priced at the FALLBACK
    model's rates under MY pricing rows and MY usage numbers."""
    sc = Scenario("v1_fallback")
    record = start_stub("fallback", "v1")
    pid, run, canon = make_production("MM-05 verifier V1 fallback via n8n")
    _, _, u07 = build_chain(sc, pid, run, canon)
    u08 = plan_unit(pid, run, "08.12", depends=[u07], inputs=[canon])
    state = drive_via_n8n(sc, pid, u08, "08.12", approve=False)
    sc.check("08.12 reaches AWAITING_HUMAN via the fallback segment",
             state == "AWAITING_HUMAN", f"state={state}")
    calls = stub_calls(record)
    by_model = {}
    for c in calls:
        by_model[c["model"]] = by_model.get(c["model"], 0) + 1
    sc.check("stub shape: primary attempted 3x (1 + 2 bounded "
             "retries), fallback exactly 1x",
             by_model.get(PRIMARY) == 3 and by_model.get(FALLBACK) == 1
             and len(calls) == 4, f"by_model={by_model}")
    corr = {c.get("correlation") for c in calls}
    sc.check("one correlation id spans retries + fallback",
             len(corr) == 1 and None not in corr, f"corr={corr}")
    want_fb, raw_fb = expected_calc(USAGE, FALLBACK)
    want_pri, _ = expected_calc(USAGE, PRIMARY)
    fin = fin_rows(u08)
    calc = [e for e in fin if e["charge_class"] == "CALCULATED"]
    finz = [e for e in fin if e["charge_class"] == "FINALIZED"]
    sc.check(f"CALCULATED == {want_fb}c at MY FALLBACK rates "
             f"(5000x0.0004 + 1500x0.0035 = {raw_fb}); at primary "
             f"rates it would be {want_pri}c — distinguishable",
             len(calc) == 1 and calc[0]["amount_cents"] == want_fb
             and want_fb != want_pri, json.dumps(fin)[:600])
    fu = (finz[0]["usage"] or {}) if finz else {}
    sc.check(f"FINALIZED == CALCULATED ({want_fb}c), basis "
             "calculated, pricing version is MY seeded version",
             len(finz) == 1 and finz[0]["amount_cents"] == want_fb
             and fu.get("_finalization_basis") == "calculated"
             and finz[0]["pricing_version"] == PRICING_VERSION,
             json.dumps(finz)[:500])
    fb_call = [c for c in calls if c["model"] == FALLBACK]
    fb_seq = fb_call[0]["seq"] if fb_call else None
    sc.check("evidence carries MY stub's fallback-call request id "
             "(chatcmpl-vfy-<fallback seq>) + MY usage (5000/1500) "
             "— and only the fallback call's usage",
             bool(finz)
             and finz[0]["provider_request_id"] == f"chatcmpl-vfy-{fb_seq}"
             and fu.get("input_tokens") == USAGE[0]
             and fu.get("output_tokens") == USAGE[1],
             f"reqid={finz[0]['provider_request_id'] if finz else None} "
             f"expected=chatcmpl-vfy-{fb_seq}")
    recs = {r["action_key"]: r for r in action_records(u08)}
    bsum = recs.get("op.build", {}).get("output_summary") or {}
    if isinstance(bsum, str):
        bsum = json.loads(bsum)
    blob = json.dumps(bsum)
    sc.check("generation action record names the EXECUTED model "
             "(fallback) + carries the fallback event (primary + "
             "fallback + trigger) + usage + request id",
             bsum.get("model") == FALLBACK
             and isinstance(bsum.get("fallback_event"), dict)
             and bsum["fallback_event"].get("primary_model") == PRIMARY
             and bsum["fallback_event"].get("fallback_model") == FALLBACK
             and (bsum.get("usage") or {}).get("input_tokens") == USAGE[0]
             and bool(bsum.get("provider_request_id")),
             blob[:600])
    sc.check("all three plan action records SUCCEEDED",
             {k: v["status"] for k, v in recs.items()} ==
             {"inputs.manifest": "SUCCEEDED", "op.build": "SUCCEEDED",
              "output.emit": "SUCCEEDED"},
             json.dumps({k: v["status"] for k, v in recs.items()}))
    check_refs_proof(sc, pid, u08)
    script = check_script_and_gate(sc, pid)
    atts = attempts_of(u08)
    sc.check("one attempt under n8n-executor-g5, adopted",
             len(atts) == 1 and atts[0]["worker_id"] == EXECUTOR_G5
             and atts[0].get("adopted_at") is not None,
             json.dumps(atts, default=str)[:300])
    return sc.finish({"production_id": pid, "unit_08_12": u08,
                      "script_artifact": script.get("artifact_id"),
                      "expected_fallback_cents": want_fb,
                      "expected_primary_cents": want_pri})


# --------------------------------------------------------------------- v2
def v2():
    """Primary success through n8n: priced at PRIMARY rates; the stub
    receives the ASSIGNMENT's model; no fallback event; no leakage."""
    sc = Scenario("v2_primary")
    record = start_stub("ok", "v2")
    pid, run, canon = make_production("MM-05 verifier V2 primary via n8n")
    _, _, u07 = build_chain(sc, pid, run, canon)
    u08 = plan_unit(pid, run, "08.12", depends=[u07], inputs=[canon])
    state = drive_via_n8n(sc, pid, u08, "08.12", approve=False)
    sc.check("08.12 reaches AWAITING_HUMAN on the primary segment",
             state == "AWAITING_HUMAN", f"state={state}")
    atts = attempts_of(u08)
    snap = atts[0]["resolved_config"] or {} if atts else {}
    if isinstance(snap, str):
        snap = json.loads(snap)
    ma = snap.get("model_assignment") or {}
    sc.check("attempt snapshot pins the MM-03 assignment (opus-4.8 "
             "primary, gpt-5.5 fallback, matrix 1.0.0, station-03 "
             "policy)",
             ma.get("primary_model") == PRIMARY
             and ma.get("fallback_model") == FALLBACK
             and ma.get("matrix_version") == "1.0.0"
             and str(ma.get("policy_id", "")).startswith(
                 "policy-station-03"),
             json.dumps(ma))
    sc.check("resolved binding is the promoted OPERATION row "
             "(openrouter-compatible + opus-4.8)",
             snap.get("provider") == PROVIDER
             and snap.get("model") == PRIMARY,
             f"provider={snap.get('provider')} model={snap.get('model')}")
    calls = stub_calls(record)
    sc.check("ROUTING: exactly one provider call and the stub "
             "received the ASSIGNMENT's model (opus-4.8)",
             len(calls) == 1 and calls[0]["model"] == PRIMARY,
             f"calls={[(c['seq'], c['model']) for c in calls]}")
    if calls:
        prompt = calls[0].get("prompt") or ""
        sc.check("prompt grounded in CURRENT canon + chain contents",
                 canon in prompt and "CANON MANIFEST v1" in prompt
                 and "SC1" in prompt and "SC2" in prompt,
                 f"prompt_len={len(prompt)}")
    want_pri, raw_pri = expected_calc(USAGE, PRIMARY)
    want_fb, _ = expected_calc(USAGE, FALLBACK)
    fin = fin_rows(u08)
    calc = [e for e in fin if e["charge_class"] == "CALCULATED"]
    finz = [e for e in fin if e["charge_class"] == "FINALIZED"]
    fu = (finz[0]["usage"] or {}) if finz else {}
    sc.check(f"CALCULATED == FINALIZED == {want_pri}c at MY PRIMARY "
             f"rates (5000x0.0006 + 1500x0.0020 = {raw_pri}); at "
             f"fallback rates it would be {want_fb}c",
             len(calc) == 1 and calc[0]["amount_cents"] == want_pri
             and len(finz) == 1 and finz[0]["amount_cents"] == want_pri
             and fu.get("input_tokens") == USAGE[0]
             and fu.get("output_tokens") == USAGE[1]
             and finz[0]["provider_request_id"] == "chatcmpl-vfy-1",
             json.dumps(fin)[:600])
    recs = {r["action_key"]: r for r in action_records(u08)}
    bsum = recs.get("op.build", {}).get("output_summary") or {}
    if isinstance(bsum, str):
        bsum = json.loads(bsum)
    sc.check("primary path: action record names the primary model "
             "and carries NO fallback event",
             bsum.get("model") == PRIMARY
             and not bsum.get("fallback_event"),
             json.dumps(bsum)[:400])
    check_refs_proof(sc, pid, u08)
    script = check_script_and_gate(sc, pid)
    pol4 = db("SELECT status FROM model_policies "
              "WHERE role='STATION_04'")
    roles = db("SELECT DISTINCT role FROM operation_model_assignments "
               "WHERE status='ACTIVE'")
    sc.check("no leakage (registry): STATION_04 policy still "
             "PROPOSED; ACTIVE assignments only under STATION_03",
             pol4 and pol4[0]["status"] == "PROPOSED"
             and [r["role"] for r in roles] == ["STATION_03"],
             f"station04={pol4} active_roles={roles}")
    return sc.finish({"production_id": pid, "unit_08_12": u08,
                      "script_artifact": script.get("artifact_id"),
                      "expected_primary_cents": want_pri})


# --------------------------------------------------------------------- v3
def v3():
    """Mid-chain n8n interruption: kill after two units ACCEPTED,
    restart + re-sync, chain completes; exactly one attempt and one
    FINALIZED settlement per unit."""
    sc = Scenario("v3_recovery")
    record = start_stub("ok", "v3")
    pid, run, canon = make_production("MM-05 verifier V3 interruption")
    u05 = plan_unit(pid, run, "05.12", inputs=[canon])
    u06 = plan_unit(pid, run, "06.12", depends=[u05], inputs=[canon])
    for op, uid in (("05.12", u05), ("06.12", u06)):
        state = drive_via_n8n(sc, pid, uid, op)
        sc.check(f"{op} ACCEPTED before the interruption",
                 state == "ACCEPTED", f"state={state}")
    old_pid = port_pid(5678)
    kill_port(5678)
    time.sleep(2)
    down = not wait_url(N8N + "/healthz", seconds=3)
    dispatch_failed = False
    try:
        post_dispatch(pid, u06, "06.12", 3, WEBHOOK_G5)
    except Exception:  # noqa: BLE001
        dispatch_failed = True
    sc.check("n8n killed mid-chain: health down + a dispatch attempt "
             "fails (interruption is real)",
             down and dispatch_failed,
             f"down={down} dispatch_failed={dispatch_failed}")
    start_n8n()
    sync_tree("g5")
    new_pid = port_pid(5678)
    sc.check("n8n restarted as a NEW process + g5 workflows re-synced",
             new_pid is not None and new_pid != old_pid,
             f"pid {old_pid} -> {new_pid}")
    u07 = plan_unit(pid, run, "07.12", depends=[u06], inputs=[canon])
    u08 = plan_unit(pid, run, "08.12", depends=[u07], inputs=[canon])
    state7 = drive_via_n8n(sc, pid, u07, "07.12")
    state8 = drive_via_n8n(sc, pid, u08, "08.12", approve=False)
    sc.check("chain completes after recovery: 07.12 ACCEPTED, 08.12 "
             "AWAITING_HUMAN",
             state7 == "ACCEPTED" and state8 == "AWAITING_HUMAN",
             f"07={state7} 08={state8}")
    ok = True
    detail = {}
    for op, uid in (("05.12", u05), ("06.12", u06), ("07.12", u07),
                    ("08.12", u08)):
        atts = attempts_of(uid)
        finz = [e for e in fin_rows(uid)
                if e["charge_class"] == "FINALIZED"]
        detail[op] = {"attempts": len(atts), "finalized": len(finz)}
        ok = ok and len(atts) == 1 and len(finz) == 1
    sc.check("exactly ONE attempt + ONE FINALIZED settlement per "
             "unit across the interruption", ok, json.dumps(detail))
    calls = stub_calls(record)
    sc.check("provider called exactly once (the recovered 08.12)",
             len(calls) == 1, f"calls={len(calls)}")
    return sc.finish({"production_id": pid})


# --------------------------------------------------------------------- v4
def v4():
    """Guards: duplicate dispatch; span guard; HG2-PENDING claim
    refusal (scheduler skip + direct 409 + audit). Saves state v5."""
    sc = Scenario("v4_guards")
    record = start_stub("ok", "v4")
    pid, run, canon = make_production("MM-05 verifier V4 guards")
    _, _, u07 = build_chain(sc, pid, run, canon)
    u08 = plan_unit(pid, run, "08.12", depends=[u07], inputs=[canon])
    wait_state(pid, u08, {"READY"})
    scheduler_prestage()
    sc.check("08.12 prestaged before duplicate dispatches",
             unit_row(pid, u08)["state"] == "CLAIMED",
             f"state={unit_row(pid, u08)['state']}")
    post_dispatch(pid, u08, "08.12", 3, WEBHOOK_G5)
    post_dispatch(pid, u08, "08.12", 3, WEBHOOK_G5)  # duplicate
    state = wait_state(pid, u08, {"AWAITING_HUMAN", "ACCEPTED"})
    time.sleep(10)
    calls = stub_calls(record)
    atts = attempts_of(u08)
    finz = [e for e in fin_rows(u08) if e["charge_class"] == "FINALIZED"]
    sc.check("duplicate dispatch: exactly 1 provider call, 1 "
             "attempt, 1 script, 1 FINALIZED, 1 HG2 gate",
             len(calls) == 1 and len(atts) == 1
             and len(script_artifacts(pid)) == 1 and len(finz) == 1
             and len(hg2_gates(pid)) == 1,
             f"calls={len(calls)} attempts={len(atts)} "
             f"fin={len(finz)} gates={len(hg2_gates(pid))} state={state}")
    # span guard: step-12 unit to the g6 (Station 04) webhook
    u12 = plan_unit(pid, run, "12.12")
    st12 = unit_row(pid, u12)["state"]
    post_dispatch(pid, u12, "12.12", 5, WEBHOOK_G6)
    time.sleep(45)
    sc.check("span guard (12.12 -> g6 webhook): zero attempts, unit "
             "state unchanged, no further provider calls",
             len(attempts_of(u12)) == 0
             and unit_row(pid, u12)["state"] == st12
             and len(stub_calls(record)) == 1,
             f"attempts={len(attempts_of(u12))} state {st12} -> "
             f"{unit_row(pid, u12)['state']}")
    # HG2 guard: unit-level approval does NOT decide the gate
    s, _ = call(API, "POST", f"/units/{u08}/events",
                {"event": "human_approved"}, role="OPERATOR")
    state8 = wait_state(pid, u08, {"ACCEPTED"})
    script = current_artifacts(pid)["script"]
    gates = wait_hg2(pid)
    sc.check("08.12 ACCEPTED at unit level; HG2 gate itself still "
             "PENDING", s == 200 and state8 == "ACCEPTED"
             and len(gates) == 1 and gates[0]["verdict"] == "PENDING",
             f"gate={gates}")
    u09 = plan_unit(pid, run, "09.12", depends=[u08],
                    inputs=[script["artifact_id"]])
    wait_state(pid, u09, {"READY"}, timeout=60)
    report = scheduler_prestage()
    sc.check("HG2 refusal path 1 — scheduler SKIPS the gate-refused "
             "09.12 (no claim staged, still READY)",
             all(c["unit_id"] != u09 for c in report["claimed"])
             and unit_row(pid, u09)["state"] == "READY",
             f"state={unit_row(pid, u09)['state']}")
    s, out = call(API, "POST", f"/units/{u09}/claim",
                  {"worker_id": EXECUTOR_G6}, role="OPERATOR")
    audit9 = audit_of(u09)
    sc.check("HG2 refusal path 2 — direct API claim refused 409 + "
             "gate_claim_refused audit event committed",
             s == 409 and any(a["event"] == "gate_claim_refused"
                              for a in audit9),
             f"status={s} audit={audit9}")
    STATE.write_text(json.dumps(
        {"pid": pid, "run": run, "u08": u08, "u09": u09,
         "script_id": script["artifact_id"],
         "script_sha": script["sha256"],
         "gate_id": gates[0]["gate_id"]}))
    return sc.finish({"production_id": pid, "unit_08_12": u08,
                      "unit_09_12": u09})


# --------------------------------------------------------------------- v5
def v5():
    """Handoff: the OPERATOR HG2 decision (recorded as the
    verifier's) opens exactly the gated claim; 09.12 executes
    through g6 consuming the script; its snapshot carries NO
    model_assignment (Station 4 unpromoted — prior resolution)."""
    sc = Scenario("v5_handoff")
    st = json.loads(STATE.read_text())
    pid, u09 = st["pid"], st["u09"]
    gid, script_id = st["gate_id"], st["script_id"]
    s, out = call(API, "POST", f"/gates/{gid}/decide",
                  {"decision": "APPROVED",
                   "decided_by": "mm05-verifier"}, role="OPERATOR")
    grow = db("SELECT verdict, decided_by FROM human_gates "
              "WHERE gate_id=%s", (gid,))
    sc.check("HG2 APPROVED via a recorded OPERATOR decision",
             s == 200 and out.get("status") == "APPROVED"
             and grow and grow[0]["verdict"] == "APPROVED"
             and grow[0]["decided_by"] == "mm05-verifier",
             f"api={s} db={grow}")
    state9 = drive_via_n8n(sc, pid, u09, "09.12", station=4,
                           webhook=WEBHOOK_G6)
    sc.check("09.12 ACCEPTED through the g6 executor after approval",
             state9 == "ACCEPTED", f"state={state9}")
    dp = current_artifacts(pid).get("direction_package")
    sc.check("direction_package CURRENT exists", bool(dp), f"{dp}")
    if dp:
        content = read_store_artifact(dp)["output_artifacts"][0]["content"]
        sc.check("downstream consumption: direction_package."
                 "script_ref == the script artifact id",
                 content.get("script_ref") == script_id,
                 f"script_ref={content.get('script_ref')}")
    atts9 = attempts_of(u09)
    snap9 = atts9[0]["resolved_config"] or {} if atts9 else {}
    if isinstance(snap9, str):
        snap9 = json.loads(snap9)
    sc.check("unpromoted station keeps prior resolution (live): one "
             "attempt under n8n-executor-g6, adopted, "
             "deterministic-local, NO model_assignment pinned",
             len(atts9) == 1 and atts9[0]["worker_id"] == EXECUTOR_G6
             and atts9[0].get("adopted_at") is not None
             and snap9.get("provider") == "deterministic-local"
             and "model_assignment" not in snap9,
             json.dumps(atts9, default=str)[:400])
    finz9 = [e for e in fin_rows(u09) if e["charge_class"] == "FINALIZED"]
    sc.check("09.12 settlement untouched by the multi-model path: "
             "FINALIZED 90c (deterministic reported actual)",
             len(finz9) == 1 and finz9[0]["amount_cents"] == 90,
             json.dumps(finz9)[:300])
    return sc.finish({"production_id": pid, "unit_09_12": u09})


SCENARIOS = {"setup": setup, "shape": shape, "v1": v1, "v2": v2,
             "v3": v3, "v4": v4, "v5": v5, "teardown": teardown}


# -------------------------------------------------------------------- v5b
def v5b():
    """Clean-DB re-run of the handoff leg (v5's prestage miss was my
    own scratch-state artifact: 3 abandoned probe claims + the
    span-guard unit filled the text lane's capacity of 4). Fresh
    production on the rebuilt DB: approval must open the gated
    claim THROUGH the prestage + adopt path."""
    sc = Scenario("v5b_handoff_clean")
    record = start_stub("ok", "v5b")
    pid, run, canon = make_production("MM-05 verifier V5b handoff clean")
    _, _, u07 = build_chain(sc, pid, run, canon)
    u08 = plan_unit(pid, run, "08.12", depends=[u07], inputs=[canon])
    state = drive_via_n8n(sc, pid, u08, "08.12", approve=True)
    sc.check("08.12 ACCEPTED (unit-level approval)", state == "ACCEPTED",
             f"state={state}")
    script = current_artifacts(pid)["script"]
    gates = wait_hg2(pid)
    sc.check("HG2 PENDING bound to the script",
             len(gates) == 1 and gates[0]["verdict"] == "PENDING",
             json.dumps(gates)[:200])
    u09 = plan_unit(pid, run, "09.12", depends=[u08],
                    inputs=[script["artifact_id"]])
    wait_state(pid, u09, {"READY"}, timeout=60)
    report = scheduler_prestage()
    sc.check("while HG2 PENDING the scheduler still skips 09.12",
             all(c["unit_id"] != u09 for c in report["claimed"])
             and unit_row(pid, u09)["state"] == "READY",
             f"state={unit_row(pid, u09)['state']}")
    s, out = call(API, "POST", f"/gates/{gates[0]['gate_id']}/decide",
                  {"decision": "APPROVED",
                   "decided_by": "mm05-verifier"}, role="OPERATOR")
    sc.check("HG2 APPROVED (recorded OPERATOR decision)",
             s == 200 and out.get("status") == "APPROVED", f"{s} {out}")
    state9 = drive_via_n8n(sc, pid, u09, "09.12", station=4,
                           webhook=WEBHOOK_G6)
    sc.check("09.12 ACCEPTED through g6 after approval (prestage + "
             "adopt path, asserted inside the driver)",
             state9 == "ACCEPTED", f"state={state9}")
    atts9 = attempts_of(u09)
    snap9 = atts9[0]["resolved_config"] or {} if atts9 else {}
    if isinstance(snap9, str):
        snap9 = json.loads(snap9)
    sc.check("09.12 attempt ADOPTED by n8n-executor-g6 (Gate 02 "
             "path), deterministic-local snapshot, NO "
             "model_assignment (unpromoted station, prior resolution)",
             len(atts9) == 1 and atts9[0]["worker_id"] == EXECUTOR_G6
             and atts9[0].get("adopted_at") is not None
             and atts9[0].get("adopted_by") == EXECUTOR_G6
             and snap9.get("provider") == "deterministic-local"
             and "model_assignment" not in snap9,
             json.dumps(atts9, default=str)[:400])
    dp = current_artifacts(pid).get("direction_package")
    ok_ref = False
    if dp:
        content = read_store_artifact(dp)["output_artifacts"][0]["content"]
        ok_ref = content.get("script_ref") == script["artifact_id"]
    sc.check("direction_package.script_ref == the script artifact id",
             ok_ref, f"dp={bool(dp)}")
    finz9 = [e for e in fin_rows(u09) if e["charge_class"] == "FINALIZED"]
    sc.check("09.12 FINALIZED == 90c (deterministic reported actual)",
             len(finz9) == 1 and finz9[0]["amount_cents"] == 90,
             json.dumps(finz9)[:300])
    return sc.finish({"production_id": pid, "unit_09_12": u09})

SCENARIOS["v5b"] = v5b


if __name__ == "__main__":
    LOGS.mkdir(parents=True, exist_ok=True)
    RESULTS.mkdir(parents=True, exist_ok=True)
    fn = SCENARIOS[sys.argv[1]]
    rc = fn()
    sys.exit(rc if isinstance(rc, int) else 0)
