#!/usr/bin/env python3
"""MM-05 verifier — repair confinement (static, no stack).

Normalizes the CURRENT on-disk workflows of all five trees (UUID
scrub -> 'UUID', canonical JSON) and compares against:
  (a) the F-P4P baseline snapshots (lean-phase-4-prep/fix/evidence/
      fixed_normalized/) — the pre-MM-05 state;
  (b) the MM-05 builder's claimed post-repair snapshots
      (mm-gate-05/evidence/repair_normalized/).
Then diffs the submit-candidate jsonBody strings (baseline vs
current) in full for each unit-executor, and greps each tree's
generator for the forwarded model field.
"""
import difflib
import json
import re
import sys
from pathlib import Path

HOME = Path.home()
W = HOME / "workspace"
BASE = (W / "video-factory-master-programme/lean-phase-4-prep/fix"
        / "evidence/fixed_normalized")
CLAIM = W / "video-factory-master-programme/mm-gate-05/evidence/repair_normalized"
OUT = (W / "video-factory-master-programme/mm-gate-05/evidence/verify"
       / "results/confinement.json")
UUID_RE = re.compile(
    r"[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-"
    r"[0-9a-fA-F]{4}-[0-9a-fA-F]{12}")


def norm(obj):
    def scrub(v):
        if isinstance(v, str):
            return UUID_RE.sub("UUID", v)
        if isinstance(v, list):
            return [scrub(x) for x in v]
        if isinstance(v, dict):
            return {k: scrub(x) for k, x in v.items()}
        return v
    return json.dumps(scrub(obj), sort_keys=True)


def load_norm(path):
    return norm(json.loads(path.read_text()))


def submit_body(wf):
    for n in wf["nodes"]:
        if n["name"] == "submit-candidate":
            return n["parameters"]["jsonBody"]
    return None


result = {"files_compared": 0, "vs_fp4p_baseline": {}, "vs_mm05_claim": {},
          "jsonbody_diffs": {}, "generator_grep": {}}
diffs_vs_base, diffs_vs_claim = [], []
for tree in ("g4", "g5", "g6", "g7", "g8"):
    wfdir = W / f"video-factory-{tree}" / "workflows"
    for f in sorted(wfdir.glob("*.json")):
        key = f"{tree}-{f.stem}"
        cur_raw = json.loads(f.read_text())
        cur = norm(cur_raw)
        result["files_compared"] += 1
        b = load_norm(BASE / f"{key}.norm.json")
        c = load_norm(CLAIM / f"{key}.json.norm.json")
        if cur != b:
            diffs_vs_base.append(key)
        if cur != c:
            diffs_vs_claim.append(key)
        if f.stem == "unit-executor":
            base_wf = json.loads((BASE / f"{key}.norm.json").read_text())
            bb, cb = submit_body(base_wf), submit_body(cur_raw)
            result["jsonbody_diffs"][key] = list(difflib.unified_diff(
                [bb], [cb], lineterm="", n=0))
            gen = (W / f"video-factory-{tree}" / "tools/gen_workflows.py")
            txt = gen.read_text()
            result["generator_grep"][key] = {
                "has_model_forward": "model: $json.model" in txt,
                "has_usage_forward": "usage: $json.usage" in txt,
                "has_reqid_forward":
                    "provider_request_id: $json.provider_request_id" in txt}
result["vs_fp4p_baseline"]["differing"] = diffs_vs_base
result["vs_mm05_claim"]["differing"] = diffs_vs_claim
OUT.write_text(json.dumps(result, indent=1, sort_keys=True))
print(json.dumps({k: result[k] for k in
                  ("files_compared", "vs_fp4p_baseline", "vs_mm05_claim",
                   "generator_grep")}, indent=1))
for k, d in result["jsonbody_diffs"].items():
    print(f"--- {k} jsonBody diff ({len(d)} lines)")
    for line in d:
        print(line[:2000])
