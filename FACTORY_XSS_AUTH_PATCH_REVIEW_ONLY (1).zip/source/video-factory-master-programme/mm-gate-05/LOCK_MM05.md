# LOCK — GATE MM-05: n8n Six-Station Execution Integration

**Gate:** MM-05 (Multi-Model programme, MULTI_MODEL_EXECUTION_PROMPT.md)
**Builder:** MM-05 builder agent (this session)
**Date:** 2026-10-29
**Status at lock:** LOCKED → IMPLEMENTING (integration battery)

## Scope

Primarily an INTEGRATION BATTERY gate. Assemble and run the battery in
`mm-gate-05/` proving the required execution path end to end through
real n8n workflow execution: Coordinator authorizes → n8n receives the
task + pinned plan → dispatch → gateway resolves the approved model →
worker executes → independent evaluator verifies → Coordinator commits
→ PostgreSQL unlocks dependents. All six stations complete their
authorized mock paths through n8n (not direct worker-only calls).

Product changes: NONE planned. A change is permitted only for a defect
the battery proves, claimed by amendment to this lock + the OWNERSHIP
register before the edit, smallest repair, recorded in
`mm-gate-05/evidence/CHANGED_ASSERTIONS.md`, with the failing battery
item as evidence. A defect needing more than an in-scope repair is
reported precisely, not fixed by scope expansion.

## Preserved behavior (hard constraints)

- The F-P4P-01/F-P4P-02 executor repair (lean-phase-4-prep/fix): the
  unit-executor Assemble node adds CURRENT artifacts of ACCEPTED
  same-run producer units to the worker refs ONLY on the
  provider-generation path (pinned binding names a real provider);
  submit-candidate forwards `usage` + `provider_request_id` verbatim.
  The battery must re-prove both through the live executors (M05-2/3/4).
- MM-03: promotion is the only path writing registry bindings;
  PROPOSED policies never affect a claim; claim pins the ACTIVE
  assignment into the attempt snapshot (`model_assignment`).
- MM-04: gateway fallback only to the pinned assignment's
  `fallback_model`, only on provider-side failure classes after
  bounded retries; completion prices at the executed model.
- Coordinator sole authority; human gates (HG2) enforced at claim.

## Battery (mm-gate-05/evidence/results/, serial, STUB_TESTED)

- M05-1 six-station mock paths: g4/g5/g6/g7/g8 station suites + G9
  full run, serially, per-station verdicts.
- M05-2 operation-specific model routing through n8n: MM-03 registry
  seeded in the battery DB; STATION_03 policy PROMOTED via the API
  (OPERATOR; recorded as a test-fixture promotion); the slice path
  (08.12) runs through the g5 executor against a local stub → the
  attempt snapshot pins the assignment (primary
  anthropic/claude-opus-4.8) and the stub receives the assignment's
  model. Station 4 unpromoted → its ops keep existing resolution
  (registry state + the live 09.12 claim in M05-4).
- M05-3 fallback dispatch through n8n: stub fails the primary (500,
  no usage) and serves the fallback (openai/gpt-5.5) → attempt
  completes via the gateway fallback; completion evidence names the
  fallback model + fallback event; CALCULATED at fallback rates.
- M05-4 CURRENT upstream loading + handoff: 08.12's worker refs carry
  the four CURRENT upstream contents (ids+shas vs DB); after the
  OPERATOR HG2 approval (test fixture), 09.12 executes through the
  g6 executor consuming the script (direction_package.script_ref ==
  script artifact id); 09.12's snapshot carries no model_assignment
  (no cross-station leakage, live).
- M05-5 no duplicates / no unauthorized transitions: duplicate
  dispatch → one attempt/artifact/settlement; step-12 unit → g6
  webhook (span guard refusal shape); Station 03 unit → g7 webhook
  (same shape).
- M05-6 human approval not bypassed: HG2 PENDING → 09.12 refused via
  scheduler, direct claim, and executor paths; OPERATOR HG2 approval
  opens exactly the gated claim.
- M05-7 workflow interruption recovery: n8n killed mid-chain (after
  ≥1 unit ACCEPTED), restart + re-sync, redispatch → chain completes,
  exactly one attempt + one settlement per unit.
- M05-8 version/hash consistency: for the M05-2/M05-4 productions,
  every attempt's pins (plan_hash, resolved_config_hash recomputed,
  model_assignment where present) tabulated against registry/plans
  state at claim time.
- M05-9 full serial regression (baseline 239).

## Test-fixture compositions (recorded, not product changes)

- The promoted STATION_03 policy writes a STATION-scope provider row
  for station 3 (role primary) plus OPERATION rows for its 22
  model-bound assignments. The battery then seeds station 3's
  established deterministic-local STATION binding through POST
  /configs (the g5 station setup's own shape), superseding ONLY the
  station-scope row, so the plan-bound chain operations (05.12/06.12/
  07.12 — DETERMINISTIC class, no assignments) keep their existing
  resolution. The OPERATION rows — the MM-03 mechanism under test —
  are promotion-written and untouched.
- The promoted 08.12 OPERATION row's params receive a `base_url`
  override pointing at the local stub (per-DB test seeding, the Lean
  Phase 3/4 pattern; the canonical promotion carries no base_url).
  The worker runs with a dummy OPENROUTER_API_KEY value in env so the
  credentialed adapter is READY against the stub; no real credential
  exists, no real provider is contacted, no paid call is made.
- Pricing rows for anthropic/claude-opus-4.8 (0.0005 / 0.0025
  cents-per-token) and openai/gpt-5.5 (0.0005 / 0.0030) — the MM-02
  catalog's published prices converted to cents — under pricing
  version `mm05-2026-10-29`, seeded via POST /pricing-rules.

## Amendment 1 (2026-10-29) — battery-proven defect D-MM05-01, repair claimed

**Defect (proved by M05-3, evidence/results/m05_3_fallback.json, first
run):** on the n8n path, a gateway fallback completion is priced at
the PINNED (primary) model's rates, not the executed (fallback)
model's. Root cause: MM-04 made `/complete` accept an optional
executed `model` and the worker's /work response carries it
(service.py `payload["model"]`), but the unit-executor's
submit-candidate body — the actual /complete caller on the n8n path —
never forwarded it (the F-P4P-02 repair forwarded `usage` +
`provider_request_id` before MM-04 added the model field). Observed:
fallback usage 3900/2100 priced at opus rates = 7¢ instead of gpt-5.5
rates = 8¢. MM-04's own battery priced fallback correctly only
because it completed through the worker-direct path.

**Repair (smallest, same seam as F-P4P-02):** in each tree's
`tools/gen_workflows.py`, the submit-candidate body additionally
forwards `model: $json.model` verbatim; the generator's JSON.stringify
wrapper drops the field when absent, so the deterministic completion
body is unchanged in effect. Regenerate all five trees' workflows;
diffs must be confined to the unit-executor workflows (normalized
diff recorded as evidence). No coordinator/API/worker/registry/plan
change — the API already accepts the field (contract 1.9.0).

**Files claimed for this repair:** `video-factory-g{4,5,6,7,8}/tools/
gen_workflows.py` (submit-candidate body + comment only) and the
regenerated `video-factory-g{4,5,6,7,8}/workflows/unit-executor.json`.

## Amendment 2 (2026-10-29) — D-MM05-01 has a second layer; repair extended

The Amendment 1 repair alone did NOT fix M05-3 (re-run still priced
7¢): the executor now forwards `model`, but on the plan-execution
path the /work response never carries one. In the worker service,
`_result_payload` surfaces gateway metadata (executed model,
correlation id, usage lines, fallback event) only from
`result["gateway"]`, which MM-04 populated for the DIRECT adapter
path; the provider-dispatch plan branch in `run_work` builds its
result from the plan summary — which already carries `model`,
`correlation_id`, `usage_lines`, `fallback_event` at top level
(plan_exec) — without mapping them into `result["gateway"]`. The
executed model therefore existed in the action records and the plan
summary but never on the response the executor completes with.

**Repair (one dict entry, one branch):** in
`video-factory-real-ai-programme/gate-c/worker_service/service.py`,
the provider-dispatch plan branch of `run_work` adds
`"gateway": {"model": summary.get("model"), "correlation_id":
summary.get("correlation_id"), "usage_lines":
summary.get("usage_lines"), "fallback_event":
summary.get("fallback_event")}` to its result, so the existing
`_result_payload` gateway block surfaces the fields exactly as on
the direct path. No change to `_result_payload`, plan_exec, the
gateway, or any other branch; when no provider evidence exists the
fields are None and completion pricing falls back to the snapshot
model, as before. **File claimed:** the worker service's
`service.py`, this branch only (the file is otherwise MM-04-owned
and untouched).

## Out of scope / guardrails

No registry-definition, plan, migration, or contract changes. No real
provider call; no credential requested (MM-12 owns that). Serial
execution only (shared ports, one n8n). No STATE.md/MEMORY.md edits;
no gate report (the verifier writes it).
