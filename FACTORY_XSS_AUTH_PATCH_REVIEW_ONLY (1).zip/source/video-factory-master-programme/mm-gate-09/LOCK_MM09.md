# LOCK — GATE MM-09: Dashboard + Operator Control

**Gate:** MM-09 (Multi-Model programme, MULTI_MODEL_EXECUTION_PROMPT.md §MM-09)
**Builder:** MM-09 builder agent (this session)
**Date:** 2026-10-29
**Status at lock:** LOCKED → IMPLEMENTING

## Starting state (verified from source at lock time, not from summaries)

- The G3 dashboard is ONE static page (`video-factory-g3/dashboard/index.html`,
  412 lines) served by the API server at `/` and `/dashboard`; all data flows
  through the coordinator API via a JS `api()` helper sending
  `X-Operator-Token`. Twelve views exist (intake, productions, tracker,
  operations, units, artifacts, gates, finance, repair, configs, pricing,
  system). The finance view is a budget-JSON dump; the gates view lists gates
  per production with decide buttons; the repair view is artifact
  invalidation; retry exists only inside the unit-detail panel.
- Existing API endpoints already cover every MM-09 MUTATION:
  `POST /model-policies/{id}/promote|rollback` (OPERATOR only, refusal =
  403 + committed `policy_action_refused` audit),
  `POST /financial-evidence/{id}/resolve` (MM-08, OPERATOR only),
  `POST /gates/{gid}/decide` (OPERATOR only),
  `POST /units/{uid}/retry` (OPERATOR/SCHEDULER).
  Existing reads cover assignments/policies/events
  (`GET /model-assignments`, `/model-policies`, `/model-policies/{id}/events`),
  per-production evidence (`GET /productions/{pid}/financial-evidence`),
  budget (`GET /productions/{pid}/budget`), units, gates, artifacts.
- Four read surfaces the MM-09 views need have NO endpoint today:
  `benchmark_results` (migration 016, empty by design), `provider_spend_limits`
  + per-provider window position (migration 018; the coordinator's
  `_provider_window_position` is the enforcement accounting), a
  production-wide recent-evaluations list (only per-unit reads exist), and
  the evaluation service's golden-set status (its own `GET /health` on the
  Gate E service: `{armed, expert_cases, seed_cases}`; golden counts at lock
  time: 7 SEED / 0 EXPERT, arming OFF).

## Hard rules (from the brief, binding on this gate)

1. **No new coordinator powers.** Every dashboard ACTION goes through an
   existing API endpoint with its existing role enforcement. The only new
   server surface is four READ-ONLY GET endpoints (below); none of them
   mutates coordinator state, and the evaluation-status read is a
   pass-through of the evaluation service's own health surface.
2. **No secret ever rendered.** No page or new endpoint emits any
   `FACTORY_*_TOKEN` value or any configured `credential_ref` string.
   (Providers store credential_ref as an env-var NAME; it is still never
   selected by the new reads.)
3. **No production-identity invention.** Approvals display the actor as the
   OPERATOR role; the Approvals view carries a visible note that
   named-approver (per-person) identity is an open owner decision
   (AWAITING_OWNER since Gate 05) and is NOT represented here.
4. Benchmarks are never fabricated: `benchmark_results` is empty by design
   and the Models view renders an explicit empty state.

## Scope (exactly the MM-09 brief)

### Server — `video-factory-g3/api/server.py`, four additive READ-ONLY routes
- `GET /benchmarks` (READ_ROLES) — all `benchmark_results` rows, newest first.
- `GET /provider-spend` (READ_ROLES) — one row per ACTIVE
  `provider_spend_limits` row for the server's environment: provider,
  window_kind, cap_cents, plus the window position computed with the
  coordinator's own `_provider_window_position` (settled/held/total) so the
  displayed numbers ARE the enforcement numbers.
- `GET /productions/{pid}/evaluations` (READ_ROLES) — recent
  `quality_evaluations` for the production joined through artifacts →
  producing unit → operation; `limit` query param (default 100, cap 500);
  newest first. 404 for an unknown production.
- `GET /evaluation-status` (READ_ROLES) — pass-through of the evaluation
  service's `GET /health` (env `FACTORY_EVAL_URL`, default
  `http://127.0.0.1:8950`, 3s timeout). Reachable → its payload +
  `reachable: true`; unreachable → HTTP 200 `{reachable: false, ...}` so
  the card shows an honest down state instead of an error page.
- Contract `api_contract.json`: 1.10.0 → **1.11.0**, 47 → **51 endpoints**
  (the four reads above) + an auth-notes sentence. Nothing else.

### Dashboard — `video-factory-g3/dashboard/index.html`
Same single-page style, same `api()` pattern, four new/extended views:
- **Models** (new tab): policies table (role, version, status,
  primary/fallback/evaluation model, created_by) with Promote (PROPOSED)
  and Rollback (ACTIVE) buttons + per-policy event history
  (action/actor/at/note from `/model-policies/{id}/events`); assignments
  table for all 192 operations (operation, station, role, primary,
  fallback, status pill, max_cost_cents, `null_reason` for NONE rows) with
  the ACTIVE policy version per role shown in the section header;
  **Benchmarks** card (rows from `/benchmarks`, or the explicit
  "no benchmark data recorded" empty state).
- **Finance** (extended): existing budget card kept; new evidence summary
  (estimated Σ / settled FINALIZED Σ / UNRESOLVED count for the selected
  production, aggregated client-side from the existing financial-evidence
  read + budget held figure), provider-spend-vs-caps table
  (`/provider-spend`), and the unresolved-charges list with a per-row
  Resolve form (input/output token counts, optional reported cost,
  optional provider request id) posting to the MM-08 resolve endpoint;
  refusals (duplicate 409, price-to-nothing 409, role 403) surface as
  visible messages.
- **Quality** (new tab): golden-set status card from `/evaluation-status`
  (SEED/EXPERT counts, arming OFF pill; unreachable state shown honestly);
  recent evaluations table (time, operation, unit, validator layer,
  method, verdict, evaluator) from `/productions/{pid}/evaluations`;
  failures list (verdict = FAIL rows, deterministic flag shown).
- **Approvals** (new tab): the named-approver gap note; PENDING human
  gates for the selected production with context (gate kind, artifact
  type + bound hash, producing unit + operation) and Approve/Reject
  buttons via `POST /gates/{gid}/decide` with `decided_by` = the OPERATOR
  identity; AWAITING_HUMAN units list (operation, attempt, since);
  **Repair** section: BLOCKED / RETRY_WAIT units with a Retry button via
  `POST /units/{uid}/retry` (a BLOCKED unit's refusal surfaces as a
  message — never a silent success).
- Header gains a **Role selector** (OPERATOR/WORKER/SCHEDULER/VALIDATOR):
  `api()` sends `X-Operator-Token` for OPERATOR (unchanged default) and
  `X-Role` + `X-Role-Token` otherwise. Action areas carry a visible note
  that actions require the OPERATOR role and that another role's refusal
  (403) is displayed, not hidden. Default session behavior is byte-for-byte
  the pre-MM-09 behavior.

### Tests — `video-factory-g3/tests/test_mm09_dashboard.py` (new permanent suite)
Scratch stack (own DB/port, eval service on its own port): MM-03 seeder
run for real (7 policies / 192 assignments); a production seeded with a
settled charge, an UNRESOLVED charge (MM-08 fixture construction), a
provider_spend_limits row, evaluations of PASS/FAIL/REVIEW_REQUIRED, an
AWAITING_HUMAN unit with a PENDING gate, a BLOCKED unit, a RETRY_WAIT
unit. View/data assertions compare every new endpoint's payload against
raw-SQL ground truth; action tests drive promote / rollback / resolve /
approve / retry through the exact endpoints + payloads the page issues
(incl. duplicate-resolve 409, price-to-nothing 409, WORKER promote 403 +
`policy_action_refused` audit, WORKER resolve 403, BLOCKED retry refusal
surfaced); secret-scan over the page + every dashboard-consumed GET with
distinctive env token values and a distinctive credential_ref string.

### Browser feasibility (probed at lock time)
Playwright 1.64.1 (Node, `video-factory-g4/node_modules`) and the Chromium
headless shell (Chrome for Testing 156.0.8078.4,
`~/.cache/ms-playwright/chromium_headless_shell-1248`) are BOTH present →
a real scripted browser run is part of this gate's evidence
(`mm-gate-09/harness/browser_run.js`): load every new view, promote a
policy and resolve a charge through the actual UI forms, exercise the
WORKER-role refusal display, DOM assertions + screenshots in evidence.

### Regression
Full serial, port hygiene (8730/8795/8796 killed between suites, DSN
asserted): baseline **311** (MM-08: g1 9, g2 96, g3 41, g4 2, g5 1, g6 3,
g7 2, g8 1, g9 10, worker 85, storage 5, evaluation 46, runtime 10) +
MM-09 additions (new g3 tests; `test_dashboard.py` view list grows by the
four new views — recorded in CHANGED_ASSERTIONS.md). G9 full run must stay
18 ACCEPTED / 1620¢.

## Non-goals
No coordinator (`video-factory-g2`) changes; no migration; no workflow /
worker-service / evaluation-service changes (the eval service is only
*run*, never edited); no registry/plan changes; no real provider call; no
credential exists or is requested (MM-12 owns that). No STATE.md /
MEMORY.md edits; no gate report (the verifier writes it).
