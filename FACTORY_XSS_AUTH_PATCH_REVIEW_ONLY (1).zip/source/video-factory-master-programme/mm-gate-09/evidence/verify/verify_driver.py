#!/usr/bin/env python3
"""MM-09 INDEPENDENT VERIFIER driver (not the builder's harness).

Own scratch DB / ports / tokens / provider names / figures. Seeds a
stack, runs HTTP data-truth checks against raw SQL, read-only-surface
mutation attempts, a secret scan, an HTTP resolve + resolved-charge
filter check on a second production, then drives the real dashboard in
headless Chromium (verify_browser.js) and cross-checks UI-driven state
in SQL. Writes verify_results.json next to this file.
"""
import json
import os
import subprocess
import sys
import time
import urllib.request
import urllib.error
from pathlib import Path

import psycopg
from psycopg.rows import dict_row

HOME = Path.home()
G2 = HOME / "workspace/video-factory-g2"
G3 = HOME / "workspace/video-factory-g3"
HERE = Path(__file__).resolve().parent
SEEDER = (HOME / "workspace/video-factory-master-programme"
          / "mm-gate-03/tools/seed_registry.py")
EVAL_SERVICE = (HOME / "workspace/video-factory-real-ai-programme"
                / "gate-e/evaluation_service/service.py")
G2_PY = str(G2 / ".venv" / "bin" / "python")
G3_PY = str(G3 / ".venv" / "bin" / "python")

DB = "mm09_verify_scratch"
API_PORT, EVAL_PORT = 8771, 8772
OP_TOKEN = "dev-operator-token"
WORKER_TOKEN = "verify09-worker-SECRET-7f3a"
SCHEDULER_TOKEN = "verify09-scheduler-SECRET-51bc"
VALIDATOR_TOKEN = "verify09-validator-SECRET-9d2e"
CALLBACK_TOKEN = "verify09-callback-SECRET-44aa"
CRED_REF = "VERIFY09_CREDREF_SECRET_91Q"
PROVIDER = "verify-cred-provider"
PLAIN = "verify-plain-provider"
CAP = 43210
DSN = f"host=127.0.0.1 dbname={DB} user=factory password=factory_dev_local"

RESULTS = {"checks": [], "figures": {}}


def check(name, ok, detail=""):
    RESULTS["checks"].append({"name": name, "ok": bool(ok),
                              "detail": str(detail)[:400]})
    print(f"{'PASS' if ok else 'FAIL'} {name} {str(detail)[:160]}")


def raw():
    return psycopg.connect(DSN, row_factory=dict_row, autocommit=True)


def sql1(q, p=()):
    with raw() as conn:
        return conn.execute(q, p).fetchone()


def sqlall(q, p=()):
    with raw() as conn:
        return conn.execute(q, p).fetchall()


def call(method, path, body=None, token=OP_TOKEN, headers=None):
    req = urllib.request.Request(f"http://127.0.0.1:{API_PORT}{path}",
                                 method=method)
    if token is not None:
        req.add_header("X-Operator-Token", token)
    for k, v in (headers or {}).items():
        req.add_header(k, v)
    data = None
    if body is not None:
        data = json.dumps(body).encode()
        req.add_header("Content-Type", "application/json")
    try:
        with urllib.request.urlopen(req, data=data, timeout=15) as r:
            rawb = r.read()
            try:
                return r.status, json.loads(rawb or b"{}")
            except json.JSONDecodeError:
                return r.status, {"text": rawb.decode(errors="replace")}
    except urllib.error.HTTPError as e:
        rawb = e.read()
        try:
            return e.code, json.loads(rawb or b"{}")
        except json.JSONDecodeError:
            return e.code, {"text": rawb.decode(errors="replace")}


def get_text(path):
    with urllib.request.urlopen(f"http://127.0.0.1:{API_PORT}{path}",
                                timeout=15) as r:
        return r.status, r.read().decode()


def wait_health(port, path="/health"):
    for _ in range(120):
        try:
            with urllib.request.urlopen(f"http://127.0.0.1:{port}{path}",
                                        timeout=2) as r:
                if r.status == 200:
                    return True
        except Exception:
            time.sleep(0.1)
    return False


sys.path.insert(0, str(G2 / "coordinator"))
from coordinator import Coordinator  # noqa: E402


def seed():
    """Both productions fully seeded BEFORE any promotion (promotions
    must not interfere with claim-time config resolution)."""
    c = Coordinator(DSN)
    with raw() as conn:
        conn.execute(
            "INSERT INTO provider_configs(scope, operation_id, environment,"
            " provider, model, est_cost_cents, credential_ref, created_by)"
            " VALUES ('OPERATION','01.02','test',%s,'vm1',130,%s,"
            " 'mm09-verify')", (PROVIDER, CRED_REF))
        conn.execute(
            "INSERT INTO provider_configs(scope, operation_id, environment,"
            " provider, model, est_cost_cents, credential_ref, created_by)"
            " VALUES ('OPERATION','02.02','test',%s,'vm1',90,%s,"
            " 'mm09-verify')", (PROVIDER, CRED_REF))
        conn.execute(
            "INSERT INTO provider_configs(scope, operation_id, environment,"
            " provider, model, est_cost_cents, created_by) VALUES"
            " ('OPERATION','01.01','test',%s,'vm0',275,'mm09-verify')",
            (PLAIN,))
        conn.execute(
            "INSERT INTO pricing_rules(provider, model, unit_kind,"
            " unit_price_cents, pricing_version, created_by) VALUES"
            " (%s,'vm1','input_token',2.0,'verify09-1','mm09-verify')",
            (PROVIDER,))
        conn.execute(
            "INSERT INTO provider_spend_limits(provider, environment,"
            " window_kind, cap_cents) VALUES"
            " (%s,'test','calendar_day_utc',%s)", (PROVIDER, CAP))

    def unit(c, pid, run, op, worker, est, actual):
        uid = c.plan_unit(pid, run, op, "main")
        claim = c.claim(uid, worker, est)
        art = c.complete_attempt(uid, worker, claim["fencing_token"],
                                 "research_brief", b"verify-content",
                                 "local://v", actual, usage=None)
        return uid, art

    # ---- main production
    pid = c.create_production("MM-09 VERIFY main", 76543, 65432, "mm09v")
    run = c.start_run(pid, "FULL", "mm09v")
    u_settled, _ = unit(c, pid, run, "01.01", "wv-a", 275, 275)
    u_unres, _ = unit(c, pid, run, "01.02", "wv-b", 130, 130)
    u_pass, _ = unit(c, pid, run, "01.03", "wv-c", 50, 50)
    u_fail, _ = unit(c, pid, run, "01.04", "wv-d", 50, 50)
    u_human, art_h = unit(c, pid, run, "01.05", "wv-e", 50, 50)
    u_retry = c.plan_unit(pid, run, "01.06", "main")
    c.claim(u_retry, "wv-f", 50)
    c.event(u_retry, "transient_error")
    unres_ev = sql1(
        "SELECT evidence_id FROM financial_evidence fe"
        " JOIN action_attempts a ON a.attempt_id=fe.attempt_id"
        " WHERE a.unit_id=%s AND fe.charge_class='UNRESOLVED'",
        (u_unres,))["evidence_id"]
    # ---- second production: its own unresolved charge (HTTP filter test)
    pid2 = c.create_production("MM-09 VERIFY second", 76543, 65432, "mm09v")
    run2 = c.start_run(pid2, "FULL", "mm09v")
    u2_unres, _ = unit(c, pid2, run2, "02.02", "wv-g", 90, 90)
    unres_ev2 = sql1(
        "SELECT evidence_id FROM financial_evidence fe"
        " JOIN action_attempts a ON a.attempt_id=fe.attempt_id"
        " WHERE a.unit_id=%s AND fe.charge_class='UNRESOLVED'",
        (u2_unres,))["evidence_id"]
    c.close()
    return {"pid": pid, "pid2": pid2, "u_settled": u_settled,
            "u_unres": u_unres, "u_pass": u_pass, "u_fail": u_fail,
            "u_human": u_human, "u_retry": u_retry,
            "art_h": str(art_h["artifact_id"]),
            "unres_ev": str(unres_ev), "unres_ev2": str(unres_ev2)}


def main():
    r = subprocess.run(["python3", str(G3 / "tools/setup_db.py"), DB],
                       capture_output=True, text=True)
    assert r.returncode == 0, r.stderr
    r = subprocess.run([G2_PY, str(SEEDER), DB], capture_output=True,
                       text=True)
    assert r.returncode == 0, r.stderr
    RESULTS["figures"]["seeder_counts"] = json.loads(r.stdout)["counts"]

    S = seed()
    RESULTS["figures"]["seed"] = {k: str(v) for k, v in S.items()}
    pid, pid2 = S["pid"], S["pid2"]

    env = dict(os.environ, FACTORY_DSN=DSN, FACTORY_PORT=str(API_PORT),
               FACTORY_WORKER_TOKEN=WORKER_TOKEN,
               FACTORY_SCHEDULER_TOKEN=SCHEDULER_TOKEN,
               FACTORY_VALIDATOR_TOKEN=VALIDATOR_TOKEN,
               FACTORY_CALLBACK_TOKEN=CALLBACK_TOKEN,
               FACTORY_EVAL_URL=f"http://127.0.0.1:{EVAL_PORT}",
               FACTORY_STORAGE_ROOT="/tmp/mm09-verify-storage")
    api = subprocess.Popen([G3_PY, str(G3 / "api/server.py")], env=env,
                           stdout=subprocess.DEVNULL,
                           stderr=subprocess.DEVNULL)
    ev_env = dict(os.environ, FACTORY_DSN=DSN,
                  FACTORY_EVAL_PORT=str(EVAL_PORT))
    evp = subprocess.Popen([G2_PY, str(EVAL_SERVICE)], env=ev_env,
                           stdout=subprocess.DEVNULL,
                           stderr=subprocess.DEVNULL)
    try:
        assert wait_health(API_PORT), "api did not come up"
        assert wait_health(EVAL_PORT), "eval service did not come up"
        st, health = call("GET", "/health", token=None)
        check("stack_up_my_dsn", st == 200
              and health.get("registry_operations") == 192,
              f"health={health}")
        # evaluations of every verdict + PENDING gate (via API, as the
        # builder's fixture did — validate is a pre-existing endpoint)
        for uid, body in ((S["u_pass"], {"verdict": "PASS"}),
                          (S["u_fail"], {"verdict": "FAIL",
                                         "deterministic": True}),
                          (S["u_human"], {"verdict": "REVIEW_REQUIRED"})):
            st, out = call("POST", f"/units/{uid}/validate", body)
            assert st == 200, (uid, out)
        st, out = call("POST", f"/productions/{pid}/gates",
                       {"gate_kind": "HG3", "artifact_id": S["art_h"]})
        assert st == 201, out
        gate_id = out["gate_id"]
        RESULTS["figures"]["gate_id"] = gate_id

        # ================= ITEM 1: DATA TRUTH =================
        st, out = call("GET", "/model-assignments")
        asg = out["assignments"]
        truth = sqlall("SELECT operation_id, status, primary_model,"
                       " fallback_model, null_reason"
                       " FROM operation_model_assignments")
        by_op = {a["operation_id"]: a for a in asg}
        mism = [t["operation_id"] for t in truth
                if by_op[t["operation_id"]]["status"] != t["status"]
                or by_op[t["operation_id"]]["primary_model"]
                != t["primary_model"]
                or by_op[t["operation_id"]]["fallback_model"]
                != t["fallback_model"]
                or by_op[t["operation_id"]]["null_reason"]
                != t["null_reason"]]
        check("assignments_192_field_equal_sql",
              st == 200 and len(asg) == 192 and len(truth) == 192
              and not mism, f"mismatches={mism[:5]}")
        none_rows = [a for a in asg if a["status"] == "NONE"]
        check("assignments_none_rows_carry_reasons",
              len(none_rows) == 120
              and all(a["null_reason"] for a in none_rows),
              f"none={len(none_rows)}")
        st, out = call("GET", "/model-policies")
        sql_pol = sqlall("SELECT policy_id, role, version, status"
                         " FROM model_policies")
        check("policies_match_sql",
              st == 200 and len(out["policies"]) == len(sql_pol) == 7,
              f"api={len(out['policies'])} sql={len(sql_pol)}")
        # pick roles for promotions from ground truth
        proposed = [p["role"] for p in sql_pol
                    if p["status"] == "PROPOSED"]
        check("at_least_3_proposed_roles", len(proposed) >= 3,
              f"proposed={proposed}")
        http_role = proposed[0]
        browser_role = proposed[1]
        worker_role = proposed[2]
        RESULTS["figures"]["roles"] = {"http": http_role,
                                       "browser": browser_role,
                                       "worker": worker_role}
        # finance aggregates vs SQL (main production)
        st, out = call("GET", f"/productions/{pid}/financial-evidence")
        agg = {}
        for row in out["financial_evidence"]:
            agg[row["charge_class"]] = (agg.get(row["charge_class"], 0)
                                        + (row["amount_cents"] or 0))
        truth_agg = {t["charge_class"]: int(t["s"]) for t in sqlall(
            "SELECT charge_class, COALESCE(SUM(amount_cents),0) AS s"
            " FROM financial_evidence WHERE production_id=%s"
            " GROUP BY charge_class", (pid,))}
        check("finance_aggregates_equal_sql", st == 200
              and agg == truth_agg, f"api={agg} sql={truth_agg}")
        RESULTS["figures"]["finance_agg"] = truth_agg
        # evaluations list vs SQL
        st, out = call("GET", f"/productions/{pid}/evaluations")
        evs = out["evaluations"]
        truth_ev = sqlall(
            "SELECT qe.verdict, u.operation_id FROM quality_evaluations qe"
            " JOIN artifacts a ON a.artifact_id=qe.artifact_id"
            " LEFT JOIN execution_units u ON u.unit_id=a.produced_by_unit"
            " WHERE a.production_id=%s", (pid,))
        check("evaluations_list_matches_sql",
              st == 200 and len(evs) == len(truth_ev) == 3
              and {(e["verdict"], e["operation_id"]) for e in evs}
              == {(t["verdict"], t["operation_id"]) for t in truth_ev},
              f"api={[(e['verdict'], e['operation_id']) for e in evs]}")
        fail_ev = [e for e in evs if e["verdict"] == "FAIL"][0]
        ev_doc = fail_ev["evidence"]
        if isinstance(ev_doc, str):
            ev_doc = json.loads(ev_doc)
        check("fail_evaluation_deterministic_flag",
              bool(ev_doc.get("deterministic")), f"evidence={ev_doc}")
        st, _ = call("GET", "/productions/00000000-0000-0000-0000-"
                            "000000000000/evaluations")
        check("evaluations_unknown_production_404", st == 404, f"st={st}")
        # golden-set status surface
        st, out = call("GET", "/evaluation-status")
        check("evaluation_status_7_seed_0_expert_unarmed",
              st == 200 and out.get("reachable") is True
              and out.get("seed_cases") == 7
              and out.get("expert_cases") == 0
              and out.get("armed") is False, f"out={out}")
        # benchmarks empty
        st, out = call("GET", "/benchmarks")
        check("benchmarks_empty_and_sql_zero",
              st == 200 and out["benchmarks"] == []
              and sql1("SELECT COUNT(*) AS n FROM benchmark_results")["n"]
              == 0, f"st={st}")
        # approvals/repair ground truth via API reads
        st, out = call("GET", f"/productions/{pid}/gates")
        pend = [g for g in out["gates"] if g["verdict"] == "PENDING"]
        check("pending_gate_listed",
              len(pend) == 1 and pend[0]["gate_id"] == gate_id
              and pend[0]["artifact_id"] == S["art_h"], f"pend={pend}")
        st, out = call("GET", f"/productions/{pid}/units")
        states = {u["unit_id"]: u["state"] for u in out["units"]}
        check("unit_states_seeded",
              states[S["u_human"]] == "AWAITING_HUMAN"
              and states[S["u_fail"]] == "BLOCKED"
              and states[S["u_retry"]] == "RETRY_WAIT",
              f"states={ {k[-4:]: v for k, v in states.items()} }")

        # ============ ITEM 4 (HTTP part): resolve + filter ============
        st, out = call("GET", f"/productions/{pid2}/financial-evidence")
        pend2 = [x for x in out["financial_evidence"]
                 if x["charge_class"] == "UNRESOLVED"
                 and x["requires_reconciliation"]]
        check("prod2_unresolved_pending_before_resolve",
              len(pend2) == 1
              and str(pend2[0]["evidence_id"]) == S["unres_ev2"],
              f"pend={len(pend2)}")
        st, out = call("POST",
                       f"/financial-evidence/{S['unres_ev2']}/resolve",
                       {"usage": {"input_tokens": 21}})
        check("prod2_resolve_200_calculated_42",
              st == 200 and out.get("amount_cents") == 42
              and out.get("basis") == "calculated", f"st={st} out={out}")
        st, out = call("GET", f"/productions/{pid2}/financial-evidence")
        rows2 = out["financial_evidence"]
        hist = [x for x in rows2 if x["charge_class"] == "UNRESOLVED"]
        pend2b = [x for x in hist if x["requires_reconciliation"]]
        sql_hist = sql1("SELECT requires_reconciliation"
                        " FROM financial_evidence WHERE evidence_id=%s",
                        (S["unres_ev2"],))
        check("resolved_charge_leaves_pending_history_remains",
              len(hist) == 1 and pend2b == []
              and sql_hist["requires_reconciliation"] is False,
              f"hist={len(hist)} pending={len(pend2b)}")
        res2 = sql1("SELECT r.state, r.settled_cents"
                    " FROM budget_reservations r"
                    " JOIN action_attempts a"
                    "   ON a.reservation_id=r.reservation_id"
                    " JOIN financial_evidence e"
                    "   ON e.attempt_id=a.attempt_id"
                    " WHERE e.evidence_id=%s", (S["unres_ev2"],))
        check("prod2_reservation_settled_42",
              (res2["state"], res2["settled_cents"]) == ("SETTLED", 42),
              f"res={dict(res2)}")
        # provider spend == coordinator enforcement computation (now:
        # settled=42 via pid2 reservation, held=130 via main pid claim)
        c2 = Coordinator(DSN)
        cur = c2.conn.cursor()
        pos = c2._provider_window_position(cur, PROVIDER)
        c2.conn.rollback()
        c2.close()
        pos = {k: int(v) for k, v in pos.items()}
        RESULTS["figures"]["window_position_direct"] = pos
        st, out = call("GET", "/provider-spend")
        prow = [x for x in out["provider_spend"]
                if x["provider"] == PROVIDER]
        check("provider_spend_equals_enforcement_computation",
              st == 200 and len(prow) == 1
              and prow[0]["cap_cents"] == CAP
              and prow[0]["settled_cents"] == pos["settled_cents"]
              and prow[0]["held_cents"] == pos["held_cents"]
              and prow[0]["total_cents"] == pos["total_cents"]
              and pos["settled_cents"] == 42
              and pos["held_cents"] == 130
              and pos["total_cents"] == 172,
              f"api={prow} direct={pos}")

        # ============ ITEM 3: read-only surfaces + secrets ============
        def snapshot():
            return {
                "policies": sql1("SELECT COUNT(*) AS n"
                                 " FROM model_policies")["n"],
                "policy_events": sql1("SELECT COUNT(*) AS n"
                                      " FROM policy_events")["n"],
                "evidence": sql1("SELECT COUNT(*) AS n"
                                 " FROM financial_evidence")["n"],
                "benchmarks": sql1("SELECT COUNT(*) AS n"
                                   " FROM benchmark_results")["n"],
                "gates": sql1("SELECT COUNT(*) AS n"
                              " FROM human_gates")["n"],
                "units": sql1("SELECT COUNT(*) AS n"
                              " FROM execution_units")["n"],
                "assignments_active": sql1(
                    "SELECT COUNT(*) AS n FROM"
                    " operation_model_assignments"
                    " WHERE status='ACTIVE'")["n"],
            }
        before = snapshot()
        mut_results = {}
        for path in ("/benchmarks", "/provider-spend",
                     f"/productions/{pid}/evaluations",
                     "/evaluation-status"):
            for method in ("POST", "PUT", "DELETE", "PATCH"):
                stx, _ = call(method, path, {"x": 1})
                mut_results[f"{method} {path}"] = stx
        after = snapshot()
        check("new_endpoints_refuse_mutation",
              all(s in (404, 405) for s in mut_results.values()),
              f"statuses={sorted(set(mut_results.values()))}")
        check("mutation_attempts_changed_nothing", before == after,
              f"before={before} after={after}")
        st, _ = call("GET", "/benchmarks", token=None)
        check("new_endpoints_require_auth", st == 401, f"st={st}")
        # secret scan over page + every dashboard-consumed GET surface
        _, html = get_text("/")
        surfaces = {"page": html}
        for path in ("/benchmarks", "/provider-spend", "/model-policies",
                     "/model-assignments", "/provider-health",
                     "/productions", "/evaluation-status",
                     f"/productions/{pid}/financial-evidence",
                     f"/productions/{pid}/evaluations",
                     f"/productions/{pid}/gates",
                     f"/productions/{pid}/units",
                     f"/productions/{pid}/budget"):
            st, out = call("GET", path)
            assert st == 200, (path, st)
            surfaces[path] = json.dumps(out)
        secrets = [OP_TOKEN, WORKER_TOKEN, SCHEDULER_TOKEN,
                   VALIDATOR_TOKEN, CALLBACK_TOKEN, CRED_REF]
        leaks = [(name, s[:14]) for name, text in surfaces.items()
                 for s in secrets if s in text]
        check("secret_scan_clean", not leaks, f"leaks={leaks}")
        check("page_has_approvals_note_and_bench_empty_state",
              "AWAITING_OWNER" in html
              and "No benchmark data recorded" in html,
              "markers in served page HTML")

        # ============ ITEM 1b: my own promotion (HTTP) ============
        pol_http = sql1("SELECT policy_id FROM model_policies"
                        " WHERE role=%s AND status='PROPOSED'",
                        (http_role,))["policy_id"]
        st, out = call("POST", f"/model-policies/{pol_http}/promote", {})
        sql_status = sql1("SELECT status FROM model_policies"
                          " WHERE policy_id=%s", (pol_http,))["status"]
        st, ev_out = call("GET", f"/model-policies/{pol_http}/events")
        promotes = [e for e in ev_out["events"]
                    if e["action"] == "PROMOTE"]
        check("http_promotion_reflected_with_actor",
              st == 200 and out.get("status") == "ACTIVE"
              and sql_status == "ACTIVE" and len(promotes) >= 1
              and all(e["actor"].startswith("operator:")
                      for e in promotes),
              f"actor={[e['actor'] for e in promotes]}")
        st, out = call("GET", "/model-policies")
        active_row = [p for p in out["policies"]
                      if p["policy_id"] == str(pol_http)]
        check("policies_surface_shows_active_version",
              len(active_row) == 1
              and active_row[0]["status"] == "ACTIVE",
              f"row={active_row}")

        # ============ ITEM 2: BROWSER RUN ============
        shots = HERE / "shots"
        node_env = dict(os.environ,
                        MM09V_BASE=f"http://127.0.0.1:{API_PORT}",
                        MM09V_PID=pid, MM09V_POLICY_ROLE=browser_role,
                        MM09V_WORKER_ROLE=worker_role,
                        MM09V_GATE_KIND="HG3",
                        MM09V_WORKER_TOKEN=WORKER_TOKEN,
                        MM09V_SHOTS=str(shots))
        r = subprocess.run(["node", str(HERE / "verify_browser.js")],
                           capture_output=True, text=True, env=node_env,
                           timeout=420)
        RESULTS["figures"]["browser_rc"] = r.returncode
        RESULTS["figures"]["browser_stderr_tail"] = r.stderr[-600:]
        start = r.stdout.rfind('{\n "total"')
        browser = json.loads(r.stdout[start:]) if start >= 0 else None
        RESULTS["browser"] = browser
        check("browser_run_all_dom_assertions",
              r.returncode == 0 and browser is not None
              and browser["failed"] == 0,
              f"rc={r.returncode} browser={browser and browser['total']}")
        # ---- post-browser SQL cross-checks
        pol_b = sql1("SELECT policy_id, status FROM model_policies"
                     " WHERE role=%s ORDER BY created_at DESC LIMIT 1",
                     (browser_role,))
        ev_b = sql1("SELECT action, actor FROM policy_events"
                    " WHERE policy_id=%s AND action='PROMOTE'"
                    " ORDER BY at DESC LIMIT 1", (pol_b["policy_id"],))
        check("browser_promotion_in_sql",
              pol_b["status"] == "ACTIVE" and ev_b is not None
              and ev_b["actor"].startswith("operator:"),
              f"policy={dict(pol_b)} event={dict(ev_b) if ev_b else None}")
        res_main = sql1("SELECT r.state, r.settled_cents"
                        " FROM budget_reservations r"
                        " JOIN action_attempts a"
                        "   ON a.reservation_id=r.reservation_id"
                        " WHERE a.unit_id=%s", (S["u_unres"],))
        check("browser_resolve_settled_126",
              (res_main["state"], res_main["settled_cents"])
              == ("SETTLED", 126), f"res={dict(res_main)}")
        gate_row = sql1("SELECT verdict, decided_by FROM human_gates"
                        " WHERE gate_id=%s", (gate_id,))
        check("browser_gate_approved_in_sql",
              gate_row["verdict"] == "APPROVED"
              and gate_row["decided_by"] == "operator",
              f"gate={dict(gate_row)}")
        pol_w = sql1("SELECT policy_id, status FROM model_policies"
                     " WHERE role=%s AND status='PROPOSED'"
                     " ORDER BY created_at LIMIT 1", (worker_role,))
        refusal = sql1("SELECT COUNT(*) AS n FROM audit_events"
                       " WHERE event_type='policy_action_refused'"
                       " AND payload->>'action'='promote'"
                       " AND payload->>'policy_id'=%s",
                       (str(pol_w["policy_id"]),)) if pol_w else None
        check("worker_refusal_audited_policy_unchanged",
              pol_w is not None and refusal is not None
              and refusal["n"] >= 1,
              f"policy={dict(pol_w) if pol_w else None} audits={refusal}")
        hist_main = sql1("SELECT requires_reconciliation"
                         " FROM financial_evidence WHERE evidence_id=%s",
                         (S["unres_ev"],))
        check("main_resolved_charge_history_remains",
              hist_main["requires_reconciliation"] is False,
              f"hist={dict(hist_main)}")
    finally:
        for p in (api, evp):
            p.terminate()
            try:
                p.wait(timeout=5)
            except subprocess.TimeoutExpired:
                p.kill()
    failed = [c for c in RESULTS["checks"] if not c["ok"]]
    RESULTS["verdict"] = "PASS" if not failed else "FAIL"
    RESULTS["failed_checks"] = [c["name"] for c in failed]
    (HERE / "verify_results.json").write_text(
        json.dumps(RESULTS, indent=1, default=str))
    print(json.dumps({"verdict": RESULTS["verdict"],
                      "checks": len(RESULTS["checks"]),
                      "failed": RESULTS["failed_checks"]}))
    return 0 if not failed else 1


if __name__ == "__main__":
    sys.exit(main())
