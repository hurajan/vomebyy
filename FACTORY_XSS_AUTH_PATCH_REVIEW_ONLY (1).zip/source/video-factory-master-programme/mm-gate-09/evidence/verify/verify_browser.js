/* MM-09 INDEPENDENT VERIFIER browser run (Playwright + Chromium
   headless shell). Drives the real dashboard UI against the verifier's
   own stack: renders every new tab, promotes a policy, resolves the
   unresolved charge (63 input tokens -> 126c at the verifier's 2.0c
   pricing), approves the pending HG3 gate — all through the UI forms —
   and exercises the WORKER-role promote refusal display.
   Env: MM09V_BASE, MM09V_PID, MM09V_POLICY_ROLE, MM09V_WORKER_ROLE,
        MM09V_GATE_KIND, MM09V_WORKER_TOKEN, MM09V_SHOTS. */
const { chromium } = require("/home/hatch/workspace/video-factory-g4/node_modules/playwright");
const fs = require("fs");
const path = require("path");

const BASE = process.env.MM09V_BASE;
const PID = process.env.MM09V_PID;
const POLICY_ROLE = process.env.MM09V_POLICY_ROLE;
const WORKER_ROLE = process.env.MM09V_WORKER_ROLE;
const GATE_KIND = process.env.MM09V_GATE_KIND || "HG3";
const WORKER_TOKEN = process.env.MM09V_WORKER_TOKEN;
const SHOTS = process.env.MM09V_SHOTS;
const SHELL = process.env.HOME +
  "/.cache/ms-playwright/chromium_headless_shell-1248/chrome-headless-shell-linux64/chrome-headless-shell";

const results = [];
function check(name, ok, detail) {
  results.push({ name, ok: !!ok, detail: String(detail || "") });
  console.log(`${ok ? "PASS" : "FAIL"} ${name} ${detail || ""}`);
}

(async () => {
  fs.mkdirSync(SHOTS, { recursive: true });
  const browser = await chromium.launch({ executablePath: SHELL, headless: true });
  const page = await browser.newPage({ viewport: { width: 1440, height: 1000 } });
  page.on("pageerror", e => check("no_pageerror", false, e.message));
  await page.goto(BASE + "/", { waitUntil: "load" });
  await page.waitForSelector("#asgRows tr", { state: "attached", timeout: 30000 });
  await page.waitForFunction(
    () => document.querySelectorAll("#asgRows tr").length === 192,
    null, { timeout: 30000 });
  check("dom_health_badge_192",
        (await page.textContent("#healthBadge")).includes("192"),
        await page.textContent("#healthBadge"));
  check("dom_assignments_192_rows",
        (await page.locator("#asgRows tr").count()) === 192);
  const bench = await page.textContent("#benchWrap");
  check("dom_benchmark_empty_state",
        bench.includes("No benchmark data recorded") && !/\d+\.\d/.test(bench),
        bench.slice(0, 70));

  await page.selectOption("#prodSel", PID);
  await page.waitForSelector("[id^='resIn-']", { state: "attached", timeout: 30000 });

  // ---- Models tab + promote through the UI
  await page.click("button[data-view='models']");
  await page.waitForTimeout(400);
  await page.screenshot({ path: path.join(SHOTS, "v_models.png") });
  const row = page.locator("#policyRows tr", { hasText: POLICY_ROLE });
  await row.getByRole("button", { name: "Promote" }).click();
  await page.waitForFunction(
    (role) => [...document.querySelectorAll("#policyRows tr")]
      .some(tr => tr.textContent.includes(role) && tr.textContent.includes("ACTIVE")),
    POLICY_ROLE, { timeout: 30000 });
  const rowText = await page.locator("#policyRows tr", { hasText: POLICY_ROLE }).textContent();
  check("dom_ui_promote_activates_policy", rowText.includes("ACTIVE"),
        rowText.replace(/\s+/g, " ").slice(0, 90));
  await page.screenshot({ path: path.join(SHOTS, "v_models_promoted.png") });

  // ---- Finance tab + resolve through the UI form (63 tokens -> 126c)
  await page.click("button[data-view='finance']");
  await page.waitForSelector("[id^='resIn-']", { timeout: 30000 });
  const wrapBefore = await page.textContent("#unresolvedWrap");
  check("dom_unresolved_listed_before_resolve",
        wrapBefore.includes("UNRESOLVED") || wrapBefore.includes("Resolve"),
        wrapBefore.replace(/\s+/g, " ").slice(0, 90));
  await page.locator("[id^='resIn-']").first().fill("63");
  await page.screenshot({ path: path.join(SHOTS, "v_finance_before_resolve.png") });
  const resolveBtn = page.getByRole("button", { name: "Resolve" }).first();
  await resolveBtn.scrollIntoViewIfNeeded();
  await resolveBtn.click();
  await page.waitForFunction(
    () => document.querySelector("#unresolvedWrap").textContent.includes("No unresolved charges"),
    null, { timeout: 30000 });
  check("dom_ui_resolve_clears_unresolved", true,
        "unresolved list emptied after UI resolve");
  const finSummary = await page.textContent("#finSummaryRows");
  check("dom_finance_summary_shows_settled", finSummary.includes("Settled"),
        finSummary.replace(/\s+/g, " ").slice(0, 70));
  await page.screenshot({ path: path.join(SHOTS, "v_finance_after_resolve.png") });

  // ---- Approvals tab + approve the pending gate through the UI
  await page.click("button[data-view='approvals']");
  await page.waitForFunction(
    () => document.querySelector("#apprUnitRows").textContent.includes("AWAITING_HUMAN"),
    null, { timeout: 30000 });
  const apprText = await page.textContent("#view-approvals");
  check("dom_approvals_identity_note", apprText.includes("AWAITING_OWNER"),
        "named-approver gap note visible");
  check("dom_approvals_queue_row", apprText.includes(GATE_KIND),
        `pending ${GATE_KIND} gate listed`);
  const repairText = await page.textContent("#repairUnitRows");
  check("dom_repair_lists_blocked_and_retry_wait",
        repairText.includes("BLOCKED") && repairText.includes("RETRY_WAIT"),
        repairText.replace(/\s+/g, " ").slice(0, 90));
  await page.screenshot({ path: path.join(SHOTS, "v_approvals.png") });
  const approveBtn = page.locator("#apprGateRows").getByRole("button", { name: "Approve" });
  await approveBtn.scrollIntoViewIfNeeded();
  await approveBtn.click();
  await page.waitForFunction(
    () => document.querySelector("#apprGateRows").textContent.includes("No pending gates"),
    null, { timeout: 30000 });
  check("dom_ui_gate_approve", true, "pending gate decided through the UI");
  await page.screenshot({ path: path.join(SHOTS, "v_approvals_after.png") });

  // ---- Quality tab: golden-set card
  await page.click("button[data-view='quality']");
  await page.waitForFunction(
    () => document.querySelector("#goldenCard").textContent.includes("SEED"),
    null, { timeout: 30000 });
  const golden = await page.textContent("#goldenCard");
  check("dom_golden_card_7_seed_0_expert",
        golden.includes("7 SEED") && golden.includes("0 EXPERT"),
        golden.replace(/\s+/g, " ").slice(0, 90));
  check("dom_golden_card_arming_off", golden.includes("OFF"), "arming OFF shown");
  const qualText = await page.textContent("#qualRows");
  check("dom_quality_rows_show_verdicts",
        qualText.includes("FAIL") && qualText.includes("PASS"),
        qualText.replace(/\s+/g, " ").slice(0, 90));
  await page.screenshot({ path: path.join(SHOTS, "v_quality.png") });

  // ---- WORKER session: promote refusal rendered, not hidden
  await page.fill("#token", WORKER_TOKEN);
  await page.selectOption("#roleSel", "WORKER");
  await page.waitForTimeout(2500);
  await page.click("button[data-view='models']");
  const wrow = page.locator("#policyRows tr", { hasText: WORKER_ROLE });
  const wpromote = wrow.getByRole("button", { name: "Promote" });
  await wpromote.scrollIntoViewIfNeeded();
  await wpromote.click();
  await page.waitForFunction(
    () => document.querySelector("#err").textContent.includes("OPERATOR only"),
    null, { timeout: 30000 });
  check("dom_worker_promote_refusal_surfaced", true,
        await page.textContent("#err"));
  await page.screenshot({ path: path.join(SHOTS, "v_worker_refusal.png") });

  await browser.close();
  const failed = results.filter(r => !r.ok);
  console.log(JSON.stringify({ total: results.length, failed: failed.length, results }, null, 1));
  process.exit(failed.length ? 1 : 0);
})().catch(e => { console.error("BROWSER RUN ERROR:", e); process.exit(2); });
