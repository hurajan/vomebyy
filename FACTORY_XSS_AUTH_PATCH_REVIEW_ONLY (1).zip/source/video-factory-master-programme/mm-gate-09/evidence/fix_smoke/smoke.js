/* D-MM09-V1 post-fix browser smoke (Playwright + Chromium headless shell).
   Proves: (1) the dashboard token input renders EMPTY (no pre-filled
   dev-operator-token), (2) neither the old default nor the env-configured
   token appears in the live page, (3) with an empty field the page's
   authenticated loads fail visibly, and (4) after the operator TYPES the
   token, Refresh + a real UI mutation (create production) work end to end.
   Env: FIX_BASE (dashboard URL), FIX_TOKEN (server FACTORY_API_TOKEN),
        FIX_SHOTS (screenshot dir). */
const { chromium } = require("/home/hatch/workspace/video-factory-g4/node_modules/playwright");
const fs = require("fs");
const path = require("path");

const BASE = process.env.FIX_BASE;
const TOKEN = process.env.FIX_TOKEN;
const SHOTS = process.env.FIX_SHOTS;
const SHELL = process.env.HOME +
  "/.cache/ms-playwright/chromium_headless_shell-1248/chrome-headless-shell-linux64/chrome-headless-shell";

const results = [];
function check(name, ok, detail) {
  results.push({ name, ok: !!ok, detail: String(detail || "") });
  console.log(`${ok ? "PASS" : "FAIL"} ${name} ${detail || ""}`);
}

(async () => {
  fs.mkdirSync(SHOTS, { recursive: true });
  const browser = await chromium.launch({ executablePath: SHELL, headless: true });
  const page = await browser.newPage({ viewport: { width: 1440, height: 1000 } });
  page.on("pageerror", e => check("no_pageerror", false, e.message));
  await page.goto(BASE + "/", { waitUntil: "load" });
  await page.waitForTimeout(1500); // let the on-load refreshAll() settle

  // (1) token field renders empty, placeholder present
  const tokVal = await page.inputValue("#token");
  check("token_field_empty_on_load", tokVal === "", JSON.stringify(tokVal));
  const ph = await page.getAttribute("#token", "placeholder");
  check("token_field_has_placeholder", !!ph, ph || "");

  // (2) no token VALUES anywhere in the live DOM
  const html = await page.content();
  check("dom_has_no_dev_default", !html.includes("dev-operator-token"));
  check("dom_has_no_env_token", !html.includes(TOKEN));

  // (3) empty token -> authenticated loads fail visibly (error banner set)
  const errBefore = (await page.textContent("#err")) || "";
  check("auth_error_shown_before_token", errBefore.trim().length > 0, errBefore.slice(0, 80));

  // (4) type the token, Refresh -> loads succeed
  await page.fill("#token", TOKEN);
  await page.click("#refreshBtn");
  await page.waitForFunction(
    () => (document.querySelector("#healthBadge").textContent || "").includes("192 ops"),
    null, { timeout: 20000 });
  check("health_badge_after_token", true, await page.textContent("#healthBadge"));
  const errAfter = (await page.textContent("#err")) || "";
  check("error_cleared_after_token", errAfter.trim() === "", errAfter.slice(0, 80));

  // (5) real mutation through the UI with the typed token: create production
  await page.fill("#inTitle", "Fix Smoke Production");
  await page.fill("#inHard", "100000");
  await page.fill("#inSoft", "50000");
  await page.click("#createProdBtn");
  await page.waitForFunction(
    () => (document.querySelector("#prodRows").textContent || "").includes("Fix Smoke Production"),
    null, { timeout: 20000 });
  check("production_created_via_ui", true);
  await page.screenshot({ path: path.join(SHOTS, "fix_smoke_dashboard.png"), fullPage: true });

  await browser.close();
  const fails = results.filter(r => !r.ok).length;
  console.log(JSON.stringify({ total: results.length, fails, results }, null, 2));
  process.exit(fails ? 1 : 0);
})().catch(e => { console.error("SMOKE ERROR", e); process.exit(2); });
