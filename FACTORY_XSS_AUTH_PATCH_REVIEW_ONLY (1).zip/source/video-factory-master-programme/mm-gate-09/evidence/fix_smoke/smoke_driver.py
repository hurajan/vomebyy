"""D-MM09-V1 post-fix browser smoke driver.

Starts the G3 API on a fresh scratch DB with a CUSTOM env-configured
operator token (FACTORY_API_TOKEN=fix-smoke-op-token-7x — deliberately
not the documented default), runs the Playwright smoke against it,
then stops the server and drops the scratch DB.
"""
import os
import subprocess
import sys
import time
import urllib.request
from pathlib import Path

G3 = Path.home() / "workspace" / "video-factory-g3"
HERE = Path(__file__).resolve().parent
DB = "g3_fix_smoke_scratch"
PORT = 8779
TOKEN = "fix-smoke-op-token-7x"
DSN = f"host=127.0.0.1 dbname={DB} user=factory password=factory_dev_local"


def main():
    r = subprocess.run(["python3", str(G3 / "tools" / "setup_db.py"), DB],
                       capture_output=True, text=True)
    if r.returncode != 0:
        print("setup_db failed:", r.stdout, r.stderr)
        return 2
    env = dict(os.environ, FACTORY_DSN=DSN, FACTORY_PORT=str(PORT),
               FACTORY_API_TOKEN=TOKEN)
    proc = subprocess.Popen([str(G3 / ".venv" / "bin" / "python"),
                             str(G3 / "api" / "server.py")], env=env,
                            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    try:
        up = False
        for _ in range(100):
            try:
                with urllib.request.urlopen(
                        f"http://127.0.0.1:{PORT}/health", timeout=2) as resp:
                    if resp.status == 200:
                        up = True
                        break
            except Exception:
                time.sleep(0.1)
        if not up:
            print("server did not come up")
            return 2
        js_env = dict(os.environ, FIX_BASE=f"http://127.0.0.1:{PORT}",
                      FIX_TOKEN=TOKEN, FIX_SHOTS=str(HERE / "shots"))
        r = subprocess.run(["node", str(HERE / "smoke.js")], env=js_env,
                           capture_output=True, text=True, timeout=180)
        print(r.stdout)
        if r.stderr:
            print("STDERR:", r.stderr[-2000:])
        return r.returncode
    finally:
        proc.terminate()
        try:
            proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            proc.kill()
        denv = dict(os.environ, PGPASSWORD="factory_dev_local")
        subprocess.run(["psql", "-h", "127.0.0.1", "-U", "factory", "-d", "postgres",
                        "-c", f'DROP DATABASE IF EXISTS {DB}'],
                       capture_output=True, text=True, env=denv)


if __name__ == "__main__":
    sys.exit(main())
