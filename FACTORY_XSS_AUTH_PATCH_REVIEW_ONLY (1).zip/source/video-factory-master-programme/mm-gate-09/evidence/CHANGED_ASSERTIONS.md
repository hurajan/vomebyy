# MM-09 — Changed assertions & in-pass fixes

## Changed assertions (pre-existing tests)

1. **`video-factory-g3/tests/test_dashboard.py` — VIEWS list**: gains
   `models`, `approvals`, `quality` (the three new views; Finance is an
   extension of the existing view). This is the test's own inventory of
   the page's sections; the page grew, so the inventory grows. No
   assertion was weakened.
2. **`video-factory-g3/tests/test_api_contract.py` — `test_all_endpoints`**:
   gains four `hit()` exercises for the MM-09 read endpoints
   (`GET /benchmarks`, `GET /provider-spend`,
   `GET /productions/{id}/evaluations`, `GET /evaluation-status`). The
   contract test requires every contract endpoint to be exercised; the
   contract grew 47 → 51 endpoints (1.10.0 → 1.11.0), so the exercises
   grow with it. No existing exercise or key assertion changed.
3. **`video-factory-g3/tests/test_mm09_dashboard.py` import style**:
   written initially as `from coordinator.coordinator import Coordinator`
   (G2 root on sys.path); under full-tree `unittest discover` this
   collides with `test_mm08_api.py`, which loads G2's `coordinator.py`
   as a top-level module. Aligned to the MM-08 pattern verbatim
   (`G2/coordinator` on sys.path, `from coordinator import Coordinator`).
   Test-logic unchanged.

## In-pass fixes (MM-09 code only)

4. **Dashboard unresolved-charge filter (found by the browser run, not
   by the HTTP tests):** the Finance view initially listed every
   `charge_class='UNRESOLVED'` evidence row as pending. MM-08 semantics:
   a resolved charge keeps its UNRESOLVED row as history and resolution
   flips `requires_reconciliation` to false — the flag the resolve
   endpoint itself keys its "already resolved" refusal on. The view now
   lists/counts/sums only rows with `requires_reconciliation` true, and
   `test_mm09_dashboard.py` pins the rule (after a UI-shaped resolve,
   the production's pending set is empty). Before the fix, the browser
   run's resolve succeeded (HTTP 200, reservation settled 40¢) yet the
   row stayed listed — a wrong operator picture of exactly the kind this
   gate exists to prevent.
5. **Browser harness click reliability (harness-only, no product
   change):** two Playwright/headless-shell ergonomics fixes —
   (a) waits on elements inside `display:none` sections use
   `state:"attached"`; (b) a `fullPage` screenshot resizes the headless
   viewport and a following click could silently land off-target (the
   Resolve click never fired its request): pre-action screenshots are
   viewport-only and below-the-fold buttons are scrolled into view
   before clicking. The promote assertion also polls the re-rendered
   policy row instead of racing `loadModels`.

## Explicitly NOT changed

- No coordinator (G2) code, no migration, no registry/plan/workflow,
  no worker-service or evaluation-service code.
- No existing API route's behavior; the four new routes are GET-only.
- The dashboard's existing twelve views behave as before; the default
  session (OPERATOR + the token field) issues byte-identical headers to
  the pre-MM-09 page.
- `benchmark_results` remains empty; no score was seeded anywhere for
  display purposes. The golden set remains 7 SEED / 0 EXPERT, unarmed.
