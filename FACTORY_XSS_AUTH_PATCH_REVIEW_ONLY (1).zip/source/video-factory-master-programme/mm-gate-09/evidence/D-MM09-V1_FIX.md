# D-MM09-V1 — FIX RECORD

**Finding (from `MM09_VERIFIER_REPORT.md`, MINOR, pre-existing):** the served
dashboard page pre-filled its token input with the documented local-dev
default operator token — `<input id="token" value="dev-operator-token">`
(`video-factory-g3/dashboard/index.html` line 36). The page is served
unauthenticated, so the pre-fill handed the *default* credential to anyone
who could fetch the page. The string is a public, documented local-dev
default, not a configured secret; no env-configured token value was ever
emitted. Recommendation: ship the token field empty.

**Fixer:** D-MM09-V1 fix agent, 2026-10-29. Serial execution, port hygiene
(8730/8795/8796 killed by port before every run).

## Exact diff (one line, one file)

File: `video-factory-g3/dashboard/index.html`, line 36 — the `value`
attribute is removed and a neutral placeholder added. Element id, size,
label, role selector, header behavior, and every endpoint are unchanged.
The page JS reads the token at call time (`const token = () =>
$("token").value;`, line 244), so no JS change was needed.

```diff
-  <label class="dim">Token <input id="token" value="dev-operator-token" size="18"></label>
+  <label class="dim">Token <input id="token" placeholder="paste token" size="18"></label>
```

No other product file was modified. No test file was modified: no
permanent-suite assertion depended on the pre-fill (see below).

## Test-suite assertion check (task step 2)

- `tests/test_dashboard.py`: contains no reference to the token input or
  its value at all.
- `tests/test_mm09_dashboard.py`: its secret-scan and page-structure
  tests assert the input's presence/ids and the *absence* of configured
  secret values — nothing asserts the pre-fill. Its own results record
  (builder's `mm09_dashboard_tests.json`) noted the pre-fill as an
  accepted pre-existing condition; that is an evidence record, not an
  assertion.
- `tests/test_api_contract.py` and the remaining g3 suites: no reference
  to the dashboard token field's value.
- **Result: zero assertions updated; nothing weakened.**

## Grep findings — token-value emission across the factory trees

Searched `video-factory-g3` and g1, g2, g4–g9 +
`video-factory-real-ai-programme` for `dev-operator-token`,
`dev-worker-token`, `dev-scheduler-token`, `dev-validator-token`,
`dev-callback-token`, and for the page-emission pattern `value="dev-…"`.

**Page/response emission of a token VALUE: exactly one site existed —
the one fixed above.** After the fix, `value="dev-…"` matches nowhere
in any tree. The only other `.html` file in the trees is n8n's own
bundled UI shell (`video-factory-g4/n8n-data/.cache/n8n/public/
index.html`, third-party, contains no token values).

All remaining literal occurrences are **noted, NOT changed** (out of
scope per the fix brief — none emit a value into a page or response):

| Location | Nature |
|---|---|
| `video-factory-g3/api/server.py:73` | Server-side env fallback `os.environ.get("FACTORY_API_TOKEN", "dev-operator-token")` — the accepted-token default itself; changing it would change auth behavior and break the documented local-dev flow and every fixture. Not an emission. |
| `video-factory-g3/api/server.py:10`, `video-factory-g3/README.md:14` | Documentation of the local-dev default (docstring / README, both marked LOCAL DEV ONLY). |
| `video-factory-g3/tests/server_fixture.py:13` | Test-fixture client constant (sends the header; emits nothing). |
| g4–g8 `driver/dispatch.py`, `workers/mock_workers.py`, `tests/test_g*_station*.py`, g7/g8 `evidence/*_verifier_harness.py`, g9 `tests/g9_common.py`, gate-h `harness/common.py` | Client/test credential constants for the local scratch stacks (header use only). |
| g4–g8 `tools/setup_env.py`, g9 `tools/setup_fullrun.py` | Local-stack env seeding: writes the documented dev token set into generated env for scratch stacks — the counterpart of the server default, not a page/response emission. |
| g4–g8 `tools/gen_workflows.py`, gate-h `harness/t08_security.py` | **Absence guards**: needle lists asserting generated workflow JSON contains *no* token literals (Gate G verifier confirmed zero occurrences). |
| `video-factory-real-ai-programme/gate-a/GATE_A_REPORT.md` (GA-10), gate-g verifier report | Historical reports documenting this pre-existing posture / evidencing absence in workflows. |

## Re-runs (serial, port hygiene)

| Run | Result |
|---|---|
| g3 full suite (`.venv/bin/python -m unittest discover -s tests`) | **54/54 OK** (53.1s) — matches the MM-09 regression anchor exactly |
| Dashboard modules standalone (`tests.test_dashboard` + `tests.test_mm09_dashboard`) | **17/17 OK** (dashboard 4 + MM-09 13, incl. `test_secret_scan`) |
| Post-fix browser smoke (new, `evidence/fix_smoke/`) | **8/8 PASS** |

Browser smoke detail (`fix_smoke/smoke_driver.py` + `smoke.js`, real
headless Chromium via Playwright from the g4 tree; scratch DB
`g3_fix_smoke_scratch`, port 8779, server run with a **custom**
env-configured token `FACTORY_API_TOKEN=fix-smoke-op-token-7x` so the
smoke also proves no env value leaks; scratch DB dropped afterwards):

1. `token_field_empty_on_load` — `#token` value is `""` on load.
2. `token_field_has_placeholder` — placeholder "paste token" present.
3. `dom_has_no_dev_default` — live DOM contains no `dev-operator-token`.
4. `dom_has_no_env_token` — live DOM contains no env-configured token.
5. `auth_error_shown_before_token` — with the empty field, the page's
   authenticated loads fail visibly: "missing or wrong credentials"
   (the intended post-fix behavior: the operator must supply a token).
6. `health_badge_after_token` — after typing the token + Refresh:
   "health: ok · 192 ops · wf 1.0.0".
7. `error_cleared_after_token` — error banner empty after Refresh.
8. `production_created_via_ui` — a real mutation (Create Production)
   through the UI succeeds with the typed token; screenshot
   `fix_smoke/shots/fix_smoke_dashboard.png`.

Note: the MM-09 builder/verifier browser harnesses (as-run gate
evidence, left unmodified) relied on the pre-fill for their operator
sessions and would now need the operator token typed/filled — expected
consequence of the fix; both harnesses already fill `#token`
explicitly for their WORKER sessions.

## Scope statement

Changed: one attribute on one line of the G3 dashboard page, plus this
record and the `fix_smoke/` evidence. Not changed: `server.py`
(including its documented local-dev token default), README/docstrings,
fixtures, setup tooling, workflows, contracts, coordinator, worker or
evaluation services. D-MM09-V1 is resolved for the page-emission vector
it named; the broader pre-existing posture (a documented shared
local-dev default token, recorded since Gate A GA-10 as
NOT_IMPLEMENTED for production) is unchanged and remains an
owner/deployment decision, not something this fix silently re-scopes.
