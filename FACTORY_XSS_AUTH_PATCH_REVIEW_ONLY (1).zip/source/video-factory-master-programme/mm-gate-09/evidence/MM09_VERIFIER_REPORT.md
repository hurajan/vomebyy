# GATE MM-09 — INDEPENDENT VERIFIER REPORT

**Gate:** MM-09 (Dashboard + operator control)
**Verifier:** independent verifier agent (not the builder)
**Date:** 2026-10-29
**Verdict: PASS** — one MINOR pre-existing finding (D-MM09-V1), no MM-09-introduced defects.

## Method / environment discipline

Everything ran on the verifier's own stack, serially, with OBS-1 port
hygiene (leftover processes on 8730/8795/8796 killed by port before
each phase; suites run one at a time):

- Scratch DB `mm09_verify_scratch` (the builder used `g3_mm09_scratch`
  / `g3_mm09_browser`); API port 8771, evaluation service port 8772
  (builder used 8751/8752 and 8761/8762).
- Own role tokens (`verify09-*-SECRET-*`), own credential_ref
  (`VERIFY09_CREDREF_SECRET_91Q`), own provider names
  (`verify-cred-provider` / `verify-plain-provider`), and own figures
  throughout: spend cap **43210¢** (builder: 100000), settled charge
  **275¢** (builder: 300), unresolved estimate **130¢** (builder: 100),
  pricing **2.0¢/input-token** (builder: 1.0), UI resolve **63 tokens →
  126¢** (builder: 40 → 40¢), second-production resolve **21 tokens →
  42¢**, gate kind **HG3** (builder: HG2), production ceilings
  76543/65432.
- DSN assurance (OBS-1): `/health` does not echo the DSN, so sameness
  of database is proven by data equality — every API figure below was
  compared against raw SQL on `mm09_verify_scratch`, and the API
  returned exactly the rows seeded into that DB (health: 192 registry
  operations, workflow 1.0.0).
- Harness: `evidence/verify/verify_driver.py` +
  `evidence/verify/verify_browser.js`; machine-readable results in
  `evidence/verify/verify_results.json`; screenshots in
  `evidence/verify/shots/` (8 PNGs). 31 driver checks: 29 PASS as
  encoded; the 2 exceptions are analyzed under Items 3 — one is an
  assertion-encoding artifact (requirement met), one is the MINOR
  finding D-MM09-V1.

## Item 1 — Data truth: **PASS**

Seeded my own promotion candidate set, a production with a settled
charge (275¢) + one UNRESOLVED charge (130¢), PASS/FAIL/REVIEW_REQUIRED
evaluations, a PENDING HG3 gate on an AWAITING_HUMAN unit, a BLOCKED
unit, and a RETRY_WAIT unit.

- `GET /model-assignments`: 192 rows, **field-equal to SQL for all 192**
  (status / primary_model / fallback_model / null_reason — zero
  mismatches); 120 NONE rows, every one carrying its `null_reason`.
- `GET /model-policies`: 7 rows == SQL count. All 7 policies PROPOSED
  after seeding (promotion is the only activation path).
- **My own promotion** (HTTP, STATION_01): 200 → SQL status ACTIVE;
  `GET /model-policies/{id}/events` shows the PROMOTE event with actor
  `operator:operator`; the policies surface then shows that policy
  ACTIVE at its version.
- Finance: per-charge-class aggregates from
  `GET /productions/{pid}/financial-evidence` equal SQL `GROUP BY`
  sums exactly — ESTIMATED 605, FINALIZED 425, UNRESOLVED 130.
- Provider spend: `GET /provider-spend` row for `verify-cred-provider`
  = cap 43210, settled 42, held 130, total 172 — **identical to calling
  the coordinator's own `_provider_window_position` in-process on the
  same DB** (the enforcement computation), and identical to the
  hand-derived expectation (settled 42 = second production's resolved
  reservation; held 130 = the main production's unresolved claim).
- Evaluations: `GET /productions/{pid}/evaluations` returns exactly
  the 3 SQL rows as a (verdict, operation_id) set —
  (PASS, 01.03), (FAIL, 01.04), (REVIEW_REQUIRED, 01.05); the FAIL
  row's evidence carries `deterministic: true`; unknown production →
  404.
- `GET /evaluation-status`: reachable, `seed_cases` 7, `expert_cases`
  0, `armed` false — the golden-set card's data reads 7/0, arming OFF.
- `GET /benchmarks`: `[]`, and SQL `benchmark_results` count = 0.
- Gates/units surfaces show the seeded PENDING gate (bound to the
  AWAITING_HUMAN unit's artifact) and unit states AWAITING_HUMAN /
  BLOCKED / RETRY_WAIT exactly as seeded.

## Item 2 — Browser run (the gate's PASS criterion): **PASS**

Reproduced independently in a **real headless Chromium**
(Playwright 1.64.1 from the g4 tree + Chrome-for-Testing headless
shell) against the verifier's stack — not HTTP substitution.
**15/15 DOM assertions PASS**, 8 screenshots captured
(`evidence/verify/shots/v_*.png`). Per action:

- **Page load / Models tab:** health badge shows 192 ops; exactly 192
  assignment rows rendered; benchmarks card shows the explicit empty
  state. Screenshot `v_models.png`.
- **(a) Policy promote through the UI** (STATION_02 row's Promote
  button): row re-renders ACTIVE. SQL after: policy
  `policy-station-02-1.0.0` status ACTIVE, PROMOTE policy_event with
  actor `operator:operator`. `v_models_promoted.png`.
- **(b) Unresolved-charge resolve through the UI form** (Finance tab;
  the 130¢ charge listed before, filled Input tokens = 63, clicked
  Resolve): unresolved list empties in the DOM; finance summary then
  shows FINALIZED Σ **551 = 425 + 126** — the UI resolve visibly moved
  the totals by exactly the expected amount. SQL after: the claim's
  reservation **SETTLED at 126¢** (63 × 2.0¢ pricing). 
  `v_finance_before_resolve.png`, `v_finance_after_resolve.png`.
- **(c) Gate approve through the UI** (Approvals tab; pending HG3 gate
  listed; AWAITING_OWNER note visible; repair section lists the BLOCKED
  and RETRY_WAIT units): after clicking Approve, the queue shows "No
  pending gates". SQL after: gate verdict **APPROVED**,
  `decided_by = 'operator'`. `v_approvals.png`, `v_approvals_after.png`.
- **Quality tab:** golden card renders "7 SEED · 0 EXPERT", arming OFF;
  evaluation rows show the seeded verdicts. `v_quality.png`.
- **WORKER-role session:** switched the role selector to WORKER with
  the verifier's worker token, clicked Promote on the still-PROPOSED
  STATION_03 policy → the page renders **"model policy promotion is
  OPERATOR only"** in the error area. SQL after: exactly 1 committed
  `policy_action_refused` audit for that policy/action, and the policy
  is still PROPOSED. `v_worker_refusal.png`.

Every UI-driven change was confirmed in raw SQL, not just in the DOM.

## Item 3 — No new powers / no secrets: **PASS with MINOR finding D-MM09-V1**

- **Read-only surfaces:** POST/PUT/DELETE/PATCH against each of
  `/benchmarks`, `/provider-spend`, `/productions/{pid}/evaluations`,
  `/evaluation-status` (16 attempts, OPERATOR token): **all refused** —
  POST → 404 (no such route), PUT/DELETE/PATCH → 501
  (`server.py` implements only `do_GET`/`do_POST`; the verbs are
  rejected by the HTTP layer). A full state snapshot (policies,
  policy_events, financial_evidence, benchmark_results, human_gates,
  execution_units, ACTIVE assignments) was **identical before and
  after** — the attempts were no-ops. (My driver initially encoded
  "expect 404/405" and flagged the 501s; the requirement — refusal +
  no state change — is met. Recorded transparently rather than
  silently re-scored.)
- **Auth still enforced:** unauthenticated `GET /benchmarks` → 401.
- **Secret scan:** the served page plus 12 dashboard-consumed GET
  surfaces were scanned for the verifier's four role-token values,
  the operator token in use, and the seeded credential_ref string.
  **No role-token value and no credential_ref string appears
  anywhere.** One hit, recorded as a finding:
- **D-MM09-V1 (MINOR, pre-existing — not introduced by MM-09):** the
  served dashboard page pre-fills its token input with the local-dev
  default operator token (`dashboard/index.html` line 36:
  `<input id="token" value="dev-operator-token">`). Characterization:
  the string is the *public, documented* local-dev default (README,
  server docstring, contract auth notes all publish it), not a
  configured secret — when `FACTORY_API_TOKEN` is set, its value does
  **not** appear in the page (verified by construction: the file is
  static, and my scan with env-set role tokens found none of them).
  The token field itself predates MM-09 (part of the original
  dashboard; MM-09 added only the role selector beside it), and none
  of the four new endpoints emit the string. Residual risk: the page
  is served unauthenticated, so the pre-fill hands the *default*
  credential to anyone who can fetch the page — OPERATOR-equivalent
  against any server left running on the default. Recommendation
  (outside this gate's change surface): ship the token field empty
  and require `FACTORY_API_TOKEN` outside local dev. Does not block
  the MM-09 criterion.
- **Approvals limitation note:** present in the served page and
  rendered in the Approvals view (AWAITING_OWNER / named-approver gap
  wording), confirmed in HTML and in the browser DOM.
- **Benchmarks empty state:** rendered text is the explicit "No
  benchmark data recorded… empty by design…" message; the DOM block
  contains no score figures (asserted in the browser run); the API
  returns `[]` and the table holds 0 rows. No fabricated numbers.

## Item 4 — Resolved-charge filter (the builder's browser-caught defect): **PASS**

On the verifier's second production (own unresolved charge, est 90¢):

- Before: the financial-evidence surface shows exactly 1 pending
  UNRESOLVED row (`requires_reconciliation = true`) — the seeded one.
- HTTP resolve with 21 input tokens → 200, `amount_cents` 42, basis
  `calculated`.
- After: the pending set (UNRESOLVED ∧ requires_reconciliation) is
  **empty**; the UNRESOLVED history row **remains present** in both the
  API surface and SQL with `requires_reconciliation = false`; the
  reservation is SETTLED at 42¢.
- Independently re-proven in the browser on the main production: the
  Finance list emptied after the UI resolve while the history row
  remains in SQL with the flag flipped. The MM-09 view filter (keyed
  on `requires_reconciliation`) behaves correctly in both paths.

## Item 5 — Regression spot: **PASS**

Serial, ports killed between suites:

- **g3 suite: 54/54 OK** — and `tests.test_mm09_dashboard` run
  standalone: **13/13 OK** (the MM-09 module count matches).
- **Worker suite (gate-c): 85/85 OK.**
- **g9 suite: 10/10 OK**; persisted `g9_fullrun_scratch` read by SQL:
  the "G9 full run" production shows **18 ACCEPTED units, FINALIZED Σ
  1620¢, 0 UNRESOLVED rows** (0 UNRESOLVED in the whole DB).
- **Contract:** `contracts/api_contract.json` reports
  `contract_version` **1.11.0** with **51 endpoints**, and its auth
  notes describe the four MM-09 surfaces as READ-ONLY / READ_ROLES.

## Defects

| ID | Severity | Status |
|---|---|---|
| D-MM09-V1 | MINOR | Pre-existing dashboard token-field pre-fill with the documented local-dev default operator token (`dev-operator-token`). Not introduced or widened by MM-09; no configured/env token value or credential_ref is emitted by any surface. Recommend removing the pre-fill before any non-local deployment. |

No other defects at any severity. (Verifier-side note: the 501
responses in Item 3 were my assertion's blind spot, not product
behavior — the refusals and the unchanged state snapshot are the
substance, and both hold.)

## Verdict against the criterion

*"Browser-based workflow tests prove dashboard functions work end to
end"* — **PASS.** Independently reproduced in a real headless
Chromium against a self-seeded stack: every new view renders data
field-equal to SQL ground truth, and promote / resolve / gate-approve
performed through the actual UI forms land exactly the state changes
the direct API semantics predict (ACTIVE policy + operator PROMOTE
event; reservation SETTLED at the verifier's own 126¢ figure; gate
APPROVED by `operator`), with role refusals surfaced in the page and
audited in SQL. MM-09 introduces no new mutation surface, leaks no
configured secret, and leaves the regression anchors (g3 54, worker
85, g9 18/1620/0) intact.
