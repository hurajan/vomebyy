/* MM-09 real-browser run (Playwright + Chromium headless shell).
   Drives the actual dashboard UI against the scratch stack the Python
   driver started: view rendering, a policy promotion and a charge
   resolution through the real forms/buttons, a gate approval, and the
   WORKER-role refusal display. Prints a JSON assertion report; the
   driver cross-checks the resulting state in SQL.
   Env: MM09_BASE (dashboard URL), MM09_PID (seeded production id),
        MM09_POLICY_ROLE (role whose Promote button to click),
        MM09_WORKER_TOKEN, MM09_SHOTS (screenshot dir). */
const { chromium } = require("/home/hatch/workspace/video-factory-g4/node_modules/playwright");
const fs = require("fs");
const path = require("path");

const BASE = process.env.MM09_BASE;
const PID = process.env.MM09_PID;
const POLICY_ROLE = process.env.MM09_POLICY_ROLE || "STATION_06";
const WORKER_TOKEN = process.env.MM09_WORKER_TOKEN;
const SHOTS = process.env.MM09_SHOTS;
const SHELL = process.env.HOME +
  "/.cache/ms-playwright/chromium_headless_shell-1248/chrome-headless-shell-linux64/chrome-headless-shell";

const results = [];
function check(name, ok, detail) {
  results.push({ name, ok: !!ok, detail: String(detail || "") });
  console.log(`${ok ? "PASS" : "FAIL"} ${name} ${detail || ""}`);
}

(async () => {
  fs.mkdirSync(SHOTS, { recursive: true });
  const browser = await chromium.launch({ executablePath: SHELL, headless: true });
  const page = await browser.newPage({ viewport: { width: 1440, height: 1000 } });
  page.on("pageerror", e => check("no_pageerror", false, e.message));
  await page.goto(BASE + "/", { waitUntil: "load" });
  // sections render display:none until their tab is clicked, so data
  // waits use state:"attached" (visibility is asserted after tab clicks)
  await page.waitForSelector("#asgRows tr", { state: "attached", timeout: 20000 });
  await page.waitForFunction(
    () => document.querySelectorAll("#asgRows tr").length === 192,
null, { timeout: 20000 });
  check("health_badge_192", (await page.textContent("#healthBadge")).includes("192"),
        await page.textContent("#healthBadge"));
  check("assignments_rendered_192",
        (await page.locator("#asgRows tr").count()) === 192);
  const bench = await page.textContent("#benchWrap");
  check("benchmark_empty_state", bench.includes("No benchmark data recorded"), bench.slice(0, 60));

  // select the seeded production (drives every per-production view)
  await page.selectOption("#prodSel", PID);
  await page.waitForSelector("[id^='resIn-']", { state: "attached", timeout: 20000 });

  // ---- Models view + promote through the UI
  await page.click("button[data-view='models']");
  await page.waitForTimeout(400);
  await page.screenshot({ path: path.join(SHOTS, "models.png"), fullPage: true });
  const row = page.locator("#policyRows tr", { hasText: POLICY_ROLE });
  await row.getByRole("button", { name: "Promote" }).click();
  // wait for the re-rendered row itself to show ACTIVE (modelOut is set
  // before loadModels re-renders, so asserting on it alone races)
  await page.waitForFunction(
    (role) => [...document.querySelectorAll("#policyRows tr")]
      .some(tr => tr.textContent.includes(role) && tr.textContent.includes("ACTIVE")),
    POLICY_ROLE, { timeout: 20000 });
  const rowText = await page.locator("#policyRows tr", { hasText: POLICY_ROLE }).textContent();
  check("ui_promote_activates_policy", rowText.includes("ACTIVE"), rowText.slice(0, 80));
  await page.screenshot({ path: path.join(SHOTS, "models_promoted.png"), fullPage: true });

  // ---- Finance view + resolve through the UI form
  await page.click("button[data-view='finance']");
  await page.waitForSelector("[id^='resIn-']", { timeout: 20000 });
  await page.locator("[id^='resIn-']").first().fill("40");
  // viewport-only screenshot: a fullPage shot resizes the headless
  // viewport and the following click can land off-target (observed:
  // the click silently never fired the resolve request).
  await page.screenshot({ path: path.join(SHOTS, "finance_before_resolve.png") });
  const resolveBtn = page.getByRole("button", { name: "Resolve" }).first();
  await resolveBtn.scrollIntoViewIfNeeded();
  await resolveBtn.click();
  await page.waitForFunction(
    () => document.querySelector("#unresolvedWrap").textContent.includes("No unresolved charges"),
null, { timeout: 20000 });
  check("ui_resolve_clears_unresolved", true, "unresolved list emptied after UI resolve");
  const finSummary = await page.textContent("#finSummaryRows");
  check("finance_summary_shows_settled", finSummary.includes("Settled"), finSummary.slice(0, 60));
  await page.screenshot({ path: path.join(SHOTS, "finance_after_resolve.png"), fullPage: true });

  // ---- Approvals view + approve the pending gate through the UI
  await page.click("button[data-view='approvals']");
  await page.waitForFunction(
    () => document.querySelector("#apprUnitRows").textContent.includes("AWAITING_HUMAN"),
null, { timeout: 20000 });
  const apprText = await page.textContent("#view-approvals");
  check("approvals_identity_note", apprText.includes("AWAITING_OWNER"), "named-approver gap note visible");
  check("approvals_queue_row", apprText.includes("HG2"), "pending HG2 gate listed");
  await page.screenshot({ path: path.join(SHOTS, "approvals.png") });
  const approveBtn = page.locator("#apprGateRows").getByRole("button", { name: "Approve" });
  await approveBtn.scrollIntoViewIfNeeded();
  await approveBtn.click();
  await page.waitForFunction(
    () => document.querySelector("#apprGateRows").textContent.includes("No pending gates"),
null, { timeout: 20000 });
  check("ui_gate_approve", true, "pending gate decided through the UI");

  // ---- Quality view: golden-set card from the evaluation service
  await page.click("button[data-view='quality']");
  await page.waitForFunction(
    () => document.querySelector("#goldenCard").textContent.includes("SEED"),
null, { timeout: 20000 });
  const golden = await page.textContent("#goldenCard");
  check("golden_card_counts", golden.includes("7 SEED") && golden.includes("0 EXPERT"), golden.slice(0, 80));
  check("golden_card_arming_off", golden.includes("OFF"), "arming OFF pill");
  await page.screenshot({ path: path.join(SHOTS, "quality.png"), fullPage: true });

  // ---- WORKER session: the promote refusal is displayed, not hidden
  await page.fill("#token", WORKER_TOKEN);
  await page.selectOption("#roleSel", "WORKER");
  await page.waitForTimeout(2500); // refreshAll settles (some reads 403 by design)
  await page.click("button[data-view='models']");
  const wrow = page.locator("#policyRows tr", { hasText: "STATION_05" });
  const wpromote = wrow.getByRole("button", { name: "Promote" });
  await wpromote.scrollIntoViewIfNeeded();
  await wpromote.click();
  await page.waitForFunction(
    () => document.querySelector("#err").textContent.includes("OPERATOR only"),
null, { timeout: 20000 });
  check("worker_promote_refusal_surfaced", true, await page.textContent("#err"));
  await page.screenshot({ path: path.join(SHOTS, "worker_refusal.png"), fullPage: true });

  await browser.close();
  const failed = results.filter(r => !r.ok);
  console.log(JSON.stringify({ total: results.length, failed: failed.length, results }, null, 1));
  process.exit(failed.length ? 1 : 0);
})().catch(e => { console.error("BROWSER RUN ERROR:", e); process.exit(2); });
