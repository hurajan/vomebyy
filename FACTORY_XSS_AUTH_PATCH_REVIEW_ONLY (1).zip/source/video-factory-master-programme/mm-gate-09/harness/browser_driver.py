#!/usr/bin/env python3
"""MM-09 browser-run driver: builds the scratch stack (fresh DB, MM-03
registry seed, API server, Gate E evaluation service), seeds a production
with an UNRESOLVED charge + an AWAITING_HUMAN unit with a PENDING HG2
gate, runs harness/browser_run.js (Playwright + Chromium headless shell)
against the real dashboard UI, then cross-checks the UI-driven state
changes in raw SQL. Writes evidence/results/browser_run.json."""
import json
import os
import subprocess
import sys
import time
import urllib.request
from pathlib import Path

import psycopg
from psycopg.rows import dict_row

HOME = Path.home()
G2 = HOME / "workspace/video-factory-g2"
G3 = HOME / "workspace/video-factory-g3"
MM09 = HOME / "workspace/video-factory-master-programme/mm-gate-09"
SEEDER = (HOME / "workspace/video-factory-master-programme"
          / "mm-gate-03/tools/seed_registry.py")
EVAL_SERVICE = (HOME / "workspace/video-factory-real-ai-programme"
                / "gate-e/evaluation_service/service.py")
G2_PY = str(G2 / ".venv" / "bin" / "python")
DB, API_PORT, EVAL_PORT = "g3_mm09_browser", 8761, 8762
WORKER_TOKEN = "browser-worker-token"
CRED_REF = "BROWSER_CREDREF_STR"
sys.path.insert(0, str(G2 / "coordinator"))
from coordinator import Coordinator  # noqa: E402

DSN = f"host=127.0.0.1 dbname={DB} user=factory password=factory_dev_local"


def raw():
    return psycopg.connect(DSN, row_factory=dict_row, autocommit=True)


def wait_health(port, path="/health"):
    for _ in range(100):
        try:
            with urllib.request.urlopen(f"http://127.0.0.1:{port}{path}",
                                        timeout=2) as r:
                if r.status == 200:
                    return True
        except Exception:
            time.sleep(0.1)
    return False


def main():
    results = {"stack": {}, "sql_crosschecks": {}}
    r = subprocess.run(["python3", str(G3 / "tools/setup_db.py"), DB],
                       capture_output=True, text=True)
    assert r.returncode == 0, r.stderr
    r = subprocess.run([G2_PY, str(SEEDER), DB], capture_output=True,
                       text=True)
    assert r.returncode == 0, r.stderr
    results["stack"]["registry_seeded"] = json.loads(r.stdout)["counts"]

    # seed: production with an UNRESOLVED charge + AWAITING_HUMAN + gate
    c = Coordinator(DSN)
    with raw() as conn:
        conn.execute(
            "INSERT INTO provider_configs(scope, operation_id, environment,"
            " provider, model, est_cost_cents, credential_ref, created_by)"
            " VALUES ('OPERATION','01.02','test','cred-provider','m1',100,"
            " %s,'mm09-browser')", (CRED_REF,))
        conn.execute(
            "INSERT INTO pricing_rules(provider, model, unit_kind,"
            " unit_price_cents, pricing_version, created_by) VALUES"
            " ('cred-provider','m1','input_token',1.0,'mm09-browser',"
            " 'mm09-browser')")
    pid = c.create_production("MM-09 browser run", 100000, 90000, "mm09")
    run = c.start_run(pid, "FULL", "mm09")
    uid = c.plan_unit(pid, run, "01.02", "main")
    claim = c.claim(uid, "w-browser", 100)
    c.complete_attempt(uid, "w-browser", claim["fencing_token"],
                       "research_brief", b"content", "local://d", 100,
                       usage=None)
    uid_h = c.plan_unit(pid, run, "01.05", "main")
    claim_h = c.claim(uid_h, "w-browser", 50)
    art_h = c.complete_attempt(uid_h, "w-browser", claim_h["fencing_token"],
                               "research_brief", b"content", "local://d",
                               50, usage=None)
    c.close()
    results["stack"]["production_id"] = pid

    env = dict(os.environ, FACTORY_DSN=DSN, FACTORY_PORT=str(API_PORT),
               FACTORY_WORKER_TOKEN=WORKER_TOKEN,
               FACTORY_EVAL_URL=f"http://127.0.0.1:{EVAL_PORT}",
               FACTORY_STORAGE_ROOT="/tmp/g3-mm09-browser-storage")
    api = subprocess.Popen([str(G3 / ".venv" / "bin" / "python"),
                            str(G3 / "api/server.py")], env=env,
                           stdout=subprocess.DEVNULL,
                           stderr=subprocess.DEVNULL)
    eval_env = dict(os.environ, FACTORY_DSN=DSN,
                    FACTORY_EVAL_PORT=str(EVAL_PORT))
    ev = subprocess.Popen([G2_PY, str(EVAL_SERVICE)], env=eval_env,
                          stdout=subprocess.DEVNULL,
                          stderr=subprocess.DEVNULL)
    try:
        assert wait_health(API_PORT), "api did not come up"
        assert wait_health(EVAL_PORT), "eval service did not come up"
        # unit_h -> AWAITING_HUMAN via the API validate route, then a gate
        import urllib.error
        def call(method, path, body=None):
            req = urllib.request.Request(
                f"http://127.0.0.1:{API_PORT}{path}", method=method)
            req.add_header("X-Operator-Token", "dev-operator-token")
            data = None
            if body is not None:
                data = json.dumps(body).encode()
                req.add_header("Content-Type", "application/json")
            with urllib.request.urlopen(req, data=data, timeout=10) as resp:
                return resp.status, json.loads(resp.read() or b"{}")
        status, out = call("POST", f"/units/{uid_h}/validate",
                           {"verdict": "REVIEW_REQUIRED"})
        assert status == 200 and out["state"] == "AWAITING_HUMAN", out
        status, out = call("POST", f"/productions/{pid}/gates",
                           {"gate_kind": "HG2",
                            "artifact_id": art_h["artifact_id"]})
        assert status == 201, out
        gate_id = out["gate_id"]
        results["stack"]["gate_id"] = gate_id

        shots = MM09 / "evidence/results/browser"
        node_env = dict(os.environ, MM09_BASE=f"http://127.0.0.1:{API_PORT}",
                        MM09_PID=pid, MM09_POLICY_ROLE="STATION_06",
                        MM09_WORKER_TOKEN=WORKER_TOKEN,
                        MM09_SHOTS=str(shots))
        r = subprocess.run(["node", str(MM09 / "harness/browser_run.js")],
                           capture_output=True, text=True, env=node_env,
                           timeout=300)
        results["browser_stdout_tail"] = r.stdout[-3000:]
        results["browser_stderr_tail"] = r.stderr[-1000:]
        results["browser_rc"] = r.returncode
        # extract the JSON assertion report (last JSON block on stdout)
        start = r.stdout.rfind('{\n "total"')
        if start >= 0:
            results["browser"] = json.loads(r.stdout[start:])
        # SQL cross-checks of the UI-driven changes
        with raw() as conn:
            pol = conn.execute(
                "SELECT status FROM model_policies WHERE role='STATION_06'"
                " AND version='1.0.0'").fetchone()
            results["sql_crosschecks"]["station06_policy"] = pol["status"]
            ev_row = conn.execute(
                "SELECT action, actor FROM policy_events pe"
                " JOIN model_policies mp ON mp.policy_id=pe.policy_id"
                " WHERE mp.role='STATION_06' AND pe.action='PROMOTE'"
                " ORDER BY pe.at DESC LIMIT 1").fetchone()
            results["sql_crosschecks"]["promote_event"] = (
                dict(ev_row) if ev_row else None)
            res = conn.execute(
                "SELECT r.state, r.settled_cents FROM budget_reservations r"
                " JOIN action_attempts a ON a.reservation_id=r.reservation_id"
                " WHERE a.unit_id=%s", (uid,)).fetchone()
            results["sql_crosschecks"]["resolved_reservation"] = dict(res)
            gate = conn.execute(
                "SELECT verdict, decided_by FROM human_gates"
                " WHERE gate_id=%s", (gate_id,)).fetchone()
            results["sql_crosschecks"]["gate"] = dict(gate)
            refusal = conn.execute(
                "SELECT COUNT(*) AS n FROM audit_events"
                " WHERE event_type='policy_action_refused'"
                " AND payload->>'action'='promote'").fetchone()
            results["sql_crosschecks"]["worker_refusal_audits"] = refusal["n"]
        ok = (r.returncode == 0
              and results["sql_crosschecks"]["station06_policy"] == "ACTIVE"
              and results["sql_crosschecks"]["resolved_reservation"]
                  == {"state": "SETTLED", "settled_cents": 40}
              and results["sql_crosschecks"]["gate"]["verdict"] == "APPROVED"
              and results["sql_crosschecks"]["worker_refusal_audits"] >= 1)
        results["verdict"] = "PASS" if ok else "FAIL"
    finally:
        for p in (api, ev):
            p.terminate()
            try:
                p.wait(timeout=5)
            except subprocess.TimeoutExpired:
                p.kill()
    out_path = MM09 / "evidence/results/browser_run.json"
    out_path.write_text(json.dumps(results, indent=1, default=str))
    print(json.dumps({"verdict": results.get("verdict"),
                      "browser_rc": results.get("browser_rc"),
                      "sql": results.get("sql_crosschecks")}, default=str))
    return 0 if results.get("verdict") == "PASS" else 1


if __name__ == "__main__":
    sys.exit(main())
