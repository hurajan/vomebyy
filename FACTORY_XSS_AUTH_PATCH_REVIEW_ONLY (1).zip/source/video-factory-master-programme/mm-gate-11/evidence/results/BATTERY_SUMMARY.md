# MM-11 cold-restart recovery battery — summary (builder evidence)

DB: `mm11_scratch`, built by the recorded chain (5× station
setup_env.py → g3 setup_db.py mm11_scratch → API/worker/evaluation
respawn onto it → STATION bindings 1–6). Setup wall time 87.1 s
(logs/setup.log). G9 full run on it pre-restart: 1/1 OK in 64.2 s
(logs/g9_fullrun_pre_restart.log). Gate F runtime runner then started
against the same DB and cycled cleanly (scheduler/reaper/retry/
reconciler empty reports; dispatcher counted 18 pending dispatch
events as failed/cycle because FACTORY_DISPATCH_URL is unset — see
inventory F-03; no state mutated).

## (a) Pre-stop snapshot (snapshot_pre.json)
- Production 1560f3bc-e320-4033-86b4-30c1cc2cfe25 ("G9 full run")
- Units: **18 total, 18 ACCEPTED** (01.01, 01.12–16.12 chain as in G9)
- Artifacts: **18**, all CURRENT v1
- financial_evidence: ESTIMATED 18 rows totalling 1800¢ (100¢ each); **FINALIZED 18 rows totalling 1620¢ (90¢ each)**
- budget_transactions: RESERVE 18 rows totalling 1800¢; CHARGE 18 rows totalling 1620¢
- Amendment note (MM-11 verifier V-02, 2026-10-29): the totals above are sums over 18 rows, not per-unit amounts — wording corrected from the original "18 × …¢" phrasing.
- Human gates HG2/HG4/HG5 all APPROVED; human_approved events 18
- Gate D store hash check: **18 verified / 0 missing / 0 mismatch**

## (b) Full stop (logs/stop.log)
Runtime runner killed; `fuser -k` on 8730/8795/8796/5678;
`pg_ctlcluster 16 main stop` exit 0. Verified: cluster down, all five
ports (incl. 5432) closed, no factory processes remaining.

## (c) Cold start (harness/start_stack.py, logs/cold_start.log)
Dependency order, recorded spawn procedures only, **no DB-creation
step**: PostgreSQL → API (0.6 s to health) → worker (0.5 s) →
evaluation (0.5 s) → Gate F runner (alive) → n8n (12.1 s to /healthz).
Total 19.0 s (cold_start_timings.json). DB identity asserted via psql
before any API traffic (OBS-1). No workflow re-sync performed.

## (d) Post-restart readback (snapshot_post.json, readback_assert.json)
- SQL snapshot diff vs pre-stop: **IDENTICAL** (every field).
- API readback: 18 units all ACCEPTED; 18 artifacts; budget
  spent_cents **1620**, reserved 0.
- Store hashes re-verified in the post snapshot: 18/18.
- n8n: SQLite store readback **26 workflows / 26 active** with no
  re-sync (n8n_persistence.json; REST list probe anomaly = F-07).

## (e) Post-restart suites (serial, port hygiene between)
- g6 station suite (fresh setup_env + unittest): **3/3 OK**, 33.9 s
  (logs/g6_setup_post_restart.log, logs/g6_suite_post_restart.log)
- G9 suite (recorded setup_fullrun + full discover): **10/10 OK**,
  130.1 s (logs/g9_setup_post_restart.log, logs/g9_suite_post_restart.log)

## (f) Regression spot (deliverable 4)
- Worker service suite: **105/105 OK**, 90.6 s
  (logs/worker_suite_post_restart.log)
- Evaluation service suite: **57/57 OK**, 31.2 s
  (logs/evaluation_suite_post_restart.log)

## Verdict (builder)
Local cold-restart recovery: **PASS** — a completed production
survived a total stop (including PostgreSQL) and a procedure-only
cold start with byte-identical readback, and both post-restart suites
plus the regression spot are green. Deployment to OVHcloud:
**BLOCKED_EXTERNAL** (inventory §6, items i–vi; G0.6 standing block
untouched — no remote access was attempted).
