# MM-11 AMENDMENTS — verifier findings V-01..V-03 (amendment builder)

Date: 2026-10-29. Scope: documentation-only amendments responding to
`MM11_VERIFIER_REPORT.md` defects V-MM11-01 (V-01), V-MM11-02 (V-02)
and V-MM11-03 (V-03a–d). No product code changed. Files changed are
listed below and no others.

## 1. `DEPLOYMENT_INVENTORY.md` (§4, deployment friction list)

- **V-03a — F-11 added (§4, line 233):** "No host-level resource
  ceilings exist." States the factory has no cgroup/container limits
  and no per-service memory/CPU caps; the only ceilings are financial
  (budget/provider caps) and scheduler lane concurrency. Noted as a
  deployment-design input tied to F-01 (packaging), explicitly not
  to the §6 BLOCKED_EXTERNAL list — ceiling values belong with the
  hosting/packaging work.
- **V-03b — F-12 added (§4, line 244):** "No media-worker isolation
  exists." States the worker service imports `media_tools` and runs
  ffmpeg/flite in-process (verified in
  `gate-c/worker_service/actions.py`); no separate media-worker
  process or sandbox; media work shares the worker's process and
  failure domain; isolation would need a packaging change
  (owner/architecture item at deployment time, not a local defect).
- **V-03c — F-13 added (§4, line 255):** "No monitoring/alerting
  beyond health endpoints and the dashboard." Carries the §1.10
  absence as a numbered friction item and notes the Gate F
  reconciler + dashboard are the current operator surfaces.
- **V-03d — Revision pin added (§4, lines 264–278, immediately after
  F-13):** "Revision pin — what a deployment must reproduce and
  verify post-deploy." States the deployed revision is identified by
  the source-manifest aggregate (MM-00 method) + registry
  `definition_hash` + `plans_hash` + contract version, listing the
  current values: workflow 1.0.0, `definition_hash` ea4503f5…,
  `plans_hash` 9fa67675… (192 plans), contract 1.11.0 / 51 endpoints,
  migrations through 018.

## 2. `evidence/logs/n8n_persistence.log` (V-01)

- Annotation block appended at lines 8–22, headed
  "[VERIFIER ANNOTATION — MM-11 verifier V-01, 2026-10-29]" and
  closed "[END VERIFIER ANNOTATION]". It explains the log is a
  superseded probe whose "0 workflows" reading is contradicted by
  the SQLite ground truth (26/26, independently counted by the
  verifier; see `evidence/results/n8n_persistence.json` and
  MM11_VERIFIER_REPORT.md §2b/§3) and points to friction F-07.
  Original log content (lines 1–6) is unaltered; the annotation is
  append-only.
- Path note: the task brief cited this file under
  `evidence/results/`; the actual log on disk is
  `evidence/logs/n8n_persistence.log` (the `results/` directory holds
  `n8n_persistence.json`). The logs file — the one the verifier
  report names — was annotated.

## 3. `evidence/results/BATTERY_SUMMARY.md` (V-02)

- §(a), line 17: "ESTIMATED 18 × 1800¢; FINALIZED 18 × 1620¢"
  reworded to sum-over-rows form: "ESTIMATED 18 rows totalling
  1800¢ (100¢ each); FINALIZED 18 rows totalling 1620¢ (90¢ each)".
  Line 18 (budget_transactions RESERVE/CHARGE) reworded the same way
  for consistency ("18 rows totalling …").
- §(a), line 19: one-line amendment note added, attributed
  "(MM-11 verifier V-02, 2026-10-29)", stating the totals are sums
  over 18 rows, not per-unit amounts.

## Confirmation

Only the three files above plus this `AMENDMENTS.md` were written.
No product code, no other inventory/evidence/harness files, and no
files outside `mm-gate-11/` were changed by this amendment pass.
