# MM-11 VERIFIER REPORT — Gate MM-11 Deployment Readiness (independent)

Verifier, 2026-10-29. Read-only on product code; my only writes were this
report and a scratch restore DB (`mm11_verify_restore`, dropped after use).
All work serial, no suites re-run, no ports touched (OBS-1 honoured — the
restore was DB-only over the already-running PostgreSQL cluster).

## 1. DB dumps (new standing rule D-MM10-V1) — PASS

- All **10 dumps present** in `evidence/db_dumps/`: g4/g5/g6/g7/g8 station
  scratch, g9_fullrun_scratch, gatec_worker_scratch, gatee_eval_scratch,
  mm04_worker_scratch, mm11_scratch.
- **10 distinct SHA-256 hashes** (verified by direct `sha256sum`; no two
  dumps share a hash). mm11_scratch.sql =
  `b091bbd7176fa3de64381361c5368392617f0674ec8a605e8f64d808f5cb391c`.
- **Independent restore:** `mm11_scratch.sql` restored into my own DB
  `mm11_verify_restore` — clean load, **0 ERRORs**, 44 public tables.
  (Restore note: the dump files are mode 660 root:nogroup, so the postgres
  OS user cannot read them by path; I restored via stdin redirection. An
  operator restoring as `postgres` from another account would hit the same
  permission wall — worth knowing, not a defect against this gate.)
- **Readback from the restored dump** (same queries as harness/snapshot.py):
  - production `1560f3bc-e320-4033-86b4-30c1cc2cfe25` ("G9 full run") — the
    battery production, and the only production in the DB
  - **18 units, all ACCEPTED**; operation list identical to the snapshots
    (01.01, 01.12–13.12 chain, 14.01, 14.12, 15.12, 16.12)
  - **18 artifacts, all CURRENT v1**; artifact rows (type/version/sha/state)
    match `snapshot_post.json` exactly, row for row
  - financial_evidence: **ESTIMATED 18 rows, sum 1800¢; FINALIZED 18 rows,
    sum 1620¢**; budget_transactions RESERVE sum 1800¢ / CHARGE sum 1620¢
  - human gates **HG2/HG4/HG5 all APPROVED**; **18 human_approved events**
- Restore DB **dropped** afterwards (verified absent).
- The dumps are therefore loadable evidence, not just files. PASS.

## 2. Inventory accuracy spot-checks — PASS (with nuances noted)

- **(a) Migrations / contract — PASS.** `video-factory-g2/database/
  migrations/` runs 002–018, **max = 018_mm08_financial_controls.sql**
  (plus G1's 001). `video-factory-g3/contracts/api_contract.json` reports
  **contract_version 1.11.0 with exactly 51 endpoints**. Both as claimed.
- **(b) n8n SQLite workflow count — PASS.** Read-only query of
  `video-factory-g4/n8n-data/.n8n/database.sqlite` (mode=ro):
  **workflow_entity = 26, active = 26** (g4×6 + g5–g8×5, names as
  inventoried). Executions now 16,853 (inventory said 16,708 at inventory
  time — the count grows with the post-restart suites; consistent).
- **(c) Gate D store — PASS.** Today: **2,245 objects** in
  `.store/objects/` vs 2,202 claimed at inventory time — same order of
  magnitude, growth only (+43, consistent with post-restart suites writing
  new artifacts). Whole `.store` = 25 MB, matching the inventory's ~25 MB
  figure (that figure describes `.store` as a whole; the `objects/` files
  alone sum to ~4.2 MB of content — minor wording imprecision, see OBS-2).
  I also re-verified the battery production's 18 artifact hashes against
  this store today: **18 verified / 0 missing / 0 mismatch**.
- **(d) Redis — CONFIRMED (inventory claim holds).** Case-insensitive grep
  across all factory trees returns hits only for the substring in
  "**redis**patch" (`redispatch` in coordinator/driver/tests) and in
  docs/reports. A word-boundary search for `redis` in factory-authored
  source (excluding node_modules/.venv/n8n-data/.store/pycache) returns
  **zero**. Nuance: n8n's upstream `node_modules` bundles `@ioredis/
  commands` / ioredis references (n8n's optional queue-mode dependency,
  present in its package manifest) — it is bundled upstream code, never
  referenced or configured by any factory component; n8n runs
  single-process as inventoried. The claim "nothing in the local stack
  uses or requires Redis; no component references Redis" is accurate for
  this architecture.
- **(e) Packaging absence (F-01) — CONFIRMED.** `find` across all factory
  trees for Dockerfile*/docker-compose*/compose.y*ml/*.service (excluding
  node_modules/.venv) returns **nothing**. The only Dockerfiles on disk
  are inside `node_modules/isolated-vm/` (third-party dependency, not a
  factory artifact). F-01 stands exactly as recorded.

## 3. Restart evidence consistency — PASS (one log contradiction, V-01)

- `snapshot_pre.json` vs `snapshot_post.json`: **identical in every field**
  except `label` (verified by diff) — production id
  1560f3bc-e320-4033-86b4-30c1cc2cfe25, 18 ACCEPTED, FINALIZED/ESTIMATED
  totals, HG2/HG4/HG5 APPROVED, 18 human_approved, store check 18/0/0.
  `readback_assert.json` = `{diff: {}, api_units: 18, api_artifacts: 18}`,
  consistent.
- The **restored dump (§1) agrees with both snapshots on every figure** —
  production id, unit states/ops, artifact hashes, ESTIMATED sum 1800¢,
  FINALIZED sum 1620¢, gate verdicts. BATTERY_SUMMARY's before/after
  figures are therefore corroborated by an independently restored DB.
- `logs/stop.log`: pg stop exit 0, all five ports closed, no factory
  processes. `logs/cold_start.log` + `cold_start_timings.json` agree
  (API 0.6 s, worker 0.5 s, evaluation 0.5 s, n8n 12.1 s, total 19.0 s).
- **Post-restart suite logs exist with exactly the claimed counts, all OK:**
  g6 **3/3** (33.9 s), G9 **10/10** (130.1 s), worker **105/105** (90.6 s),
  evaluation **57/57** (31.2 s); pre-restart G9 full run 1/1 OK (64.2 s).
- Exception — **V-01 (MINOR):** `logs/n8n_persistence.log` records
  "workflows in n8n SQLite after cold restart (no re-sync): **0; active:
  0**" and REST 401s, directly contradicting `results/n8n_persistence.json`
  (26/26, "SQLite read-only query") and BATTERY_SUMMARY §(d). My own
  read-only SQLite count (§2b) confirms **26/26 is the true figure**, so
  the substance holds and F-07 covers the REST-probe anomaly — but the log
  file as preserved mislabels a failed/REST-based probe as a SQLite
  readback with a 0 count and is nowhere explained as superseded. An
  auditor reading the log alone would conclude n8n persistence failed.

## 4. BLOCKED_EXTERNAL completeness — PASS with MINOR gaps (V-03)

Mapping of the prompt's 16-item MM-11 checklist against the inventory
((a) verified locally by the restart battery / present-and-evidenced,
(b) in the friction list or explicitly recorded as absent, (c) in the
blocked-external list §6):

| Checklist item | Where accounted | Class |
|---|---|---|
| Trusted SSH identity | §6(ii), G0.6 standing block | (c) ✓ |
| Authorized access | §6(i)+(ii) | (c) ✓ |
| Revision | §5 only: source trees "pinned by Gate 00/MM-00 manifests (hashes)" — no revision identifier restated in the inventory proper | weak (b) — see V-03 |
| Container runtime | §1.10 "no container runtime artifacts" + **F-01** (deployment must first package) | (b) ✓ — friction, correctly not blocked-external: packaging is buildable work, not an owner input |
| n8n main+worker | §1.10: single-process mode, no queue/worker mode; queue mode = new architecture decision (owner) | (b) ✓ |
| PostgreSQL persistence | Battery §(a)–(d); §5 backup gaps | (a) ✓ |
| Redis health | §1.10: no Redis in this architecture, nothing requires it | (b) ✓ — N/A by design, explicitly stated; my grep (§2d) confirms |
| Coordinator API | §1.3; battery cold start + readback | (a) ✓ |
| Dashboard | §1.3 (served by API process, no separate server); exposure gated by §6(iii)/(v) + F-10; known token finding D-MM09-V1 noted | (b) ✓ inventoried — note: the battery's readback exercised SQL/API, not the dashboard page itself (OBS-1) |
| Media-worker isolation | **Not flagged.** §1.4 lists `media_tools.py` inside the worker service and §1.9 lists host ffmpeg — i.e. the inventory *describes* in-process media tooling (confirmed in code: `gate-c/worker_service/actions.py` imports `media_tools` and calls `mt.ffmpeg(...)` in-process) but never states that isolation is absent, and no F-item or §6 item carries it | **unaccounted as an explicit item — V-03** |
| Object storage | §1.7 local store (a); S3 stub-only, OD-A4 + §6(iv) | (a)+(c) ✓ |
| TLS | F-10 + §6(iii) | (b)+(c) ✓ |
| Backup + restore | §5 today-vs-needed in full; §6(iv) off-machine destination | (b)+(c) ✓ (and §1 of this report independently proves the local dump→restore leg) |
| Restart recovery | Battery §(a)–(f) | (a) ✓ |
| Health checks | §1.3–§1.6 per-service `/health(z)`, all asserted in the cold start | (a) ✓ |
| Resource ceilings | **Nowhere.** No mention of CPU/RAM/process limits anywhere in the inventory (grep: no "ceiling"/"resource" hits in this sense — the only ceilings in the system are production budget ceilings, a different thing) | **silently dropped — V-03** |
| Monitoring | §1.10 states "No monitoring/alerting stack; health surfaces are the per-service GET /health(z) endpoints only" — absence is recorded, but it is **not** carried as a numbered friction item nor as a blocked-external/deployment need | partial (b) — V-03 |

Nothing else on the checklist is unaccounted. The three gaps in V-03 are
inventory-completeness gaps, not evidence failures: none of them changes
the local PASS, and all three belong on the deployment work list the
inventory is meant to feed.

## Defects

- **V-MM11-01 — MINOR (evidence hygiene).** `logs/n8n_persistence.log`
  (0 workflows, labelled as a SQLite readback) contradicts
  `results/n8n_persistence.json` (26/26) and the true state (independently
  confirmed 26/26). The log should have been annotated or superseded in
  BATTERY_SUMMARY; F-07 explains the REST anomaly but not this log line.
- **V-MM11-02 — MINOR (summary wording).** BATTERY_SUMMARY §(a) writes
  "ESTIMATED 18 × 1800¢; FINALIZED 18 × 1620¢". Per the snapshots and the
  restored DB, 1800¢/1620¢ are the **sums over 18 rows** (100¢/90¢ per
  unit), not per-unit amounts. The totals reconcile everywhere (budget
  spent 1620¢, CHARGE sum 1620¢); only the "18 ×" phrasing misleads.
- **V-MM11-03 — MINOR (inventory completeness vs checklist).**
  (i) *Resource ceilings* are absent from the inventory entirely —
  silently dropped, neither friction nor blocked. (ii) *Media-worker
  isolation* is never flagged: media tooling runs in-process inside the
  worker service (verified in code), with no isolation statement, friction
  item, or deployment note. (iii) *Monitoring* is stated as absent in
  §1.10 but carried neither as a numbered friction item nor in §6, so it
  has no owner/work item on the deployment path. (iv) *Revision* is
  accounted only obliquely via §5's manifest-pinning sentence.
  Container runtime, by contrast, is properly placed: §1.10 + F-01.
- **OBS-1.** The cold-restart readback asserts state via SQL + API
  unit/artifact counts; the dashboard page itself was not fetched
  post-restart. Dashboard availability after restart is inferred (same
  process as the API), not evidenced.
- **OBS-2.** §1.7's "~25 MB" is the whole `.store` size; `objects/` content
  alone is ~4.2 MB (2,245 files today). Count claim verified; size label
  attaches to the parent directory.

No MAJOR or CRITICAL defects. No product code was modified.

## Verdict

- **Local readiness (inventory + cold-restart recovery evidence): PASS.**
  All 10 dumps present, distinct, and the battery dump independently
  restores to exactly the production the battery claims (18 ACCEPTED,
  FINALIZED total 1620¢, 18 artifacts, HG2/HG4/HG5 approved). Every
  inventory spot-check (migrations 018 max, contract 1.11.0/51, n8n
  26/26 in SQLite, Gate D store count/growth, no Redis, no packaging)
  confirmed independently. Restart before/after evidence is internally
  consistent and corroborated by the restored dump. Three MINOR defects
  (one contradictory log, one misleading phrase, checklist-coverage gaps
  for resource ceilings / media-worker isolation / monitoring carry-over)
  should be fixed in the inventory record but do not undermine the local
  evidence.
- **Deployment target state: BLOCKED_EXTERNAL** — as expected and as the
  builder recorded. §6 items (i)–(vi) are discrete and decidable, G0.6
  was honoured (no remote access attempted by builder or verifier), and
  no deployed PASS or production-readiness claim is supported until the
  owner clears them. This separation — local PASS, deployment
  BLOCKED_EXTERNAL — is stated correctly in both the inventory and
  BATTERY_SUMMARY and is upheld.
