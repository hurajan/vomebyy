# MM-11 DEPLOYMENT INVENTORY — the deployable unit as it exists locally

Compiled 2026-10-29 (builder, Gate MM-11) from the recorded setup chain
and live inspection. **Configuration surfaces list env-var NAMES only —
no values anywhere in this document.** The local stack is a single-host,
loopback-only development deployment; §5 records what a real deployment
still needs, and §6 is the BLOCKED_EXTERNAL record. Nothing in this gate
deployed anywhere: the OVHcloud target is blocked at G0.6 (see §6).

## 1. Component inventory

### 1.1 PostgreSQL 16 (system cluster `16/main`)
- Role: sole persistence + sole authority store (coordinator tables,
  registry, plans, financial ledger, model registry, outbox).
- Launch: `pg_ctlcluster 16 main start` (also the first step of every
  recorded setup script). Port **5432**, loopback.
- Persistent state: `/var/lib/postgresql/16/main` (system-managed);
  config `/etc/postgresql/16/main/postgresql.conf`.
- Schema construction chain (recorded, in order):
  1. G1 loader — `video-factory-g1/tools/registry_tool.py load <db>`:
     creates the DB, applies migration `001_g1_registry.sql`
     (g1/database/migrations/), loads the frozen registry seed
     (workflow 1.0.0, definition_hash ea4503f5…).
  2. G2 wrapper — `video-factory-g2/tools/setup_db.py <db>` applies
     migrations **002–018** from `video-factory-g2/database/migrations/`
     (002 coordinator … 015 execution plans, 016 model registry,
     017 provider-job cancel, **018 financial controls = max**), then
     `registry_tool.py load-plans <db>` (192 plans, hash-asserted), then
     seeds the FACTORY/test mock provider_configs compatibility row.
  3. G3 wrapper — `video-factory-g3/tools/setup_db.py <db>` is a thin
     re-entry of the G2 script under a caller-chosen DB name.
- Dependencies: none (root of the dependency order). Dev role name
  `factory` (scratch use on this VM only, per the G2 script header).

### 1.2 Coordinator library (no port — in-process)
- `video-factory-g2/coordinator/coordinator.py` (+ `model_registry.py`,
  `mock_provider.py`): the sole authority for state transitions,
  claims/fencing, budgets, gates. Imported by the API server and by the
  Gate F runtime services (`runtime_services/common.py` inserts this
  path). No independent launch; it lives/dies with its host process.

### 1.3 Coordinator API + dashboard (G3)
- Launch (recorded in every station `setup_env.py` and in
  `video-factory-g9/tools/setup_fullrun.py`): kill port 8730, spawn
  `video-factory-g3/.venv/bin/python video-factory-g3/api/server.py`
  with env (§3). Port **8730**, binds 127.0.0.1 only. Health:
  `GET /health` → `{status, registry_operations: 192, workflow_version}`.
- Contract: `video-factory-g3/contracts/api_contract.json`,
  contract_version **1.11.0 / 51 endpoints**.
- Dashboard: single static page `video-factory-g3/dashboard/index.html`
  served by the same process at `/` (no separate web server, no build
  step). Known pre-existing finding D-MM09-V1 was dispatched for fix
  before any non-local deployment (dashboard token field).
- Persistent state: none of its own — all state is in PostgreSQL.
- Dependencies: PostgreSQL (§1.1); evaluation service for the MM-09
  evaluation-status read (`FACTORY_EVAL_URL`).

### 1.4 Worker service (Gate C, Real-AI programme)
- `video-factory-real-ai-programme/gate-c/worker_service/service.py`
  (+ `actions.py`, `plan_exec.py`, `gateway.py` — the MM-04 provider
  gateway lives here — `media_tools.py`, `envelope.py`, `payloads.py`).
- Launch (recorded): spawn with the **g2 venv** python; env (§3).
  Port **8795** in the deployed-local topology (code default 8799 —
  always set explicitly). Health: `GET /health`.
- Persistent state: none (attempt/action records are posted to the
  coordinator API; artifact bytes go to the Gate D store, §1.7).
- Dependencies: PostgreSQL directly (plan-pin verification via
  `WORKER_DSN`), coordinator API (action records, worker role token),
  Gate D store, local media tooling (§1.8).

### 1.5 Evaluation service (Gate E)
- `video-factory-real-ai-programme/gate-e/evaluation_service/service.py`
  (+ layers/golden/schema engine; golden cases in-tree).
- Launch (recorded): spawn with the g2 venv python; env (§3). Port
  **8796** in the deployed-local topology (code default 8950 — always
  set explicitly). Health: `GET /health` → includes golden-set arming
  status (at inventory time: 7 SEED / 0 EXPERT, arming OFF).
- Persistent state: none of its own (verdicts submitted to the
  coordinator as VALIDATOR).
- Dependencies: PostgreSQL (`FACTORY_DSN`), coordinator API, Gate D
  store (artifact reads for evaluation).

### 1.6 Gate F runtime services (scheduler / dispatcher / reaper / retry / reconciler)
- `video-factory-real-ai-programme/gate-f/runtime_services/` —
  five stateless `run_once` services + thin multi-interval runner
  `runner.py` (intervals via `FACTORY_*_INTERVAL_S`, defaults
  5/2/10/5/15 s).
- Launch: `runner.py` with the g2 venv python, cwd = gate-f tree,
  `FACTORY_DSN` set; dispatcher additionally needs
  `FACTORY_DISPATCH_URL` (see friction F-03: no recorded launcher sets
  it, and there is **no recorded production launcher for the runner at
  all** — suites instantiate the services in-process; MM-10/MM-11 ran
  the runner as an ad-hoc spawn using its own module entry point).
- Persistent state: **none by design** — every fact is read from /
  written to coordinator tables; a restart resumes from those tables
  (Gate F restart-recovery test evidence).
- Dependencies: PostgreSQL (via the coordinator library, §1.2), n8n
  dispatch receiver (dispatcher POST target).

### 1.7 Gate D artifact store (content-addressed object store)
- Library: `video-factory-real-ai-programme/gate-d/storage_service/
  storage.py` — `LocalStorage` (default) or `S3Storage` (SigV4,
  stub-tested only; no real endpoint ever used).
- Persistent state (local backend): `storage_service/.store/objects/`
  — **2,202 objects / ~25 MB** at inventory time, named by SHA-256;
  candidate→promote two-phase writes. This directory is load-bearing:
  every production artifact's bytes live here and are read back by hash
  (the MM-11 battery hash-verified all 18 artifacts of its production
  from this store, pre- and post-restart).
- Config (§3): backend/root names; S3 names listed, never populated
  locally. Backend choice for deployment is OD-A4 (owner, §6-iv).
- Dependencies: filesystem (local) — in-process for worker/evaluation/
  executors; no port.

### 1.8 n8n (orchestrator) + station workflow trees
- One shared n8n **2.45.5** instance from `video-factory-g4/
  node_modules/.bin/n8n` (Node 24), port **5678**, binds 127.0.0.1.
- Launch (recorded in station `setup_env.py`): spawn `n8n start` with
  `N8N_USER_FOLDER=video-factory-g4/n8n-data` + env (§3: role tokens +
  service URLs — workflow JSON contains only `$env` expressions, zero
  literals), wait `/healthz`, REST-login as the local dev owner, then
  PATCH-or-create + activate each workflow file.
- Persistent state: `video-factory-g4/n8n-data/.n8n/database.sqlite`
  (+ WAL/SHM, event logs; whole folder ~432 MB) — holds all workflow
  definitions, activation state, credentials store, and execution
  history (16,708 executions at inventory time).
- Workflows: **26 JSON files** across five station trees —
  g4 (`video-factory-g4/workflows/`): station-01, station-02,
  unit-executor, call-worker, dispatch-receiver, error-handler (6);
  g5/g6/g7/g8: station-03/04/05/06 respectively + the same four shared
  files (5 each). Station→tree map: S1–S2 g4, S3 g5, S4 g6, S5 g7
  (incl. step 12 per Gate 03 Option B), S6 g8. Each tree also carries
  `driver/dispatch.py` (the harness-side dispatch driver) and
  `tools/setup_env.py`.
- MM-11 evidence: after a full stop/start with **no re-sync**, the
  SQLite store read back 26 workflows / 26 active (see friction F-07
  on the REST list probe).

### 1.9 Local media tooling (host binaries, MM-06)
- `ffmpeg`/`ffprobe` 8.1.2 (incl. libflite for local TTS, quality-
  labeled) at `/usr/bin`. No port, no state except per-run workdirs
  (see MM-06 finding D-1 on workdir cleanup). Video generation has NO
  local provider — external dependency, owner decision at MM-12.

### 1.10 Explicitly NOT present locally
- **No Redis** (named in the MM-11 prompt's checklist): nothing in the
  local stack uses or requires it — n8n runs in its default single-
  process mode (no queue/worker mode), and no component references
  Redis. A deployment that wants n8n queue mode would be a new
  architecture decision (owner).
- No container runtime artifacts: there are **no Dockerfiles, no
  Compose file, no systemd units, no reverse proxy/TLS terminator**
  anywhere in the factory trees. Every launch is a bare process spawn
  from a setup script (see §4/F-01).
- No monitoring/alerting stack; health surfaces are the per-service
  `GET /health(z)` endpoints only.

## 2. Dependency order (as exercised by the MM-11 cold start)

PostgreSQL → Coordinator API (8730) → Worker (8795) + Evaluation (8796)
→ Gate F runner → n8n (5678). Gate D store and media tooling are
filesystem/host dependencies of the worker/evaluation layers. The G9
setup chain additionally interleaves per-station `setup_env.py` runs
(each restarts API+worker+evaluation onto its own scratch DB and syncs
its workflows into the shared n8n) before a final respawn onto the
target DB.

## 3. Configuration surfaces (env-var NAMES only — values never recorded)

| Surface | Names |
|---|---|
| Coordinator API | `FACTORY_DSN`, `FACTORY_PORT`, `FACTORY_ENVIRONMENT`, `FACTORY_API_TOKEN` (legacy operator), `FACTORY_EVAL_URL`, `FACTORY_DISPATCH_URL` (runtime common) |
| Role tokens (API, n8n, services — secret class, vault-staged in any deployment) | `FACTORY_OPERATOR_TOKEN`, `FACTORY_WORKER_TOKEN`, `FACTORY_SCHEDULER_TOKEN`, `FACTORY_VALIDATOR_TOKEN`, `FACTORY_CALLBACK_TOKEN` |
| Worker service | `WORKER_SERVICE_PORT`, `WORKER_ENVIRONMENT`, `WORKER_DSN`, `WORKER_CREDENTIAL_REFS`, `FACTORY_API_URL`, `FACTORY_WORKER_TOKEN`, `OPENROUTER_API_KEY` (credential-ref name only; **absent locally**, MM-12) |
| Evaluation service | `FACTORY_DSN`, `FACTORY_API_URL`, `FACTORY_VALIDATOR_TOKEN`, `FACTORY_EVAL_PORT`, `FACTORY_STORAGE_*` (below) |
| Gate D storage | `FACTORY_STORAGE_BACKEND`, `FACTORY_STORAGE_ROOT`, `FACTORY_S3_ENDPOINT`, `FACTORY_S3_BUCKET`, `FACTORY_S3_ACCESS_KEY`, `FACTORY_S3_SECRET_KEY`, `FACTORY_S3_REGION` (last five: secret class, never populated locally) |
| Gate F runtime | `FACTORY_DSN`, `FACTORY_DISPATCH_URL`, `FACTORY_SCHEDULER_INTERVAL_S`, `FACTORY_DISPATCHER_INTERVAL_S`, `FACTORY_REAPER_INTERVAL_S`, `FACTORY_RETRY_INTERVAL_S`, `FACTORY_RECONCILER_INTERVAL_S` |
| n8n | `N8N_USER_FOLDER`, `N8N_PORT`, `N8N_LISTEN_ADDRESS`, `N8N_DIAGNOSTICS_ENABLED`, `N8N_TEMPLATES_ENABLED`, `N8N_BLOCK_ENV_ACCESS_IN_NODE`, plus the role-token and service-URL names above (`FACTORY_API_URL`, `FACTORY_WORKER_SERVICE_URL`, `FACTORY_EVALUATION_URL`) |
| Database construction | DB name is a CLI argument to the setup scripts; the local dev role name is `factory` (its credential exists only inside the recorded setup scripts for this VM's scratch use — not reproduced here) |
| Provider bindings (DB rows, not env) | `provider_configs` rows (scope FACTORY/STATION/OPERATION, environment, provider, model, est/max cents, params) + MM-03 model registry tables (migration 016) + pricing rules — data, promoted only via the recorded API/policy paths |

## 4. Deployment friction list (from the MM-11 battery — each item named)

- **F-01 No deployment packaging exists.** No Dockerfile/Compose/
  systemd unit/installer for any component; every launch is a spawn
  embedded in a test-oriented setup script. A deployment must first
  package: PG, API, worker, evaluation, runtime runner, n8n.
- **F-02 The recorded setup chain is destructive to existing state.**
  `setup_db.py` DROPs and recreates its target DB; every station
  `setup_env.py` and `setup_fullrun.py` re-run that chain per suite.
  There is **no recorded non-destructive restart procedure**: the
  MM-11 cold start had to re-use the *spawn fragments* of
  `setup_fullrun.py` while deliberately skipping its DB-creation step.
  A standalone `start_stack` procedure (start-only, no DB creation)
  does not exist and is needed before any deployment.
- **F-03 Gate F runner has no recorded launcher and an unset input.**
  No script starts `runner.py`; with `FACTORY_DISPATCH_URL` unset the
  dispatcher counts every pending dispatch outbox event as `failed`
  each cycle (observed live in MM-11: 18/cycle on a completed
  production — counted, not published; no state corruption, but noisy
  and indistinguishable from real failure in logs).
- **F-04 Port/DB coupling is by convention, with stale defaults.**
  Worker code default port 8799 vs deployed-local 8795; evaluation
  default 8950 vs 8796; API default DB is a scratch name. Every launch
  must set port+DSN explicitly, and OBS-1 stands: station setups reuse
  any answering API on 8730 — a deployment (and any battery) must
  assert the answering API's DB before sending traffic.
- **F-05 Shared-singleton topology.** One API, one worker, one
  evaluation service and one n8n serve all six stations, re-pointed
  per suite by killing by port (`fuser -k`). Nothing supervises or
  restarts a crashed process; there is no PID management anywhere.
- **F-06 n8n owner bootstrap is manual-in-script.** The dev owner is
  created/logged-in inside `setup_env.py` with local-only credentials
  embedded in the recorded scripts (not reproduced here); a deployment
  needs a real owner/SSO story and must rotate these.
- **F-07 n8n REST list probe inconsistency (observed MM-11).** After
  cold restart, `GET /rest/workflows` returned 0 rows in one probe and
  401 in a repeat, while the SQLite store and per-ID state agree:
  26 workflows / 26 active, and the post-restart g6+G9 suites executed
  through the webhooks green. Operator verification of n8n state
  should not rely on that list call alone until explained.
- **F-08 Persistent-state locations are inside source trees.**
  Gate D store under the programme tree, n8n data under the g4 tree,
  per-tree legacy `store/` dirs in g5–g8. A deployment must relocate
  state to managed volumes without breaking the recorded paths the
  code defaults to (`FACTORY_STORAGE_ROOT`, `N8N_USER_FOLDER` exist
  for exactly this; the defaults point into the trees).
- **F-09 Backup is manual and local-only** (see §5).
- **F-10 Loopback-only binding everywhere.** API and n8n bind
  127.0.0.1; there is no TLS, no auth beyond shared role tokens, and
  named-approver identity is an open owner decision (Gate 05). None
  of this may be exposed beyond a host without §6 items (iii)/(v).
- **F-11 No host-level resource ceilings exist (V-03a).** The factory
  today has **no** host-level resource ceilings: no cgroup or
  container limits, and no per-service memory or CPU caps on any
  component in §1. The only ceilings that exist are financial
  (production budget / provider caps enforced by the coordinator)
  and scheduler lane concurrency — neither bounds host CPU or
  memory. This becomes a deployment-design input when a
  container/packaging decision is made: the choice of ceiling
  values belongs with the hosting/packaging work under F-01, not
  with the §6 BLOCKED_EXTERNAL list (no owner input is needed to
  record the absence; the values are set when packaging is built).
- **F-12 No media-worker isolation exists (V-03b).** The worker
  service imports `media_tools` and runs `ffmpeg`/`flite`
  **in-process** (verified in
  `video-factory-real-ai-programme/gate-c/worker_service/actions.py`:
  `import media_tools`, in-process `mt.ffmpeg(...)` calls). There
  is no separate media-worker process and no sandbox today:
  CPU-heavy media work shares the worker service's process and
  failure domain, so a media-tool crash or resource spike is a
  worker-service crash or resource spike. Any deployment requiring
  media isolation needs a packaging change — an owner/architecture
  item at deployment time, not a local defect.
- **F-13 No monitoring/alerting beyond health endpoints and the
  dashboard (V-03c).** Monitoring/alerting beyond the per-service
  `GET /health` / `GET /healthz` endpoints and the dashboard does
  not exist: no metrics collection, no alerting, no log aggregation
  (§1.10). The Gate F reconciler loop and the dashboard are the
  current operator surfaces. A deployment must add monitoring/
  alerting as deployment work; until then, operator awareness is
  limited to those two surfaces plus direct log inspection.

**Revision pin (V-03d) — what a deployment must reproduce and
verify post-deploy.** The deployed revision is identified by the
combination of: (i) the source-manifest aggregate (MM-00 method,
Gate 00/MM-00 manifests), (ii) the registry `definition_hash`,
(iii) the `plans_hash`, and (iv) the API contract version. Current
values, which a deployment must reproduce exactly and verify
post-deploy before any traffic:

- workflow 1.0.0, registry `definition_hash` **ea4503f5…**
- `plans_hash` **9fa67675…** (192 plans)
- API contract **1.11.0 / 51 endpoints**
- migrations through **018** (max; G1 `001` + G2 `002–018`)

If any element differs post-deploy, the deployed revision is not
the revision this inventory describes.

## 5. Backup story — today vs. needed

**Exists today (all on this one VM, all manual):**
- PostgreSQL: `pg_dump` works against any factory DB
  (`sudo -u postgres pg_dump`); MM-11 dumped every scratch DB it
  created into `mm-gate-11/evidence/db_dumps/` per the D-MM10-V1
  standing rule. Gate 00's RESTORE.md documents baseline reproduction
  from source manifests + the setup chain.
- Gate D store: a plain directory of hash-named files — copyable
  as-is; integrity is self-verifying (filename = SHA-256 of content).
- n8n: the SQLite database file (+WAL) under `n8n-data/.n8n/` —
  copyable when n8n is stopped (WAL checkpointing is on the operator).
- Source trees: pinned by Gate 00/MM-00 manifests (hashes), not by any
  backup system.

**A deployment still needs (none exists):**
- An **off-machine backup destination** + schedule + retention +
  restore drill (owner item §6-iv). Today, a VM loss loses DB + store
  + n8n state together — exactly the D-MM10-V1 failure mode, mitigated
  only by the per-gate dump rule.
- WAL/PITR or equivalent for PostgreSQL (only full dumps exist).
- A consistent cross-component snapshot procedure (DB + store + n8n
  SQLite taken together, quiesced) — the three stores are only
  mutually consistent when the stack is stopped or productions are
  idle; no tooling encodes that today.
- Backup of configuration: provider_configs/model-registry rows live
  in the DB (covered by dumps); env/token staging lives nowhere
  (§6-v).

## 6. BLOCKED_EXTERNAL record — OVHcloud deployment prerequisites

MM-11's deployed-target PASS criteria are **BLOCKED_EXTERNAL**. The
local evidence (inventory + cold-restart battery, this gate's
`evidence/`) is preserved and complete; each item below is a discrete
owner-side decision/action. Nothing here was attempted by this gate.

- **(i) Factory hosting decision + order.** No hosting order exists
  for the AI Video Production Factory. The OVHcloud decision on
  record (OD-010: Vint Hill VA primary, Hillsboro OR replication,
  managed PostgreSQL + VPS layout, ≈$181/mo) was made for the
  **Storytelling Studio — a different workstream** — and does not
  authorize, size, or fund factory hosting. *Unblocks:* the existence
  of a target host at all. *Without it:* every item below has nowhere
  to land; deployment is undefined, not merely blocked.
- **(ii) SSH host identity confirmation (G0.6 — standing block).**
  The OVHcloud normal-boot SSH host identity has **never been
  confirmed** through the provider's out-of-band channel. Confirmation
  must come from the provider console/out-of-band record — **never by
  accepting an unverified key at a prompt**, and SSH verification must
  not be bypassed or weakened in any tooling. *Unblocks:* any remote
  access whatsoever. *Without it:* no login, no provisioning, no
  deployment, no remote verification — full stop.
- **(iii) DNS + TLS.** A hostname for the factory (API/dashboard/n8n)
  and a certificate path (issuer + renewal) on the target. *Unblocks:*
  any non-loopback access; the current loopback-only, token-only
  posture (F-10) is not exposable as-is. *Without it:* services could
  run on a host but could not be reached or used safely.
- **(iv) Off-machine backup destination (+ S3 credentials if the S3
  backend is chosen — OD-A4).** A destination outside the deployment
  host for DB dumps + Gate D store + n8n state, and — if the Gate D
  `S3Storage` backend is selected (stub-tested only today) — the
  bucket + access credentials for it, staged per (v). *Unblocks:*
  the backup/restore PASS criteria and any durability claim.
  *Without it:* deployment would repeat the single-VM loss mode
  (§5) on a more expensive host.
- **(v) Credential staging via the secure vault.** The service role
  tokens (§3, secret class), the DB role credential, the n8n owner
  credential (replacing the local dev owner, F-06), and any storage
  credentials must be provisioned through the secure vault flow —
  never via chat, never committed to a tree. (Provider credentials —
  e.g. OpenRouter — are **not** part of this item; they belong to
  MM-12 and its separate spend authorization.) *Unblocks:* starting
  any service on the target with real secrets. *Without it:* only
  the local dev token set exists, and shipping it off this VM would
  itself be a security defect.
- **(vi) Data-residency / legal constraints.** Any constraints Raj
  wants applied (regions, retention, provider data terms) must be
  stated before (i) is ordered, since they can invalidate a region or
  provider choice after the fact. *Unblocks:* a compliant (i)/(iv)
  decision. *Without it:* hosting and backup choices may need to be
  re-made.

**What remains possible without (i)–(vi):** everything local — the
full mock factory, all suites, and the cold-restart recovery evidence
in this gate. **What remains impossible:** any deployed service, any
restart/persistence claim about a remote host, TLS, off-machine
backup/restore, and therefore MM-11's deployed PASS and any
production-readiness claim that depends on it (MM-14).
