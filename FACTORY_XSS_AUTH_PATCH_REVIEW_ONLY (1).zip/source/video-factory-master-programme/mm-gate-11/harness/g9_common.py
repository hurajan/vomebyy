"""Shared helpers for the G9 harness (LOCK_G9; Gate G: the store-copy
bridge is gone — all artifact bytes live in the one Gate D content
store, read by sha, and step-exit contents are layered envelopes whose
deliverable is unwrapped here)."""
import hashlib
import importlib.util
import json
import time
import urllib.request
import urllib.error
from pathlib import Path

API = "http://127.0.0.1:8730"
TOKEN = "dev-operator-token"
HOME = Path.home() / "workspace"
STATION_TREES = {1: "video-factory-g4", 3: "video-factory-g5",
                 4: "video-factory-g6", 5: "video-factory-g7",
                 6: "video-factory-g8"}
GATE_D_STORE = (HOME / "video-factory-real-ai-programme/gate-d"
                / "storage_service/.store/objects")
DSN = "host=127.0.0.1 dbname=mm11_scratch user=factory password=factory_dev_local"


def load_driver(tree):
    path = HOME / tree / "driver" / "dispatch.py"
    spec = importlib.util.spec_from_file_location(f"driver_{tree}", path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


DRIVERS = {station: load_driver(tree) for station, tree in STATION_TREES.items()}


def call(method, path, body=None, expect=(200, 201)):
    req = urllib.request.Request(API + path, method=method)
    req.add_header("X-Operator-Token", TOKEN)
    data = None
    if body is not None:
        data = json.dumps(body).encode()
        req.add_header("Content-Type", "application/json")
    try:
        with urllib.request.urlopen(req, data=data, timeout=15) as r:
            out = json.loads(r.read() or b"{}")
            status = r.status
    except urllib.error.HTTPError as e:
        status, out = e.code, json.loads(e.read() or b"{}")
    assert status in expect, f"{method} {path} -> {status}: {out}"
    return out


def make_production(title, hard=1000000):
    p = call("POST", "/productions", {"title": title,
                                      "hard_ceiling_cents": hard,
                                      "soft_ceiling_cents": hard - 100000})
    pid = p["production_id"]
    run = call("POST", f"/productions/{pid}/runs", {"kind": "FULL"})["run_id"]
    return pid, run


def plan(pid, run, op, key="main", depends=(), inputs=()):
    return call("POST", f"/productions/{pid}/units",
                {"operation_id": op, "run_id": run, "unit_key": key,
                 "depends_on": list(depends),
                 "input_artifact_ids": list(inputs)})["unit_id"]


def unit_state(pid, unit_id):
    units = call("GET", f"/productions/{pid}/units")["units"]
    return [u for u in units if u["unit_id"] == unit_id][0]


def wait_state(pid, unit_id, target, timeout=180):
    deadline = time.time() + timeout
    last = None
    while time.time() < deadline:
        last = unit_state(pid, unit_id)
        if last["state"] == target:
            return last
        time.sleep(2)
    raise AssertionError(f"unit {unit_id} stuck at {last and last['state']}, "
                         f"wanted {target}")


def artifacts(pid):
    return call("GET", f"/productions/{pid}/artifacts")["artifacts"]


def current(pid, artifact_type):
    cur = [a for a in artifacts(pid)
           if a["artifact_type"] == artifact_type and a["state"] == "CURRENT"]
    assert cur, f"no CURRENT {artifact_type} in {pid}"
    return cur[0]


def content_of(art):
    """Artifact bytes from the Gate D content store by sha (hash
    verified); layered envelopes (OD-E1 iii) unwrap to the matching
    entry's deliverable content."""
    for name in (art["sha256"], art["sha256"] + ".json"):
        p = GATE_D_STORE / name
        if p.exists():
            raw = p.read_bytes()
            break
    else:
        raise AssertionError(
            f"Gate D store holds no content for {art['artifact_type']}")
    assert hashlib.sha256(raw).hexdigest() == art["sha256"]
    try:
        doc = json.loads(raw)
    except ValueError:
        return raw.decode()
    if isinstance(doc, dict) and "output_artifacts" in doc:
        for entry in doc["output_artifacts"]:
            if entry.get("artifact_type") == art["artifact_type"]:
                return entry.get("content")
    return doc


def drive(station, pid, unit_ids, inputs_by_unit=None, timeout=300):
    """Dispatch via the station's own driver until all units ACCEPTED."""
    driver = DRIVERS[station]
    deadline = time.time() + timeout
    while time.time() < deadline:
        driver.run_once(pid, inputs_by_unit=inputs_by_unit or {})
        if all(unit_state(pid, u)["state"] == "ACCEPTED" for u in unit_ids):
            return
        time.sleep(2)
    states = {u: unit_state(pid, u)["state"] for u in unit_ids}
    raise AssertionError(f"station {station} drive timed out: {states}")


def wait_gate(pid, kind, timeout=60):
    deadline = time.time() + timeout
    while time.time() < deadline:
        gates = [g for g in call("GET", f"/productions/{pid}/gates")["gates"]
                 if g["gate_kind"] == kind]
        if gates:
            return gates[0]
        time.sleep(2)
    raise AssertionError(f"no {kind} gate created for {pid}")


def approve(gate_id):
    call("POST", f"/gates/{gate_id}/decide",
         {"decision": "APPROVED", "decided_by": "operator"})
