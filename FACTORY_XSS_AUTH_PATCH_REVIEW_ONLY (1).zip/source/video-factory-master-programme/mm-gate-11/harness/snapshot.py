#!/usr/bin/env python3
"""Snapshot the latest 'G9 full run' production in mm11_scratch (SQL only
+ Gate D store hash spot-verification). Usage: snapshot.py <label>"""
import hashlib, json, sys
from pathlib import Path
import psycopg
from psycopg.rows import dict_row
DSN="host=127.0.0.1 dbname=mm11_scratch user=factory password=factory_dev_local"
STORE=Path.home()/"workspace/video-factory-real-ai-programme/gate-d/storage_service/.store/objects"
label=sys.argv[1]
outp=Path.home()/f"workspace/video-factory-master-programme/mm-gate-11/evidence/results/snapshot_{label}.json"
with psycopg.connect(DSN, row_factory=dict_row, autocommit=True) as c:
    pid=str(c.execute("SELECT production_id FROM productions WHERE title='G9 full run' ORDER BY created_at DESC LIMIT 1").fetchone()["production_id"])
    units=c.execute("SELECT state, count(*) n FROM execution_units WHERE production_id=%s GROUP BY 1 ORDER BY 1",(pid,)).fetchall()
    unit_ops=c.execute("SELECT operation_id, state FROM execution_units WHERE production_id=%s ORDER BY operation_id",(pid,)).fetchall()
    arts=c.execute("SELECT artifact_id, artifact_type, version, sha256, state FROM artifacts WHERE production_id=%s ORDER BY artifact_type, version",(pid,)).fetchall()
    fin=c.execute("SELECT charge_class, count(*) n, coalesce(sum(amount_cents),0) s FROM financial_evidence WHERE production_id=%s GROUP BY 1 ORDER BY 1",(pid,)).fetchall()
    bud=c.execute("SELECT kind, count(*) n, coalesce(sum(amount_cents),0) s FROM budget_transactions WHERE production_id=%s GROUP BY 1 ORDER BY 1",(pid,)).fetchall()
    gates=c.execute("SELECT gate_kind, verdict, count(*) n FROM human_gates WHERE production_id=%s GROUP BY 1,2 ORDER BY 1,2",(pid,)).fetchall()
    ha=c.execute("SELECT count(*) n FROM audit_events WHERE production_id=%s AND event_type='human_approved'",(pid,)).fetchone()["n"]
verified=missing=bad=0; checked=[]
for a in arts:
    p=STORE/a["sha256"]
    if not p.exists(): p=STORE/(a["sha256"]+".json")
    if not p.exists(): missing+=1; continue
    ok=hashlib.sha256(p.read_bytes()).hexdigest()==a["sha256"]
    if ok: verified+=1; checked.append(a["sha256"])
    else: bad+=1
snap={"label":label,"production_id":pid,"units_by_state":{r["state"]:r["n"] for r in units},
 "units_total":sum(r["n"] for r in units),"unit_ops":[[r["operation_id"],r["state"]] for r in unit_ops],
 "artifacts_total":len(arts),"artifacts":[[a["artifact_type"],a["version"],a["sha256"],a["state"]] for a in arts],
 "financial_evidence":[[r["charge_class"],r["n"],int(r["s"])] for r in fin],
 "budget_transactions":[[r["kind"],r["n"],int(r["s"])] for r in bud],
 "human_gates":[[r["gate_kind"],r["verdict"],r["n"]] for r in gates],
 "human_approved_events":ha,
 "store_hash_check":{"verified":verified,"missing":missing,"mismatch":bad}}
outp.parent.mkdir(parents=True, exist_ok=True)
outp.write_text(json.dumps(snap, indent=2))
print(json.dumps(snap, indent=2))
