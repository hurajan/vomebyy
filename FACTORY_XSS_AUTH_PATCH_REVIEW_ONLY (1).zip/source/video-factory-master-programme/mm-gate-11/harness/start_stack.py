#!/usr/bin/env python3
"""Cold-start the mm11 stack in dependency order using ONLY the launch
procedures recorded in the setup scripts (setup_fullrun.py tail +
station setup_env.py n8n spawn), WITHOUT any DB-creation step:
  1 PostgreSQL (pg_ctlcluster start, done by caller / here idempotent)
  2 Coordinator API :8730 on EXISTING mm11_scratch
  3 Worker service :8795 + Evaluation service :8796 on same DSN
  4 Gate F runtime runner (runner.py, FACTORY_DSN=mm11_scratch)
  5 n8n :5678 from the G4 tree (workflows persist in its SQLite store;
     NO workflow re-sync is performed — persistence is part of the test)
Asserts each health surface before proceeding to the next layer."""
import json, os, subprocess, sys, time, urllib.request, urllib.error
from pathlib import Path
HOME=Path.home()/"workspace"; PROG=HOME/"video-factory-real-ai-programme"
DB="mm11_scratch"; DSN=f"host=127.0.0.1 dbname={DB} user=factory password=factory_dev_local"
API="http://127.0.0.1:8730"
TOKENS={"FACTORY_OPERATOR_TOKEN":"dev-operator-token","FACTORY_WORKER_TOKEN":"dev-worker-token","FACTORY_SCHEDULER_TOKEN":"dev-scheduler-token","FACTORY_VALIDATOR_TOKEN":"dev-validator-token","FACTORY_CALLBACK_TOKEN":"dev-callback-token"}
N8N_TOKENS={"FACTORY_API_TOKEN":"dev-operator-token","FACTORY_WORKER_TOKEN":"dev-worker-token","FACTORY_SCHEDULER_TOKEN":"dev-scheduler-token","FACTORY_VALIDATOR_TOKEN":"dev-validator-token","FACTORY_CALLBACK_TOKEN":"dev-callback-token"}
SERVICE_URLS={"FACTORY_API_URL":API,"FACTORY_WORKER_SERVICE_URL":"http://127.0.0.1:8795","FACTORY_EVALUATION_URL":"http://127.0.0.1:8796"}
timings={}
def up(url):
    try:
        with urllib.request.urlopen(url, timeout=3) as r: return r.status==200
    except Exception: return False
def wait(url, label, timeout=90):
    t0=time.time()
    for _ in range(timeout*2):
        if up(url): timings[label]=round(time.time()-t0,1); print(f"{label}: up in {timings[label]}s", flush=True); return
        time.sleep(0.5)
    raise SystemExit(f"{label} did not come up")
def spawn(cmd, env, log):
    e={"PATH":"/usr/bin:/bin:/usr/local/bin:/usr/local/sbin:/usr/sbin:/sbin","HOME":str(Path.home()),"USER":"root"}; e.update(env)
    return subprocess.Popen(cmd, env=e, stdout=open(log,"wb"), stderr=subprocess.STDOUT, start_new_session=True)
def main():
    t_all=time.time()
    subprocess.run(["pg_ctlcluster","16","main","start"], capture_output=True)
    # assert the API's DB identity via psql before any traffic (OBS-1)
    r=subprocess.run(["sudo","-u","postgres","psql","-At","-d",DB,"-c","SELECT current_database()"], capture_output=True, text=True)
    assert r.stdout.strip()==DB, r.stdout+r.stderr
    print(f"postgres: up, {DB} present", flush=True)
    spawn([str(HOME/"video-factory-g3/.venv/bin/python"), str(HOME/"video-factory-g3/api/server.py")], {"FACTORY_DSN":DSN,"FACTORY_PORT":"8730",**TOKENS}, "/tmp/mm11-restart-api.log")
    wait(API+"/health","api")
    venv_py=str(HOME/"video-factory-g2/.venv/bin/python")
    spawn([venv_py, str(PROG/"gate-c/worker_service/service.py")], {"WORKER_SERVICE_PORT":"8795","WORKER_ENVIRONMENT":"test","WORKER_DSN":DSN,"FACTORY_API_URL":API,"FACTORY_WORKER_TOKEN":TOKENS["FACTORY_WORKER_TOKEN"]}, "/tmp/mm11-restart-worker.log")
    wait("http://127.0.0.1:8795/health","worker")
    spawn([venv_py, str(PROG/"gate-e/evaluation_service/service.py")], {"FACTORY_DSN":DSN,"FACTORY_API_URL":API,"FACTORY_VALIDATOR_TOKEN":TOKENS["FACTORY_VALIDATOR_TOKEN"],"FACTORY_EVAL_PORT":"8796"}, "/tmp/mm11-restart-eval.log")
    wait("http://127.0.0.1:8796/health","evaluation")
    # Gate F runtime runner: cwd must be gate-f so runtime_services imports
    rp=spawn([venv_py, str(PROG/"gate-f/runtime_services/runner.py")], {"FACTORY_DSN":DSN}, "/tmp/mm11-restart-runtime.log")
    (Path("/tmp/mm11-runtime.pid")).write_text(str(rp.pid))
    time.sleep(3); assert rp.poll() is None, "runtime runner exited immediately"
    print(f"runtime runner: alive pid={rp.pid}", flush=True)
    G4T=HOME/"video-factory-g4"
    spawn([str(G4T/"node_modules/.bin/n8n"),"start"], {"N8N_USER_FOLDER":str(G4T/"n8n-data"),"N8N_PORT":"5678","N8N_LISTEN_ADDRESS":"127.0.0.1","N8N_DIAGNOSTICS_ENABLED":"false","N8N_TEMPLATES_ENABLED":"false","N8N_BLOCK_ENV_ACCESS_IN_NODE":"false",**N8N_TOKENS,**SERVICE_URLS}, "/tmp/mm11-restart-n8n.log")
    wait("http://127.0.0.1:5678/healthz","n8n", timeout=90)
    timings["total"]=round(time.time()-t_all,1)
    print(json.dumps({"cold_start_timings_s":timings}), flush=True)
    (HOME/"video-factory-master-programme/mm-gate-11/evidence/results/cold_start_timings.json").write_text(json.dumps(timings, indent=2))
if __name__=="__main__": main()
