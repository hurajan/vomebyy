#!/usr/bin/env python3
"""MM-11 setup: the recorded G9 setup chain (setup_fullrun.py) with the
battery DB name mm11_scratch substituted. Steps mirror setup_fullrun.py
exactly: five tree setup_env.py runs, g3 setup_db.py <db>, API + worker +
evaluation respawn onto the battery DB, STATION bindings 1-6 seeded."""
import json, subprocess, sys, time, urllib.request
from pathlib import Path
HOME = Path.home() / "workspace"
PROG = HOME / "video-factory-real-ai-programme"
TREES = ["video-factory-g4","video-factory-g5","video-factory-g6","video-factory-g7","video-factory-g8"]
DB = "mm11_scratch"
DSN = f"host=127.0.0.1 dbname={DB} user=factory password=factory_dev_local"
API = "http://127.0.0.1:8730"
TOKENS = {"FACTORY_OPERATOR_TOKEN":"dev-operator-token","FACTORY_WORKER_TOKEN":"dev-worker-token","FACTORY_SCHEDULER_TOKEN":"dev-scheduler-token","FACTORY_VALIDATOR_TOKEN":"dev-validator-token","FACTORY_CALLBACK_TOKEN":"dev-callback-token"}
def run(cmd):
    print("+", " ".join(str(c) for c in cmd), flush=True)
    subprocess.run(cmd, check=True)
def up(url):
    try:
        with urllib.request.urlopen(url, timeout=3) as r: return r.status==200
    except Exception: return False
def wait_up(url, timeout=60):
    for _ in range(timeout):
        if up(url): return
        time.sleep(1)
    raise SystemExit(f"{url} did not come up")
def api_call(method, path, body=None):
    req = urllib.request.Request(API+path, method=method)
    req.add_header("X-Operator-Token", TOKENS["FACTORY_OPERATOR_TOKEN"])
    data=None
    if body is not None:
        data=json.dumps(body).encode(); req.add_header("Content-Type","application/json")
    with urllib.request.urlopen(req, data=data, timeout=15) as r: return json.loads(r.read() or b"{}")
def main():
    t0=time.time()
    subprocess.run(["pg_ctlcluster","16","main","start"], capture_output=True)
    for tree in TREES:
        run([sys.executable, str(HOME/tree/"tools"/"setup_env.py")])
    run([sys.executable, str(HOME/"video-factory-g3/tools/setup_db.py"), DB])
    subprocess.run(["fuser","-k","8730/tcp"], capture_output=True); time.sleep(1)
    env={"FACTORY_DSN":DSN,"FACTORY_PORT":"8730","PATH":"/usr/bin:/bin:/usr/local/bin","HOME":str(Path.home()),"USER":"root",**TOKENS}
    subprocess.Popen([str(HOME/"video-factory-g3/.venv/bin/python"), str(HOME/"video-factory-g3/api/server.py")], stdout=open("/tmp/mm11-api.log","wb"), stderr=subprocess.STDOUT, start_new_session=True, env=env)
    wait_up(API+"/health"); print("api: up (mm11_scratch)", flush=True)
    venv_py=str(HOME/"video-factory-g2/.venv/bin/python")
    for port in (8795,8796): subprocess.run(["fuser","-k",f"{port}/tcp"], capture_output=True)
    time.sleep(1)
    wenv={"WORKER_SERVICE_PORT":"8795","WORKER_ENVIRONMENT":"test","PATH":"/usr/bin:/bin:/usr/local/bin","HOME":str(Path.home()),"WORKER_DSN":DSN,"FACTORY_API_URL":API,"FACTORY_WORKER_TOKEN":TOKENS["FACTORY_WORKER_TOKEN"]}
    subprocess.Popen([venv_py, str(PROG/"gate-c/worker_service/service.py")], stdout=open("/tmp/mm11-worker.log","wb"), stderr=subprocess.STDOUT, start_new_session=True, env=wenv)
    eenv={"FACTORY_DSN":DSN,"FACTORY_API_URL":API,"FACTORY_VALIDATOR_TOKEN":TOKENS["FACTORY_VALIDATOR_TOKEN"],"FACTORY_EVAL_PORT":"8796","PATH":"/usr/bin:/bin:/usr/local/bin","HOME":str(Path.home())}
    subprocess.Popen([venv_py, str(PROG/"gate-e/evaluation_service/service.py")], stdout=open("/tmp/mm11-eval.log","wb"), stderr=subprocess.STDOUT, start_new_session=True, env=eenv)
    wait_up("http://127.0.0.1:8795/health"); wait_up("http://127.0.0.1:8796/health")
    print("worker+evaluation: up on mm11_scratch", flush=True)
    seeded=[]
    for station in (1,2,3,4,5,6):
        out=api_call("POST","/configs",{"scope":"STATION","station":station,"environment":"test","provider":"deterministic-local","est_cost_cents":100,"params":{"reported_actual_cents":90}})
        seeded.append((station,out["version"]))
    print(f"bindings seeded: {seeded}", flush=True)
    for tree in TREES:
        (HOME/tree/"driver"/"dispatch-state.json").unlink(missing_ok=True)
    print(f"MM11 environment ready in {time.time()-t0:.1f}s", flush=True)
if __name__=="__main__": main()
