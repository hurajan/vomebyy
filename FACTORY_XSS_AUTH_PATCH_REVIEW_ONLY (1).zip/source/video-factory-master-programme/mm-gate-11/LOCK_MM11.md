# LOCK — GATE MM-11: Deployment Readiness (Multi-Model programme)

Builder lock, taken 2026-10-29 before any battery work. Authority:
MULTI_MODEL_EXECUTION_PROMPT.md Gate MM-11 + the controller's MM-11
builder brief (deliverables 1–4). No STATE.md / MEMORY.md edits; no gate
report (controller writes it).

## Starting state (measured at lock time)

- PostgreSQL 16/main online on 127.0.0.1:5432; NO factory service running
  (no API 8730, worker 8795, evaluation 8796, runtime, or n8n 5678 listener).
- Existing DBs include g9_fullrun_scratch (stale, 11 productions from prior
  batteries) and per-station scratch DBs — none is treated as evidence for
  this gate; the battery builds its own coherent stack via the recorded
  setup chain.
- Migrations: G1 001 + G2 tree 002–018 (018 = max, MM-08). Registry
  workflow 1.0.0, definition_hash ea4503f5… (standing anchor).
- n8n: single shared instance from the G4 tree, SQLite store at
  video-factory-g4/n8n-data/ (~432 MB incl. logs/WAL), 26 workflow JSON
  files across the five station trees (g4:6, g5–g8:5 each).
- Gate D store: video-factory-real-ai-programme/gate-d/storage_service/
  .store/objects — 2,202 objects at lock time.

## Standing blocks honoured (non-negotiable)

- **G0.6: the OVHcloud normal-boot SSH host identity has NEVER been
  confirmed.** Nothing in this gate connects to, probes, or deploys to any
  remote host; SSH verification is never bypassed or weakened; nothing
  deploys. The OVHcloud target is recorded BLOCKED_EXTERNAL.
- No provider credential is requested or used (MM-12 territory); no paid
  call; no secrets printed — inventory lists env-var NAMES only.
- Environment exclusively this builder's for the battery duration;
  SERIALLY only, with port hygiene per OBS-1 (MM-07): before any suite,
  kill by port (8730/8795/8796/5678), assert the answering API's DB/DSN
  is the intended one before sending test traffic.

## Scope (exactly the brief)

1. DEPLOYMENT_INVENTORY.md — complete local deployable unit: every
   component with launch procedure (pointing at recorded setup scripts),
   ports, persistent state, config surfaces (names only), dependencies,
   today's backup story vs. what deployment still needs.
2. Cold-restart recovery battery on a scratch DB (mm11_scratch, built by
   the recorded G9 setup chain re-pointed at that DB name — the chain's
   scripts are used, the DB name is the battery's): G9 full run to a
   completed production → snapshot → stop EVERYTHING incl. PostgreSQL
   (pg_ctlcluster) → cold-start in dependency order using only the
   launch procedures recorded in the setup scripts (API/worker/eval/n8n
   spawns as written there, WITHOUT re-running the DB-creation step,
   which would destroy the production — that gap is itself a friction
   item) → assert identical readback → fresh g6 suite + G9 suite green.
3. BLOCKED_EXTERNAL record as final inventory section: items (i)–(vi)
   from the brief, each decidable, with what it unblocks.
4. Regression spot after restart: worker + evaluation suites, counts
   from logs.
5. Standing rule (D-MM10-V1): every scratch DB created is dumped with
   `sudo -u postgres pg_dump` into mm-gate-11/evidence/db_dumps/ at end.

## Out of scope

Any remote access/deployment, any product-code change (friction is
recorded, not fixed), any new migration, dashboard/token fixes, and the
MM-12 credential request.
