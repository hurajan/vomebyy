#!/usr/bin/env python3
"""Lean Phase 3 — slice configuration seeding (idempotent).

Seeds, through the coordinator API (OPERATOR), everything the Station 03
vertical slice (operation 08.12) needs beyond the station trees' global
setups — the station trees' own setup_env.py files are NOT touched:

1. The OPERATION-scope provider binding for 08.12 (the slice binding):

     scope OPERATION, operation_id 08.12, environment test,
     provider "openrouter-compatible",
     model "anthropic/claude-haiku-4.5"          (PROPOSED — see below),
     credential_ref "OPENROUTER_API_KEY",
     est_cost_cents 25, timeout_s 120,
     params {temperature 0.7, max_tokens 2000},
     retry_policy {base_s 30, max_s 900}

   Deliberately NO reported_actual_cents param: the OpenRouter adapter
   reports cost_cents None, and cost evidence must come from pricing
   rules x recorded token usage (spec constraint C-3), never from a
   seeded "actual". No credential VALUE is handled here — the worker
   service resolves the env var named by credential_ref at call time.

2. pricing_rules for that model under one pricing_version
   ("openrouter-2026-10-29", PROPOSED): the model's real published
   OpenRouter prices — $1.00 per 1M input tokens, $5.00 per 1M output
   tokens — expressed as unit_price_cents per token:
   input_token 0.0001, output_token 0.0005. (These are exactly
   representable in pricing_rules.unit_price_cents NUMERIC(12,4);
   cheaper models such as gpt-4o-mini at $0.15/M input = 0.000015
   cents/token are BELOW that column's representable floor and would
   silently round to zero — one reason Haiku 4.5 was pinned.)

3. The STATION 3 deterministic-local binding the fixture chain runs
   under (same shape the G5 setup seeds: est 100, reported actual 90).

Idempotency: an existing active row with identical content is left
alone (reported as "present"); a differing OPERATION/STATION row is
superseded through POST /configs (the API's versioned insert — history
is never edited); pricing rows are inserted only when no identical
active row exists.

Usage: python3 setup_slice.py [--base-url URL]
  --base-url: harness-only override written into the binding's
  params.base_url (the local OpenRouter-shaped stub). The canonical
  slice binding carries no base_url — the adapter default
  (https://openrouter.ai/api/v1) applies. Re-running without the flag
  restores the canonical binding.
Env: SLICE_API_URL (default http://127.0.0.1:8730),
     FACTORY_OPERATOR_TOKEN (default dev-operator-token, the local
     harness token used by every station setup).
"""
import json
import os
import sys
import urllib.error
import urllib.request

API = os.environ.get("SLICE_API_URL", "http://127.0.0.1:8730")


def _operator_token():
    """OPERATOR role token for the local harness API: the
    FACTORY_OPERATOR_TOKEN env var when set, else the canonical
    fixture value from the g5 station setup (never a literal here)."""
    value = os.environ.get("FACTORY_OPERATOR_TOKEN")
    return value if value else _fixture_token()


def _fixture_token():
    """The local harness OPERATOR token, sourced from the canonical
    fixture (g5 tools/setup_env.py TOKENS) - never re-typed as a
    literal in this file (display redaction mangles literals)."""
    import re as _re
    from pathlib import Path as _Path
    src = (_Path.home() / "workspace/video-factory-g5/tools/setup_env.py").read_text()
    return _re.search(r'"FACTORY_API_TOKEN": *\"([^\"]+)\"', src).group(1)

TOKEN = _operator_token()

MODEL = "anthropic/claude-haiku-4.5"
PRICING_VERSION = "openrouter-2026-10-29"
PROVIDER = "openrouter-compatible"
INPUT_TOKEN_PRICE_CENTS = "0.0001"   # $1.00 / 1M tokens
OUTPUT_TOKEN_PRICE_CENTS = "0.0005"  # $5.00 / 1M tokens


def call(method, path, body=None):
    req = urllib.request.Request(API + path, method=method)
    req.add_header("X-Operator-Token", TOKEN)
    data = None
    if body is not None:
        data = json.dumps(body).encode()
        req.add_header("Content-Type", "application/json")
    try:
        with urllib.request.urlopen(req, data=data, timeout=15) as r:
            return r.status, json.loads(r.read() or b"{}")
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read() or b"{}")


def _same_binding(row, want):
    if row.get("provider") != want["provider"]:
        return False
    for key in ("model", "credential_ref", "est_cost_cents", "timeout_s"):
        if row.get(key) != want.get(key):
            return False
    params = row.get("params") or {}
    if isinstance(params, str):
        params = json.loads(params)
    if params != (want.get("params") or {}):
        return False
    retry = row.get("retry_policy") or {}
    if isinstance(retry, str):
        retry = json.loads(retry)
    return retry == (want.get("retry_policy") or {})


def seed_binding(want, label):
    _, out = call("GET", "/configs")
    for row in out.get("configs", []):
        if not row.get("active", True):
            continue
        if row.get("scope") != want["scope"]:
            continue
        if want["scope"] == "OPERATION" and \
                row.get("operation_id") != want.get("operation_id"):
            continue
        if want["scope"] == "STATION" and \
                row.get("station") != want.get("station"):
            continue
        if (row.get("environment") or "test") != want.get("environment", "test"):
            continue
        if _same_binding(row, want):
            return f"{label}: present (config {row['config_id'][:8]} v{row['version']})"
        break
    status, out = call("POST", "/configs", want)
    if status not in (200, 201):
        raise SystemExit(f"{label}: seed failed {status}: {out}")
    return f"{label}: seeded (config {out['config_id'][:8]} v{out['version']})"


def seed_pricing():
    _, out = call("GET", "/pricing-rules")
    have = {(r["provider"], r.get("model"), r["unit_kind"],
             r["pricing_version"], str(r["unit_price_cents"]))
            for r in out.get("pricing_rules", []) if r.get("active", True)}
    msgs = []
    for unit_kind, price in (("input_token", INPUT_TOKEN_PRICE_CENTS),
                             ("output_token", OUTPUT_TOKEN_PRICE_CENTS)):
        key = (PROVIDER, MODEL, unit_kind, PRICING_VERSION, price)
        if key in have:
            msgs.append(f"pricing {unit_kind}: present")
            continue
        status, out = call("POST", "/pricing-rules", {
            "provider": PROVIDER, "model": MODEL, "modality": "text",
            "unit_kind": unit_kind, "unit_price_cents": price,
            "pricing_version": PRICING_VERSION})
        if status not in (200, 201):
            raise SystemExit(f"pricing {unit_kind}: seed failed {status}: {out}")
        msgs.append(f"pricing {unit_kind}: seeded @ {price} cents/token "
                    f"({PRICING_VERSION})")
    return msgs


def slice_binding(base_url=None):
    params = {"temperature": 0.7, "max_tokens": 2000}
    if base_url:
        params["base_url"] = base_url
    return {"scope": "OPERATION", "operation_id": "08.12",
            "environment": "test", "provider": PROVIDER, "model": MODEL,
            "modality": "text", "credential_ref": "OPENROUTER_API_KEY",
            "est_cost_cents": 25, "timeout_s": 120, "params": params,
            "retry_policy": {"base_s": 30, "max_s": 900}}


def station_binding():
    return {"scope": "STATION", "station": 3, "environment": "test",
            "provider": "deterministic-local", "est_cost_cents": 100,
            "params": {"reported_actual_cents": 90}}


def main():
    base_url = None
    if "--base-url" in sys.argv:
        base_url = sys.argv[sys.argv.index("--base-url") + 1]
    print(seed_binding(station_binding(), "STATION 3 deterministic-local"))
    print(seed_binding(slice_binding(base_url),
                       "OPERATION 08.12 openrouter-compatible"
                       + (f" (base_url={base_url})" if base_url else "")))
    for msg in seed_pricing():
        print(msg)
    return 0


if __name__ == "__main__":
    sys.exit(main())
