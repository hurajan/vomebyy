# Lean Phase 3 — changed assertions, interpretations, findings

Builder record for the op 08.12 provider-preparation slice. No existing
suite's assertions were edited; every deviation or interpretation is
listed here.

## 1. Plan versioning interpretation (flagged for the controller)

The brief says "08.12's plan gets its new version/hash" following
Gate 04 plan versioning. Implemented as: **plan_version stays "1.0.0",
plan_id stays `plan/1.0.0/08.12`, the plan BODY changes and therefore
plan_hash changes** — c7e1a0b6e370ae7ed0f33369d9786bfed302e22fe6df0dbed41faede0dd01817
→ 244c5fcc0854700872552e8c3b5b7904bd4df1c2c071223bbc040a982e0cf8fa;
plans_hash 9955af63fb3f55d82e89fbafe0a0c561f7caddf6a022ed75b6b53a558d22795b
→ a71d77c66da556f499646eab8fc2c04a5031a944ce4e2ed81723cd66aff3115e.

Rationale: the coordinator resolves plans at (operation_id,
CURRENT_PLAN_VERSION = "1.0.0") and the loader asserts exactly 192
rows with stored hash == file hash; bumping plan_version would break
claim resolution for 08.12 and the loader's exact-count check, and
the attested spec §3.1 itself frames the change as a hash change with
c7e1a0b6… as the recorded baseline. The other 191 plans are
byte-identical (verified by regeneration diff). Registry
definition_hash ea4503f5… untouched; registry validate + plans-validate
PASS. If the owner intended a plan_version bump instead, that is a
coordinator change (CURRENT_PLAN_VERSION) outside this build's scope.

## 2. Estimate fallback in the /work response — considered, rejected

Considered: suppress the Gate C estimate fallback on the new dispatch
path so the response's actual_cost_cents would be null (the adapter
reports cost_cents None). REJECTED: POST /units/{id}/complete requires
an integer actual_cost_cents (`_need` + `int(...)`) and the Gate G
executor passes the /work value straight through — a null would break
the Phase 4 executor contract. Behavior is therefore unchanged
(response actual = binding estimate, the shipped convention). Cost
honesty (spec C-3) is enforced where it is decided: the binding
carries NO reported_actual_cents param, the adapter reports
cost_cents None, and run-b proves settlement comes from CALCULATED
pricing evidence (FINALIZED 1¢, basis "calculated") — not the 25¢
estimate (production spent 271¢ = 270¢ chain + 1¢, not 295¢).

## 3. Harness assertion refinement (scenarios a and c)

First run of scenario (a) asserted "zero financial evidence" and
failed on one row: the coordinator writes an ESTIMATED evidence row at
every claim by design (Gate C/D). The assertion now reads precisely:
no settlement evidence — charge classes == [ESTIMATED] only, no
CALCULATED / PROVIDER_REPORTED / FINALIZED. Same refinement in (c).
This is a harness-wording correction, not a product change.

## 4. New tests added; no existing test modified

- worker_service/tests/test_generate_script.py: 15 new tests (worker
  suite 25 → 40): dispatch byte-identity, refusal, stub generation +
  shaping, garbage/uncovered/HTTP-500 failures, plan_exec evidence
  records, service routing + envelope.
- No existing test file was edited. The g5 suite's script-content
  assertions run unmodified against the new plan (deterministic path).

## 5. Stub authoring (recorded per the brief)

- The stub's canned script deliberately gives line L2 a WRONG
  canon_ref ("model-invented-ref") and omits beat_ref/story_ref on
  L3: assertions prove the worker SETS canon_refs from the actual
  canon input ref and derives beat/story refs from the scene/beat
  inputs. This is stub content design, not provider behavior.
- Canned usage 1500 input / 700 output tokens makes the expected
  CALCULATED amount 1500×0.0001 + 700×0.0005 = 0.50¢ → 1¢ under the
  coordinator's ROUND_HALF_UP quantization: a nonzero, exactly
  checkable settlement.
- The stub runs only on localhost via the adapter's binding
  params.base_url override; the canonical slice binding carries no
  base_url (adapter default https://openrouter.ai/api/v1). Stub
  scenarios re-seed the canonical binding afterwards.

## 6. FINDING — QA-binding resolution vs the OPERATION work binding

With the OPERATION-scope provider binding on 08.12, the evaluation
service's QA resolution (CAPABILITY → OPERATION → FACTORY) resolves
THAT binding as the QA binding. Gate E then refuses to judge with a
credentialed provider: semantic layer = REVIEW_REQUIRED (reason
credential_absent in the harness, whose evaluation service env
deliberately holds no key; real_semantic_judging_not_in_scope_gate_e
when a key is present). The unit therefore reaches AWAITING_HUMAN and
the human decision carries it — consistent with HG2's design — but
the deterministic script_canon_coverage rubric does NOT run
service-side for a provider-bound 08.12. The harness verified the
rubric directly against the produced deliverable (100% coverage,
PASS) as a labeled harness-side check.

A CAPABILITY-scope deterministic-local QA binding is NOT a safe
workaround: claim resolution probes CAPABILITY before OPERATION, so
it would hijack the 08.12 work claim itself. Phase 5/7 needs an
owner-visible decision on QA binding separation. No behavior was
changed for this finding.

## 7. plan_exec failure mapping (additive)

plan_exec now also maps ActionRefused → REFUSED record + BlockedError
and re-raises an action's ProviderError after a FAILED record
(preserving error_class, needed for the stub-500 record). No existing
implementation raises either exception from inside an action, so the
Gate 04 behavior of every other operation is unchanged (full
regression evidence).

## 8. Environment repairs (not product changes)

- The local PostgreSQL `factory` dev role pre-existed with a password
  different from the codebase's documented scratch fixture
  (setup_db.py only creates the role when absent). Reconciled with
  ALTER ROLE to the fixture value so the standard service DSNs work.
- Authored-file credential literals were mangled by display
  redaction twice (harness DSN; setup_slice token line). Both files
  now SOURCE those values from the canonical fixtures (g2 setup_db.py,
  g5 setup_env.py) instead of carrying literals.
