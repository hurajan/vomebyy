# Lean Phase 3 — readiness for the genuine Phase 4 run

State after this build: everything for one genuine Station 03
operation (08.12) through a real text provider is PREPARED and
stub-verified. The real-provider acceptance remains BLOCKED_EXTERNAL:
no credential exists and no paid request was made or attempted.

## Owner-supplied inputs still required

1. **Credential**: an OpenRouter API key, supplied by the owner into
   the worker service's environment as the env var named by the
   binding's credential_ref (`OPENROUTER_API_KEY`) at worker start —
   never into a binding, a workflow, a file, or chat. Also add the
   name to the worker's `WORKER_CREDENTIAL_REFS` so /health reports
   the adapter READY (the slice harness already starts the worker
   this way).
2. **Cap confirmation (PROPOSED, awaiting owner)**: model
   `anthropic/claude-haiku-4.5`; binding estimate 25¢/unit; fixture
   production ceilings soft 250¢ / hard 500¢; pricing_version
   "openrouter-2026-10-29" at the model's published OpenRouter prices
   ($1.00/M input → 0.0001¢/token; $5.00/M output → 0.0005¢/token).
   Expected genuine-run cost at the stub's token profile
   (1500 in / 700 out) is ≈0.5¢, settling as 1¢ CALCULATED.

## Exact remaining steps to the genuine run

1. Owner sets `OPENROUTER_API_KEY` in the worker service environment
   (step 1 above) and confirms the cap/model in step 2.
2. `slice_harness.py setup` (fresh scratch DB, API + evaluation
   service, canonical slice seeding — the binding already in place
   needs no base_url override; the adapter default
   https://openrouter.ai/api/v1 applies).
3. Start the worker service WITH the key in env (harness scenario
   shape: same env as run-b minus the dummy value, plus the real key;
   /health must show openrouter-compatible READY).
4. Drive the fixture exactly as run-b does (canon + 05.12/06.12/07.12
   deterministic chain → 08.12 claim under the OPERATION binding →
   /work → complete with the response's usage + provider_request_id →
   evaluation → human approval). Phase 4 performs this leg through
   the n8n station executor instead of the harness driver; the
   fixture, seeding, and assertions carry over unchanged.
5. Acceptance evidence to collect on the genuine run (mirrors run-b):
   provider_request_id from the real response in the op.build action
   record; token usage → CALCULATED from the seeded pricing rows;
   FINALIZED basis "calculated"; settlement == FINALIZED; envelope
   CANDIDATE with the step-08 deliverable; schema layer PASS;
   semantic layer REVIEW_REQUIRED → human approval (HG2 in Phase 7
   binds that decision to the script artifact); script artifact
   CURRENT in the store.
6. Known open item for Phase 5/7 (see CHANGED_ASSERTIONS.md §6): the
   deterministic canon-coverage rubric cannot run service-side while
   the QA resolution binds the credentialed OPERATION binding; the
   human gate is the quality bar until the owner decides on QA
   binding separation. The 50+ EXPERT golden-set arming requirement
   is untouched and still unmet (factory set 7 SEED / 0 EXPERT).
