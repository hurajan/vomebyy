#!/usr/bin/env python3
"""INDEPENDENT VERIFIER harness — Lean Phase 3 (operation 08.12).

Written independently of the builder's slice_harness.py (same drive
patterns the factory's own suites use: claim -> /work -> /complete ->
/evaluate -> human_approved). Verifier-owned stack:
  DBs    lean3_verify_slice / lean3_verify_det (fresh, chain-built)
  ports  API 8830, worker 8895, evaluation 8896, stub 8899
Scenarios:
  A  no-credential refusal under the real OPERATION binding
  B  stub mechanics with the VERIFIER's stub (usage 3700/2600 ->
     expected CALCULATED 2 cents) + QA-interaction checks (item 5)
  C1 stub HTTP 500 -> typed failure
  C2 stub down (connection refused) -> failure, never a fallback
  D  deterministic identity on a clean DB with NO operation binding
Results JSON land in verify/results/. Run serially, one command at a
time: setup-slice | A | B | C1 | C2 | down-slice | setup-det | D |
down-det.
"""
import json
import os
import re
import subprocess
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path

import psycopg
from psycopg.rows import dict_row

HERE = Path(__file__).resolve().parent
LOGS = HERE / "logs"
RESULTS = HERE / "results"
HOME = Path.home()
G2 = HOME / "workspace/video-factory-g2"
G3 = HOME / "workspace/video-factory-g3"
PROG = HOME / "workspace/video-factory-real-ai-programme"
LP3 = HOME / "workspace/video-factory-master-programme/lean-phase-3"
VENV_PY = str(G2 / ".venv/bin/python")
STORE = PROG / "gate-d/storage_service/.store"

API_PORT, WORKER_PORT, EVAL_PORT, STUB_PORT = 8830, 8895, 8896, 8899
API = f"http://127.0.0.1:{API_PORT}"
WORKER = f"http://127.0.0.1:{WORKER_PORT}"
EVAL = f"http://127.0.0.1:{EVAL_PORT}"
STUB_URL = f"http://127.0.0.1:{STUB_PORT}"
TOKENS = {"FACTORY_API_TOKEN": "dev-operator-token",
          "FACTORY_WORKER_TOKEN": "dev-worker-token",
          "FACTORY_SCHEDULER_TOKEN": "dev-scheduler-token",
          "FACTORY_VALIDATOR_TOKEN": "dev-validator-token",
          "FACTORY_CALLBACK_TOKEN": "dev-callback-token"}
OPERATOR = TOKENS["FACTORY_API_TOKEN"]
DRIVER = "verify-driver"
CANON_TEXT = ("CANON MANIFEST verify-fixture — the tide clock, the "
              "keeper Ines, the drowned ledger, the third night.")
MODEL = "anthropic/claude-haiku-4.5"
PRICING_VERSION = "openrouter-2026-10-29"
STUB_USAGE = {"input_tokens": 3700, "output_tokens": 2600,
              "total_tokens": 6300}
STUB_PRID = "chatcmpl-verify-9d2"
# 3700*0.0001 + 2600*0.0005 = 1.67 -> ROUND_HALF_UP -> 2
EXPECTED_CALCULATED = 2

DB = None  # set per setup


def _fixture_password():
    src = (G2 / "tools/setup_db.py").read_text()
    return re.search(
        r"CREATE ROLE factory LOGIN PASSWORD '([^']+)'", src).group(1)


def dsn(db):
    return ("host=127.0.0.1 dbname=" + db + " user=factory password="
            + _fixture_password())


def db(sql, args=()):
    with psycopg.connect(dsn(DB), row_factory=dict_row,
                         autocommit=True) as conn:
        cur = conn.execute(sql, args)
        try:
            return cur.fetchall()
        except psycopg.errors.ProgrammingError:
            return []


# ------------------------------------------------------------------ http
def call(base, method, path, body=None, role=None, expect=None):
    req = urllib.request.Request(base + path, method=method)
    data = None
    if role == "OPERATOR":
        req.add_header("X-Operator-Token", OPERATOR)
    elif role == "WORKER":
        req.add_header("X-Role", "WORKER")
        req.add_header("X-Role-Token", TOKENS["FACTORY_WORKER_TOKEN"])
        req.add_header("X-Identity", "verify-harness")
    if body is not None:
        data = json.dumps(body).encode()
        req.add_header("Content-Type", "application/json")
    try:
        with urllib.request.urlopen(req, data=data, timeout=30) as r:
            status, out = r.status, json.loads(r.read() or b"{}")
    except urllib.error.HTTPError as e:
        status, out = e.code, json.loads(e.read() or b"{}")
    if expect is not None and status != expect:
        raise AssertionError(f"{method} {path} -> {status} (want {expect}): {out}")
    return status, out


# -------------------------------------------------------------- processes
def kill_port(port):
    subprocess.run(["fuser", "-k", f"{port}/tcp"], capture_output=True)
    time.sleep(0.5)


def spawn(cmd, env, log_name):
    e = dict(os.environ)
    e.update(env)
    out = open(LOGS / log_name, "ab")
    return subprocess.Popen(cmd, env=e, stdout=out, stderr=out,
                            start_new_session=True)


def wait_url(url, seconds=60):
    deadline = time.time() + seconds
    while time.time() < deadline:
        try:
            with urllib.request.urlopen(url, timeout=2) as r:
                if r.status == 200:
                    return True
        except Exception:  # noqa: BLE001
            pass
        time.sleep(0.5)
    return False


def start_stack(dbname, log_prefix):
    kill_port(API_PORT)
    spawn([str(G3 / ".venv/bin/python"), str(G3 / "api/server.py")],
          {"FACTORY_DSN": dsn(dbname), "FACTORY_PORT": str(API_PORT),
           **TOKENS}, f"{log_prefix}-api.log")
    if not wait_url(API + "/health"):
        raise SystemExit(f"API did not come up ({log_prefix}-api.log)")
    kill_port(EVAL_PORT)
    spawn([VENV_PY, str(PROG / "gate-e/evaluation_service/service.py")],
          {"FACTORY_DSN": dsn(dbname), "FACTORY_API_URL": API,
           "FACTORY_VALIDATOR_TOKEN": TOKENS["FACTORY_VALIDATOR_TOKEN"],
           "FACTORY_EVAL_PORT": str(EVAL_PORT)}, f"{log_prefix}-eval.log")
    if not wait_url(EVAL + "/health"):
        raise SystemExit(f"eval service did not come up ({log_prefix}-eval.log)")


def start_worker(dbname, extra_env, log_name):
    kill_port(WORKER_PORT)
    env = {"WORKER_SERVICE_PORT": str(WORKER_PORT),
           "WORKER_ENVIRONMENT": "test", "WORKER_DSN": dsn(dbname),
           "FACTORY_API_URL": API,
           "FACTORY_WORKER_TOKEN": TOKENS["FACTORY_WORKER_TOKEN"],
           "WORKER_CREDENTIAL_REFS": "OPENROUTER_API_KEY",
           "OPENROUTER_API_KEY": None}
    env.update(extra_env)
    env = {k: v for k, v in env.items() if v is not None}
    saved = os.environ.pop("OPENROUTER_API_KEY", None)
    try:
        spawn([VENV_PY, str(PROG / "gate-c/worker_service/service.py")],
              env, log_name)
    finally:
        if saved is not None:
            os.environ["OPENROUTER_API_KEY"] = saved
    if not wait_url(WORKER + "/health"):
        raise SystemExit(f"worker did not come up ({log_name})")


def start_stub(mode):
    kill_port(STUB_PORT)
    record = LOGS / f"vstub_requests_{mode}.jsonl"
    if record.exists():
        record.unlink()
    spawn([sys.executable, str(HERE / "verifier_stub.py"),
           str(STUB_PORT), mode, str(record)], {}, f"vstub_{mode}.log")
    deadline = time.time() + 15
    while time.time() < deadline:
        try:
            req = urllib.request.Request(STUB_URL + "/chat/completions",
                                         data=b"{}", method="POST")
            urllib.request.urlopen(req, timeout=2)
            return record
        except urllib.error.HTTPError:
            return record
        except Exception:  # noqa: BLE001
            time.sleep(0.3)
    raise SystemExit("verifier stub did not come up")


def seed_slice(base_url=None):
    env = dict(os.environ)
    env["SLICE_API_URL"] = API
    cmd = [sys.executable, str(LP3 / "tools/setup_slice.py")]
    if base_url:
        cmd += ["--base-url", base_url]
    r = subprocess.run(cmd, capture_output=True, text=True, env=env)
    if r.returncode != 0:
        raise SystemExit(f"slice seeding failed: {r.stdout} {r.stderr}")
    return r.stdout.strip()


# ---------------------------------------------------------------- driver
class Scenario:
    def __init__(self, name):
        self.name = name
        self.checks = []

    def check(self, name, ok, detail=""):
        self.checks.append({"name": name, "pass": bool(ok),
                            "detail": str(detail)[:600]})
        print(f"  [{'PASS' if ok else 'FAIL'}] {name} — {str(detail)[:200]}")

    def finish(self, extra=None):
        verdict = all(c["pass"] for c in self.checks)
        doc = {"scenario": self.name,
               "verdict": "PASS" if verdict else "FAIL",
               "checks": self.checks, **(extra or {})}
        RESULTS.mkdir(parents=True, exist_ok=True)
        (RESULTS / f"{self.name}.json").write_text(
            json.dumps(doc, indent=1, sort_keys=True))
        print(f"{self.name}: {'PASS' if verdict else 'FAIL'} "
              f"({sum(1 for c in self.checks if c['pass'])}/{len(self.checks)})")
        return 0 if verdict else 1


def unit_row(pid, uid):
    _, out = call(API, "GET", f"/productions/{pid}/units", role="OPERATOR")
    return [u for u in out["units"] if u["unit_id"] == uid][0]


def wait_state(pid, uid, states, timeout=90):
    deadline = time.time() + timeout
    state = None
    while time.time() < deadline:
        state = unit_row(pid, uid)["state"]
        if state in states:
            return state
        time.sleep(0.5)
    raise AssertionError(f"unit {uid} stuck in {state}, wanted {states}")


def current_artifacts(pid):
    _, out = call(API, "GET", f"/productions/{pid}/artifacts", role="OPERATOR")
    return {a["artifact_type"]: a for a in out["artifacts"]
            if a["state"] == "CURRENT"}


def wire_ref(art):
    return {"artifact_type": art["artifact_type"],
            "artifact_id": art["artifact_id"], "sha256": art["sha256"]}


def make_fixture(tag):
    _, p = call(API, "POST", "/productions",
                {"title": f"Lean Phase 3 VERIFY ({tag})",
                 "hard_ceiling_cents": 500, "soft_ceiling_cents": 250},
                role="OPERATOR", expect=201)
    pid = p["production_id"]
    _, r = call(API, "POST", f"/productions/{pid}/runs", {"kind": "FULL"},
                role="OPERATOR", expect=201)
    run = r["run_id"]
    _, a = call(API, "POST", f"/productions/{pid}/artifacts",
                {"artifact_type": "canon_manifest", "content": CANON_TEXT,
                 "storage_uri": "local://canon-verify-fixture"},
                role="OPERATOR", expect=201)
    canon = a["artifact_id"]

    def plan(op, depends=()):
        _, u = call(API, "POST", f"/productions/{pid}/units",
                    {"operation_id": op, "run_id": run, "unit_key": "main",
                     "depends_on": list(depends),
                     "input_artifact_ids": [canon]},
                    role="OPERATOR", expect=201)
        return u["unit_id"]

    units = {}
    units["05.12"] = plan("05.12")
    units["06.12"] = plan("06.12", [units["05.12"]])
    units["07.12"] = plan("07.12", [units["06.12"]])
    units["08.12"] = plan("08.12", [units["07.12"]])
    return pid, canon, units


def claim_and_binding(pid, uid):
    _, claim = call(API, "POST", f"/units/{uid}/claim",
                    {"worker_id": DRIVER}, role="OPERATOR", expect=200)
    _, attempts = call(API, "GET", f"/units/{uid}/attempts", role="OPERATOR")
    return claim, attempts["attempts"][0]["resolved_config"]


def work(pid, uid, op, claim, binding, refs):
    body = {"provider_binding": binding, "operation_id": op,
            "production_id": pid, "unit_id": uid,
            "attempt_id": claim["attempt_id"],
            "fencing_token": claim["fencing_token"], "worker_id": DRIVER,
            "input_artifact_refs": refs}
    return call(WORKER, "POST", "/work", body)


def complete(uid, claim, out, usage=None, provider_request_id=None):
    body = {"worker_id": DRIVER, "fencing_token": claim["fencing_token"],
            "artifact_type": out["artifact_type"], "content": out["content"],
            "actual_cost_cents": out["actual_cost_cents"]}
    if usage is not None:
        body["usage"] = usage
    if provider_request_id is not None:
        body["provider_request_id"] = provider_request_id
    return call(API, "POST", f"/units/{uid}/complete", body,
                role="OPERATOR", expect=200)


def evaluate(uid):
    return call(EVAL, "POST", "/evaluate", {"unit_id": uid}, expect=200)


def drive_chain_unit(sc, pid, uid, op, refs):
    wait_state(pid, uid, {"READY"})
    claim, binding = claim_and_binding(pid, uid)
    status, out = work(pid, uid, op, claim, binding, refs)
    sc.check(f"{op} /work 200 (deterministic chain)",
             status == 200 and out.get("status") == "COMPLETED",
             f"status={status}")
    complete(uid, claim, out)
    _, report = evaluate(uid)
    state = wait_state(pid, uid, {"ACCEPTED", "AWAITING_HUMAN", "FAILED",
                                  "BLOCKED", "RETRY_WAIT"})
    if state == "AWAITING_HUMAN":
        call(API, "POST", f"/units/{uid}/events",
             {"event": "human_approved"}, role="OPERATOR", expect=200)
        state = wait_state(pid, uid, {"ACCEPTED"})
    sc.check(f"{op} ACCEPTED after evaluation + human approval",
             state == "ACCEPTED", f"state={state}")
    return current_artifacts(pid)


def drive_fixture_chain(sc, pid, canon_id, units):
    _, arts = call(API, "GET", f"/productions/{pid}/artifacts",
                   role="OPERATOR")
    canon_row = [a for a in arts["artifacts"]
                 if a["artifact_id"] == canon_id][0]
    have = {"canon_manifest": canon_row}
    refs = [wire_ref(canon_row)]
    for op in ("05.12", "06.12", "07.12"):
        have = drive_chain_unit(sc, pid, units[op], op, refs)
        refs = [wire_ref(have[t]) for t in
                ("canon_manifest", "story_architecture", "beat_graph",
                 "scene_set") if t in have]
    return have, refs


def action_records(uid):
    return db("SELECT action_key, status, output_summary, error "
              "FROM plan_action_attempts WHERE unit_id=%s ORDER BY seq",
              (uid,))


def evidence_classes(attempt_id):
    ev = db("SELECT charge_class, amount_cents, pricing_version, usage "
            "FROM financial_evidence WHERE attempt_id=%s ORDER BY created_at",
            (attempt_id,))
    return ev


def fire_transient_error(uid):
    return call(API, "POST", f"/units/{uid}/events",
                {"event": "transient_error", "worker_id": DRIVER},
                role="WORKER")


# -------------------------------------------------------------- scenarios
def run_a():
    sc = Scenario("v_a_nocredential")
    start_worker(DB, {}, "v-worker-a.log")  # key scrubbed by start_worker
    _, health = call(WORKER, "GET", "/health")
    sc.check("worker /health: openrouter-compatible adapter BLOCKED",
             health["adapters"]["openrouter-compatible"]["status"] == "BLOCKED",
             json.dumps(health["adapters"]["openrouter-compatible"]))
    pid, canon_id, units = make_fixture("A")
    have, refs = drive_fixture_chain(sc, pid, canon_id, units)
    uid = units["08.12"]
    wait_state(pid, uid, {"READY"})
    claim, binding = claim_and_binding(pid, uid)
    sc.check("08.12 claim resolves the OPERATION slice binding",
             binding.get("provider") == "openrouter-compatible"
             and binding.get("operation_id") == "08.12"
             and binding.get("model") == MODEL
             and binding.get("credential_ref") == "OPENROUTER_API_KEY",
             f"provider={binding.get('provider')} model={binding.get('model')}")
    sc.check("binding has no reported_actual_cents / no base_url",
             "reported_actual_cents" not in (binding.get("params") or {})
             and "base_url" not in (binding.get("params") or {}),
             f"params={binding.get('params')}")
    status, out = work(pid, uid, "08.12", claim, binding, refs)
    sc.check("/work refused 409 BLOCKED, error names the missing credential",
             status == 409 and out.get("error_class") == "BLOCKED"
             and "OPENROUTER_API_KEY" in str(out.get("error")),
             f"status={status} out={out}")
    records = {r["action_key"]: r for r in action_records(uid)}
    by_key = {k: v["status"] for k, v in records.items()}
    sc.check("records: manifest SUCCEEDED, op.build REFUSED (credential "
             "reason in the record), no output.emit",
             by_key.get("inputs.manifest") == "SUCCEEDED"
             and by_key.get("op.build") == "REFUSED"
             and "credential" in (records["op.build"].get("error") or "")
             and "output.emit" not in by_key, json.dumps(by_key))
    _, arts = call(API, "GET", f"/productions/{pid}/artifacts",
                   role="OPERATOR")
    types = [a["artifact_type"] for a in arts["artifacts"]]
    sc.check("ANTI-FALLBACK: zero script artifacts; artifact set is only "
             "the chain's deterministic outputs",
             "script" not in types
             and set(types) == {"canon_manifest", "story_architecture",
                                "beat_graph", "scene_set"},
             f"artifacts={types}")
    ev = evidence_classes(claim["attempt_id"])
    classes = sorted(r["charge_class"] for r in ev)
    sc.check("no settlement: financial evidence is ESTIMATED only",
             classes == ["ESTIMATED"], f"classes={classes}")
    state = unit_row(pid, uid)["state"]
    sc.check("unit not ACCEPTED", state != "ACCEPTED", f"state={state}")
    fire_transient_error(uid)
    state = wait_state(pid, uid, {"RETRY_WAIT"})
    sc.check("unit parked in RETRY_WAIT after transient_error",
             state == "RETRY_WAIT", f"state={state}")
    return sc.finish({"production_id": pid, "unit_08_12": uid,
                      "label": "REAL_BINDING_NO_CREDENTIAL"})


def run_b():
    sc = Scenario("v_b_stub_mechanics")
    record = start_stub("ok")
    print("seed (stub base_url):", seed_slice(base_url=STUB_URL))
    try:
        start_worker(DB, {"OPENROUTER_API_KEY": "verifier-dummy-key"},
                     "v-worker-b.log")
        record.write_text("")  # drop the readiness-probe line
        pid, canon_id, units = make_fixture("B")
        have, refs = drive_fixture_chain(sc, pid, canon_id, units)
        uid = units["08.12"]
        wait_state(pid, uid, {"READY"})
        claim, binding = claim_and_binding(pid, uid)
        sc.check("08.12 claim resolves OPERATION binding (stub base_url)",
                 binding.get("provider") == "openrouter-compatible"
                 and (binding.get("params") or {}).get("base_url") == STUB_URL,
                 f"params={binding.get('params')}")
        status, out = work(pid, uid, "08.12", claim, binding, refs)
        sc.check("/work 200 COMPLETED via verifier stub",
                 status == 200 and out.get("status") == "COMPLETED",
                 f"status={status}")
        sc.check("/work usage == verifier stub usage; provider_request_id "
                 "== verifier stub id",
                 out.get("usage") == STUB_USAGE
                 and out.get("provider_request_id") == STUB_PRID,
                 f"usage={out.get('usage')} prid={out.get('provider_request_id')}")
        pe = out.get("plan_execution") or {}
        sc.check("plan_execution FULLY_BOUND, plan pin == new 08.12 hash, "
                 "3 records posted",
                 pe.get("binding_status") == "FULLY_BOUND"
                 and pe.get("plan_hash", "").startswith("244c5fcc")
                 and pe.get("records_posted") == 3,
                 json.dumps(pe)[:250])
        envelope = json.loads(out["content"])
        entry = envelope["output_artifacts"][0]
        script = entry["content"]
        if isinstance(script, str):
            script = json.loads(script)
        sc.check("envelope CANDIDATE, step-08 const, script entry, method "
                 "openrouter-compatible",
                 envelope.get("status") == "CANDIDATE"
                 and envelope.get("step_deliverable")
                 == "Versioned Script + Line IDs"
                 and entry.get("artifact_type") == "script"
                 and envelope["evidence"][0].get("method")
                 == "openrouter-compatible",
                 f"step_deliverable={envelope.get('step_deliverable')}")
        sc.check("WORKER-SET canon_refs: every line + top level == the real "
                 "canon artifact id (stub sent corrupt/absent values)",
                 script.get("canon_refs") == [canon_id]
                 and all(l["canon_refs"] == [canon_id]
                         for l in script["lines"]),
                 f"canon_id={canon_id} top={script.get('canon_refs')}")
        l3 = [l for l in script["lines"] if l["id"] == "L3"][0]
        sc.check("L3 beat/story refs DERIVED worker-side (stub omitted "
                 "them): B1/S1 via SC1",
                 l3["beat_ref"] == "B1" and l3["story_ref"] == "S1",
                 json.dumps(l3))
        sc.check("model text flowed through (verifier line text present); "
                 "scenes SC1+SC2 covered",
                 any("tide log aloud" in l["text"] for l in script["lines"])
                 and {l["scene_ref"] for l in script["lines"]} == {"SC1", "SC2"},
                 json.dumps([l["text"] for l in script["lines"]]))
        # independent deliverable-schema validation (Gate E engine)
        sys.path.insert(0, str(PROG / "gate-e"))
        from evaluation_service import schema_engine  # noqa: E402
        schema = json.loads((HOME / "workspace/video-factory-g1/contracts"
                             "/deliverables/step-08.schema.json").read_text())
        violations = schema_engine.validate(script, schema)
        sc.check("deliverable validates against deliverables/"
                 "step-08.schema.json (verifier-side engine call)",
                 violations == [], f"violations={violations}")
        seen = [json.loads(l) for l in record.read_text().splitlines() if l]
        prompt = seen[0]["messages"][0]["content"] if seen else ""
        sc.check("EXACTLY ONE provider HTTP call; prompt carries canon id "
                 "+ canon text + story/beat/scene content of the CURRENT "
                 "upstream artifacts",
                 len(seen) == 1
                 and seen[0].get("_path") == "/chat/completions"
                 and seen[0].get("model") == MODEL
                 and canon_id in prompt and "tide clock" in prompt
                 and "SC1" in prompt and "SC2" in prompt
                 and "B1" in prompt and "S1" in prompt,
                 f"requests={len(seen)} prompt_len={len(prompt)}")
        _, done = complete(uid, claim, out, usage=out.get("usage"),
                           provider_request_id=out.get("provider_request_id"))
        sc.check("complete accepted (barrier satisfied)",
                 done.get("state") == "VALIDATING",
                 f"state={done.get('state')}")
        records = {r["action_key"]: r for r in action_records(uid)}
        gen = records["op.build"]["output_summary"] or {}
        if isinstance(gen, str):
            gen = json.loads(gen)
        sc.check("generation action record carries provider_request_id + "
                 "token usage",
                 gen.get("provider_request_id") == STUB_PRID
                 and (gen.get("usage") or {}).get("input_tokens") == 3700
                 and (gen.get("usage") or {}).get("output_tokens") == 2600,
                 json.dumps(gen)[:300])
        # ---- item 5: QA interaction
        _, report = evaluate(uid)
        layers = {l.get("layer"): l for l in report.get("layers", [])}
        sem = layers.get("semantic_evaluation", {})
        sc.check("evaluation: schema layer PASS",
                 layers.get("schema_validation", {}).get("verdict") == "PASS",
                 json.dumps(layers.get("schema_validation"))[:200])
        sc.check("evaluation: semantic layer REVIEW_REQUIRED (QA resolves "
                 "the credentialed OPERATION binding; Gate E refuses to "
                 "judge with it)",
                 sem.get("verdict") == "REVIEW_REQUIRED"
                 and sem.get("status") == "BLOCKED",
                 json.dumps(sem)[:300])
        state = wait_state(pid, uid, {"AWAITING_HUMAN", "ACCEPTED",
                                      "BLOCKED", "FAILED"})
        sc.check("unit parks at AWAITING_HUMAN (not ACCEPTED) after "
                 "evaluation", state == "AWAITING_HUMAN", f"state={state}")
        st_w, out_w = call(API, "POST", f"/units/{uid}/events",
                           {"event": "human_approved"}, role="WORKER")
        state2 = unit_row(pid, uid)["state"]
        sc.check("WORKER-role human_approved refused; unit still "
                 "AWAITING_HUMAN (human decision is OPERATOR-only)",
                 st_w in (401, 403) and state2 == "AWAITING_HUMAN",
                 f"status={st_w} state={state2}")
        call(API, "POST", f"/units/{uid}/events",
             {"event": "human_approved"}, role="OPERATOR", expect=200)
        state = wait_state(pid, uid, {"ACCEPTED"})
        sc.check("unit ACCEPTED only after the OPERATOR human decision",
                 state == "ACCEPTED", f"state={state}")
        # ---- money
        ev = evidence_classes(claim["attempt_id"])
        by_class = {r["charge_class"]: r for r in ev}
        calc = by_class.get("CALCULATED", {})
        fin = by_class.get("FINALIZED", {})
        fin_usage = fin.get("usage") or {}
        if isinstance(fin_usage, str):
            fin_usage = json.loads(fin_usage)
        sc.check("CALCULATED == verifier arithmetic (3700*0.0001 + "
                 "2600*0.0005 = 1.67 -> 2c) at the seeded pricing_version",
                 calc.get("amount_cents") == EXPECTED_CALCULATED
                 and calc.get("pricing_version") == PRICING_VERSION,
                 json.dumps({k: v.get("amount_cents")
                             for k, v in by_class.items()}))
        sc.check("FINALIZED == CALCULATED, basis 'calculated', no "
                 "PROVIDER_REPORTED row",
                 fin.get("amount_cents") == EXPECTED_CALCULATED
                 and fin_usage.get("_finalization_basis") == "calculated"
                 and "PROVIDER_REPORTED" not in by_class,
                 f"basis={fin_usage.get('_finalization_basis')}")
        _, budget = call(API, "GET", f"/productions/{pid}/budget",
                         role="OPERATOR")
        sc.check("production spent == 270 chain + 2 FINALIZED = 272 "
                 "(settlement from CALCULATED, not the 25c estimate)",
                 budget.get("spent_cents") == 270 + EXPECTED_CALCULATED,
                 f"spent={budget.get('spent_cents')}")
        arts = current_artifacts(pid)
        script_art = arts.get("script", {})
        store_file = STORE / "objects" / (script_art.get("sha256") or "")
        sc.check("script artifact CURRENT; store bytes == /work envelope "
                 "bytes",
                 bool(script_art) and store_file.exists()
                 and store_file.read_bytes() == out["content"].encode(),
                 f"sha={script_art.get('sha256')}")
        return sc.finish({"production_id": pid, "unit_08_12": uid,
                          "label": "STUB_TESTED",
                          "calculated_cents": EXPECTED_CALCULATED})
    finally:
        print("seed (restore canonical):", seed_slice())


def _drive_to_0812(sc, pid, canon_id, units):
    have, refs = drive_fixture_chain(sc, pid, canon_id, units)
    uid = units["08.12"]
    wait_state(pid, uid, {"READY"})
    claim, binding = claim_and_binding(pid, uid)
    return uid, claim, binding, refs


def run_c1():
    sc = Scenario("v_c1_stub_error500")
    record = start_stub("error500")
    print("seed (stub base_url):", seed_slice(base_url=STUB_URL))
    try:
        start_worker(DB, {"OPENROUTER_API_KEY": "verifier-dummy-key"},
                     "v-worker-c1.log")
        record.write_text("")
        pid, canon_id, units = make_fixture("C1")
        uid, claim, binding, refs = _drive_to_0812(sc, pid, canon_id, units)
        status, out = work(pid, uid, "08.12", claim, binding, refs)
        sc.check("/work 502 typed failure PROVIDER_HTTP_500",
                 status == 502 and out.get("error_class") == "PROVIDER_HTTP_500",
                 f"status={status} out={out}")
        records = {r["action_key"]: r for r in action_records(uid)}
        sc.check("records: manifest SUCCEEDED, op.build FAILED with the "
                 "provider error, no output.emit",
                 records.get("inputs.manifest", {}).get("status") == "SUCCEEDED"
                 and records.get("op.build", {}).get("status") == "FAILED"
                 and "provider HTTP 500" in (records["op.build"].get("error") or "")
                 and "output.emit" not in records,
                 json.dumps({k: v["status"] for k, v in records.items()}))
        _, arts = call(API, "GET", f"/productions/{pid}/artifacts",
                       role="OPERATOR")
        sc.check("zero script artifacts",
                 not any(a["artifact_type"] == "script"
                         for a in arts["artifacts"]), "")
        classes = sorted(r["charge_class"]
                         for r in evidence_classes(claim["attempt_id"]))
        sc.check("zero settlement (ESTIMATED only)",
                 classes == ["ESTIMATED"], f"classes={classes}")
        state = unit_row(pid, uid)["state"]
        sc.check("unit not ACCEPTED", state != "ACCEPTED", f"state={state}")
        fire_transient_error(uid)
        state = wait_state(pid, uid, {"RETRY_WAIT"})
        sc.check("unit driven to RETRY_WAIT (recovery)",
                 state == "RETRY_WAIT", f"state={state}")
        return sc.finish({"production_id": pid, "unit_08_12": uid,
                          "label": "STUB_TESTED"})
    finally:
        print("seed (restore canonical):", seed_slice())


def run_c2():
    sc = Scenario("v_c2_stub_down")
    print("seed (stub base_url):", seed_slice(base_url=STUB_URL))
    kill_port(STUB_PORT)  # nothing listens: connection refused
    time.sleep(0.5)
    start_worker(DB, {"OPENROUTER_API_KEY": "verifier-dummy-key"},
                 "v-worker-c2.log")
    pid, canon_id, units = make_fixture("C2")
    uid, claim, binding, refs = _drive_to_0812(sc, pid, canon_id, units)
    status, out = work(pid, uid, "08.12", claim, binding, refs)
    sc.check("/work fails typed (no 200, no COMPLETED) with the provider "
             "endpoint down",
             status != 200 and out.get("status") != "COMPLETED"
             and bool(out.get("error_class")),
             f"status={status} out={out}")
    records = {r["action_key"]: r for r in action_records(uid)}
    sc.check("records: op.build FAILED (provider error recorded), no "
             "output.emit",
             records.get("op.build", {}).get("status") == "FAILED"
             and bool(records["op.build"].get("error"))
             and "output.emit" not in records,
             json.dumps({k: (v["status"], (v.get("error") or "")[:80])
                         for k, v in records.items()}))
    _, arts = call(API, "GET", f"/productions/{pid}/artifacts",
                   role="OPERATOR")
    sc.check("NO FALLBACK: zero script artifacts with the provider down",
             not any(a["artifact_type"] == "script"
                     for a in arts["artifacts"]), "")
    classes = sorted(r["charge_class"]
                     for r in evidence_classes(claim["attempt_id"]))
    sc.check("zero settlement (ESTIMATED only)",
             classes == ["ESTIMATED"], f"classes={classes}")
    state = unit_row(pid, uid)["state"]
    sc.check("unit not ACCEPTED", state != "ACCEPTED", f"state={state}")
    return sc.finish({"production_id": pid, "unit_08_12": uid,
                      "label": "STUB_TESTED"})


def run_d():
    sc = Scenario("v_d_deterministic_identity")
    # station binding ONLY (no OPERATION binding in this DB)
    st, out_cfg = call(API, "POST", "/configs",
                       {"scope": "STATION", "station": 3,
                        "environment": "test",
                        "provider": "deterministic-local",
                        "est_cost_cents": 100,
                        "params": {"reported_actual_cents": 90}},
                       role="OPERATOR")
    sc.check("station-3 deterministic binding seeded (verifier-side)",
             st in (200, 201), f"status={st}")
    rows = db("SELECT count(*) AS n FROM provider_configs "
              "WHERE scope='OPERATION' AND operation_id='08.12'")
    sc.check("NO OPERATION binding for 08.12 exists in this DB",
             rows and rows[0]["n"] == 0, f"rows={rows}")
    start_worker(DB, {}, "v-worker-d.log")
    pid, canon_id, units = make_fixture("D")
    have, refs = drive_fixture_chain(sc, pid, canon_id, units)
    uid = units["08.12"]
    wait_state(pid, uid, {"READY"})
    claim, binding = claim_and_binding(pid, uid)
    sc.check("08.12 claim resolves the STATION deterministic-local "
             "binding", binding.get("provider") == "deterministic-local",
             f"provider={binding.get('provider')} scope={binding.get('scope')}")
    status, out = work(pid, uid, "08.12", claim, binding, refs)
    sc.check("/work 200 COMPLETED on the deterministic path",
             status == 200 and out.get("status") == "COMPLETED",
             f"status={status}")
    envelope = json.loads(out["content"])
    produced = envelope["output_artifacts"][0]["content"]
    if isinstance(produced, str):
        produced_str = produced
        produced = json.loads(produced)
    else:
        produced_str = json.dumps(produced, sort_keys=True)
    # expected: the pre-Phase-3 deterministic deliverable (structure and
    # line texts as recorded in pre-Phase-3 g5 store artifacts), with
    # this run's canon artifact id substituted.
    expected = {
        "kind": "script",
        "lines": [
            {"id": "L1", "scene_ref": "SC1", "beat_ref": "B1",
             "story_ref": "S1", "canon_refs": [canon_id],
             "text": "Mara finds the brass key behind the clock."},
            {"id": "L2", "scene_ref": "SC2", "beat_ref": "B2",
             "story_ref": "S2", "canon_refs": [canon_id],
             "text": "Tobin admits the archive door was locked from inside."},
            {"id": "L3", "scene_ref": "SC1", "beat_ref": "B1",
             "story_ref": "S1", "canon_refs": [canon_id],
             "text": "The brass key opens the archive; the ledger is gone."}],
        "trace": {
            "clues": [{"id": "CL1", "planted": "L1", "payoff": "L3"}],
            "knowledge": [{"character": "Mara", "learns": "CL1", "at": "L2"}],
            "payoffs": [{"id": "PO1", "clue": "CL1", "line": "L3"}]},
        "canon_refs": [canon_id]}
    sc.check("deliverable == pre-Phase-3 deterministic script (deep "
             "equality, canon id substituted)",
             produced == expected,
             json.dumps(produced)[:300])
    sc.check("deliverable BYTES == json.dumps(expected, sort_keys=True) "
             "(the payloads._json serialization)",
             produced_str == json.dumps(expected, sort_keys=True),
             f"len={len(produced_str)}")
    complete(uid, claim, out)
    _, report = evaluate(uid)
    state = wait_state(pid, uid, {"ACCEPTED", "AWAITING_HUMAN"})
    if state == "AWAITING_HUMAN":
        call(API, "POST", f"/units/{uid}/events",
             {"event": "human_approved"}, role="OPERATOR", expect=200)
        state = wait_state(pid, uid, {"ACCEPTED"})
    sc.check("deterministic 08.12 unit ACCEPTED end-to-end",
             state == "ACCEPTED", f"state={state}")
    return sc.finish({"production_id": pid, "unit_08_12": uid,
                      "label": "DETERMINISTIC_PATH"})


# ------------------------------------------------------------------ main
def build_db(dbname):
    subprocess.run(["pg_ctlcluster", "16", "main", "start"],
                   capture_output=True)
    r = subprocess.run(["python3", str(G3 / "tools/setup_db.py"), dbname],
                       capture_output=True, text=True)
    if r.returncode != 0:
        raise SystemExit(f"scratch DB setup failed: {r.stderr[-400:]}")
    print(f"db: {dbname} built")


def setup_slice_stack():
    global DB
    DB = "lean3_verify_slice"
    build_db(DB)
    start_stack(DB, "slice")
    print("seed:", seed_slice())
    return 0


def setup_det_stack():
    global DB
    DB = "lean3_verify_det"
    build_db(DB)
    start_stack(DB, "det")
    return 0


def teardown():
    for port in (API_PORT, WORKER_PORT, EVAL_PORT, STUB_PORT):
        kill_port(port)
    print("teardown: verifier ports stopped")
    return 0


if __name__ == "__main__":
    cmd = sys.argv[1] if len(sys.argv) > 1 else ""
    LOGS.mkdir(parents=True, exist_ok=True)
    RESULTS.mkdir(parents=True, exist_ok=True)
    if cmd in ("A", "B", "C1", "C2"):
        DB = "lean3_verify_slice"
    elif cmd == "D":
        DB = "lean3_verify_det"
    sys.exit({"setup-slice": setup_slice_stack, "A": run_a, "B": run_b,
              "C1": run_c1, "C2": run_c2, "setup-det": setup_det_stack,
              "D": run_d, "down": teardown}[cmd]())
