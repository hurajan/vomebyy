#!/usr/bin/env python3
"""INDEPENDENT VERIFIER stub — OpenRouter-shaped, written for the
Lean Phase 3 verification (NOT the builder's stub).

Usage: verifier_stub.py <port> <mode> <record_file>
  mode ok       -> 200, verifier-authored script completion + usage
  mode error500 -> 500 on every request
Every request body is appended to <record_file> as one JSON line.

Verifier authoring choices (deliberately different from the builder's):
  - usage 3700 prompt / 2600 completion tokens, so the expected
    CALCULATED evidence at the seeded prices (0.0001 / 0.0005
    cents per token) is 3700*0.0001 + 2600*0.0005 = 0.37 + 1.30 =
    1.67 cents -> 2 cents under ROUND_HALF_UP quantization;
  - provider request id "chatcmpl-verify-9d2";
  - the script's canon_refs are CORRUPT throughout: L1 omits the
    field entirely, L2 carries a bogus value, L3 omits canon_refs
    AND beat_ref AND story_ref, and the top-level canon_refs is a
    bogus value. The worker must SET every canon_refs to the real
    canon artifact id and derive L3's beat/story refs itself.
"""
import json
import sys
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

PORT = int(sys.argv[1])
MODE = sys.argv[2]
RECORD = Path(sys.argv[3])

SCRIPT = {
    "kind": "script",
    "lines": [
        {"id": "L1", "scene_ref": "SC1", "beat_ref": "B1",
         "story_ref": "S1",
         "text": "Ines reads the tide log aloud; three pages are missing."},
        {"id": "L2", "scene_ref": "SC2", "beat_ref": "B2",
         "story_ref": "S2", "canon_refs": ["bogus-model-ref-000"],
         "text": "The keeper admits the lamp was dark on the third night."},
        {"id": "L3", "scene_ref": "SC1",
         "text": "Ines finds the missing pages inside the tide clock."},
    ],
    "trace": {
        "clues": [{"id": "CL9", "planted": "L1", "payoff": "L3"}],
        "knowledge": [{"character": "Ines", "learns": "CL9", "at": "L2"}],
        "payoffs": [{"id": "PO9", "clue": "CL9", "line": "L3"}]},
    "canon_refs": ["bogus-top-level-ref"],
}


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def do_POST(self):
        raw = self.rfile.read(int(self.headers.get("Content-Length") or 0))
        try:
            body = json.loads(raw or b"{}")
        except json.JSONDecodeError:
            body = {"_unparsed": raw.decode("utf-8", errors="replace")}
        body["_path"] = self.path
        with RECORD.open("a") as fh:
            fh.write(json.dumps(body) + "\n")
        if MODE == "error500":
            payload = json.dumps({"error": "verifier stub failure"}).encode()
            code = 500
        else:
            payload = json.dumps({
                "id": "chatcmpl-verify-9d2",
                "choices": [{"message": {"role": "assistant",
                                         "content": json.dumps(SCRIPT)}}],
                "usage": {"prompt_tokens": 3700, "completion_tokens": 2600,
                          "total_tokens": 6300}}).encode()
            code = 200
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(payload)))
        self.end_headers()
        self.wfile.write(payload)


if __name__ == "__main__":
    RECORD.parent.mkdir(parents=True, exist_ok=True)
    ThreadingHTTPServer(("127.0.0.1", PORT), Handler).serve_forever()
