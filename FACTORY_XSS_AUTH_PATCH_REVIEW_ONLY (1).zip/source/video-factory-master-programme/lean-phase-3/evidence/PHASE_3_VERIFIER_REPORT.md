# Lean Phase 3 — INDEPENDENT VERIFIER REPORT (operation 08.12 provider preparation)

Verifier: independent agent, own scratch stack (DBs `lean3_verify_slice` /
`lean3_verify_det`, ports API 8830 / worker 8895 / evaluation 8896 / stub 8899),
own stub provider, own harness (`evidence/verify/verifier_harness.py`,
`verifier_stub.py`; per-scenario results in `evidence/verify/results/`,
suite logs in `evidence/verify/logs/regression/`). Everything ran SERIALLY.
No real provider call was attempted by the builder or by this verifier.

## Verdict

**Phase 3 PREPARATION: VERIFIED.** All seven verification items PASS;
defects **NONE**. The real-provider acceptance test remains
**BLOCKED_EXTERNAL** — no credential exists in the environment (env scan
confirmed: no OPENROUTER/OPENAI/ANTHROPIC variables), and nothing in this
report upgrades stub-tested mechanics to real-provider evidence.

## Item 1 — No-credential refusal: PASS (15/15)

Verifier stack, OPERATION binding seeded via the builder's
`tools/setup_slice.py`, worker started with `OPENROUTER_API_KEY` scrubbed
from env. Worker `/health`: adapter `openrouter-compatible` =
`{"status": "BLOCKED", "credential_required": true}`. The 05.12→07.12
deterministic chain completed; the 08.12 claim resolved the OPERATION
binding (provider openrouter-compatible, model anthropic/claude-haiku-4.5,
credential_ref OPENROUTER_API_KEY, params with no `reported_actual_cents`
and no `base_url`). `/work` → **409, error_class BLOCKED**, error text
naming the missing credential. DB-level inspection (not statuses only):
`plan_action_attempts` = inputs.manifest SUCCEEDED, **op.build REFUSED**
with the credential reason in the record, no output.emit record;
production artifacts = exactly {canon_manifest, story_architecture,
beat_graph, scene_set} — **zero script artifacts, i.e. no deterministic
output was produced under the provider binding (anti-fallback holds at
the artifact level)**; `financial_evidence` for the attempt = [ESTIMATED]
only; unit CLAIMED → RETRY_WAIT after transient_error, never ACCEPTED.

## Item 2 — Stub mechanics (verifier's own stub): PASS (27/27)

Verifier-authored stub: usage 3700 prompt / 2600 completion tokens,
provider_request_id `chatcmpl-verify-9d2`, script content deliberately
corrupt in canon_refs (L1 omits the field, L2 carries a bogus value, L3
omits canon_refs AND beat_ref AND story_ref, top-level canon_refs bogus).

- Exactly **one** provider HTTP call; the recorded prompt contains the
  canon artifact id, the canon text, and the scene/beat/story content of
  the CURRENT 05.12/06.12/07.12 artifacts (prompt_len 2026).
- Deliverable validates against `contracts/deliverables/step-08.schema.json`
  (verifier-side call to the Gate E schema engine: zero violations);
  envelope CANDIDATE with the step-08 const and method openrouter-compatible;
  plan_execution FULLY_BOUND, plan_hash pinned = 244c5fcc…, 3 records posted.
- **Worker-side shaping proven**: every line's canon_refs and the top-level
  canon_refs equal the real canon artifact id (not the stub's values);
  L3's beat_ref/story_ref were derived worker-side (B1/S1 via SC1); the
  stub's line text flowed through unchanged; scenes SC1+SC2 covered.
- Generation action record carries provider_request_id `chatcmpl-verify-9d2`
  and token usage {input 3700, output 2600}.
- Money, recomputed by hand: CALCULATED = 3700×0.0001 + 2600×0.0005 =
  1.67¢ → **2¢** (ROUND_HALF_UP) at pricing_version `openrouter-2026-10-29`
  — matches the evidence row exactly. FINALIZED = 2¢, basis `calculated`,
  no PROVIDER_REPORTED row. Production budget spent = **272¢** (270¢ chain
  + 2¢), not the 295¢ the 25¢ estimate would imply. Script artifact
  CURRENT; store bytes identical to the /work envelope bytes.

## Item 3 — Stub error + no fallback: PASS (C1 12/12, C2 11/11)

- C1 (stub HTTP 500): `/work` → 502, error_class `PROVIDER_HTTP_500`;
  op.build record **FAILED** with the provider error in the record;
  zero script artifacts; ESTIMATED-only evidence; unit → RETRY_WAIT.
- C2 (stub down, connection refused): `/work` → 502, error_class
  `PROVIDER_UNREACHABLE`; op.build record FAILED with the connection
  error; **zero script artifacts — no deterministic fallback with the
  endpoint down**; ESTIMATED-only evidence; unit never ACCEPTED.

## Item 4 — Deterministic identity + plan integrity: PASS

- **Cryptographic plan diff** (verifier-computed, canonical-JSON sha256
  exactly as `generate_plans.py:plan_hash`): every plan_hash in
  plans.json recomputes; reverting precisely two fields of 08.12's plan
  (seq-2 implementation → `op.build_payload`, and the classification
  note → the standard specific-builder note, both visible in the
  generator's `build_specific_plan`) reproduces the Gate 04 plan_hash
  **c7e1a0b6e370ae7ed0f33369d9786bfed302e22fe6df0dbed41faede0dd01817**
  exactly; rebuilding the whole document with only that plan reverted
  reproduces the Gate 04 plans_hash **9955af63…** exactly. Conclusion:
  the other 191 plans are byte-identical to Gate 04, and 08.12 differs
  only in the rebound action + its classification note.
- `registry_tool.py validate` PASS with **definition_hash
  ea4503f516fc4f7940f187f5cd9dac38c57f0d239726cac90e2d0a18a8bc9d73**
  intact; `plans-validate` PASS, plans_hash a71d77c6…. Stored rows in a
  freshly chain-built DB: 192 plans, 69 FULLY_BOUND, 08.12 at
  plan_version 1.0.0 / hash 244c5fcc….
- **Live byte-identity** (scenario D, 13/13): on a clean DB with NO
  OPERATION binding (verified by direct DB count = 0), the 08.12 claim
  resolves the STATION deterministic-local binding and the produced
  deliverable is byte-identical to the pre-Phase-3 deterministic script
  (deep equality + string equality against
  `json.dumps(expected, sort_keys=True)`; expected structure and line
  texts anchored in pre-Phase-3 G5 store artifacts, canon id
  substituted). Unit ACCEPTED end-to-end.

## Item 5 — QA-interaction claim: PASS (reproduced; design, not defect)

Reproduced inside scenario B on the verifier's stack: evaluation of the
provider-bound 08.12 returns semantic layer **REVIEW_REQUIRED**
(status BLOCKED, reason credential_absent — the evaluation service holds
no key) while the schema layer PASSes; the unit parks at
**AWAITING_HUMAN**; a WORKER-role `human_approved` event is refused
(403, state unchanged); only the OPERATOR human decision moves it to
ACCEPTED. This is the Gate E refusal design operating as built
(validation is independent; a credentialed provider binding is never
used to judge), not a Phase 3 regression. Recorded consequence, already
disclosed by the builder and confirmed here: the deterministic
`script_canon_coverage` rubric does not run service-side on this path —
the human gate is the quality bar for the slice, and QA-binding
separation remains an owner-visible open decision (CHANGED_ASSERTIONS
§6). No behavior was changed for it in Phase 3; none is recommended
inside this phase.

## Item 6 — Regression spot re-runs (serial, verifier-run): PASS

| suite | result | note |
|---|---|---|
| worker service | **40 tests, OK** | 25 baseline + 15 new `test_generate_script` |
| g3 (API) | **36 tests, OK** | matches post-Gate-05 count |
| g5 (Station 3) | **1 test, OK** | unmodified suite against the new 08.12 plan |
| g9 | **10 tests, OK** (clean re-run — see the correction record below) | incl. `test_sixteen_steps_one_production`; post-completion DB state confirms the full-run production independently: **18 units, 18 ACCEPTED, CHARGE total 1620¢, 3 APPROVED human gates (HG2/HG4/HG5)** |

Consistent with the builder's full 13-suite regression (215 tests,
`evidence/results/d_regression.json`).

**Correction record (g9 spot run, verifier error — disclosed in full).**
The first g9 run of this verification was invalidated by the verifier,
not by the product, and an early draft of this section reported it
incorrectly. Facts, from the runs' own log files: run 1
(`logs/regression/g9.log`) records **FAILED (errors=2)** — both errors
are `URLError: Connection refused` against the API; the full-run test
had progressed to driving its final unit (16.12, test line 138) when
the API became unreachable. The cause: a spurious early completion
signal for the backgrounded suite command reached the verifier while
the suite was still in its final seconds, and the verifier's cleanup
step (`fuser -k 8730/tcp`) killed the suite's API mid-run; the
materialized-equivalence test then failed at production creation.
Database counts observed in that window shifted between queries
because the suite was still driving its production — they were
mid-flight state, not results. The verifier then re-ran the suite
cleanly (fresh `setup_fullrun`, no interference until completion):
**10 tests, OK** (`logs/regression/g9_rerun.log`), with the DB
confirmation in the table above. No assertion failure occurred in
either run; the worker/g3/g5 spot results were foreground runs read
synchronously from their logs and are unaffected. Item 6 stands as
PASS on the re-run evidence.

## Item 7 — Plan-version observation: OBSERVATION (minor), not a defect

Facts established from source: the claim transaction pins
(plan_id, plan_version, plan_hash) from the single current row of
`operation_execution_plans` (coordinator resolves by
(operation_id, CURRENT_PLAN_VERSION = "1.0.0")); action records are
stamped with the attempt's pinned version+hash; the Gate 05 completion
barrier reads the plan BODY from the current stored row by
(operation_id, attempt.plan_version) — it does not hash-compare the row
against the attempt's pin; the worker verifies the attempt's pinned
plan_id+plan_hash against its plans FILE and aborts PLAN_PIN_MISMATCH
on divergence; the plan loader inserts with ON CONFLICT DO NOTHING and
then verifies stored hash == file hash per operation.

Precise impact of the same-version body change (c7e1a0b6… → 244c5fcc…
at plan_version 1.0.0):

- **No stored record lets an old-pinned attempt verify against the new
  body, and none needs to for this change**: the two bodies have
  identical action keys (inputs.manifest / op.build / output.emit), so
  even the barrier's current-row read yields the same verdict shape.
- **A genuinely mid-flight 08.12 attempt would fail closed, not
  silently**: claimed under c7e1a0b6…, then dispatched to a worker
  whose file carries 244c5fcc…, it aborts with PLAN_PIN_MISMATCH
  (Gate 04 probe-C behavior) — §18 pin semantics working as designed.
- **The supported reload path cannot swap the body silently**: on an
  existing DB holding the old body, `load-plans` leaves the row
  untouched (DO NOTHING) and its post-load hash check fails loudly.
  The new body only ever entered fresh chain-built DBs, before any
  claim existed.
- **No production was in flight**: every factory DB is a per-battery
  scratch DB; production deployment does not exist (Gate 11 blocked).
  G9's full run re-pins per run and passed (item 6).

Residual truth worth carrying forward: multi-version plan storage does
not exist — "1.0.0" now names two historical bodies, distinguished only
by hash. On a future long-lived production DB, a plan-body change
would require a real plan_version bump mechanism (coordinator
CURRENT_PLAN_VERSION is a constant today). That is a Gate 14 /
expansion-phase note, not a Phase 3 defect: the builder's
interpretation is disclosed in CHANGED_ASSERTIONS §1, the spec framed
the change as a hash change with c7e1a0b6… as baseline, and the
fail-closed properties above were verified, not assumed.

## Carry-forward notes (not defects)

1. The `/work` response still carries the binding estimate as
   `actual_cost_cents` (the /complete contract requires an integer;
   the builder's rejected alternative is documented in
   CHANGED_ASSERTIONS §2). Settlement truth lives in the evidence
   layer and was verified there (items 1–2): no settlement in this
   phase ever used the estimate as a measured cost.
2. QA-binding separation (item 5) remains an owner decision for
   Phase 5/7, exactly as the builder recorded it.
3. Model + pricing stand as PROPOSED (anthropic/claude-haiku-4.5;
   $1.00/M input, $5.00/M output, pricing_version openrouter-2026-10-29;
   estimate 25¢, ceilings soft 250¢ / hard 500¢) awaiting owner
   confirmation together with the credential — see READINESS.md.

## Final statement

Phase 3 preparation is **VERIFIED**: the provider path for operation
08.12 is genuinely wired inside plan execution, dispatches strictly on
the attempt's pinned binding, refuses BLOCKED without a credential,
fails typed on provider errors, never falls back to the deterministic
builder under a provider binding, shapes and grounds its output
worker-side, and settles from CALCULATED pricing evidence — while the
deterministic path and all 191 other plans are provably unchanged.
The Phase 3 acceptance test itself (one genuine provider request) is
**BLOCKED_EXTERNAL**: it requires the owner-supplied OpenRouter
credential and cap confirmation, and was not attempted.
