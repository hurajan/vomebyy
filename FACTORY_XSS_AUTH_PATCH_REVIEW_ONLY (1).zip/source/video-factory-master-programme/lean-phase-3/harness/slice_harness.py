#!/usr/bin/env python3
"""Lean Phase 3 — slice harness: the fixture + drive cycle Phase 4 runs.

Fixture (per production): an operator-registered canon_manifest (the
canonical Station 1-2 output text), then units 05.12 -> 06.12 -> 07.12
-> 08.12, each depending on the previous, canon as the planned input —
the same shape the G5 suite plans. Production ceilings are the slice
harness's params from the spec: soft 250 / hard 500 cents.

Drive cycle per unit (the Gate 04 probe pattern, replacing the n8n
executor leg-for-leg; Phase 4 swaps this leg for the station executor
and keeps the fixture, seeding and assertions):
  wait READY -> claim (worker_id "slice-driver") -> read the attempt's
  resolved_config snapshot -> POST worker /work with wire refs
  (planned inputs + transitive dependency outputs; the worker resolves
  contents from the Gate D store by sha) -> POST /complete with the
  work response's artifact_type/content/actual + usage +
  provider_request_id -> POST evaluation /evaluate -> on
  AWAITING_HUMAN fire human_approved as OPERATOR (harness-as-human,
  the G5 driver pattern) -> ACCEPTED.

Scenarios (each an independent production on the shared slice DB;
results JSON in lean-phase-3/evidence/results/):
  run-a  NO-CREDENTIAL (STUB-free, the real binding): worker env has
         WORKER_CREDENTIAL_REFS=OPENROUTER_API_KEY but no key -> 08.12
         /work must be a 409 BLOCKED refusal with a REFUSED generation
         action record, zero artifacts, unit not ACCEPTED, and worker
         /health shows the adapter BLOCKED.
  run-b  STUB-MECHANICS: worker env carries a harness-only dummy value
         for OPENROUTER_API_KEY and the binding is re-seeded with
         params.base_url pointing at the local stub (adapter-supported
         override). Full path executes against the stub; financial
         evidence must settle from CALCULATED pricing, not the
         estimate. Labeled STUB_TESTED — never the real acceptance.
  run-c  STUB-ERROR: stub answers 500 -> typed PROVIDER_HTTP_500
         failure, FAILED generation record, zero artifacts, zero
         settlement, unit driven to RETRY_WAIT (recovery).

setup: build scratch DB lean3_slice_scratch (G3 setup chain), start
the API (:8730) + evaluation service (:8796) bound to it, seed the
slice configuration (tools/setup_slice.py). The worker service is
(re)started per scenario because its credential env differs.
teardown: stop API/worker/evaluation/stub by port.

Run with the factory venv python (psycopg):
  ~/workspace/video-factory-g2/.venv/bin/python slice_harness.py setup
"""
import json
import os
import re
import subprocess
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path

import psycopg
from psycopg.rows import dict_row

ROOT = Path(__file__).resolve().parent.parent
LOGS = ROOT / "evidence" / "logs"
RESULTS = ROOT / "evidence" / "results"
HOME = Path.home()
G2 = HOME / "workspace/video-factory-g2"
G3 = HOME / "workspace/video-factory-g3"
PROG = HOME / "workspace/video-factory-real-ai-programme"
VENV_PY = str(G2 / ".venv/bin/python")
STORE = PROG / "gate-d/storage_service/.store"

DB = "lean3_slice_scratch"
def _fixture_password():
    """The dev scratch role's password, sourced from the canonical
    fixture (g2 tools/setup_db.py CREATE ROLE line) — never re-typed
    as a literal in this file (display redaction mangles literals)."""
    src = (G2 / "tools/setup_db.py").read_text()
    return re.search(
        r"CREATE ROLE factory LOGIN PASSWORD '([^']+)'", src).group(1)


DSN = ("host=127.0.0.1 dbname=" + DB + " user=factory password="
       + _fixture_password())
API = "http://127.0.0.1:8730"
WORKER = "http://127.0.0.1:8795"
EVAL = "http://127.0.0.1:8796"
STUB_PORT = 8799
STUB_URL = f"http://127.0.0.1:{STUB_PORT}"
TOKENS = {"FACTORY_API_TOKEN": "dev-operator-token",
          "FACTORY_WORKER_TOKEN": "dev-worker-token",
          "FACTORY_SCHEDULER_TOKEN": "dev-scheduler-token",
          "FACTORY_VALIDATOR_TOKEN": "dev-validator-token",
          "FACTORY_CALLBACK_TOKEN": "dev-callback-token"}
OPERATOR = TOKENS["FACTORY_API_TOKEN"]
DRIVER = "slice-driver"
CANON_TEXT = ("CANON MANIFEST v1 — universe, chronology, world rules, "
              "knowledge boundaries released.")
MODEL = "anthropic/claude-haiku-4.5"
PRICING_VERSION = "openrouter-2026-10-29"
STUB_USAGE = {"input_tokens": 1500, "output_tokens": 700,
              "total_tokens": 2200}
EXPECTED_CALCULATED = 1  # 1500*0.0001 + 700*0.0005 = 0.50 -> HALF_UP 1


# ------------------------------------------------------------------ http
def call(base, method, path, body=None, role=None, expect=None):
    req = urllib.request.Request(base + path, method=method)
    data = None
    if role == "OPERATOR":
        req.add_header("X-Operator-Token", OPERATOR)
    elif role == "WORKER":
        req.add_header("X-Role", "WORKER")
        req.add_header("X-Role-Token", TOKENS["FACTORY_WORKER_TOKEN"])
        req.add_header("X-Identity", "slice-harness")
    if body is not None:
        data = json.dumps(body).encode()
        req.add_header("Content-Type", "application/json")
    try:
        with urllib.request.urlopen(req, data=data, timeout=30) as r:
            status, out = r.status, json.loads(r.read() or b"{}")
    except urllib.error.HTTPError as e:
        status, out = e.code, json.loads(e.read() or b"{}")
    if expect is not None and status != expect:
        raise AssertionError(f"{method} {path} -> {status} (want {expect}): {out}")
    return status, out


def db(sql, args=()):
    with psycopg.connect(DSN, row_factory=dict_row, autocommit=True) as conn:
        cur = conn.execute(sql, args)
        try:
            return cur.fetchall()
        except psycopg.errors.ProgrammingError:
            return []


# -------------------------------------------------------------- processes
def kill_port(port):
    subprocess.run(["fuser", "-k", f"{port}/tcp"], capture_output=True)
    time.sleep(0.5)


def spawn(cmd, env, log_name):
    e = dict(os.environ)
    e.update(env)
    out = open(LOGS / log_name, "ab")
    return subprocess.Popen(cmd, env=e, stdout=out, stderr=out,
                            start_new_session=True)


def wait_url(url, seconds=60):
    deadline = time.time() + seconds
    while time.time() < deadline:
        try:
            with urllib.request.urlopen(url, timeout=2) as r:
                if r.status == 200:
                    return True
        except Exception:  # noqa: BLE001
            pass
        time.sleep(0.5)
    return False


def start_worker(extra_env, log_name="worker.log"):
    kill_port(8795)
    env = {"WORKER_SERVICE_PORT": "8795", "WORKER_ENVIRONMENT": "test",
           "WORKER_DSN": DSN, "FACTORY_API_URL": API,
           "FACTORY_WORKER_TOKEN": TOKENS["FACTORY_WORKER_TOKEN"],
           "WORKER_CREDENTIAL_REFS": "OPENROUTER_API_KEY",
           # scrubbed unless the scenario explicitly provides it:
           # scenario (a) must prove behavior with the key ABSENT
           "OPENROUTER_API_KEY": None}
    env.update(extra_env)
    env = {k: v for k, v in env.items() if v is not None}
    # spawn() inherits os.environ: scrub the credential there too, so
    # scenario (a)'s absence is real even if the harness shell had it
    saved = os.environ.pop("OPENROUTER_API_KEY", None)
    try:
        spawn([VENV_PY, str(PROG / "gate-c/worker_service/service.py")],
              env, log_name)
    finally:
        if saved is not None:
            os.environ["OPENROUTER_API_KEY"] = saved
    if not wait_url(WORKER + "/health"):
        raise SystemExit(f"worker service did not come up (see logs/{log_name})")


def start_stub(mode):
    kill_port(STUB_PORT)
    record = LOGS / f"stub_requests_{mode}.jsonl"
    if record.exists():
        record.unlink()
    spawn([sys.executable, str(ROOT / "harness/stub_provider.py"),
           str(STUB_PORT), mode, str(record)], {}, "stub.log")
    deadline = time.time() + 15
    while time.time() < deadline:
        try:
            req = urllib.request.Request(STUB_URL + "/chat/completions",
                                         data=b"{}", method="POST")
            urllib.request.urlopen(req, timeout=2)
            return record
        except urllib.error.HTTPError:
            return record  # any HTTP answer = stub is serving
        except Exception:  # noqa: BLE001
            time.sleep(0.3)
    raise SystemExit("stub provider did not come up (see logs/stub.log)")


def seed(base_url=None):
    cmd = [sys.executable, str(ROOT / "tools/setup_slice.py")]
    if base_url:
        cmd += ["--base-url", base_url]
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode != 0:
        raise SystemExit(f"slice seeding failed: {r.stdout} {r.stderr}")
    return r.stdout.strip()


# ---------------------------------------------------------------- driver
class Scenario:
    def __init__(self, name):
        self.name = name
        self.checks = []

    def check(self, name, ok, detail=""):
        self.checks.append({"name": name, "pass": bool(ok),
                            "detail": str(detail)})
        print(f"  [{'PASS' if ok else 'FAIL'}] {name} — {detail}")

    def finish(self, extra=None):
        verdict = all(c["pass"] for c in self.checks)
        doc = {"scenario": self.name, "verdict": "PASS" if verdict else "FAIL",
               "checks": self.checks, **(extra or {})}
        RESULTS.mkdir(parents=True, exist_ok=True)
        (RESULTS / f"{self.name}.json").write_text(
            json.dumps(doc, indent=1, sort_keys=True))
        print(f"{self.name}: {'PASS' if verdict else 'FAIL'} "
              f"({sum(1 for c in self.checks if c['pass'])}/{len(self.checks)})")
        return 0 if verdict else 1


def unit_row(pid, uid):
    _, out = call(API, "GET", f"/productions/{pid}/units", role="OPERATOR")
    return [u for u in out["units"] if u["unit_id"] == uid][0]


def wait_state(pid, uid, states, timeout=90):
    deadline = time.time() + timeout
    state = None
    while time.time() < deadline:
        state = unit_row(pid, uid)["state"]
        if state in states:
            return state
        time.sleep(0.5)
    raise AssertionError(f"unit {uid} stuck in {state}, wanted {states}")


def current_artifacts(pid):
    _, out = call(API, "GET", f"/productions/{pid}/artifacts", role="OPERATOR")
    return {a["artifact_type"]: a for a in out["artifacts"]
            if a["state"] == "CURRENT"}


def wire_ref(art):
    return {"artifact_type": art["artifact_type"],
            "artifact_id": art["artifact_id"], "sha256": art["sha256"]}


def make_fixture(sc):
    _, p = call(API, "POST", "/productions",
                {"title": f"Lean Phase 3 slice ({sc.name})",
                 "hard_ceiling_cents": 500, "soft_ceiling_cents": 250},
                role="OPERATOR", expect=201)
    pid = p["production_id"]
    _, r = call(API, "POST", f"/productions/{pid}/runs", {"kind": "FULL"},
                role="OPERATOR", expect=201)
    run = r["run_id"]
    _, a = call(API, "POST", f"/productions/{pid}/artifacts",
                {"artifact_type": "canon_manifest", "content": CANON_TEXT,
                 "storage_uri": "local://canon-fixture"},
                role="OPERATOR", expect=201)
    canon = a["artifact_id"]

    def plan(op, depends=()):
        _, u = call(API, "POST", f"/productions/{pid}/units",
                    {"operation_id": op, "run_id": run, "unit_key": "main",
                     "depends_on": list(depends),
                     "input_artifact_ids": [canon]},
                    role="OPERATOR", expect=201)
        return u["unit_id"]

    units = {}
    units["05.12"] = plan("05.12")
    units["06.12"] = plan("06.12", [units["05.12"]])
    units["07.12"] = plan("07.12", [units["06.12"]])
    units["08.12"] = plan("08.12", [units["07.12"]])
    return pid, canon, units


def claim_and_binding(pid, uid):
    _, claim = call(API, "POST", f"/units/{uid}/claim",
                    {"worker_id": DRIVER}, role="OPERATOR", expect=200)
    _, attempts = call(API, "GET", f"/units/{uid}/attempts", role="OPERATOR")
    return claim, attempts["attempts"][0]["resolved_config"]


def work(pid, uid, op, claim, binding, refs):
    body = {"provider_binding": binding, "operation_id": op,
            "production_id": pid, "unit_id": uid,
            "attempt_id": claim["attempt_id"],
            "fencing_token": claim["fencing_token"], "worker_id": DRIVER,
            "input_artifact_refs": refs}
    return call(WORKER, "POST", "/work", body)


def complete(uid, claim, out, usage=None, provider_request_id=None):
    body = {"worker_id": DRIVER, "fencing_token": claim["fencing_token"],
            "artifact_type": out["artifact_type"], "content": out["content"],
            "actual_cost_cents": out["actual_cost_cents"]}
    if usage is not None:
        body["usage"] = usage
    if provider_request_id is not None:
        body["provider_request_id"] = provider_request_id
    return call(API, "POST", f"/units/{uid}/complete", body,
                role="OPERATOR", expect=200)


def evaluate_and_approve(sc, pid, uid):
    """Returns (eval_report, final_state)."""
    _, report = call(EVAL, "POST", "/evaluate", {"unit_id": uid}, expect=200)
    state = wait_state(pid, uid, {"ACCEPTED", "AWAITING_HUMAN", "FAILED",
                                  "BLOCKED", "RETRY_WAIT"})
    if state == "AWAITING_HUMAN":
        call(API, "POST", f"/units/{uid}/events",
             {"event": "human_approved"}, role="OPERATOR", expect=200)
        state = wait_state(pid, uid, {"ACCEPTED"})
    return report, state


def drive_chain_unit(sc, pid, uid, op, refs):
    wait_state(pid, uid, {"READY"})
    claim, binding = claim_and_binding(pid, uid)
    status, out = work(pid, uid, op, claim, binding, refs)
    sc.check(f"{op} /work 200 (deterministic chain)",
             status == 200 and out.get("status") == "COMPLETED",
             f"status={status}")
    complete(uid, claim, out)
    report, state = evaluate_and_approve(sc, pid, uid)
    sc.check(f"{op} ACCEPTED after evaluation + harness human approval",
             state == "ACCEPTED", f"state={state}")
    return current_artifacts(pid)


def drive_fixture_chain(sc, pid, canon_id, units):
    """Run 05.12/06.12/07.12 deterministically; returns the artifact
    map (type -> row) including the canon row."""
    _, arts = call(API, "GET", f"/productions/{pid}/artifacts",
                   role="OPERATOR")
    canon_row = [a for a in arts["artifacts"]
                 if a["artifact_id"] == canon_id][0]
    have = {"canon_manifest": canon_row}
    refs = [wire_ref(canon_row)]
    for op, produces in (("05.12", "story_architecture"),
                         ("06.12", "beat_graph"),
                         ("07.12", "scene_set")):
        have = drive_chain_unit(sc, pid, units[op], op, refs)
        refs = [wire_ref(have[t]) for t in
                ("canon_manifest", "story_architecture", "beat_graph",
                 "scene_set") if t in have]
    return have, refs


def fire_transient_error(uid):
    return call(API, "POST", f"/units/{uid}/events",
                {"event": "transient_error", "worker_id": DRIVER},
                role="WORKER")


def action_records(uid):
    return db("SELECT action_key, status, output_summary, error "
              "FROM plan_action_attempts WHERE unit_id=%s ORDER BY seq",
              (uid,))


# -------------------------------------------------------------- scenarios
def run_a():
    sc = Scenario("a_nocredential")
    print("seed (canonical):", seed())
    start_worker({})  # no OPENROUTER_API_KEY in env
    _, health = call(WORKER, "GET", "/health")
    sc.check("worker /health: openrouter-compatible adapter BLOCKED "
             "(credential ref named, key absent)",
             health["adapters"]["openrouter-compatible"]["status"] == "BLOCKED",
             json.dumps(health["adapters"]["openrouter-compatible"]))
    pid, canon_id, units = make_fixture(sc)
    have, refs = drive_fixture_chain(sc, pid, canon_id, units)
    uid = units["08.12"]
    wait_state(pid, uid, {"READY"})
    claim, binding = claim_and_binding(pid, uid)
    sc.check("08.12 claim resolves the OPERATION slice binding",
             binding.get("provider") == "openrouter-compatible"
             and binding.get("operation_id") == "08.12"
             and binding.get("model") == MODEL
             and binding.get("credential_ref") == "OPENROUTER_API_KEY",
             f"provider={binding.get('provider')} model={binding.get('model')}")
    sc.check("binding carries no reported_actual_cents / no base_url",
             "reported_actual_cents" not in (binding.get("params") or {})
             and "base_url" not in (binding.get("params") or {}),
             f"params={binding.get('params')}")
    status, out = work(pid, uid, "08.12", claim, binding, refs)
    sc.check("/work refused 409 BLOCKED (no credential, no fallback)",
             status == 409 and out.get("error_class") == "BLOCKED",
             f"status={status} out={out}")
    records = action_records(uid)
    by_key = {r["action_key"]: r["status"] for r in records}
    sc.check("action records: manifest SUCCEEDED, op.build REFUSED, "
             "no output.emit",
             by_key.get("inputs.manifest") == "SUCCEEDED"
             and by_key.get("op.build") == "REFUSED"
             and "output.emit" not in by_key, json.dumps(by_key))
    _, arts = call(API, "GET", f"/productions/{pid}/artifacts",
                   role="OPERATOR")
    sc.check("zero script artifacts produced",
             not any(a["artifact_type"] == "script"
                     for a in arts["artifacts"]),
             f"artifacts={[a['artifact_type'] for a in arts['artifacts']]}")
    ev = db("SELECT charge_class FROM financial_evidence "
            "WHERE attempt_id=%s", (claim["attempt_id"],))
    classes = sorted(r["charge_class"] for r in ev)
    sc.check("no settlement evidence for the refused attempt (only "
             "the claim-time ESTIMATED row the coordinator writes for "
             "every claim; no CALCULATED / FINALIZED)",
             classes == ["ESTIMATED"], f"classes={classes}")
    state = unit_row(pid, uid)["state"]
    sc.check("unit not ACCEPTED", state != "ACCEPTED", f"state={state}")
    fire_transient_error(uid)
    state = wait_state(pid, uid, {"RETRY_WAIT"})
    sc.check("unit parked in RETRY_WAIT after transient_error "
             "(recovery state)", state == "RETRY_WAIT", f"state={state}")
    return sc.finish({"production_id": pid, "unit_08_12": uid,
                      "label": "REAL_BINDING_NO_CREDENTIAL"})


def run_b():
    sc = Scenario("b_stub_mechanics")
    record = start_stub("ok")
    print("seed (stub base_url):", seed(base_url=STUB_URL))
    try:
        start_worker({"OPENROUTER_API_KEY": "stub-local-key"})
        record.write_text("")  # drop the stub readiness-probe line
        _, health = call(WORKER, "GET", "/health")
        sc.check("worker /health: adapter READY with harness dummy key",
                 health["adapters"]["openrouter-compatible"]["status"]
                 == "READY", health["adapters"]["openrouter-compatible"]["status"])
        pid, canon_id, units = make_fixture(sc)
        have, refs = drive_fixture_chain(sc, pid, canon_id, units)
        uid = units["08.12"]
        wait_state(pid, uid, {"READY"})
        claim, binding = claim_and_binding(pid, uid)
        sc.check("08.12 claim resolves the OPERATION slice binding "
                 "(stub base_url override)",
                 binding.get("provider") == "openrouter-compatible"
                 and (binding.get("params") or {}).get("base_url") == STUB_URL,
                 f"params={binding.get('params')}")
        status, out = work(pid, uid, "08.12", claim, binding, refs)
        sc.check("/work 200 COMPLETED via stub", status == 200
                 and out.get("status") == "COMPLETED", f"status={status}")
        sc.check("/work usage = stub token usage; provider_request_id "
                 "recorded",
                 out.get("usage") == STUB_USAGE
                 and out.get("provider_request_id") == "chatcmpl-stub-1",
                 f"usage={out.get('usage')} prid={out.get('provider_request_id')}")
        sc.check("plan_execution FULLY_BOUND, 3 records posted",
                 (out.get("plan_execution") or {}).get("binding_status")
                 == "FULLY_BOUND"
                 and out["plan_execution"].get("records_posted") == 3,
                 json.dumps(out.get("plan_execution"))[:200])
        envelope = json.loads(out["content"])
        entry = envelope["output_artifacts"][0]
        script = entry["content"]
        sc.check("envelope: CANDIDATE, step-08 const, script entry",
                 envelope.get("status") == "CANDIDATE"
                 and envelope.get("step_deliverable")
                 == "Versioned Script + Line IDs"
                 and entry.get("artifact_type") == "script"
                 and envelope["evidence"][0].get("method")
                 == "openrouter-compatible",
                 f"step_deliverable={envelope.get('step_deliverable')}")
        sc.check("deliverable shaped worker-side: canon_refs SET from "
                 "the canon input ref on every line + top level",
                 script.get("kind") == "script"
                 and script.get("canon_refs") == [canon_id]
                 and all(l["canon_refs"] == [canon_id]
                         for l in script["lines"]),
                 f"canon_refs={script.get('canon_refs')}")
        sc.check("scene coverage SC1+SC2; L3 beat/story derived from "
                 "scene/beat inputs",
                 {l["scene_ref"] for l in script["lines"]} == {"SC1", "SC2"}
                 and [l for l in script["lines"] if l["id"] == "L3"][0]
                 ["beat_ref"] == "B1"
                 and [l for l in script["lines"] if l["id"] == "L3"][0]
                 ["story_ref"] == "S1", json.dumps(script["lines"]))
        seen = [json.loads(l) for l in record.read_text().splitlines() if l]
        prompt = seen[0]["messages"][0]["content"] if seen else ""
        sc.check("stub received ONE chat request; prompt assembled from "
                 "current canon/scene contents",
                 len(seen) == 1 and seen[0].get("_path") == "/chat/completions"
                 and seen[0].get("model") == MODEL
                 and canon_id in prompt and "CANON MANIFEST v1" in prompt
                 and "SC1" in prompt and "SC2" in prompt,
                 f"requests={len(seen)} prompt_len={len(prompt)}")
        _, done = complete(uid, claim, out, usage=out.get("usage"),
                           provider_request_id=out.get("provider_request_id"))
        sc.check("complete accepted (completion barrier satisfied by "
                 "the 3 SUCCEEDED action records)",
                 done.get("state") == "VALIDATING", f"state={done.get('state')}")
        records = {r["action_key"]: r for r in action_records(uid)}
        gen = records["op.build"]["output_summary"] or {}
        sc.check("generation action record carries provider_request_id "
                 "+ token usage",
                 gen.get("provider_request_id") == "chatcmpl-stub-1"
                 and (gen.get("usage") or {}).get("input_tokens") == 1500
                 and (gen.get("usage") or {}).get("output_tokens") == 700,
                 json.dumps(gen))
        report, state = evaluate_and_approve(sc, pid, uid)
        layers = {l.get("layer"): l for l in report.get("layers", [])}
        sc.check("evaluation ran: schema layer PASS",
                 layers.get("schema_validation", {}).get("verdict") == "PASS",
                 json.dumps(layers.get("schema_validation"))[:200])
        sem = layers.get("semantic_evaluation", {})
        sc.check("semantic layer REVIEW_REQUIRED (QA resolution binds "
                 "the credentialed OPERATION binding; Gate E does not "
                 "judge with real providers — recorded finding)",
                 sem.get("verdict") == "REVIEW_REQUIRED",
                 json.dumps(sem)[:300])
        sc.check("unit ACCEPTED after harness human approval",
                 state == "ACCEPTED", f"state={state}")
        # harness-side rubric check on the produced deliverable
        sys.path.insert(0, str(PROG / "gate-e"))
        from evaluation_service import layers as eval_layers  # noqa: E402
        stats, problems = eval_layers._rubric_script_canon(script, 100)
        sc.check("rubric script_canon_coverage (direct call on the "
                 "produced deliverable): 100% of lines carry canon_refs",
                 not problems and stats["coverage_pct"] == 100.0,
                 json.dumps(stats))
        ev = db("SELECT charge_class, amount_cents, pricing_version, usage "
                "FROM financial_evidence WHERE attempt_id=%s "
                "ORDER BY created_at", (claim["attempt_id"],))
        by_class = {r["charge_class"]: r for r in ev}
        calc = by_class.get("CALCULATED", {})
        fin = by_class.get("FINALIZED", {})
        fin_usage = fin.get("usage") or {}
        if isinstance(fin_usage, str):
            fin_usage = json.loads(fin_usage)
        sc.check("financial evidence: CALCULATED from seeded pricing "
                 "rows; FINALIZED basis = calculated; no PROVIDER_REPORTED",
                 calc.get("amount_cents") == EXPECTED_CALCULATED
                 and calc.get("pricing_version") == PRICING_VERSION
                 and fin.get("amount_cents") == EXPECTED_CALCULATED
                 and fin_usage.get("_finalization_basis") == "calculated"
                 and "PROVIDER_REPORTED" not in by_class,
                 json.dumps({k: v.get("amount_cents") for k, v in by_class.items()})
                 + f" basis={fin_usage.get('_finalization_basis')}")
        _, budget = call(API, "GET", f"/productions/{pid}/budget",
                         role="OPERATOR")
        sc.check("settlement == FINALIZED (budget spent = chain 270 + "
                 "FINALIZED 1 = 271, not the 25 estimate)",
                 budget.get("spent_cents") == 270 + EXPECTED_CALCULATED
                 and fin.get("amount_cents") == EXPECTED_CALCULATED,
                 f"spent={budget.get('spent_cents')}")
        arts = current_artifacts(pid)
        script_art = arts.get("script", {})
        store_file = STORE / "objects" / (script_art.get("sha256") or "")
        sc.check("script artifact CURRENT and durable in the store "
                 "(bytes == the /work envelope bytes)",
                 bool(script_art) and store_file.exists()
                 and store_file.read_bytes() == out["content"].encode(),
                 f"sha={script_art.get('sha256')}")
        return sc.finish({"production_id": pid, "unit_08_12": uid,
                          "label": "STUB_TESTED",
                          "calculated_cents": EXPECTED_CALCULATED})
    finally:
        print("seed (restore canonical):", seed())


def run_c():
    sc = Scenario("c_stub_error")
    record = start_stub("error500")
    print("seed (stub base_url):", seed(base_url=STUB_URL))
    try:
        start_worker({"OPENROUTER_API_KEY": "stub-local-key"})
        record.write_text("")  # drop the stub readiness-probe line
        pid, canon_id, units = make_fixture(sc)
        have, refs = drive_fixture_chain(sc, pid, canon_id, units)
        uid = units["08.12"]
        wait_state(pid, uid, {"READY"})
        claim, binding = claim_and_binding(pid, uid)
        status, out = work(pid, uid, "08.12", claim, binding, refs)
        sc.check("/work 502 typed failure PROVIDER_HTTP_500",
                 status == 502
                 and out.get("error_class") == "PROVIDER_HTTP_500",
                 f"status={status} out={out}")
        records = {r["action_key"]: r for r in action_records(uid)}
        sc.check("action records: manifest SUCCEEDED, op.build FAILED "
                 "(provider error in the record), no output.emit",
                 records.get("inputs.manifest", {}).get("status") == "SUCCEEDED"
                 and records.get("op.build", {}).get("status") == "FAILED"
                 and "provider HTTP 500" in (records["op.build"].get("error") or "")
                 and "output.emit" not in records,
                 json.dumps({k: v["status"] for k, v in records.items()}))
        _, arts = call(API, "GET", f"/productions/{pid}/artifacts",
                       role="OPERATOR")
        sc.check("zero script artifacts",
                 not any(a["artifact_type"] == "script"
                         for a in arts["artifacts"]), "")
        ev = db("SELECT charge_class FROM financial_evidence "
                "WHERE attempt_id=%s", (claim["attempt_id"],))
        classes = sorted(r["charge_class"] for r in ev)
        sc.check("zero settlement for the failed attempt (only the "
                 "claim-time ESTIMATED row; no CALCULATED / FINALIZED)",
                 classes == ["ESTIMATED"], f"classes={classes}")
        fire_transient_error(uid)
        state = wait_state(pid, uid, {"RETRY_WAIT"})
        sc.check("unit in recovery state RETRY_WAIT (not ACCEPTED)",
                 state == "RETRY_WAIT", f"state={state}")
        return sc.finish({"production_id": pid, "unit_08_12": uid,
                          "label": "STUB_TESTED"})
    finally:
        print("seed (restore canonical):", seed())


# ------------------------------------------------------------------ main
def setup():
    subprocess.run(["pg_ctlcluster", "16", "main", "start"],
                   capture_output=True)
    r = subprocess.run(["python3", str(G3 / "tools/setup_db.py"), DB],
                       capture_output=True, text=True)
    if r.returncode != 0:
        raise SystemExit(f"scratch DB setup failed: {r.stderr[-400:]}")
    print(f"db: {DB} built (registry + plans loaded by the G3 chain)")
    kill_port(8730)
    spawn([str(G3 / ".venv/bin/python"), str(G3 / "api/server.py")],
          {"FACTORY_DSN": DSN, "FACTORY_PORT": "8730", **TOKENS}, "api.log")
    if not wait_url(API + "/health"):
        raise SystemExit("API did not come up (see logs/api.log)")
    print("api: up on 8730")
    kill_port(8796)
    spawn([VENV_PY, str(PROG / "gate-e/evaluation_service/service.py")],
          {"FACTORY_DSN": DSN, "FACTORY_API_URL": API,
           "FACTORY_VALIDATOR_TOKEN": TOKENS["FACTORY_VALIDATOR_TOKEN"],
           "FACTORY_EVAL_PORT": "8796"}, "eval.log")
    if not wait_url(EVAL + "/health"):
        raise SystemExit("evaluation service did not come up (see logs/eval.log)")
    print("evaluation service: up on 8796")
    print("seed:", seed())
    return 0


def teardown():
    for port in (8730, 8795, 8796, STUB_PORT):
        kill_port(port)
    print("teardown: ports 8730/8795/8796/8799 stopped")
    return 0


if __name__ == "__main__":
    cmd = sys.argv[1] if len(sys.argv) > 1 else ""
    LOGS.mkdir(parents=True, exist_ok=True)
    RESULTS.mkdir(parents=True, exist_ok=True)
    sys.exit({"setup": setup, "run-a": run_a, "run-b": run_b,
              "run-c": run_c, "teardown": teardown}[cmd]())
