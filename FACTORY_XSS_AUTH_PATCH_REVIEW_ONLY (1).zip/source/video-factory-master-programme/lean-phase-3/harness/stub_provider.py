#!/usr/bin/env python3
"""Lean Phase 3 harness — local OpenRouter-shaped stub provider.

STUB_TESTED evidence only: implements the OpenRouter chat-completions
HTTP shape on localhost so the slice's provider mechanics (prompt
assembly, response shaping, usage/evidence recording, typed failure)
can be exercised without a credential or a paid request. It is NOT a
provider response and never presented as one; the real-provider
acceptance stays BLOCKED_EXTERNAL.

Usage: stub_provider.py <port> <mode> <record_file>
  mode ok       -> 200 with the canned script completion + usage
  mode error500 -> 500 on every request
Every request body is appended to <record_file> as one JSON line so
the harness can assert what prompt the worker actually sent.

Stub authoring note: the canned script's L2 line deliberately carries
a WRONG canon_ref and L3 omits beat_ref/story_ref — the assertions
prove the worker SETS canon_refs from the actual canon input ref and
derives beat/story refs from the scene/beat inputs, rather than
trusting the model. Canned usage: 1500 input / 700 output tokens, so
the expected CALCULATED evidence at the seeded prices
(0.0001 / 0.0005 cents per token) is 1500*0.0001 + 700*0.0005 = 0.50
cents -> 1 cent under the coordinator's ROUND_HALF_UP quantization.
"""
import json
import sys
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

PORT = int(sys.argv[1])
MODE = sys.argv[2]
RECORD = Path(sys.argv[3])

CANNED_SCRIPT = {
    "kind": "script",
    "lines": [
        {"id": "L1", "scene_ref": "SC1", "beat_ref": "B1",
         "story_ref": "S1", "canon_refs": ["stub-will-be-replaced"],
         "text": "Mara turns the brass key; the clock case swings open."},
        {"id": "L2", "scene_ref": "SC2", "beat_ref": "B2",
         "story_ref": "S2", "canon_refs": ["model-invented-ref"],
         "text": "Tobin bars the archive door and pockets the ledger."},
        {"id": "L3", "scene_ref": "SC1",
         "text": "The ledger is gone; only dust where it lay."},
    ],
    "trace": {
        "clues": [{"id": "CL1", "planted": "L1", "payoff": "L3"}],
        "knowledge": [{"character": "Mara", "learns": "CL1", "at": "L2"}],
        "payoffs": [{"id": "PO1", "clue": "CL1", "line": "L3"}]},
    "canon_refs": ["model-invented-ref"],
}


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def do_POST(self):
        raw = self.rfile.read(int(self.headers.get("Content-Length") or 0))
        try:
            body = json.loads(raw or b"{}")
        except json.JSONDecodeError:
            body = {"_unparsed": raw.decode("utf-8", errors="replace")}
        body["_path"] = self.path
        with RECORD.open("a") as fh:
            fh.write(json.dumps(body) + "\n")
        if MODE == "error500":
            payload = json.dumps({"error": "stub failure"}).encode()
            self.send_response(500)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(payload)))
            self.end_headers()
            self.wfile.write(payload)
            return
        payload = json.dumps({
            "id": "chatcmpl-stub-1",
            "choices": [{"message": {"role": "assistant",
                                     "content": json.dumps(CANNED_SCRIPT)}}],
            "usage": {"prompt_tokens": 1500, "completion_tokens": 700,
                      "total_tokens": 2200}}).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(payload)))
        self.end_headers()
        self.wfile.write(payload)


if __name__ == "__main__":
    RECORD.parent.mkdir(parents=True, exist_ok=True)
    ThreadingHTTPServer(("127.0.0.1", PORT), Handler).serve_forever()
