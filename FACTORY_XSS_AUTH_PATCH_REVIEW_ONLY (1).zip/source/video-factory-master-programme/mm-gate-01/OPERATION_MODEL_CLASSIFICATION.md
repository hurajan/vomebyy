# GATE MM-01 — Operation-Level Model Selection Specification (Classification)

**Status: ANALYST DELIVERABLE — classification complete and machine-validated (validator PASS, 27/27 checks). All PROPOSED values are labeled PROPOSED and are not owner-approved. No model names appear in this gate (model selection is MM-02).**

Machine-readable rows: `evidence/classification.json` (exactly 192 rows). Validator: `evidence/validate_classification.py`, output: `evidence/validator_output.txt`.

## 1. Sources (every field derives from a named source)

| Source | Used for |
|---|---|
| Registry seed `g1/seed-definitions/workflow-1.0.0/operations.json` (workflow 1.0.0, definition_hash `ea4503f5…`) | operation_id, station, step, title, responsibility, capability_slot, validator_policy, approval_policy, resource_ceiling, unit_key, input/output envelope schemas |
| `plans.json` (plans_hash `a71d77c6…`, post-Lean-Phase-3) | plan actions (bound implementations / UNBOUND declared classes), plan classification class, binding_status, output_artifact_type, step_deliverable, action timeouts, emit-spec deliverable schemas, unbound_reason texts |
| Gate 01 `operation_classification.json` | predecessor links (dependency templates), worker_binding (SPECIFIC/GENERIC), deliverable-schema record, L3 evidence for 11.06 |
| `g1/contracts/` (step envelopes + `deliverables/`) | structured-output existence checks — deliverable schemas exist only for the 16 step exits + op 14.01 |
| Worker action registry `gate-c/worker_service/actions.py` (+ `action_implementations.json`) | the typed action-spec vocabulary the capability labels are drawn from |
| Binding seeds: station trees' `tools/setup_env.py`; `lean-phase-3/tools/setup_slice.py` | existing binding estimates (cost_source = BINDING) |

## 2. Derivation rules (applied mechanically; each row's `class_derivation` cites its rule)

**Execution class** — from the operation's pinned plan (Gate 04 model: the plan is what executes):
- **R-DET** — plan FULLY_BOUND and every action is a deterministic engine action or the SPECIFIC `op.build_payload` builder → `DETERMINISTIC`.
- **R-AI-08.12** — 08.12's plan action is `op.generate_script`, which dispatches on the attempt's pinned binding (deterministic builder under `deterministic-local`; genuine provider generation under a provider binding; verified Lean Phases 3–4-prep) → `AI_TEXT`.
- **R-UNBOUND** — plan PARTIALLY_UNBOUND with exactly one UNBOUND declared class → that class's nature: `creative.generate`→AI_TEXT, `semantic.evaluate`→AI_EVAL, `human.decision`→HUMAN_DECISION, `media.generate`→AI_MEDIA, `media.process`/`media.render`→MEDIA_TOOL, `external.provider`/`external.platform`→EXTERNAL_SERVICE. (Every PARTIALLY_UNBOUND plan carries exactly one UNBOUND action — Gate 04, re-verified by the validator against plans.json.)
- **R-MIXED** — plan classification class is `mixed` in plans.json (7 ops: a substantive deterministic engine core plus one UNBOUND judgment element) → `MIXED`, with `mixed_elements` naming the deterministic core and the judgment element class.

**Required capabilities** — one entry per plan action, labeled from the worker action registry's typed vocabulary (bound implementation or declared UNBOUND class), plus the registry `capability_slot` (capability records remain PROPOSED — Gate 04).

**Modalities** — input: from the step's input contract and upstream artifact types (steps 01–10 records/text; 11 records + media references; 12–14 media assets + records; 15 media + platform metadata; 16 platform metrics, + participant text for 16.04–16.06). Output: from the plan's `output_artifact_type`, overridden by UNBOUND media classes (boards → image; media candidates → audio/video assets; process/render → processed/rendered media) and by step-exit deliverables.

**Structured output** — the op's emit-spec deliverable schema where the plan names one (exactly the 17 exit-style ops; files verified on disk), the step envelope schema for every op, and — for the other 175 ops — the typed action `output_spec` chain (no per-operation deliverable schema exists; see C-11).

**Context band** — L: step exits (deliverable consolidates the step chain) + ops whose title/responsibility names a whole-artifact scope (05.11 whole-story, 09.01 complete arc, 12.10 full-sequence, 13.06 full narrative). M: step-start ops whose dependency-template predecessor is the previous step's exit deliverable. S: everything else (single planned input at unit scope).

**Creative quality tier** — HIGH: AI authoring of audience-facing content (AI_TEXT in narrative/design slots — story, beats, scenes, script, people, canon, direction, shot design, derivative packaging, edit — plus all AI_MEDIA, plus MIXED 08.11). STANDARD: AI_EVAL (judgment quality bar), AI_TEXT in analytical slots (charter framing 01.04/01.07/01.11, learning proposals 16.10), MIXED-with-AI_EVAL, and provider extraction 03.03. NONE: everything else (correctness/authority is the bar).

**Latency class** — re-derived mechanically from the plan's maximum action `timeout_s`: 30 → FAST (the 50 deterministic-engine plans), 120 → STANDARD (the 19 SPECIFIC builders), 300 → LONG (all 123 PARTIALLY_UNBOUND plans — every UNBOUND action carries a 300 s timeout in the plan data).

**Maximum authorized cost** — the registry sets **no** per-operation ceiling (`resource_ceiling.max_cost_usd_per_unit` is null for all 192 ops; see C-01), so:
- FULLY_BOUND ops: the estimate of the binding that resolves for the op today — STATION-scope `deterministic-local` est **100¢** (69 ops minus 08.12), 08.12: OPERATION-scope provider binding est **25¢**. `cost_source = BINDING`.
- PARTIALLY_UNBOUND ops: no binding exists for the required element → **PROPOSED class defaults** (planning ceilings for MM-02/MM-03 to ratify or revise; NOT authorizations):

| Class | PROPOSED default | Rationale |
|---|---|---|
| AI_TEXT | 100¢ | one generation claim at the existing station-estimate scale (measured stub-era cost was 1–5¢; ceiling, not expectation) |
| AI_MEDIA | 100¢ | capped at the same scale per MM-01 discipline; real media prices will force an owner revision at MM-02/MM-06 — flagged, not hidden |
| AI_EVAL | 50¢ | one evaluation call, smaller context than authoring |
| EXTERNAL_SERVICE | 100¢ | platform/provider call at station-estimate scale |
| MEDIA_TOOL | 25¢ | local tool execution (no provider tokens); compute allowance |
| HUMAN_DECISION | 0¢ | no provider spend; human time is not metered in cents |
| MIXED | max of elements | computed per row from its named elements |

**Privacy restrictions** — derived from slot/step semantics and registry text: step 02 = rights-bearing inputs (all 12); 02.03 adds minors; step 04 = personal-data-adjacent people/identity/voice records (12) + 11.04/11.08 likeness; step 03 = source/canon content about real-world subjects (12); 01.01 = commissioner identity (named in its responsibility text); step 15 = external transmission (12), 15.06 adds credential-adjacent; 16.04/16.05 = real research participants. All other rows: `none`. (Production-IP confidentiality of narrative content is a deployment posture, not a per-op privacy restriction — boundary judgment, recorded here.)

**Validation requirement** — per row: deterministic checks (schema_validation + dependency_integrity, universal in the registry), the step's named checks (registry `validator_policy` is **step-scoped** — identical for all 12 ops of a step; recorded as such), the implemented rubric where one exists (only 08.12 `script_canon_coverage` and 12.12 `rule_of_six`), the human gate where the step's approval policy is a gate policy (step 08 → HG2, 13 → HG4, 14 → HG5, 15 → HG5 publication kind), the verbatim approval_policy, and the semantic-evaluation posture (golden set UNARMED at 0 EXPERT — AI-judged acceptance resolves REVIEW_REQUIRED → human path today).

**Plan state / current binding** — from plans.json binding_status + the Gate 04/Gate G execution record: FULLY_BOUND ops execute today via plan_exec under the STATION deterministic-local binding; PARTIALLY_UNBOUND ops are refused by plan_exec at the UNBOUND action (`UNBOUND_OPERATION`) — their `current_binding` says so plainly.

## 3. Summary tables

**Execution class distribution (192):**

| Class | Count | | Class | Count |
|---|---|---|---|---|
| DETERMINISTIC | 68 | | HUMAN_DECISION | 25 |
| AI_TEXT | 43 | | EXTERNAL_SERVICE | 11 |
| AI_EVAL | 24 | | MEDIA_TOOL | 10 |
| MIXED | 7 | | AI_MEDIA | 4 |

**By station:**

| Station | DET | AI_TEXT | AI_EVAL | HUMAN | MIXED | MEDIA_TOOL | AI_MEDIA | EXT | Total |
|---|---|---|---|---|---|---|---|---|---|
| 1 Intake & Authority | 8 | 3 | 7 | 5 | 1 | – | – | – | 24 |
| 2 Reality & People | 10 | 7 | 4 | 1 | 1 | – | – | 1 | 24 |
| 3 Narrative | 18 | 21 | 3 | 5 | 1 | – | – | – | 48 |
| 4 Direction & Capture | 10 | 8 | 5 | 6 | 2 | – | 4 | 1 | 36 |
| 5 Post & Packaging | 13 | 3 | 3 | 5 | 1 | 10 | – | 1 | 36 |
| 6 Release & Learn | 9 | 1 | 2 | 3 | 1 | – | – | 8 | 24 |

**Plan state:** FULLY_BOUND 69 (68 DETERMINISTIC + 08.12 AI_TEXT) · PARTIALLY_UNBOUND 123 — blocking classes: creative.generate 43, human.decision 28, semantic.evaluate 27, external.platform 9, media.process 9, media.generate 4, external.provider 2, media.render 1.

**Other axes:** context S 158 / M 13 / L 21 · latency FAST 50 / STANDARD 19 / LONG 123 · creative tier NONE 116 / STANDARD 32 / HIGH 44 · cost BINDING 69 / PROPOSED_CLASS_DEFAULT 123 · privacy: 139 rows `none`, 53 rows with at least one restriction.

**Reading for MM-02:** the AI surface that needs model selection is 43 AI_TEXT + 24 AI_EVAL + the AI elements inside 7 MIXED + 4 AI_MEDIA (media models/adapters — MM-06 boundary) = 74 text/eval operations; 68 DETERMINISTIC ops need no model; 25 HUMAN_DECISION ops need no model (they need the production-identity decision parked at Gate 05); 21 EXTERNAL/MEDIA_TOOL ops are tool/provider mechanics, not model selection.

## 4. Validation

`evidence/validate_classification.py` re-reads operations.json, plans.json and the contracts tree independently and checks: exactly 192 rows; id set equality with the registry; field presence/types; the taxonomy; FULLY_BOUND-deterministic ⇒ not AI_*; creative.generate-UNBOUND ⇒ not DETERMINISTIC; 08.12 = AI_TEXT; human.decision-UNBOUND ⇒ HUMAN_DECISION or MIXED-with-human-named; MIXED rows name ≥2 elements; plan_state/blocking class regenerated from plans.json; cost presence for all AI_* rows; BINDING costs equal the seeded estimates (25/100); PROPOSED costs within the stated defaults; validation_requirement non-empty everywhere; claimed deliverable schemas exist on disk and exactly match plan emit specs in both directions; latency re-derived from plan timeouts; station/step/title equal to the registry; capabilities cite plan actions; and **no model names anywhere** (MM-02 scope). **Result: PASS — 27/27 checks, exit 0** (`evidence/validator_output.txt`).

## 5. Contradiction register (sources disagreeing — recorded, not smoothed over)

- **C-01 — The registry sets no cost or latency ceilings.** `max_cost_usd_per_unit` and `wall_clock_s` are null for **all 192** operations. The approved definition source therefore cannot answer MM-01's "maximum authorized cost" — every figure in this classification comes from runtime bindings or labeled PROPOSED defaults. MM-03 must decide where ceilings authoritatively live.
- **C-02 — Registry policies are step-scoped, not operation-scoped.** `validator_policy` and `approval_policy` are identical for all 12 operations of each step (11 approval policies = 11 step values, steps 04–07 sharing EDITORIAL). Operation-level validation/approval differentiation does not exist in the source; rows inherit step policy and say so.
- **C-03 — Named semantic checks vs implemented validation (Gate 01 D05, still open).** The registry names 41 semantic checks across steps; exactly **2 implemented rubrics** exist (08.12, 12.12). All 69 FULLY_BOUND ops carry step-level named checks (e.g. 05.01 `causality_check`, 08.01 `text_fidelity`) that their deterministic execution does not perform as semantic judgment. Validation *as specified* ≠ validation *as implemented*; today the schema/continuity layers plus the human approval path carry the difference.
- **C-04 — 11.06 has test evidence on an unbound plan.** Its plan is PARTIALLY_UNBOUND (`media.generate`), yet the Gate 01 classification records L3 TESTED via a worker-service async path against a **local stub provider** (payload was stub content, settled 450¢, no n8n executor). It is the only op where "tested" could be misread as "executable" — it is not executable through the approved path.
- **C-05 — Three BOUND-BUT-THIN deterministic bindings (Gate 04 verifier).** 09.01 "Read the complete approved arc" is a structural inventory (`engine.analyze_content`), a shallow proxy for reading; 15.03 "Bind authorization to asset hash" never reads an authorization operand; 15.05's "release ID" attestation is in substance a stable idempotency key. All three are classified DETERMINISTIC (that is what executes) with the thinness recorded here.
- **C-06 — 13.03's title promises a fallback that does not exist.** "Render a review master **deterministically where possible**" — its plan declares `media.render` UNBOUND ("no media rendering engine is bound in the local stack"). There is no deterministic render path to fall back to.
- **C-07 — Same verb, opposite natures: extraction.** 03.03 "Extract claims" is `external.provider`-UNBOUND (its unbound_reason assumes a credentialed provider call), while 04.01 "Extract participants" is deterministic_engine. The registry/plan sources never state why claim extraction needs a provider and participant extraction does not — MM-02/MM-04 must resolve this explicitly rather than inherit it silently.
- **C-08 — Exit-op titles name governance acts the plan does not perform.** 05.12 "Approve Story Architecture…", 02.12 "Approve scoped Rights…Register", 07.12 "Validate redundancy", 08.12 "Run text-fidelity" (names its validator policy; its deliverable is script *production*), 09.12 "Escalate any change to truth…", 12.12 "Commit Edit Timeline". Approval, validation and commit live in the Coordinator/gates/evaluation layers. The pattern is consistent (titles describe the step's governance outcome) but any consumer reading titles as execution semantics will misclassify these ops.
- **C-09 — Two unlinked human mechanisms.** 28 ops carry a plan-level `human.decision` element; separately, approval policies name approver classes for all 192 ops, and Gate 05 verified 144 of them (including most DETERMINISTIC ops, e.g. 06.01 under EDITORIAL) are inexpressible as named approvers in the current shared-token identity model (parked AWAITING_OWNER). A fully deterministic op can thus carry a human approval requirement that exists in neither its plan nor any gate.
- **C-10 — Step-12 routing residue (RESOLVED, retained for provenance).** The Gate 01 classification originally recorded step-12 serving_tree = g6 against registry station 5; corrected by Raj's Gate 03 Option B ruling and the file's routing amendment (now g7). Any stale copy of that file reintroduces the contradiction — this classification derives station from the registry only.
- **C-11 — 14.01 breaks the exit-schema pattern.** It is the only non-.12 operation with a deliverable schema and an exit-style emit spec (`op-14.01.schema.json`, Gate G design). Consumers must not assume ".12 ⇔ deliverable schema"; the validator checks schema claims against plan emit specs in both directions instead.
- **C-12 — The rights-decision dependency loop.** `rights_decision_present` is required by validator policy in steps 02, 11 and 14, but the issuing operation 02.10 is `human.decision`-UNBOUND — the plan graph says a human-gated op issues rights decisions, while the operative factory model (G4) is operator-registered `rights_decision` artifacts created out-of-band. Both work today only because the artifact path bypasses the plan; MM-03/MM-05 must not "fix" either side without reconciling the other.

## 6. Gate posture

MM-01 PASS condition (per the governing prompt): *complete validated 192-operation coverage with no missing or contradictory bindings.* Coverage is complete (192/192, validator PASS) and every binding a row asserts was verified against its source. The contradictions in §5 are **properties of the sources**, surfaced with dispositions for MM-02/MM-03/MM-07 — none of them is a gap *in this classification*: no row invents a binding to hide one, and each contradiction names the gate that must resolve it. Whether the gate is marked PASSED is the controller's call on this evidence.
