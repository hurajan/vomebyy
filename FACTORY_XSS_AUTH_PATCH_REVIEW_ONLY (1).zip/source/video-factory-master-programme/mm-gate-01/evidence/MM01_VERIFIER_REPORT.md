# GATE MM-01 — INDEPENDENT VERIFIER REPORT

**Verifier scope:** independent re-run of the analyst's validator, independent re-derivation of 8 spot operations from source, independent arithmetic, and source-level audit of contradiction claims C-01, C-03, C-11. Read-only throughout; all facts below were taken from the sources named, not from the analyst's report.

## Item 1 — Validator re-run: **PASS**

Ran `python3 validate_classification.py` myself in `mm-gate-01/evidence/`:

- **Exit code 0.**
- **27/27 checks PASS** in my run, identical to `validator_output.txt` (row count 192, id-set equality with the registry, field presence/types, taxonomy membership, FULLY_BOUND-deterministic ⇒ not AI_*, creative.generate-UNBOUND ⇒ not DETERMINISTIC, 08.12 = AI_TEXT, human.decision rule, MIXED elements, plan_state/blocking class vs plans.json, cost presence + BINDING amounts + PROPOSED ceilings, validation_requirement non-emptiness, deliverable-schema existence and both-direction agreement with plan emit specs, latency re-derivation from plan timeouts, station/step/title vs registry, capability citations, no model names).

## Item 2 — Independent spot-derivation (8 operations): **PASS — 0 disagreements**

Each row re-derived by me from `operations.json` (registry), `plans.json` (plan actions/binding_status/plan class), and the binding seeds (`video-factory-g5/tools/setup_env.py` — STATION `deterministic-local` **est_cost_cents 100** confirmed in source; `lean-phase-3/tools/setup_slice.py` — OPERATION 08.12 **est_cost_cents 25** confirmed in source):

| Op | My derivation from source | classification.json | Agree |
|---|---|---|---|
| 01.01 | FULLY_BOUND; actions engine.manifest_inputs + op.build_payload + engine.emit_output (all deterministic) → **DETERMINISTIC**; station binding 100 → **BINDING 100** | DETERMINISTIC / FULLY_BOUND / BINDING 100 | ✓ |
| 08.12 | FULLY_BOUND; seq-2 implementation is `op.generate_script` (provider-dispatched) → **AI_TEXT**; OPERATION binding 25 → **BINDING 25**; emit spec names step-08 deliverable schema (exists on disk) | AI_TEXT / FULLY_BOUND / BINDING 25 | ✓ |
| 08.05 | 1 UNBOUND action, declared `creative.generate` → **AI_TEXT**; no binding → **PROPOSED**, AI_TEXT default 100; max timeout 300 → LONG | AI_TEXT / PARTIALLY_UNBOUND / PROPOSED 100 | ✓ |
| 02.02 | 1 UNBOUND action, declared `semantic.evaluate` → **AI_EVAL**; **PROPOSED** AI_EVAL default 50 | AI_EVAL / PARTIALLY_UNBOUND / PROPOSED 50 | ✓ |
| 02.10 | 1 UNBOUND action, declared `human.decision` → **HUMAN_DECISION**; **PROPOSED** 0 (human default) | HUMAN_DECISION / PARTIALLY_UNBOUND / PROPOSED 0 | ✓ |
| 15.02 | 1 UNBOUND action, declared `external.platform` → **EXTERNAL_SERVICE**; **PROPOSED** 100 | EXTERNAL_SERVICE / PARTIALLY_UNBOUND / PROPOSED 100 | ✓ |
| 13.03 | 1 UNBOUND action, declared `media.render` → **MEDIA_TOOL** (its class is MEDIA_TOOL, not a deterministic render — confirming C-06: the title's "deterministically where possible" has no bound implementation); **PROPOSED** MEDIA_TOOL default 25 | MEDIA_TOOL / PARTIALLY_UNBOUND / PROPOSED 25 | ✓ |
| 13.07 | plans.json plan class = `mixed`: bound deterministic engine core (extract_records, verify_fields) + 1 UNBOUND `semantic.evaluate` → **MIXED**, elements [DETERMINISTIC_ENGINE_CORE, AI_EVAL]; cost = max of elements = **PROPOSED 50**; tier STANDARD per the MIXED-with-AI_EVAL rule | MIXED / PARTIALLY_UNBOUND / PROPOSED 50 | ✓ |

No row disagrees with my derivation on execution_class, plan_state, or cost_source. (Terminology note, not a disagreement: plans.json's literal field reads `binding_status: PARTIALLY_BOUND` where the classification uses `plan_state: PARTIALLY_UNBOUND` — the Gate 04 vocabulary; both denote exactly "plan has ≥1 UNBOUND action," and the validator checks the derived semantics.)

## Item 3 — Arithmetic: **PASS**

Counted by me directly from `classification.json` (not from the report's tables):

- Class distribution: DETERMINISTIC 68 + AI_TEXT 43 + AI_EVAL 24 + HUMAN_DECISION 25 + EXTERNAL_SERVICE 11 + MEDIA_TOOL 10 + AI_MEDIA 4 + MIXED 7 = **192** ✓
- Cost sources: **BINDING 69 / PROPOSED_CLASS_DEFAULT 123**, sum 192 ✓ (69 = 68 fully-bound deterministic-binding ops + 08.12's OPERATION binding; 123 = exactly the partially-unbound set)
- Context bands: S 158 / M 13 / L 21 = **192** ✓
- Creative tiers: NONE 116 / STANDARD 32 / HIGH 44 = **192** ✓
- (Bonus) Latency: FAST 50 / STANDARD 19 / LONG 123 = 192, matching the doc.

All figures equal the analyst's summary tables exactly.

## Item 4 — Contradiction audit (from source): **PASS — all three claims confirmed**

- **C-01 CONFIRMED.** Read `resource_ceiling` for all 192 operations in `operations.json` directly: `max_cost_usd_per_unit` is null **and** `wall_clock_s` is null for **192/192** operations, with zero exceptions. The registry genuinely sets no per-operation cost/latency ceiling; every cost figure in the classification necessarily comes from bindings or labeled PROPOSED defaults, exactly as C-01 states.
- **C-03 CONFIRMED.** Registry side: distinct check names across all `validator_policy` lists = 43; the two universal deterministic checks (`schema_validation`, `dependency_integrity`) are present in all 192 policies; 43 − 2 = **41 named semantic checks**, matching the claim. Implementation side: the evaluation service (`gate-e/evaluation_service/layers.py:492`) has `RUBRICS = {"12.12": "rule_of_six", "08.12": "script_canon_coverage"}` — **exactly 2 implemented rubrics**, and the only two `_rubric_*` functions in the service. Named-vs-implemented gap is real and correctly stated. (Corroboration of C-02 en route: exactly **1** validator_policy variant and **1** approval_policy variant per step; 11 distinct approval_policy values across 192 ops.)
- **C-11 CONFIRMED.** `op-14.01.schema.json` exists in `g1/contracts/deliverables/`; operation 14.01's classification row claims exactly `contracts/deliverables/op-14.01.schema.json` (row class DETERMINISTIC, plan_state FULLY_BOUND — consistent with its plan). Counted from disk: **18 files** in `deliverables/` = 16 step schemas + `op-14.01.schema.json` + `generic-fallback.schema.json`. **17 rows claim 17 distinct deliverable schemas; no row claims generic-fallback.** Precision note (not a defect): the deliverable says "deliverable schemas exist only for the 16 step exits + op 14.01," which is exact for *operation* deliverable schemas; a reader counting raw files will find 18 because of the unclaimed generic-fallback file.

## MM-01 verdict: **PASS**

Against the gate condition — *complete validated 192-operation coverage with no missing or contradictory bindings*:

- **Complete:** 192/192 operations classified on every required axis, machine-validated (27/27 on my own re-run), with all distribution arithmetic independently reproduced.
- **No missing bindings asserted or concealed:** every binding a row claims was traced to a seed in source (station est 100¢, OPERATION 08.12 est 25¢); every unbound element is carried as PARTIALLY_UNBOUND with its blocking class named, and its cost is labeled PROPOSED, never presented as authorized.
- **The 12 documented contradictions do not make the classification itself contradictory.** Each of C-01…C-12 is a disagreement *between the factory's source artifacts* (registry vs plans vs implementation vs titles — three of them, C-01/C-03/C-11, re-verified from source above), not an inconsistency *within* the classification: no two rows conflict with each other, and no row conflicts with the sources it cites — which is precisely what the validator's cross-checks plus my 8-operation re-derivation establish. The register records each contradiction with an owning downstream gate (MM-02/MM-03/MM-05/MM-07) instead of smoothing it over, and no row invents a value to hide one. A classification that faithfully surfaces its sources' contradictions, labeled and owned, satisfies the gate; the contradictions themselves are inputs to later gates, not MM-01 failures.

**Defects: NONE.** Two non-blocking precision notes recorded above (PARTIALLY_BOUND/PARTIALLY_UNBOUND vocabulary normalization; the 18th unclaimed schema file).
