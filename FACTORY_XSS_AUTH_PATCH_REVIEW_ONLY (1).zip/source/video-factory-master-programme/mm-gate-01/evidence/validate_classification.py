#!/usr/bin/env python3
"""MM-01 classification validator.

Independently re-reads the registry seed (operations.json), plans.json and
the contracts tree, and mechanically checks evidence/classification.json:
row count, id set equality, field presence/types, execution-class
consistency rules, cost rules, validation non-emptiness, deliverable
schema existence, latency re-derivation, and the no-model-names rule
(model selection is MM-02; MM-01 must not name models).

Exit code 0 = PASS, 1 = FAIL. Output is evidence.
"""
import json
import os
import sys

BASE = os.path.dirname(os.path.abspath(__file__))
G1 = os.path.expanduser("~/workspace/video-factory-g1")
SEED = os.path.join(G1, "seed-definitions/workflow-1.0.0")
CONTRACTS = os.path.join(G1, "contracts")

failures = []
notes = []


def check(cond, label, detail=""):
    if cond:
        print(f"  PASS  {label}")
    else:
        failures.append(label)
        print(f"  FAIL  {label}  {detail}")


registry = {o["operation_id"]: o for o in json.load(open(os.path.join(SEED, "operations.json")))["operations"]}
plans = {p["operation_id"]: p for p in json.load(open(os.path.join(SEED, "plans.json")))["plans"]}
doc = json.load(open(os.path.join(BASE, "classification.json")))
rows = doc["rows"]
by_id = {r["operation_id"]: r for r in rows}

print("== MM-01 classification validation ==")
check(len(rows) == 192, "exactly 192 rows", f"got {len(rows)}")
check(len(by_id) == len(rows), "operation ids unique")
check(set(by_id) == set(registry), "operation id set == registry id set",
      f"missing={sorted(set(registry)-set(by_id))} extra={sorted(set(by_id)-set(registry))}")

REQUIRED = {
    "operation_id": str, "station": int, "step": str, "title": str,
    "execution_class": str, "class_derivation": str,
    "required_capabilities": list, "input_modality": str, "output_modality": str,
    "structured_output": dict, "context_band": str, "creative_quality_tier": str,
    "latency_class": str, "max_cost_cents": (int, float), "cost_source": str,
    "privacy_restrictions": list, "validation_requirement": dict,
    "plan_state": str, "current_binding": str,
}
CLASSES = {"DETERMINISTIC", "AI_TEXT", "AI_MEDIA", "AI_EVAL", "HUMAN_DECISION", "MEDIA_TOOL", "EXTERNAL_SERVICE", "MIXED"}
bad_type = [r["operation_id"] for r in rows
            if any(k not in r or not isinstance(r[k], t) for k, t in REQUIRED.items())]
check(not bad_type, "every required field present and typed in all rows", f"bad: {bad_type[:8]}")
bad_class = [r["operation_id"] for r in rows if r["execution_class"] not in CLASSES]
check(not bad_class, "execution_class in the MM-01 taxonomy", f"bad: {bad_class}")
bad_band = [r["operation_id"] for r in rows if r["context_band"] not in ("S", "M", "L")]
check(not bad_band, "context_band in {S,M,L}", f"bad: {bad_band}")
bad_tier = [r["operation_id"] for r in rows if r["creative_quality_tier"] not in ("NONE", "STANDARD", "HIGH")]
check(not bad_tier, "creative_quality_tier in {NONE,STANDARD,HIGH}", f"bad: {bad_tier}")
bad_lat = [r["operation_id"] for r in rows if r["latency_class"] not in ("FAST", "STANDARD", "LONG")]
check(not bad_lat, "latency_class in {FAST,STANDARD,LONG}", f"bad: {bad_lat}")

DET_IMPLS = None  # computed per plan below

def plan_unbound(p):
    return [a for a in p["actions"] if a["binding_status"] == "UNBOUND"]

def plan_is_deterministic(p):
    return all(a["binding_status"] == "BOUND" and
               (a["implementation"].startswith("engine.") or a["implementation"] == "op.build_payload")
               for a in p["actions"])

# --- rule: FULLY_BOUND + only deterministic actions (and not 08.12) => not AI_*
viol = []
for oid, r in by_id.items():
    p = plans[oid]
    if not plan_unbound(p) and plan_is_deterministic(p):
        if r["execution_class"].startswith("AI_"):
            viol.append(oid)
check(not viol, "FULLY_BOUND deterministic-only plans are not classified AI_*", f"violations: {viol}")

# --- rule: creative.generate UNBOUND => not DETERMINISTIC
viol = [oid for oid, r in by_id.items()
        if any(a.get("declared_implementation") == "creative.generate" for a in plan_unbound(plans[oid]))
        and r["execution_class"] == "DETERMINISTIC"]
check(not viol, "creative.generate-UNBOUND ops are not DETERMINISTIC", f"violations: {viol}")

# --- rule: 08.12 is AI_TEXT (provider-dispatched op.generate_script)
check(by_id["08.12"]["execution_class"] == "AI_TEXT", "08.12 classified AI_TEXT (provider-dispatched generation action)")

# --- rule: human.decision-UNBOUND => HUMAN_DECISION or MIXED with the human element named
viol = []
for oid, r in by_id.items():
    if any(a.get("declared_implementation") == "human.decision" for a in plan_unbound(plans[oid])):
        if r["execution_class"] == "HUMAN_DECISION":
            named = "human" in r["class_derivation"].lower()
        elif r["execution_class"] == "MIXED":
            named = any("HUMAN" in e for e in (r.get("mixed_elements") or []))
        else:
            named = False
        if not named:
            viol.append(oid)
check(not viol, "human.decision-UNBOUND ops are HUMAN_DECISION or MIXED with the human element named",
      f"violations: {viol}")

# --- rule: MIXED rows name at least two elements
viol = [r["operation_id"] for r in rows if r["execution_class"] == "MIXED" and len(r.get("mixed_elements") or []) < 2]
check(not viol, "MIXED rows name >= 2 elements", f"violations: {viol}")

# --- plan_state / blocking class agree with plans.json
viol = []
for oid, r in by_id.items():
    unb = plan_unbound(plans[oid])
    expect_state = "PARTIALLY_UNBOUND" if unb else "FULLY_BOUND"
    expect_block = unb[0].get("declared_implementation") if unb else None
    if r["plan_state"] != expect_state or r["blocking_action_class"] != expect_block:
        viol.append(oid)
check(not viol, "plan_state + blocking_action_class match plans.json for all rows", f"violations: {viol[:8]}")

# --- cost: present + numeric for every AI_* row; present for all rows; source labels sane
viol = [r["operation_id"] for r in rows
        if r["execution_class"].startswith("AI_") and not isinstance(r["max_cost_cents"], (int, float))]
check(not viol, "max_cost_cents present (numeric) for every AI_* row", f"violations: {viol}")
viol = [r["operation_id"] for r in rows if not isinstance(r["max_cost_cents"], (int, float))]
check(not viol, "max_cost_cents present (numeric) for every row", f"violations: {viol}")
viol = [r["operation_id"] for r in rows if r["cost_source"] not in ("BINDING", "PROPOSED_CLASS_DEFAULT")]
check(not viol, "cost_source in {BINDING, PROPOSED_CLASS_DEFAULT}", f"violations: {viol}")
viol = [r["operation_id"] for r in rows if r["cost_source"] == "BINDING"
        and r["max_cost_cents"] != (25 if r["operation_id"] == "08.12" else 100)]
check(not viol, "BINDING costs equal the seeded binding estimates (08.12 OPERATION 25c; all others STATION 100c)",
      f"violations: {viol}")
defaults = doc.get("proposed_cost_defaults_cents", {})
viol = [r["operation_id"] for r in rows if r["cost_source"] == "PROPOSED_CLASS_DEFAULT"
        and r["execution_class"] in defaults and r["max_cost_cents"] > max(defaults.values())]
check(not viol, "PROPOSED costs never exceed the stated class-default ceiling", f"violations: {viol}")

# --- validation_requirement non-empty for every row
viol = [r["operation_id"] for r in rows
        if not r["validation_requirement"].get("deterministic_checks")
        or not r["validation_requirement"].get("approval_policy")]
check(not viol, "validation_requirement non-empty (deterministic checks + approval policy) for every row",
      f"violations: {viol[:8]}")

# --- structured output: claimed deliverable schemas exist; exits claim theirs
viol = []
for r in rows:
    ds = r["structured_output"].get("deliverable_schema")
    if ds and not os.path.exists(os.path.join(G1, ds)):
        viol.append((r["operation_id"], ds))
check(not viol, "no row claims a deliverable schema that does not exist on disk", f"violations: {viol}")
missing = []
for oid, r in by_id.items():
    expect = None
    for a in plans[oid]["actions"]:
        if a.get("spec", {}).get("deliverable_schema"):
            expect = "contracts/deliverables/" + a["spec"]["deliverable_schema"]
    if expect and r["structured_output"].get("deliverable_schema") != expect:
        missing.append(oid)
check(not missing, "every op whose plan emit spec names a deliverable schema claims exactly it",
      f"violations: {missing}")
extra = [r["operation_id"] for r in rows
         if r["structured_output"].get("deliverable_schema")
         and not any(a.get("spec", {}).get("deliverable_schema") for a in plans[r["operation_id"]]["actions"])]
check(not extra, "no op claims a deliverable schema its plan does not name", f"violations: {extra}")

# --- latency re-derivation from plan timeouts
viol = []
for oid, r in by_id.items():
    maxt = max(a["timeout_s"] for a in plans[oid]["actions"])
    expect = {30: "FAST", 120: "STANDARD", 300: "LONG"}[maxt]
    if r["latency_class"] != expect:
        viol.append(oid)
check(not viol, "latency_class re-derives from plan max action timeout (30 FAST / 120 STANDARD / 300 LONG)",
      f"violations: {viol}")

# --- station/step/title agree with the registry
viol = [oid for oid, r in by_id.items()
        if r["station"] != registry[oid]["station"] or r["step"] != registry[oid]["step_id"]
        or r["title"] != registry[oid]["title"]]
check(not viol, "station/step/title match the registry for all rows", f"violations: {viol[:8]}")

# --- required_capabilities non-empty and action-sourced
viol = [r["operation_id"] for r in rows
        if len(r["required_capabilities"]) < 2 or not any("plan action" in c for c in r["required_capabilities"])]
check(not viol, "required_capabilities are non-empty and cite plan actions", f"violations: {viol[:8]}")

# --- no model names anywhere in the classification (model selection is MM-02)
MODEL_TOKENS = ["claude", "gpt-", "gpt4", "gpt5", "gemini", "llama", "mistral", "haiku",
                "sonnet", "opus", "qwen", "deepseek", "command-r", "mixtral"]
blob = json.dumps(doc).lower()
hits = [t for t in MODEL_TOKENS if t in blob]
check(not hits, "no model names/ids anywhere in the classification (MM-02 scope)", f"hits: {hits}")

import collections
dist = collections.Counter(r["execution_class"] for r in rows)
print("\nclass distribution:", dict(sorted(dist.items())))
print("cost sources:", dict(collections.Counter(r["cost_source"] for r in rows)))
print(f"\n{'VALIDATION: PASS' if not failures else 'VALIDATION: FAIL'} "
      f"({len(failures)} failing check(s))")
sys.exit(0 if not failures else 1)
