#!/usr/bin/env python3
"""Gate 05 SS4 authority battery (Master Execution Programme).

Re-proves / newly proves the coordinator authority invariants on a
scratch DB + a dedicated API instance (port 8755):

  freshness_at_claim            superseded planned input -> claim refused
  freshness_at_promotion_async  input superseded mid-flight -> provider
                                callback promotes nothing (STALE_INPUT)
  freshness_at_sync_completion  FACTUAL: the sync completion path does
                                not re-verify input currency; the stale
                                candidate is stopped at validation
  snapshot_immutability         config supersede + new plan-version row
                                mid-flight -> the attempt's pinned config
                                + plan are untouched; completion proceeds
                                under the pin
  exactly_once                  duplicate action record / duplicate
                                completion / adopt replay
  cancellation_paths            OPERATOR cancel from READY and CLAIMED
                                (the CLAIMED reservation's state is
                                recorded factually)
  stale_callback                callback for a superseded attempt ->
                                STALE_FENCING, nothing registered/settled
  failure_recovery_lease_reaper expired lease -> RETRY_WAIT -> retry ->
                                re-claim succeeds
  partial_repair                selective invalidation supersedes the
                                chain; PARTIAL_REPAIR replacements are
                                driven back to ACCEPTED

Writes one JSON per probe group into gate-05/evidence/results/.
Exit code 0 iff every probe verdict is PASS (factual probes carry
verdict PASS when the observed behavior matches the recorded fact).
"""
import json
import os
import subprocess
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path

HOME = Path.home()
G2 = HOME / "workspace" / "video-factory-g2"
G3 = HOME / "workspace" / "video-factory-g3"
sys.path.insert(0, str(G2 / "coordinator"))
sys.path.insert(0, str(G2))

from coordinator import Coordinator, StaleInput  # noqa: E402
import psycopg  # noqa: E402
from psycopg.rows import dict_row  # noqa: E402

DB = "gate05_authority_scratch"
DSN = f"host=127.0.0.1 dbname={DB} user=factory password=factory_dev_local"
PORT = 8755
BASE = f"http://127.0.0.1:{PORT}"
OPERATOR_TOKEN = "dev-operator-token"
ROLE_TOKENS = {"WORKER": "auth-worker-token", "SCHEDULER": "auth-sched-token"}
RESULTS = (HOME / "workspace" / "video-factory-master-programme" / "gate-05"
           / "evidence" / "results")
PLANS = {p["operation_id"]: p for p in json.loads(
    (HOME / "workspace" / "video-factory-g1" / "seed-definitions"
     / "workflow-1.0.0" / "plans.json").read_text())["plans"]}

RESULTS.mkdir(parents=True, exist_ok=True)


def q(sql, args=()):
    import psycopg.errors
    with psycopg.connect(DSN, row_factory=dict_row, autocommit=True) as conn:
        cur = conn.execute(sql, args)
        try:
            return cur.fetchall()
        except psycopg.errors.ProgrammingError:
            return []


def call(method, path, body=None, role=None, token=OPERATOR_TOKEN):
    req = urllib.request.Request(BASE + path, method=method)
    if role:
        req.add_header("X-Role", role)
        req.add_header("X-Role-Token", ROLE_TOKENS[role])
    elif token:
        req.add_header("X-Operator-Token", token)
    data = None
    if body is not None:
        data = json.dumps(body).encode()
        req.add_header("Content-Type", "application/json")
    try:
        with urllib.request.urlopen(req, data=data, timeout=15) as r:
            return r.status, json.loads(r.read() or b"{}")
    except urllib.error.HTTPError as e:
        raw = e.read()
        try:
            return e.code, json.loads(raw or b"{}")
        except json.JSONDecodeError:
            return e.code, {"raw": raw.decode(errors="replace")}


def start_api():
    r = subprocess.run(["python3", str(G3 / "tools" / "setup_db.py"), DB],
                       capture_output=True, text=True)
    assert r.returncode == 0, r.stdout[-400:] + r.stderr[-400:]
    env = dict(os.environ, FACTORY_DSN=DSN, FACTORY_PORT=str(PORT),
               FACTORY_WORKER_TOKEN=ROLE_TOKENS["WORKER"],
               FACTORY_SCHEDULER_TOKEN=ROLE_TOKENS["SCHEDULER"])
    proc = subprocess.Popen([str(G2 / ".venv" / "bin" / "python"),
                             str(G3 / "api" / "server.py")], env=env,
                            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    for _ in range(100):
        try:
            st, _ = call("GET", "/health", token=None)
            if st == 200:
                return proc
        except Exception:
            pass
        time.sleep(0.1)
    proc.kill()
    raise RuntimeError("authority-battery API did not come up")


def verdict(name, ok, detail):
    return {"probe": name, "verdict": "PASS" if ok else "FAIL",
            "detail": detail}


PROBES = {"freshness": [], "snapshots": [], "exactly_once": [],
          "lifecycle": []}


def library_probes():
    c = Coordinator(DSN, actor="battery:gate05")
    pid = c.create_production("Authority battery", 10_000_000, 10_000_000,
                              "battery")
    rid = c.start_run(pid, "FULL", "battery")

    def drive(uid, worker="w1", artifact_type="generic_artifact", data=b"x",
              depends=()):
        claim = c.claim(uid, worker, estimated_cents=100)
        art = c.complete_attempt(uid, worker, claim["fencing_token"],
                                 artifact_type, data, "local://x", 90,
                                 depends_on_artifact_ids=depends)
        return claim, art

    def accept(uid):
        return c.validate(uid, [{"validator": "schema_validation",
                                 "method": "contract", "verdict": "PASS",
                                 "evaluator": "battery", "evidence": {}}])

    # ---- freshness at claim
    ua = c.plan_unit(pid, rid, "01.01", "f-claim-a")
    _, art_a = drive(ua)
    accept(ua)
    ub = c.plan_unit(pid, rid, "02.01", "f-claim-b", "text", (ua,),
                     (art_a["artifact_id"],))
    c.register_artifact(pid, "generic_artifact", b"v2", "local://v2")
    stale = q("SELECT state FROM artifacts WHERE artifact_id=%s",
              (art_a["artifact_id"],))[0]["state"]
    refused = False
    try:
        c.claim(ub, "w1", estimated_cents=100)
    except StaleInput:
        refused = True
    attempts = q("SELECT count(*) AS n FROM action_attempts WHERE unit_id=%s",
                 (ub,))[0]["n"]
    PROBES["freshness"].append(verdict(
        "freshness_at_claim", refused and attempts == 0 and stale == "SUPERSEDED",
        f"input v1 state after v2 registered: {stale}; claim raised "
        f"StaleInput: {refused}; attempts created: {attempts}"))

    # ---- freshness at promotion (async provider path)
    art_y = c.register_artifact(pid, "story_architecture", b"y1", "local://y1")
    up = c.plan_unit(pid, rid, "05.12", "f-promo", "text", (),
                     (art_y["artifact_id"],))
    claim = c.claim(up, "w1", estimated_cents=100)
    c.event(up, "start")
    c.submit_provider_job_v2(up, claim["attempt_id"], claim["fencing_token"],
                             "battery-promo-1")
    assert c.get_unit(up)["state"] == "AWAITING_PROVIDER"
    c.register_artifact(pid, "story_architecture", b"y2", "local://y2")
    out = c.handle_callback("battery-promo-1", "generic_artifact", b"late",
                            "local://late", 90)
    job = q("SELECT status, raw_response FROM provider_jobs"
            " WHERE idempotency_key='battery-promo-1'")[0]
    arts = q("SELECT count(*) AS n FROM artifacts WHERE produced_by_unit=%s",
             (up,))[0]["n"]
    charges = q("SELECT count(*) AS n FROM budget_transactions"
                " WHERE production_id=%s AND kind='CHARGE'", (pid,))[0]["n"]
    PROBES["freshness"].append(verdict(
        "freshness_at_promotion_async",
        out["result"]["outcome"] == "stale_input"
        and job["status"] == "FAILED"
        and job["raw_response"]["failure_code"] == "STALE_INPUT"
        and arts == 0 and c.get_unit(up)["state"] == "RETRY_WAIT",
        f"callback outcome: {out['result']['outcome']}; job: {job['status']}/"
        f"{job['raw_response'].get('failure_code')}; artifacts produced: "
        f"{arts}; unit state: {c.get_unit(up)['state']}; production CHARGE "
        f"rows so far: {charges} (from earlier probes only)"))

    # ---- freshness at sync completion (factual)
    art_z = c.register_artifact(pid, "canon", b"z1", "local://z1")
    us = c.plan_unit(pid, rid, "03.12", "f-sync", "text", (),
                     (art_z["artifact_id"],))
    claim = c.claim(us, "w1", estimated_cents=100)  # fresh at claim time
    c.register_artifact(pid, "canon", b"z2", "local://z2")  # supersede mid-flight
    c.complete_attempt(us, "w1", claim["fencing_token"], "beat_graph",
                       b"bg", "local://bg", 90)
    state_after_complete = c.get_unit(us)["state"]
    state_after_validate = c.validate(us, [{
        "validator": "continuity_checks", "method": "continuity",
        "verdict": "FAIL", "deterministic": False, "evaluator": "battery",
        "evidence": {"problems": ["planned inputs no longer CURRENT"]}}])
    PROBES["freshness"].append(verdict(
        "freshness_at_sync_completion",
        state_after_complete == "VALIDATING"
        and state_after_validate == "REPAIR_REQUIRED",
        "FACTUAL: sync complete_attempt does not re-verify input currency "
        f"(mid-flight supersession -> completion reached {state_after_complete}); "
        "the stale candidate is stopped at the validation layer "
        f"(continuity FAIL -> {state_after_validate}), never ACCEPTED. "
        "Promotion-time currency is enforced on the async path "
        "(freshness_at_promotion_async) and at claim."))

    # ---- stale callback
    uc = c.plan_unit(pid, rid, "05.12", "cb-stale")
    claim = c.claim(uc, "w1", estimated_cents=100)
    c.event(uc, "start")
    c.submit_provider_job_v2(uc, claim["attempt_id"], claim["fencing_token"],
                             "battery-stale-1")
    c.event(uc, "transient_error")          # AWAITING_PROVIDER -> RETRY_WAIT
    c.retry_unit(uc)
    claim2 = c.claim(uc, "w2", estimated_cents=100)
    charges_before = q("SELECT count(*) AS n FROM budget_transactions"
                       " WHERE production_id=%s AND kind='CHARGE'",
                       (pid,))[0]["n"]
    out = c.handle_callback("battery-stale-1", "media", b"late",
                            "local://late", 90, reported_cost_cents=33)
    charges_after = q("SELECT count(*) AS n FROM budget_transactions"
                      " WHERE production_id=%s AND kind='CHARGE'",
                      (pid,))[0]["n"]
    job = q("SELECT status, raw_response FROM provider_jobs"
            " WHERE idempotency_key='battery-stale-1'")[0]
    arts = q("SELECT count(*) AS n FROM artifacts WHERE produced_by_unit=%s",
             (uc,))[0]["n"]
    pos = c.budget_position(pid)
    PROBES["lifecycle"].append(verdict(
        "stale_callback",
        out["result"]["outcome"] == "stale_fencing"
        and job["status"] == "FAILED"
        and job["raw_response"]["failure_code"] == "STALE_FENCING"
        and arts == 0 and c.get_unit(uc)["state"] == "CLAIMED"
        and charges_after == charges_before
        and claim2["fencing_token"] > claim["fencing_token"],
        f"old-attempt callback outcome: {out['result']['outcome']}; job: "
        f"{job['status']}/{job['raw_response'].get('failure_code')}; "
        f"artifacts: {arts}; unit state (attempt 2): "
        f"{c.get_unit(uc)['state']}; fencing {claim['fencing_token']} -> "
        f"{claim2['fencing_token']}; CHARGE rows {charges_before} -> "
        f"{charges_after} (the stale job settled nothing; its reported "
        f"33c is flagged reconciliation evidence only)"))

    # ---- failure recovery: expired lease -> reaper -> retry -> re-claim
    ur = c.plan_unit(pid, rid, "06.12", "reap")
    c.claim(ur, "w-dead", estimated_cents=100)
    q("UPDATE worker_leases SET expires_at = now() - interval '1 second'"
      " WHERE unit_id=%s", (ur,))
    moved = c.reap_expired_leases()
    state_reaped = c.get_unit(ur)["state"]
    audit_rows = q("SELECT payload FROM audit_events WHERE unit_id=%s"
                   " AND event_type='transient_error'", (ur,))
    c.retry_unit(ur)
    claim_r = c.claim(ur, "w-new", estimated_cents=100)
    PROBES["lifecycle"].append(verdict(
        "failure_recovery_lease_reaper",
        (str(ur), "RETRY_WAIT") in moved and state_reaped == "RETRY_WAIT"
        and any(r["payload"].get("via") == "lease_reaper" for r in audit_rows)
        and c.get_unit(ur)["state"] == "CLAIMED",
        f"reaper moved: {moved}; unit state after reap: {state_reaped}; "
        f"parking audit via: {[r['payload'].get('via') for r in audit_rows]}; "
        f"after retry + re-claim: {c.get_unit(ur)['state']} under "
        f"{claim_r['worker_id'] if 'worker_id' in claim_r else 'w-new'}"))

    # ---- partial repair (selective invalidation cascade)
    pa = c.plan_unit(pid, rid, "01.01", "pr-a")
    _, part_a = drive(pa, artifact_type="canon", data=b"a1")
    accept(pa)
    pb = c.plan_unit(pid, rid, "03.12", "pr-b", "text", (pa,),
                     (part_a["artifact_id"],))
    _, part_b = drive(pb, artifact_type="beat_graph", data=b"b1",
                      depends=(part_a["artifact_id"],))
    accept(pb)
    out = c.invalidate_artifact(part_a["artifact_id"], "battery repair",
                                "battery-editor")
    new_units = out["new_unit_ids"]
    import uuid as _uuid
    all_ids = [_uuid.UUID(x) for x in [pa, pb] + new_units]
    states = {str(r["unit_id"]): r["state"] for r in
              q("SELECT unit_id, state FROM execution_units"
                " WHERE unit_id = ANY(%s)", (all_ids,))}
    runs = q("SELECT kind FROM production_runs WHERE run_id IN"
             " (SELECT run_id FROM execution_units WHERE unit_id = ANY(%s))",
             ([_uuid.UUID(x) for x in new_units],))
    # drive the replacements back to ACCEPTED. The cascade leaves them
    # PENDING; the coordinator's readiness pass (the same one plan_unit /
    # validate / human_approved invoke internally) promotes them.
    c.recompute_readiness(pid)
    ready_states = {str(r["unit_id"]): r["state"] for r in
                    q("SELECT unit_id, state FROM execution_units"
                      " WHERE unit_id = ANY(%s)",
                      ([_uuid.UUID(x) for x in new_units],))}
    repl = {}
    for nu in new_units:
        row = q("SELECT operation_id FROM execution_units WHERE unit_id=%s",
                (nu,))[0]
        repl[row["operation_id"]] = nu
    _, new_a = drive(repl["01.01"], artifact_type="canon", data=b"a2")
    accept(repl["01.01"])
    drive(repl["03.12"], artifact_type="beat_graph", data=b"b2",
          depends=(new_a["artifact_id"],))
    accept(repl["03.12"])
    final = {op: c.get_unit(u)["state"] for op, u in repl.items()}
    v2 = q("SELECT state FROM artifacts WHERE artifact_id=%s",
           (new_a["artifact_id"],))[0]["state"]
    PROBES["lifecycle"].append(verdict(
        "partial_repair",
        states[pa] == "SUPERSEDED" and states[pb] == "SUPERSEDED"
        and len(new_units) == 2
        and all(r["kind"] == "PARTIAL_REPAIR" for r in runs)
        and all(s == "READY" for s in ready_states.values())
        and final == {"01.01": "ACCEPTED", "03.12": "ACCEPTED"}
        and v2 == "CURRENT",
        f"invalidated chain: originals {states[pa]}/{states[pb]}; "
        f"replacements: {len(new_units)} in run kinds "
        f"{[r['kind'] for r in runs]}, READY after the readiness pass: "
        f"{sorted(set(ready_states.values()))}; replacements driven to "
        f"{final}; new canon artifact state: {v2}"))
    c.close()


def api_probes():
    _, out = call("POST", "/productions",
                  {"title": "Authority battery API", "hard_ceiling_cents": 1000000,
                   "soft_ceiling_cents": 900000})
    pid = out["production_id"]
    _, out = call("POST", f"/productions/{pid}/runs", {"kind": "FULL"})
    rid = out["run_id"]

    def plan(op, key):
        st, o = call("POST", f"/productions/{pid}/units",
                     {"operation_id": op, "run_id": rid, "unit_key": key})
        assert st == 201, (st, o)
        return o["unit_id"]

    def claim(uid, worker):
        st, o = call("POST", f"/units/{uid}/claim",
                     {"worker_id": worker, "estimated_cents": 100})
        assert st == 200, (st, o)
        return o

    def unit_state(uid):
        _, o = call("GET", f"/productions/{pid}/units")
        return [u for u in o["units"] if u["unit_id"] == uid][0]["state"]

    def record(uid, cl, action, status="SUCCEEDED", worker="w1"):
        return call("POST", f"/units/{uid}/actions",
                    {"attempt_id": cl["attempt_id"],
                     "fencing_token": cl["fencing_token"],
                     "worker_id": worker, "action_key": action["action_key"],
                     "seq": action["seq"], "status": status},
                    role="WORKER")

    def record_plan(uid, cl, op, worker="w1"):
        for a in PLANS[op]["actions"]:
            st, o = record(uid, cl, a, worker=worker)
            assert st in (200, 201), (st, o)

    # ---- snapshot immutability (config supersede + plan-version row)
    st, cfg1 = call("POST", "/configs",
                    {"scope": "OPERATION", "operation_id": "06.12",
                     "provider": "snap-a", "est_cost_cents": 100})
    assert st == 201, (st, cfg1)
    uid = plan("06.12", "snap")
    cl = claim(uid, "w1")
    _, atts = call("GET", f"/units/{uid}/attempts")
    before = atts["attempts"][0]
    pin_before = q("SELECT plan_id, plan_version, plan_hash FROM"
                   " action_attempts WHERE attempt_id=%s",
                   (cl["attempt_id"],))[0]
    st, cfg2 = call("POST", "/configs",
                    {"scope": "OPERATION", "operation_id": "06.12",
                     "provider": "snap-b", "est_cost_cents": 200})
    assert st == 201, (st, cfg2)
    q("INSERT INTO operation_execution_plans(plan_id, workflow_version,"
      " plan_version, operation_id, capability_slot, capability_version,"
      " binding_status, plan, plan_hash, action_count, unbound_action_count)"
      " VALUES ('plan/9.9.9/06.12', '1.0.0', '9.9.9-gate05', '06.12', 'slot',"
      " '9.9.9', 'FULLY_BOUND', '{\"actions\": []}'::jsonb, 'deadbeef', 1, 0)")
    _, atts = call("GET", f"/units/{uid}/attempts")
    after = atts["attempts"][0]
    pin_after = q("SELECT plan_id, plan_version, plan_hash FROM"
                  " action_attempts WHERE attempt_id=%s",
                  (cl["attempt_id"],))[0]
    record_plan(uid, cl, "06.12")
    st, done = call("POST", f"/units/{uid}/complete",
                    {"worker_id": "w1", "fencing_token": cl["fencing_token"],
                     "artifact_type": "generic_artifact", "content": "snap",
                     "actual_cost_cents": 90})
    PROBES["snapshots"].append(verdict(
        "snapshot_immutability",
        before["resolved_config"]["provider"] == "snap-a"
        and after["resolved_config"] == before["resolved_config"]
        and after["resolved_config_hash"] == before["resolved_config_hash"]
        and pin_after == pin_before
        and pin_before["plan_id"] == cl["plan_id"]
        and pin_before["plan_hash"] == cl["plan_hash"]
        and st == 200 and done["state"] == "VALIDATING",
        f"config v{cfg1['version']} (snap-a) superseded by v{cfg2['version']} "
        f"(snap-b) + a 9.9.9-gate05 plan row inserted mid-flight; attempt "
        f"snapshot provider stayed {after['resolved_config']['provider']}, "
        f"config hash unchanged: "
        f"{after['resolved_config_hash'] == before['resolved_config_hash']}, "
        f"plan pin unchanged: {pin_after['plan_id']}/"
        f"{pin_after['plan_hash'][:12]}...; completion under the pin: "
        f"{st} {done.get('state')}"))

    # ---- exactly-once
    uid = plan("01.01", "xo")
    cl = claim(uid, "w1")
    a0 = PLANS["01.01"]["actions"][0]
    st1, r1 = record(uid, cl, a0)
    st2, r2 = record(uid, cl, a0)
    record_plan(uid, cl, "01.01")
    n_records = q("SELECT count(*) AS n FROM plan_action_attempts"
                  " WHERE unit_id=%s", (uid,))[0]["n"]
    _, budget_before = call("GET", f"/productions/{pid}/budget")
    st3, done = call("POST", f"/units/{uid}/complete",
                     {"worker_id": "w1", "fencing_token": cl["fencing_token"],
                      "artifact_type": "generic_artifact", "content": "xo",
                      "actual_cost_cents": 90})
    st4, _ = call("POST", f"/units/{uid}/complete",
                  {"worker_id": "w1", "fencing_token": cl["fencing_token"],
                   "artifact_type": "generic_artifact", "content": "xo",
                   "actual_cost_cents": 90})
    n_arts = q("SELECT count(*) AS n FROM artifacts WHERE produced_by_unit=%s",
               (uid,))[0]["n"]
    _, budget = call("GET", f"/productions/{pid}/budget")
    spent_delta = budget["spent_cents"] - budget_before["spent_cents"]
    uid2 = plan("01.02", "xo-adopt")
    cl2 = claim(uid2, "w-adopt")
    st5, ad1 = call("POST", f"/units/{uid2}/adopt",
                    {"worker_id": "w-adopt", "attempt_id": cl2["attempt_id"],
                     "idempotency_key": "battery-adopt-1"}, role="WORKER")
    st6, ad2 = call("POST", f"/units/{uid2}/adopt",
                    {"worker_id": "w-adopt", "attempt_id": cl2["attempt_id"],
                     "idempotency_key": "battery-adopt-1"}, role="WORKER")
    st7, _ = call("POST", f"/units/{uid2}/adopt",
                  {"worker_id": "w-adopt", "attempt_id": cl2["attempt_id"],
                   "idempotency_key": "battery-adopt-2"}, role="WORKER")
    PROBES["exactly_once"].append(verdict(
        "exactly_once",
        st1 == 201 and r1["recorded"] and st2 == 200 and not r2["recorded"]
        and n_records == len(PLANS["01.01"]["actions"])
        and st3 == 200 and st4 in (400, 409) and n_arts == 1
        and spent_delta == 90
        and st5 == 200 and ad1["fresh"] and st6 == 200 and not ad2["fresh"]
        and ad2["fencing_token"] == ad1["fencing_token"] and st7 == 409,
        f"duplicate action record: {st1}/recorded={r1['recorded']} then "
        f"{st2}/recorded={r2['recorded']} (rows for the unit after full "
        f"plan posted: {n_records} = plan size); duplicate completion: "
        f"{st3} then {st4}, artifacts={n_arts}, spent delta={spent_delta} "
        f"(single 90 charge); adopt replay: fresh={ad1['fresh']} then "
        f"fresh={ad2['fresh']} same fencing, different key -> {st7}"))

    # ---- cancellation paths
    uid_r = plan("01.03", "cancel-ready")
    st, out = call("POST", f"/units/{uid_r}/events", {"event": "cancel"})
    ready_cancel = (st == 200 and out["state"] == "CANCELLED")
    uid_c = plan("01.04", "cancel-claimed")
    cl_c = claim(uid_c, "w1")
    st, out = call("POST", f"/units/{uid_c}/events", {"event": "cancel"})
    res = q("SELECT state FROM budget_reservations WHERE reservation_id ="
            " (SELECT reservation_id FROM action_attempts WHERE unit_id=%s"
            "  AND attempt_no=1)", (uid_c,))[0]["state"]
    PROBES["lifecycle"].append(verdict(
        "cancellation_paths",
        ready_cancel and st == 200 and out["state"] == "CANCELLED",
        f"READY unit cancel -> CANCELLED: {ready_cancel}; CLAIMED unit "
        f"cancel -> {out.get('state')}; FACTUAL: the event-path cancel "
        f"leaves the claim's budget reservation {res} (it is not released "
        "by the events path — pre-existing behavior, unchanged by "
        "Gate 05; reservation release lives in the retry/settle paths)"))


def main():
    proc = start_api()
    try:
        library_probes()
        api_probes()
    finally:
        proc.terminate()
        try:
            proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            proc.kill()
    groups = {"freshness": "freshness.json",
              "snapshots": "snapshot_immutability.json",
              "exactly_once": "exactly_once.json",
              "lifecycle": "cancellation_callback_repair.json"}
    failed = []
    for group, fname in groups.items():
        rows = PROBES[group]
        (RESULTS / fname).write_text(json.dumps(
            {"battery": f"gate05_authority_{group}", "probes": rows},
            indent=2))
        for r in rows:
            print(f"{r['verdict']}  {r['probe']}: {r['detail']}")
            if r["verdict"] != "PASS":
                failed.append(r["probe"])
    print("AUTHORITY BATTERY:", "FAIL " + str(failed) if failed else "ALL PASS")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
