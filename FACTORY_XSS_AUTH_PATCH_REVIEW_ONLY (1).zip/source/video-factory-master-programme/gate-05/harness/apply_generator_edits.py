#!/usr/bin/env python3
"""Gate 05 generator edits, applied uniformly to the five station trees.

1. http() gains an `identity` parameter (X-Identity header).
2. The error-handler workflow re-authenticates as WORKER with the tree's
   executor identity and presents worker_id in the /events body
   (Gate 05 per-event matrix: transient_error is WORKER-class; SCHEDULER
   may fire no events).
3. The executor Assemble node adds worker_id to the /work payload (the
   worker service's action-record sink must present the attempt's worker
   identity to POST /units/{uid}/actions).
4. Header docstring role summary updated.
Each replacement must occur exactly once per file; anything else aborts.
"""
import sys
from pathlib import Path

TREES = ["g4", "g5", "g6", "g7", "g8"]

EDITS = [
    # 1. http() signature + identity header
    ('def http(name, method, url, body=None, x=0, on_error=None, role="WORKER"):',
     'def http(name, method, url, body=None, x=0, on_error=None, role="WORKER",\n'
     '         identity=None):'),
    ('    elif role is not None:\n'
     '        raise ValueError(f"unknown role {role}")\n'
     '    p = {"method": method,',
     '    elif role is not None:\n'
     '        raise ValueError(f"unknown role {role}")\n'
     '    if identity:\n'
     '        headers.append({"name": "X-Identity", "value": identity})\n'
     '    p = {"method": method,'),
    # 2. error handler: WORKER + identity + worker_id body field
    ('         "{ event: $json.event, error_class: $json.error_class }", 460,\n'
     '         role="SCHEDULER"),',
     '         "{ event: $json.event, error_class: $json.error_class,"\n'
     '         " worker_id: \'" + EXECUTOR_WORKER_ID + "\' }", 460,\n'
     '         role="WORKER", identity=EXECUTOR_WORKER_ID),'),
    # 4. docstring role summary
    ("event reports = SCHEDULER",
     "event reports = WORKER (executor identity, Gate 05)"),
    # 3. assemble payload worker_id. NOTE (as applied): the identity is
    # embedded as the tree's literal ('n8n-executor-gN' == the tree's
    # EXECUTOR_WORKER_ID constant) inside the JS string — an earlier
    # string-concatenation variant was reverted in-pass because the
    # anchor sat inside a single triple-quoted literal; the embedded
    # literal produces byte-identical workflow content to the claim
    # bodies' concatenation.
]

COMMENT_ANCHOR = 'eh = workflow(WF["errorhandler"], '
COMMENT = (
    "# Gate 05 (G01-D07): the error handler reports transient_error - a\n"
    "# WORKER-class event under the per-event matrix. It authenticates as\n"
    "# WORKER with this tree's executor identity (X-Identity header + body\n"
    "# worker_id, which the API binds to the attempt's claim identity).\n"
    "# Before Gate 05 it used the SCHEDULER role, which may fire no events.\n")


def main():
    for tree in TREES:
        path = Path.home() / "workspace" / f"video-factory-{tree}" / "tools" / "gen_workflows.py"
        text = path.read_text()
        for old, new in EDITS:
            count = text.count(old)
            if count != 1:
                print(f"ABORT {tree}: anchor occurs {count}x: {old[:60]!r}")
                return 1
            text = text.replace(old, new)
        idx = text.find(COMMENT_ANCHOR)
        if idx < 0 or text.count(COMMENT_ANCHOR) != 1:
            print(f"ABORT {tree}: comment anchor problem")
            return 1
        text = text[:idx] + COMMENT + text[idx:]
        path.write_text(text)
        print(f"{tree}: edits applied")
    return 0


if __name__ == "__main__":
    sys.exit(main())
