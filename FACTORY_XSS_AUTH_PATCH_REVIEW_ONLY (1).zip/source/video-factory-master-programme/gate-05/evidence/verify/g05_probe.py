"""Gate 05 INDEPENDENT verifier probes (G05-T01..T09 + exhaustive event x role sweep).
Own scratch stack: API on port 8739 against the chain-built g3_dashboard_scratch DB.
Fixtures via API; tested actions via API; DB assertions via sudo psql.
"""
import json, os, re, subprocess, sys, time, urllib.request, urllib.error

BASE = "http://127.0.0.1:8739"
OP_TOKEN = "dev-operator-token"
ROLE_TOKENS = {"WORKER": "g05v-worker", "SCHEDULER": "g05v-sched",
               "VALIDATOR": "g05v-valid", "CALLBACK": "g05v-callback"}
WORKER_ID = "wv-verify"
RESULTS = {}

def req(method, path, role=None, body=None, identity=None, worker_id_body=None):
    data = None
    headers = {"Content-Type": "application/json"}
    if role == "OPERATOR" or role is None:
        headers["X-Operator-Token"] = OP_TOKEN
        if identity: headers["X-Identity"] = identity
    else:
        headers["X-Role"] = role
        headers["X-Role-Token"] = ROLE_TOKENS[role]
        if identity: headers["X-Identity"] = identity
    if body is not None:
        data = json.dumps(body).encode()
    r = urllib.request.Request(BASE + path, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(r, timeout=30) as resp:
            return resp.status, json.loads(resp.read() or b"{}")
    except urllib.error.HTTPError as e:
        try: payload = json.loads(e.read() or b"{}")
        except Exception: payload = {}
        return e.code, payload

def sql(query):
    out = subprocess.run(["sudo", "-u", "postgres", "psql", "-d", "g3_dashboard_scratch",
                          "-Atc", query], capture_output=True, text=True)
    return out.stdout.strip()

def unit_state(uid):
    return sql(f"SELECT state FROM execution_units WHERE unit_id='{uid}'")

def audit_count(uid, etype):
    return int(sql(f"SELECT count(*) FROM audit_events WHERE unit_id='{uid}' AND event_type='{etype}'") or 0)

def plan_actions(op):
    raw = sql(f"SELECT plan::text FROM operation_execution_plans WHERE operation_id='{op}'")
    return json.loads(raw)["actions"]

def fixture(op, worker=WORKER_ID):
    s, p = req("POST", "/productions", "OPERATOR",
               {"title": "g05v", "hard_ceiling_cents": 100000000, "soft_ceiling_cents": 100000000})
    pid = p["production_id"]
    s, r = req("POST", f"/productions/{pid}/runs", "OPERATOR", {"kind": "FULL"})
    rid = r["run_id"]
    s, u = req("POST", f"/productions/{pid}/units", "OPERATOR",
               {"operation_id": op, "run_id": rid})
    uid = u["unit_id"]
    s, claim = req("POST", f"/units/{uid}/claim", "WORKER", {"worker_id": worker})
    assert s == 200, (s, claim)
    return pid, uid, claim

def post_records(uid, claim, op, worker=WORKER_ID, skip_last=False, last_status=None, role="WORKER"):
    acts = plan_actions(op)
    codes = []
    for i, a in enumerate(acts):
        if skip_last and i == len(acts) - 1:
            if last_status is None: continue
            status = last_status
        else:
            status = "SUCCEEDED"
        s, b = req("POST", f"/units/{uid}/actions", role,
                   {"attempt_id": claim["attempt_id"], "fencing_token": claim["fencing_token"],
                    "action_key": a["action_key"], "seq": a["seq"], "status": status,
                    "worker_id": worker})
        codes.append(s)
    return codes

def complete(uid, claim, worker=WORKER_ID, fencing=None, atype="generic_artifact"):
    s, b = req("POST", f"/units/{uid}/complete", "WORKER",
               {"worker_id": worker, "fencing_token": fencing if fencing is not None else claim["fencing_token"],
                "artifact_type": atype, "content": f"g05v content for {uid}",
                "actual_cost_cents": 90})
    return s, b

def to_awaiting_human(op="01.01", worker=WORKER_ID):
    pid, uid, claim = fixture(op, worker)
    post_records(uid, claim, op, worker)
    s, b = complete(uid, claim, worker)
    assert s == 200 and unit_state(uid) == "VALIDATING", (s, b, unit_state(uid))
    s, b = req("POST", f"/units/{uid}/validate", "VALIDATOR",
               {"verdict": "REVIEW_REQUIRED", "validator": "g05-verifier"})
    assert s == 200 and unit_state(uid) == "AWAITING_HUMAN", (s, b, unit_state(uid))
    return uid, claim

def record(tid, ok, detail):
    RESULTS[tid] = {"ok": bool(ok), "detail": detail}
    print(tid, "PASS" if ok else "FAIL", "-", detail)

# ---------------------------------------------------------------- T01/T02/T03/T04
uidA, claimA = to_awaiting_human()
before_refused = audit_count(uidA, "event_refused")
s, b = req("POST", f"/units/{uidA}/events", "WORKER", {"event": "human_approved"}, identity=WORKER_ID)
t01 = (s == 403 and unit_state(uidA) == "AWAITING_HUMAN"
       and audit_count(uidA, "event_refused") == before_refused + 1)
record("G05-T01", t01, f"WORKER human_approved -> {s} {b.get('error','')}; state={unit_state(uidA)}; event_refused +1")

s, b = req("POST", f"/units/{uidA}/events", "SCHEDULER", {"event": "human_approved"}, identity="sched")
t02 = (s == 403 and unit_state(uidA) == "AWAITING_HUMAN"
       and audit_count(uidA, "event_refused") == before_refused + 2)
record("G05-T02", t02, f"SCHEDULER human_approved -> {s}; state={unit_state(uidA)}; event_refused +2 total")

types_before = sql(f"SELECT DISTINCT event_type FROM audit_events WHERE unit_id='{uidA}' ORDER BY 1")
s1, _ = req("POST", f"/units/{uidA}/events", "OPERATOR", {"event": "bogus_event_xyz"})
s2, _ = req("POST", f"/units/{uidA}/events", "WORKER", {"event": "bogus_event_xyz"}, identity=WORKER_ID)
types_after = sql(f"SELECT DISTINCT event_type FROM audit_events WHERE unit_id='{uidA}' ORDER BY 1")
new_types = set(types_after.split("\n")) - set(types_before.split("\n"))
t03 = (s1 == 403 and s2 == 403 and unit_state(uidA) == "AWAITING_HUMAN"
       and new_types <= {"event_refused"}
       and audit_count(uidA, "event_refused") == before_refused + 4)
record("G05-T03", t03, f"unknown event OPERATOR->{s1} WORKER->{s2}; state unchanged; new audit types={new_types}")

s, b = req("POST", f"/units/{uidA}/events", "OPERATOR", {"event": "human_approved"}, identity="verifier-human")
pol = sql(f"SELECT payload::text FROM audit_events WHERE unit_id='{uidA}' AND event_type='approval_policy_applied'")
t04 = (s == 200 and unit_state(uidA) == "ACCEPTED" and "PRODUCER_AND_BUDGET_OWNER" in pol
       and "human_approved" in pol)
record("G05-T04", t04, f"OPERATOR human_approved -> {s}; state={unit_state(uidA)}; approval_policy_applied: {pol[:220]}")

# ---------------------------------------------------------------- T05 legitimate worker flow
pidB, uidB, claimB = fixture("01.01")
s, b = req("POST", f"/units/{uidB}/events", "WORKER", {"event": "start", "worker_id": WORKER_ID}, identity=WORKER_ID)
start_ok = (s == 200 and unit_state(uidB) == "RUNNING")
post_records(uidB, claimB, "01.01")
s, b = complete(uidB, claimB)
comp_ok = (s == 200 and unit_state(uidB) == "VALIDATING")
s, b = req("POST", f"/units/{uidB}/validate", "VALIDATOR",
           {"verdict": "PASS", "validator": "g05-verifier", "deterministic": True})
val_ok = (s == 200 and unit_state(uidB) == "ACCEPTED")
pidC, uidC, claimC = fixture("01.01")
s, b = req("POST", f"/units/{uidC}/events", "WORKER",
           {"event": "transient_error", "worker_id": WORKER_ID, "error_class": "WORKER_ERROR"}, identity=WORKER_ID)
te_ok = (s == 200 and unit_state(uidC) == "RETRY_WAIT")
# error-handler producer pattern: pre-claim block from the entitled executor identity (g4 tree for steps 01-04)
sys.path.insert(0, "/home/hatch/workspace/video-factory-g2/coordinator")
from coordinator import executor_worker_id_for_operation
ent = executor_worker_id_for_operation("02.12")
s, p = req("POST", "/productions", "OPERATOR", {"title": "g05v-d", "hard_ceiling_cents": 100000000, "soft_ceiling_cents": 100000000})
pidD = p["production_id"]
s, r = req("POST", f"/productions/{pidD}/runs", "OPERATOR", {"kind": "FULL"})
s, u = req("POST", f"/productions/{pidD}/units", "OPERATOR", {"operation_id": "02.12", "run_id": r["run_id"]})
uidD = u["unit_id"]
s, b = req("POST", f"/units/{uidD}/events", "WORKER",
           {"event": "block", "worker_id": ent, "error_class": "RIGHTS_BLOCKED"}, identity=ent)
block_ok = (s == 200 and unit_state(uidD) == "BLOCKED")
s, p2 = req("POST", "/productions", "OPERATOR", {"title": "g05v-d2", "hard_ceiling_cents": 100000000, "soft_ceiling_cents": 100000000})
s, r2 = req("POST", f"/productions/{p2['production_id']}/runs", "OPERATOR", {"kind": "FULL"})
s, u2 = req("POST", f"/productions/{p2['production_id']}/units", "OPERATOR", {"operation_id": "02.12", "run_id": r2["run_id"]})
uidD2 = u2["unit_id"]
s, b = req("POST", f"/units/{uidD2}/events", "WORKER",
           {"event": "block", "worker_id": "mallory", "error_class": "RIGHTS_BLOCKED"}, identity="mallory")
block_bad = (s == 403 and unit_state(uidD2) == "READY")
record("G05-T05", start_ok and comp_ok and val_ok and te_ok and block_ok and block_bad,
       f"start={start_ok} complete={comp_ok} validate->ACCEPTED={val_ok} transient_error->RETRY_WAIT={te_ok} "
       f"pre-claim block by entitled {ent}={block_ok} block by mallory 403={block_bad}")

# ---------------------------------------------------------------- T06 barrier
pidE, uidE, claimE = fixture("06.01")
s, b = complete(uidE, claimE)
bar1 = (s == 409 and audit_count(uidE, "completion_barrier_refused") >= 1 and unit_state(uidE) == "CLAIMED")
actsE = plan_actions("06.01")
codes = post_records(uidE, claimE, "06.01", skip_last=True, last_status=None)
s, b = complete(uidE, claimE)
bar2 = (s == 409 and unit_state(uidE) == "CLAIMED")
last = actsE[-1]
s, b = req("POST", f"/units/{uidE}/actions", "WORKER",
           {"attempt_id": claimE["attempt_id"], "fencing_token": claimE["fencing_token"],
            "action_key": last["action_key"], "seq": last["seq"], "status": "SUCCEEDED", "worker_id": WORKER_ID})
s, b = complete(uidE, claimE)
bar3 = (s == 200 and unit_state(uidE) == "VALIDATING")
pidE2, uidE2, claimE2 = fixture("01.01")
post_records(uidE2, claimE2, "01.01", skip_last=True, last_status="REFUSED")
s, b = complete(uidE2, claimE2)
bar4 = (s == 409 and unit_state(uidE2) == "CLAIMED")
record("G05-T06", bar1 and bar2 and bar3 and bar4,
       f"no-records complete={bar1} (409+audit) missing-last={bar2} full-records complete 200={bar3} REFUSED-record blocks={bar4}; 06.01 plan actions={len(actsE)}")

# ---------------------------------------------------------------- T07 forged records
pidF, uidF, claimF = fixture("01.01")
a0 = plan_actions("01.01")[0]
def try_record(**over):
    body = {"attempt_id": claimF["attempt_id"], "fencing_token": claimF["fencing_token"],
            "action_key": a0["action_key"], "seq": a0["seq"], "status": "SUCCEEDED",
            "worker_id": WORKER_ID}
    body.update(over)
    return req("POST", f"/units/{uidF}/actions", "WORKER", body, identity=WORKER_ID)
s1, _ = try_record(fencing_token=claimF["fencing_token"] + 999)
s2, _ = try_record(worker_id="mallory")
s3, _ = try_record(action_key="zz_not_in_plan", seq=99)
s4, _ = try_record(attempt_id="00000000-0000-0000-0000-000000000000")
rowsF = int(sql(f"SELECT count(*) FROM plan_action_attempts WHERE unit_id='{uidF}'") or -1)
s5, _ = complete(uidF, claimF)
t07 = (s1 in (400, 403, 409) and s2 == 403 and s3 in (400, 403, 409) and s4 in (400, 403, 409)
       and rowsF == 0 and s5 == 409 and audit_count(uidF, "action_record_refused") >= 1)
record("G05-T07", t07, f"forged fencing->{s1} wrong identity->{s2} out-of-plan->{s3} foreign attempt->{s4}; "
                       f"records persisted={rowsF}; complete still 409={s5==409}; action_record_refused audits={audit_count(uidF,'action_record_refused')}")

# ---------------------------------------------------------------- T08 stale attempt
pidG, uidG, claimG = fixture("01.01")
sql(f"UPDATE worker_leases SET expires_at = now() - interval '1 minute' WHERE unit_id='{uidG}'")
src = open("/home/hatch/workspace/video-factory-g3/api/server.py").read()
dsn = re.search(r'os\.environ\.get\(\s*"FACTORY_DSN",\s*"([^"]+)"', src).group(1)
sys.path.insert(0, "/home/hatch/workspace/video-factory-g2/coordinator")
from coordinator import Coordinator
co = Coordinator(dsn, actor="g05-verifier")
moved = co.reap_expired_leases()
co.close()
reaped = unit_state(uidG) == "RETRY_WAIT"
s, b = req("POST", f"/units/{uidG}/retry", "OPERATOR", {})
s, claimG2 = req("POST", f"/units/{uidG}/claim", "WORKER", {"worker_id": WORKER_ID})
f_changed = claimG2.get("fencing_token") != claimG["fencing_token"]
post_records(uidG, claimG2, "01.01")
s_old, b_old = complete(uidG, claimG2, fencing=claimG["fencing_token"])
stale_refused = (s_old in (403, 409) and unit_state(uidG) == "CLAIMED")
s_new, b_new = complete(uidG, claimG2)
fresh_ok = (s_new == 200 and unit_state(uidG) == "VALIDATING")
record("G05-T08", reaped and f_changed and stale_refused and fresh_ok,
       f"reaped={reaped} fencing bumped={f_changed} ({claimG['fencing_token']}->{claimG2.get('fencing_token')}) "
       f"stale complete->{s_old} refused={stale_refused} current complete={s_new}")

# ---------------------------------------------------------------- T09 identity mismatch surfaces
s, p = req("POST", "/productions", "OPERATOR", {"title": "g05v-h", "hard_ceiling_cents": 100000000, "soft_ceiling_cents": 100000000})
pidH = p["production_id"]
s, r = req("POST", f"/productions/{pidH}/runs", "OPERATOR", {"kind": "FULL"})
s, u = req("POST", f"/productions/{pidH}/units", "OPERATOR", {"operation_id": "01.01", "run_id": r["run_id"]})
uidH = u["unit_id"]
entH = executor_worker_id_for_operation("01.01")
co = Coordinator(dsn, actor="g05-verifier")
claimH = co.claim(uidH, entH, estimated_cents=100)
co.close()
s_bad, b_bad = req("POST", f"/units/{uidH}/adopt", "WORKER",
                   {"worker_id": "mallory", "attempt_id": claimH["attempt_id"], "idempotency_key": "g05v-bad"}, identity="mallory")
adopt_bad = (s_bad == 409)
s_ok, b_ok = req("POST", f"/units/{uidH}/adopt", "WORKER",
                 {"worker_id": entH, "attempt_id": claimH["attempt_id"], "idempotency_key": "g05v-ok"}, identity=entH)
adopt_ok = (s_ok == 200 and b_ok.get("fencing_token") == claimH["fencing_token"])
claimH2 = {"attempt_id": claimH["attempt_id"], "fencing_token": b_ok.get("fencing_token", claimH["fencing_token"])}
a0 = plan_actions("01.01")[0]
s_rec, _ = req("POST", f"/units/{uidH}/actions", "WORKER",
               {"attempt_id": claimH2["attempt_id"], "fencing_token": claimH2["fencing_token"],
                "action_key": a0["action_key"], "seq": a0["seq"], "status": "SUCCEEDED", "worker_id": "mallory"},
               identity="mallory")
rec_bad = (s_rec == 403)
post_records(uidH, claimH2, "01.01", worker=entH)
s_comp_bad, _ = complete(uidH, claimH2, worker="mallory")
comp_bad = (s_comp_bad in (403, 409) and unit_state(uidH) == "CLAIMED")
s_comp, _ = complete(uidH, claimH2, worker=entH)
comp_ok = (s_comp == 200 and unit_state(uidH) == "VALIDATING")
record("G05-T09", adopt_bad and adopt_ok and rec_bad and comp_bad and comp_ok,
       f"adopt as mallory->{s_bad} adopt as {entH}->200 fencing returned={adopt_ok} "
       f"action record as mallory->{s_rec} complete as mallory->{s_comp_bad} complete as entitled={s_comp}")

# ---------------------------------------------------------------- exhaustive sweep
EVENTS = ["claim", "start", "await_provider", "provider_resumed", "submit_candidate",
          "validation_passed", "validation_failed_content", "validation_failed_deterministic",
          "validation_needs_human", "human_approved", "human_rejected", "transient_error",
          "provider_unknown", "reconciled_submitted", "reconciled_failed", "retry_ready",
          "repair_ready", "cancel", "block", "bogus_event_xyz"]
sweep = {}
base_units = {}
for role in ("WORKER", "SCHEDULER", "VALIDATOR", "CALLBACK"):
    u, cl = to_awaiting_human()
    base_units[role] = (u, cl)
op_base, op_claim = to_awaiting_human()
for role in ("OPERATOR", "WORKER", "SCHEDULER", "VALIDATOR", "CALLBACK"):
    sweep[role] = {}
    for ev in EVENTS:
        if role == "OPERATOR" and ev in ("human_approved", "human_rejected"):
            u, cl = to_awaiting_human()
            s, b = req("POST", f"/units/{u}/events", "OPERATOR", {"event": ev}, identity="verifier-human")
            sweep[role][ev] = s
            continue
        u, cl = (op_base, op_claim) if role == "OPERATOR" else base_units[role]
        body = {"event": ev}
        if role == "WORKER": body["worker_id"] = WORKER_ID
        s, b = req("POST", f"/units/{u}/events", role, body, identity=(WORKER_ID if role == "WORKER" else None))
        sweep[role][ev] = s
states_ok = all(unit_state(u) == "AWAITING_HUMAN" for u, cl in list(base_units.values())) and unit_state(op_base) == "AWAITING_HUMAN"
RESULTS["SWEEP"] = {"table": sweep, "base_states_unchanged": states_ok}
print("SWEEP base states unchanged:", states_ok)
print(json.dumps(sweep, indent=1))

json.dump(RESULTS, open("/tmp/g05_probe_results.json", "w"), indent=1)
fails = [k for k, v in RESULTS.items() if isinstance(v, dict) and v.get("ok") is False]
print("PROBE DONE. fails:", fails)
