import json, subprocess, sys
sys.path.insert(0, "/tmp")
# reuse probe helpers by importing the module would re-run everything; instead inline minimal client
import urllib.request, urllib.error
BASE = "http://127.0.0.1:8739"
def req(method, path, role=None, body=None):
    h = {"Content-Type": "application/json"}
    if role == "OPERATOR": h["X-Operator-Token"] = "dev-operator-token"
    else: h.update({"X-Role": role, "X-Role-Token": {"WORKER": "g05v-worker", "VALIDATOR": "g05v-valid"}[role]})
    d = json.dumps(body).encode() if body is not None else None
    r = urllib.request.Request(BASE + path, data=d, headers=h, method=method)
    try:
        with urllib.request.urlopen(r, timeout=30) as resp: return resp.status, json.loads(resp.read() or b"{}")
    except urllib.error.HTTPError as e:
        try: return e.code, json.loads(e.read() or b"{}")
        except Exception: return e.code, {}
def sql(q):
    return subprocess.run(["sudo", "-u", "postgres", "psql", "-d", "g3_dashboard_scratch", "-Atc", q],
                          capture_output=True, text=True).stdout.strip()
s, p = req("POST", "/productions", "OPERATOR", {"title": "g05v-e2", "hard_ceiling_cents": 100000000, "soft_ceiling_cents": 100000000})
pid = p["production_id"]
s, r = req("POST", f"/productions/{pid}/runs", "OPERATOR", {"kind": "FULL"})
s, u = req("POST", f"/productions/{pid}/units", "OPERATOR", {"operation_id": "01.01", "run_id": r["run_id"]})
uid = u["unit_id"]
s, claim = req("POST", f"/units/{uid}/claim", "WORKER", {"worker_id": "wv-verify"})
acts = json.loads(sql("SELECT plan::text FROM operation_execution_plans WHERE operation_id='01.01'"))["actions"]
print("unit", uid, "actions", [a["action_key"] for a in acts])
for i, a in enumerate(acts):
    status = "REFUSED" if i == len(acts) - 1 else "SUCCEEDED"
    s, b = req("POST", f"/units/{uid}/actions", "WORKER",
               {"attempt_id": claim["attempt_id"], "fencing_token": claim["fencing_token"],
                "action_key": a["action_key"], "seq": a["seq"], "status": status, "worker_id": "wv-verify"})
    print("record", a["action_key"], status, "->", s, b)
print("rows:", sql(f"SELECT action_key||':'||status FROM plan_action_attempts WHERE unit_id='{uid}' ORDER BY seq"))
s, b = req("POST", f"/units/{uid}/complete", "WORKER",
           {"worker_id": "wv-verify", "fencing_token": claim["fencing_token"], "artifact_type": "generic_artifact",
            "content": "x", "actual_cost_cents": 90})
print("complete ->", s, b)
print("state:", sql(f"SELECT state FROM execution_units WHERE unit_id='{uid}'"))
print("barrier audits:", sql(f"SELECT payload::text FROM audit_events WHERE unit_id='{uid}' AND event_type='completion_barrier_refused'"))
