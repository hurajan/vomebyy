import json, re, subprocess, sys, urllib.request, urllib.error
BASE = "http://127.0.0.1:8739"
def req(method, path, role="OPERATOR", body=None):
    h = {"Content-Type": "application/json", "X-Operator-Token": "dev-operator-token"}
    d = json.dumps(body).encode() if body is not None else None
    r = urllib.request.Request(BASE + path, data=d, headers=h, method=method)
    try:
        with urllib.request.urlopen(r, timeout=30) as resp: return resp.status, json.loads(resp.read() or b"{}")
    except urllib.error.HTTPError as e:
        try: return e.code, json.loads(e.read() or b"{}")
        except Exception: return e.code, {}
def sql(q):
    return subprocess.run(["sudo", "-u", "postgres", "psql", "-d", "g3_dashboard_scratch", "-Atc", q],
                          capture_output=True, text=True).stdout.strip()
src = open("/home/hatch/workspace/video-factory-g3/api/server.py").read()
dsn = re.search(r'os\.environ\.get\(\s*"FACTORY_DSN",\s*"([^"]+)"', src).group(1)
sys.path.insert(0, "/home/hatch/workspace/video-factory-g2/coordinator")
from coordinator import Coordinator
co = Coordinator(dsn, actor="g05-verifier")
pid = co.create_production("g05v-gate", 100000000, 100000000, "g05-verifier")
rid = co.start_run(pid, "FULL", "g05-verifier")
art = co.register_artifact(pid, "script", json.dumps({"kind": "script", "lines": ["INT. TEST - DAY"]}).encode(), "local://script1")
aid = art["artifact_id"] if isinstance(art, dict) else art
print("script artifact:", aid, "type:", sql(f"SELECT artifact_type FROM artifacts WHERE artifact_id='{aid}'"))
uid = co.plan_unit(pid, rid, "09.01", input_artifact_ids=(aid,))
co.close()
s, b = req("POST", f"/units/{uid}/claim", "OPERATOR", {"worker_id": "wv-verify"})
print("claim without approved HG2 ->", s, b.get("error", b))
refused_rows = sql(f"SELECT count(*) FROM audit_events WHERE unit_id='{uid}' AND event_type='gate_claim_refused'")
# create + approve the HG2 gate bound to this artifact, then claim again
co = Coordinator(dsn, actor="g05-verifier")
gate = co.create_gate(pid, "HG2", aid)
gid = gate["gate_id"] if isinstance(gate, dict) else gate
print("gate:", gid, gate if isinstance(gate, dict) else "")
co.decide_gate(gid, "APPROVED", "verifier-human")
co.close()
s, b = req("POST", f"/units/{uid}/claim", "OPERATOR", {"worker_id": "wv-verify"})
print("claim after HG2 APPROVED ->", s, "state:", sql(f"SELECT state FROM execution_units WHERE unit_id='{uid}'"))
print("gate_claim_refused audit rows:", refused_rows)
ok = refused_rows == "1"
print("GATE-ENFORCEMENT SPOTCHECK:", "PASS" if ok else "CHECK", "| first claim refused, post-approval claim:", s)
