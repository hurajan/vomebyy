# APPROVAL_POLICY_MAP — Gate 05 (G01-D06)

Every `approval_policy` value in the registry (workflow 1.0.0, 192
operations) × its enforcement in the running system. Produced from the
registry data (`operation_definitions.approval_policy`), the
`gate_requirements` table, and the coordinator/API source at Gate 05.

**Baseline fact:** before Gate 05, no runtime code read
`approval_policy` at all (grep-verified: zero references in the
coordinator, API, worker, evaluation or runtime services). Enforcement
existed only where the `gate_requirements` data + claim machinery
happen to implement a policy's intent. Gate 05 adds the provenance
half: at every acceptance the coordinator now writes an
`approval_policy_applied` audit row naming the operation's policy, the
mechanism that reached acceptance (`validation_layers` |
`human_approved`), the human who satisfied it where one did
(`human_satisfied_by`, null on the validation path), and any input-gate
decisions (kind, verdict, decider). The policy string itself is still
never consulted to ALLOW or REFUSE anything.

## Enforced — via artifact gates (3 policies, 36 operations)

Enforcement mechanism (all three): `gate_requirements` maps an artifact
TYPE to a gate kind (data-only migrations 003/004/005, Gate 6-era,
ruled permanent). `Coordinator._claim_txn` → `_verify_input_gates`
refuses the claim of any unit whose planned input artifact is of a
gated type unless a `human_gates` row for that gate kind bound to the
EXACT artifact id (hash-bound identity) is APPROVED — typed
`GateNotSatisfied`, HTTP 409, committed `gate_claim_refused` audit.
Gates are created by the producing station's flow and decided only via
the OPERATOR-only decide endpoint (`decided_by` recorded). Since Gate
05 the acceptance of the consuming unit also records the gate +
decider in `approval_policy_applied.input_gates`.

| Policy | Steps / operations | Gate | Gated artifact type |
|---|---|---|---|
| HUMAN_GATE_SCRIPT | step 08 — 08.01–08.12 | HG2 | `script` (consumed by downstream units) |
| HUMAN_GATE_MASTER | step 13 — 13.01–13.12 | HG4 | `master_package` |
| HUMAN_GATE_DERIVATIVE | step 14 — 14.01–14.12 | HG5 | `derivative_package` |

Precision note: the gate binds CONSUMPTION of the gated artifact (the
downstream unit's claim), not completion of the producing unit — the
producing unit itself completes and validates without any human
decision; nothing downstream can execute on the artifact until the
named gate is approved. That is the enforcement the machinery honestly
supports, and it is how the gates have operated since G5–G8.

## Indirectly covered — no distinct decision (1 policy, 12 operations)

| Policy | Steps / operations | Position |
|---|---|---|
| HUMAN_GATE_RELEASE | step 15 — 15.01–15.12 | No release gate kind exists in `gate_requirements`. Step-15 units cannot execute until their planned inputs are consumable — the chain's `derivative_package` input is HG5-gated, so the HG5 human decision is a hard precondition of any distribution execution, and it is the last human checkpoint before release. A DISTINCT release approval (a decision about the distribution/release itself, after derivatives are approved) is **NOT_ENFORCED**. Owner decision OD-G05-1 below. |

## NOT_ENFORCED as distinct policies (7 policies, 144 operations)

For each: no gate kind, no role, and no code path distinguishes the
named approver. The only human path that can touch these units is the
generic one — evaluation routes REVIEW_REQUIRED → AWAITING_HUMAN →
OPERATOR-only `human_approved` (OPERATOR-only since Gate 05's D07 fix)
— which attests "an operator approved", never the named policy role.
Absent a review route, these units are accepted purely by the
validation layers. Gate 05's `approval_policy_applied` row makes that
visible per unit (policy + mechanism + satisfied_by) but does not
change it. Each policy below is an owner-decision item (OD-G05-2):
the local single-operator token model cannot express a distinct
approver identity, and Gate 05 does not invent one.

| Policy | Steps / operations | Notes |
|---|---|---|
| PRODUCER_AND_BUDGET_OWNER | step 01 — 01.01–01.12 | Budget ceilings are enforced (hard-ceiling claim block, `budget_exceeded`), but that is a money control, not a producer approval of step-01 outputs. No approval step exists. |
| RIGHTS_OWNER | step 02 — 02.01–02.12 | A rights EVIDENCE mechanism exists in the Station-1 tree (operator-registered `rights_decision:<asset_id>` artifacts; silence never grants) — it gates what content may be used, enforced by the station payload logic. It is not an approval of step-02 units by a rights owner, and no rights-owner identity exists. |
| CANON_STEWARD | step 03 — 03.01–03.12 | No mechanism. Canon-affecting invalidation requires no steward authority (any OPERATOR may invalidate non-master artifacts). |
| EDITORIAL | steps 04–07, 12 — 60 operations (04.01–07.12, 12.01–12.12) | No mechanism. The largest gap by operation count. |
| DIRECTOR | steps 09, 10 — 09.01–10.12 (24) | No mechanism. (The step-09/10 units' inputs include the HG2-gated script, so an HG2 approval precedes them — that is the SCRIPT policy's gate, not a director approval of edit decisions.) |
| PRODUCER | step 11 — 11.01–11.12 | No mechanism. |
| LEARNING_OWNER | step 16 — 16.01–16.12 | No mechanism. |

## Owner-decision items (AWAITING_OWNER candidates — not decided here)

- **OD-G05-1 (HUMAN_GATE_RELEASE):** introduce a release gate kind
  (e.g. HG-RELEASE bound to the `distribution_record` artifact type,
  decided before step-15 completion is accepted) — a registry-data +
  gate-requirements change; OR owner-accept the HG5 derivative
  decision as the release checkpoint and retire the distinct policy.
  Affected: 15.01–15.12.
- **OD-G05-2 (the 7 distinct-role policies):** for EDITORIAL (60 ops),
  DIRECTOR (24), PRODUCER_AND_BUDGET_OWNER (12), RIGHTS_OWNER (12),
  CANON_STEWARD (12), PRODUCER (12), LEARNING_OWNER (12) — choose per
  policy or wholesale: (a) retire the distinct policy string in the
  registry (owner-ruled registry change); (b) introduce distinct
  approver identities and per-policy enforcement — production-identity
  work (Gate 11 territory; the local token model cannot express it);
  (c) owner-accept the generic OPERATOR human path (REVIEW_REQUIRED →
  OPERATOR approval, with the Gate 05 `approval_policy_applied` audit
  row as the record) as the satisfaction mechanism for these policies.

## Split summary

- Enforced via artifact gates: **3 policies / 36 operations**
- Indirectly covered, distinct decision NOT_ENFORCED: **1 policy / 12 operations**
- NOT_ENFORCED as distinct policies (owner-decision): **7 policies / 144 operations**
- Total: 11 policies / 192 operations.
