# CHANGED_ASSERTIONS — Gate 05

Every existing test/harness assertion or fixture behavior Gate 05
touched, and why. Product-behavior changes are listed first; test
updates follow. No assertion was weakened: each update re-expresses the
same intent under the Gate 05 authority rules (the lock's §1–§3), and
the suites are the proof.

## Product behavior changes (by design, per the lock)

1. **POST /units/{uid}/events is per-event authorized** (contract
   1.6.0 → 1.7.0). Previously OPERATOR/SCHEDULER/WORKER could fire ANY
   transition (the D07 defect, Phase 3 live repro). Now:
   human_approved/human_rejected/cancel/repair_ready = OPERATOR only;
   start/transient_error = WORKER only + body worker_id bound to the
   attempt's claim identity; block = OPERATOR, or WORKER under the
   same binding (claim identity when an attempt exists; the executor
   entitlement for the operation pre-claim — its only composed-flow
   producer is the G4 Station-2 rights check's pre-claim failure
   signal, found during this gate's regression after the first
   inventory pass missed it; the inventory and this file were
   corrected, and the dual-class treatment is recorded as a design
   finding in the gate summary); every other event name refused for
   all roles. Refusals: 403 + committed `event_refused` audit row.
2. **POST /units/{uid}/complete enforces the completion barrier**
   (API path only): the attempt's pinned plan must be fully evidenced
   by SUCCEEDED action records, else 409 + committed
   `completion_barrier_refused` audit. A unit whose plan contains an
   UNBOUND action can no longer complete via the API at all (its
   records are REFUSED) — the explicit post-Gate-04 failure mode.
3. **POST /units/{uid}/actions requires worker_id**, bound in the
   coordinator to the attempt's claim identity + live lease holder;
   mismatch → 403 + committed `action_record_refused` audit.
4. **Acceptance writes an `approval_policy_applied` audit row**
   (validate() ACCEPTED branch and event() human_approved branch):
   policy + mechanism + human_satisfied_by + input-gate deciders.
   Additive audit evidence; no state behavior changed.
5. **The five station trees' error-handler workflows were
   re-authenticated** (generators + regenerated workflow JSON):
   SCHEDULER → WORKER with X-Identity = the tree's executor identity
   and body worker_id = the same identity. DESIGN FINDING (see the
   gate summary): the error handler is executor plumbing that was
   mis-authenticated as SCHEDULER since Gate G; the lock's matrix
   gives SCHEDULER no events, so the caller was corrected rather than
   the matrix widened. The event it fires (transient_error) and its
   trigger conditions are unchanged.
6. **Executor /work payloads carry worker_id** (generators' Assemble
   nodes), and the **worker service's action-record sink forwards it**
   (`worker_service/service.py`). A /work request without worker_id
   now fails explicitly at its first action record (API 400 → sink
   abort → ProviderError) instead of recording unattributed evidence;
   all composed flows supply it after change 5's sibling edit.

## Test/harness updates (intent preserved in every case)

### video-factory-g3/tests/test_api_contract.py
- `TestApiContract.setUpClass`: the class server now also sets
  `FACTORY_WORKER_TOKEN=contract-worker-token` so worker-class events
  can be fired by their legitimate caller. No assertion changed.
- Gate 04 /actions posts (test_all_endpoints): bodies gain
  `"worker_id": "w1"` (the claim's worker) — new contract-required
  field. The two negative posts (wrong fencing; out-of-plan action)
  now stop at the required-field check (400) instead of reaching the
  fencing/plan checks; their assertions already accepted (400, 409)
  and are unchanged.
- /complete sites gain plan-record postings before completion
  (barrier): test_all_endpoints (01.01, remaining actions),
  test_validator_cannot_claim_but_can_validate (01.01),
  test_worker_claims_completes_and_submits_but_no_gates (01.01, posted
  as the WORKER role), TestApiGateD.test_stage_and_complete_by_candidate
  (05.12), TestApiGateD.test_pricing_rules_drive_calculated_settlement
  (06.12), TestApiGateE.validating_unit (05.12),
  TestApiGateG.test_evaluations_read (05.12). Assertions unchanged.
- TestApiGateD.test_complete_hash_mismatch_is_409: records posted
  first, so the asserted 409 is the hash refusal itself rather than
  the barrier's (intent sharpened, not changed).
- Worker-class events re-fired as their legitimate caller (was: the
  OPERATOR default client): transient_error in the retry flow
  (WORKER + worker_id "w"), start in the uid4 provider-job flow
  (WORKER + "w1"), start in test_worker_claims_completes_and_submits_
  but_no_gates (WORKER + "w"), start in test_callback_role_only_callbacks
  (WORKER + "w"), start in TestApiGateG.test_provider_jobs_read
  (WORKER + "w1"). All assertions unchanged.

### video-factory-g3/tests/test_walkthrough.py
- The 01.01 unit's pinned-plan records are posted before /complete
  (barrier). Assertions unchanged.

### video-factory-real-ai-programme/gate-h/harness/fix_dh1_t09.py
- N2 setup: the `start` event is fired as WORKER with
  worker_id=IDENTITY (was OPERATOR, identity "harness"). The probe's
  intent — a started attempt must not be adopted — is unchanged; the
  start now also exercises the identity binding positively.

## Judgment calls recorded (also in the gate summary)

- **Fixture-completion rule (lock §2):** the barrier binds the API
  completion path (enforce_barrier=True at the /complete route). The
  coordinator library default is unchanged: in-process callers
  (runtime services, evaluation fixtures, the g2/gate test suites) are
  trusted system actors whose completions do not assert worker
  execution. Stated in complete_attempt's docstring; proven both ways
  in g2/tests/test_gate05_api.py.
- **validate() is not separately barrier-gated:** acceptance through
  the evaluation path is protected transitively — every API-driven
  VALIDATING unit crossed the barrier at /complete; library
  completions are fixtures under the rule above; async provider-job
  completions reach VALIDATING through the provider-job + fencing +
  evaluation authority chain, not through plan-action execution.
- **D17 (artifact-register role surface) NOT narrowed:** the lock does
  not own D17; the inventory confirms register callers are OPERATOR in
  every tree today. Recorded, not actioned.
- **No migration:** Gate 05 needed no schema change; migration number
  016 remains unused.
