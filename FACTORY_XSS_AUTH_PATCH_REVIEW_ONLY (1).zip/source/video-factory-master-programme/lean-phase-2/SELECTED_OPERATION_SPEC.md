# LEAN PHASE 2 — Selected Operation Specification

**Selected operation: 08.12 — "Run text-fidelity" — the step-08 exit producing the Versioned Script + Line IDs (artifact type `script`). Operation ID unchanged.**
Status of this document: FROZEN TEST SPECIFICATION for Lean Phases 3–9. No product code was changed for Phase 2. Machine-readable candidate analysis: `evidence/operation_candidates.json`.

---

## 1. Candidate analysis (summary)

Five Station 03 candidates were evaluated against the prompt's selection criteria (Station 03 membership · substantive text · existing text-model adapter usable · clear input/output contracts **including a deliverable schema** · defined downstream consumer · no image/video dependency). Full per-candidate plans, inputs, outputs, and downstream analysis are in `evidence/operation_candidates.json`.

| Op | Title | Plan state today | Deliverable schema | Executed downstream | HG2 | Verdict |
|---|---|---|---|---|---|---|
| **08.12** | Run text-fidelity (script exit) | FULLY_BOUND, SPECIFIC builder — but the builder's script lines are **hardcoded mock text** (`payloads.py:107-125`) | **Yes** — `deliverables/step-08.schema.json` | **Yes** — 09.12 (Station 4) + HG2-gated claim | **Yes** | **SELECTED** |
| 08.05 | Compose dialogue from speaker objectives | PARTIALLY_BOUND — `creative_generate` UNBOUND (declared `creative.generate`) | **No** (non-exit) | No — successor 08.06 is itself UNBOUND | No | Runner-up |
| 08.04 | Write playable actions | PARTIALLY_BOUND — `creative_generate` UNBOUND | No | No | No | Rejected |
| 08.11 | Estimate durations and revise | PARTIALLY_BOUND — `creative_generate` UNBOUND at seq 4 of 6 (mixed) | No | No | No | Rejected |
| 07.05 | State each character's immediate objective | PARTIALLY_BOUND — `creative_generate` UNBOUND (step 07, `scene_design`) | No | No | No | Rejected |

The decisive facts: Gate G authored deliverable schemas **only for step exits (.12) plus op-14.01**, and the worker wraps envelopes **only for .12 exits**; HG2 binds only to the artifact type `script`; the only deterministic semantic rubric in Station 03 is for 08.12. Every non-exit candidate fails at least two selection criteria structurally, before any question of generation quality.

## 2. Selection and justification

**08.12 is the only candidate that satisfies every criterion simultaneously.** It belongs to Station 03 (step 08); its output is the production's script — the most substantive text artifact in the station; the existing `openrouter-compatible` text adapter (gate-c worker service) can generate it; it is the only Station 03 operation with **both** contracts frozen — the registry envelope (`contracts/step-08/output.schema.json`, `step_deliverable` const "Versioned Script + Line IDs") **and** a Gate G deliverable schema (`contracts/deliverables/step-08.schema.json`); it has a defined, already-executed downstream consumer (09.12, Station 4) whose claim is **HG2-gated on this exact artifact**; and it needs no image/video capability. What is "mock" about 08.12 today is precisely what Phase 3 replaces: its SPECIFIC builder returns three hardcoded script lines. The slice therefore replaces mock generation **inside the one operation whose surrounding contract machinery — envelope, deliverable schema, rubric, human gate, downstream handoff — is already complete and tested**, instead of building contract machinery and generation at the same time.

**Runner-up: 08.05** (Compose dialogue from speaker objectives) — the purest generative operation in the station, and the only candidate whose plan already declares the exact binding point Phase 3 wants (`creative_generate`, UNBOUND, declared implementation `creative.generate`). It loses on criteria, not on spirit: it has **no deliverable schema** (creating one is a contract addition requiring owner approval under the lean prompt's change rules), **no executed downstream consumer** (successor 08.06 is itself UNBOUND, so Phase 8's "downstream actually consumes the artifact" cannot be demonstrated), and **no HG2 relationship** (Phase 7's gate evidence would be vacuous). It is the designated first Phase 10 expansion operation once the 08.12 pattern is proven.

## 3. Frozen specification for the selected operation

### 3.1 Identity and plan (unchanged)
- Operation **08.12**, workflow 1.0.0, station 3, step 08, capability slot `script_writing`, approval policy `HUMAN_GATE_SCRIPT`, unit key `scene`, resource ceiling `max_attempts 3`.
- Plan `plan/1.0.0/08.12`, plan_version 1.0.0, current plan_hash `c7e1a0b6e370ae7ed0f33369d9786bfed302e22fe6df0dbed41faede0dd01817`.
- Plan actions today: seq 1 `inputs.manifest` (`engine.manifest_inputs`) → seq 2 `op.build` (`op.build_payload`, timeout 120s) → seq 3 `output.emit` (`engine.emit_output`, spec `{artifact_type: "script", deliverable_schema: "step-08.schema.json"}`).
- **Phase 4 plan change shape (the only plan change in the slice):** seq 2 is **rebound** from the deterministic `op.build_payload` to a provider-backed generation implementation that (a) assembles the prompt (§3.2), (b) calls the `openrouter-compatible` adapter with the attempt's resolved OPERATION binding, (c) shapes and validates the raw completion into the §3.3 deliverable, and (d) returns usage + provider_request_id so they reach the completion payload. This changes the plan's hash (plans are versioned data with their own hash; the registry `definition_hash ea4503f5…` does **not** cover plans and does not change). It is **not** a registry or contract change and needs no owner approval under the lean rules; it is recorded as a plan-data change under Phase 4's lock, with the pre-change hash above as the baseline.

### 3.2 Exact input contract
Registry envelope: `contracts/step-08/input.schema.json` — `{production_id, operation_id (^08\.\d{2}$), input_artifacts[] {artifact_id, artifact_type, sha256, version?}}`.

**Frozen fixture planning (exactly as the g5 chain plans it today — `test_g5_station.py:115`):**
- Unit 08.12 **depends on** unit 07.12 (so the CURRENT `scene_set` exists and is the dependency predecessor).
- `input_artifact_ids` = **[CURRENT `canon_manifest` artifact id]** (dependency-only for the other upstreams, matching every previously verified 08.12 execution and the Gate 03B lesson that exit deliverables declare content references, not artifact references).

**Prompt assembly inputs (Phase 4 — what generation actually reads):** the worker service resolves every ref in `input_artifact_refs` to content by SHA-256 from durable storage (`service.py:_resolve_input_refs`, envelope-unwrapped). Today `payloads.build("08.12")` reads **only** the `canon_manifest` artifact_id from the refs and hardcodes everything else (scene ids SC1/SC2, beats B1/B2, story nodes S1/S2, all line text, the whole trace block). The frozen prompt assembly for the slice must therefore be fed, in the worker request, the CURRENT contents of:
- `canon_manifest` (planned input — supplies the canon artifact id that must appear in every line's `canon_refs`, plus canon content as grounding);
- `scene_set` (07.12 CURRENT — scenes `{id, beat_ref, canon_refs}`: the scene/beat skeleton the lines must cover);
- `beat_graph` (06.12 CURRENT — beats `{id, story_ref}`) and `story_architecture` (05.12 CURRENT — story nodes `{id, summary}`), as narrative context.

Mechanics note for Phase 4 (not a contract change): scene/beat/story artifacts reach the worker either by extending the fixture unit's planned inputs or by the executor including the production's CURRENT artifacts of those types in `input_artifact_refs`; both are planning/request-level, registry untouched. Whichever mechanism Phase 4 chooses must be proven by the Phase 8-style evidence (the actual refs + hashes in the worker request), and the prompt must instruct the model to emit **only** the deliverable JSON of §3.3, covering every scene in the supplied `scene_set`, with `canon_refs` on every line set to the supplied canon artifact id.

### 3.3 Exact output contract
- Artifact type: **`script`**. Registered through the normal candidate → CURRENT promotion path; bytes in durable storage, addressed by SHA-256.
- Envelope (registry contract, `contracts/step-08/output.schema.json`): `{production_id, operation_id: "08.12", status: "CANDIDATE", step_deliverable: "Versioned Script + Line IDs", output_artifacts[ {artifact_type: "script", sha256, …} ], evidence[ worker provenance incl. config hash + attempt_id ]}` — produced by the existing `envelope.py` wrap, which applies **only on the plan-execution path** (see §5, constraint C-1).
- Deliverable (`contracts/deliverables/step-08.schema.json`), required:
  - `kind`: const `"script"`;
  - `lines[]` — each `{id, scene_ref, beat_ref, story_ref, canon_refs[≥ the canon id], text}` — **the model's genuine generated text lives in `lines[].text`**;
  - `trace` — `{clues[] {id, planted, payoff}, knowledge[] {character, learns, at}, payoffs[] {id, clue, line}}`, internally consistent (planted/payoff/line references resolve to line ids);
  - `canon_refs[]` — top-level, containing the canon artifact id.
- Shaping rule (Phase 4, deterministic, worker-side): the model's raw completion is parsed as JSON; structural fields the model cannot know (`canon_refs` values) are **set from the actual input refs, not trusted from model output**; a completion that is not parseable, misses required fields, or leaves a scene uncovered fails the action explicitly (no placeholder substitution — Phase 5 guardrail).

### 3.4 Downstream consumer (Phase 8) and how it reads
- Registry linear successor: **09.01** (Station 4; generic plan-bound — consumes at manifest level only; **not** the Phase 8 proof consumer).
- **Phase 8 consumer: 09.12** (Station 4 exit, SPECIFIC builder, g6 tree). Source-level read: `payloads.build("09.12")` takes `_ref_id(refs, "script")` and emits `direction_package {kind, script_ref: <script artifact_id>, directions[]}` (payloads.py:127-131). Its unit is planned with the `script` artifact as planned input, and — decisively — **its claim is refused by the Coordinator until HG2 is APPROVED on that exact script artifact id + sha256** (`gate_requirements`: `script → HG2`).
- Consumption proof method (Phase 8 evidence): the downstream worker request's `input_artifact_refs` contain the genuine script's artifact_id **and** sha256; the worker service's `_resolve_input_refs` loads its actual bytes by that sha (record the resolved content presence in evidence); the produced `direction_package.script_ref` equals the genuine artifact_id; and a control dispatch referencing a **superseded** script version is refused (input-currency / gate-claim path). Honest limit, recorded: 09.12's builder consumes the script's **reference** (and the service layer demonstrably loads its content); it does not parse the line text. No stronger downstream text consumer exists in the current factory — 09.12 + HG2 is the strongest handoff the approved architecture offers, and it is a real one.

### 3.5 HG2 behavior for the slice
- Creation: **after** the 08.12 unit completes, the g5 `station-03` workflow loads the production's artifacts, selects the CURRENT `script`, and calls gate creation with `{gate_kind: "HG2", artifact_id}` — the **Coordinator** snapshots the artifact's id + version + sha256 into the gate at creation. The workflow never decides the gate.
- Binding: the gate binds that **exact artifact version + hash**. A revised script (new version) does **not** inherit an approval — it needs its own gate (proven in the g5 suite and re-proven for the genuine artifact in Phase 7).
- Effect: while HG2 is PENDING or REJECTED for the genuine script, **09.12 cannot be claimed** (gate-claim enforcement: 409 + `gate_claim_refused` audit, zero attempts). On APPROVED (human, OPERATOR role, via the API — post-Gate-05, `human_approved`/gate decisions are OPERATOR-only), the downstream claim opens.
- The slice's HG2 decision is a **human** decision on genuine model content — this is also the Phase 7 acceptance act (§3.6).

### 3.6 Semantic-validation posture (exact)
The evaluation service will check, deterministically:
1. **Schema layer** — the envelope against `contracts/step-08/output.schema.json` **and** the deliverable against `contracts/deliverables/step-08.schema.json`; a violation is a deterministic FAIL → BLOCKED.
2. **Technical/continuity layers** — every artifact reference resolves to a CURRENT artifact with matching sha; planned-input currency (a superseded canon input → REPAIR_REQUIRED).
3. **Semantic layer, deterministic rubric** — the operation's named checks (`text_fidelity`, `knowledge_eligibility`, `setup_payoff_integrity`, `duration_estimate`) route to the semantic layer; the QA binding in the test environment resolves to `deterministic-local`, for which `layers.py` has exactly one Station 03 rubric: **`RUBRICS["08.12"] = "script_canon_coverage"`** — the percentage of script lines carrying a non-empty `canon_refs`, against `params.canon_ref_threshold_pct` (default **100**). Below threshold → `RUBRIC_FAIL` (deterministic FAIL → BLOCKED). This is a hard, mechanical bar the generated script must clear — hence §3.3's shaping rule.

The evaluation service will **not** check: dialogue quality, narrative coherence, fidelity of the text to the story in any human sense, or any LLM-judged property. The golden set is **NOT ARMED (7 SEED / 0 EXPERT; arming requires 50+ EXPERT — not lowered)**, so even a rubric pass yields `RUBRIC_PASS_UNARMED` → REVIEW_REQUIRED → the unit parks at **AWAITING_HUMAN**, and acceptance requires the human `human_approved` decision (OPERATOR). Worker-reported verdicts remain advisory only throughout.

## 4. Frozen test configuration

### 4.1 Fixture production (upstream CURRENT artifacts)
One test production on the g5 scratch chain, built by the existing station-03 path (deterministic adapters — legitimate outputs of **prior** operations, not mocks of the selected one):
1. Register the `canon_manifest` fixture artifact (as the g5 suite does) → CURRENT.
2. Run 05.12 → `story_architecture` CURRENT; 06.12 → `beat_graph` CURRENT; 07.12 → `scene_set` CURRENT (the established deterministic contents: story nodes S1/S2, beats B1/B2, scenes SC1→B1, SC2→B2).
3. Plan 08.12 exactly per §3.2 (depends on the 07.12 unit; planned input = canon artifact).
4. Downstream fixture: one 09.12 unit (g6 tree) planned with the genuine script as input, for Phases 7–8.

### 4.2 Provider binding Phase 3 must create (exact shape)
An **OPERATION-scope** row in `provider_configs` (whole-row resolution: OPERATION beats STATION 3's `deterministic-local` row for this operation only; all other Station 03 operations keep the station binding):
- `scope: "OPERATION"`, `operation_id: "08.12"`, `environment: "test"`, `active: true`
- `provider: "openrouter-compatible"` — the adapter registry key (`adapters.py`: `OpenRouterCompatibleAdapter.name`, modality `text`, `credential_required: true`, default base `https://openrouter.ai/api/v1`, POST `/chat/completions`)
- `model:` a concrete inexpensive general chat model available on OpenRouter — **the exact model string is pinned at Phase 3 and recorded here by amendment; it is a binding datum, not code** (adapter sends `binding.model` verbatim)
- `credential_ref: "OPENROUTER_API_KEY"` — the binding stores the **environment variable name**; the adapter resolves `os.environ[credential_ref]`. The secret itself is supplied by the owner via the approved secrets path and must also be listed in the worker service's `WORKER_CREDENTIAL_REFS` env or `/health` reports the adapter BLOCKED. **No credential exists in the environment today (Phase 0 inventory) — Phase 3's acceptance test is BLOCKED_EXTERNAL until the owner supplies it.**
- `est_cost_cents: 25` (per-claim estimate/reservation — §4.3)
- `timeout_s: 120` (adapter uses `min(binding.timeout_s, request.deadline_s)`)
- `params`: `{temperature: 0.7, max_tokens: 2000}` (both forwarded verbatim by the adapter), `retry_policy: {base_s: 30, max_s: 900}` (Gate F retry-driver shape; the adapter itself makes **one** HTTP attempt — retries happen only through the Coordinator's retry path, `max_attempts 3` per the registry ceiling). **No `reported_actual_cents` param may be set on this binding** — that fixture datum is forbidden for real-provider accounting (Phase 6 guardrail).
- **Pricing rows Phase 3 must seed** (`pricing_rules`, migration-012 table): two ACTIVE rows for `provider="openrouter-compatible"`, `model=<pinned model>`, a single `pricing_version` (e.g. `"or-2026-10"`): `unit_kind "input_token"` and `"output_token"` with the model's real per-token prices converted to `unit_price_cents` (NUMERIC cents-per-token, sub-cent exact). Without these, no CALCULATED evidence can exist and Phase 6 cannot pass — the coordinator never invents a price.

### 4.3 Spend ceiling (PROPOSED — for owner confirmation alongside the credential)
- Per-claim estimate/reservation: **25¢**.
- Fixture production **soft ceiling: 250¢**; **hard ceiling: 500¢ ($5.00)**.
- Sizing: the full Phase 4–9 battery (one happy-path generation, duplicate-dispatch control, one failure/recovery run, downstream run, plus retries at `max_attempts 3`) needs **≤ 10 provider calls**; at small-model token prices (≤ ~2,000 output tokens per script) expected actual spend is a few cents. The 500¢ hard cap is an authorization ceiling, not an expectation, and the Coordinator's hard-ceiling refusal is itself exercised if approached. **Status: PROPOSED — Phase 3 may not execute a paid request until the owner confirms this cap (or sets another) together with the credential.**

### 4.4 Acceptance evidence list (Phases 5–8)
- **Phase 5 (genuine artifact):** the script artifact's id + SHA-256; the durable-storage bytes re-read by sha and hash-verified; deliverable-schema validation output; model provenance (provider, model, provider_request_id, attempt_id, resolved-config hash, plan hash) from the envelope evidence + attempt row; a diff against the deterministic builder's former output proving the content is not the hardcoded mock lines (different text, model-authored trace).
- **Phase 6 (cost + DB):** claim estimate 25¢ = reservation HELD amount; attempt usage `{input_tokens, output_tokens, total_tokens}` exactly as the provider reported; CALCULATED evidence from the §4.2 pricing rows (version recorded); FINALIZED selection outcome with its basis; settlement CHARGE == FINALIZED, reservation released to 0 held; no duplicate CHARGE on duplicate completion; action records for seq 1–3 (with the generation action carrying the provider request id in its evidence); audit trail (claim → adopt/start → completion → validation → settlement).
- **Phase 7 (quality + human):** evaluation rows for the unit (schema PASS, continuity PASS, semantic `script_canon_coverage` stats with coverage % and threshold, `NOT_ARMED` calibration with 0 EXPERT); unit AWAITING_HUMAN before approval; HG2 gate row bound to the genuine script's id + sha256; the human decision record; a rejection control (rejected content leaves 09.12 unclaimable).
- **Phase 8 (handoff):** §3.4's proof set — downstream worker request refs (genuine artifact id + sha), content-resolution evidence, `direction_package.script_ref` equality, gate-open claim success after HG2 approval, superseded-script refusal control.

## 5. Constraints and blockers found in the contracts (for Phases 3–4)

- **C-1 (execution-path constraint, not a contract change):** `envelope.wrap` returns a wrapped envelope **only** for payload providers (`deterministic-local`, `mock`), and `service.run_work` routes any other provider's binding **directly** to `adapter.execute`, whose OpenRouter result is `artifact_type "text_output"` with raw string content — no envelope, no deliverable shape, no plan execution, no action records, no plan-pin check. **Therefore Phase 4 must NOT implement the slice as a bare OPERATION-binding swap.** The generation must execute as the rebound seq-2 action **inside** plan execution (§3.1), where envelope wrapping, action records, plan pinning, and the Gate 05 completion barrier all apply. This is implementation inside existing components (plan_exec / actions / adapters) — no new service, framework, or abstraction.
- **C-2 (prompt constraint):** the adapter's prompt is `request["prompt"]` if present, else a content-free generated string ("Execute operation … with N input artifact(s)"). Phase 4 must supply the assembled prompt (§3.2); a slice that runs on the fallback prompt would produce ungrounded text and fail the rubric/grounding evidence.
- **C-3 (cost constraint):** the OpenRouter adapter returns `cost_cents: None`; the completion payload then falls back to the binding estimate as "actual". Phase 6's standard (measured usage, CALCULATED vs provider-reported distinguished) is met **only** via the §4.2 pricing rows + the recorded token usage — the estimate must never be presented as a measured cost.
- **No contract blocker for the selected operation.** The deliverable schema, envelope schema, gate row, and rubric all already exist for 08.12. (For the runner-up 08.05 the missing deliverable schema **would** have been a blocker requiring an owner-approved contract addition — one of the reasons it lost.)
- **External blocker (unchanged, owner-side):** no provider credential and no spend authorization exist yet. Phase 3 preparation (binding shape, pricing rows, prompt assembly spec) is fully defined by this document; its acceptance test stays **BLOCKED_EXTERNAL** until the owner supplies the credential and confirms §4.3 (or another cap).

## 6. Phase 0 closeout facts

- **Authoritative source (from the register):** the integrated factory trees `video-factory-g1…g9` + the programme service trees under `video-factory-real-ai-programme/gate-c|d|e|f` (worker, storage, evaluation, runtime services), baseline-pinned by the Gate 00 content-addressed manifest (aggregate `78cd4744…`; the trees are not Git repositories — OD-A1 remains open). Programme state register: `video-factory-master-programme/controller/STATE.md`. Gates 00–05 **PASSED**; Gate 05 (= Lean Phase 1) closed the D07 authority bypass with G05-T01..T10 independently verified, regression 210/210.
- **Station 03 execution path as it exists TODAY (g5 tree):** driver/dispatcher POSTs a dispatch payload to the n8n webhook `/webhook/dispatch-g5` → `g5-dispatch-receiver` → `g5-station-03` (chain sequencing; creates the HG2 gate after 08.12) → `g5-unit-executor` (span guard → RETRY_WAIT pre-step → claim **or adopt** a scheduler-prestaged claim via `POST /units/{uid}/adopt` under identity `n8n-executor-g5` → attempt snapshot) → `g5-call-worker` → worker service `/work` (input refs resolved to content by sha → plan pin verified → `plan_exec` runs the pinned plan's actions in order, posting each action record via `POST /units/{uid}/actions`) → completion via the Coordinator API (fencing + completion barrier over action records) → evaluation service `/evaluate` (schema → technical/continuity → semantic; verdicts submitted as VALIDATOR) → Coordinator acceptance or AWAITING_HUMAN → human decision (OPERATOR) → downstream readiness recomputed by dependency state. Scheduler/dispatcher/reaper/retry services (Gate F) drive the same path unattended; error handling routes to `g5-error-handler`, whose events are WORKER-authenticated post-Gate-05.
- **Phase 0 PASS items not yet evidenced (honest list):** (i) no standalone Lean-Phase-0 report exists — Phase 0 rests on the Gates 00–04 baseline records plus the credential inventory, not on a lean-specific baseline battery (the most recent full regression is Gate 05's 210/210, run under the Master Programme); (ii) the credential inventory is evidenced (none present) but, by the same token, **provider configuration availability (Phase 0 task 10) is evidenced as absent** — this is the recorded BLOCKED_EXTERNAL for Phase 3, not a Phase 0 failure; (iii) file-ownership for the Phase 3–4 write scope (worker service + g5 generators + provider_configs data) is not yet entered in the Gate 00 ownership register — the Phase 3/4 lock must record it before edits begin.
