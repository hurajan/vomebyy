# G1 — Operation & Capability Registry

Build tree for G1 of the AI Video Production Factory programme. Lock: `LOCK_G1.md`.
Status: built by the builder; independent verification and owner acceptance are separate steps.

## Layout
- `seed-definitions/workflow-1.0.0/` — 192 operation definitions (`operations.json`,
  `definition_hash ea4503f5…`), capability registry skeleton (`capabilities.json`),
  genre profile references (`genre_profiles.json`)
- `contracts/step-01 … step-16/` — input/output JSON Schemas (32 files)
- `database/migrations/001_g1_registry.sql` — standalone registry schema (PostgreSQL 16)
- `tools/` — `generate_seed.py` (deterministic seed generation from the pinned source),
  `generate_contracts.py`, `registry_tool.py` (validate / load)
- `tests/` — validator tests incl. tamper cases
- `evidence/` — builder's load report + test output (verifier produces its own)

## Reproduce
```bash
python3 tools/generate_seed.py          # byte-deterministic
python3 tools/generate_contracts.py
python3 -m unittest discover -s tests   # 7 tests
python3 tools/registry_tool.py validate
python3 tools/registry_tool.py load g1_registry_scratch   # needs local PostgreSQL 16
```

## Not in G1
Coordinator/state machine (G2), dashboard (G3), station workflows (G4–G8), providers,
deployment (G0 — blocked on G0.6). No capability is APPROVED; no model is bound;
monetary ceilings are `PIN_AT_PRODUCTION` by design.
