# G1 REPORT — Operation & Capability Registry

- **Programme:** AI Video Production Factory (Master Guide v1.3 / A–Z Guide §17)
- **Lock:** confirmed by Raj 2026-10-27 22:25 EDT ("Lock G1 first (registry, host-independent)"); record: `LOCK_G1.md`
- **Status: ACCEPTED by Raj 2026-10-27 22:33 EDT — WITHOUT FREEZING.** (Was: COMPLETE + INDEPENDENTLY VERIFIED, submitted.) The seed data is unchanged by this acceptance: file SHA-256 and definition hash below remain the verified values. Because G1 is accepted-but-not-frozen, a future change follows a new lock and produces a new definition hash; nothing may silently edit the accepted seed.
- **Definition hash:** `ea4503f516fc4f7940f187f5cd9dac38c57f0d239726cac90e2d0a18a8bc9d73`
- **Seed file SHA-256:** `8bc567a61b60334abd36415abb84faae1486f3d2aa08f29523ddacfd408ad8d4`
- **Source pin:** S2 SHA-256 `0f3f38711c9761a67c161862feacbc72b08e1c172935691431e2f0cbbc8b7a8d`

## What was built

| Deliverable | Evidence |
|---|---|
| 192 operation definitions as data (workflow 1.0.0) | `seed-definitions/workflow-1.0.0/operations.json` — 16 steps × 12; stations 24/24/48/36/36/24 |
| 191 dependency templates (rule T-DEP-01, recorded in the lock) | Same file; chain within steps + across step boundaries |
| 32 contracts (16 steps × input/output JSON Schema; deliverable pinned as `const`) | `contracts/step-01…16/` |
| Capability registry skeleton: 16 step slots + 8 creative + 5 NI components | `capabilities.json` — **all PROPOSED**, `execution_plan: null`, `benchmark_evidence_ref: null`, no model bound |
| Genre profile references: the 8 existing keys (migration 0077) | `genre_profiles.json` — all PROPOSED, references only |
| Registry schema (standalone programme migration set v1) | `database/migrations/001_g1_registry.sql` (PG16) |
| Loader + validator with definition-hash pinning | `tools/registry_tool.py` |
| Monetary ceilings | `null` + `PIN_AT_PRODUCTION` in all 192 — no invented values |

## Builder results
- Validator: PASS, zero errors (counts, ID set, dependency integrity, schema presence + deliverable consts, provider-name blocklist, source + definition hash recompute)
- Tests: 7/7 (incl. tamper cases: duplicate ID, missing op, dangling dependency, provider name, pre-promoted capability — all correctly FAIL)
- Load on real PostgreSQL 16.15 (scratch DB): 192 ops / 191 deps / 16 steps / 6 stations / 29 capabilities / 8 genres / 0 orphans; DB definition hash matches; reload idempotent
- One builder fix en route: loader stages SQL via `/tmp` because the postgres OS user cannot traverse `/home/hatch`

## Independent verification (verifier ≠ builder)
Full report: `evidence/G1_VERIFIER_REPORT.md` — **VERIFIED, defects NONE.**
- Own source parse: 192, 12/step, station totals exact; source hash matches pin
- Verbatim check extended to all 192: every responsibility is a character-exact suffix of its source line, 0 altered words
- Definition hash independently recomputed — matches seed and DB
- Clean-room reproduction from `/tmp` copy + fresh DB, README commands only: seed byte-identical, 7/7 tests, validator PASS, loader PASS; scratch DB dropped after
- FK negative test: insert with `from_operation='99.99'` rejected by the composite FK
- NOT TESTED (verifier): adversarial tests beyond the builder's 7, migration re-apply idempotency, concurrency/performance, title semantics, everything outside the G1 lock

## Note N1 — CLOSED
The verifier noted the generator's "verbatim" wording hid a prefix-stripping normalization. The generator docstring now documents it explicitly (185 lines `Operation NN.`; 7 duplicated-title lines). After the fix the regenerated seed is **byte-identical** (SHA-256 above, before = after) and tests remain green — the verification stands unmodified.

## Open after G1 (unchanged queues)
OD-F01 (orchestrator), OD-F02 (coordinator language), OD-F03 (OVH topology), OD-F04 (HG numbering), OD-F05 (state vocabulary — needed at G2 lock), OD-F06 (D-378), OD-F07 (G0.6). Next stage on owner lock only: **G2** (requires OD-F02 + OD-F05) or **G0** (requires OD-F07).
