# G2 LOCK REQUEST — Coordinator (PREPARED, not confirmed)

Prepared 2026-10-27 after G1 was ACCEPTED (without freezing). **No G2 work starts until Raj confirms this lock and rules OD-F02 + OD-F05.**

> **Owner ruling 2026-10-27 22:43 EDT — "i agree your suggestion": OD-F02 DECIDED = (a) Python, consolidating existing logic.** This supersedes the A–Z Guide's TypeScript-coordinator wording by owner ruling (guide not edited). OD-F05 is recorded as agreed in the same message; the G2 lock itself is confirmed or held by the owner's next explicit tap/message — no G2 work has started.

## Blockers to this lock (owner rulings needed)

### OD-F02 — Coordinator implementation language
- **(a) Python, consolidating existing logic (builder recommendation):** the verified mechanisms G2 must reuse — reserve-and-ledger, golden-set framework, media/provider services — are Python in the frozen baseline; the existing PG16 + Python 3.12 environment is proven here (G1 loader ran on it). A TS coordinator would re-implement verified finance code in a second language and re-verify it from zero.
- (b) TypeScript service per A–Z/v1.3 letter: cleaner long-term if the dashboard also goes TS, but discards verified Python mechanisms or wraps them as foreign services.
- (c) TS API shell over Python domain modules: two runtimes to operate from day one.
- *Effect of (a):* the A–Z Guide §3.2/§4 wording ("TypeScript coordinator") is superseded by owner ruling, recorded here — the guide itself is not edited.

### OD-F05 — State vocabulary ratification
Ratify the A–Z Guide §7.1 reconciliation: ONE engine vocabulary
`PENDING → READY → CLAIMED → RUNNING → VALIDATING → ACCEPTED` + side states
`RETRY_WAIT · AWAITING_PROVIDER · AWAITING_HUMAN · REPAIR_REQUIRED · BLOCKED · CANCELLED · UNKNOWN · SUPERSEDED`,
with S1's production vocabulary kept as a reporting projection (mapping in §7.1) and the existing Studio production state model kept distinct (per R1: three vocabularies, never conflated). G1 recorded no engine states, so nothing in G1 changes either way.

## Proposed G2 scope (if locked)
Baseline: G1 accepted seed (`definition_hash ea4503f5…`, seed SHA-256 `8bc567a6…`) + frozen Studio `72414ed` as read-only reuse reference.
In: coordinator service (single writer) with — transition table (§7.1), execution-unit/action/attempt ledgers (§8.3–8.4 tables), leases + fencing (§7.3), outbox + idempotency (§7.4), capacity scheduler (§7.5), selective invalidation (§7.6 corrected cascade), provider reconciliation (§7.7, mock providers only), budget reserve/settle/release on the reused ledger pattern (§10), audit events. Simulated-worker harness only — no real providers, no dashboard (G3), no station workflows (G4+), no OVHcloud (G0 still blocked).
PASS (A–Z §17 G2): simulated jobs survive worker/coordinator kills; unauthorized transitions rejected; acceptance tests T-DEP-01, T-BUD-01, T-REC-01, T-PRV-01 pass; builder ≠ verifier; regression: G1 validator + loader re-run green.
Out: everything listed above as excluded, plus any change to the accepted G1 seed (a seed defect found during G2 is reported as an owner decision, not edited).

## Decision asked
1. OD-F02: (a) / (b) / (c) / defer
2. OD-F05: ratify / amend / defer
3. G2 lock: confirm / hold
