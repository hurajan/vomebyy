"""FP-01 (F-G9-01) — Gate C: dependency templates must load under the seed's
OWN workflow_version. Before the fix, build_load_sql hardcoded '1.0.0', so a
variant seed silently wrote its 191 templates under the wrong version.
"""
import json
import shutil
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "tools"))
import registry_tool as rt  # noqa: E402

DB = "g1_fp01_scratch"


def variant_seed():
    tmp = Path(tempfile.mkdtemp(prefix="g1-variant-"))
    for f in ("operations.json", "capabilities.json", "genre_profiles.json"):
        shutil.copy(rt.SEED_DIR / f, tmp / f)
    data = json.loads((tmp / "operations.json").read_text())
    data["workflow_version"] = "1.1.0"
    for op in data["operations"]:
        op["workflow_version"] = "1.1.0"
    (tmp / "operations.json").write_text(json.dumps(data, ensure_ascii=False, indent=2))
    return tmp


class TestFP01(unittest.TestCase):
    def test_canonical_sql_references_seed_version(self):
        sql = rt.build_load_sql()
        dep_lines = [ln for ln in sql.splitlines() if "dependency_templates" in ln]
        self.assertEqual(len(dep_lines), 191)
        self.assertTrue(all(ln.startswith("INSERT INTO dependency_templates VALUES ('1.0.0',")
                            for ln in dep_lines))

    def test_variant_seed_templates_under_own_version(self):
        tmp = variant_seed()
        try:
            rt.psql("postgres", sql=f"DROP DATABASE IF EXISTS {DB}")
            rt.psql("postgres", sql=f"CREATE DATABASE {DB}")
            rt.psql(DB, sql_file=rt.MIGRATION)
            for seed_dir in (None, tmp):
                stage = Path(tempfile.gettempdir()) / f"g1-fp01-{seed_dir is not None}.sql"
                stage.write_text(rt.build_load_sql(seed_dir), encoding="utf-8")
                rt.psql(DB, sql_file=stage)
            n_var = int(rt.psql(DB, sql="SELECT count(*) FROM dependency_templates "
                                        "WHERE workflow_version='1.1.0'"))
            n_can = int(rt.psql(DB, sql="SELECT count(*) FROM dependency_templates "
                                        "WHERE workflow_version='1.0.0'"))
            n_ops = int(rt.psql(DB, sql="SELECT count(*) FROM operation_definitions "
                                        "WHERE workflow_version='1.1.0'"))
            self.assertEqual(n_var, 191)
            self.assertEqual(n_can, 191)
            self.assertEqual(n_ops, 192)
            # canonical registry validation is unaffected by the fix
            self.assertEqual(rt.validate()["verdict"], "PASS")
        finally:
            rt.psql("postgres", sql=f"DROP DATABASE IF EXISTS {DB}")
            shutil.rmtree(tmp, ignore_errors=True)


if __name__ == "__main__":
    unittest.main(verbosity=2)
