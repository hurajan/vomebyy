import json
import shutil
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "tools"))
import registry_tool as rt  # noqa: E402


def tampered_seed(mutator):
    tmp = Path(tempfile.mkdtemp(prefix="g1-tamper-"))
    for f in ("operations.json", "capabilities.json", "genre_profiles.json"):
        shutil.copy(rt.SEED_DIR / f, tmp / f)
    data = json.loads((tmp / "operations.json").read_text())
    mutator(data)
    (tmp / "operations.json").write_text(json.dumps(data, ensure_ascii=False, indent=2))
    return tmp


class TamperCase(unittest.TestCase):
    def run_with(self, mutator):
        tmp = tampered_seed(mutator)
        original = rt.SEED_DIR
        rt.SEED_DIR = tmp
        try:
            return rt.validate()
        finally:
            rt.SEED_DIR = original
            shutil.rmtree(tmp, ignore_errors=True)


class TestShippedSeed(unittest.TestCase):
    def test_validate_passes(self):
        r = rt.validate()
        self.assertEqual(r["verdict"], "PASS", r["errors"])
        self.assertEqual(r["operations"], 192)
        self.assertEqual(r["dependencies"], 191)
        self.assertEqual(r["creative_capabilities"], 8)
        self.assertEqual(r["genre_profiles"], 8)

    def test_generator_determinism(self):
        import subprocess
        before = (rt.SEED_DIR / "operations.json").read_bytes()
        subprocess.run([sys.executable, str(ROOT / "tools" / "generate_seed.py")],
                       check=True, capture_output=True)
        after = (rt.SEED_DIR / "operations.json").read_bytes()
        self.assertEqual(before, after, "seed generation is not byte-deterministic")


class TestTampering(TamperCase):
    def test_duplicate_id_fails(self):
        def m(d):
            d["operations"][1]["operation_id"] = d["operations"][0]["operation_id"]
        r = self.run_with(m)
        self.assertEqual(r["verdict"], "FAIL")

    def test_missing_operation_fails(self):
        def m(d):
            d["operations"] = d["operations"][:-1]
        r = self.run_with(m)
        self.assertEqual(r["verdict"], "FAIL")
        self.assertTrue(any("192" in e or "ID set" in e for e in r["errors"]))

    def test_dangling_dependency_fails(self):
        def m(d):
            d["dependency_templates"][0]["to_operation"] = "99.99"
        r = self.run_with(m)
        self.assertEqual(r["verdict"], "FAIL")

    def test_provider_name_fails(self):
        def m(d):
            d["operations"][0]["responsibility"] += " Use OpenAI for this."
        r = self.run_with(m)
        self.assertEqual(r["verdict"], "FAIL")
        self.assertTrue(any("provider name" in e for e in r["errors"]))

    def test_promoted_capability_fails_g1(self):
        tmp = Path(tempfile.mkdtemp(prefix="g1-tamper-cap-"))
        for f in ("operations.json", "capabilities.json", "genre_profiles.json"):
            shutil.copy(rt.SEED_DIR / f, tmp / f)
        caps = json.loads((tmp / "capabilities.json").read_text())
        caps["creative_capabilities"][0]["status"] = "APPROVED"
        (tmp / "capabilities.json").write_text(json.dumps(caps, indent=2))
        original = rt.SEED_DIR
        rt.SEED_DIR = tmp
        try:
            r = rt.validate()
        finally:
            rt.SEED_DIR = original
            shutil.rmtree(tmp, ignore_errors=True)
        self.assertEqual(r["verdict"], "FAIL")


if __name__ == "__main__":
    unittest.main(verbosity=2)
