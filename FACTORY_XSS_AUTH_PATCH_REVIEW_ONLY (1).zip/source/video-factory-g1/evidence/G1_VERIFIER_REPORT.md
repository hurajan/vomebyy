# G1 — Independent Verifier Report

- **Programme:** AI Video Production Factory — G1 Operation & Capability Registry
- **Lock:** `LOCK_G1.md` (owner-confirmed 2026-10-27 22:25 EDT)
- **Verifier role:** independent — did not build G1; build tree treated as read-only
- **Date:** 2026-10-27 (America/New_York)
- **Method note:** every check below was produced by the verifier's own scripts/commands
  (own parser in `/tmp/g1verify/`, clean extraction in `/tmp/g1_clean`, fresh scratch DB
  `g1_verify_scratch`). The builder's evidence files were **not** relied on.

---

## Check 1 — Independent source parse: counts — **PASS**

Verifier's own regex parser (`^(\d{2})\.(\d{2}) — (.*)$`) over
`~/workspace/user/files/192_documented_atomic_operations.txt`:

- Source SHA-256 recomputed: `0f3f38711c9761a67c161862feacbc72b08e1c172935691431e2f0cbbc8b7a8d` — matches the LOCK's pinned value exactly.
- Total operations: **192**; unique IDs: **192**.
- Per step 01–16: **12 each** (01:12, 02:12, …, 16:12 — all sixteen confirmed individually).
- Station totals (steps 01–02 / 03–04 / 05–08 / 09–11 / 12–14 / 15–16): **24 / 24 / 48 / 36 / 36 / 24** — exact.

## Check 2 — Verbatim fidelity of `responsibility` (16 spot picks, all 6 stations; then all 192) — **PASS with a documented normalization (Note N1)**

Picks: 01.01, 02.12 (St.1) · 03.05, 04.07 (St.2) · 05.03, 06.10, 07.04, 08.05 (St.3) ·
09.02, 10.11, 11.06 (St.4) · 12.09, 13.10, 14.01 (St.5) · 15.09, 16.05 (St.6).

Character-level finding: no seed `responsibility` is byte-identical to the *entire remainder*
of its source line, because every source line carries a redundant leading label segment that
the generator strips. That is the **only** difference, proven for all 192 (not just the picks):

- **192/192 seed responsibilities are exact character-for-character suffixes of their source
  line's remainder. Zero suffix mismatches, zero altered words, zero truncation of content.**
- Stripped prefixes fall into exactly two classes:
  - 185 lines: `Operation NN. ` (e.g. source `Operation 01. Capture premise, intent, …` → seed `Capture premise, intent, references, and applicant/commissioner identity; assign production ID.`)
  - 7 lines: a duplicated title fragment ending in `NN. ` where the source itself repeats the
    title (e.g. 03.05 source remainder `Assess reliability independently 05. Assess reliability
    independently: authenticity, directness, bias, corroboration and conflicting accounts.` →
    seed `Assess reliability independently: authenticity, directness, bias, corroboration and
    conflicting accounts.`; same pattern at 01.03, 02.10, 06.03, 14.01, 16.05 and one further line).

**Note N1 (minor, documentation — not a content defect):** the generator's docstring claim
"copied VERBATIM" is true of the responsibility *sentence* but involves this prefix-stripping
normalization. It should be described as such in the seed provenance, so a future auditor
comparing raw lines is not surprised. No responsibility content differs from the source.

## Check 3 — `definition_hash` recomputation — **PASS**

Verifier recomputed independently (canonical JSON: seed minus `definition_hash`,
`sort_keys=True`, `separators=(",", ":")`, `ensure_ascii=False`, UTF-8, SHA-256):

- Recomputed: `ea4503f516fc4f7940f187f5cd9dac38c57f0d239726cac90e2d0a18a8bc9d73`
- Stored in `operations.json`: identical.
- In DB (`workflow_versions.definition_hash` for 1.0.0, read from the verifier's own scratch load): identical.

## Check 4 — Clean-room reproduction (fresh copy + fresh DB, README commands only) — **PASS**

Extraction: build tree copied to `/tmp/g1_clean`; database name `g1_verify_scratch` (new,
confirmed absent before the run). Commands run exactly as documented in `README.md`:

| Command | Actual result |
|---|---|
| `python3 tools/generate_seed.py` | `operations=192 dependencies=191 definition_hash=ea4503f5…`; regenerated `operations.json` SHA-256 `8bc567a61b60334abd36415abb84faae1486f3d2aa08f29523ddacfd408ad8d4` — **byte-identical to the shipped file** (deterministic generation confirmed) |
| `python3 tools/generate_contracts.py` | `contracts written: 32` |
| `python3 -m unittest discover -s tests` | **Ran 7 tests — OK** |
| `python3 tools/registry_tool.py validate` | verdict **PASS**, errors `[]`: operations 192, dependencies 191, steps 16, stations {1:24, 2:24, 3:48, 4:36, 5:36, 6:24}, contracts_checked 32, creative_capabilities 8, step_capability_slots 16, genre_profiles 8, source_sha256 matches pin |
| `python3 tools/registry_tool.py load g1_verify_scratch` | verdict **PASS** on PostgreSQL **16.15**: operations 192, dependencies 191, steps 16, stations 6, capabilities 29 (16 step slots + 8 creative + 5 narrative-intelligence components), genres 8, orphan_deps 0, definition_hash_db matches |

Scratch database `g1_verify_scratch` was dropped after verification (`DROP DATABASE` confirmed).

## Check 5 — LOCK out-of-scope claims — **PASS**

Verified by the verifier's own inspection of the seed JSON (all three capability groups,
including the narrative-intelligence components the builder's validator does not iterate over):

- **Status:** every capability in `capabilities.json` — 16 step slots, 8 creative
  capabilities, 5 NI components — has `status = PROPOSED`. No other value present.
- **Execution plans:** `execution_plan` is `null` for all 29; `benchmark_evidence_ref` is
  `null` for all 29. Step slots carry only a `model_policy_class` label (e.g.
  `structured_text`, `deterministic_media`) — a class, not a model binding.
- **Monetary ceilings:** `max_cost_usd_per_unit` is `null` in **all 192** operations;
  `cost_policy` is uniformly `PIN_AT_PRODUCTION`. No numeric monetary ceiling exists.
  (`max_attempts: 3` and `wall_clock_s: null` are non-monetary and as locked.)
- **Genres:** keys are exactly {comedy, confession, documentary, drama, educational,
  mystery, romance, thriller} — the 8 expected — all status PROPOSED.
- **Provider names:** verifier grep (extended list incl. sora/veo/whisper) over
  `seed-definitions/`, `contracts/`, and `database/` (SQL): **no matches**. The only
  occurrences in the tree are the validator's own blocklist in `tools/registry_tool.py`
  and a tamper-test fixture string in `tests/test_registry_tool.py` — both are enforcement
  machinery, not seed/contract/SQL content, and are outside the checked scope by design.

## Check 6 — Migration integrity + FK enforcement — **PASS**

- Migration `001_g1_registry.sql` applied cleanly to the fresh scratch DB as part of the
  Check 4 loader run (no errors; all counts in Check 4 derive from its tables).
- FK structure confirmed in `pg_constraint`: `dependency_templates` has composite FKs to
  `operation_definitions(workflow_version, operation_id)` on both `from_operation` and
  `to_operation`.
- Negative test (verifier's own insert): `INSERT INTO dependency_templates VALUES
  ('1.0.0','99.99','01.01','REQUIRED')` → **rejected**: `violates foreign key constraint
  "dependency_templates_workflow_version_from_operation_fkey" — Key (1.0.0, 99.99) is not
  present in table "operation_definitions"`. FK integrity holds.

---

## Defects

- **NONE (functional/content).**
- One minor documentation note, **N1** (Check 2): the seed generator's "verbatim" claim
  involves stripping the source lines' redundant label prefixes (`Operation NN. ` /
  duplicated title fragment). All 192 responsibility sentences are character-exact suffixes
  of the source; recommend recording the normalization explicitly in the seed provenance.
  This does not change any content and does not block acceptance.

## NOT TESTED

- Tamper-case behaviour beyond re-running the builder's own 7 tests in the clean copy
  (they passed; the verifier did not write additional adversarial validator tests).
- Migration idempotency on a second application to the same database (migration header
  states "apply once" on a fresh database; only the fresh-apply path was verified).
- Anything outside the G1 lock: coordinator/state machine (G2), dashboard (G3), station
  workflows (G4–G8), providers, deployment/G0 (blocked on G0.6) — none exists in this tree
  and none was tested.
- Concurrency, performance, and multi-user load on the registry schema.
- The semantic quality of generated operation *titles* (labels derived from the
  responsibility text by the generator) — format-checked only via the registry load.

## Verdict

**VERIFIED** — all six checks PASS (Check 2 with documentation note N1, no content defect).
G1 is submitted for owner acceptance; this verification does not make it ACCEPTED or FROZEN.
