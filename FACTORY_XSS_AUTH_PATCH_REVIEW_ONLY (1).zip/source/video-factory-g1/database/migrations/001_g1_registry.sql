-- G1 registry schema — AI Video Production Factory, programme migration set v1.
-- Standalone numbering: integration/renumbering into any existing migration chain
-- waits on owner decisions OD-F01/OD-F02 (see LOCK_G1.md).
-- PostgreSQL 16. Idempotent within a fresh database: apply once.

BEGIN;

CREATE TABLE IF NOT EXISTS workflow_versions (
    workflow_version TEXT PRIMARY KEY,
    status           TEXT NOT NULL CHECK (status IN ('PROPOSED','APPROVED','FROZEN','RETIRED')),
    definition_hash  TEXT NOT NULL,
    source_sha256    TEXT NOT NULL,
    created_at       TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS stations (
    station          INT PRIMARY KEY CHECK (station BETWEEN 1 AND 6),
    name             TEXT NOT NULL,
    operation_count  INT NOT NULL CHECK (operation_count > 0)
);

CREATE TABLE IF NOT EXISTS steps (
    step_id          TEXT PRIMARY KEY CHECK (step_id ~ '^[0-9]{2}$'),
    station          INT NOT NULL REFERENCES stations(station),
    name             TEXT NOT NULL,
    deliverable      TEXT NOT NULL,
    pass_condition   TEXT NOT NULL,
    capability_slot  TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS operation_definitions (
    workflow_version TEXT NOT NULL REFERENCES workflow_versions(workflow_version),
    operation_id     TEXT NOT NULL CHECK (operation_id ~ '^[0-9]{2}\.[0-9]{2}$'),
    step_id          TEXT NOT NULL REFERENCES steps(step_id),
    station          INT NOT NULL REFERENCES stations(station),
    title            TEXT NOT NULL,
    responsibility   TEXT NOT NULL,
    input_schema     TEXT NOT NULL,
    output_schema    TEXT NOT NULL,
    capability_slot  TEXT NOT NULL,
    validator_policy JSONB NOT NULL,
    approval_policy  TEXT NOT NULL,
    resource_ceiling JSONB NOT NULL,
    unit_key         TEXT NOT NULL,
    PRIMARY KEY (workflow_version, operation_id)
);

CREATE TABLE IF NOT EXISTS dependency_templates (
    workflow_version TEXT NOT NULL,
    from_operation   TEXT NOT NULL,
    to_operation     TEXT NOT NULL,
    kind             TEXT NOT NULL CHECK (kind IN ('REQUIRED','OPTIONAL')),
    PRIMARY KEY (workflow_version, from_operation, to_operation),
    FOREIGN KEY (workflow_version, from_operation)
        REFERENCES operation_definitions(workflow_version, operation_id),
    FOREIGN KEY (workflow_version, to_operation)
        REFERENCES operation_definitions(workflow_version, operation_id)
);

CREATE TABLE IF NOT EXISTS capability_versions (
    capability_id    TEXT NOT NULL,
    version          TEXT NOT NULL,
    kind             TEXT NOT NULL CHECK (kind IN ('STEP_SLOT','CREATIVE','NI_COMPONENT')),
    status           TEXT NOT NULL CHECK (status IN ('PROPOSED','EXPERIMENTAL','BENCHMARKED','APPROVED','PINNED','RETIRED')),
    serves_steps     JSONB NOT NULL DEFAULT '[]'::jsonb,
    model_policy_class TEXT,
    contract_summary TEXT,
    benchmark_evidence_ref TEXT,
    PRIMARY KEY (capability_id, version)
);

-- Skeleton only (G1): execution plans are authored per capability under the
-- promotion protocol; no plan rows are seeded by G1.
CREATE TABLE IF NOT EXISTS execution_plan_versions (
    plan_id          TEXT PRIMARY KEY,
    capability_id    TEXT NOT NULL,
    capability_version TEXT NOT NULL,
    status           TEXT NOT NULL CHECK (status IN ('PROPOSED','APPROVED','RETIRED')),
    actions          JSONB NOT NULL DEFAULT '[]'::jsonb,
    FOREIGN KEY (capability_id, capability_version)
        REFERENCES capability_versions(capability_id, version)
);

CREATE TABLE IF NOT EXISTS genre_profile_refs (
    genre_key        TEXT PRIMARY KEY,
    status           TEXT NOT NULL CHECK (status IN ('PROPOSED','APPROVED')),
    source_mechanism TEXT NOT NULL
);

COMMIT;
