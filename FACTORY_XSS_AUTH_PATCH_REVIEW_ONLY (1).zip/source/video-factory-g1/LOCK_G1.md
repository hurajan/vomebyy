# G1 LOCK — Operation & Capability Registry (Master Instructions)

- **Lock confirmed by:** Raj (owner), 2026-10-27 22:25 EDT — "Lock G1 first (registry, host-independent)"
- **Programme:** AI Video Production Factory, Master Implementation Guide v1.3 + A–Z Implementation Guide §17
- **Stage:** G1 only. G0 remains BLOCKED on G0.6 host verification — G1 is host-independent and was explicitly sequenced first by the owner (OD-F08). G2–G9 are NOT authorized.
- **Baseline pinned:**
  - A–Z Guide: `~/workspace/goals/storytelling-studio-v1-1-rebuild/files/AI_Video_Production_Factory_Implementation_Guide_A-Z.md` (PROPOSED; owner adopted it as the G1 build reference by confirming this lock)
  - S1 `Six_Station_192_Operation_Runtime_Map.md` SHA-256 `dfe8065bfd4402fa7169a8654e0ff108cede5f6e3e26bb06baaf1eb67ab4a878`
  - S2 `192_documented_atomic_operations.txt` SHA-256 `0f3f38711c9761a67c161862feacbc72b08e1c172935691431e2f0cbbc8b7a8d`
  - S3 `Content_Automation_2026.md` SHA-256 `9d3fac64a722516c7f8c201b0a59cb9a7ae3addfc988d136ed533c98790f8a75`
  - Frozen Studio baseline `72414ed` is **read-only reference** for reuse (genre profile keys from migration 0077). It is not modified by G1.
- **Scope (in):**
  1. 192 operation definitions as versioned seed data (`workflow_version 1.0.0`), generated from S2 verbatim responsibilities, with station/step metadata, dependency templates, capability slots, validator policies, approval policies, resource-ceiling policy.
  2. Output contracts: one JSON Schema per step (16), referenced by every operation in that step.
  3. Capability registry skeleton: 16 step capability slots + the 8 creative capabilities (A–Z Guide §6.3), all status PROPOSED, no benchmark evidence, no approved model bindings.
  4. Genre profile references: the 8 existing keys from migration 0077 (drama, mystery, thriller, romance, comedy, documentary, educational, confession), status PROPOSED — references only, no new genre content.
  5. Standalone SQL migration set `001_g1_registry.sql` (factory programme numbering; integration/renumbering into any existing chain waits on OD-F01/OD-F02).
  6. Loader + validator (Python stdlib) that (a) validates seed data against A–Z §5.2 rules a–f, (b) loads into a scratch PostgreSQL 16 database, (c) verifies in-DB counts and integrity, (d) emits a validation report with the canonical definition hash.
  7. Builder tests for the validator (tamper cases must fail).
- **Scope (out, explicitly):** coordinator/state machine (G2; OD-F05 vocabulary not yet ratified — G1 records no engine states), dashboard (G3), station workflows / n8n (G4–G8; OD-F01 open), provider adapters or credentials, any OVHcloud access, any change to the frozen Studio repo, monetary resource ceilings (G1 records `PIN_AT_PRODUCTION` policy instead of invented dollar values — A–Z §5.3).
- **Dependency template rule T-DEP-01 (recorded, PROPOSED):** within a step, operation N depends on operation N−1 (REQUIRED); the first operation of steps 02–16 depends on the last operation of the previous step (REQUIRED). Rationale: S2/S3 define the operations as a sequential, artifact-producing chain per step. Finer-grained cross-step artifact dependencies are capability-plan work (G2+), not G1.
- **PASS criteria (A–Z §17, G1):** loader validation report shows 192/192 definitions, unique IDs `01.01`–`16.12`, dependency + schema checks pass, no commercial provider name in any seed/contract, definitions hash-pinned; in-DB verification on real PostgreSQL 16 concurs; builder tests green; independent verifier reproduces from a clean extract.
- **Protocol:** builder ≠ verifier; status on completion = SUBMITTED for owner acceptance. Not ACCEPTED, not FROZEN, until Raj rules.
