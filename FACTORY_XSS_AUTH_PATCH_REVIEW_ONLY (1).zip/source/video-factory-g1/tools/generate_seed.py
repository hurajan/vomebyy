#!/usr/bin/env python3
"""Generate the G1 operation registry seed from the pinned source S2.

Deterministic: same input file -> same output bytes (sorted keys, stable order).

Provenance / normalization (verifier note N1, closed 2026-10-27): each source line is
"<op_id> — <label prefix>NN. <responsibility sentence>". The seed's `responsibility`
is the responsibility sentence copied character-exactly; the redundant label prefix
is stripped (185 lines: "Operation NN. "; 7 lines: a duplicated title fragment ending
in "NN. " where the source repeats the title before the full sentence). Every seed
responsibility is therefore an exact suffix of its source line — no words altered,
added, or truncated. Titles are generated labels (first phrase of the sentence).
"""
import hashlib
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SOURCE = Path.home() / "workspace/user/files/192_documented_atomic_operations.txt"
EXPECTED_SOURCE_SHA256 = "0f3f38711c9761a67c161862feacbc72b08e1c172935691431e2f0cbbc8b7a8d"

# step_id -> (name, station, deliverable, pass_condition, capability_slot,
#             approval_policy, unit_key, step_validators)
STEP_META = {
    "01": ("Intake", 1, "Production Charter",
           "Validate fields, approve authority and spending limits.",
           "charter_intake", "PRODUCER_AND_BUDGET_OWNER", "production",
           ["charter_completeness"]),
    "02": ("Rights & Safety", 1, "Rights Register",
           "Block consequential unresolved rights or safety risks.",
           "rights_review", "RIGHTS_OWNER", "asset",
           ["rights_decision_present", "vendor_policy_check"]),
    "03": ("Truth", 2, "Canon Manifest",
           "Approve evidence classifications and world-rule consistency.",
           "truth_canon", "CANON_STEWARD", "claim",
           ["claim_classification_present", "chronology_consistency", "world_rule_consistency"]),
    "04": ("People", 2, "People Manifest + Character State Ledger",
           "Validate identity, agency, permissions and state continuity.",
           "people_registry", "EDITORIAL", "person",
           ["identity_uniqueness", "distinctiveness", "state_continuity"]),
    "05": ("Story", 3, "Story Architecture + Experience Map",
           "Evaluate coherence, clarity, motivation and legitimate promises.",
           "story_architecture", "EDITORIAL", "story",
           ["causality_check", "canon_validation", "nq_story_eval"]),
    "06": ("Beat Graph", 3, "Beat Graph + State Deltas",
           "Verify causality, knowledge eligibility and setup/payoff.",
           "beat_graph", "EDITORIAL", "beat",
           ["causal_vs_temporal_edges", "knowledge_eligibility", "setup_payoff_integrity"]),
    "07": ("Scenes", 3, "Scene Contracts",
           "Check coverage, chronology, feasibility and scene purpose.",
           "scene_design", "EDITORIAL", "scene",
           ["beat_coverage", "entry_exit_state_present", "production_feasibility"]),
    "08": ("Script", 3, "Versioned Script + Line IDs",
           "Run textual and spoken checks; request script human gate approval.",
           "script_writing", "HUMAN_GATE_SCRIPT", "scene",
           ["text_fidelity", "knowledge_eligibility", "setup_payoff_integrity", "duration_estimate"]),
    "09": ("Direction", 4, "Direction Bible",
           "Check consistency with approved script and creative scope.",
           "direction", "DIRECTOR", "scene",
           ["script_consistency", "scope_consistency"]),
    "10": ("Shot & Sound Design", 4, "Shot Manifest + Sound Plan",
           "Verify coverage, estimated cost and production feasibility.",
           "shot_sound_design", "DIRECTOR", "shot",
           ["coverage_sufficiency", "reveal_conceal_check", "cost_estimate_present"]),
    "11": ("Production", 4, "Verified Media Manifests",
           "Accept only rights-compliant, technically valid, creatively appropriate assets.",
           "media_production", "PRODUCER", "shot",
           ["rights_decision_present", "technical_validity", "identity_continuity", "textual_fidelity"]),
    "12": ("Edit", 5, "Editorial Timeline + Rough Cut",
           "Pass editorial quality and cross-modal verification.",
           "edit", "EDITORIAL", "sequence",
           ["cross_modal_qa", "reveal_timing", "rule_of_six_rubric", "dialogue_intelligibility"]),
    "13": ("Master", 5, "Master MP4 + QC Report",
           "Human gate approves exact master hash.",
           "master_qc", "HUMAN_GATE_MASTER", "master",
           ["file_integrity", "codec_audio_caption_checks", "accessibility_rights_audit"]),
    "14": ("Derive & Package", 5, "Derivative Package Manifest",
           "Approve each independent package against relevant constraints.",
           "derivative_packaging", "HUMAN_GATE_DERIVATIVE", "derivative",
           ["independent_comprehensibility", "platform_profile", "rights_decision_present"]),
    "15": ("Distribute", 6, "Publication Receipts",
           "Verify publication and scheduling outcomes.",
           "distribution", "HUMAN_GATE_RELEASE", "release",
           ["release_authorization_bound", "publication_reconciliation"]),
    "16": ("Learn", 6, "Learning Report + Capability Proposals",
           "Separate observations from AI interpretations; require approval for improvements.",
           "learning_analysis", "LEARNING_OWNER", "production",
           ["observation_interpretation_separation", "causal_claim_check"]),
}

LINE_RE = re.compile(r"^(\d{2})\.(\d{2}) — (.*)$")
PREFIX_RE = re.compile(r"^.*?(\d{2})\. (.*)$", re.DOTALL)


def make_title(responsibility: str) -> str:
    head = re.split(r"[:;,]", responsibility)[0].strip()
    words = head.split()
    return " ".join(words[:8]).rstrip(".")


def main() -> int:
    raw = SOURCE.read_bytes()
    digest = hashlib.sha256(raw).hexdigest()
    if digest != EXPECTED_SOURCE_SHA256:
        print(f"FATAL: source hash mismatch: {digest} != {EXPECTED_SOURCE_SHA256}")
        return 1
    ops = []
    for line in raw.decode("utf-8").splitlines():
        m = LINE_RE.match(line.strip())
        if not m:
            continue
        step_id, _op_no, rest = m.group(1), m.group(2), m.group(3)
        pm = PREFIX_RE.match(rest)
        responsibility = pm.group(2).strip() if pm else rest.strip()
        name, station, deliverable, pass_condition, slot, approval, unit_key, validators = STEP_META[step_id]
        op_id = f"{step_id}.{_op_no}"
        ops.append({
            "operation_id": op_id,
            "workflow_version": "1.0.0",
            "step_id": step_id,
            "station": station,
            "title": make_title(responsibility),
            "responsibility": responsibility,
            "input_schema": f"contracts/step-{step_id}/input.schema.json",
            "output_schema": f"contracts/step-{step_id}/output.schema.json",
            "capability_slot": slot,
            "validator_policy": ["schema_validation", "dependency_integrity"] + validators,
            "approval_policy": approval,
            "resource_ceiling": {
                "max_attempts": 3,
                "max_cost_usd_per_unit": None,
                "wall_clock_s": None,
                "cost_policy": "PIN_AT_PRODUCTION",
            },
            "unit_key": unit_key,
        })
    # dependency templates per LOCK rule T-DEP-01
    deps = []
    ids = [o["operation_id"] for o in ops]
    for i, oid in enumerate(ids):
        if i == 0:
            continue
        deps.append({"from_operation": ids[i - 1], "to_operation": oid, "kind": "REQUIRED"})
    steps = []
    for step_id in sorted(STEP_META):
        name, station, deliverable, pass_condition, slot, approval, unit_key, _v = STEP_META[step_id]
        steps.append({
            "step_id": step_id, "station": station, "name": name,
            "deliverable": deliverable, "pass_condition": pass_condition,
            "capability_slot": slot,
        })
    stations = [
        {"station": 1, "name": "Intake & Authority", "steps": ["01", "02"], "operations": 24},
        {"station": 2, "name": "Reality & People", "steps": ["03", "04"], "operations": 24},
        {"station": 3, "name": "Narrative", "steps": ["05", "06", "07", "08"], "operations": 48},
        {"station": 4, "name": "Direction & Capture", "steps": ["09", "10", "11"], "operations": 36},
        {"station": 5, "name": "Post & Package", "steps": ["12", "13", "14"], "operations": 36},
        {"station": 6, "name": "Release & Learn", "steps": ["15", "16"], "operations": 24},
    ]
    seed = {
        "workflow_version": "1.0.0",
        "status": "PROPOSED",
        "source": {"file": SOURCE.name, "sha256": digest},
        "stations": stations,
        "steps": steps,
        "operations": ops,
        "dependency_templates": deps,
    }
    canonical = json.dumps(seed, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    seed["definition_hash"] = hashlib.sha256(canonical.encode("utf-8")).hexdigest()
    out = ROOT / "seed-definitions" / "workflow-1.0.0" / "operations.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(seed, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"operations={len(ops)} dependencies={len(deps)} definition_hash={seed['definition_hash']}")
    print(f"wrote {out}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
