#!/usr/bin/env python3
"""Gate 04 — execution-plan generator.

Generates seed-definitions/workflow-1.0.0/plans.json: one versioned
capability execution plan per operation (192), each an ordered list of
atomic actions with typed input/output specs (copied from the worker
service's actions.py registry — the single source for spec shapes),
timeout, idempotency rule and cost policy.

Binding discipline (G01-D01/D02):
  * The 19 operations with proven operation-specific builders
    (payloads.SPECIFIC_OPS) decompose as [manifest, op.build_payload,
    emit] — the builder IS the implementation, outputs unchanged.
  * Every other operation is classified below (CLASS) by the nature of
    its work, from its registry title/responsibility:
      - deterministic record/check/attest work over structured inputs
        binds to engine actions (extract/project/index/verify/cross-
        check/chronology/metrics/attest) that produce their outputs
        FROM the inputs or fail explicitly;
      - creative authoring, semantic judgment, human decisions and
        external-platform work bind NOTHING today: their core action
        is recorded UNBOUND with the implementation that would serve
        it (creative.generate, semantic.evaluate, human.decision,
        external.*, media.generate) and the reason. Executing such a
        plan fails explicitly at that action — never a generic
        success.
      - media processing/rendering (media.process / media.render)
        binds to the local FFmpeg tool implementations since MM-06
        (worker_service media.ffmpeg_process / media.ffmpeg_render):
        deterministic tool operations over the media bytes the
        inputs resolve to, failing explicitly when no media input
        exists.
      - creative authoring, media generation and external
        platform/provider interaction bind since MM-10 to the
        EXPLICITLY SIMULATED mock implementations (worker_service
        mock.creative_generate / mock.media_generate /
        mock.external_platform / mock.external_provider): fixture
        outputs labeled simulated in-band, executable ONLY under a
        pinned 'mock' binding — under any other binding the
        implementation refuses (ActionRefused), so no simulated
        output can be produced under a real or deterministic label.
        Semantic judgment and human decisions remain UNBOUND: no
        implementation may take them.
  * 'mixed' plans bind their structural core and carry one UNBOUND
    judgment action (binding_status PARTIALLY_BOUND).

Regenerable and diff-able: deterministic output (sorted keys, stable
ordering); plan_hash per plan + plans_hash over the file, canonicalized
exactly as worker_service/plans.py and registry_tool.py compute them.
"""
import hashlib
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SEED_DIR = ROOT / "seed-definitions" / "workflow-1.0.0"
WORKER = (Path.home() / "workspace/video-factory-real-ai-programme"
          / "gate-c" / "worker_service")
sys.path.insert(0, str(WORKER))
import actions as worker_actions  # noqa: E402
import payloads as worker_payloads  # noqa: E402

PLAN_VERSION = "1.0.0"
IDEMPOTENCY = {"rule": "attempt_scoped_replay",
               "record_unique": "(attempt_id, action_key)"}
COST_BOUND = {"kind": "included_in_operation_binding", "metered": False}
COST_UNBOUND = {"kind": "unbound_no_cost_until_bound", "metered": False}

SPECIFIC_OUTPUTS = {
    "01.01": "premise_record", "01.12": "production_charter",
    "02.12": "rights_register", "03.02": "source_registration",
    "03.12": "canon_manifest", "04.12": "people_manifest",
    "05.12": "story_architecture", "06.12": "beat_graph",
    "07.12": "scene_set", "08.12": "script",
    "09.12": "direction_package", "10.12": "shot_manifest",
    "11.12": "asset_registry", "12.12": "edit_timeline",
    "13.12": "master_package", "14.01": "derivative_portfolio",
    "14.12": "derivative_package", "15.12": "distribution_record",
    "16.12": "learning_record",
}


def _action(seq, key, impl, spec=None, timeout=30, unbound=None,
            declared_impl=None):
    a = {"seq": seq, "action_key": key,
         "implementation": impl if not unbound else None,
         "binding_status": "UNBOUND" if unbound else "BOUND",
         "spec": spec or {},
         "timeout_s": timeout,
         "idempotency": IDEMPOTENCY,
         "cost_policy": COST_UNBOUND if unbound else COST_BOUND}
    if impl:
        a["input_spec"] = worker_actions.INPUT_SPECS[impl]
        a["output_spec"] = worker_actions.OUTPUT_SPECS[impl]
    else:
        a["declared_implementation"] = declared_impl
        a["unbound_reason"] = unbound
        a["input_spec"] = {"type": "operation_inputs"}
        a["output_spec"] = {"type": "operation_output"}
    return a


class PlanBuilder:
    """Accumulates actions, tracking the latest records-producing key
    so from_action specs chain deterministically."""

    def __init__(self):
        self.actions = []
        self.last_records_key = None

    def add(self, key, impl, spec=None, timeout=30, unbound=None,
            declared_impl=None, produces_records=False):
        a = _action(len(self.actions) + 1, key, impl, spec, timeout,
                    unbound, declared_impl)
        self.actions.append(a)
        if produces_records:
            self.last_records_key = key
        return a

    def manifest(self):
        return self.add("inputs.manifest", "engine.manifest_inputs")

    def analyze(self):
        return self.add("content.analyze", "engine.analyze_content")

    def extract(self):
        return self.add("records.extract", "engine.extract_records",
                        produces_records=True)

    def core(self, impl, key, spec=None, timeout=30):
        return self.add(key, impl, spec, timeout,
                        produces_records=True)

    def from_spec(self, extra=None):
        spec = {"from_action": self.last_records_key}
        spec.update(extra or {})
        return spec

    def unbound(self, kind, reason):
        timeout = 300
        return self.add(kind.replace(".", "_"), None, timeout=timeout,
                        unbound=reason, declared_impl=kind)

    def simulate(self, kind):
        # MM-10: bound to the explicitly-simulated mock implementation.
        # The action key stays "creative_generate" etc. (record
        # continuity with the Gate 04 UNBOUND declaration it
        # replaces); the implementation runs ONLY under a pinned
        # 'mock' binding and refuses under any other binding.
        return self.add(kind.replace(".", "_"), f"mock.{kind}",
                        timeout=300,
                        produces_records=kind in ("creative.generate",
                                                  "external.provider"))

    def media(self, transform, params=None):
        # MM-06: media.process bound to the local FFmpeg tool. The
        # action key stays "media_process" (record continuity with
        # the Gate 04 UNBOUND declaration it replaces).
        spec = {"transform": transform}
        spec.update(params or {})
        return self.add("media_process", "media.ffmpeg_process", spec,
                        timeout=300)

    def render(self, spec=None):
        # MM-06: media.render (op 13.03) bound to the local FFmpeg
        # tool rendering the review master.
        return self.add("media_render", "media.ffmpeg_render",
                        spec or {"width": 1280, "height": 720, "crf": 18},
                        timeout=300)

    def compose(self):
        return self.add("record.compose", "engine.compose_document")

    def emit(self, artifact_type, deliverable_schema=None):
        spec = {"artifact_type": artifact_type}
        if deliverable_schema:
            spec["deliverable_schema"] = deliverable_schema
        return self.add("output.emit", "engine.emit_output", spec)


def slugify(title):
    out = []
    for ch in title.lower():
        out.append(ch if ch.isalnum() else "_")
    slug = "".join(out)
    while "__" in slug:
        slug = slug.replace("__", "_")
    return slug.strip("_")[:60].strip("_")


# ------------------------------------------------------- classification
# Shorthand cores: ("analyze",) ("extract",) ("index",) ("project", fields)
# ("group", field) ("assign", prefix) ("cross",) ("verify", fields)
# ("sort",) ("metrics",) ("attest",) ("unbound", kind, reason)
R_CREATIVE = ("requires creative authoring (provider generation engine, "
              "Gate 07); no deterministic implementation can author this "
              "content from inputs")
R_SEMANTIC = ("requires semantic judgment over content (Gate 06/08 "
              "evaluation); no deterministic implementation can make "
              "this judgment")
R_HUMAN = ("requires an accountable human decision; automation must not "
           "take it (human-gate machinery covers step exits only)")
R_PLATFORM = ("requires a live external platform/provider interaction "
              "(Gate 07/11); no local implementation exists")
R_PROVIDER = ("requires a credentialed provider call (Gate 07, OD-A3); "
              "adapters refuse without credentials")
R_MEDIA_GEN = ("requires media generation/recording (Gate 07 providers); "
               "no local engine produces media")
R_MEDIA_RENDER = ("requires a media rendering engine; none is bound in "
                  "the local stack")
R_MEDIA_PROC = ("requires media processing over media bytes (edit/mix/"
                "sync); no local engine is bound")

CLASS = {
    # ---- step 01 charter_intake
    "01.02": ([("unbound", "semantic.evaluate", R_SEMANTIC)],
              "classifying the source's nature is a judgment over content"),
    "01.03": ([("unbound", "semantic.evaluate", R_SEMANTIC)],
              "format classification is a judgment over the source material"),
    "01.04": ([("unbound", "creative.generate", R_CREATIVE)],
              "audience definition is authored policy content"),
    "01.05": ([("extract",), ("project", ["language", "territories",
                                          "platforms", "accessibility_needs"])],
              "capture = projection of declared production parameters from inputs"),
    "01.06": ([("unbound", "human.decision", R_HUMAN)],
              "stand-alone vs series is a producer choice"),
    "01.07": ([("unbound", "creative.generate", R_CREATIVE)],
              "dramatic-experience hypotheses are authored content"),
    "01.08": ([("extract",), ("project", ["time_ceiling", "cost_ceiling",
                                          "labor_ceiling", "stop_loss"])],
              "ceilings are declared input data, recorded by projection"),
    "01.09": ([("extract",), ("verify", ["source_id", "status"])],
              "evidence inventory = registered records, completeness-checked"),
    "01.10": ([("unbound", "human.decision", R_HUMAN)],
              "assigning accountable people is a producer decision"),
    "01.11": ([("unbound", "creative.generate", R_CREATIVE)],
              "acceptance benchmarks are authored criteria"),
    # ---- step 02 rights_review
    "02.01": ([("extract",), ("index",)],
              "contributors/rights are extracted and indexed from input records"),
    "02.02": ([("unbound", "semantic.evaluate", R_SEMANTIC)],
              "legal-basis mapping per asset is a rights judgment"),
    "02.03": ([("unbound", "semantic.evaluate", R_SEMANTIC)],
              "safeguarding risk assessment is a judgment, human-led capability"),
    "02.04": ([("unbound", "semantic.evaluate", R_SEMANTIC)],
              "synthetic-identity classification is a judgment over assets"),
    "02.05": ([("unbound", "semantic.evaluate", R_SEMANTIC)],
              "policy application requires expert human review per its text"),
    "02.06": ([("unbound", "human.decision", R_HUMAN)],
              "restricted claims/portrayals are defined by the rights owner"),
    "02.07": ([("extract",), ("verify", ["actor", "subject", "purpose", "scope"])],
              "consent record = assembly from input data, required fields verified"),
    "02.08": ([("unbound", "semantic.evaluate", R_SEMANTIC)],
              "vendor retention/terms evaluation is a judgment over external terms"),
    "02.09": ([("unbound", "human.decision", R_HUMAN)],
              "age-gate and format requirements are policy settings by the owner"),
    "02.10": ([("unbound", "human.decision", R_HUMAN)],
              "rights decisions per asset are human decisions ('do not grant by silence')"),
    "02.11": ([("cross",), ("unbound", "human.decision", R_HUMAN)],
              "downstream impact is a structural cross-check; the triggers themselves are policy"),
    # ---- step 03 truth_canon
    "03.01": ([("unbound", "semantic.evaluate", R_SEMANTIC)],
              "identifying the governing universe/jurisdiction is a judgment"),
    "03.03": ([("unbound", "external.provider", R_PROVIDER)],
              "claim extraction from source text is language-model work"),
    "03.04": ([("unbound", "semantic.evaluate", R_SEMANTIC)],
              "assertion classification (verified/contested/invented) is the truth judgment itself"),
    "03.05": ([("unbound", "semantic.evaluate", R_SEMANTIC)],
              "reliability assessment is a judgment over sources"),
    "03.06": ([("extract",), ("sort",)],
              "chronology = deterministic ordering of dated claim records"),
    "03.07": ([("unbound", "creative.generate", R_CREATIVE)],
              "world rules are authored canon"),
    "03.08": ([("extract",), ("index",)],
              "knowledge boundaries = boundary table indexed by character from knowledge records"),
    "03.09": ([("unbound", "creative.generate", R_CREATIVE)],
              "a hidden-truth ledger is authored canon"),
    "03.10": ([("extract",), ("sort",), ("cross",)],
              "impossible sequences = chronology inversions + dangling references over records"),
    "03.11": ([("unbound", "human.decision", R_HUMAN)],
              "routing contradictions is an escalation to the authorized editor"),
    # ---- step 04 people_registry
    "04.01": ([("extract",), ("index",)],
              "participants are extracted and indexed from canon/source records"),
    "04.02": ([("extract",), ("assign", "P")],
              "permanent IDs = stable deterministic assignment over participant records"),
    "04.03": ([("unbound", "semantic.evaluate", R_SEMANTIC)],
              "evidence-vs-invented determination is a truth judgment"),
    "04.04": ([("unbound", "creative.generate", R_CREATIVE)],
              "biography/desire/fear are authored character content"),
    "04.05": ([("unbound", "creative.generate", R_CREATIVE)],
              "relationship power/histories are authored content"),
    "04.06": ([("extract",), ("project", ["person_ref", "voice", "appearance",
                                           "age_variant"])],
              "embodiment variants are recorded by projection of supplied data"),
    "04.07": ([("unbound", "creative.generate", R_CREATIVE)],
              "agency definition is authored character content"),
    "04.08": ([("extract",), ("project", ["person_ref", "knowledge", "beliefs",
                                           "possessions", "emotional_context"])],
              "knowledge-state ledger = initialization from people records"),
    "04.09": ([("unbound", "creative.generate", R_CREATIVE)],
              "behavioral tendencies are authored content"),
    "04.10": ([("unbound", "creative.generate", R_CREATIVE)],
              "plausible-change mapping is authored analysis"),
    "04.11": ([("extract",), ("sort",), ("unbound", "semantic.evaluate", R_SEMANTIC)],
              "chronology conflicts are structural; dialogue/stereotype checks are semantic"),
    # ---- step 05 story_architecture
    "05.01": ([("extract",), ("index",)],
              "premise resolution = assembly/indexing of canon, people and context inputs"),
    "05.02": ([("unbound", "human.decision", R_HUMAN)],
              "narrative-mode selection is a creative choice by the author"),
    "05.03": ([("unbound", "creative.generate", R_CREATIVE)],
              "the thematic question is authored content"),
    "05.04": ([("extract",), ("project", ["person_ref", "desire", "obstacle",
                                           "stakes"])],
              "protagonists/stakes are projected from people records"),
    "05.05": ([("unbound", "human.decision", R_HUMAN)],
              "endpoint selection is an authorial decision"),
    "05.06": ([("unbound", "creative.generate", R_CREATIVE)],
              "the causal chain is authored narrative"),
    "05.07": ([("unbound", "creative.generate", R_CREATIVE)],
              "transformation planning is authored narrative"),
    "05.08": ([("unbound", "creative.generate", R_CREATIVE)],
              "revelation allocation is authored narrative"),
    "05.09": ([("unbound", "creative.generate", R_CREATIVE)],
              "anticipation/release design is authored narrative"),
    "05.10": ([("extract",), ("cross",)],
              "setup/payoff enforcement = cross-check that payoffs reference setups"),
    "05.11": ([("unbound", "semantic.evaluate", R_SEMANTIC)],
              "whole-story cohesion assessment is a judgment"),
    # ---- step 06 beat_graph
    "06.01": ([("extract",), ("assign", "B")],
              "beat_ids = stable deterministic assignment over narrative-change records"),
    "06.02": ([("attest",)],
              "version pinning = attestation over the pinned input versions"),
    "06.03": ([("extract",), ("project", ["beat_ref", "time", "place",
                                           "participants", "goals"])],
              "entry state = record assembly from beat/scene inputs"),
    "06.04": ([("extract",), ("project", ["beat_ref", "pov", "knowledge"])],
              "POV/knowledge = record assembly from inputs"),
    "06.05": ([("unbound", "creative.generate", R_CREATIVE)],
              "triggers/objectives are authored beat content"),
    "06.06": ([("unbound", "creative.generate", R_CREATIVE)],
              "resistance/tactic/consequence are authored beat content"),
    "06.07": ([("extract",), ("project", ["beat_ref", "exit_state", "knowledge",
                                           "beliefs", "relationships"])],
              "exit state = state-delta records applied from inputs"),
    "06.08": ([("extract",), ("index",), ("cross",)],
              "causal links = indexing + referential cross-check over beat records"),
    "06.09": ([("unbound", "creative.generate", R_CREATIVE)],
              "stakes/meaning changes are authored beat content"),
    "06.10": ([("extract",), ("cross",)],
              "setup/clue/payoff links = referential cross-check over beat records"),
    "06.11": ([("unbound", "creative.generate", R_CREATIVE)],
              "audience attention/emotional hypotheses are authored content"),
    # ---- step 07 scene_design
    "07.01": ([("extract",), ("group", "scene_ref")],
              "scene grouping = grouping beat records by their scene reference"),
    "07.02": ([("unbound", "semantic.evaluate", R_SEMANTIC)],
              "indispensability/function is a design judgment"),
    "07.03": ([("extract",), ("project", ["scene_ref", "entry_state", "location",
                                           "participants"])],
              "entry state = record assembly from scene inputs"),
    "07.04": ([("unbound", "human.decision", R_HUMAN)],
              "scene POV is a design choice"),
    "07.05": ([("unbound", "creative.generate", R_CREATIVE)],
              "character objectives are authored scene content"),
    "07.06": ([("unbound", "creative.generate", R_CREATIVE)],
              "opposition/tension are authored scene content"),
    "07.07": ([("unbound", "creative.generate", R_CREATIVE)],
              "tactics under resistance are authored scene content"),
    "07.08": ([("unbound", "creative.generate", R_CREATIVE)],
              "stakes/costs of action are authored scene content"),
    "07.09": ([("unbound", "creative.generate", R_CREATIVE)],
              "turning-point placement is authored scene content"),
    "07.10": ([("unbound", "semantic.evaluate", R_SEMANTIC)],
              "audience perception/inference is a judgment"),
    "07.11": ([("extract",), ("project", ["scene_ref", "exit_state",
                                           "unresolved_promise", "transition"])],
              "exit state = record assembly from scene inputs"),
    # ---- step 08 script_writing
    "08.01": ([("extract",), ("index",), ("cross",)],
              "resolving approved references = indexing + referential cross-check"),
    "08.02": ([("unbound", "human.decision", R_HUMAN)],
              "script format is an authorial choice"),
    "08.03": ([("extract",), ("verify", ["id", "scene_ref"])],
              "state/boundary preservation = field verification over script records"),
    "08.04": ([("unbound", "creative.generate", R_CREATIVE)],
              "playable actions are written content"),
    "08.05": ([("unbound", "creative.generate", R_CREATIVE)],
              "dialogue composition is written content"),
    "08.06": ([("unbound", "creative.generate", R_CREATIVE)],
              "exposition placement is written content"),
    "08.07": ([("unbound", "creative.generate", R_CREATIVE)],
              "silence/interruption design is written content"),
    "08.08": ([("unbound", "creative.generate", R_CREATIVE)],
              "clue placement/reveal timing are authored decisions in the text"),
    "08.09": ([("unbound", "creative.generate", R_CREATIVE)],
              "transitions/narrator subjectivity are written content"),
    "08.10": ([("unbound", "human.decision", R_HUMAN)],
              "read-aloud comprehension testing is a performed human activity"),
    "08.11": ([("extract",), ("metrics",), ("unbound", "creative.generate", R_CREATIVE)],
              "duration estimation is metric computation over lines; revision is authoring"),
}

CLASS.update({
    # ---- step 09 direction
    "09.01": ([("analyze",)],
              "reading the arc = content analysis package over the approved inputs"),
    "09.02": ([("unbound", "creative.generate", R_CREATIVE)],
              "directorial concept is authored content"),
    "09.03": ([("unbound", "semantic.evaluate", R_SEMANTIC)],
              "subtext/power interpretation per scene is a judgment"),
    "09.04": ([("unbound", "creative.generate", R_CREATIVE)],
              "performance intentions are authored direction"),
    "09.05": ([("unbound", "human.decision", R_HUMAN)],
              "treatment of silence/pacing is a directorial choice"),
    "09.06": ([("unbound", "human.decision", R_HUMAN)],
              "improvisation limits are a directorial ruling"),
    "09.07": ([("unbound", "human.decision", R_HUMAN)],
              "approving stylistic conventions is a director decision"),
    "09.08": ([("unbound", "semantic.evaluate", R_SEMANTIC)],
              "feasibility inspection is a judgment (rewrites go through change control)"),
    "09.09": ([("unbound", "human.decision", R_HUMAN)],
              "arbitration of creative disagreement is a human decision"),
    "09.10": ([("unbound", "creative.generate", R_CREATIVE)],
              "the Direction Bible is an authored document"),
    "09.11": ([("unbound", "human.decision", R_HUMAN)],
              "accept/revise decisions on cuts are human decisions"),
    # ---- step 10 shot_sound_design
    "10.01": ([("analyze",)],
              "loading the locked script = content analysis package over inputs"),
    "10.02": ([("unbound", "creative.generate", R_CREATIVE)],
              "coverage decomposition is design work"),
    "10.03": ([("unbound", "semantic.evaluate", R_SEMANTIC)],
              "naming informational/emotional function is a judgment"),
    "10.04": ([("unbound", "creative.generate", R_CREATIVE)],
              "blocking/geography design is authored design work"),
    "10.05": ([("unbound", "creative.generate", R_CREATIVE)],
              "framing/lens/lighting choices are design work"),
    "10.06": ([("extract",), ("project", ["id", "start_state", "end_state"])],
              "shot start/end states = record assembly from the shot list"),
    "10.07": ([("extract",), ("project", ["shot_ref", "clues_visible",
                                           "concealed"])],
              "clue perceptibility = record assembly from the reveal schedule"),
    "10.08": ([("unbound", "creative.generate", R_CREATIVE)],
              "voice perspective design is authored design work"),
    "10.09": ([("unbound", "creative.generate", R_CREATIVE)],
              "ambience/Foley/score planning is authored design work"),
    "10.10": ([("unbound", "media.generate", R_MEDIA_GEN)],
              "boards/animatics are produced media artifacts"),
    "10.11": ([("extract",), ("metrics",), ("unbound", "semantic.evaluate", R_SEMANTIC)],
              "budget is metric computation; comprehensibility/framing-safety are judgments"),
    # ---- step 11 media_production
    "11.01": ([("attest",)],
              "version pinning = attestation over the approved input versions"),
    "11.02": ([("extract",), ("verify", ["asset_ref", "cost_cap"])],
              "cost-cap checking = field verification over reservation records (the reservation itself is the claim)"),
    "11.03": ([("unbound", "external.provider", R_PROVIDER)],
              "provider capability/data-handling validation is against the real provider (Gate 07)"),
    "11.04": ([("unbound", "media.generate", R_MEDIA_GEN)],
              "preparing reference identities/sets/props is media work"),
    "11.05": ([("unbound", "human.decision", R_HUMAN)],
              "acquisition route per asset is a feasibility/rights choice"),
    "11.06": ([("unbound", "media.generate", R_MEDIA_GEN)],
              "generating/recording candidates is media production"),
    "11.07": ([("extract",), ("project", ["asset_ref", "source_id", "cost_cents"])],
              "technical metadata capture = record assembly from generation receipts"),
    "11.08": ([("unbound", "semantic.evaluate", R_SEMANTIC)],
              "identity/continuity/fidelity checks over media are judgments"),
    "11.09": ([("unbound", "semantic.evaluate", R_SEMANTIC)],
              "performance assessment is a judgment"),
    "11.10": ([("extract",), ("verify", ["id", "shot_ref"]),
               ("unbound", "human.decision", R_HUMAN)],
              "violation checks are structural; candidate selection is a decision"),
    "11.11": ([("unbound", "media.generate", R_MEDIA_GEN)],
              "repairing an asset is regeneration"),
    # ---- step 12 edit
    "12.01": ([("extract",), ("index",), ("cross",)],
              "resolving approved media = indexing + referential cross-check"),
    "12.02": ([("extract",), ("project", ["id", "source_ref", "timecode"])],
              "the EDL = assembly of source/timecode records from approved media"),
    "12.03": ([("unbound", "creative.generate", R_CREATIVE)],
              "narrative assembly is editing authorship"),
    "12.04": ([("unbound", "human.decision", R_HUMAN)],
              "performance selection/ordering is an editorial decision"),
    "12.05": ([("media", "cuts")],
              "applying cuts = segment cut/concat over the media bytes per the segments the inputs declare, local FFmpeg (MM-06)"),
    "12.06": ([("media", "sync")],
              "dialogue synchronization = audio offset applied to the media bytes by the declared offset, local FFmpeg (MM-06)"),
    "12.07": ([("media", "ambience")],
              "sound continuity = audio bed padded/trimmed to the picture duration over the media bytes, local FFmpeg (MM-06)"),
    "12.08": ([("media", "mix")],
              "mixing = two-pass EBU R128 loudness normalization over the media bytes with measured before/after, local FFmpeg (MM-06)"),
    "12.09": ([("extract",), ("cross",)],
              "clue timing check = cross-check of segment times against authorized windows in records"),
    "12.10": ([("unbound", "semantic.evaluate", R_SEMANTIC)],
              "emotional pacing is a judgment over playback"),
    "12.11": ([("unbound", "human.decision", R_HUMAN)],
              "director review decisions are human decisions"),
    # ---- step 13 master_qc
    "13.01": ([("attest",)],
              "freezing = attestation + manifest over the timeline and its dependencies"),
    "13.02": ([("extract",), ("project", ["codec", "frame_rate", "audio_format",
                                           "caption_version"])],
              "render configuration = assembly of the resolved config record"),
    "13.03": ([("render",)],
              "rendering a master = deterministic local FFmpeg render to the review-master spec (MM-06)"),
    "13.04": ([("extract",), ("verify", ["file_ref", "codec", "duration_s"])],
              "integrity checks bind at the technical-metadata record level (byte-level media probing is Gate 09/11 tooling)"),
    "13.05": ([("media", "color_check")],
              "color/loudness measurement = signalstats + loudnorm measurement over the rendered bytes, local FFmpeg (MM-06)"),
    "13.06": ([("unbound", "human.decision", R_HUMAN)],
              "full narrative playback review is a performed human review"),
    "13.07": ([("extract",), ("verify", ["file_ref", "captions"]),
               ("unbound", "semantic.evaluate", R_SEMANTIC)],
              "accessibility presence is field verification; the rights audit is a judgment"),
    "13.08": ([("media", "fix_errors")],
              "fixing errors in a new version = full re-encode repair of the media bytes to the master spec, local FFmpeg (MM-06)"),
    "13.09": ([("unbound", "human.decision", R_HUMAN)],
              "obtaining exact-file approvals is a human decision flow"),
    "13.10": ([("attest",)],
              "hashing + immutable storage reference = attestation over the master"),
    "13.11": ([("extract",), ("project", ["asset_ref", "captions", "transcript",
                                           "stems"])],
              "accessibility derivatives are registered by record assembly"),
    # ---- step 14 derivative_packaging
    "14.02": ([("extract",), ("project", ["derivative_ref", "audience",
                                           "platform", "language"])],
              "per-derivative targets are registered by record assembly"),
    "14.03": ([("unbound", "human.decision", R_HUMAN)],
              "beat/scene selection + spoiler policy is an editorial decision"),
    "14.04": ([("unbound", "semantic.evaluate", R_SEMANTIC)],
              "derivative classification is a judgment"),
    "14.05": ([("unbound", "creative.generate", R_CREATIVE)],
              "context reconstruction is authored editing"),
    "14.06": ([("media", "reedit")],
              "re-editing = segment cut/concat over the approved source media per the segments the inputs declare, local FFmpeg (MM-06)"),
    "14.07": ([("media", "reframe", {"target": {"width": 720, "height": 1280}})],
              "composition adaptation = scale/pad reframing of the media bytes to the derivative's target frame (720x1280 portrait), local FFmpeg (MM-06)"),
    "14.08": ([("media", "narration_adapt")],
              "narration/subtitle adaptation = narration audio extraction + loudness normalization (and subtitle extraction when a subtitle stream exists) over the media bytes, local FFmpeg (MM-06); translation itself remains the authorized provider workflow"),
    "14.09": ([("unbound", "creative.generate", R_CREATIVE)],
              "title/cover/chapter design is authored content"),
    "14.10": ([("unbound", "external.platform", R_PLATFORM)],
              "platform capability profiles are live external data"),
    "14.11": ([("unbound", "semantic.evaluate", R_SEMANTIC)],
              "per-version comprehensibility/truth evaluation is a judgment"),
    # ---- step 15 distribution
    "15.01": ([("attest",)],
              "resolving the exact derivative = attestation over the package hash"),
    "15.02": ([("unbound", "external.platform", R_PLATFORM)],
              "platform API/account capability checks are live external calls"),
    "15.03": ([("attest",)],
              "the authorization binding record = attestation over asset hash + account/window data"),
    "15.04": ([("extract",), ("cross",)],
              "launch-dependency respect = cross-check over embargo/quota records"),
    "15.05": ([("attest",)],
              "release ID + idempotency key = deterministic derivation (attestation hash) over inputs"),
    "15.06": ([("unbound", "external.platform", R_PLATFORM)],
              "credential resolution is secret-store access (Gate 11); never local data"),
    "15.07": ([("unbound", "external.platform", R_PLATFORM)],
              "upload/submission is a live platform call through a provider adapter"),
    "15.08": ([("unbound", "external.platform", R_PLATFORM)],
              "transcoding/moderation state lives on the platform"),
    "15.09": ([("unbound", "external.platform", R_PLATFORM)],
              "UNKNOWN reconciliation queries the provider (the coordinator reconciler owns the state machine)"),
    "15.10": ([("unbound", "external.platform", R_PLATFORM)],
              "visibility/URL verification is a live platform read"),
    "15.11": ([("unbound", "external.platform", R_PLATFORM)],
              "removal/claim monitoring is a live platform read"),
    # ---- step 16 learning_analysis
    "16.01": ([("extract",), ("index",)],
              "published IDs are resolved/indexed from distribution records"),
    "16.02": ([("extract",), ("project", ["hypothesis", "measure"])],
              "predeclared hypotheses are recorded by projection of editorial inputs"),
    "16.03": ([("unbound", "external.platform", R_PLATFORM)],
              "platform metrics collection is a live external read"),
    "16.04": ([("unbound", "human.decision", R_HUMAN)],
              "recruiting real participants is a real-world human action"),
    "16.05": ([("unbound", "human.decision", R_HUMAN)],
              "asking participants questions is a performed human research activity"),
    "16.06": ([("extract",), ("metrics",), ("unbound", "human.decision", R_HUMAN)],
              "response measurement is metric computation; the testing activity is human"),
    "16.07": ([("extract",), ("group", "format"), ("metrics",)],
              "stratification = grouping + metric computation over result records"),
    "16.08": ([("unbound", "semantic.evaluate", R_SEMANTIC)],
              "correlation-vs-causation discipline is analytical judgment"),
    "16.09": ([("unbound", "semantic.evaluate", R_SEMANTIC)],
              "triangulation with editorial review is a judgment"),
    "16.10": ([("unbound", "creative.generate", R_CREATIVE)],
              "proposed changes are authored content"),
    "16.11": ([("unbound", "human.decision", R_HUMAN)],
              "requiring authorizations is a governance action by accountable owners"),
})


# MM-10: the four action classes whose Gate 04 UNBOUND declarations
# named capabilities with no genuine local implementation (creative
# authoring, media generation, external platform/provider interaction)
# are rewritten to bound "simulate" cores served by the explicitly
# simulated mock implementations. Semantic judgment and human
# decisions are NOT rewritten — they stay UNBOUND. The rewrite is
# mechanical and total over CLASS, so the plan diff is exactly the
# set of plans whose single unbound kind is mockable (58 plans).
MOCKABLE_KINDS = {"creative.generate", "media.generate",
                  "external.platform", "external.provider"}
for _op_id, (_cores, _note) in list(CLASS.items()):
    if any(c[0] == "unbound" and c[1] in MOCKABLE_KINDS for c in _cores):
        CLASS[_op_id] = (
            [("simulate", c[1]) if (c[0] == "unbound"
                                    and c[1] in MOCKABLE_KINDS) else c
             for c in _cores],
            _note + "; MM-10: core action bound to the explicitly "
                    "simulated mock implementation (test-mode 'mock' "
                    "bindings only; refuses under any other binding)")


# ------------------------------------------------------------- assembly
def _emit_schema(op_id):
    if op_id.endswith(".12"):
        return f"step-{op_id.split('.')[0]}.schema.json"
    if op_id == "14.01":
        return "op-14.01.schema.json"
    return None


def _run_cores(pb, cores):
    for core in cores:
        kind = core[0]
        if kind == "analyze":
            pb.analyze()
        elif kind == "extract":
            pb.extract()
        elif kind == "index":
            pb.core("engine.index_records", "records.index", pb.from_spec())
        elif kind == "project":
            pb.core("engine.project_records", "records.project",
                    pb.from_spec({"fields": core[1]}))
        elif kind == "group":
            pb.core("engine.group_records", "records.group",
                    pb.from_spec({"group_field": core[1]}))
        elif kind == "assign":
            pb.core("engine.assign_stable_ids", "records.assign_ids",
                    pb.from_spec({"prefix": core[1]}))
        elif kind == "cross":
            pb.core("engine.cross_check_refs", "records.cross_check", {})
        elif kind == "verify":
            pb.core("engine.verify_fields", "records.verify",
                    pb.from_spec({"required_fields": core[1]}))
        elif kind == "sort":
            pb.core("engine.sort_chronology", "records.chronology",
                    pb.from_spec())
        elif kind == "metrics":
            pb.core("engine.aggregate_metrics", "records.metrics",
                    pb.from_spec())
        elif kind == "attest":
            pb.add("records.attest", "engine.hash_attest")
        elif kind == "unbound":
            pb.unbound(core[1], core[2])
        elif kind == "simulate":
            pb.simulate(core[1])
        elif kind == "media":
            pb.media(core[1], core[2] if len(core) > 2 else None)
        elif kind == "render":
            pb.render(core[1] if len(core) > 1 else None)
        else:
            raise ValueError(f"unknown core shorthand {kind!r}")


def _plan_shell(op, step, output_type):
    return {"plan_id": f"plan/{op['workflow_version']}/{op['operation_id']}",
            "workflow_version": op["workflow_version"],
            "plan_version": PLAN_VERSION,
            "operation_id": op["operation_id"],
            "operation_title": op["title"],
            "step_id": op["step_id"],
            "step_deliverable": step["deliverable"],
            "capability_slot": op["capability_slot"],
            "capability_version": "0.1.0",
            "capability_status": "PROPOSED",
            "output_artifact_type": output_type}


def build_specific_plan(op, step):
    pb = PlanBuilder()
    pb.manifest()
    if op["operation_id"] == "08.12":
        # Lean Phase 3 slice (SELECTED_OPERATION_SPEC): seq 2 is the
        # provider-aware generation implementation. It dispatches on
        # the attempt's PINNED binding inside plan execution:
        # deterministic-local/mock run the proven payload builder
        # byte-identical; openrouter-compatible performs genuine
        # generation. Plan version stays 1.0.0 (the coordinator's
        # claim-time CURRENT_PLAN_VERSION pin); the plan BODY changes,
        # so 08.12's plan_hash changes and is pinned per attempt.
        pb.add("op.build", "op.generate_script", timeout=120)
    else:
        pb.add("op.build", "op.build_payload", timeout=120)
    pb.emit(SPECIFIC_OUTPUTS[op["operation_id"]],
            _emit_schema(op["operation_id"]))
    plan = _plan_shell(op, step, SPECIFIC_OUTPUTS[op["operation_id"]])
    if op["operation_id"] == "08.12":
        plan["classification"] = {
            "class": "specific_builder",
            "note": "provider-aware generation (Lean Phase 3 slice), "
                    "decomposed as manifest -> op.generate_script -> "
                    "emit: deterministic bindings run the proven "
                    "payload builder (outputs unchanged); provider "
                    "bindings generate inside plan execution"}
    else:
        plan["classification"] = {
            "class": "specific_builder",
            "note": "proven operation-specific builder, decomposed as "
                    "manifest -> op.build_payload -> emit (outputs unchanged)"}
    plan["actions"] = pb.actions
    plan["binding_status"] = "FULLY_BOUND"
    return plan


def build_generic_plan(op, step, entry):
    cores, note = entry
    pb = PlanBuilder()
    pb.manifest()
    _run_cores(pb, cores)
    output_type = slugify(op["title"])
    pb.compose()
    pb.emit(output_type)
    plan = _plan_shell(op, step, output_type)
    unbound_kinds = [c[1] for c in cores if c[0] == "unbound"]
    simulated_kinds = [c[1] for c in cores if c[0] == "simulate"]
    media_bound = any(c[0] in ("media", "render") for c in cores)
    plan["classification"] = {
        "class": "mixed" if any(c[0] != "unbound" for c in cores) and unbound_kinds
                 else (unbound_kinds[0].split(".")[0] if unbound_kinds
                       and all(c[0] == "unbound" for c in cores)
                       else ("simulated_mock" if simulated_kinds
                             else ("media_tool" if media_bound
                                   else "deterministic_engine"))),
        "note": note}
    plan["actions"] = pb.actions
    plan["binding_status"] = ("PARTIALLY_BOUND" if unbound_kinds
                              else "FULLY_BOUND")
    return plan


def plan_hash(plan):
    body = {k: v for k, v in plan.items() if k != "plan_hash"}
    canonical = json.dumps(body, ensure_ascii=False, sort_keys=True,
                           separators=(",", ":"))
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


def main():
    seed = json.loads((SEED_DIR / "operations.json").read_text(encoding="utf-8"))
    steps = {s["step_id"]: s for s in seed["steps"]}
    ops = {o["operation_id"]: o for o in seed["operations"]}
    specific = set(worker_payloads.SPECIFIC_OPS)
    if set(CLASS) & specific:
        raise SystemExit(f"CLASS overlaps SPECIFIC_OPS: {sorted(set(CLASS) & specific)}")
    if set(CLASS) | specific != set(ops):
        missing = sorted(set(ops) - set(CLASS) - specific)
        extra = sorted((set(CLASS) | specific) - set(ops))
        raise SystemExit(f"classification coverage wrong: missing={missing} extra={extra}")
    plans = []
    for op_id in sorted(ops):
        op = ops[op_id]
        step = steps[op["step_id"]]
        if op_id in specific:
            plan = build_specific_plan(op, step)
        else:
            plan = build_generic_plan(op, step, CLASS[op_id])
        plan["plan_hash"] = plan_hash(plan)
        plans.append(plan)
    doc = {"workflow_version": seed["workflow_version"],
           "plan_version": PLAN_VERSION,
           "generator": "tools/generate_plans.py",
           "capability_activation_procedure":
               "Capability records stay PROPOSED (programme Gate 04 task 8): "
               "a capability is activated by an owner-approved change that "
               "sets its capability_versions status, recorded in the Gate 04 "
               "report; plans reference records as-is and never flip them.",
           "plans": plans}
    body = {k: v for k, v in doc.items() if k != "plans_hash"}
    canonical = json.dumps(body, ensure_ascii=False, sort_keys=True,
                           separators=(",", ":"))
    doc["plans_hash"] = hashlib.sha256(canonical.encode("utf-8")).hexdigest()
    out = SEED_DIR / "plans.json"
    out.write_text(json.dumps(doc, ensure_ascii=False, indent=1, sort_keys=True),
                   encoding="utf-8")
    fully = sum(1 for p in plans if p["binding_status"] == "FULLY_BOUND")
    unbound_actions = sum(1 for p in plans for a in p["actions"]
                          if a["binding_status"] == "UNBOUND")
    print(json.dumps({"plans": len(plans), "fully_bound": fully,
                      "partially_bound": len(plans) - fully,
                      "unbound_actions": unbound_actions,
                      "plans_hash": doc["plans_hash"]}, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
