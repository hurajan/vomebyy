#!/usr/bin/env python3
"""Generate the 16 step input/output JSON Schemas referenced by the seed.

Every operation output must carry: the operation + production identity, the
artifacts it produced (id + sha256), evidence records for what was checked,
and a status. Step outputs additionally name the step deliverable.
"""
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "tools"))
from generate_seed import STEP_META  # noqa: E402


def artifact_ref():
    return {
        "type": "object",
        "required": ["artifact_id", "artifact_type", "sha256"],
        "properties": {
            "artifact_id": {"type": "string"},
            "artifact_type": {"type": "string"},
            "sha256": {"type": "string", "pattern": "^[0-9a-f]{64}$"},
            "version": {"type": "integer", "minimum": 1},
        },
        "additionalProperties": True,
    }


def main() -> int:
    written = 0
    for step_id, meta in sorted(STEP_META.items()):
        name, _station, deliverable = meta[0], meta[1], meta[2]
        d = ROOT / "contracts" / f"step-{step_id}"
        d.mkdir(parents=True, exist_ok=True)
        input_schema = {
            "$schema": "https://json-schema.org/draft/2020-12/schema",
            "$id": f"factory/step-{step_id}/input/v1",
            "title": f"Step {step_id} ({name}) operation input",
            "type": "object",
            "required": ["production_id", "operation_id", "input_artifacts"],
            "properties": {
                "production_id": {"type": "string"},
                "operation_id": {"type": "string", "pattern": f"^{step_id}\\.\\d{{2}}$"},
                "execution_unit": {"type": "string"},
                "input_artifacts": {"type": "array", "items": artifact_ref()},
                "rights_snapshot_ref": {"type": "string"},
                "parameters": {"type": "object"},
            },
            "additionalProperties": False,
        }
        output_schema = {
            "$schema": "https://json-schema.org/draft/2020-12/schema",
            "$id": f"factory/step-{step_id}/output/v1",
            "title": f"Step {step_id} ({name}) operation output",
            "type": "object",
            "required": ["production_id", "operation_id", "status", "output_artifacts", "evidence"],
            "properties": {
                "production_id": {"type": "string"},
                "operation_id": {"type": "string", "pattern": f"^{step_id}\\.\\d{{2}}$"},
                "status": {"enum": ["CANDIDATE", "ACCEPTED", "REVIEW_REQUIRED", "BLOCKED"]},
                "step_deliverable": {"const": deliverable},
                "output_artifacts": {"type": "array", "items": artifact_ref()},
                "evidence": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "required": ["validator", "method", "result"],
                        "properties": {
                            "validator": {"type": "string"},
                            "method": {"type": "string"},
                            "result": {"enum": ["PASS", "FAIL", "REVIEW_REQUIRED"]},
                            "detail": {"type": "string"},
                        },
                        "additionalProperties": False,
                    },
                },
            },
            "additionalProperties": False,
        }
        (d / "input.schema.json").write_text(json.dumps(input_schema, indent=2) + "\n")
        (d / "output.schema.json").write_text(json.dumps(output_schema, indent=2) + "\n")
        written += 2
    print(f"contracts written: {written}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
