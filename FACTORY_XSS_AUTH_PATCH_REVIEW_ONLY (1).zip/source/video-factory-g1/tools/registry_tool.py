#!/usr/bin/env python3
"""G1 registry validator + loader (Python stdlib only; psql for DB work).

validate : pure-data checks per A-Z Guide §5.2 (a)-(f) + capability/genre checks.
load     : create a scratch DB, apply the migration, insert seed rows,
           then run in-DB verification queries. Prints a JSON report.
"""
import hashlib
import json
import re
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SEED_DIR = ROOT / "seed-definitions" / "workflow-1.0.0"
MIGRATION = ROOT / "database" / "migrations" / "001_g1_registry.sql"

PROVIDER_BLOCKLIST = [
    "openai", "anthropic", "claude", "gpt-", "gpt4", "elevenlabs", "seedance",
    "kling", "deepseek", "gemini", "midjourney", "runway", "pika", "heygen",
    "synthesia", "openrouter", "google cloud", "azure", "aws bedrock",
]

EXPECTED_STATION_COUNTS = {1: 24, 2: 24, 3: 48, 4: 36, 5: 36, 6: 24}
EXPECTED_GENRES = {"drama", "mystery", "thriller", "romance", "comedy",
                   "documentary", "educational", "confession"}
EXPECTED_CREATIVE = {"narration_engineering", "storyboard_animatic", "narrative_timing",
                     "visual_continuity", "sound_dramaturgy", "cross_modal_qa",
                     "audience_testing", "selective_repair"}


def load_json(p: Path):
    return json.loads(p.read_text(encoding="utf-8"))


def validate():
    errors, warnings = [], []
    seed = load_json(SEED_DIR / "operations.json")
    caps = load_json(SEED_DIR / "capabilities.json")
    genres = load_json(SEED_DIR / "genre_profiles.json")
    ops = seed["operations"]

    # (a) exactly 192
    if len(ops) != 192:
        errors.append(f"operation count {len(ops)} != 192")
    # (b) IDs exactly 01.01..16.12, 12 per step, unique
    expected_ids = {f"{s:02d}.{o:02d}" for s in range(1, 17) for o in range(1, 13)}
    got_ids = [o["operation_id"] for o in ops]
    if set(got_ids) != expected_ids:
        errors.append("operation ID set != 01.01..16.12")
    if len(set(got_ids)) != len(got_ids):
        errors.append("duplicate operation IDs")
    # station counts
    from collections import Counter
    sc = Counter(o["station"] for o in ops)
    if dict(sc) != EXPECTED_STATION_COUNTS:
        errors.append(f"station counts {dict(sc)} != {EXPECTED_STATION_COUNTS}")
    # step metadata consistency
    step_meta = {s["step_id"]: s for s in seed["steps"]}
    if len(step_meta) != 16:
        errors.append("steps != 16")
    for o in ops:
        sm = step_meta.get(o["step_id"])
        if not sm:
            errors.append(f"{o['operation_id']}: unknown step {o['step_id']}")
            continue
        if sm["station"] != o["station"]:
            errors.append(f"{o['operation_id']}: station mismatch with step")
        if sm["capability_slot"] != o["capability_slot"]:
            errors.append(f"{o['operation_id']}: capability slot mismatch with step")
        if sm["deliverable"] not in json.dumps(load_json(ROOT / o["output_schema"]), ensure_ascii=False) and False:
            pass  # deliverable const is checked under (d) below
    # (c) dependencies reference existing ops in earlier-or-same step
    deps = seed["dependency_templates"]
    if len(deps) != 191:
        errors.append(f"dependency count {len(deps)} != 191 (T-DEP-01 chain)")
    for d in deps:
        if d["from_operation"] not in expected_ids or d["to_operation"] not in expected_ids:
            errors.append(f"dependency references unknown op: {d}")
        elif d["from_operation"][:2] > d["to_operation"][:2]:
            errors.append(f"dependency goes to an earlier step: {d}")
        elif d["from_operation"] == d["to_operation"]:
            errors.append(f"self dependency: {d}")
    # chain completeness: every op except 01.01 has exactly one T-DEP-01 predecessor
    pred_count = Counter(d["to_operation"] for d in deps)
    for oid in expected_ids - {"01.01"}:
        if pred_count.get(oid, 0) != 1:
            errors.append(f"{oid}: T-DEP-01 predecessor count {pred_count.get(oid, 0)} != 1")
    # (d) schemas exist, parse, and output schema pins the step deliverable const
    for step_id, sm in step_meta.items():
        for kind in ("input", "output"):
            p = ROOT / "contracts" / f"step-{step_id}" / f"{kind}.schema.json"
            if not p.exists():
                errors.append(f"missing contract: {p.relative_to(ROOT)}")
                continue
            try:
                schema = load_json(p)
            except Exception as e:  # noqa: BLE001
                errors.append(f"unparsable contract {p.name}: {e}")
                continue
            if kind == "output":
                const = (schema.get("properties", {}).get("step_deliverable", {}) or {}).get("const")
                if const != sm["deliverable"]:
                    errors.append(f"step {step_id}: output schema deliverable const != step deliverable")
        for o in [x for x in ops if x["step_id"] == step_id]:
            if o["input_schema"] != f"contracts/step-{step_id}/input.schema.json":
                errors.append(f"{o['operation_id']}: input_schema path mismatch")
            if o["output_schema"] != f"contracts/step-{step_id}/output.schema.json":
                errors.append(f"{o['operation_id']}: output_schema path mismatch")
    # (e) no commercial provider name in seed or contracts
    haystacks = {
        "operations.json": (SEED_DIR / "operations.json").read_text(encoding="utf-8").lower(),
        "capabilities.json": (SEED_DIR / "capabilities.json").read_text(encoding="utf-8").lower(),
    }
    for p in (ROOT / "contracts").rglob("*.json"):
        haystacks[str(p.relative_to(ROOT))] = p.read_text(encoding="utf-8").lower()
    for name, text in haystacks.items():
        for bad in PROVIDER_BLOCKLIST:
            if bad in text:
                errors.append(f"provider name '{bad}' found in {name}")
    # (f) source hash + definition hash recompute
    src = Path.home() / "workspace/user/files/192_documented_atomic_operations.txt"
    src_hash = hashlib.sha256(src.read_bytes()).hexdigest()
    if seed["source"]["sha256"] != src_hash:
        errors.append("seed source sha256 != pinned source file")
    stripped = {k: v for k, v in seed.items() if k != "definition_hash"}
    canonical = json.dumps(stripped, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    if hashlib.sha256(canonical.encode("utf-8")).hexdigest() != seed["definition_hash"]:
        errors.append("definition_hash does not recompute")
    # capabilities
    creative = {c["capability_id"] for c in caps["creative_capabilities"]}
    if creative != EXPECTED_CREATIVE:
        errors.append(f"creative capabilities {sorted(creative)} != expected 8")
    slots = {c["capability_slot"] for c in caps["step_capability_slots"]}
    if slots != {o["capability_slot"] for o in ops} or len(slots) != 16:
        errors.append("step capability slots != the 16 slots used by operations")
    for group in ("creative_capabilities", "step_capability_slots"):
        for c in caps[group]:
            if c["status"] != "PROPOSED" or c["benchmark_evidence_ref"] is not None or c["execution_plan"] is not None:
                errors.append(f"capability {c.get('capability_id') or c.get('capability_slot')}: must be PROPOSED with no evidence/plan in G1")
    # genres
    gkeys = {g["genre_key"] for g in genres["profiles"]}
    if gkeys != EXPECTED_GENRES:
        errors.append(f"genre keys {sorted(gkeys)} != expected 8")
    if any(g["status"] != "PROPOSED" for g in genres["profiles"]):
        errors.append("a genre profile is not PROPOSED")

    report = {
        "operations": len(ops), "dependencies": len(deps), "steps": len(step_meta),
        "stations": dict(sorted(sc.items())),
        "contracts_checked": len(list((ROOT / 'contracts').rglob('*.json'))),
        "creative_capabilities": len(creative), "step_capability_slots": len(slots),
        "genre_profiles": len(gkeys),
        "definition_hash": seed["definition_hash"], "source_sha256": src_hash,
        "errors": errors, "warnings": warnings,
        "verdict": "PASS" if not errors else "FAIL",
    }
    return report


def sql_str(v):
    if v is None:
        return "NULL"
    return "'" + str(v).replace("'", "''") + "'"


def sql_json(v):
    return sql_str(json.dumps(v, ensure_ascii=False)) + "::jsonb"


def build_load_sql(seed_dir=None):
    sd = Path(seed_dir) if seed_dir else SEED_DIR
    seed = load_json(sd / "operations.json")
    caps = load_json(sd / "capabilities.json")
    genres = load_json(sd / "genre_profiles.json")
    lines = ["BEGIN;"]
    lines.append(
        "INSERT INTO workflow_versions VALUES (%s,'PROPOSED',%s,%s) "
        "ON CONFLICT (workflow_version) DO NOTHING;"
        % (sql_str(seed["workflow_version"]), sql_str(seed["definition_hash"]), sql_str(seed["source"]["sha256"])))
    for s in seed["stations"]:
        lines.append("INSERT INTO stations VALUES (%d,%s,%d) ON CONFLICT (station) DO NOTHING;"
                     % (s["station"], sql_str(s["name"]), s["operations"]))
    for s in seed["steps"]:
        lines.append("INSERT INTO steps VALUES (%s,%d,%s,%s,%s,%s) ON CONFLICT (step_id) DO NOTHING;"
                     % (sql_str(s["step_id"]), s["station"], sql_str(s["name"]),
                        sql_str(s["deliverable"]), sql_str(s["pass_condition"]), sql_str(s["capability_slot"])))
    for o in seed["operations"]:
        lines.append(
            "INSERT INTO operation_definitions VALUES (%s,%s,%s,%d,%s,%s,%s,%s,%s,%s,%s,%s,%s) "
            "ON CONFLICT (workflow_version, operation_id) DO NOTHING;"
            % (sql_str(o["workflow_version"]), sql_str(o["operation_id"]), sql_str(o["step_id"]),
               o["station"], sql_str(o["title"]), sql_str(o["responsibility"]),
               sql_str(o["input_schema"]), sql_str(o["output_schema"]), sql_str(o["capability_slot"]),
               sql_json(o["validator_policy"]), sql_str(o["approval_policy"]),
               sql_json(o["resource_ceiling"]), sql_str(o["unit_key"])))
    for d in seed["dependency_templates"]:
        # FP-01 (F-G9-01): templates belong to the seed's OWN workflow version,
        # not a hardcoded literal — a variant seed (e.g. 1.1.0) previously had
        # all 191 templates silently written under '1.0.0'.
        lines.append("INSERT INTO dependency_templates VALUES (%s,%s,%s,%s) "
                     "ON CONFLICT DO NOTHING;"
                     % (sql_str(seed["workflow_version"]), sql_str(d["from_operation"]),
                        sql_str(d["to_operation"]), sql_str(d["kind"])))
    for c in caps["step_capability_slots"]:
        lines.append("INSERT INTO capability_versions(capability_id,version,kind,status,serves_steps,model_policy_class) "
                     "VALUES (%s,'0.1.0','STEP_SLOT','PROPOSED',%s,%s) ON CONFLICT DO NOTHING;"
                     % (sql_str(c["capability_slot"]), sql_json(c["serves_steps"]), sql_str(c["model_policy_class"])))
    for c in caps["creative_capabilities"]:
        lines.append("INSERT INTO capability_versions(capability_id,version,kind,status,serves_steps,contract_summary) "
                     "VALUES (%s,'0.1.0','CREATIVE','PROPOSED',%s,%s) ON CONFLICT DO NOTHING;"
                     % (sql_str(c["capability_id"]), sql_json(c["serves_steps"]), sql_str(c["contract_summary"])))
    for c in caps["narrative_intelligence_components"]:
        lines.append("INSERT INTO capability_versions(capability_id,version,kind,status,contract_summary) "
                     "VALUES (%s,'0.1.0','NI_COMPONENT','PROPOSED',%s) ON CONFLICT DO NOTHING;"
                     % (sql_str(c["component_id"]), sql_str(c["note"])))
    for g in genres["profiles"]:
        lines.append("INSERT INTO genre_profile_refs VALUES (%s,'PROPOSED',%s) ON CONFLICT DO NOTHING;"
                     % (sql_str(g["genre_key"]), sql_str(genres["source_mechanism"])))
    lines.append("COMMIT;")
    return "\n".join(lines) + "\n"


def psql(db, sql_file=None, sql=None, db_admin="postgres"):
    cmd = ["sudo", "-u", "postgres", "psql", "-v", "ON_ERROR_STOP=1", "-At", "-d", db]
    staged = None
    if sql_file:
        # The postgres OS user cannot traverse /home/hatch; stage a copy in /tmp.
        import shutil
        staged = Path("/tmp") / f"g1-stage-{Path(sql_file).name}"
        shutil.copy(sql_file, staged)
        staged.chmod(0o644)
        cmd += ["-f", str(staged)]
    r = subprocess.run(cmd, input=sql, capture_output=True, text=True)
    if staged is not None:
        staged.unlink(missing_ok=True)
    if r.returncode != 0:
        raise RuntimeError(f"psql failed on {db}: {r.stderr.strip()[:500]}")
    return r.stdout.strip()


def load(db_name, seed_dir=None):
    report = validate()
    if report["verdict"] != "PASS":
        return {"validate": report, "load": "SKIPPED_VALIDATION_FAILED"}
    exists = psql("postgres", sql=f"SELECT 1 FROM pg_database WHERE datname='{db_name}'")
    if not exists:
        psql("postgres", sql=f"CREATE DATABASE {db_name}")
    psql(db_name, sql_file=MIGRATION)
    tmp = ROOT / "hidden_tmp_load.sql"
    tmp.write_text(build_load_sql(seed_dir), encoding="utf-8")
    try:
        psql(db_name, sql_file=tmp)
    finally:
        tmp.unlink(missing_ok=True)
    checks = {}
    checks["operations"] = int(psql(db_name, sql="SELECT count(*) FROM operation_definitions"))
    checks["dependencies"] = int(psql(db_name, sql="SELECT count(*) FROM dependency_templates"))
    checks["steps"] = int(psql(db_name, sql="SELECT count(*) FROM steps"))
    checks["stations"] = int(psql(db_name, sql="SELECT count(*) FROM stations"))
    checks["capabilities"] = int(psql(db_name, sql="SELECT count(*) FROM capability_versions"))
    checks["genres"] = int(psql(db_name, sql="SELECT count(*) FROM genre_profile_refs"))
    checks["orphan_deps"] = int(psql(db_name, sql=(
        "SELECT count(*) FROM dependency_templates d LEFT JOIN operation_definitions o "
        "ON o.workflow_version=d.workflow_version AND o.operation_id=d.from_operation WHERE o.operation_id IS NULL")))
    checks["definition_hash_db"] = psql(db_name, sql="SELECT definition_hash FROM workflow_versions WHERE workflow_version='1.0.0'")
    ok = (checks["operations"] == 192 and checks["dependencies"] == 191 and checks["steps"] == 16
          and checks["stations"] == 6 and checks["capabilities"] == 29 and checks["genres"] == 8
          and checks["orphan_deps"] == 0 and checks["definition_hash_db"] == report["definition_hash"])
    return {"validate": report, "db": db_name, "checks": checks, "verdict": "PASS" if ok else "FAIL"}


PLANS_VERSION = "1.0.0"
WORKER_SERVICE = (Path.home() / "workspace/video-factory-real-ai-programme"
                  / "gate-c" / "worker_service")
MIGRATION_015 = (Path.home() / "workspace/video-factory-g2" / "database"
                 / "migrations" / "015_gate04_execution_plans.sql")


def _canonical_hash(obj, omit_keys=()):
    body = {k: v for k, v in obj.items() if k not in omit_keys}
    canonical = json.dumps(body, ensure_ascii=False, sort_keys=True,
                           separators=(",", ":"))
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


def validate_plans():
    """Gate 04 pure-data validation of plans.json against the seed and
    the worker service's action-implementation manifest. Returns
    (problems, unbound, plans_doc)."""
    problems = []
    seed = load_json(SEED_DIR / "operations.json")
    plans_doc = load_json(SEED_DIR / "plans.json")
    if "plans" not in plans_doc or "plans_hash" not in plans_doc:
        return ["plans.json is missing plans/plans_hash"], [], plans_doc
    if plans_doc.get("workflow_version") != seed["workflow_version"]:
        problems.append("plans.json workflow_version != seed workflow_version")
    if _canonical_hash(plans_doc, ("plans_hash",)) != plans_doc["plans_hash"]:
        problems.append("plans_hash mismatch (plans.json edited without "
                        "regeneration via tools/generate_plans.py)")
    impls = load_json(WORKER_SERVICE / "action_implementations.json")["implementations"]
    ops = {o["operation_id"]: o for o in seed["operations"]}
    plans = plans_doc["plans"]
    if len(plans) != 192:
        problems.append(f"expected 192 plans, found {len(plans)}")
    seen, unbound = set(), []
    for p in plans:
        oid = p.get("operation_id")
        label = f"plan {oid}"
        if oid in seen:
            problems.append(f"{label}: duplicate plan")
        seen.add(oid)
        op = ops.get(oid)
        if op is None:
            problems.append(f"{label}: no such operation in the seed")
            continue
        if p.get("capability_slot") != op["capability_slot"]:
            problems.append(f"{label}: capability_slot "
                            f"{p.get('capability_slot')} != registry "
                            f"{op['capability_slot']}")
        if _canonical_hash(p, ("plan_hash",)) != p.get("plan_hash"):
            problems.append(f"{label}: plan_hash mismatch")
        actions = p.get("actions") or []
        if not actions:
            problems.append(f"{label}: plan has no actions")
        if [a["seq"] for a in actions] != list(range(1, len(actions) + 1)):
            problems.append(f"{label}: action seq is not 1..n in order")
        keys = [a["action_key"] for a in actions]
        for i, a in enumerate(actions):
            alabel = f"{label} action {a['action_key']}"
            if a["binding_status"] == "BOUND":
                impl = a.get("implementation")
                if impl not in impls:
                    problems.append(f"{alabel}: implementation {impl!r} is "
                                    f"not in the worker action manifest")
                    continue
                if a.get("input_spec") != impls[impl]["input_spec"]:
                    problems.append(f"{alabel}: input_spec differs from the "
                                    f"manifest for {impl}")
                if a.get("output_spec") != impls[impl]["output_spec"]:
                    problems.append(f"{alabel}: output_spec differs from the "
                                    f"manifest for {impl}")
            elif a["binding_status"] == "UNBOUND":
                if a.get("implementation") is not None:
                    problems.append(f"{alabel}: UNBOUND action carries an "
                                    f"implementation")
                if not a.get("unbound_reason") or not a.get("declared_implementation"):
                    problems.append(f"{alabel}: UNBOUND action lacks "
                                    f"declared_implementation/unbound_reason")
                unbound.append({"operation_id": oid,
                                "action_key": a["action_key"],
                                "declared_implementation":
                                    a.get("declared_implementation")})
            else:
                problems.append(f"{alabel}: unknown binding_status "
                                f"{a['binding_status']!r}")
            from_action = (a.get("spec") or {}).get("from_action")
            if from_action is not None and from_action not in keys[:i]:
                problems.append(f"{alabel}: spec.from_action {from_action!r} "
                                f"does not point at an earlier action")
    missing = sorted(set(ops) - seen)
    if missing:
        problems.append(f"operations without a plan: {missing}")
    plan_slots = {p["capability_slot"] for p in plans}
    if plan_slots != {o["capability_slot"] for o in ops.values()}:
        problems.append("plan capability slots do not cover the registry "
                        "capability slots")
    return problems, unbound, plans_doc


def plans_validate():
    problems, unbound, plans_doc = validate_plans()
    fully = sum(1 for p in plans_doc.get("plans", [])
                if p["binding_status"] == "FULLY_BOUND")
    return {"plans": len(plans_doc.get("plans", [])),
            "fully_bound": fully,
            "plans_containing_unbound": len(plans_doc.get("plans", [])) - fully,
            "unbound_action_count": len(unbound),
            "unbound_actions": unbound,
            "plans_hash": plans_doc.get("plans_hash"),
            "problems": problems,
            "verdict": "PASS" if not problems else "FAIL"}


def build_load_plans_sql(plans_doc, seed):
    plans_by_op = {p["operation_id"]: p for p in plans_doc["plans"]}
    lines = ["BEGIN;"]
    for p in plans_doc["plans"]:
        lines.append(
            "INSERT INTO operation_execution_plans (plan_id, workflow_version, "
            "plan_version, operation_id, capability_slot, capability_version, "
            "binding_status, plan, plan_hash, action_count, unbound_action_count) "
            f"VALUES ({sql_str(p['plan_id'])}, {sql_str(p['workflow_version'])}, "
            f"{sql_str(p['plan_version'])}, {sql_str(p['operation_id'])}, "
            f"{sql_str(p['capability_slot'])}, {sql_str(p['capability_version'])}, "
            f"{sql_str(p['binding_status'])}, {sql_json(p)}, "
            f"{sql_str(p['plan_hash'])}, {len(p['actions'])}, "
            f"{sum(1 for a in p['actions'] if a['binding_status'] == 'UNBOUND')}) "
            "ON CONFLICT (operation_id, plan_version) DO NOTHING;")
    slot_ops = {}
    for op in seed["operations"]:
        slot_ops.setdefault(op["capability_slot"], []).append(op)
    steps = {s["step_id"]: s for s in seed["steps"]}
    for slot, ops_in_slot in sorted(slot_ops.items()):
        step = steps[ops_in_slot[0]["step_id"]]
        # The rollup materializes the capability's execution plan in
        # the table's own shape: the concatenated action lists of the
        # step's twelve operation plans, each annotated with its
        # operation and plan hash. Status stays PROPOSED, mirroring
        # the capability record (activation is an owner procedure).
        rollup_actions = []
        for o in ops_in_slot:
            p = plans_by_op[o["operation_id"]]
            for a in p["actions"]:
                rollup_actions.append({**a, "operation_id": o["operation_id"],
                                       "plan_id": p["plan_id"],
                                       "plan_hash": p["plan_hash"]})
        lines.append(
            "INSERT INTO execution_plan_versions (plan_id, capability_id, "
            "capability_version, status, actions) VALUES "
            f"({sql_str('capability-plan/' + slot)}, {sql_str(slot)}, "
            f"{sql_str('0.1.0')}, 'PROPOSED', {sql_json(rollup_actions)}) "
            "ON CONFLICT (plan_id) DO NOTHING;")
    lines.append("COMMIT;")
    return "\n".join(lines)


def load_plans(db_name):
    """Load plans.json into operation_execution_plans + the
    execution_plan_versions rollups. Applies migration 015 if needed.
    Content-addressed: re-runs are no-ops; a changed plan body under an
    existing plan_version fails the post-load hash comparison."""
    report = validate()
    if report["verdict"] != "PASS":
        return {"validate": report, "load_plans": "SKIPPED_VALIDATION_FAILED"}
    problems, _unbound, plans_doc = validate_plans()
    if problems:
        return {"plans_problems": problems, "verdict": "FAIL"}
    seed = load_json(SEED_DIR / "operations.json")
    table = psql(db_name, sql="SELECT to_regclass('public.operation_execution_plans')")
    if table in ("", "None"):
        psql(db_name, sql_file=MIGRATION_015)
    tmp = ROOT / "hidden_tmp_load_plans.sql"
    tmp.write_text(build_load_plans_sql(plans_doc, seed), encoding="utf-8")
    try:
        psql(db_name, sql_file=tmp)
    finally:
        tmp.unlink(missing_ok=True)
    checks = {}
    checks["plans"] = int(psql(db_name, sql="SELECT count(*) FROM operation_execution_plans"))
    checks["plans_fully_bound"] = int(psql(db_name, sql=(
        "SELECT count(*) FROM operation_execution_plans WHERE binding_status='FULLY_BOUND'")))
    checks["plans_with_unbound"] = int(psql(db_name, sql=(
        "SELECT count(*) FROM operation_execution_plans WHERE unbound_action_count > 0")))
    checks["unbound_actions"] = int(psql(db_name, sql=(
        "SELECT COALESCE(sum(unbound_action_count),0) FROM operation_execution_plans")))
    checks["rollups"] = int(psql(db_name, sql=(
        "SELECT count(*) FROM execution_plan_versions")))
    # every stored plan hash equals the source file's hash for that op
    stored = {}
    for line in psql(db_name, sql=(
            "SELECT operation_id || '|' || plan_hash FROM operation_execution_plans")).splitlines():
        oid, h = line.split("|", 1)
        stored[oid] = h
    hash_mismatch = [oid for oid, p in
                     ((p["operation_id"], p) for p in plans_doc["plans"])
                     if stored.get(oid) != p["plan_hash"]]
    checks["hash_mismatches"] = len(hash_mismatch)
    ok = (checks["plans"] == 192 and checks["rollups"] == 16
          and checks["hash_mismatches"] == 0)
    return {"db": db_name, "checks": checks,
            "verdict": "PASS" if ok else "FAIL"}


if __name__ == "__main__":
    mode = sys.argv[1] if len(sys.argv) > 1 else "validate"
    if mode == "validate":
        out = validate()
    elif mode == "load":
        out = load(sys.argv[2] if len(sys.argv) > 2 else "g1_registry_scratch",
                   sys.argv[3] if len(sys.argv) > 3 else None)
    elif mode == "plans-validate":
        out = plans_validate()
    elif mode == "load-plans":
        out = load_plans(sys.argv[2] if len(sys.argv) > 2 else "g1_registry_scratch")
    else:
        print("usage: registry_tool.py [validate|load [dbname] [seed_dir]|"
              "plans-validate|load-plans [dbname]]")
        sys.exit(2)
    print(json.dumps(out, ensure_ascii=False, indent=2))
    sys.exit(0 if out.get("verdict") == "PASS" or (isinstance(out.get("validate"), dict) and out["validate"]["verdict"] == "PASS" and out.get("verdict", "PASS") == "PASS") else 1)
