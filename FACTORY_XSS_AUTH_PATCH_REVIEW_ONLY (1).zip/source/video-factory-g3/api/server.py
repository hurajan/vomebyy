#!/usr/bin/env python3
"""G3 coordinator API — thin HTTP layer over the verified G2 coordinator library.

Stdlib HTTP server; one coordinator connection per request (the connection is
closed when the request ends, so no read transaction can dangle across
requests — the G2 D1 lesson applied at the API boundary).

Env:
  FACTORY_DSN        psycopg DSN (default: local scratch DB g3_dashboard_scratch)
  FACTORY_API_TOKEN  operator token (default: dev-operator-token — LOCAL DEV ONLY)
  FACTORY_PORT       listen port (default 8730), binds 127.0.0.1
  FACTORY_ENVIRONMENT  config environment this API resolves (default: test)
  FACTORY_EVAL_URL   Gate E evaluation service base URL for the MM-09
                       read-only /evaluation-status pass-through
                       (default http://127.0.0.1:8950)
  FACTORY_WORKER_TOKEN / FACTORY_SCHEDULER_TOKEN / FACTORY_VALIDATOR_TOKEN /
  FACTORY_CALLBACK_TOKEN   per-role tokens for X-Role + X-Role-Token auth
                       (Gate C, design B4.1). Unset = that role cannot
                       authenticate. The legacy X-Operator-Token remains the
                       OPERATOR credential for dev compatibility.
"""
import base64
import hashlib
import hmac
import json
import os
import sys
import urllib.error
import urllib.request
import uuid
from decimal import Decimal
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse, parse_qs

G2 = Path.home() / "workspace/video-factory-g2"
sys.path.insert(0, str(G2))

from coordinator.coordinator import (  # noqa: E402
    ActionRecordRefused, AdoptRefused, ArtifactHashMismatchError, CancelRefused,
    Coordinator, CoordinatorError, EstimateBelowConfigError, GateNotSatisfied,
    executor_worker_id_for_operation)
from coordinator.model_registry import (  # noqa: E402
    ModelRegistry, PolicyConflict, PolicyNotFound, PolicyNotPromotable)

# Gate 05 (G01-D07): per-event authorization for POST /units/{id}/events.
# Human/operator-class events are OPERATOR only; worker-class events are
# WORKER only and additionally bind the body's worker_id to the attempt's
# claim identity. Any event NOT listed here (validation_*,
# submit_candidate, claim, provider_*, reconciled_*, retry_ready, unknown
# names) is refused for every role: those transitions move only through
# their own authority paths (/validate, /complete, provider callbacks,
# the reconciler, /retry). SCHEDULER/VALIDATOR/CALLBACK fire no events.
# 'block' sits in both classes: as an operator action it is OPERATOR;
# its only composed-flow producer is executor failure signalling — the
# G4 Station-2 rights check reports {event: 'block', error_class:
# 'RIGHTS_BLOCKED'} through the error-handler channel — so WORKER may
# fire it under the identity binding (the attempt's claim identity, or
# pre-claim — the rights report fires from READY — the executor
# entitlement for the unit's operation).
EVENT_MATRIX = {
    "human_approved": ("OPERATOR",),
    "human_rejected": ("OPERATOR",),
    "cancel": ("OPERATOR",),
    "block": ("OPERATOR", "WORKER"),
    "repair_ready": ("OPERATOR",),
    "start": ("WORKER",),
    "transient_error": ("WORKER",),
}
WORKER_IDENTITY_EVENTS = frozenset({"start", "transient_error", "block"})

DSN = os.environ.get(
    "FACTORY_DSN",
    "host=127.0.0.1 dbname=g3_dashboard_scratch user=factory password=factory_dev_local")
TOKEN = os.environ.get("FACTORY_API_TOKEN", "dev-operator-token")
PORT = int(os.environ.get("FACTORY_PORT", "8730"))
DASHBOARD = Path(__file__).resolve().parent.parent / "dashboard" / "index.html"
OPERATOR = "operator"  # local single-operator identity (see LOCK_G3.md)
ENVIRONMENT = os.environ.get("FACTORY_ENVIRONMENT", "test")
# MM-09: the dashboard's golden-set card reads the evaluation service's
# OWN health surface through this pass-through (display only).
EVAL_URL = os.environ.get("FACTORY_EVAL_URL", "http://127.0.0.1:8950")
ROLE_TOKENS = {role: os.environ.get(f"FACTORY_{role}_TOKEN")
               for role in ("WORKER", "SCHEDULER", "VALIDATOR", "CALLBACK")}
READ_ROLES = ("OPERATOR", "WORKER", "SCHEDULER", "VALIDATOR")

# Deployment hardening: never permit local-development credentials in non-test runs.
# This adds a startup guard while preserving the exact original development behavior.
def enforce_deployment_auth():
    if ENVIRONMENT.lower() in ("test", "dev", "development", "local"):
        return
    if not os.environ.get("FACTORY_DSN"):
        raise RuntimeError("FACTORY_DSN must be explicitly configured for deployment")
    if not TOKEN or TOKEN == "dev-operator-token" or len(TOKEN) < 32:
        raise RuntimeError("A non-default FACTORY_API_TOKEN (>=32 characters) is required")
    for role, value in ROLE_TOKENS.items():
        if not value or len(value) < 32 or value == TOKEN:
            raise RuntimeError(f"A distinct {role} token (>=32 characters) is required")



def jdefault(o):
    if isinstance(o, Decimal):
        return int(o)
    return str(o)


class ApiError(Exception):
    def __init__(self, status, message):
        self.status, self.message = status, message


def rows(cur):
    # Coordinator connections use psycopg dict_row — rows are already dicts.
    return [dict(r) for r in cur.fetchall()]


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    # ------------------------------------------------------------- plumbing
    def log_message(self, *a):  # quiet
        pass

    def _send(self, status, obj=None, raw=None, ctype="application/json"):
        body = raw if raw is not None else json.dumps(obj, default=jdefault).encode()
        self.send_response(status)
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Cache-Control", "no-store")
        if ctype.startswith("text/html"):
            dashboard_bytes = raw if raw is not None else b""
            # Hash permits ONLY the vetted, bundled inline application script.
            script = dashboard_bytes.split(b"<script>",1)[1].split(b"</script>",1)[0]
            digest = base64.b64encode(hashlib.sha256(script).digest()).decode("ascii")
            self.send_header("Content-Security-Policy", "default-src 'none'; script-src 'sha256-" + digest + "'; style-src 'unsafe-inline'; connect-src 'self'; img-src 'self' data:; base-uri 'none'; object-src 'none'; form-action 'self'; frame-ancestors 'none'")
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _body(self):
        length_value = self.headers.get("Content-Length", "0")
        if not length_value.isdecimal():
            raise ApiError(400, "invalid content length")
        n = int(length_value)
        if n > 1024 * 1024:
            raise ApiError(413, "request body too large")
        if n and self.headers.get("Content-Type", "").split(";")[0].strip().lower() != "application/json":
            raise ApiError(415, "JSON content type required")
        if not n:
            return {}
        try:
            data = json.loads(self.rfile.read(n) or b"{}")
            if not isinstance(data, dict):
                raise ApiError(400, "JSON object body required")
            return data
        except json.JSONDecodeError:
            raise ApiError(400, "invalid JSON body")

    def _need(self, body, *fields):
        missing = [f for f in fields if body.get(f) is None]
        if missing:
            raise ApiError(400, f"missing fields: {', '.join(missing)}")

    def _coord(self):
        actor = f"{self._role.lower()}:{self._identity}" if getattr(self, "_role", None) \
            else "g3-api"
        return Coordinator(DSN, actor=actor, environment=ENVIRONMENT)

    def _authenticate(self):
        """(role, identity) for this request, or None. OPERATOR via the
        legacy X-Operator-Token; WORKER/SCHEDULER/VALIDATOR/CALLBACK via
        X-Role + X-Role-Token against the per-role env token. Identity comes
        from X-Identity, defaulting to the role's canonical name."""
        if hmac.compare_digest(self.headers.get("X-Operator-Token") or "", TOKEN):
            return "OPERATOR", OPERATOR if ENVIRONMENT.lower() not in ("test", "dev", "development", "local") else self.headers.get("X-Identity", OPERATOR)
        role = (self.headers.get("X-Role") or "").upper()
        tok = self.headers.get("X-Role-Token")
        if role in ROLE_TOKENS and ROLE_TOKENS[role] and hmac.compare_digest(tok or "", ROLE_TOKENS[role]):
            return role, role.lower() if ENVIRONMENT.lower() not in ("test", "dev", "development", "local") else self.headers.get("X-Identity", role.lower())
        return None

    def _allow(self, *roles):
        if self._role not in roles:
            raise ApiError(403, f"role {self._role} may not call this endpoint")

    def _route(self, method, seg, query, body):
        c = self._coord()
        try:
            return self._dispatch(c, method, seg, query, body)
        finally:
            c.close()

    # -------------------------------------------------------------- routing
    def _dispatch(self, c, method, seg, q, b):
        cur = c.conn.cursor()
        # ---- health (unauthenticated)
        if seg == ["health"] and method == "GET":
            cur.execute("SELECT workflow_version FROM workflow_versions ORDER BY workflow_version LIMIT 1")
            wv = cur.fetchone()
            cur.execute("SELECT COUNT(*) AS n FROM operation_definitions")
            return 200, {"status": "ok", "registry_operations": cur.fetchone()["n"],
                         "workflow_version": wv["workflow_version"] if wv else None}

        # ---- Gate C: provider configs
        if seg == ["configs"] and method == "GET":
            self._allow("OPERATOR", "SCHEDULER")
            cur.execute("SELECT * FROM provider_configs WHERE active ORDER BY scope, version")
            return 200, {"configs": rows(cur)}
        if seg == ["configs"] and method == "POST":
            self._allow("OPERATOR")
            self._need(b, "scope", "provider")
            if b["scope"] not in ("FACTORY", "STATION", "OPERATION", "CAPABILITY", "ACTION"):
                raise ApiError(400, "unknown config scope")
            return self._create_config(c, b)

        # ---- Gate D: artifact staging, pricing rules, evidence settlement
        if seg == ["artifacts", "stage"] and method == "POST":
            self._allow("WORKER", "OPERATOR")
            self._need(b, "production_id", "content_base64")
            cand = c.stage_content(base64.b64decode(b["content_base64"]),
                                   b.get("content_type"),
                                   actor=f"{self._role.lower()}:{self._identity}",
                                   production_id=b["production_id"])
            return 201, cand
        if seg == ["pricing-rules"] and method == "GET":
            self._allow("OPERATOR", "SCHEDULER")
            cur.execute("SELECT * FROM pricing_rules WHERE active"
                        " ORDER BY provider, model, unit_kind, pricing_version")
            rules = rows(cur)
            for r in rules:  # NUMERIC price: serialize exactly, never via int()
                r["unit_price_cents"] = str(r["unit_price_cents"])
            return 200, {"pricing_rules": rules}
        if seg == ["pricing-rules"] and method == "POST":
            self._allow("OPERATOR")
            self._need(b, "provider", "unit_kind", "unit_price_cents", "pricing_version")
            if b["unit_kind"] not in ("input_token", "output_token", "cached_token",
                                      "image", "media_second", "request"):
                raise ApiError(400, "unknown unit_kind")
            cur.execute(
                "INSERT INTO pricing_rules(provider, model, modality, unit_kind,"
                " unit_price_cents, pricing_version, created_by)"
                " VALUES (%s,%s,%s,%s,%s,%s,%s) RETURNING rule_id",
                (b["provider"], b.get("model"), b.get("modality"), b["unit_kind"],
                 Decimal(str(b["unit_price_cents"])), b["pricing_version"],
                 f"{self._role.lower()}:{self._identity}"))
            rule_id = cur.fetchone()["rule_id"]
            c.conn.commit()
            return 201, {"rule_id": rule_id, "pricing_version": b["pricing_version"]}
        if len(seg) == 3 and seg[0] == "financial-evidence" and seg[2] == "settle" \
                and method == "POST":
            self._allow("OPERATOR")
            cur.execute("SELECT 1 FROM financial_evidence WHERE evidence_id=%s", (seg[1],))
            if not cur.fetchone():
                raise ApiError(404, "financial evidence not found")
            out = c.settle_provider_charge(
                seg[1], actor=f"{self._role.lower()}:{self._identity}")
            return 200, out
        if len(seg) == 3 and seg[0] == "financial-evidence" and seg[2] == "resolve" \
                and method == "POST":
            # MM-08: operator reconciliation of an UNRESOLVED
            # (missing-usage) charge. OPERATOR only — any other role
            # gets 403 from _allow before anything moves. Refusals are
            # ChargeSettlementError (CoordinatorError -> 409).
            self._allow("OPERATOR")
            cur.execute("SELECT 1 FROM financial_evidence WHERE evidence_id=%s", (seg[1],))
            if not cur.fetchone():
                raise ApiError(404, "financial evidence not found")
            reported = b.get("reported_cost_cents")
            out = c.resolve_unresolved_charge(
                seg[1], usage=b.get("usage"),
                reported_cost_cents=int(reported) if reported is not None else None,
                provider_request_id=b.get("provider_request_id"),
                actor=f"{self._role.lower()}:{self._identity}")
            return 200, out
        if len(seg) == 3 and seg[0] == "productions" and seg[2] == "financial-evidence" \
                and method == "GET":
            self._allow("OPERATOR", "SCHEDULER")
            cur.execute("SELECT * FROM financial_evidence WHERE production_id=%s"
                        " ORDER BY created_at", (seg[1],))
            return 200, {"financial_evidence": rows(cur)}

        # ---- Gate C: provider jobs
        if seg == ["provider-jobs"] and method == "POST":
            self._allow("WORKER", "OPERATOR")
            self._need(b, "unit_id", "attempt_id", "fencing_token", "idempotency_key")
            job_id = c.submit_provider_job_v2(b["unit_id"], b["attempt_id"],
                                              int(b["fencing_token"]), b["idempotency_key"])
            return 201, {"job_id": job_id, "status": "SUBMITTED"}
        if len(seg) == 3 and seg[0] == "provider-jobs" and seg[2] == "callback" and method == "POST":
            self._allow("CALLBACK", "OPERATOR")
            job = c.get_provider_job(seg[1])
            if not job:
                raise ApiError(404, "provider job not found")
            payload = job["request_payload"] or {}
            data = b""
            if b.get("content_b64"):
                data = base64.b64decode(b["content_b64"])
            elif b.get("content"):
                data = b["content"].encode()
            reported = b.get("reported_cost_cents")
            out = c.handle_callback(
                job["idempotency_key"],
                b.get("artifact_type") or payload.get("artifact_type") or "provider_output",
                data, b.get("storage_uri") or f"provider-job://{seg[1]}",
                int(reported) if reported is not None else int(b.get("actual_cost_cents", 0)),
                usage=b.get("usage"), provider_request_id=b.get("provider_request_id"),
                reported_cost_cents=int(reported) if reported is not None else None,
                status=b.get("status", "COMPLETED"),
                correlation_id=b.get("correlation_id"), model=b.get("model"))
            after = c.get_provider_job(seg[1])
            return 200, {"job_id": seg[1], "job_status": after["status"],
                         "duplicate": out["duplicate"], "result": out["result"]}
        if len(seg) == 3 and seg[0] == "provider-jobs" and seg[2] == "cancel" and method == "POST":
            # MM-04: provider-job cancellation. OPERATOR cancels by role
            # authority (parity with /complete's OPERATOR role); a WORKER
            # caller must present the attempt's claim identity in the
            # body (worker_id, plus fencing_token when it has one) and
            # the coordinator binds it — a mismatch is a committed
            # refusal audit + 403 (CancelRefused).
            self._allow("OPERATOR", "WORKER")
            job = c.get_provider_job(seg[1])
            if not job:
                raise ApiError(404, "provider job not found")
            worker_id = None
            fencing = None
            if self._role == "WORKER":
                self._need(b, "worker_id")
                worker_id = b["worker_id"]
                fencing = b.get("fencing_token")
            reported = b.get("reported_cost_cents")
            try:
                out = c.cancel_provider_job(
                    seg[1], worker_id=worker_id,
                    fencing_token=int(fencing) if fencing is not None else None,
                    reported_cost_cents=int(reported) if reported is not None else None,
                    provider_request_id=b.get("provider_request_id"),
                    usage=b.get("usage"),
                    correlation_id=b.get("correlation_id"),
                    actor=f"{self._role.lower()}:{self._identity}")
            except CancelRefused as exc:
                raise ApiError(403, str(exc))
            after = c.get_provider_job(seg[1])
            return 200, {"job_id": seg[1], "job_status": after["status"],
                         "unit_state": out.get("unit_state"),
                         "already_cancelled": bool(out.get("already_cancelled"))}

        # ---- MM-03: central model + capability registry (governance
        # layer above provider_configs). Reads are READ_ROLES; promotion
        # and rollback are OPERATOR only — any other role gets a 403 AND
        # a committed policy_action_refused audit row (the Gate 05
        # refusal-evidence discipline). Promotion is the only path by
        # which a policy writes provider_configs rows.
        if seg == ["model-policies"] and method == "GET":
            self._allow(*READ_ROLES)
            return 200, {"policies": self._registry(c).list_policies()}
        if len(seg) == 2 and seg[0] == "model-policies" and method == "GET":
            self._allow(*READ_ROLES)
            pol = self._registry(c).get_policy(seg[1])
            if not pol:
                raise ApiError(404, "model policy not found")
            return 200, pol
        if len(seg) == 3 and seg[0] == "model-policies" and seg[2] == "events" \
                and method == "GET":
            self._allow(*READ_ROLES)
            reg = self._registry(c)
            if not reg.get_policy(seg[1]):
                raise ApiError(404, "model policy not found")
            return 200, {"events": reg.policy_events(seg[1])}
        if len(seg) == 3 and seg[0] == "model-policies" and seg[2] == "promote" \
                and method == "POST":
            reg = self._registry(c)
            if self._role != "OPERATOR":
                reg.audit_refusal(seg[1], "promote", self._role)
                raise ApiError(403, "model policy promotion is OPERATOR only")
            try:
                out = reg.promote(seg[1], approval_note=b.get("approval_note"))
            except PolicyNotFound as exc:
                raise ApiError(404, str(exc))
            except (PolicyNotPromotable, PolicyConflict) as exc:
                raise ApiError(409, str(exc))
            return 200, out
        if len(seg) == 3 and seg[0] == "model-policies" and seg[2] == "rollback" \
                and method == "POST":
            reg = self._registry(c)
            if self._role != "OPERATOR":
                reg.audit_refusal(seg[1], "rollback", self._role)
                raise ApiError(403, "model policy rollback is OPERATOR only")
            try:
                out = reg.rollback(seg[1], note=b.get("note"))
            except PolicyNotFound as exc:
                raise ApiError(404, str(exc))
            except (PolicyNotPromotable, PolicyConflict) as exc:
                raise ApiError(409, str(exc))
            return 200, out
        if seg == ["model-assignments"] and method == "GET":
            self._allow(*READ_ROLES)
            return 200, {"assignments": self._registry(c).list_assignments(
                operation_id=q.get("operation_id", [None])[0],
                status=q.get("status", [None])[0])}
        if seg == ["models"] and method == "GET":
            self._allow(*READ_ROLES)
            models = self._registry(c).list_models(
                provider=q.get("provider", [None])[0])
            for m in models:  # NUMERIC prices: serialize exactly (Gate D pattern)
                for k in ("pricing_in", "pricing_out"):
                    if m.get(k) is not None:
                        m[k] = str(m[k])
            return 200, {"models": models}
        if seg == ["provider-health"] and method == "GET":
            self._allow(*READ_ROLES)
            return 200, {"provider_health": self._registry(c).provider_health()}

        # ---- MM-09: dashboard read surfaces. READ-ONLY: none of these
        # mutates coordinator state, and no credential_ref or token value
        # is ever selected. Every dashboard ACTION goes through the
        # pre-existing mutation endpoints (promote/rollback, resolve,
        # gate decide, retry) with their existing role enforcement.
        if seg == ["benchmarks"] and method == "GET":
            self._allow(*READ_ROLES)
            cur.execute("SELECT result_id, model_id, task, score, status, source,"
                        " created_at FROM benchmark_results ORDER BY created_at DESC")
            bench = rows(cur)
            for r in bench:  # NUMERIC score: serialize exactly (Gate D pattern)
                if r.get("score") is not None:
                    r["score"] = str(r["score"])
            return 200, {"benchmarks": bench}
        if seg == ["provider-spend"] and method == "GET":
            self._allow(*READ_ROLES)
            cur.execute("SELECT provider, window_kind, cap_cents"
                        " FROM provider_spend_limits WHERE environment=%s"
                        " AND active ORDER BY provider", (ENVIRONMENT,))
            spend = []
            for lim in rows(cur):
                # the enforcement accounting itself (MM-08), so the
                # displayed position IS the position the cap checks.
                pos = c._provider_window_position(cur, lim["provider"])
                spend.append({**lim, **pos})
            return 200, {"provider_spend": spend}
        if len(seg) == 3 and seg[0] == "productions" and seg[2] == "evaluations" \
                and method == "GET":
            self._allow(*READ_ROLES)
            cur.execute("SELECT 1 FROM productions WHERE production_id=%s", (seg[1],))
            if not cur.fetchone():
                raise ApiError(404, "production not found")
            try:
                limit = min(max(int(q.get("limit", ["100"])[0]), 1), 500)
            except ValueError:
                raise ApiError(400, "limit must be an integer")
            cur.execute(
                "SELECT qe.evaluation_id, qe.artifact_id, a.artifact_type,"
                " a.produced_by_unit AS unit_id, u.operation_id,"
                " qe.validator_id, qe.method, qe.verdict,"
                " qe.evaluator_identity, qe.evidence, qe.created_at"
                " FROM quality_evaluations qe"
                " JOIN artifacts a ON a.artifact_id=qe.artifact_id"
                " LEFT JOIN execution_units u ON u.unit_id=a.produced_by_unit"
                " WHERE a.production_id=%s"
                " ORDER BY qe.created_at DESC, qe.evaluation_id LIMIT %s",
                (seg[1], limit))
            return 200, {"evaluations": rows(cur)}
        if seg == ["evaluation-status"] and method == "GET":
            self._allow(*READ_ROLES)
            try:
                req = urllib.request.Request(EVAL_URL + "/health")
                with urllib.request.urlopen(req, timeout=3) as resp:
                    payload = json.loads(resp.read() or b"{}")
                return 200, {"reachable": True, **payload}
            except Exception as exc:  # honest down-state, not an error page
                return 200, {"reachable": False,
                             "error": f"{type(exc).__name__}: {exc}"}

        # ---- productions
        if seg == ["productions"] and method == "POST":
            self._allow("OPERATOR", "SCHEDULER")
            self._need(b, "title", "hard_ceiling_cents")
            pid = c.create_production(b["title"], int(b["hard_ceiling_cents"]),
                                      int(b.get("soft_ceiling_cents", b["hard_ceiling_cents"])),
                                      b.get("created_by", OPERATOR))
            return 201, {"production_id": pid, "status": "ACTIVE"}
        if seg == ["productions"] and method == "GET":
            self._allow(*READ_ROLES)
            cur.execute("SELECT production_id, title, status, workflow_version, hard_ceiling_cents,"
                        " soft_ceiling_cents, created_by, created_at FROM productions ORDER BY created_at")
            return 200, {"productions": rows(cur)}
        if len(seg) == 2 and seg[0] == "productions" and method == "GET":
            self._allow(*READ_ROLES)
            pid = seg[1]
            cur.execute("SELECT * FROM productions WHERE production_id=%s", (pid,))
            prod = cur.fetchone()
            if not prod:
                raise ApiError(404, "production not found")
            cur.execute(
                "SELECT s.step_id, s.name, s.station, COUNT(u.unit_id) AS units,"
                " COUNT(u.unit_id) FILTER (WHERE u.state='ACCEPTED') AS accepted"
                " FROM steps s LEFT JOIN operation_definitions od ON od.step_id=s.step_id"
                "   AND od.workflow_version=%s"
                " LEFT JOIN execution_units u ON u.operation_id=od.operation_id AND u.production_id=%s"
                " GROUP BY s.step_id, s.name, s.station ORDER BY s.step_id",
                (prod["workflow_version"], pid))
            steps = rows(cur)
            cur.execute(
                "SELECT od.step_id, u.state, COUNT(*) AS n FROM execution_units u"
                " JOIN operation_definitions od ON od.operation_id=u.operation_id"
                "  AND od.workflow_version=u.workflow_version_ref"
                " WHERE u.production_id=%s GROUP BY od.step_id, u.state", (pid,))
            by_state = {}
            for r in cur.fetchall():
                by_state.setdefault(r["step_id"], {})[r["state"]] = r["n"]
            for s in steps:
                s["by_state"] = by_state.get(s["step_id"], {})
            return 200, {"production_id": pid, "title": prod["title"], "status": prod["status"],
                         "steps": steps, "budget": self._budget(c, pid)}
        if len(seg) == 3 and seg[0] == "productions" and seg[2] == "runs" and method == "POST":
            self._allow("OPERATOR", "SCHEDULER")
            kind = b.get("kind", "FULL")
            rid = c.start_run(seg[1], kind, self._identity)
            return 201, {"run_id": rid, "kind": kind}
        if len(seg) == 5 and seg[0] == "productions" and seg[2] == "runs" \
                and seg[4] == "materialize" and method == "POST":
            # Gate 04 (G01-D03): registry-driven run materialization —
            # the unit graph derives from dependency_templates via
            # Coordinator.materialize_run (nearest planned predecessor).
            self._allow("OPERATOR", "SCHEDULER")
            cur.execute("SELECT 1 FROM productions WHERE production_id=%s", (seg[1],))
            if not cur.fetchone():
                raise ApiError(404, "production not found")
            cur.execute("SELECT 1 FROM production_runs WHERE run_id=%s AND production_id=%s",
                        (seg[3], seg[1]))
            if not cur.fetchone():
                raise ApiError(404, "run not found for this production")
            out = c.materialize_run(seg[1], seg[3],
                                    operation_ids=b.get("operation_ids"),
                                    unit_key=b.get("unit_key", "main"),
                                    lane=b.get("lane", "text"))
            return 201, out
        if len(seg) == 3 and seg[0] == "productions" and seg[2] == "units" and method == "POST":
            self._allow("OPERATOR", "SCHEDULER")
            self._need(b, "operation_id", "run_id")
            uid = c.plan_unit(seg[1], b["run_id"], b["operation_id"],
                              unit_key=b.get("unit_key", "main"), lane=b.get("lane", "text"),
                              depends_on=tuple(b.get("depends_on", ())),
                              input_artifact_ids=tuple(b.get("input_artifact_ids", ())))
            unit = c.get_unit(uid)
            return 201, {"unit_id": uid, "state": unit["state"]}
        if len(seg) == 3 and seg[0] == "productions" and seg[2] == "units" and method == "GET":
            self._allow(*READ_ROLES)
            cur.execute("SELECT unit_id, run_id, operation_id, unit_key, lane, state, current_attempt,"
                        " fencing_token, supersedes_unit_id, block_reason, created_at"
                        " FROM execution_units WHERE production_id=%s ORDER BY created_at", (seg[1],))
            units = rows(cur)
            # Gate G (Part D): planned input refs on the unit read — the
            # n8n executor assembles the worker request's
            # input_artifact_refs from these (additive fields).
            for u in units:
                cur.execute(
                    "SELECT a.artifact_id, a.artifact_type, a.sha256, a.storage_uri"
                    " FROM unit_inputs ui JOIN artifacts a ON a.artifact_id=ui.artifact_id"
                    " WHERE ui.unit_id=%s ORDER BY a.artifact_type", (u["unit_id"],))
                refs = rows(cur)
                u["input_artifact_ids"] = [r["artifact_id"] for r in refs]
                u["input_artifacts"] = refs
            return 200, {"units": units}
        if len(seg) == 3 and seg[0] == "productions" and seg[2] == "operations" and method == "GET":
            self._allow(*READ_ROLES)
            pid = seg[1]
            cur.execute("SELECT workflow_version FROM productions WHERE production_id=%s", (pid,))
            prod = cur.fetchone()
            if not prod:
                raise ApiError(404, "production not found")
            cur.execute(
                "SELECT od.operation_id, od.step_id, od.station, od.title, u.unit_id, u.state"
                " FROM operation_definitions od"
                " LEFT JOIN LATERAL (SELECT unit_id, state FROM execution_units"
                "   WHERE production_id=%s AND operation_id=od.operation_id"
                "   ORDER BY created_at DESC LIMIT 1) u ON true"
                " WHERE od.workflow_version=%s ORDER BY od.operation_id",
                (pid, prod["workflow_version"]))
            return 200, {"operations": rows(cur)}
        if len(seg) == 3 and seg[0] == "productions" and seg[2] == "budget" and method == "GET":
            self._allow(*READ_ROLES)
            return 200, self._budget(c, seg[1])
        if len(seg) == 3 and seg[0] == "productions" and seg[2] == "artifacts" and method == "POST":
            self._allow("OPERATOR", "WORKER")
            self._need(b, "artifact_type", "content", "storage_uri")
            art = c.register_artifact(seg[1], b["artifact_type"], b["content"].encode(),
                                      b["storage_uri"],
                                      depends_on_artifact_ids=tuple(b.get("depends_on_artifact_ids", ())))
            return 201, art
        if len(seg) == 3 and seg[0] == "productions" and seg[2] == "artifacts" and method == "GET":
            self._allow(*READ_ROLES)
            cur.execute("SELECT artifact_id, artifact_type, version, state, sha256, storage_uri,"
                        " produced_by_unit, created_at FROM artifacts WHERE production_id=%s"
                        " ORDER BY artifact_type, version", (seg[1],))
            return 200, {"artifacts": rows(cur)}
        if len(seg) == 3 and seg[0] == "productions" and seg[2] == "gates" and method == "POST":
            self._allow("OPERATOR")
            self._need(b, "gate_kind", "artifact_id")
            gate = c.create_gate(seg[1], b["gate_kind"], b["artifact_id"])
            return 201, {"gate_id": gate["gate_id"], "status": "PENDING",
                         "existing": gate["existing"]}
        if len(seg) == 3 and seg[0] == "productions" and seg[2] == "gates" and method == "GET":
            self._allow(*READ_ROLES)
            cur.execute("SELECT gate_id, gate_kind, artifact_id, artifact_sha256, verdict, decided_by,"
                        " decided_at, created_at FROM human_gates WHERE production_id=%s"
                        " ORDER BY created_at", (seg[1],))
            return 200, {"gates": rows(cur)}

        # ---- units
        if len(seg) == 3 and seg[0] == "units" and seg[2] == "attempts" and method == "GET":
            self._allow(*READ_ROLES)
            cur.execute("SELECT current_attempt FROM execution_units WHERE unit_id=%s", (seg[1],))
            unit_row = cur.fetchone()
            if not unit_row:
                raise ApiError(404, "unit not found")
            cur.execute(
                "SELECT attempt_id, attempt_no, worker_id, status, actual_cost_cents,"
                " output_artifact_id, reservation_id, config_id, resolved_config,"
                " resolved_config_hash, started_at, finished_at FROM action_attempts"
                " WHERE unit_id=%s ORDER BY attempt_no", (seg[1],))
            attempts = rows(cur)
            # Gate G (Part D): lease fields per attempt. worker_leases
            # holds the unit's CURRENT lease only, so the fields are
            # populated on the current attempt's row, null elsewhere.
            # Master Execution Programme Gate 02 guardrail: the fencing
            # token is NOT exposed on this read — the adoption endpoint
            # (POST /units/{id}/adopt) is the only disclosure, gated on
            # the caller's identity matching the attempt's worker.
            cur.execute("SELECT worker_id, expires_at FROM worker_leases"
                        " WHERE unit_id=%s", (seg[1],))
            lease = cur.fetchone()
            for a in attempts:
                current = lease and a["attempt_no"] == unit_row["current_attempt"]
                a["lease_expires_at"] = lease["expires_at"] if current else None
                a["lease_worker_id"] = lease["worker_id"] if current else None
            return 200, {"attempts": attempts}
        if len(seg) == 3 and seg[0] == "units" and seg[2] == "evaluations" and method == "GET":
            self._allow(*READ_ROLES)
            cur.execute("SELECT 1 FROM execution_units WHERE unit_id=%s", (seg[1],))
            if not cur.fetchone():
                raise ApiError(404, "unit not found")
            cur.execute(
                "SELECT qe.evaluation_id, qe.artifact_id, qe.validator_id, qe.method,"
                " qe.verdict, qe.evaluator_identity, qe.evidence, qe.created_at"
                " FROM quality_evaluations qe JOIN artifacts a"
                "   ON a.artifact_id=qe.artifact_id"
                " WHERE a.produced_by_unit=%s ORDER BY qe.created_at", (seg[1],))
            return 200, {"evaluations": rows(cur)}
        if len(seg) == 3 and seg[0] == "units" and seg[2] == "provider-jobs" and method == "GET":
            self._allow(*READ_ROLES)
            cur.execute("SELECT 1 FROM execution_units WHERE unit_id=%s", (seg[1],))
            if not cur.fetchone():
                raise ApiError(404, "unit not found")
            cur.execute(
                "SELECT * FROM provider_jobs WHERE unit_id=%s"
                " ORDER BY submitted_at", (seg[1],))
            return 200, {"provider_jobs": rows(cur)}
        if len(seg) == 3 and seg[0] == "units" and seg[2] == "claim" and method == "POST":
            self._allow("OPERATOR", "WORKER", "SCHEDULER")
            self._need(b, "worker_id")
            est = b.get("estimated_cents")
            # Gate D (D-C1): the API path enforces the resolved binding's
            # estimate; the body value is a ceiling assertion only.
            out = c.claim(seg[1], b["worker_id"],
                          int(est) if est is not None else None,
                          lease_ttl_s=int(b.get("lease_ttl_s", 600)),
                          estimate_mode="api")
            cur.execute("SELECT expires_at FROM worker_leases WHERE unit_id=%s", (seg[1],))
            lease = cur.fetchone()
            out["lease_expires_at"] = lease["expires_at"] if lease else None
            return 200, out
        if len(seg) == 3 and seg[0] == "units" and seg[2] == "adopt" and method == "POST":
            # Master Execution Programme Gate 02 (tasks 4-6): the
            # Coordinator-controlled adoption endpoint. The response
            # carries the attempt's execution credentials (fencing token
            # + resolved-config snapshot) and is issued ONLY when the
            # body's worker_id matches the attempt's worker (enforced in
            # Coordinator.adopt_attempt). Roles mirror /claim (OPERATOR
            # parity; n8n executors authenticate as WORKER). Atomic,
            # single-winner, idempotent per idempotency_key.
            self._allow("OPERATOR", "WORKER")
            self._need(b, "worker_id", "attempt_id", "idempotency_key")
            if not c.get_unit(seg[1]):
                raise ApiError(404, "unit not found")
            try:
                out = c.adopt_attempt(seg[1], b["worker_id"], b["attempt_id"],
                                      b["idempotency_key"],
                                      b.get("fencing_token"))
            except AdoptRefused as exc:
                raise ApiError(409, str(exc))
            return 200, out
        if len(seg) == 3 and seg[0] == "units" and seg[2] == "actions" and method == "POST":
            # Gate 04: the worker service records each plan action's
            # execution against the attempt's pinned plan (validated +
            # fencing-checked in Coordinator.record_action_attempt).
            # OPERATOR parity mirrors /complete. Idempotent per
            # (attempt_id, action_key).
            # Gate 05: the call must PRESENT the attempt's worker
            # identity (body worker_id) and the coordinator binds it to
            # the claim's identity (GB-SEC-01 shape); a mismatch is a
            # committed 'action_record_refused' audit row + 403 here.
            self._allow("WORKER", "OPERATOR")
            self._need(b, "attempt_id", "fencing_token", "action_key", "seq",
                       "status", "worker_id")
            if not c.get_unit(seg[1]):
                raise ApiError(404, "unit not found")
            try:
                out = c.record_action_attempt(
                    seg[1], b["attempt_id"], int(b["fencing_token"]),
                    b["action_key"], int(b["seq"]), b["status"],
                    inputs_hash=b.get("inputs_hash"),
                    output_summary=b.get("output_summary"),
                    cost_cents=int(b.get("cost_cents", 0)),
                    error=b.get("error"),
                    recorded_by=f"{self._role.lower()}:{self._identity}",
                    worker_id=b["worker_id"])
            except ActionRecordRefused as exc:
                raise ApiError(403, str(exc))
            return (201 if out["recorded"] else 200), out
        if len(seg) == 3 and seg[0] == "units" and seg[2] == "events" and method == "POST":
            # Gate 05 (G01-D07): per-event authorization matrix
            # (EVENT_MATRIX above). Before this gate the route accepted
            # OPERATOR/SCHEDULER/WORKER for ANY transition — a WORKER
            # token fired human_approved on its own unit and drove it
            # to ACCEPTED (Phase 3 verifier, live repro). Now every
            # refusal is 403 + a committed event_refused audit row; an
            # authorized role firing an event that is invalid for the
            # unit's state keeps the existing 409 transition semantics.
            self._need(b, "event")
            ev = b["event"]
            unit = c.get_unit(seg[1])
            if not unit:
                raise ApiError(404, "unit not found")
            if self._role not in EVENT_MATRIX.get(ev, ()):
                reason = ("event_not_fireable_via_api" if ev not in EVENT_MATRIX
                          else "role_not_authorized")
                c.audit_event_refusal(seg[1], ev, reason, {"role": self._role})
                raise ApiError(403, f"role {self._role} may not fire event "
                                    f"{ev!r} ({reason})")
            if ev in WORKER_IDENTITY_EVENTS and self._role == "WORKER":
                wid = b.get("worker_id")
                if not wid:
                    c.audit_event_refusal(seg[1], ev, "worker_identity_required",
                                          {"role": self._role})
                    raise ApiError(403, f"event {ev!r} requires the attempt's "
                                        f"worker_id in the body")
                cur.execute("SELECT worker_id FROM action_attempts"
                            " WHERE unit_id=%s AND attempt_no=%s",
                            (seg[1], unit["current_attempt"]))
                att = cur.fetchone()
                cur.execute("SELECT worker_id FROM worker_leases WHERE unit_id=%s",
                            (seg[1],))
                lease = cur.fetchone()
                if att:
                    # an attempt exists: the claim's identity governs
                    expected = att["worker_id"]
                    basis = "attempt_claim_identity"
                    ok = wid == expected and (not lease
                                              or lease["worker_id"] == wid)
                else:
                    # no attempt (pre-claim signalling — the executor
                    # rights-block report fires from READY): the identity
                    # entitled to this unit's operation governs, the same
                    # entitlement the adoption path enforces.
                    expected = executor_worker_id_for_operation(
                        unit["operation_id"])
                    basis = "executor_entitlement"
                    ok = wid == expected
                if not ok:
                    c.audit_event_refusal(
                        seg[1], ev, "identity_mismatch",
                        {"role": self._role, "presented_worker_id": wid,
                         "expected_worker_id": expected, "basis": basis})
                    raise ApiError(403, f"worker identity {wid!r} does not match "
                                        f"the entitled identity ({basis})")
            state = c.event(seg[1], ev)
            return 200, {"unit_id": seg[1], "state": state}
        if len(seg) == 3 and seg[0] == "units" and seg[2] == "retry" and method == "POST":
            self._allow("OPERATOR", "SCHEDULER")
            # F-G9-03 fix (LOCK_FIX_F-G9-03): RETRY_WAIT -> READY, closing
            # the failed attempt and releasing its reservation.
            state = c.retry_unit(seg[1])
            return 200, {"unit_id": seg[1], "state": state}
        if len(seg) == 3 and seg[0] == "units" and seg[2] == "complete" and method == "POST":
            self._allow("OPERATOR", "WORKER")
            self._need(b, "worker_id", "fencing_token", "artifact_type",
                       "actual_cost_cents")
            # Gate D: content arrives inline ("content" text, or
            # "content_base64" for binary) or pre-staged via
            # POST /artifacts/stage ("candidate_uri"). storage_uri is now
            # optional: without it the artifact records the promoted
            # store://objects/<sha256> URI.
            # Gate 05: the API path enforces the completion barrier
            # (enforce_barrier=True at the coordinator call below) — the
            # attempt's pinned plan must be fully evidenced by SUCCEEDED
            # action records, else a committed
            # completion_barrier_refused audit row + 409.
            if b.get("content_base64") is not None:
                data = base64.b64decode(b["content_base64"])
            elif b.get("content") is not None:
                data = b["content"].encode()
            elif b.get("candidate_uri"):
                data = None
            else:
                raise ApiError(400, "content, content_base64 or candidate_uri required")
            reported = b.get("reported_cost_cents")
            art = c.complete_attempt(seg[1], b["worker_id"], int(b["fencing_token"]),
                                     b["artifact_type"], data, b.get("storage_uri"),
                                     int(b["actual_cost_cents"]),
                                     depends_on_artifact_ids=tuple(b.get("depends_on_artifact_ids", ())),
                                     usage=b.get("usage"),
                                     provider_request_id=b.get("provider_request_id"),
                                     candidate_uri=b.get("candidate_uri"),
                                     expected_sha256=b.get("expected_sha256"),
                                     reported_cost_cents=int(reported) if reported is not None else None,
                                     enforce_barrier=True,
                                     model=b.get("model"))
            unit = c.get_unit(seg[1])
            return 200, {"unit_id": seg[1], "state": unit["state"], **art}
        if len(seg) == 3 and seg[0] == "units" and seg[2] == "validate" and method == "POST":
            self._allow("OPERATOR", "VALIDATOR")
            if isinstance(b.get("evaluations"), list):
                # Gate E: an evaluation service submits its layer verdicts
                # in one call; the coordinator's mapping decides the state.
                ev = []
                for item in b["evaluations"]:
                    if not isinstance(item, dict) or "verdict" not in item \
                            or "validator" not in item:
                        raise ApiError(400, "each evaluation needs validator + verdict")
                    if item["verdict"] not in ("PASS", "FAIL", "REVIEW_REQUIRED"):
                        raise ApiError(400, f"unknown verdict {item['verdict']!r}")
                    evidence = dict(item.get("evidence") or {})
                    evidence["deterministic"] = bool(
                        item.get("deterministic", evidence.get("deterministic", False)))
                    ev.append({"validator": item["validator"],
                               "method": item.get("method", "evaluation_service"),
                               "verdict": item["verdict"],
                               "evaluator": item.get("evaluator", self._identity),
                               "evidence": evidence})
                state = c.validate(seg[1], ev)
                return 200, {"unit_id": seg[1], "state": state}
            self._need(b, "verdict")
            ev = [{"validator": b.get("validator", "dashboard"), "method": b.get("method", "operator_review"),
                   "verdict": b["verdict"], "evaluator": b.get("evaluator", OPERATOR),
                   "evidence": {"deterministic": bool(b.get("deterministic", False))}}]
            state = c.validate(seg[1], ev)
            return 200, {"unit_id": seg[1], "state": state}

        # ---- artifacts
        if len(seg) == 3 and seg[0] == "artifacts" and seg[2] == "impact" and method == "GET":
            self._allow("OPERATOR")
            aid = seg[1]
            cur.execute("SELECT 1 FROM artifacts WHERE artifact_id=%s", (aid,))
            if not cur.fetchone():
                raise ApiError(404, "artifact not found")
            cur.execute(
                "WITH RECURSIVE affected AS ("
                "  SELECT consumer_artifact_id AS aid, 1 AS depth FROM artifact_dependencies"
                "   WHERE consumed_artifact_id=%s"
                "  UNION SELECT d.consumer_artifact_id, a.depth+1 FROM artifact_dependencies d"
                "   JOIN affected a ON d.consumed_artifact_id=a.aid WHERE a.depth<50)"
                " SELECT DISTINCT aid FROM affected", (aid,))
            affected = [str(r["aid"]) for r in cur.fetchall()]
            all_ids = [aid] + affected
            cur.execute("SELECT DISTINCT produced_by_unit AS uid FROM artifacts"
                        " WHERE artifact_id = ANY(%s) AND produced_by_unit IS NOT NULL", (all_ids,))
            units = [str(r["uid"]) for r in cur.fetchall()]
            return 200, {"artifact_id": aid, "affected_artifact_ids": sorted(all_ids),
                         "affected_unit_ids": sorted(units)}
        if len(seg) == 3 and seg[0] == "artifacts" and seg[2] == "invalidate" and method == "POST":
            self._allow("OPERATOR")
            self._need(b, "reason")
            # GB-SEC-02: no master_authority body field anymore — master
            # authority is the coordinator's data rule (APPROVED HG4 on the
            # artifact, or a co_authorizer distinct from the actor).
            out = c.invalidate_artifact(seg[1], b["reason"], self._identity,
                                        co_authorizer=b.get("co_authorizer"))
            run_id = None
            if out["new_unit_ids"]:
                cur.execute("SELECT run_id FROM execution_units WHERE unit_id=%s", (out["new_unit_ids"][0],))
                run_id = cur.fetchone()["run_id"]
            return 200, {**out, "replacement_run_id": run_id}

        # ---- gates
        if len(seg) == 3 and seg[0] == "gates" and seg[2] == "decide" and method == "POST":
            self._allow("OPERATOR")
            self._need(b, "decision")
            cur.execute("SELECT verdict FROM human_gates WHERE gate_id=%s", (seg[1],))
            if not cur.fetchone():
                raise ApiError(404, "gate not found")
            c.decide_gate(seg[1], b["decision"], b.get("decided_by", self._identity))
            cur.execute("SELECT verdict FROM human_gates WHERE gate_id=%s", (seg[1],))
            row = cur.fetchone()
            if not row:
                raise ApiError(404, "gate not found")
            return 200, {"gate_id": seg[1], "status": row["verdict"]}
        if seg == ["gates", "require"] and method == "GET":
            self._allow(*READ_ROLES)
            for k in ("production_id", "gate_kind", "artifact_id"):
                if not q.get(k):
                    raise ApiError(400, f"missing query param: {k}")
            try:
                c.require_gate(q["production_id"][0], q["gate_kind"][0], q["artifact_id"][0])
                return 200, {"satisfied": True}
            except GateNotSatisfied:
                return 200, {"satisfied": False}

        raise ApiError(404, "no such route")

    def _registry(self, c):
        return ModelRegistry(
            c.conn, environment=ENVIRONMENT,
            actor=f"{self._role.lower()}:{self._identity}")

    def _create_config(self, c, b):
        """POST /configs (Gate C): insert a new binding version. The active
        row of the same scope key is superseded in the same transaction;
        history is never edited (design B2.1)."""
        scope = b["scope"]
        env_name = b.get("environment", ENVIRONMENT)
        station = b.get("station")
        station = int(station) if station is not None else None
        with c.conn.transaction():
            cur = c.conn.cursor()
            cur.execute(
                "SELECT config_id, version FROM provider_configs WHERE active AND scope=%s"
                " AND environment=%s AND COALESCE(station,-1)=%s"
                " AND COALESCE(operation_id,'')=%s AND COALESCE(capability_slot,'')=%s"
                " AND COALESCE(action_key,'')=%s",
                (scope, env_name, station if station is not None else -1,
                 b.get("operation_id") or "", b.get("capability_slot") or "",
                 b.get("action_key") or ""))
            old = cur.fetchone()
            version = 1
            if old:
                version = old["version"] + 1
                cur.execute(
                    "UPDATE provider_configs SET active=false, superseded_at=now()"
                    " WHERE config_id=%s", (old["config_id"],))
            config_id = str(uuid.uuid4())
            cur.execute(
                "INSERT INTO provider_configs(config_id, scope, station, operation_id,"
                " capability_slot, action_key, environment, provider, model, modality,"
                " params, est_cost_cents, max_cost_cents, timeout_s, retry_policy,"
                " concurrency_limit, credential_ref, human_approval_required, version,"
                " created_by) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)",
                (config_id, scope, station, b.get("operation_id"), b.get("capability_slot"),
                 b.get("action_key"), env_name, b["provider"], b.get("model"),
                 b.get("modality"), json.dumps(b.get("params", {})),
                 b.get("est_cost_cents"), b.get("max_cost_cents"), b.get("timeout_s"),
                 json.dumps(b.get("retry_policy", {})), b.get("concurrency_limit"),
                 b.get("credential_ref"), bool(b.get("human_approval_required", False)),
                 version, f"{self._role.lower()}:{self._identity}"))
            cur.execute(
                "INSERT INTO audit_events(production_id, unit_id, event_type, actor, payload)"
                " VALUES (NULL, NULL, 'provider_config_changed', %s, %s)",
                (f"{self._role.lower()}:{self._identity}",
                 json.dumps({"config_id": config_id, "scope": scope, "version": version,
                             "provider": b["provider"], "environment": env_name})))
        return 201, {"config_id": config_id, "version": version, "scope": scope}

    def _budget(self, c, pid):
        cur = c.conn.cursor()
        cur.execute("SELECT soft_ceiling_cents FROM productions WHERE production_id=%s", (pid,))
        prod = cur.fetchone()
        if not prod:
            raise ApiError(404, "production not found")
        pos = c.budget_position(pid)
        soft = prod["soft_ceiling_cents"]
        return {"production_id": pid, "spent_cents": pos["settled_cents"],
                "reserved_cents": pos["held_cents"], "projected_cents": pos["projected_cents"],
                "available_cents": pos["hard_ceiling_cents"] - pos["projected_cents"],
                "hard_ceiling_cents": pos["hard_ceiling_cents"],
                "soft_ceiling_cents": soft,
                "soft_ceiling_crossed": bool(soft is not None
                                             and pos["settled_cents"] >= soft)}

    # -------------------------------------------------------------- verbs
    def do_GET(self):
        self._handle("GET")

    def do_POST(self):
        self._handle("POST")

    def _handle(self, method):
        parsed = urlparse(self.path)
        seg = [s for s in parsed.path.split("/") if s]
        try:
            if method == "GET" and parsed.path in ("/", "/dashboard"):
                return self._send(200, raw=DASHBOARD.read_bytes(), ctype="text/html; charset=utf-8")
            self._role, self._identity = None, None
            if seg != ["health"]:
                auth = self._authenticate()
                if auth is None:
                    return self._send(401, {"error": "missing or wrong credentials"})
                self._role, self._identity = auth
            body = self._body() if method == "POST" else {}
            status, obj = self._route(method, seg, parse_qs(parsed.query), body)
            self._send(status, obj)
        except ApiError as e:
            self._send(e.status, {"error": e.message})
        except PermissionError as e:
            # GB-SEC-02: coordinator-level authority refusal (master rule).
            self._send(403, {"error": str(e)})
        except (EstimateBelowConfigError, ArtifactHashMismatchError) as e:
            # Gate D typed refusals (D-C1 estimate enforcement; staged-hash
            # mismatch): committed audit evidence, nothing else moved.
            self._send(409, {"error": str(e)})
        except GateNotSatisfied as e:
            self._send(409, {"error": str(e)})
        except CoordinatorError as e:
            # Contract: 404 for unknown ids, 409 for state/budget/fencing
            # rejections. The coordinator reports unknown ids in its messages.
            msg = str(e)
            if msg.startswith("gate not pending"):
                status = 409  # gate exists but was already decided (existence pre-checked)
            elif msg.startswith("unknown unit") or "artifact not found" in msg:
                status = 404
            else:
                status = 409
            self._send(status, {"error": msg})
        except Exception as e:  # never leak a stack to the client; still be honest
            self._send(500, {"error": "internal_server_error"})


def main():
    enforce_deployment_auth()
    server = ThreadingHTTPServer(("127.0.0.1", PORT), Handler)
    print(f"G3 API on http://127.0.0.1:{PORT} (dashboard at /, health at /health)")
    server.serve_forever()


if __name__ == "__main__":
    main()
