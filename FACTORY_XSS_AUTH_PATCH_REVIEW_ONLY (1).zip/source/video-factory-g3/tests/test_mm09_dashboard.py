"""MM-09 dashboard tests: Models / Finance / Quality / Approvals views.

Fixture: a fresh scratch DB + real API server + a real Gate E evaluation
service (its own /health is the golden-set surface). The MM-03 registry
seeder runs for real (7 policies, 192 assignments, benchmark_results
empty by design). One production is seeded with a settled charge, an
UNRESOLVED (missing-usage) charge, a provider spend cap, evaluations of
every verdict, an AWAITING_HUMAN unit with a PENDING gate, a BLOCKED
unit and a RETRY_WAIT unit — the MM-08 fixture construction, in-process,
with every dashboard assertion made over HTTP against raw-SQL ground
truth.

View/data tests read the exact endpoints the page's JS consumes.
Action tests POST the exact endpoints + payload shapes the page's
buttons issue (promote / rollback / resolve / gate decide / retry).
Secret scan: the served page and every MM-09 read surface must contain
no FACTORY_*_TOKEN value and no configured credential_ref string.
"""
import json
import os
import subprocess
import sys
import time
import unittest
import urllib.request
from pathlib import Path

import psycopg
from psycopg.rows import dict_row

ROOT = Path(__file__).resolve().parent.parent
G2 = Path.home() / "workspace/video-factory-g2"
MM09 = Path.home() / "workspace/video-factory-master-programme/mm-gate-09"
SEEDER = (Path.home() / "workspace/video-factory-master-programme"
          / "mm-gate-03/tools/seed_registry.py")
EVAL_SERVICE = (Path.home() / "workspace/video-factory-real-ai-programme"
                / "gate-e/evaluation_service/service.py")
G2_PY = str(G2 / ".venv" / "bin" / "python")
sys.path.insert(0, str(ROOT / "tests"))
sys.path.insert(0, str(G2 / "coordinator"))

from server_fixture import make_dsn, start_server, stop_server  # noqa: E402
from coordinator import Coordinator  # noqa: E402

DB, PORT, EVAL_PORT = "g3_mm09_scratch", 8751, 8752
WORKER_TOKEN = "mm09-worker-token-SECRET"
SCHEDULER_TOKEN = "mm09-scheduler-token-SECRET"
VALIDATOR_TOKEN = "mm09-validator-token-SECRET"
CALLBACK_TOKEN = "mm09-callback-token-SECRET"
CRED_REF = "MM09_CREDREF_SECRET_STR"
ENV = {"FACTORY_WORKER_TOKEN": WORKER_TOKEN,
       "FACTORY_SCHEDULER_TOKEN": SCHEDULER_TOKEN,
       "FACTORY_VALIDATOR_TOKEN": VALIDATOR_TOKEN,
       "FACTORY_CALLBACK_TOKEN": CALLBACK_TOKEN,
       "FACTORY_EVAL_URL": f"http://127.0.0.1:{EVAL_PORT}",
       "FACTORY_STORAGE_ROOT": "/tmp/g3-mm09-storage"}
DSN = make_dsn(DB)


def raw():
    return psycopg.connect(DSN, row_factory=dict_row, autocommit=True)


def sql1(query, params=()):
    with raw() as conn:
        return conn.execute(query, params).fetchone()


def sqlall(query, params=()):
    with raw() as conn:
        return conn.execute(query, params).fetchall()


class TestMM09Dashboard(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.proc, cls.api = start_server(DB, PORT, env_extra=ENV)
        # MM-03 registry, seeded for real (idempotent seeder).
        r = subprocess.run([G2_PY, str(SEEDER), DB],
                           capture_output=True, text=True)
        assert r.returncode == 0, f"seeder failed: {r.stdout} {r.stderr}"
        # Gate E evaluation service (golden-set surface), own port.
        env = dict(os.environ, FACTORY_DSN=DSN,
                   FACTORY_EVAL_PORT=str(EVAL_PORT))
        cls.eval_proc = subprocess.Popen(
            [G2_PY, str(EVAL_SERVICE)], env=env,
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        for _ in range(100):
            try:
                with urllib.request.urlopen(
                        f"http://127.0.0.1:{EVAL_PORT}/health",
                        timeout=2) as resp:
                    if resp.status == 200:
                        break
            except Exception:
                time.sleep(0.1)
        else:
            raise RuntimeError("evaluation service did not come up")
        cls._seed_production()

    @classmethod
    def tearDownClass(cls):
        stop_server(cls.proc)
        cls.eval_proc.terminate()
        try:
            cls.eval_proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            cls.eval_proc.kill()

    # ------------------------------------------------------------- seed
    @classmethod
    def _seed_production(cls):
        c = Coordinator(DSN)
        with raw() as conn:
            conn.execute(
                "INSERT INTO provider_configs(scope, operation_id,"
                " environment, provider, model, est_cost_cents,"
                " credential_ref, created_by) VALUES"
                " ('OPERATION','01.02','test','cred-provider','m1',100,"
                " %s,'mm09-test')", (CRED_REF,))
            conn.execute(
                "INSERT INTO provider_configs(scope, operation_id,"
                " environment, provider, model, est_cost_cents,"
                " created_by) VALUES"
                " ('OPERATION','01.01','test','plain-provider','m0',300,"
                " 'mm09-test')")
            conn.execute(
                "INSERT INTO pricing_rules(provider, model, unit_kind,"
                " unit_price_cents, pricing_version, created_by) VALUES"
                " ('cred-provider','m1','input_token',1.0,'mm09-1',"
                " 'mm09-test')")
            conn.execute(
                "INSERT INTO provider_spend_limits(provider, environment,"
                " window_kind, cap_cents) VALUES"
                " ('cred-provider','test','calendar_day_utc',100000)")
        pid = c.create_production("MM-09 dashboard", 100000, 90000, "mm09")
        cls.pid = pid
        run = c.start_run(pid, "FULL", "mm09")

        def unit(op, worker, est, actual, artifact_type):
            uid = c.plan_unit(pid, run, op, "main")
            claim = c.claim(uid, worker, est)
            c.complete_attempt(uid, worker, claim["fencing_token"],
                               artifact_type, b"content", "local://d",
                               actual, usage=None)
            return uid

        # settled charge (plain binding, reported actual settles)
        cls.u_settled = unit("01.01", "w-a", 300, 300, "research_brief")
        # UNRESOLVED charge (credentialed binding, no usage at all)
        cls.u_unres = unit("01.02", "w-b", 100, 100, "research_brief")
        cls.unres_evidence = sql1(
            "SELECT evidence_id FROM financial_evidence fe"
            " JOIN action_attempts a ON a.attempt_id=fe.attempt_id"
            " WHERE a.unit_id=%s AND fe.charge_class='UNRESOLVED'",
            (cls.u_unres,))["evidence_id"]
        # evaluations of every verdict, via the API validate endpoint
        cls.u_pass = unit("01.03", "w-c", 50, 50, "research_brief")
        cls.u_fail = unit("01.04", "w-d", 50, 50, "research_brief")
        cls.u_human = unit("01.05", "w-e", 50, 50, "research_brief")
        c.close()
        api = cls.api
        for uid, body in ((cls.u_pass, {"verdict": "PASS"}),
                          (cls.u_fail, {"verdict": "FAIL",
                                        "deterministic": True}),
                          (cls.u_human, {"verdict": "REVIEW_REQUIRED"})):
            status, out = api.call("POST", f"/units/{uid}/validate", body)
            assert status == 200, (uid, out)
        # PENDING gate on the AWAITING_HUMAN unit's artifact
        art = sql1("SELECT output_artifact_id FROM action_attempts"
                   " WHERE unit_id=%s", (cls.u_human,))
        status, out = api.call("POST", f"/productions/{pid}/gates",
                               {"gate_kind": "HG2",
                                "artifact_id": str(art["output_artifact_id"])})
        assert status == 201, out
        cls.gate_id = out["gate_id"]
        cls.human_artifact = str(art["output_artifact_id"])
        # RETRY_WAIT unit (claimed, then a transient failure)
        c = Coordinator(DSN)
        cls.u_retry = c.plan_unit(pid, run, "01.06", "main")
        c.claim(cls.u_retry, "w-f", 50)
        c.event(cls.u_retry, "transient_error")
        c.close()

    # ------------------------------------------------------------ helpers
    def worker_post(self, path, body):
        return self.api.call("POST", path, body, None,
                             headers={"X-Role": "WORKER",
                                      "X-Role-Token": WORKER_TOKEN,
                                      "X-Identity": "worker-service"})

    def make_unresolved(self, op):
        """A fresh production + credentialed unit completed with no
        usage -> its UNRESOLVED evidence id (MM-08 construction)."""
        c = Coordinator(DSN)
        with raw() as conn:
            conn.execute(
                "INSERT INTO provider_configs(scope, operation_id,"
                " environment, provider, model, est_cost_cents,"
                " credential_ref, created_by) VALUES"
                " ('OPERATION',%s,'test','cred-provider','m1',100,"
                " %s,'mm09-test') ON CONFLICT DO NOTHING", (op, CRED_REF))
        pid = c.create_production(f"MM-09 extra {op}", 100000, 90000,
                                  "mm09")
        run = c.start_run(pid, "FULL", "mm09")
        uid = c.plan_unit(pid, run, op, "main")
        claim = c.claim(uid, "w-x", 100)
        c.complete_attempt(uid, "w-x", claim["fencing_token"],
                           "research_brief", b"content", "local://d", 100,
                           usage=None)
        c.close()
        row = sql1(
            "SELECT evidence_id FROM financial_evidence fe"
            " JOIN action_attempts a ON a.attempt_id=fe.attempt_id"
            " WHERE a.unit_id=%s AND fe.charge_class='UNRESOLVED'",
            (uid,))
        return pid, row["evidence_id"]

    # ------------------------------------------------------- view / data
    def test_page_structure(self):
        status, html = self.api.get_text("/")
        self.assertEqual(status, 200)
        for marker in ('id="view-models"', 'data-view="models"',
                       'id="view-quality"', 'data-view="quality"',
                       'id="view-approvals"', 'data-view="approvals"',
                       'id="policyRows"', 'id="asgRows"', 'id="benchWrap"',
                       'id="finSummaryRows"', 'id="spendRows"',
                       'id="unresolvedWrap"', 'id="goldenCard"',
                       'id="qualRows"', 'id="failRows"',
                       'id="apprGateRows"', 'id="apprUnitRows"',
                       'id="repairUnitRows"', 'id="roleSel"',
                       "promotePolicy", "rollbackPolicy", "showPolicyEvents",
                       "resolveCharge", "decideAppr", "apprRetry",
                       "No benchmark data recorded", "AWAITING_OWNER"):
            self.assertIn(marker, html, f"missing dashboard marker {marker}")

    def test_models_view_data_matches_sql(self):
        status, out = self.api.call("GET", "/model-assignments")
        self.assertEqual(status, 200)
        asg = out["assignments"]
        self.assertEqual(len(asg), 192)
        truth = sqlall("SELECT operation_id, status, primary_model,"
                       " fallback_model, null_reason FROM"
                       " operation_model_assignments")
        self.assertEqual(len(truth), 192)
        by_op = {a["operation_id"]: a for a in asg}
        for t in truth:
            a = by_op[t["operation_id"]]
            self.assertEqual(a["status"], t["status"], t["operation_id"])
            self.assertEqual(a["primary_model"], t["primary_model"])
            self.assertEqual(a["fallback_model"], t["fallback_model"])
            self.assertEqual(a["null_reason"], t["null_reason"])
        none_rows = [a for a in asg if a["status"] == "NONE"]
        self.assertEqual(len(none_rows), 120)
        self.assertTrue(all(a["null_reason"] for a in none_rows),
                        "every NONE assignment must carry its reason")
        status, out = self.api.call("GET", "/model-policies")
        self.assertEqual(status, 200)
        self.assertEqual(len(out["policies"]), 7)
        truth = sql1("SELECT COUNT(*) AS n FROM model_policies")
        self.assertEqual(truth["n"], 7)

    def test_benchmarks_empty_state(self):
        status, out = self.api.call("GET", "/benchmarks")
        self.assertEqual(status, 200)
        self.assertEqual(out["benchmarks"], [])
        self.assertEqual(sql1("SELECT COUNT(*) AS n FROM"
                              " benchmark_results")["n"], 0)

    def test_finance_view_data_matches_sql(self):
        status, out = self.api.call(
            "GET", f"/productions/{self.pid}/financial-evidence")
        self.assertEqual(status, 200)
        ev = out["financial_evidence"]
        agg = {}
        for r in ev:
            agg[r["charge_class"]] = agg.get(r["charge_class"], 0) \
                + (r["amount_cents"] or 0)
        truth = sqlall("SELECT charge_class, COALESCE(SUM(amount_cents),0)"
                       " AS s FROM financial_evidence"
                       " WHERE production_id=%s GROUP BY charge_class",
                       (self.pid,))
        self.assertEqual(agg, {t["charge_class"]: int(t["s"])
                               for t in truth})
        unres = [r for r in ev if r["charge_class"] == "UNRESOLVED"]
        self.assertEqual(len(unres), 1)
        self.assertEqual(str(unres[0]["evidence_id"]),
                         str(self.unres_evidence))
        # provider spend vs cap: the page's numbers are the cap
        # enforcement accounting read back from SQL ground truth.
        status, out = self.api.call("GET", "/provider-spend")
        self.assertEqual(status, 200)
        rows = [r for r in out["provider_spend"]
                if r["provider"] == "cred-provider"]
        self.assertEqual(len(rows), 1)
        row = rows[0]
        self.assertEqual(row["cap_cents"], 100000)
        held = sql1("SELECT COALESCE(SUM(r.estimated_cents),0) AS h"
                    " FROM budget_reservations r"
                    " JOIN action_attempts a"
                    "   ON a.reservation_id=r.reservation_id"
                    " WHERE a.resolved_config->>'provider'='cred-provider'"
                    " AND r.state='HELD'")["h"]
        self.assertEqual(row["held_cents"], int(held))
        self.assertEqual(row["held_cents"], 100)  # the unresolved claim
        self.assertEqual(row["total_cents"],
                         row["settled_cents"] + row["held_cents"])

    def test_quality_view_data_matches_sql(self):
        status, out = self.api.call("GET", "/evaluation-status")
        self.assertEqual(status, 200)
        self.assertTrue(out["reachable"])
        self.assertEqual(out["seed_cases"], 7)
        self.assertEqual(out["expert_cases"], 0)
        self.assertFalse(out["armed"])
        status, out = self.api.call(
            "GET", f"/productions/{self.pid}/evaluations")
        self.assertEqual(status, 200)
        evs = out["evaluations"]
        verdicts = {e["verdict"] for e in evs}
        self.assertEqual(verdicts, {"PASS", "FAIL", "REVIEW_REQUIRED"})
        truth = sqlall("SELECT qe.verdict, u.operation_id FROM"
                       " quality_evaluations qe JOIN artifacts a"
                       " ON a.artifact_id=qe.artifact_id"
                       " LEFT JOIN execution_units u"
                       " ON u.unit_id=a.produced_by_unit"
                       " WHERE a.production_id=%s", (self.pid,))
        self.assertEqual(len(evs), len(truth))
        self.assertEqual({(e["verdict"], e["operation_id"]) for e in evs},
                         {(t["verdict"], t["operation_id"]) for t in truth})
        fail = [e for e in evs if e["verdict"] == "FAIL"][0]
        ev_doc = fail["evidence"]
        if isinstance(ev_doc, str):
            ev_doc = json.loads(ev_doc)
        self.assertTrue(ev_doc.get("deterministic"))
        status, _ = self.api.call(
            "GET", "/productions/00000000-0000-0000-0000-000000000000"
                   "/evaluations")
        self.assertEqual(status, 404)

    def test_approvals_view_data_matches_sql(self):
        status, out = self.api.call(
            "GET", f"/productions/{self.pid}/gates")
        self.assertEqual(status, 200)
        pend = [g for g in out["gates"] if g["verdict"] == "PENDING"]
        self.assertEqual(len(pend), 1)
        self.assertEqual(pend[0]["gate_id"], self.gate_id)
        self.assertEqual(pend[0]["artifact_id"], self.human_artifact)
        status, out = self.api.call(
            "GET", f"/productions/{self.pid}/units")
        states = {u["unit_id"]: u["state"] for u in out["units"]}
        self.assertEqual(states[self.u_human], "AWAITING_HUMAN")
        self.assertEqual(states[self.u_fail], "BLOCKED")
        self.assertEqual(states[self.u_retry], "RETRY_WAIT")

    # ------------------------------------------------------------ actions
    def test_promote_then_rollback_restores(self):
        role = "STATION_06"
        p1 = sql1("SELECT policy_id FROM model_policies WHERE role=%s"
                  " AND version='1.0.0'", (role,))["policy_id"]
        with raw() as conn:
            conn.execute(
                "INSERT INTO model_policies(policy_id, role, station,"
                " primary_model, fallback_model, version, status,"
                " created_by) VALUES ('mm09-policy-st06-v2',%s,6,"
                " 'mm09/model-v2','mm09/model-v2-fb','9.9.9','PROPOSED',"
                " 'mm09-test') ON CONFLICT (policy_id) DO NOTHING",
                (role,))
        p2 = "mm09-policy-st06-v2"
        bound = sql1("SELECT COUNT(*) AS n FROM"
                     " operation_model_assignments WHERE role=%s"
                     " AND primary_model IS NOT NULL", (role,))["n"]
        status, out = self.api.call(
            "POST", f"/model-policies/{p1}/promote", {})
        self.assertEqual(status, 200, str(out))
        self.assertEqual(out["status"], "ACTIVE")
        active = sql1("SELECT COUNT(*) AS n FROM"
                      " operation_model_assignments WHERE role=%s"
                      " AND status='ACTIVE'", (role,))["n"]
        self.assertEqual(active, bound)
        status, out = self.api.call(
            "POST", f"/model-policies/{p2}/promote", {})
        self.assertEqual(status, 200, str(out))
        self.assertEqual(sql1("SELECT status FROM model_policies"
                              " WHERE policy_id=%s", (p1,))["status"],
                         "RETIRED")
        status, out = self.api.call(
            "POST", f"/model-policies/{p2}/rollback", {})
        self.assertEqual(status, 200, str(out))
        self.assertEqual(out["restored_policy_id"], p1)
        self.assertEqual(sql1("SELECT status FROM model_policies"
                              " WHERE policy_id=%s", (p1,))["status"],
                         "ACTIVE")
        self.assertEqual(sql1("SELECT status FROM model_policies"
                              " WHERE policy_id=%s", (p2,))["status"],
                         "RETIRED")
        active = sql1("SELECT COUNT(*) AS n FROM"
                      " operation_model_assignments WHERE role=%s"
                      " AND status='ACTIVE'", (role,))["n"]
        self.assertEqual(active, bound)
        # event history through the endpoint the page's Events button uses
        status, out = self.api.call(
            "GET", f"/model-policies/{p1}/events")
        self.assertEqual(status, 200)
        actions = [e["action"] for e in out["events"]]
        self.assertIn("PROMOTE", actions)
        self.assertIn("REACTIVATE", actions)
        self.assertTrue(all(e["actor"].startswith("operator:")
                            for e in out["events"]
                            if e["action"] in ("PROMOTE", "REACTIVATE")))

    def test_resolve_action_and_refusals(self):
        # duplicate / roles / price-to-nothing all surface as non-200
        status, out = self.api.call(
            "POST", f"/financial-evidence/{self.unres_evidence}/resolve",
            {"usage": {"input_tokens": 40}})
        self.assertEqual(status, 200, str(out))
        self.assertEqual(out["amount_cents"], 40)
        self.assertEqual(out["basis"], "calculated")
        res = sql1("SELECT r.state, r.settled_cents FROM"
                   " budget_reservations r JOIN action_attempts a"
                   " ON a.reservation_id=r.reservation_id"
                   " JOIN financial_evidence e"
                   " ON e.attempt_id=a.attempt_id"
                   " WHERE e.evidence_id=%s", (self.unres_evidence,))
        self.assertEqual((res["state"], res["settled_cents"]),
                         ("SETTLED", 40))
        status, _ = self.api.call(
            "POST", f"/financial-evidence/{self.unres_evidence}/resolve",
            {"usage": {"input_tokens": 40}})
        self.assertEqual(status, 409)  # duplicate resolution refused
        # the dashboard's pending rule (MM-08 semantics): the resolved
        # row remains as UNRESOLVED history but is no longer pending —
        # requires_reconciliation is the flag the page filters on.
        status, out = self.api.call(
            "GET", f"/productions/{self.pid}/financial-evidence")
        pending = [r for r in out["financial_evidence"]
                   if r["charge_class"] == "UNRESOLVED"
                   and r["requires_reconciliation"]]
        self.assertEqual(pending, [])

    def test_resolve_price_to_nothing_refused(self):
        _, ev = self.make_unresolved("02.01")
        status, _ = self.api.call(
            "POST", f"/financial-evidence/{ev}/resolve", {})
        self.assertEqual(status, 409)
        row = sql1("SELECT requires_reconciliation FROM financial_evidence"
                   " WHERE evidence_id=%s", (ev,))
        self.assertTrue(row["requires_reconciliation"])

    def test_worker_refusals_are_real(self):
        # promote with a WORKER session: 403 + committed refusal audit
        p = sql1("SELECT policy_id FROM model_policies"
                 " WHERE status='PROPOSED' LIMIT 1")["policy_id"]
        status, out = self.worker_post(
            f"/model-policies/{p}/promote", {})
        self.assertEqual(status, 403)
        self.assertIn("OPERATOR only", out.get("error", ""))
        audit = sql1("SELECT COUNT(*) AS n FROM audit_events"
                     " WHERE event_type='policy_action_refused'"
                     " AND payload->>'policy_id'=%s"
                     " AND payload->>'action'='promote'", (p,))
        self.assertGreaterEqual(audit["n"], 1)
        self.assertEqual(sql1("SELECT status FROM model_policies"
                              " WHERE policy_id=%s", (p,))["status"],
                         "PROPOSED")
        # resolve with a WORKER session: 403, charge untouched
        _, ev = self.make_unresolved("02.02")
        status, _ = self.worker_post(
            f"/financial-evidence/{ev}/resolve",
            {"usage": {"input_tokens": 10}})
        self.assertEqual(status, 403)
        self.assertTrue(sql1("SELECT requires_reconciliation"
                             " FROM financial_evidence WHERE evidence_id=%s",
                             (ev,))["requires_reconciliation"])

    def test_gate_approve_action(self):
        status, out = self.api.call(
            "POST", f"/gates/{self.gate_id}/decide",
            {"decision": "APPROVED", "decided_by": "operator"})
        self.assertEqual(status, 200, str(out))
        self.assertEqual(out["status"], "APPROVED")
        row = sql1("SELECT verdict, decided_by FROM human_gates"
                   " WHERE gate_id=%s", (self.gate_id,))
        self.assertEqual(row["verdict"], "APPROVED")
        self.assertEqual(row["decided_by"], "operator")

    def test_retry_action_and_blocked_refusal(self):
        status, out = self.api.call(
            "POST", f"/units/{self.u_retry}/retry", {})
        self.assertEqual(status, 200, str(out))
        self.assertEqual(out["state"], "READY")
        self.assertEqual(sql1("SELECT state FROM execution_units"
                              " WHERE unit_id=%s",
                              (self.u_retry,))["state"], "READY")
        # a BLOCKED unit cannot be retried — the refusal surfaces
        status, out = self.api.call(
            "POST", f"/units/{self.u_fail}/retry", {})
        self.assertEqual(status, 409)
        self.assertIn("error", out)
        self.assertEqual(sql1("SELECT state FROM execution_units"
                              " WHERE unit_id=%s",
                              (self.u_fail,))["state"], "BLOCKED")

    # -------------------------------------------------------- secret scan
    def test_secret_scan(self):
        secrets = [WORKER_TOKEN, SCHEDULER_TOKEN, VALIDATOR_TOKEN,
                   CALLBACK_TOKEN, CRED_REF]
        _, html = self.api.get_text("/")
        surfaces = {"page": html}
        for path in ("/benchmarks", "/provider-spend", "/model-policies",
                     "/model-assignments",
                     f"/productions/{self.pid}/financial-evidence",
                     f"/productions/{self.pid}/evaluations",
                     "/evaluation-status", "/provider-health",
                     "/productions"):
            status, out = self.api.call("GET", path)
            self.assertEqual(status, 200, path)
            surfaces[path] = json.dumps(out)
        for name, text in surfaces.items():
            for secret in secrets:
                self.assertNotIn(secret, text,
                                 f"secret leaked into {name}")


if __name__ == "__main__":
    unittest.main(verbosity=2)
