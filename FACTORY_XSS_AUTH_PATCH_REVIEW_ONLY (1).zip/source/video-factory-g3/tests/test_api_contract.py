"""Contract tests: every endpoint in contracts/api_contract.json is exercised
against the REAL API + scratch PG16, and each response carries at least the
keys the contract promises. Also: auth, missing-field and unknown-id errors."""
import json
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from server_fixture import make_dsn, start_server, stop_server  # noqa: E402

CONTRACT = json.loads((Path(__file__).resolve().parent.parent
                       / "contracts" / "api_contract.json").read_text())
DB, PORT = "g3_contract_test_scratch", 8741

# Gate 05: the API completion barrier requires a SUCCEEDED action record
# for every action of an attempt's pinned plan before /complete succeeds.
# These helpers post the plan's records the way the worker service does.
PLANS_PATH = (Path(__file__).resolve().parents[2] / "video-factory-g1"
              / "seed-definitions" / "workflow-1.0.0" / "plans.json")
PLAN_ACTIONS = {p["operation_id"]: p["actions"]
                for p in json.loads(PLANS_PATH.read_text())["plans"]}


def post_plan_records(case, post, uid, attempt_id, fencing, worker_id,
                      operation_id, skip=()):
    for a in PLAN_ACTIONS[operation_id]:
        if a["action_key"] in skip:
            continue
        status, out = post(f"/units/{uid}/actions",
                           {"attempt_id": attempt_id, "fencing_token": fencing,
                            "worker_id": worker_id, "action_key": a["action_key"],
                            "seq": a["seq"], "status": "SUCCEEDED"})
        case.assertIn(status, (200, 201),
                      f"plan record {a['action_key']} -> {status}: {out}")


class TestApiContract(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        # Gate 05: a WORKER role token so worker-class events (start,
        # transient_error) can be fired by their legitimate caller.
        cls.proc, cls.api = start_server(
            DB, PORT, env_extra={"FACTORY_WORKER_TOKEN": "contract-worker-token"})
        cls.covered = set()

    @classmethod
    def tearDownClass(cls):
        stop_server(cls.proc)

    def hit(self, method, path, body=None, expect=200):
        status, out = self.api.call(method, path, body)
        self.assertEqual(status, expect, f"{method} {path} -> {status}: {out}")
        # record coverage by template
        import re
        tmpl = re.sub(r"/[0-9a-f-]{36}(?=/|$)", "/{id}", path)
        tmpl = re.sub(r"\?.*$", "", tmpl)
        self.covered.add((method, tmpl))
        return out

    def contract_keys(self, method, template):
        for ep in CONTRACT["endpoints"]:
            if ep["method"] == method and ep["path"].replace("{pid}", "{id}").replace(
                    "{uid}", "{id}").replace("{aid}", "{id}").replace("{gid}", "{id}").replace(
                    "{job_id}", "{id}").replace("{evidence_id}", "{id}").replace(
                    "{rid}", "{id}") == template:
                return ep
        return None

    def assert_keys(self, method, template, out):
        ep = self.contract_keys(method, template)
        self.assertIsNotNone(ep, f"no contract entry for {method} {template}")
        missing = [k for k in ep["response"] if k not in out]
        self.assertEqual(missing, [], f"{method} {template} missing response keys {missing}")

    def test_all_endpoints(self):
        api = self.api
        # auth + error behaviour first
        status, _ = api.call("GET", "/productions", token=None)
        self.assertEqual(status, 401)
        status, _ = api.call("GET", "/productions", token="wrong")
        self.assertEqual(status, 401)
        status, _ = api.call("GET", "/productions/00000000-0000-0000-0000-000000000000")
        self.assertEqual(status, 404)
        # unknown-id writes are 404 too (verifier defect D1 regression guard)
        unknown = "00000000-0000-0000-0000-000000000000"
        for method, path, body in [
                ("POST", f"/units/{unknown}/claim", {"worker_id": "w", "estimated_cents": 1}),
                ("POST", f"/units/{unknown}/validate", {"verdict": "PASS"}),
                ("POST", f"/units/{unknown}/events", {"event": "cancel"}),
                ("POST", f"/units/{unknown}/retry", {}),
                ("POST", f"/units/{unknown}/complete",
                 {"worker_id": "w", "fencing_token": 1, "artifact_type": "x", "content": "y",
                  "storage_uri": "local://z", "actual_cost_cents": 1}),
                ("POST", f"/artifacts/{unknown}/invalidate", {"reason": "r"}),
                ("POST", f"/gates/{unknown}/decide", {"decision": "APPROVED"})]:
            status, out = api.call(method, path, body)
            self.assertEqual(status, 404, f"{method} {path} -> {status}: {out}")
        status, _ = api.call("POST", "/productions", {"title": "x"})
        self.assertEqual(status, 400)

        out = self.hit("GET", "/health", expect=200)
        self.assert_keys("GET", "/health", out)
        self.assertEqual(out["registry_operations"], 192)

        out = self.hit("POST", "/productions",
                       {"title": "Contract Prod", "hard_ceiling_cents": 100000,
                        "soft_ceiling_cents": 80000}, expect=201)
        self.assert_keys("POST", "/productions", out)
        pid = out["production_id"]

        out = self.hit("GET", "/productions")
        self.assert_keys("GET", "/productions", out)
        self.assertTrue(any(p["production_id"] == pid for p in out["productions"]))

        out = self.hit("POST", f"/productions/{pid}/runs", {"kind": "FULL"}, expect=201)
        self.assert_keys("POST", "/productions/{id}/runs", out)
        run = out["run_id"]

        out = self.hit("POST", f"/productions/{pid}/units",
                       {"operation_id": "01.01", "run_id": run}, expect=201)
        self.assert_keys("POST", "/productions/{id}/units", out)
        uid = out["unit_id"]
        self.assertEqual(out["state"], "READY")

        out = self.hit("GET", f"/productions/{pid}")
        self.assert_keys("GET", "/productions/{id}", out)
        self.assertEqual(len(out["steps"]), 16)

        out = self.hit("GET", f"/productions/{pid}/units")
        self.assert_keys("GET", "/productions/{id}/units", out)
        self.assertEqual(len(out["units"]), 1)

        out = self.hit("GET", f"/productions/{pid}/operations")
        self.assert_keys("GET", "/productions/{id}/operations", out)
        self.assertEqual(len(out["operations"]), 192)
        op1 = [o for o in out["operations"] if o["operation_id"] == "01.01"][0]
        self.assertEqual(op1["state"], "READY")

        out = self.hit("POST", f"/units/{uid}/claim",
                       {"worker_id": "w1", "estimated_cents": 500})
        self.assert_keys("POST", "/units/{id}/claim", out)
        fencing = out["fencing_token"]
        claim_plan = (out["plan_id"], out["plan_version"], out["plan_hash"])

        # Master Programme Gate 02: adoption of a prestaged claim over the
        # API — wrong identity refused; the claim's own worker adopts and
        # receives the same fencing token; a replay with the same key is
        # idempotent (fresh=False); a different key is refused.
        claim_attempt = out["attempt_id"]
        status, _ = api.call("POST", f"/units/{uid}/adopt",
                             {"worker_id": "intruder",
                              "attempt_id": claim_attempt,
                              "idempotency_key": "contract-adopt-x"})
        self.assertEqual(status, 409)
        out = self.hit("POST", f"/units/{uid}/adopt",
                       {"worker_id": "w1", "attempt_id": claim_attempt,
                        "idempotency_key": "contract-adopt-1"})
        self.assert_keys("POST", "/units/{id}/adopt", out)
        self.assertEqual(out["fencing_token"], fencing)
        self.assertTrue(out["fresh"])
        out = self.hit("POST", f"/units/{uid}/adopt",
                       {"worker_id": "w1", "attempt_id": claim_attempt,
                        "idempotency_key": "contract-adopt-1"})
        self.assertFalse(out["fresh"])
        status, _ = api.call("POST", f"/units/{uid}/adopt",
                             {"worker_id": "w1", "attempt_id": claim_attempt,
                              "idempotency_key": "contract-adopt-2"})
        self.assertEqual(status, 409)

        # Gate 04: the claim pins the operation's execution plan, and
        # plan-action records persist against it (idempotent replay;
        # wrong fencing refused; an action outside the plan refused).
        self.assertEqual(claim_plan[0], "plan/1.0.0/01.01")
        self.assertEqual(claim_plan[1], "1.0.0")
        self.assertTrue(claim_plan[2])
        out = self.hit("POST", f"/units/{uid}/actions",
                       {"attempt_id": claim_attempt, "fencing_token": fencing,
                        "worker_id": "w1",
                        "action_key": "inputs.manifest", "seq": 1,
                        "status": "SUCCEEDED",
                        "output_summary": {"inputs": 0}}, expect=201)
        self.assert_keys("POST", "/units/{id}/actions", out)
        self.assertTrue(out["recorded"])
        self.assertEqual(out["plan_id"], "plan/1.0.0/01.01")
        out = self.hit("POST", f"/units/{uid}/actions",
                       {"attempt_id": claim_attempt, "fencing_token": fencing,
                        "worker_id": "w1",
                        "action_key": "inputs.manifest", "seq": 1,
                        "status": "SUCCEEDED"}, expect=200)
        self.assertFalse(out["recorded"])
        status, _ = api.call("POST", f"/units/{uid}/actions",
                             {"attempt_id": claim_attempt,
                              "fencing_token": fencing + 99,
                              "action_key": "op.build", "seq": 2,
                              "status": "SUCCEEDED"})
        self.assertIn(status, (400, 409))
        status, _ = api.call("POST", f"/units/{uid}/actions",
                             {"attempt_id": claim_attempt,
                              "fencing_token": fencing,
                              "action_key": "not.a.plan.action", "seq": 9,
                              "status": "SUCCEEDED"})
        self.assertIn(status, (400, 409))

        # Gate 04: registry-driven materialization of a run graph.
        out = self.hit("POST", "/productions",
                       {"title": "Materialized Prod", "hard_ceiling_cents": 100000},
                       expect=201)
        mpid = out["production_id"]
        out = self.hit("POST", f"/productions/{mpid}/runs", {"kind": "FULL"},
                       expect=201)
        mrid = out["run_id"]
        out = self.hit("POST", f"/productions/{mpid}/runs/{mrid}/materialize",
                       {"operation_ids": ["01.01", "01.12", "02.12"]},
                       expect=201)
        self.assert_keys("POST", "/productions/{id}/runs/{id}/materialize", out)
        self.assertEqual(out["unit_count"], 3)
        self.assertEqual(set(out["units"]), {"01.01", "01.12", "02.12"})
        out = self.hit("GET", f"/productions/{mpid}/units")
        states = {u["operation_id"]: u["state"] for u in out["units"]}
        self.assertEqual(states["01.01"], "READY")
        self.assertEqual(states["01.12"], "PENDING")
        self.assertEqual(states["02.12"], "PENDING")

        # Gate 05: the completion barrier needs the rest of the pinned
        # plan's records before /complete (inputs.manifest already posted).
        post_plan_records(self, lambda p, b: api.call("POST", p, b), uid,
                          claim_attempt, fencing, "w1", "01.01",
                          skip={"inputs.manifest"})
        out = self.hit("POST", f"/units/{uid}/complete",
                       {"worker_id": "w1", "fencing_token": fencing, "artifact_type": "script",
                        "content": "script text", "storage_uri": "local://s1",
                        "actual_cost_cents": 400})
        self.assert_keys("POST", "/units/{id}/complete", out)
        self.assertEqual(out["state"], "VALIDATING")
        script_art = out["artifact_id"]

        out = self.hit("POST", f"/units/{uid}/validate", {"verdict": "PASS"})
        self.assert_keys("POST", "/units/{id}/validate", out)
        self.assertEqual(out["state"], "ACCEPTED")

        # Gate G reads: evaluations + provider-jobs for the unit
        out = self.hit("GET", f"/units/{uid}/evaluations")
        self.assert_keys("GET", "/units/{id}/evaluations", out)
        self.assertTrue(any(e["verdict"] == "PASS" for e in out["evaluations"]))
        out = self.hit("GET", f"/units/{uid}/provider-jobs")
        self.assert_keys("GET", "/units/{id}/provider-jobs", out)
        self.assertEqual(out["provider_jobs"], [])

        out = self.hit("GET", f"/productions/{pid}/budget")
        self.assert_keys("GET", "/productions/{id}/budget", out)
        self.assertEqual(out["spent_cents"], 400)
        self.assertEqual(out["available_cents"], 100000 - 400)

        out = self.hit("POST", f"/productions/{pid}/artifacts",
                       {"artifact_type": "storyboard", "content": "board",
                        "storage_uri": "local://b1", "depends_on_artifact_ids": [script_art]},
                       expect=201)
        self.assert_keys("POST", "/productions/{id}/artifacts", out)
        board_art = out["artifact_id"]

        out = self.hit("GET", f"/productions/{pid}/artifacts")
        self.assert_keys("GET", "/productions/{id}/artifacts", out)
        self.assertEqual(len(out["artifacts"]), 2)

        out = self.hit("GET", f"/artifacts/{script_art}/impact")
        self.assert_keys("GET", "/artifacts/{id}/impact", out)
        self.assertEqual(set(out["affected_artifact_ids"]), {script_art, board_art})
        self.assertEqual(out["affected_unit_ids"], [uid])

        out = self.hit("POST", f"/productions/{pid}/gates",
                       {"gate_kind": "HG-SCRIPT", "artifact_id": script_art}, expect=201)
        self.assert_keys("POST", "/productions/{id}/gates", out)
        gid = out["gate_id"]

        out = self.hit("GET", f"/productions/{pid}/gates")
        self.assert_keys("GET", "/productions/{id}/gates", out)
        self.assertEqual(out["gates"][0]["verdict"], "PENDING")

        out = self.hit("GET", f"/gates/require?production_id={pid}&gate_kind=HG-SCRIPT"
                             f"&artifact_id={script_art}")
        self.assert_keys("GET", "/gates/require", out)
        self.assertFalse(out["satisfied"])

        out = self.hit("POST", f"/gates/{gid}/decide",
                       {"decision": "APPROVED", "decided_by": "operator"})
        self.assert_keys("POST", "/gates/{id}/decide", out)
        self.assertEqual(out["status"], "APPROVED")

        out = self.hit("GET", f"/gates/require?production_id={pid}&gate_kind=HG-SCRIPT"
                             f"&artifact_id={script_art}")
        self.assertTrue(out["satisfied"])

        # re-deciding a decided gate is a state rejection: 409, not 404
        status, _ = api.call("POST", f"/gates/{gid}/decide",
                             {"decision": "REJECTED", "decided_by": "operator"})
        self.assertEqual(status, 409)

        # events endpoint: plan a fresh unit and cancel it
        out = self.hit("POST", f"/productions/{pid}/units",
                       {"operation_id": "01.02", "run_id": run}, expect=201)
        uid2 = out["unit_id"]
        out = self.hit("POST", f"/units/{uid2}/events", {"event": "cancel"})
        self.assert_keys("POST", "/units/{id}/events", out)
        self.assertEqual(out["state"], "CANCELLED")

        # retry endpoint (F-G9-03 fix): claim -> transient_error parks the
        # unit in RETRY_WAIT; retry returns it to READY; a second retry is
        # a state rejection (409) and changes nothing.
        out = self.hit("POST", f"/productions/{pid}/units",
                       {"operation_id": "01.03", "run_id": run}, expect=201)
        uid3 = out["unit_id"]
        self.hit("POST", f"/units/{uid3}/claim",
                 {"worker_id": "w", "estimated_cents": 100})
        # Gate 05 (G01-D07): transient_error is a WORKER-class event; it
        # is fired by the claiming worker, not the operator token.
        status, out = api.call(
            "POST", f"/units/{uid3}/events",
            {"event": "transient_error", "worker_id": "w"}, token=None,
            headers=role_headers("WORKER", token="contract-worker-token"))
        self.assertEqual(status, 200)
        self.assertEqual(out["state"], "RETRY_WAIT")
        out = self.hit("POST", f"/units/{uid3}/retry", {})
        self.assert_keys("POST", "/units/{id}/retry", out)
        self.assertEqual(out["state"], "READY")
        status, _ = api.call("POST", f"/units/{uid3}/retry", {})
        self.assertEqual(status, 409)

        # ---- Gate C: configs, attempt snapshots, provider-job round trip
        out = self.hit("GET", "/configs")
        self.assert_keys("GET", "/configs", out)
        self.assertTrue(any(cfg["scope"] == "FACTORY" for cfg in out["configs"]))

        out = self.hit("POST", "/configs",
                       {"scope": "STATION", "station": 1, "provider": "contract-test",
                        "est_cost_cents": 100}, expect=201)
        self.assert_keys("POST", "/configs", out)
        self.assertEqual(out["version"], 1)
        out = self.hit("POST", "/configs",
                       {"scope": "STATION", "station": 1, "provider": "contract-test",
                        "est_cost_cents": 100}, expect=201)
        self.assertEqual(out["version"], 2)  # supersede bumps the version
        out = self.hit("GET", "/configs")
        active_s1 = [x for x in out["configs"]
                     if x["scope"] == "STATION" and x["station"] == 1]
        self.assertEqual(len(active_s1), 1)  # exactly one active row per scope key

        out = self.hit("POST", f"/productions/{pid}/units",
                       {"operation_id": "01.04", "run_id": run}, expect=201)
        uid4 = out["unit_id"]
        out = self.hit("POST", f"/units/{uid4}/claim",
                       {"worker_id": "w1", "estimated_cents": 100})
        att_id, fenc4 = out["attempt_id"], out["fencing_token"]
        # Gate 05: start is a WORKER-class event, fired by the claim's worker.
        status, _ = api.call(
            "POST", f"/units/{uid4}/events",
            {"event": "start", "worker_id": "w1"}, token=None,
            headers=role_headers("WORKER", token="contract-worker-token"))
        self.assertEqual(status, 200)
        out = self.hit("POST", "/provider-jobs",
                       {"unit_id": uid4, "attempt_id": att_id, "fencing_token": fenc4,
                        "idempotency_key": "contract-job-1"}, expect=201)
        self.assert_keys("POST", "/provider-jobs", out)
        job_id = out["job_id"]
        import base64 as _b64
        out = self.hit("POST", f"/provider-jobs/{job_id}/callback",
                       {"status": "COMPLETED",
                        "content_b64": _b64.b64encode(b"async clip").decode(),
                        "artifact_type": "media", "reported_cost_cents": 90,
                        "provider_request_id": "ct-1"})
        self.assert_keys("POST", "/provider-jobs/{id}/callback", out)
        self.assertEqual(out["job_status"], "COMPLETED")
        self.assertFalse(out["duplicate"])
        out = self.hit("POST", f"/provider-jobs/{job_id}/callback",
                       {"status": "COMPLETED",
                        "content_b64": _b64.b64encode(b"async clip").decode(),
                        "artifact_type": "media", "reported_cost_cents": 90})
        self.assertTrue(out["duplicate"])  # exactly-once

        # ---- MM-04: provider-job cancellation (contract 1.9.0). A
        # WORKER cancel must present the attempt's claim identity
        # (wrong identity -> 403 + refusal audit); OPERATOR cancels by
        # role authority; a repeat cancel is idempotent.
        out = self.hit("POST", f"/productions/{pid}/units",
                       {"operation_id": "01.05", "run_id": run}, expect=201)
        uid5 = out["unit_id"]
        out = self.hit("POST", f"/units/{uid5}/claim",
                       {"worker_id": "w1", "estimated_cents": 100})
        att5, fenc5 = out["attempt_id"], out["fencing_token"]
        status, _ = api.call(
            "POST", f"/units/{uid5}/events",
            {"event": "start", "worker_id": "w1"}, token=None,
            headers={"X-Role": "WORKER",
                     "X-Role-Token": "contract-worker-token",
                     "X-Identity": "w1"})
        self.assertEqual(status, 200)
        out = self.hit("POST", "/provider-jobs",
                       {"unit_id": uid5, "attempt_id": att5, "fencing_token": fenc5,
                        "idempotency_key": "contract-job-cancel"}, expect=201)
        job5 = out["job_id"]
        status, _ = api.call(
            "POST", f"/provider-jobs/{job5}/cancel",
            {"worker_id": "mallory"}, token=None,
            headers={"X-Role": "WORKER",
                     "X-Role-Token": "contract-worker-token",
                     "X-Identity": "mallory"})
        self.assertEqual(status, 403)  # identity-bound: not the claim's worker
        out = self.hit("POST", f"/provider-jobs/{job5}/cancel", {})
        self.assert_keys("POST", "/provider-jobs/{id}/cancel", out)
        self.assertEqual(out["job_status"], "CANCELLED")
        self.assertEqual(out["unit_state"], "RETRY_WAIT")
        self.assertFalse(out["already_cancelled"])
        out = self.hit("POST", f"/provider-jobs/{job5}/cancel", {})
        self.assertTrue(out["already_cancelled"])  # idempotent

        out = self.hit("GET", f"/units/{uid4}/attempts")
        self.assert_keys("GET", "/units/{id}/attempts", out)
        self.assertEqual(len(out["attempts"]), 1)
        self.assertEqual(out["attempts"][0]["status"], "VALIDATING")
        self.assertIsNotNone(out["attempts"][0]["resolved_config_hash"])
        self.assertEqual(out["attempts"][0]["resolved_config"]["provider"], "contract-test")

        # ---- Gate D: staging, pricing rules, evidence reads + settle refusal
        import base64 as _b64d
        out = self.hit("POST", "/artifacts/stage",
                       {"production_id": pid,
                        "content_base64": _b64d.b64encode(b"staged contract bytes").decode(),
                        "content_type": "text/plain"}, expect=201)
        self.assert_keys("POST", "/artifacts/stage", out)
        self.assertEqual(out["state"], "STAGED")
        self.assertTrue(out["uri"].startswith("store://candidates/"))

        out = self.hit("POST", "/pricing-rules",
                       {"provider": "mock", "unit_kind": "input_token",
                        "unit_price_cents": "0.3000", "pricing_version": "pv-contract"},
                       expect=201)
        self.assert_keys("POST", "/pricing-rules", out)
        out = self.hit("GET", "/pricing-rules")
        self.assert_keys("GET", "/pricing-rules", out)
        self.assertTrue(any(r["pricing_version"] == "pv-contract"
                            for r in out["pricing_rules"]))

        out = self.hit("GET", f"/productions/{pid}/financial-evidence")
        self.assert_keys("GET", "/productions/{id}/financial-evidence", out)
        self.assertTrue(out["financial_evidence"])  # uid4's callback wrote rows
        ev_id = out["financial_evidence"][0]["evidence_id"]
        # settling a row that is not an unsettled provider charge -> 409
        status, _ = api.call("POST", f"/financial-evidence/{ev_id}/settle", {})
        self.assertEqual(status, 409)
        self.covered.add(("POST", "/financial-evidence/{id}/settle"))
        # MM-08: resolving a row that is not an UNRESOLVED charge -> 409
        status, _ = api.call("POST", f"/financial-evidence/{ev_id}/resolve",
                             {"reported_cost_cents": 1})
        self.assertEqual(status, 409)
        self.covered.add(("POST", "/financial-evidence/{id}/resolve"))
        # budget now reports the soft-ceiling fields (contract 1.2.0)
        out = self.hit("GET", f"/productions/{pid}/budget")
        self.assertIn("soft_ceiling_crossed", out)
        self.assertFalse(out["soft_ceiling_crossed"])

        # invalidate last (cascades over script + storyboard)
        out = self.hit("POST", f"/artifacts/{script_art}/invalidate",
                       {"reason": "contract test cascade"})
        self.assert_keys("POST", "/artifacts/{id}/invalidate", out)
        self.assertEqual(set(out["affected_artifact_ids"]), {script_art, board_art})

        # ---- MM-03: model registry endpoints (contract 1.8.0). The
        # scratch DB carries migration 016 with EMPTY registry tables;
        # seed one throwaway policy row directly (test fixture data),
        # then exercise the reads plus the OPERATOR promote/rollback
        # path (a station-less, assignment-less policy writes 0
        # bindings — the full binding flow is MM-03's own battery).
        import psycopg
        pol_id = "11111111-2222-3333-4444-555555555555"
        with psycopg.connect(make_dsn(DB)) as conn:
            conn.execute(
                "INSERT INTO model_policies(policy_id, role, version, status,"
                " created_by) VALUES (%s,'CONTRACT_TEST','0.0.1','PROPOSED',"
                "'contract-test') ON CONFLICT (policy_id) DO NOTHING",
                (pol_id,))
            conn.commit()
        out = self.hit("GET", "/model-policies")
        self.assert_keys("GET", "/model-policies", out)
        out = self.hit("GET", f"/model-policies/{pol_id}")
        self.assert_keys("GET", "/model-policies/{id}", out)
        self.assertEqual(out["status"], "PROPOSED")
        out = self.hit("GET", f"/model-policies/{pol_id}/events")
        self.assert_keys("GET", "/model-policies/{id}/events", out)
        out = self.hit("GET", "/model-assignments")
        self.assert_keys("GET", "/model-assignments", out)
        out = self.hit("GET", "/models")
        self.assert_keys("GET", "/models", out)
        out = self.hit("GET", "/provider-health")
        self.assert_keys("GET", "/provider-health", out)
        out = self.hit("POST", f"/model-policies/{pol_id}/promote",
                       {"approval_note": "contract test approval"})
        self.assert_keys("POST", "/model-policies/{id}/promote", out)
        self.assertEqual(out["status"], "ACTIVE")
        self.assertEqual(out["bindings_written"], 0)
        out = self.hit("POST", f"/model-policies/{pol_id}/rollback",
                       {"note": "contract test rollback"})
        self.assert_keys("POST", "/model-policies/{id}/rollback", out)
        self.assertEqual(out["status"], "RETIRED")
        self.assertIsNone(out["restored_policy_id"])

        # MM-09: the four read-only dashboard surfaces.
        out = self.hit("GET", "/benchmarks")
        self.assert_keys("GET", "/benchmarks", out)
        out = self.hit("GET", "/provider-spend")
        self.assert_keys("GET", "/provider-spend", out)
        out = self.hit("GET", f"/productions/{pid}/evaluations")
        self.assert_keys("GET", "/productions/{id}/evaluations", out)
        out = self.hit("GET", "/evaluation-status")
        self.assert_keys("GET", "/evaluation-status", out)

        # every contract endpoint was exercised
        want = {(ep["method"], ep["path"].replace("{pid}", "{id}").replace("{uid}", "{id}")
                 .replace("{aid}", "{id}").replace("{gid}", "{id}").replace("{job_id}", "{id}")
                 .replace("{evidence_id}", "{id}").replace("{rid}", "{id}"))
                for ep in CONTRACT["endpoints"]}
        self.assertEqual(want - self.covered, set(),
                         f"contract endpoints never exercised: {want - self.covered}")


ROLE_ENV = {"FACTORY_WORKER_TOKEN": "test-worker-token",
            "FACTORY_SCHEDULER_TOKEN": "test-scheduler-token",
            "FACTORY_VALIDATOR_TOKEN": "test-validator-token",
            "FACTORY_CALLBACK_TOKEN": "test-callback-token"}
ROLE_DB, ROLE_PORT = "g3_gatec_roles_scratch", 8742


def role_headers(role, token=None, identity=None):
    h = {"X-Role": role, "X-Role-Token": token or ROLE_ENV[f"FACTORY_{role}_TOKEN"]}
    if identity:
        h["X-Identity"] = identity
    return h


class TestApiGateCRoles(unittest.TestCase):
    """Gate C: role-separated auth (B4.1) enforced per endpoint."""

    @classmethod
    def setUpClass(cls):
        cls.proc, cls.api = start_server(ROLE_DB, ROLE_PORT, env_extra=ROLE_ENV)

    @classmethod
    def tearDownClass(cls):
        stop_server(cls.proc)

    def setUp(self):
        api = self.api
        _, out = api.call("POST", "/productions",
                          {"title": "Roles Prod", "hard_ceiling_cents": 100000,
                           "soft_ceiling_cents": 80000})
        self.pid = out["production_id"]
        _, out = api.call("POST", f"/productions/{self.pid}/runs", {"kind": "FULL"})
        self.run = out["run_id"]

    def unit(self, op="01.01"):
        _, out = self.api.call("POST", f"/productions/{self.pid}/units",
                               {"operation_id": op, "run_id": self.run})
        return out["unit_id"]

    def role_call(self, role, method, path, body=None, identity=None):
        return self.api.call(method, path, body, token=None,
                             headers=role_headers(role, identity=identity))

    def test_validator_cannot_claim_but_can_validate(self):
        uid = self.unit()
        status, _ = self.role_call("VALIDATOR", "POST", f"/units/{uid}/claim",
                                   {"worker_id": "v", "estimated_cents": 1})
        self.assertEqual(status, 403)
        # operator drives the unit to VALIDATING; the validator validates it
        _, claim = self.api.call("POST", f"/units/{uid}/claim",
                                 {"worker_id": "w1", "estimated_cents": 100})
        # Gate 05: completion barrier — post the 01.01 plan's records first.
        post_plan_records(self, lambda p, b: self.api.call("POST", p, b), uid,
                          claim["attempt_id"], claim["fencing_token"], "w1",
                          "01.01")
        self.api.call("POST", f"/units/{uid}/complete",
                      {"worker_id": "w1", "fencing_token": claim["fencing_token"],
                       "artifact_type": "script", "content": "s", "storage_uri": "local://s",
                       "actual_cost_cents": 90})
        status, out = self.role_call("VALIDATOR", "POST", f"/units/{uid}/validate",
                                     {"verdict": "PASS"})
        self.assertEqual(status, 200)
        self.assertEqual(out["state"], "ACCEPTED")
        # ...and the validator still cannot do operator work
        status, _ = self.role_call("VALIDATOR", "POST", "/productions",
                                   {"title": "x", "hard_ceiling_cents": 1})
        self.assertEqual(status, 403)

    def test_worker_claims_completes_and_submits_but_no_gates(self):
        uid = self.unit()
        status, claim = self.role_call("WORKER", "POST", f"/units/{uid}/claim",
                                       {"worker_id": "station-1-worker"})
        self.assertEqual(status, 200)  # estimate omitted -> config binding (100)
        # Gate 05: completion barrier — the worker posts its plan records.
        post_plan_records(self,
                          lambda p, b: self.role_call("WORKER", "POST", p, b),
                          uid, claim["attempt_id"], claim["fencing_token"],
                          "station-1-worker", "01.01")
        status, out = self.role_call("WORKER", "POST", f"/units/{uid}/complete",
                                     {"worker_id": "station-1-worker",
                                      "fencing_token": claim["fencing_token"],
                                      "artifact_type": "script", "content": "s",
                                      "storage_uri": "local://s", "actual_cost_cents": 90,
                                      "usage": {"input_tokens": 3},
                                      "provider_request_id": "w-1"})
        self.assertEqual(status, 200)
        self.assertEqual(out["state"], "VALIDATING")
        _, arts = self.api.call("GET", f"/productions/{self.pid}/artifacts")
        art_id = arts["artifacts"][0]["artifact_id"]
        status, _ = self.role_call("WORKER", "POST", f"/productions/{self.pid}/gates",
                                   {"gate_kind": "HG2", "artifact_id": art_id})
        self.assertEqual(status, 403)  # gates are OPERATOR-only
        uid2 = self.unit("01.02")
        _, claim2 = self.api.call("POST", f"/units/{uid2}/claim",
                                  {"worker_id": "w", "estimated_cents": 100})
        # Gate 05: start is WORKER-class, fired by the claim's worker.
        s2, _ = self.role_call("WORKER", "POST", f"/units/{uid2}/events",
                               {"event": "start", "worker_id": "w"})
        self.assertEqual(s2, 200)
        status, out = self.role_call("WORKER", "POST", "/provider-jobs",
                                     {"unit_id": uid2, "attempt_id": claim2["attempt_id"],
                                      "fencing_token": claim2["fencing_token"],
                                      "idempotency_key": "role-job-1"})
        self.assertEqual(status, 201)
        self.assertIn("job_id", out)

    def test_callback_role_only_callbacks(self):
        uid = self.unit()
        _, claim = self.api.call("POST", f"/units/{uid}/claim",
                                 {"worker_id": "w", "estimated_cents": 100})
        # Gate 05: start is WORKER-class, fired by the claim's worker.
        s0, _ = self.role_call("WORKER", "POST", f"/units/{uid}/events",
                               {"event": "start", "worker_id": "w"})
        self.assertEqual(s0, 200)
        _, job = self.api.call("POST", "/provider-jobs",
                               {"unit_id": uid, "attempt_id": claim["attempt_id"],
                                "fencing_token": claim["fencing_token"],
                                "idempotency_key": "role-job-2"})
        status, _ = self.role_call("CALLBACK", "GET", "/productions")
        self.assertEqual(status, 403)  # CALLBACK has no read access
        status, _ = self.role_call("CALLBACK", "POST", f"/units/{uid}/claim",
                                   {"worker_id": "x", "estimated_cents": 1})
        self.assertEqual(status, 403)
        status, out = self.role_call("CALLBACK", "POST",
                                     f"/provider-jobs/{job['job_id']}/callback",
                                     {"status": "COMPLETED", "content": "clip",
                                      "artifact_type": "media", "reported_cost_cents": 90})
        self.assertEqual(status, 200)
        self.assertEqual(out["job_status"], "COMPLETED")
        # wrong role token -> 401, not 403
        status, _ = self.api.call("POST", f"/provider-jobs/{job['job_id']}/callback",
                                  {"status": "COMPLETED"}, token=None,
                                  headers={"X-Role": "CALLBACK", "X-Role-Token": "nope"})
        self.assertEqual(status, 401)

    def test_scheduler_claims_but_cannot_write_configs(self):
        uid = self.unit()
        status, out = self.role_call("SCHEDULER", "POST", f"/units/{uid}/claim",
                                     {"worker_id": "sched-text"})
        self.assertEqual(status, 200)
        status, _ = self.role_call("SCHEDULER", "POST", "/configs",
                                   {"scope": "STATION", "station": 9, "provider": "x"})
        self.assertEqual(status, 403)
        status, out = self.role_call("SCHEDULER", "GET", "/configs")
        self.assertEqual(status, 200)
        self.assertIn("configs", out)
        # legacy operator token still works alongside roles
        status, _ = self.api.call("GET", "/productions")
        self.assertEqual(status, 200)


GATED_DB, GATED_PORT = "g3_gated_scratch", 8743
GATED_ENV = {"FACTORY_WORKER_TOKEN": "gated-worker-token",
             "FACTORY_STORAGE_ROOT": "/tmp/g3-gated-storage"}


class TestApiGateD(unittest.TestCase):
    """Gate D: D-C1 estimate enforcement over HTTP, candidate staging +
    complete-by-candidate, hash-mismatch refusal, pricing evidence,
    provider-charge settlement."""

    @classmethod
    def setUpClass(cls):
        cls.proc, cls.api = start_server(GATED_DB, GATED_PORT, env_extra=GATED_ENV)

    @classmethod
    def tearDownClass(cls):
        stop_server(cls.proc)

    def setUp(self):
        _, out = self.api.call("POST", "/productions",
                               {"title": "Gate D HTTP", "hard_ceiling_cents": 100000,
                                "soft_ceiling_cents": 90000})
        self.pid = out["production_id"]
        _, out = self.api.call("POST", f"/productions/{self.pid}/runs", {"kind": "FULL"})
        self.run = out["run_id"]

    def unit(self, op="05.12", key="main"):
        _, out = self.api.call("POST", f"/productions/{self.pid}/units",
                               {"operation_id": op, "run_id": self.run, "unit_key": key})
        return out["unit_id"]

    def role_post(self, path, body, role, role_token):
        """POST authenticated ONLY as a Gate C role (no operator header)."""
        import json as _json
        import urllib.error
        import urllib.request
        req = urllib.request.Request(f"http://127.0.0.1:{GATED_PORT}" + path, method="POST")
        req.add_header("X-Role", role)
        req.add_header("X-Role-Token", role_token)
        req.add_header("Content-Type", "application/json")
        try:
            with urllib.request.urlopen(req, data=_json.dumps(body).encode(),
                                        timeout=10) as r:
                return r.status, _json.loads(r.read() or b"{}")
        except urllib.error.HTTPError as e:
            raw = e.read()
            try:
                return e.code, _json.loads(raw or b"{}")
            except _json.JSONDecodeError:
                return e.code, {}

    def test_claim_enforces_config_estimate(self):
        _, out = self.api.call("POST", "/configs",
                               {"scope": "OPERATION", "operation_id": "05.12",
                                "provider": "gated-http", "est_cost_cents": 900})
        self.assertEqual(out["version"], 1)
        uid = self.unit()
        status, _ = self.api.call("POST", f"/units/{uid}/claim",
                                  {"worker_id": "w1", "estimated_cents": 100})
        self.assertEqual(status, 409)  # below the binding's 900
        status, out = self.api.call("POST", f"/units/{uid}/claim",
                                    {"worker_id": "w1", "estimated_cents": 950})
        self.assertEqual(status, 200)
        _, budget = self.api.call("GET", f"/productions/{self.pid}/budget")
        self.assertEqual(budget["reserved_cents"], 900)  # config, not 950
        uid2 = self.unit(key="second")
        status, _ = self.api.call("POST", f"/units/{uid2}/claim", {"worker_id": "w1"})
        self.assertEqual(status, 200)
        _, budget = self.api.call("GET", f"/productions/{self.pid}/budget")
        self.assertEqual(budget["reserved_cents"], 1800)

    def test_stage_and_complete_by_candidate(self):
        import base64 as b64
        import hashlib
        data = b"gate d http candidate"
        sha = hashlib.sha256(data).hexdigest()
        status, cand = self.role_post(
            "/artifacts/stage",
            {"production_id": self.pid,
             "content_base64": b64.b64encode(data).decode(), "content_type": "text/plain"},
            "WORKER", GATED_ENV["FACTORY_WORKER_TOKEN"])
        self.assertEqual(status, 201)  # WORKER may stage
        self.assertEqual(cand["state"], "STAGED")
        uid = self.unit()
        _, claim = self.api.call("POST", f"/units/{uid}/claim", {"worker_id": "w1"})
        # Gate 05: completion barrier — post the 05.12 plan's records.
        post_plan_records(self, lambda p, b: self.api.call("POST", p, b), uid,
                          claim["attempt_id"], claim["fencing_token"], "w1",
                          "05.12")
        status, out = self.api.call(
            "POST", f"/units/{uid}/complete",
            {"worker_id": "w1", "fencing_token": claim["fencing_token"],
             "artifact_type": "generic_artifact", "candidate_uri": cand["uri"],
             "actual_cost_cents": 90})
        self.assertEqual(status, 200)
        self.assertEqual(out["state"], "VALIDATING")
        _, arts = self.api.call("GET", f"/productions/{self.pid}/artifacts")
        mine = [a for a in arts["artifacts"] if a["artifact_id"] == out["artifact_id"]][0]
        self.assertEqual(mine["storage_uri"], f"store://objects/{sha}")

    def test_complete_hash_mismatch_is_409(self):
        uid = self.unit()
        _, claim = self.api.call("POST", f"/units/{uid}/claim", {"worker_id": "w1"})
        # Gate 05: satisfy the completion barrier first so the 409 below
        # is the hash refusal itself, not the barrier's.
        post_plan_records(self, lambda p, b: self.api.call("POST", p, b), uid,
                          claim["attempt_id"], claim["fencing_token"], "w1",
                          "05.12")
        status, _ = self.api.call(
            "POST", f"/units/{uid}/complete",
            {"worker_id": "w1", "fencing_token": claim["fencing_token"],
             "artifact_type": "generic_artifact", "content": "abc",
             "storage_uri": "local://x", "actual_cost_cents": 90,
             "expected_sha256": "0" * 64})
        self.assertEqual(status, 409)
        _, units = self.api.call("GET", f"/productions/{self.pid}/units")
        mine = [u for u in units["units"] if u["unit_id"] == uid][0]
        self.assertEqual(mine["state"], "CLAIMED")  # nothing registered/settled

    def test_pricing_rules_drive_calculated_settlement(self):
        status, _ = self.api.call("POST", "/pricing-rules",
                                  {"provider": "mock", "unit_kind": "input_token",
                                   "unit_price_cents": "0.3000",
                                   "pricing_version": "pv-http"})
        self.assertEqual(status, 201)
        uid = self.unit("06.12")  # no OPERATION binding: snapshot provider is FACTORY 'mock'
        _, claim = self.api.call("POST", f"/units/{uid}/claim", {"worker_id": "w1"})
        # Gate 05: completion barrier — post the 06.12 plan's records.
        post_plan_records(self, lambda p, b: self.api.call("POST", p, b), uid,
                          claim["attempt_id"], claim["fencing_token"], "w1",
                          "06.12")
        status, _ = self.api.call(
            "POST", f"/units/{uid}/complete",
            {"worker_id": "w1", "fencing_token": claim["fencing_token"],
             "artifact_type": "generic_artifact", "content": "x",
             "storage_uri": "local://x", "actual_cost_cents": 999,
             "usage": {"input_tokens": 1000}})
        self.assertEqual(status, 200)
        _, budget = self.api.call("GET", f"/productions/{self.pid}/budget")
        self.assertEqual(budget["spent_cents"], 300)  # CALCULATED wins over the 999 actual
        _, ev = self.api.call("GET", f"/productions/{self.pid}/financial-evidence")
        classes = {e["charge_class"] for e in ev["financial_evidence"]}
        self.assertIn("CALCULATED", classes)
        fin = [e for e in ev["financial_evidence"] if e["charge_class"] == "FINALIZED"]
        self.assertEqual(fin[-1]["usage"]["_finalization_basis"], "calculated")

    def test_settle_provider_charge_endpoint(self):
        import psycopg
        from psycopg.rows import dict_row
        uid = self.unit()
        dsn = f"host=127.0.0.1 dbname={GATED_DB} user=factory password=factory_dev_local"
        with psycopg.connect(dsn, row_factory=dict_row, autocommit=True) as conn:
            ev = conn.execute(
                "INSERT INTO financial_evidence(production_id, unit_id, provider,"
                " provider_request_id, charge_class, amount_cents, requires_reconciliation)"
                " VALUES (%s,%s,'mock','http-settle-1','PROVIDER_REPORTED',25,true)"
                " RETURNING evidence_id", (self.pid, uid)).fetchone()
        ev_id = ev["evidence_id"]
        # WORKER may not settle (OPERATOR only)
        status, _ = self.role_post(f"/financial-evidence/{ev_id}/settle", {},
                                   "WORKER", GATED_ENV["FACTORY_WORKER_TOKEN"])
        self.assertEqual(status, 403)
        status, out = self.api.call("POST", f"/financial-evidence/{ev_id}/settle", {})
        self.assertEqual(status, 200)
        self.assertEqual(out["amount_cents"], 25)
        _, budget = self.api.call("GET", f"/productions/{self.pid}/budget")
        self.assertEqual(budget["spent_cents"], 25)
        status, _ = self.api.call("POST", f"/financial-evidence/{ev_id}/settle", {})
        self.assertEqual(status, 409)  # already settled
        status, _ = self.api.call(
            "POST", "/financial-evidence/00000000-0000-0000-0000-000000000000/settle", {})
        self.assertEqual(status, 404)


GATEE_DB, GATEE_PORT = "g3_gatee_scratch", 8744


class TestApiGateE(unittest.TestCase):
    """Gate E: /validate accepts an evaluations array (evaluation-service
    submission shape) alongside the legacy single-verdict body; the
    coordinator mapping decides the outcome."""

    @classmethod
    def setUpClass(cls):
        cls.proc, cls.api = start_server(GATEE_DB, GATEE_PORT)

    @classmethod
    def tearDownClass(cls):
        stop_server(cls.proc)

    def setUp(self):
        _, out = self.api.call("POST", "/productions",
                               {"title": "Gate E HTTP", "hard_ceiling_cents": 100000,
                                "soft_ceiling_cents": 90000})
        self.pid = out["production_id"]
        _, out = self.api.call("POST", f"/productions/{self.pid}/runs", {"kind": "FULL"})
        self.run = out["run_id"]

    def validating_unit(self, key):
        _, out = self.api.call("POST", f"/productions/{self.pid}/units",
                               {"operation_id": "05.12", "run_id": self.run,
                                "unit_key": key})
        uid = out["unit_id"]
        _, out = self.api.call("POST", f"/units/{uid}/claim", {"worker_id": "w1"})
        fencing = out["fencing_token"]
        attempt_id = out["attempt_id"]
        # Gate 05: completion barrier — post the 05.12 plan's records.
        post_plan_records(self, lambda p, b: self.api.call("POST", p, b), uid,
                          attempt_id, fencing, "w1", "05.12")
        _, out = self.api.call("POST", f"/units/{uid}/complete",
                               {"worker_id": "w1", "fencing_token": fencing,
                                "artifact_type": "story_architecture",
                                "content": "gate-e contract content",
                                "storage_uri": "local://gatee",
                                "actual_cost_cents": 90})
        self.assertEqual(out["state"], "VALIDATING")
        return uid

    def test_evaluations_all_pass_accepted(self):
        uid = self.validating_unit("e-pass")
        status, out = self.api.call("POST", f"/units/{uid}/validate", {
            "evaluations": [
                {"validator": "schema_validation", "method": "json_schema_subset",
                 "verdict": "PASS", "deterministic": True, "evidence": {"violations": []}},
                {"validator": "deterministic_checks", "method": "technical_checks",
                 "verdict": "PASS", "deterministic": True, "evidence": {}},
                {"validator": "continuity_checks", "method": "continuity",
                 "verdict": "PASS", "evidence": {}}]})
        self.assertEqual(status, 200)
        self.assertEqual(out["state"], "ACCEPTED")

    def test_evaluations_deterministic_fail_blocked(self):
        uid = self.validating_unit("e-det-fail")
        status, out = self.api.call("POST", f"/units/{uid}/validate", {
            "evaluations": [
                {"validator": "schema_validation", "method": "json_schema_subset",
                 "verdict": "FAIL", "deterministic": True,
                 "evidence": {"violations": [{"path": "$", "message": "missing 'evidence'"}]}},
                {"validator": "continuity_checks", "method": "continuity",
                 "verdict": "PASS", "evidence": {}}]})
        self.assertEqual(status, 200)
        self.assertEqual(out["state"], "BLOCKED")

    def test_evaluations_content_fail_repair_required(self):
        uid = self.validating_unit("e-content-fail")
        status, out = self.api.call("POST", f"/units/{uid}/validate", {
            "evaluations": [
                {"validator": "continuity_checks", "method": "continuity",
                 "verdict": "FAIL", "deterministic": False,
                 "evidence": {"problems": ["planned inputs no longer CURRENT"]}}]})
        self.assertEqual(status, 200)
        self.assertEqual(out["state"], "REPAIR_REQUIRED")

    def test_evaluations_review_required_awaits_human(self):
        uid = self.validating_unit("e-review")
        status, out = self.api.call("POST", f"/units/{uid}/validate", {
            "evaluations": [
                {"validator": "semantic_evaluation", "method": "qa_binding",
                 "verdict": "REVIEW_REQUIRED",
                 "evidence": {"calibration": "NOT_ARMED", "expert_cases": 0}}]})
        self.assertEqual(status, 200)
        self.assertEqual(out["state"], "AWAITING_HUMAN")

    def test_evaluations_bad_verdict_400(self):
        uid = self.validating_unit("e-bad")
        status, _ = self.api.call("POST", f"/units/{uid}/validate", {
            "evaluations": [{"validator": "x", "verdict": "MAYBE"}]})
        self.assertEqual(status, 400)

    def test_legacy_single_verdict_unchanged(self):
        uid = self.validating_unit("e-legacy-pass")
        status, out = self.api.call("POST", f"/units/{uid}/validate", {"verdict": "PASS"})
        self.assertEqual(status, 200)
        self.assertEqual(out["state"], "ACCEPTED")
        uid = self.validating_unit("e-legacy-fail")
        status, out = self.api.call("POST", f"/units/{uid}/validate",
                                    {"verdict": "FAIL", "deterministic": True})
        self.assertEqual(status, 200)
        self.assertEqual(out["state"], "BLOCKED")


GATEG_DB, GATEE_PORT_G = "g3_gateg_scratch", 8747


class TestApiGateG(unittest.TestCase):
    """Gate G (Part D): unit evaluations + provider-jobs reads, planned
    input refs on the units list, lease fields on attempts."""

    @classmethod
    def setUpClass(cls):
        cls.proc, cls.api = start_server(GATEG_DB, GATEE_PORT_G,
                                         env_extra=ROLE_ENV)

    @classmethod
    def tearDownClass(cls):
        stop_server(cls.proc)

    def setUp(self):
        _, out = self.api.call("POST", "/productions",
                               {"title": "Gate G HTTP", "hard_ceiling_cents": 1000000,
                                "soft_ceiling_cents": 900000})
        self.pid = out["production_id"]
        _, out = self.api.call("POST", f"/productions/{self.pid}/runs",
                               {"kind": "FULL"})
        self.run = out["run_id"]

    def plan(self, op, key, inputs=()):
        _, out = self.api.call("POST", f"/productions/{self.pid}/units",
                               {"operation_id": op, "run_id": self.run,
                                "unit_key": key,
                                "input_artifact_ids": list(inputs)})
        return out["unit_id"]

    def test_units_list_carries_input_refs(self):
        _, art = self.api.call("POST", f"/productions/{self.pid}/artifacts",
                               {"artifact_type": "canon_manifest",
                                "content": "canon", "storage_uri": "local://c"})
        uid = self.plan("05.12", "refs", inputs=[art["artifact_id"]])
        _, out = self.api.call("GET", f"/productions/{self.pid}/units")
        row = [u for u in out["units"] if u["unit_id"] == uid][0]
        self.assertEqual(row["input_artifact_ids"], [art["artifact_id"]])
        ref = row["input_artifacts"][0]
        self.assertEqual(ref["artifact_type"], "canon_manifest")
        self.assertEqual(ref["sha256"], art["sha256"])
        # the artifact row's recorded URI (bytes are in the Gate D
        # store by sha regardless — coordinator.register_artifact)
        self.assertEqual(ref["storage_uri"], "local://c")

    def test_attempts_carry_lease_fields(self):
        uid = self.plan("01.01", "lease")
        _, claim = self.api.call("POST", f"/units/{uid}/claim",
                                 {"worker_id": "w-lease"})
        _, out = self.api.call("GET", f"/units/{uid}/attempts")
        cur = [a for a in out["attempts"] if a["attempt_no"] == 1][0]
        self.assertIsNotNone(cur["lease_expires_at"])
        self.assertEqual(cur["lease_worker_id"], "w-lease")

    def test_adopt_endpoint_issues_credentials(self):
        # Master Execution Programme Gate 02: the attempts read must NOT
        # expose the fencing token; POST /units/{id}/adopt is the only
        # credential disclosure, gated on identity match, atomic and
        # idempotent per key.
        uid = self.plan("01.01", "resume")
        _, claim = self.api.call("POST", f"/units/{uid}/claim",
                                 {"worker_id": "n8n-executor-g4"})
        _, out = self.api.call("GET", f"/units/{uid}/attempts")
        cur = [a for a in out["attempts"] if a["attempt_no"] == 1][0]
        self.assertNotIn("fencing_token", cur)
        self.assertEqual(cur["worker_id"], "n8n-executor-g4")
        worker = role_headers("WORKER")
        body = {"worker_id": "n8n-executor-g5",
                "attempt_id": claim["attempt_id"], "idempotency_key": "g-1"}
        status, _ = self.api.call("POST", f"/units/{uid}/adopt", body,
                                  token=None, headers=worker)
        self.assertEqual(status, 409)  # identity mismatch
        body["worker_id"] = "n8n-executor-g4"
        status, out = self.api.call("POST", f"/units/{uid}/adopt", body,
                                    token=None, headers=worker)
        self.assertEqual(status, 200)
        self.assertEqual(out["fencing_token"], claim["fencing_token"])
        self.assertEqual(out["resolved_config_hash"],
                         cur["resolved_config_hash"])
        self.assertTrue(out["fresh"])
        status, out = self.api.call("POST", f"/units/{uid}/adopt", body,
                                    token=None, headers=worker)
        self.assertEqual(status, 200)
        self.assertFalse(out["fresh"])  # idempotent replay, same adoption
        body["idempotency_key"] = "g-2"
        status, _ = self.api.call("POST", f"/units/{uid}/adopt", body,
                                  token=None, headers=worker)
        self.assertEqual(status, 409)  # already adopted under another key

    def test_evaluations_read(self):
        uid = self.plan("05.12", "evals")
        _, claim = self.api.call("POST", f"/units/{uid}/claim",
                                 {"worker_id": "w1"})
        # Gate 05: completion barrier — post the 05.12 plan's records.
        post_plan_records(self, lambda p, b: self.api.call("POST", p, b), uid,
                          claim["attempt_id"], claim["fencing_token"], "w1",
                          "05.12")
        self.api.call("POST", f"/units/{uid}/complete",
                      {"worker_id": "w1", "fencing_token": claim["fencing_token"],
                       "artifact_type": "story_architecture", "content": "x",
                       "actual_cost_cents": 90})
        self.api.call("POST", f"/units/{uid}/validate", {"evaluations": [
            {"validator": "schema_validation", "method": "m", "verdict": "PASS",
             "evaluator": "evaluation-service", "evidence": {}},
            {"validator": "deterministic_checks", "method": "m",
             "verdict": "PASS", "evaluator": "evaluation-service",
             "evidence": {}}]})
        status, out = self.api.call("GET", f"/units/{uid}/evaluations")
        self.assertEqual(status, 200)
        self.assertEqual([e["validator_id"] for e in out["evaluations"]],
                         ["schema_validation", "deterministic_checks"])
        status, _ = self.api.call(
            "GET", "/units/00000000-0000-0000-0000-000000000000/evaluations")
        self.assertEqual(status, 404)

    def test_provider_jobs_read(self):
        uid = self.plan("11.06", "jobs")
        _, claim = self.api.call("POST", f"/units/{uid}/claim",
                                 {"worker_id": "w1"})
        # job submission requires the unit RUNNING (claim -> start);
        # Gate 05: start is WORKER-class, fired by the claim's worker.
        status, _ = self.api.call("POST", f"/units/{uid}/events",
                                  {"event": "start", "worker_id": "w1"},
                                  token=None, headers=role_headers("WORKER"))
        self.assertEqual(status, 200)
        _, attempts = self.api.call("GET", f"/units/{uid}/attempts")
        attempt_id = attempts["attempts"][0]["attempt_id"]
        status, job = self.api.call(
            "POST", "/provider-jobs",
            {"unit_id": uid, "attempt_id": attempt_id,
             "fencing_token": claim["fencing_token"],
             "idempotency_key": f"gate-g-test-{uid}"},
            headers=role_headers("WORKER"))
        self.assertEqual(status, 201)
        status, out = self.api.call("GET", f"/units/{uid}/provider-jobs")
        self.assertEqual(status, 200)
        self.assertEqual(len(out["provider_jobs"]), 1)
        self.assertEqual(out["provider_jobs"][0]["job_id"], job["job_id"])
        self.assertEqual(out["provider_jobs"][0]["status"], "SUBMITTED")
        # CALLBACK is not a read role
        status, _ = self.api.call("GET", f"/units/{uid}/provider-jobs",
                                  token=None,
                                  headers=role_headers("CALLBACK"))
        self.assertEqual(status, 403)
        status, _ = self.api.call(
            "GET", "/units/00000000-0000-0000-0000-000000000000/provider-jobs")
        self.assertEqual(status, 404)


if __name__ == "__main__":
    unittest.main(verbosity=2)
