"""MM-08 API tests: POST /financial-evidence/{evidence_id}/resolve.

The UNRESOLVED fixture row is created with in-process Coordinator calls
against the fixture DB (the same construction the coordinator suite
proves); every assertion about the endpoint itself is over HTTP:
OPERATOR resolves, WORKER is refused 403, duplicate resolution is 409,
empty resolution is 409, unknown evidence is 404, and the response
carries exactly the contract keys (contract 1.10.0).
"""
import os
import re
import sys
import unittest
from pathlib import Path

import psycopg
from psycopg.rows import dict_row

ROOT = Path(__file__).resolve().parent.parent
G2 = Path.home() / "workspace/video-factory-g2"
sys.path.insert(0, str(ROOT / "tests"))
sys.path.insert(0, str(G2 / "coordinator"))

from server_fixture import make_dsn, start_server, stop_server  # noqa: E402

DB, PORT = "g3_mm08_scratch", 8746
ENV = {"FACTORY_WORKER_TOKEN": "mm08-worker-token",
       "FACTORY_STORAGE_ROOT": "/tmp/g3-mm08-storage"}
DSN = make_dsn(DB)

from coordinator import Coordinator  # noqa: E402


def raw():
    return psycopg.connect(DSN, row_factory=dict_row, autocommit=True)


class TestResolveEndpoint(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.proc, cls.api = start_server(DB, PORT, env_extra=ENV)

    @classmethod
    def tearDownClass(cls):
        stop_server(cls.proc)

    def setUp(self):
        # fixture: a credentialed-provider attempt completed with no
        # usage at all -> UNRESOLVED charge (MM-08 detection)
        c = Coordinator(DSN)
        with raw() as conn:
            conn.execute(
                "INSERT INTO provider_configs(scope, operation_id, environment,"
                " provider, model, est_cost_cents, credential_ref, created_by)"
                " VALUES ('OPERATION','01.02','test','cred-provider','m1',100,"
                " 'SOME_KEY','mm08-api-test')")
            conn.execute(
                "INSERT INTO pricing_rules(provider, model, unit_kind,"
                " unit_price_cents, pricing_version, created_by) VALUES"
                " ('cred-provider','m1','input_token',1.0,'mm08-api-1',"
                " 'mm08-api-test')")
        self.pid = c.create_production("MM-08 API", 100000, 90000, "mm08-api")
        run = c.start_run(self.pid, "FULL", "mm08-api")
        uid = c.plan_unit(self.pid, run, "01.02", "main")
        claim = c.claim(uid, "w-api", 100)
        c.complete_attempt(uid, "w-api", claim["fencing_token"],
                           "research_brief", b"content", "local://d", 100,
                           usage=None)
        with raw() as conn:
            self.unres = conn.execute(
                "SELECT evidence_id FROM financial_evidence"
                " WHERE attempt_id=%s AND charge_class='UNRESOLVED'",
                (claim["attempt_id"],)).fetchone()["evidence_id"]
        c.close()

    def tearDown(self):
        with raw() as conn:
            conn.execute("UPDATE provider_configs SET active=false"
                         " WHERE created_by='mm08-api-test'")
            conn.execute("DELETE FROM pricing_rules"
                         " WHERE created_by='mm08-api-test'")

    def worker_post(self, path, body):
        # positional None token: authenticate ONLY as the WORKER role
        return self.api.call("POST", path, body, None,
                             headers={"X-Role": "WORKER",
                                      "X-Role-Token": "mm08-worker-token",
                                      "X-Identity": "worker-service"})

    def test_worker_role_refused_403(self):
        status, _ = self.worker_post(
            f"/financial-evidence/{self.unres}/resolve",
            {"usage": {"input_tokens": 40}})
        self.assertEqual(status, 403)
        with raw() as conn:
            flag = conn.execute(
                "SELECT requires_reconciliation FROM financial_evidence"
                " WHERE evidence_id=%s", (self.unres,)).fetchone()
        self.assertTrue(flag["requires_reconciliation"])

    def test_operator_resolves_with_contract_keys(self):
        status, out = self.api.call(
            "POST", f"/financial-evidence/{self.unres}/resolve",
            {"usage": {"input_tokens": 40}})
        self.assertEqual(status, 200, str(out))
        self.assertEqual(out["evidence_id"], str(self.unres))
        self.assertEqual(out["production_id"], str(self.pid))
        self.assertEqual(out["amount_cents"], 40)
        self.assertEqual(out["basis"], "calculated")
        with raw() as conn:
            res = conn.execute(
                "SELECT r.state, r.settled_cents FROM budget_reservations r"
                " JOIN action_attempts a ON a.reservation_id=r.reservation_id"
                " JOIN financial_evidence e ON e.attempt_id=a.attempt_id"
                " WHERE e.evidence_id=%s", (self.unres,)).fetchone()
        self.assertEqual((res["state"], res["settled_cents"]), ("SETTLED", 40))

    def test_duplicate_resolution_refused_409(self):
        status, _ = self.api.call(
            "POST", f"/financial-evidence/{self.unres}/resolve",
            {"reported_cost_cents": 33})
        self.assertEqual(status, 200)
        status, _ = self.api.call(
            "POST", f"/financial-evidence/{self.unres}/resolve",
            {"reported_cost_cents": 33})
        self.assertEqual(status, 409)

    def test_empty_resolution_refused_409(self):
        status, _ = self.api.call(
            "POST", f"/financial-evidence/{self.unres}/resolve", {})
        self.assertEqual(status, 409)

    def test_unknown_evidence_404(self):
        status, _ = self.api.call(
            "POST",
            "/financial-evidence/00000000-0000-0000-0000-000000000000/resolve",
            {"reported_cost_cents": 1})
        self.assertEqual(status, 404)


if __name__ == "__main__":
    unittest.main()
