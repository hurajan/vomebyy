"""Dashboard checks (no browser needed):
- the served page contains all nine section views from A-Z §13,
- the inline JS parses under node's parser,
- every API call the page makes exists in contracts/api_contract.json."""
import json
import re
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from server_fixture import start_server, stop_server  # noqa: E402

DB, PORT = "g3_dashboard_test_scratch", 8743
ROOT = Path(__file__).resolve().parent.parent
VIEWS = ["intake", "productions", "tracker", "operations", "models",
         "units", "artifacts", "gates", "approvals", "finance", "quality",
         "repair", "configs", "pricing", "system"]


def normalize(path):
    path = re.sub(r"\$\{[^}]+\}", "{}", path)
    path = re.sub(r"\{[^}]+\}", "{}", path)
    return re.sub(r"\?.*$", "", path)


class TestDashboard(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.proc, cls.api = start_server(DB, PORT)
        status, cls.html = cls.api.get_text("/")
        assert status == 200

    @classmethod
    def tearDownClass(cls):
        stop_server(cls.proc)

    def test_all_views_present(self):
        for v in VIEWS:
            self.assertIn(f'id="view-{v}"', self.html, f"missing view {v}")
            self.assertIn(f'data-view="{v}"', self.html, f"missing tab {v}")

    def test_gate_g_unit_detail_and_views(self):
        # Gate G (Part D): unit detail shows attempts with the resolved
        # config, provider jobs, QA verdicts, FINALIZED cost, retry +
        # cancel actions; finance shows the soft-ceiling flag; the
        # configs + pricing views carry create forms.
        for marker in ('id="attemptRows"', 'id="jobRows"', 'id="evalRows"',
                       'id="unitCost"', 'id="unitActions"', "unitRetry",
                       "unitCancel", 'id="softCrossed"', 'id="configRows"',
                       'id="cfgCreateBtn"', 'id="pricingRows"',
                       'id="priceCreateBtn"'):
            self.assertIn(marker, self.html, f"missing Gate G element {marker}")

    def test_js_parses(self):
        scripts = re.findall(r"<script>(.*?)</script>", self.html, re.S)
        self.assertEqual(len(scripts), 1)
        with tempfile.NamedTemporaryFile("w", suffix=".js", delete=False) as f:
            f.write(scripts[0])
            name = f.name
        r = subprocess.run(["node", "--check", name], capture_output=True, text=True)
        self.assertEqual(r.returncode, 0, f"node --check failed: {r.stderr}")

    def test_ui_calls_exist_in_contract(self):
        contract = json.loads((ROOT / "contracts" / "api_contract.json").read_text())
        allowed = {(ep["method"], normalize(ep["path"])) for ep in contract["endpoints"]}
        calls = re.findall(r'api\("([A-Z]+)",\s*(`[^`]*`|"[^"]*")', self.html)
        self.assertGreaterEqual(len(calls), 12)
        for method, raw in calls:
            path = raw.strip("`\"")
            # template literals with expressions already handled by normalize;
            # string concatenation via ${...} inside backticks only.
            key = (method, normalize(path))
            self.assertIn(key, allowed, f"UI calls {method} {path} — not in contract")


if __name__ == "__main__":
    unittest.main(verbosity=2)
