"""Gate 05 (Master Execution Programme) API battery:

- D07 per-event authorization (G01-D07): the inverted Phase 3 repro —
  a WORKER (or SCHEDULER) token firing human_approved / any
  validation-class event is refused 403 with a committed event_refused
  audit row and the unit's state unchanged; the OPERATOR human path
  stays green end to end; worker-class events (start, transient_error)
  bind the body's worker_id to the attempt's claim identity.
- Completion barrier: /complete refuses (409 + completion_barrier_
  refused audit) until every action of the attempt's pinned plan has a
  terminal SUCCEEDED record — missing, FAILED and REFUSED records all
  fail the barrier; a fully-evidenced completion succeeds.
- Action-record trust: POST /units/{uid}/actions requires the attempt's
  worker_id (mismatch -> 403 + action_record_refused audit; missing ->
  400; a record addressed to another unit's attempt -> 409); replays
  are idempotent (exactly-once).
"""
import json
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from server_fixture import make_dsn, start_server, stop_server  # noqa: E402
import psycopg  # noqa: E402
from psycopg.rows import dict_row  # noqa: E402

DB, PORT = "g3_gate05_scratch", 8751
DSN = make_dsn(DB)
ENV = {"FACTORY_WORKER_TOKEN": "g05-worker-token",
       "FACTORY_SCHEDULER_TOKEN": "g05-scheduler-token",
       "FACTORY_VALIDATOR_TOKEN": "g05-validator-token",
       "FACTORY_CALLBACK_TOKEN": "g05-callback-token"}

PLANS_PATH = (Path(__file__).resolve().parents[2] / "video-factory-g1"
              / "seed-definitions" / "workflow-1.0.0" / "plans.json")
PLANS = {p["operation_id"]: p
         for p in json.loads(PLANS_PATH.read_text())["plans"]}
UNBOUND_OP = next(op for op in sorted(PLANS)
                  if any(a["binding_status"] == "UNBOUND"
                         for a in PLANS[op]["actions"]))


def role_headers(role, identity=None):
    h = {"X-Role": role, "X-Role-Token": ENV[f"FACTORY_{role}_TOKEN"]}
    if identity:
        h["X-Identity"] = identity
    return h


def audit(unit_id, event_type):
    with psycopg.connect(DSN, row_factory=dict_row, autocommit=True) as conn:
        return conn.execute(
            "SELECT * FROM audit_events WHERE unit_id=%s AND event_type=%s"
            " ORDER BY created_at", (unit_id, event_type)).fetchall()


class TestGate05Api(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.proc, cls.api = start_server(DB, PORT, env_extra=ENV)

    @classmethod
    def tearDownClass(cls):
        stop_server(cls.proc)

    def setUp(self):
        _, out = self.api.call("POST", "/productions",
                               {"title": "Gate05", "hard_ceiling_cents": 1000000,
                                "soft_ceiling_cents": 900000})
        self.pid = out["production_id"]
        _, out = self.api.call("POST", f"/productions/{self.pid}/runs",
                               {"kind": "FULL"})
        self.run = out["run_id"]

    # ------------------------------------------------------------ helpers
    def role(self, role, method, path, body=None, identity=None):
        return self.api.call(method, path, body, token=None,
                             headers=role_headers(role, identity))

    def plan(self, op, key="main"):
        _, out = self.api.call("POST", f"/productions/{self.pid}/units",
                               {"operation_id": op, "run_id": self.run,
                                "unit_key": key})
        return out["unit_id"]

    def claim(self, uid, worker="w1"):
        status, out = self.api.call("POST", f"/units/{uid}/claim",
                                    {"worker_id": worker, "estimated_cents": 100})
        self.assertEqual(status, 200, out)
        return out

    def state(self, uid):
        _, out = self.api.call("GET", f"/productions/{self.pid}/units")
        return [u for u in out["units"] if u["unit_id"] == uid][0]["state"]

    def record(self, uid, claim, action, status="SUCCEEDED", worker="w1",
               role="WORKER"):
        return self.role(role, "POST", f"/units/{uid}/actions",
                         {"attempt_id": claim["attempt_id"],
                          "fencing_token": claim["fencing_token"],
                          "worker_id": worker, "action_key": action["action_key"],
                          "seq": action["seq"], "status": status},
                         identity=worker)

    def record_plan(self, uid, claim, op, worker="w1", skip=(), overrides=None):
        overrides = overrides or {}
        for a in PLANS[op]["actions"]:
            if a["action_key"] in skip:
                continue
            st, out = self.record(uid, claim, a,
                                  status=overrides.get(a["action_key"],
                                                       "SUCCEEDED"),
                                  worker=worker)
            self.assertIn(st, (200, 201), f"{a['action_key']}: {st} {out}")

    def complete(self, uid, claim, worker="w1"):
        return self.api.call("POST", f"/units/{uid}/complete",
                             {"worker_id": worker,
                              "fencing_token": claim["fencing_token"],
                              "artifact_type": "generic_artifact",
                              "content": "gate05", "storage_uri": "local://g05",
                              "actual_cost_cents": 90})

    def drive_awaiting_human(self, op="01.01", worker="w1"):
        uid = self.plan(op)
        claim = self.claim(uid, worker)
        self.record_plan(uid, claim, op, worker=worker)
        st, out = self.complete(uid, claim, worker)
        self.assertEqual(st, 200, out)
        st, out = self.api.call("POST", f"/units/{uid}/validate",
                                {"verdict": "REVIEW_REQUIRED"})
        self.assertEqual(st, 200, out)
        self.assertEqual(out["state"], "AWAITING_HUMAN")
        return uid

    # ------------------------------------------------------------- D07
    def test_worker_and_scheduler_cannot_approve_humans(self):
        # The inverted Phase 3 repro: pre-Gate-05 a WORKER token fired
        # validation_needs_human + human_approved and drove its own
        # unit to ACCEPTED.
        uid = self.drive_awaiting_human()
        for role in ("WORKER", "SCHEDULER"):
            for ev in ("validation_needs_human", "human_approved"):
                st, _ = self.role(role, "POST", f"/units/{uid}/events",
                                  {"event": ev, "worker_id": "w1"})
                self.assertEqual(st, 403, f"{role} {ev}")
                self.assertEqual(self.state(uid), "AWAITING_HUMAN")
        rows = audit(uid, "event_refused")
        self.assertEqual(len(rows), 4)
        reasons = {(r["payload"]["event"], r["payload"]["reason"])
                   for r in rows}
        self.assertIn(("human_approved", "role_not_authorized"), reasons)
        self.assertIn(("validation_needs_human", "event_not_fireable_via_api"),
                      reasons)
        self.assertEqual({r["actor"] for r in rows},
                         {"worker:worker", "scheduler:scheduler"})
        # the OPERATOR human path stays green, and the acceptance is
        # policy-stamped (G01-D06)
        st, out = self.api.call("POST", f"/units/{uid}/events",
                                {"event": "human_approved"})
        self.assertEqual(st, 200)
        self.assertEqual(out["state"], "ACCEPTED")
        rows = audit(uid, "approval_policy_applied")
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]["payload"]["approval_policy"],
                         "PRODUCER_AND_BUDGET_OWNER")
        self.assertEqual(rows[0]["payload"]["mechanism"], "human_approved")
        self.assertTrue(rows[0]["payload"]["human_satisfied_by"]
                        .startswith("operator:"))

    def test_internal_events_refused_for_every_role(self):
        uid = self.plan("01.01")
        for ev in ("validation_passed", "validation_failed_content",
                   "validation_failed_deterministic", "submit_candidate",
                   "claim", "await_provider", "provider_resumed",
                   "provider_unknown", "reconciled_submitted",
                   "reconciled_failed", "retry_ready", "not_a_real_event"):
            st, _ = self.api.call("POST", f"/units/{uid}/events",
                                  {"event": ev})
            self.assertEqual(st, 403, f"OPERATOR {ev}")
            self.assertEqual(self.state(uid), "READY")
        rows = audit(uid, "event_refused")
        self.assertEqual(len(rows), 12)
        self.assertTrue(all(r["payload"]["reason"] ==
                            "event_not_fireable_via_api" for r in rows))
        # VALIDATOR holds no event rights either
        st, _ = self.role("VALIDATOR", "POST", f"/units/{uid}/events",
                          {"event": "human_approved"})
        self.assertEqual(st, 403)
        # unknown unit: 404 before any audit row can exist
        st, _ = self.api.call(
            "POST", "/units/00000000-0000-0000-0000-000000000000/events",
            {"event": "cancel"})
        self.assertEqual(st, 404)

    def test_cancel_is_operator_only(self):
        uid = self.plan("01.02")
        for role in ("WORKER", "SCHEDULER", "VALIDATOR", "CALLBACK"):
            st, _ = self.role(role, "POST", f"/units/{uid}/events",
                              {"event": "cancel", "worker_id": "w1"})
            self.assertEqual(st, 403, role)
            self.assertEqual(self.state(uid), "READY")
        st, out = self.api.call("POST", f"/units/{uid}/events",
                                {"event": "cancel"})
        self.assertEqual(st, 200)
        self.assertEqual(out["state"], "CANCELLED")

    def test_transient_error_identity_binding(self):
        uid = self.plan("01.03")
        self.claim(uid, "w-claim")
        # OPERATOR may not fire a worker-class event at all
        st, _ = self.api.call("POST", f"/units/{uid}/events",
                              {"event": "transient_error",
                               "worker_id": "w-claim"})
        self.assertEqual(st, 403)
        # WORKER without the identity -> refused
        st, _ = self.role("WORKER", "POST", f"/units/{uid}/events",
                          {"event": "transient_error"})
        self.assertEqual(st, 403)
        # WORKER with a different identity -> refused
        st, _ = self.role("WORKER", "POST", f"/units/{uid}/events",
                          {"event": "transient_error", "worker_id": "other"})
        self.assertEqual(st, 403)
        # SCHEDULER fires no events, identity or not
        st, _ = self.role("SCHEDULER", "POST", f"/units/{uid}/events",
                          {"event": "transient_error", "worker_id": "w-claim"})
        self.assertEqual(st, 403)
        self.assertEqual(self.state(uid), "CLAIMED")
        reasons = [r["payload"]["reason"] for r in audit(uid, "event_refused")]
        self.assertEqual(reasons, ["role_not_authorized",
                                   "worker_identity_required",
                                   "identity_mismatch",
                                   "role_not_authorized"])
        # the claiming worker itself -> green (the executor error path)
        st, out = self.role("WORKER", "POST", f"/units/{uid}/events",
                            {"event": "transient_error",
                             "worker_id": "w-claim"}, identity="w-claim")
        self.assertEqual(st, 200)
        self.assertEqual(out["state"], "RETRY_WAIT")

    def test_start_identity_binding(self):
        uid = self.plan("01.04")
        self.claim(uid, "w-claim")
        st, _ = self.api.call("POST", f"/units/{uid}/events",
                              {"event": "start", "worker_id": "w-claim"})
        self.assertEqual(st, 403)  # OPERATOR may not start
        st, _ = self.role("WORKER", "POST", f"/units/{uid}/events",
                          {"event": "start", "worker_id": "other"})
        self.assertEqual(st, 403)
        st, out = self.role("WORKER", "POST", f"/units/{uid}/events",
                            {"event": "start", "worker_id": "w-claim"},
                            identity="w-claim")
        self.assertEqual(st, 200)
        self.assertEqual(out["state"], "RUNNING")

    def test_block_dual_class(self):
        # block is dual-class: an OPERATOR action, and the executor's
        # rights-block failure signal (G4 Station-2 'Prepare block
        # report' -> error handler, error_class RIGHTS_BLOCKED). The
        # composed rights flow fires it PRE-CLAIM from READY (the unit
        # was never claimed — the transition table has block only from
        # READY/PENDING/RETRY_WAIT), so the worker-side binding is the
        # executor entitlement for the unit's operation.
        uid = self.plan("02.01", "blk-worker")  # step 02 -> executor g4
        st, _ = self.role("SCHEDULER", "POST", f"/units/{uid}/events",
                          {"event": "block", "worker_id": "n8n-executor-g4"})
        self.assertEqual(st, 403)  # SCHEDULER fires nothing
        st, _ = self.role("WORKER", "POST", f"/units/{uid}/events",
                          {"event": "block", "worker_id": "w-rights"})
        self.assertEqual(st, 403)  # not the entitled executor identity
        self.assertEqual(self.state(uid), "READY")
        st, out = self.role("WORKER", "POST", f"/units/{uid}/events",
                            {"event": "block", "worker_id": "n8n-executor-g4"},
                            identity="n8n-executor-g4")
        self.assertEqual(st, 200)
        self.assertEqual(out["state"], "BLOCKED")
        # the operator path needs no worker identity
        uid2 = self.plan("02.02", "blk-operator")
        st, out = self.api.call("POST", f"/units/{uid2}/events",
                                {"event": "block"})
        self.assertEqual(st, 200)
        self.assertEqual(out["state"], "BLOCKED")
        # authorization does not manufacture transitions: block from
        # CLAIMED does not exist in the table, for any identity
        uid3 = self.plan("02.03", "blk-claimed")
        self.claim(uid3, "w1")
        st, _ = self.role("WORKER", "POST", f"/units/{uid3}/events",
                          {"event": "block", "worker_id": "w1"})
        self.assertEqual(st, 409)
        self.assertEqual(self.state(uid3), "CLAIMED")

    # ----------------------------------------------------------- barrier
    def test_barrier_battery(self):
        # no records at all -> refused; nothing registered or settled
        uid = self.plan("05.12", "b-none")
        claim = self.claim(uid)
        st, _ = self.complete(uid, claim)
        self.assertEqual(st, 409)
        self.assertEqual(self.state(uid), "CLAIMED")
        rows = audit(uid, "completion_barrier_refused")
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]["payload"]["reason"], "missing_records")
        # all but one -> still refused, naming the missing action
        actions = PLANS["05.12"]["actions"]
        self.record_plan(uid, claim, "05.12", skip={actions[-1]["action_key"]})
        st, _ = self.complete(uid, claim)
        self.assertEqual(st, 409)
        rows = audit(uid, "completion_barrier_refused")
        self.assertEqual(rows[-1]["payload"]["missing"],
                         [actions[-1]["action_key"]])
        # the final record -> completion succeeds
        st, out = self.record(uid, claim, actions[-1])
        self.assertIn(st, (200, 201))
        st, out = self.complete(uid, claim)
        self.assertEqual(st, 200, out)
        self.assertEqual(out["state"], "VALIDATING")
        # duplicate completion: refused by state/fencing, exactly one
        # artifact and one CHARGE (no double settlement)
        st, _ = self.complete(uid, claim)
        self.assertIn(st, (400, 409))
        _, budget = self.api.call("GET", f"/productions/{self.pid}/budget")
        self.assertEqual(budget["spent_cents"], 90)

    def test_barrier_failed_and_refused_records(self):
        # a FAILED record fails the barrier
        uid = self.plan("05.12", "b-failed")
        claim = self.claim(uid)
        first = PLANS["05.12"]["actions"][0]
        self.record_plan(uid, claim, "05.12",
                         overrides={first["action_key"]: "FAILED"})
        st, _ = self.complete(uid, claim)
        self.assertEqual(st, 409)
        rows = audit(uid, "completion_barrier_refused")
        self.assertEqual(rows[-1]["payload"]["reason"],
                         "actions_not_succeeded")
        # a REFUSED record (UNBOUND action) fails the barrier: an
        # operation with an unbound action can never complete via the
        # API — the explicit post-Gate-04 failure mode
        uid2 = self.plan(UNBOUND_OP, "b-refused")
        claim2 = self.claim(uid2)
        unbound = [a for a in PLANS[UNBOUND_OP]["actions"]
                   if a["binding_status"] == "UNBOUND"]
        overrides = {a["action_key"]: "REFUSED" for a in unbound}
        self.record_plan(uid2, claim2, UNBOUND_OP, overrides=overrides)
        st, _ = self.complete(uid2, claim2)
        self.assertEqual(st, 409)
        rows = audit(uid2, "completion_barrier_refused")
        self.assertEqual({n["action_key"] for n in
                          rows[-1]["payload"]["not_succeeded"]},
                         {a["action_key"] for a in unbound})
        self.assertTrue(all(n["status"] == "REFUSED" for n in
                            rows[-1]["payload"]["not_succeeded"]))

    # -------------------------------------------------- action-record trust
    def test_action_record_identity_binding(self):
        uid = self.plan("01.01", "a-bind")
        claim = self.claim(uid, "w-owner")
        action = PLANS["01.01"]["actions"][0]
        # another worker's identity -> 403 + audit, nothing recorded
        st, _ = self.record(uid, claim, action, worker="intruder")
        self.assertEqual(st, 403)
        rows = audit(uid, "action_record_refused")
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]["payload"]["presented_worker_id"], "intruder")
        self.assertEqual(rows[0]["payload"]["attempt_worker_id"], "w-owner")
        with psycopg.connect(DSN, autocommit=True) as conn:
            n = conn.execute("SELECT count(*) FROM plan_action_attempts"
                             " WHERE unit_id=%s", (uid,)).fetchone()[0]
        self.assertEqual(n, 0)
        # missing worker_id -> 400 (contract: required field)
        st, _ = self.role("WORKER", "POST", f"/units/{uid}/actions",
                          {"attempt_id": claim["attempt_id"],
                           "fencing_token": claim["fencing_token"],
                           "action_key": action["action_key"],
                           "seq": action["seq"], "status": "SUCCEEDED"})
        self.assertEqual(st, 400)
        # the claim's identity -> 201; replay -> 200 recorded=false
        st, out = self.record(uid, claim, action, worker="w-owner")
        self.assertEqual(st, 201)
        self.assertTrue(out["recorded"])
        st, out = self.record(uid, claim, action, worker="w-owner")
        self.assertEqual(st, 200)
        self.assertFalse(out["recorded"])

    def test_action_record_for_another_attempt_refused(self):
        # a record addressed to unit B carrying unit A's attempt id is
        # refused (the attempt does not belong to the unit)
        uid_a = self.plan("01.01", "a-a")
        claim_a = self.claim(uid_a, "w1")
        uid_b = self.plan("01.02", "a-b")
        claim_b = self.claim(uid_b, "w1")
        action = PLANS["01.02"]["actions"][0]
        st, _ = self.role("WORKER", "POST", f"/units/{uid_b}/actions",
                          {"attempt_id": claim_a["attempt_id"],
                           "fencing_token": claim_b["fencing_token"],
                           "worker_id": "w1", "action_key": action["action_key"],
                           "seq": action["seq"], "status": "SUCCEEDED"})
        self.assertEqual(st, 409)
        with psycopg.connect(DSN, autocommit=True) as conn:
            n = conn.execute("SELECT count(*) FROM plan_action_attempts"
                             " WHERE unit_id=%s", (uid_b,)).fetchone()[0]
        self.assertEqual(n, 0)


if __name__ == "__main__":
    unittest.main(verbosity=2)
