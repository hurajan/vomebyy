"""Shared fixture: fresh scratch DB + real API server subprocess per test class."""
import json
import os
import subprocess
import sys
import time
import urllib.request
import urllib.error
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
PY = str(ROOT / ".venv" / "bin" / "python")
TOKEN = "dev-operator-token"


def make_dsn(db):
    return f"host=127.0.0.1 dbname={db} user=factory password=factory_dev_local"


class Client:
    def __init__(self, port):
        self.base = f"http://127.0.0.1:{port}"

    def call(self, method, path, body=None, token=TOKEN, headers=None):
        req = urllib.request.Request(self.base + path, method=method)
        if token is not None:
            req.add_header("X-Operator-Token", token)
        for k, v in (headers or {}).items():
            req.add_header(k, v)
        data = None
        if body is not None:
            data = json.dumps(body).encode()
            req.add_header("Content-Type", "application/json")
        try:
            with urllib.request.urlopen(req, data=data, timeout=10) as r:
                return r.status, json.loads(r.read() or b"{}")
        except urllib.error.HTTPError as e:
            raw = e.read()
            try:
                return e.code, json.loads(raw or b"{}")
            except json.JSONDecodeError:
                return e.code, {"raw": raw.decode(errors="replace")}

    def get_text(self, path):
        with urllib.request.urlopen(self.base + path, timeout=10) as r:
            return r.status, r.read().decode()


def start_server(db, port, env_extra=None):
    r = subprocess.run(["python3", str(ROOT / "tools" / "setup_db.py"), db],
                       capture_output=True, text=True)
    if r.returncode != 0:
        raise RuntimeError(f"setup_db failed: {r.stdout} {r.stderr}")
    env = dict(os.environ, FACTORY_DSN=make_dsn(db), FACTORY_PORT=str(port),
               **(env_extra or {}))
    proc = subprocess.Popen([PY, str(ROOT / "api" / "server.py")], env=env,
                            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    client = Client(port)
    for _ in range(100):
        try:
            status, _ = client.call("GET", "/health", token=None)
            if status == 200:
                return proc, client
        except Exception:
            pass
        time.sleep(0.1)
    proc.kill()
    raise RuntimeError("server did not come up")


def stop_server(proc):
    proc.terminate()
    try:
        proc.wait(timeout=5)
    except subprocess.TimeoutExpired:
        proc.kill()
