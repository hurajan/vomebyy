"""Operator walkthrough over HTTP only (G3 PASS gate):
intake -> plan chained units -> claim/complete/validate -> dependent artifact ->
hash-bound gate -> new version refuses the old gate -> repair preview ==
actual cascade -> replacement run -> budget and health close out."""
import json
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from server_fixture import start_server, stop_server  # noqa: E402

DB, PORT = "g3_walkthrough_scratch", 8742

# Gate 05: the API completion barrier requires a SUCCEEDED record for
# every action of the attempt's pinned plan before /complete.
PLANS_PATH = (Path(__file__).resolve().parents[2] / "video-factory-g1"
              / "seed-definitions" / "workflow-1.0.0" / "plans.json")
PLAN_ACTIONS = {p["operation_id"]: p["actions"]
                for p in json.loads(PLANS_PATH.read_text())["plans"]}


class TestWalkthrough(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.proc, cls.api = start_server(DB, PORT)

    @classmethod
    def tearDownClass(cls):
        stop_server(cls.proc)

    def call(self, method, path, body=None, expect=(200, 201)):
        status, out = self.api.call(method, path, body)
        self.assertIn(status, expect, f"{method} {path} -> {status}: {out}")
        return out

    def test_operator_journey(self):
        api = self.api
        # intake
        p = self.call("POST", "/productions", {"title": "Walkthrough", "hard_ceiling_cents": 100000,
                                               "soft_ceiling_cents": 80000})
        pid = p["production_id"]
        run = self.call("POST", f"/productions/{pid}/runs", {"kind": "FULL"})["run_id"]

        # plan a chain: 01.01 -> 02.01
        u1 = self.call("POST", f"/productions/{pid}/units",
                       {"operation_id": "01.01", "run_id": run})
        self.assertEqual(u1["state"], "READY")
        u2 = self.call("POST", f"/productions/{pid}/units",
                       {"operation_id": "02.01", "run_id": run, "depends_on": [u1["unit_id"]]})
        self.assertEqual(u2["state"], "PENDING")  # dependency not yet ACCEPTED

        # work unit 1 to ACCEPTED
        claim = self.call("POST", f"/units/{u1['unit_id']}/claim",
                          {"worker_id": "w1", "estimated_cents": 500})
        # Gate 05: post the pinned plan's action records (the worker
        # service's evidence) so the completion barrier passes.
        for a in PLAN_ACTIONS["01.01"]:
            self.call("POST", f"/units/{u1['unit_id']}/actions",
                      {"attempt_id": claim["attempt_id"],
                       "fencing_token": claim["fencing_token"],
                       "worker_id": "w1", "action_key": a["action_key"],
                       "seq": a["seq"], "status": "SUCCEEDED"})
        done = self.call("POST", f"/units/{u1['unit_id']}/complete",
                         {"worker_id": "w1", "fencing_token": claim["fencing_token"],
                          "artifact_type": "script", "content": "script v1",
                          "storage_uri": "local://script-v1", "actual_cost_cents": 400})
        script_v1 = done["artifact_id"]
        val = self.call("POST", f"/units/{u1['unit_id']}/validate", {"verdict": "PASS"})
        self.assertEqual(val["state"], "ACCEPTED")

        units = self.call("GET", f"/productions/{pid}/units")["units"]
        u2_now = [u for u in units if u["unit_id"] == u2["unit_id"]][0]
        self.assertEqual(u2_now["state"], "READY")  # readiness recomputed

        home = self.call("GET", f"/productions/{pid}")
        step1 = [s for s in home["steps"] if s["step_id"] == "01"][0]
        self.assertEqual(step1["accepted"], 1)  # tracker reflects the ACCEPTED unit

        # downstream artifact consumes the script
        board = self.call("POST", f"/productions/{pid}/artifacts",
                          {"artifact_type": "storyboard", "content": "board v1",
                           "storage_uri": "local://board-v1",
                           "depends_on_artifact_ids": [script_v1]})

        # hash-bound gate on script v1
        gate = self.call("POST", f"/productions/{pid}/gates",
                         {"gate_kind": "HG-SCRIPT", "artifact_id": script_v1})
        self.call("POST", f"/gates/{gate['gate_id']}/decide",
                  {"decision": "APPROVED", "decided_by": "operator"})
        req = self.call("GET", f"/gates/require?production_id={pid}&gate_kind=HG-SCRIPT"
                               f"&artifact_id={script_v1}")
        self.assertTrue(req["satisfied"])

        # a new script version does NOT inherit the approval (exact-hash binding)
        v2 = self.call("POST", f"/productions/{pid}/artifacts",
                       {"artifact_type": "script", "content": "script v2",
                        "storage_uri": "local://script-v2"})
        self.assertEqual(v2["version"], 2)
        req2 = self.call("GET", f"/gates/require?production_id={pid}&gate_kind=HG-SCRIPT"
                                f"&artifact_id={v2['artifact_id']}")
        self.assertFalse(req2["satisfied"])

        # repair console: preview must equal the actual cascade
        preview = self.call("GET", f"/artifacts/{script_v1}/impact")
        self.assertEqual(set(preview["affected_artifact_ids"]),
                         {script_v1, board["artifact_id"]})
        self.assertEqual(preview["affected_unit_ids"], [u1["unit_id"]])
        inv = self.call("POST", f"/artifacts/{script_v1}/invalidate",
                        {"reason": "script defect found"})
        self.assertEqual(set(inv["affected_artifact_ids"]),
                         set(preview["affected_artifact_ids"]))
        self.assertEqual(set(inv["affected_unit_ids"]), set(preview["affected_unit_ids"]))
        self.assertIsNotNone(inv["replacement_run_id"])
        self.assertEqual(len(inv["new_unit_ids"]), 1)

        units = self.call("GET", f"/productions/{pid}/units")["units"]
        old = [u for u in units if u["unit_id"] == u1["unit_id"]][0]
        self.assertEqual(old["state"], "SUPERSEDED")
        new = [u for u in units if u["unit_id"] == inv["new_unit_ids"][0]][0]
        self.assertEqual(new["run_id"], inv["replacement_run_id"])
        self.assertEqual(new["supersedes_unit_id"], u1["unit_id"])
        self.assertEqual(new["operation_id"], "01.01")

        arts = self.call("GET", f"/productions/{pid}/artifacts")["artifacts"]
        states = {a["artifact_id"]: a["state"] for a in arts}
        self.assertEqual(states[script_v1], "INVALIDATED")
        self.assertEqual(states[board["artifact_id"]], "INVALIDATED")
        self.assertEqual(states[v2["artifact_id"]], "CURRENT")

        # finance + tracker + health close the journey
        budget = self.call("GET", f"/productions/{pid}/budget")
        self.assertEqual(budget["spent_cents"], 400)
        self.assertEqual(budget["reserved_cents"], 0)
        home = self.call("GET", f"/productions/{pid}")
        step1 = [s for s in home["steps"] if s["step_id"] == "01"][0]
        self.assertEqual(step1["by_state"].get("SUPERSEDED"), 1)  # cascade visible in tracker
        health = self.call("GET", "/health")
        self.assertEqual(health["registry_operations"], 192)


if __name__ == "__main__":
    unittest.main(verbosity=2)
