#!/usr/bin/env python3
"""Create the fresh G3 scratch DB by reusing the verified G2 setup script
(G1 registry load + migration 002) under the G3 database name."""
import subprocess
import sys
from pathlib import Path

G2_SETUP = Path.home() / "workspace/video-factory-g2/tools/setup_db.py"


def main():
    db = sys.argv[1] if len(sys.argv) > 1 else "g3_dashboard_scratch"
    r = subprocess.run(["python3", str(G2_SETUP), db])
    return r.returncode


if __name__ == "__main__":
    sys.exit(main())
