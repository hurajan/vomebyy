# G3 REPORT — Coordinator API + Dashboard

- **Lock:** confirmed by Raj 2026-10-28 05:03 EDT (LOCK_G3.md). Entry condition: G2 accepted (2026-10-28, without freezing) — met.
- **Status: ACCEPTED by Raj 2026-10-28 05:47 EDT — WITHOUT FREEZING.** (Was: COMPLETE + INDEPENDENTLY VERIFIED after one NOT-VERIFIED pass and a verified MINOR fix, submitted.) No code, contract, or dashboard file was changed by this acceptance. Accepted-but-not-frozen: any future change follows a new lock; the verified evidence belongs to the build exactly as verified.

## What was built (tree: ~/workspace/video-factory-g3/; G1/G2 unmodified)

- **API** (`api/server.py`): Python stdlib HTTP server over the verified G2 coordinator library, one coordinator connection per request (the G2 D1 dangling-transaction class cannot recur at this boundary). 22 endpoints pinned in `contracts/api_contract.json`: productions CRUD-lite, runs, unit plan/claim/event/complete/validate, 192-row operation ledger, 16-step tracker projection, budget position, artifacts, gates (create/decide/hash-bound require), read-only invalidation **preview** (recursive CTE in the API layer — zero write SQL in the API; every state change goes through a Coordinator method, confirmed by the verifier's grep of all 18 execute sites). Auth: single local operator token — **recorded limitation, not production auth**.
- **Dashboard** (`dashboard/index.html`): single page, 10 views covering §13's screens (intake wizard, productions, step tracker, operation ledger, units workbench, artifacts, gate inbox, finance, repair console with preview-before-cascade, provider/health). Every call it makes exists in the contract — enforced by test.

## Evidence

- **Builder tests 5/5** (unittest): contract suite exercises *every* contract endpoint against the real API + scratch PG16 (response keys vs contract, 401/400/404 behavior, full-endpoint coverage assertion); HTTP-only operator walkthrough (intake → chained units unlock on ACCEPTED → gate approves script v1 → same gate *refuses* v2 on exact-hash binding → preview set == actual cascade set → replacement unit in a PARTIAL_REPAIR run → budget spent 400/reserved 0 → health 192); dashboard static checks (all views present, JS parses under `node --check`, UI calls ⊆ contract).
- **Regressions:** G1 suite 7/7, G2 suite 17/17 — both re-run green; G1 `definition_hash` unchanged (ea4503f5…), seed byte-identical.

## Independent verification

- **Verifier #1 (evidence/G3_VERIFIER_REPORT.md): NOT VERIFIED — one MINOR defect D1.** Unknown-id *writes* returned 409 where the contract documents 404 (claim/validate/events/complete on unknown unit; invalidate on unknown artifact; decide on unknown gate). Status semantics only — all calls failed honestly, no data effect. Everything else passed on the verifier's own evidence: 67 probes on a fresh DB with a verifier-chosen token (builder's default correctly rejected), budget exact (reserved 500 after claim; spent 450/reserved 0 after settle), preview == cascade, dashboard byte-identical with calls ⊆ contract, zero write SQL, no scope leakage, G1/G2 untouched.
- **Fix (in-lock):** coordinator not-found messages map to 404 in the API error handler; gates/decide pre-checks existence (an already-decided gate still returns 409 via the `gate not pending` branch); contract test gained regression guards for all six D1 cases + the re-decide 409. Builder suite green after the fix.
- **Re-verifier (evidence/G3_REVERIFIER_REPORT.md): VERIFIED.** 32/32 own checks on a fresh DB with its own token: all six D1 cases → 404; no false 404s (six real-id state violations still 409; gate-create on unknown artifact → 404 per contract); happy path + budget identical to the first verification; auth unchanged; builder suite 5/5 re-run; fix confined to the G3 tree (one transparency note: G1's seed file mtime moved during the fix window but its SHA-256 is byte-identical to the accepted seed — a touch, not a change).

## NOT TESTED (recorded, not hidden)

- Real-browser rendering of the dashboard (headless DOM/render proof needs a reachable host — G0/G0.6-blocked, same constraint as M8).
- Multi-process contention against the API; threaded callback behavior (out of G3 scope).

## Next (owner decisions)

- **G3 acceptance** — Raj's ruling (freeze or not, as with G1/G2).
- **G4 entry condition:** OD-F01 (orchestrator: n8n vs the existing neutral adapter spine) must be decided before a G4 lock can be scoped — the first owner decision the station builds depend on.
