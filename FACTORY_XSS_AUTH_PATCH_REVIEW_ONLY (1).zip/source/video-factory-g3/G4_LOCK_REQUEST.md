# G4 LOCK REQUEST — prepared, NOT confirmed (no work started)

**Entry condition:** G3 ACCEPTED by Raj 2026-10-28 (without freezing) — met.
**Blocking owner decision:** OD-F01 (orchestrator) must be ruled before a G4 lock can be scoped. G4 is the first station-workflow build (execution plans + capability executors for the first station's steps, mock providers only, per A–Z §17); how plans get *driven* depends on this ruling.

## OD-F01 in decidable form

**Question:** what drives step execution — the coordinator itself through the neutral adapter spine, or an external n8n instance calling the coordinator?

- **(a) Neutral adapter spine (coordinator-driven).** Execution plans run through the G2 machinery that already exists and is verified: scheduler claim → claim/lease/fencing → provider jobs → claim-first callbacks → reconciler. Capabilities stay versioned registry records (G1 skeleton, all PROPOSED) behind open adapters; provider binding remains a later OpenRouter-era decision. One authority, one state store, no new infrastructure, nothing G0-blocked. Cost: workflows are data + code, not a visual canvas.
- **(b) n8n as orchestrator (Master Guide v1.3 wording).** n8n workflows call the G3 API; the coordinator remains the state authority and n8n holds no authoritative state (the A–Z guide's design constraint). Benefit: visual workflow editing. Costs: a second deployed system (real hosting blocked on G0/G0.6), a sync/webhook failure surface between n8n and the coordinator, n8n's own database and upgrade cadence, and every G4 test must then cover two systems.
- **Compatibility note (fact, not a third option):** under either ruling the coordinator stays the authority and the G3 API is the boundary — so choosing (a) now does not foreclose adding n8n later as a client; choosing (b) now makes G4 depend on standing n8n up locally for tests.

**Assistant's recommendation: (a).** It follows Raj's standing directives (tools neutral, open adapters, provider binding decided later), the OD-F02a precedent (consolidate existing verified logic), and the pattern that has worked all programme: build on what is verified, keep one authority, add systems only when a decision needs them.

## Scope once OD-F01 is ruled

A G4 lock request in full form (scope, exclusions, PASS criteria, test list) will be prepared from the ruling — as G2 and G3 were — and starts only on Raj's lock confirmation. Nothing in G4 touches real providers, OVHcloud (G0), or the G1 seed; any coordinator change would need its own lock because G2 is accepted (not frozen, but changes are never silent).

---

# OD-F01 RULED — 2026-10-28

- **OD-F01 DECIDED by Raj 2026-10-28 05:54 EDT = (b) n8n as orchestrator.** This overrules the assistant's recommendation of (a), recorded above; the ruling stands as the owner's call and the A–Z guide is not edited. Binding design constraint from the guide (§9.1): n8n is a *client* of the coordinator — it holds **no authoritative state**; eligibility, budget, and approval decisions are coordinator reads/writes through the G3 API only; no direct DB writes by n8n, no embedded credentials beyond the local operator token.

# G4 FULL LOCK REQUEST — Stations 1–2 under n8n (prepared, NOT confirmed)

- **Baseline:** G1 registry (accepted, hash ea4503f5…) + G2 coordinator (accepted) + G3 API + dashboard (accepted). Scope unit per A–Z §17 G4: **Steps 01–04 (48 operations, Stations 1–2)**, workflows + workers, mock only.
- **Environment facts (checked 2026-10-28):** Node v24.22.1 + npm 10.9.4 on this VM; no Docker; ~6.9 GB free disk. n8n's documented LTS target is Node 20/22 — **build starts with a smoke-boot check on Node 24; if it fails, a pinned Node 22 runtime is installed inside the G4 tree** (no system change). Redis is absent → n8n **queue mode (§9.4) is G0 deployment scope**, recorded here as deferred, not silently skipped; G4 runs n8n single-instance regular mode, localhost only, its data directory inside the G4 tree.
- **Scope (in):**
  1. Pinned local n8n install in `~/workspace/video-factory-g4/` + exported, versioned workflow JSON in-tree (workflows are files, reviewed like code — not state hidden in a UI).
  2. Common sub-workflows per §9.2: `dispatch-receiver` (webhook + idempotency key → ack), `call-worker`, `submit-candidate`, `request-validation`, `report-failure`, and one global `error-handler` (a failed execution is reported to the coordinator as an event; n8n never silently retries).
  3. `station-01` and `station-02` workflows per §9.1: receive dispatch → claim via API → call mock worker → complete via API → request validation → stop. Human-confirm points where the guide requires them (01.02/01.03 classification *suggestions*; 02.10 rights decisions are human-issued via a dashboard gate — silence never grants).
  4. Deterministic **mock workers** for Steps 01–04 as local HTTP stubs producing the four exit artifacts: **Production Charter, Rights Register, Canon Manifest, People Manifest** (registered through the API with provenance + hashes).
  5. A thin local **dispatch driver** (harness, in-tree): reads READY units through the API and POSTs dispatch webhooks to n8n. It holds no authority — the coordinator re-checks eligibility at claim (a non-READY claim returns 409). *Recorded limitation:* a production outbox→dispatcher path (the coordinator's outbox table) needs an API/coordinator change under its own future lock; G4 does not touch G2/G3.
- **Scope (out):** real AI models or provider credentials (classification stays mock/deterministic), Steps 05+ (G5+), OVHcloud/Redis/queue mode (G0), the §9.4 production security audit (go-live scope), any edit to G1 seed, G2 code/schema, or the G3 API/dashboard.
- **PASS criteria (A–Z §17 G4 exit evidence):** on a scripted test premise driven end-to-end through n8n — (i) Charter, Rights Register, Canon, and People Manifests exist as CURRENT artifacts with PASS validations; (ii) **rights-block test:** a rights-blocked asset's consuming unit is never claimed/dispatched (workflow stops at the rights read; coordinator shows no claim), while a cleared asset's unit proceeds; (iii) duplicate dispatch webhook → exactly one claim (idempotency); (iv) worker-failure test → error-handler reports to the coordinator, no silent retry; (v) regressions green: G1 7/7, G2 17/17, G3 5/5; (vi) builder ≠ verifier.

