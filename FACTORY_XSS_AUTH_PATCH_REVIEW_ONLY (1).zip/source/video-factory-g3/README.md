# G3 — Coordinator API + Dashboard

Thin HTTP API over the verified G2 coordinator library, plus the §13 dashboard.
G3 does not modify G1 or G2 code or schema (LOCK_G3.md).

## Run locally

```bash
python3 tools/setup_db.py g3_dashboard_scratch      # fresh scratch DB (G1 + 002)
.venv/bin/python api/server.py                       # http://127.0.0.1:8730
```

- Dashboard: `http://127.0.0.1:8730/` · Health: `/health` (unauthenticated)
- Auth: header `X-Operator-Token`. Default token `dev-operator-token`
  (env `FACTORY_API_TOKEN`) — **local development only; production auth is a
  recorded G3 limitation, not part of this build.**
- Env: `FACTORY_DSN` (default local scratch DB, dev role `factory`),
  `FACTORY_PORT` (default 8730, binds 127.0.0.1).
- Contract: `contracts/api_contract.json` — the dashboard only calls endpoints
  listed there (enforced by tests).

## Tests

```bash
.venv/bin/python -m unittest discover -s tests
# test_api_contract.py  — every contract endpoint vs the real API + scratch PG16
# test_walkthrough.py   — full operator journey over HTTP only
# test_dashboard.py     — views present, JS parses (node), UI calls ⊆ contract
```
