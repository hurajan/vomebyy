#!/usr/bin/env python3
"""G4 deterministic mock workers for Steps 01-04 (Stations 1-2).

One stdlib HTTP server standing in for the capability workers behind the
coordinator. Deterministic: the same (production_id, operation_id) always
produces the same content. No AI, no external calls — mock scope per LOCK_G4.

POST /work {operation_id, production_id, unit_id, force_fail?}
  -> {artifact_type, content, actual_cost_cents, verdict}
GET  /health -> {status: ok}
"""
import json
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

OUTPUTS = {
    "01.01": ("premise_record", "PREMISE captured: a lighthouse keeper who trades memories for light."),
    "01.12": ("production_charter",
              "PRODUCTION CHARTER v1 — premise locked; audience, language, acceptance benchmarks committed."),
    "02.12": ("rights_register",
              "RIGHTS & SAFEGUARDING REGISTER v1 — contributors mapped; decisions per asset recorded."),
    "03.02": ("source_registration",
              "SOURCE REGISTRATION — primary/secondary sources registered with provenance + hashes."),
    "03.12": ("canon_manifest",
              "CANON MANIFEST v1 — universe, chronology, world rules, knowledge boundaries released."),
    "04.12": ("people_manifest",
              "PEOPLE MANIFEST v1 — person IDs, biographies, relationships, agency, knowledge states."),
}
DEFAULT = ("step_output", "Deterministic mock output.")


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _send(self, status, obj):
        body = json.dumps(obj).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if self.path == "/health":
            return self._send(200, {"status": "ok", "workers": "mock-steps-01-04"})
        self._send(404, {"error": "no route"})

    def do_POST(self):
        if self.path != "/work":
            return self._send(404, {"error": "no route"})
        n = int(self.headers.get("Content-Length") or 0)
        try:
            req = json.loads(self.rfile.read(n) or b"{}")
        except json.JSONDecodeError:
            return self._send(400, {"error": "invalid JSON"})
        if req.get("force_fail"):
            return self._send(500, {"error": "mock worker failure (forced by test)",
                                    "error_class": "WORKER_ERROR"})
        op = req.get("operation_id")
        artifact_type, base = OUTPUTS.get(op, DEFAULT)
        content = f"{base} [production={req.get('production_id')} op={op} unit={req.get('unit_id')}]"
        self._send(200, {"artifact_type": artifact_type, "content": content,
                         "actual_cost_cents": 90, "verdict": "PASS"})


if __name__ == "__main__":
    ThreadingHTTPServer(("127.0.0.1", 8790), Handler).serve_forever()
