"""G4 end-to-end tests: Stations 1-2 driven by n8n through the G3 API.

Requires the environment from tools/setup_env.py: G3 API on 8730 (scratch DB
g4_station_scratch), mock workers on 8790, n8n on 5678 with the G4 workflows
imported + active. Tests fail loudly if the environment is down.
"""
import json
import sys
import time
import unittest
import urllib.request
import urllib.error
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "driver"))
import dispatch as driver  # noqa: E402

API = "http://127.0.0.1:8730"
TOKEN = "dev-operator-token"


def call(method, path, body=None, expect=(200, 201)):
    req = urllib.request.Request(API + path, method=method)
    req.add_header("X-Operator-Token", TOKEN)
    data = None
    if body is not None:
        data = json.dumps(body).encode()
        req.add_header("Content-Type", "application/json")
    try:
        with urllib.request.urlopen(req, data=data, timeout=15) as r:
            out = json.loads(r.read() or b"{}")
            status = r.status
    except urllib.error.HTTPError as e:
        status, out = e.code, json.loads(e.read() or b"{}")
    assert status in expect, f"{method} {path} -> {status}: {out}"
    return out


def unit_state(pid, unit_id):
    units = call("GET", f"/productions/{pid}/units")["units"]
    return [u for u in units if u["unit_id"] == unit_id][0]


def wait_for(pid, unit_id, targets, timeout=150):
    deadline = time.time() + timeout
    last = None
    while time.time() < deadline:
        last = unit_state(pid, unit_id)
        if last["state"] in targets:
            return last
        time.sleep(2)
    raise AssertionError(f"unit {unit_id} stuck at {last and last['state']}, wanted {targets}")


def drive_until(pid, unit_ids_targets, inputs_by_unit=None, timeout=240):
    """Dispatch newly-READY units via the driver until all targets are met."""
    deadline = time.time() + timeout
    while time.time() < deadline:
        driver.run_once(pid, inputs_by_unit=inputs_by_unit)
        states = {uid: unit_state(pid, uid)["state"] for uid in unit_ids_targets}
        if all(states[uid] in tg for uid, tg in unit_ids_targets.items()):
            return states
        time.sleep(2)
    raise AssertionError(f"drive_until timed out: {states}")


class Base(unittest.TestCase):
    def make_production(self):
        p = call("POST", "/productions", {"title": "G4 test premise",
                                          "hard_ceiling_cents": 1000000,
                                          "soft_ceiling_cents": 900000})
        pid = p["production_id"]
        run = call("POST", f"/productions/{pid}/runs", {"kind": "FULL"})["run_id"]
        return pid, run

    def plan(self, pid, run, op, key="main", depends=(), inputs=()):
        return call("POST", f"/productions/{pid}/units",
                    {"operation_id": op, "run_id": run, "unit_key": key,
                     "depends_on": list(depends), "input_artifact_ids": list(inputs)})


class TestStationsEndToEnd(Base):
    def test_manifests_rights_and_idempotency(self):
        pid, run = self.make_production()
        # premise chain across both stations (step-exit operations)
        u1 = self.plan(pid, run, "01.01")["unit_id"]
        u2 = self.plan(pid, run, "01.12", depends=[u1])["unit_id"]
        u3 = self.plan(pid, run, "02.12", depends=[u2])["unit_id"]
        u4 = self.plan(pid, run, "03.12", depends=[u3])["unit_id"]
        u5 = self.plan(pid, run, "04.12", depends=[u4])["unit_id"]

        # rights fixtures: two source assets, human decisions registered as
        # rights_decision artifacts (02.10 stand-in, per LOCK_G4). Artifact
        # types are per-asset: the coordinator versions artifacts per
        # (production, artifact_type), so a shared type would supersede the
        # first asset/decision with the second.
        ok = call("POST", f"/productions/{pid}/artifacts",
                  {"artifact_type": "source_asset:ok", "content": "asset OK",
                   "storage_uri": "asset://ok"})["artifact_id"]
        blocked = call("POST", f"/productions/{pid}/artifacts",
                       {"artifact_type": "source_asset:blocked", "content": "asset BLOCKED",
                        "storage_uri": "asset://blocked"})["artifact_id"]
        for asset, decision in ((ok, "CLEARED"), (blocked, "BLOCKED")):
            call("POST", f"/productions/{pid}/artifacts",
                 {"artifact_type": f"rights_decision:{asset}",
                  "content": f"human decision {decision}",
                  "storage_uri": f"rights-decision://{asset}/{decision}"})
        u_ok = self.plan(pid, run, "03.02", key="ok", inputs=[ok])["unit_id"]
        u_blk = self.plan(pid, run, "03.02", key="blocked", inputs=[blocked])["unit_id"]

        targets = {u1: {"ACCEPTED"}, u2: {"ACCEPTED"}, u3: {"ACCEPTED"},
                   u4: {"ACCEPTED"}, u5: {"ACCEPTED"}, u_ok: {"ACCEPTED"},
                   u_blk: {"BLOCKED"}}
        drive_until(pid, targets, inputs_by_unit={u_ok: [ok], u_blk: [blocked]})

        # rights-block evidence: the blocked unit was never claimed
        blk = unit_state(pid, u_blk)
        self.assertEqual(blk["current_attempt"], 0)

        # the four exit manifests are CURRENT artifacts
        arts = call("GET", f"/productions/{pid}/artifacts")["artifacts"]
        current_types = {a["artifact_type"] for a in arts if a["state"] == "CURRENT"}
        for t in ("production_charter", "rights_register", "canon_manifest", "people_manifest"):
            self.assertIn(t, current_types)

        # budget: exactly the six completed units settled at the mock cost 90
        budget = call("GET", f"/productions/{pid}/budget")
        self.assertEqual(budget["spent_cents"], 6 * 90)
        self.assertEqual(budget["reserved_cents"], 0)

        # idempotency: duplicate dispatches change nothing
        driver.redispatch(pid, u5, "04.12")
        driver.redispatch(pid, u_ok, "03.02", inputs=[ok])
        time.sleep(6)
        self.assertEqual(unit_state(pid, u5)["current_attempt"], 1)
        self.assertEqual(unit_state(pid, u_ok)["current_attempt"], 1)
        budget = call("GET", f"/productions/{pid}/budget")
        self.assertEqual(budget["spent_cents"], 6 * 90)


class TestWorkerFailure(Base):
    def test_failure_reports_to_coordinator(self):
        pid, run = self.make_production()
        u = self.plan(pid, run, "01.01", key="failcase")["unit_id"]
        driver.run_once(pid, force_fail_units={u})
        final = wait_for(pid, u, {"RETRY_WAIT"}, timeout=120)
        # claimed once, failure reported as an event, no silent retry storm
        self.assertEqual(final["current_attempt"], 1)
        time.sleep(6)
        self.assertEqual(unit_state(pid, u)["state"], "RETRY_WAIT")
        self.assertEqual(unit_state(pid, u)["current_attempt"], 1)


if __name__ == "__main__":
    unittest.main(verbosity=2)
