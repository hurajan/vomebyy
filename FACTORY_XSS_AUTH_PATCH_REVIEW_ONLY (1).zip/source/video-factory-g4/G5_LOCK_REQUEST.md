# G5 LOCK REQUEST — Station 3 (Steps 05–08) + script gate HG2 — prepared, NOT confirmed

**Entry condition:** G4 acceptance — MET (Raj accepted G4 without freezing, 2026-10-28 06:48 EDT).
**OD-F04: DECIDED by Raj 2026-10-28 06:54 EDT = (c) built-Studio numbering — the Factory's script gate is `HG2`.** (Overruled the assistant's (a) recommendation; recorded as the owner's call. The A–Z guide is not edited; the divergence from v1.3's "HG1" wording is on record here. Earlier test gates used ad-hoc kinds such as `HG-SCRIPT`; from G5 on, Factory gate kinds follow built-Studio numbering.)
**Baseline if confirmed:** G1–G4 as accepted; the G4 pattern carries over (n8n client, coordinator authority, workflows as generated JSON, deterministic mock workers, driver harness). New tree `~/workspace/video-factory-g5/`.

## Scope (in)

- `station-03` n8n workflow reusing the G4 sub-workflows (dispatch-receiver, unit-executor, call-worker, error-handler unchanged in pattern); deterministic mock workers for the Steps 05–08 exit chain: **05.12 story architecture → 06.12 beat graph → 07.12 scene set → 08.12 script candidate**, chained on dependencies exactly as in G4 (each unit's input = the previous artifact).
- **Trace-bearing artifacts (T-CRE-01):** every artifact's content is structured JSON; the scene set references beat ids + canon refs; the script candidate carries lines, each line tracing to scene → beat → story architecture + canon artifact ids, plus a clue/knowledge/payoff trace block. Trace completeness is checked mechanically (a test-side checker over the real artifact contents fetched via the API): every line resolves, no dangling references.
- **Script gate HG2 as the station exit:** after 08.12 completes, the flow creates a coordinator human gate of kind `HG2` bound to the script artifact id + exact hash; the station's completion is only recorded once the gate is APPROVED for that exact hash. Test evidence: (i) gate created PENDING on the real script hash; (ii) a decision attempted against a *different* artifact (revised script v2) does not satisfy HG2 for v1 and vice versa — approval of v2 requires its own gate/decision; (iii) final state shows HG2 APPROVED bound to the shipped script's hash.
- **Golden-set limitation carried on record:** EXPERT < 50 → evaluators advisory; HG2 human-only. Mock validation verdicts are deterministic; no claim of armed evaluators anywhere in G5 evidence.

## Scope (out)

- Real AI/models, real providers/credentials, Steps 09+ (G6+), OVHcloud/queue mode (G0), real-browser dashboard work, any edit to G1 seed / G2 code+schema / G3 API+dashboard / G4 workflows+tree (station-03 lives in the G5 tree; the G4 env services are reused as-is).

## PASS criteria

1. Scripted Station-3 walk on a test premise driven through n8n: 05.12 → 06.12 → 07.12 → 08.12 all ACCEPTED; the four artifacts CURRENT (story architecture, beat graph, scene set, script).
2. T-CRE-01 mechanical trace check passes on the real script artifact (100% of lines traced; clue/knowledge/payoff block present and referencing real ids).
3. HG2 evidence per the scope above (PENDING → hash-bound; cross-version approval refused; APPROVED on the exact shipped hash).
4. Budget: spent == 4 × mock cost, reserved 0 at rest (modulo a gate-pending state carrying no reservation).
5. Regressions: G1 7/7, G2 17/17, G3 5/5, G4 2/2.
6. Independent verification by a separate verifier agent (own premise, own trace check, own gate probes); defects reported, not smoothed over.

## Starts only on Raj's explicit G5 lock confirmation.
