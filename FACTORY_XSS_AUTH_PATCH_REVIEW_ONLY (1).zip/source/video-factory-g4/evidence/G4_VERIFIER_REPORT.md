# G4 INDEPENDENT VERIFICATION REPORT

- **Verifier:** independent agent (not the builder). No file under `video-factory-g4/`, `-g1/`, `-g2/`, or `-g3/` was modified. All behavioral evidence comes from the verifier's own productions, fixtures, and webhook POSTs (a verifier-owned harness in /tmp mirroring the driver's payload shape; the builder's driver was not used for the behavioral tests because it writes its state file in-tree).
- **Environment:** services already running per `tools/setup_env.py` topology — G3 API :8730 (scratch DB `g4_station_scratch`, dev token), mock workers :8790, n8n 2.45.5 :5678. API `/health` → ok, 192 registry operations, workflow 1.0.0.
- **VERDICT: VERIFIED — defects NONE.** Two non-defect observations recorded at the end.

## 1. End-to-end, verifier's own premise — PASS

Fresh production `403fffc9-fd44-447f-8bf2-30747625c497` ("G4 VERIFIER premise chain"), chain planned 01.01 → 01.12 → 02.12 → 03.12 → 04.12 (each depends_on the previous), dispatched by the verifier's own webhook POSTs as units became READY:

- All five units reached **ACCEPTED**, each with **current_attempt == 1**.
- Artifacts `production_charter`, `rights_register`, `canon_manifest`, `people_manifest` all exist as **CURRENT** (storage_uri `n8n://unit-executor`, i.e. produced through the n8n path).
- Budget: **spent_cents == 450 (5 × 90), reserved_cents == 0**, projected 450.

## 2. Rights-block, verifier's own fixtures — PASS

Fresh production `f260ba4f-9478-4992-9560-0e762ed2a10c` with verifier assets `source_asset:vok` / `source_asset:vblk` and human-stand-in decisions `rights_decision:<asset_id>` with `rights-decision://<asset_id>/CLEARED|BLOCKED`:

- BLOCKED asset's 03.02 unit → **BLOCKED with current_attempt == 0** (never claimed), unchanged on re-poll 8 s later.
- CLEARED asset's 03.02 unit → **ACCEPTED**, 1 attempt.
- Production budget: spent 90 (the cleared unit only), reserved 0.

## 3. Idempotency + failure — PASS

- Idempotency (production `2dafbb58-6e5d-4fe5-a829-dbd92b98c4c2`): the same 01.01 unit dispatched **twice back-to-back** (identical idempotency_key) → ACCEPTED with **exactly 1 attempt**, spent 90. A further redispatch **after** ACCEPTED changed nothing (attempts still 1, spent still 90 after 8 s).
- Failure (production `70ffb340-ec6e-4f96-a08b-eb1735f6093b`): dispatch with `force_fail: true` → unit **RETRY_WAIT with exactly 1 attempt**; after a further 10 s it was still RETRY_WAIT with 1 attempt (no silent retry); spent 0.

## 4. Authority check — PASS

- **Static audit of all six workflow JSONs:** node types are only `webhook`, `httpRequest`, `code`, `if`, `executeWorkflow`, `executeWorkflowTrigger`, `noOp`. **Zero database-type nodes**; no `psycopg`/`jdbc`/port-5432/connection-string patterns anywhere. Every HTTP URL in every workflow points at `127.0.0.1:8730` (G3 API) or `127.0.0.1:8790/work` (mock workers) — nothing external.
- **Code-node review:** the only decision-shaped logic is station-02's rights read — it GETs the production's artifacts *from the coordinator API*, parses `rights_decision` storage_uris, treats any input without an explicit CLEARED decision as blocked ("silence never grants", per the guide), and merely *reports* a `block` event; the BLOCKED transition itself is the coordinator's (proven behaviorally in §2: state BLOCKED, 0 attempts). Claim sends a fixed `estimated_cents: 100` parameter — the coordinator enforces ceilings at claim; n8n computes no balances. `request-validation` forwards the worker's verdict to the coordinator; all other code nodes are payload reshaping or fixed-vocabulary failure reports (`transient_error` / `block`) sent to the coordinator as events.
- **No n8n retry:** no `retryOnFail` / `maxTries` in any workflow JSON. Runtime executions via the n8n REST API (owner login): exactly the 6 locked workflows, all active; the 100 most recent executions (window covering the verifier's tests, 10:19–10:27 UTC) are **all status success** and **`retryOf` is never set** — n8n retried nothing. Execution counts (25 dispatch-receiver webhook, 24 unit-executor, 20 call-worker, 14 station-01, 12 station-02, 5 error-handler) are consistent with the builder's + verifier's runs in that window.

## 5. Baseline integrity — PASS

- **G1 validate** (fresh run): verdict PASS, `definition_hash` = **ea4503f516fc4f7940f187f5cd9dac38c57f0d239726cac90e2d0a18a8bc9d73** (exact accepted value). Seed file SHA-256 = `8bc567a6…` (the accepted G1 seed hash).
- **Mtimes vs the G4 lock (2026-10-28 09:55 UTC):** G2 build-source dirs (coordinator/database/tests) — **0 files** modified after the lock; G3 build-source dirs (api/dashboard/tests/contracts) — **0 files** modified after the lock. Two transparency notes, neither a content change: (a) G1's seed `operations.json` carries an mtime of 10:24 UTC today (inside the verification window — the loader/setup tooling touches it) but is **byte-identical** to the accepted seed (SHA-256 above; same phenomenon the G3 re-verifier recorded); (b) `video-factory-g3/G4_LOCK_REQUEST.md` has mtime 09:55:00 UTC — it is the G4 decision document stored in the G3 tree by the programme's pattern, timestamped at the lock-confirmation minute, not G3 build source.
- **Suites re-run by the verifier:** G4 builder suite **2/2 OK** (27 s, real n8n), G3 suite **5/5 OK**, G1 suite **7/7 OK**, G2 suite **17/17 OK** — the full LOCK_G4 regression criterion (v) is green on verifier-run evidence, consistent with the builder's claims.

## 6. Scope — PASS

- `package.json` pins exactly `n8n: 2.45.5`, no other dependencies. Grep of workflows/tools/driver/workers/tests finds **no real provider names, no API keys or credentials** (only the documented local dev operator token), **no OVHcloud references**, and the only host referenced anywhere is `127.0.0.1`. "Redis" hits are false positives on the word "redispatch" (the idempotency helper); `tools/setup_env.py` spawns n8n with only `N8N_USER_FOLDER` (in-tree), port, listen-address, and diagnostics/templates-off — **regular single-instance mode, no queue mode, no Redis**.
- `workflows/` contains exactly the six locked workflows (dispatch-receiver, station-01, station-02, unit-executor, call-worker, error-handler) — **no Steps 05+ / Station 3+ workflows**.

## Observations (not defects)

- **O1:** A unit in RETRY_WAIT after a worker failure keeps its claim reservation HELD (failure production showed reserved 100 = the fixed claim estimate, spent 0). This matches the accepted G2 reserve semantics (budget stays reserved for the pending retry) and no LOCK_G4 criterion requires release on failure; recorded for the owner's awareness.
- **O2:** The G1 seed file's mtime moves when the loader/setup tooling runs (content byte-identical, hashes exact). Noted because mtime-only audits will flag it; hash is the reliable evidence.

## NOT TESTED by this verifier

Real-browser rendering of anything; n8n queue mode / Redis (out of scope, G0); multi-process contention; behavior under real (non-mock) workers — all outside LOCK_G4 scope.
