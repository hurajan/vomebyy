#!/usr/bin/env python3
"""G4 dispatch driver (harness only — holds NO authority).

Reads units through the G3 API; for each READY unit not yet dispatched in this
harness run, POSTs a dispatch webhook to n8n's dispatch-receiver. The
coordinator re-checks eligibility at claim time inside the workflow, so a
stale or duplicate dispatch is harmless by design (claim -> 409 -> quiet stop).

Gate G: units now pass through the Gate E evaluation service, whose
semantic layer is unarmed (0 EXPERT golden cases), so evaluated units
land in AWAITING_HUMAN. The harness acts as the human for those units:
run_once posts the human_approved event (OPERATOR) for any unit it
finds in AWAITING_HUMAN and reports them in its return value as
"human_decisions" so suites can assert the path was exercised.

State: driver/dispatch-state.json remembers dispatched unit ids for this
harness so repeated runs don't re-dispatch; --redispatch UNIT forces one
deliberate duplicate (idempotency test).
"""
import json
import sys
import urllib.request
from pathlib import Path

API = "http://127.0.0.1:8730"
N8N_WEBHOOK = "http://127.0.0.1:5678/webhook/dispatch"
TOKEN = "dev-operator-token"
STATE = Path(__file__).resolve().parent / "dispatch-state.json"


def api_get(path):
    req = urllib.request.Request(API + path, headers={"X-Operator-Token": TOKEN})
    with urllib.request.urlopen(req, timeout=10) as r:
        return json.loads(r.read())


def api_post(path, body):
    req = urllib.request.Request(API + path, method="POST",
                                 data=json.dumps(body).encode(),
                                 headers={"X-Operator-Token": TOKEN,
                                          "Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=10) as r:
        return json.loads(r.read() or b"{}")


def station_for(operation_id):
    step = int(operation_id.split(".")[0])
    return 1 if step <= 2 else 2


def post_dispatch(payload):
    req = urllib.request.Request(N8N_WEBHOOK, method="POST",
                                 data=json.dumps(payload).encode(),
                                 headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=15) as r:
        return r.status


def load_state():
    if STATE.exists():
        return set(json.loads(STATE.read_text()))
    return set()


def save_state(ids):
    STATE.write_text(json.dumps(sorted(ids)))


def run_once(production_id, inputs_by_unit=None, force_fail_units=()):
    units = api_get(f"/productions/{production_id}/units")["units"]
    # The harness acts as the human for units the (unarmed) evaluation
    # service routed to AWAITING_HUMAN.
    human_decisions = []
    for u in units:
        if u["state"] == "AWAITING_HUMAN":
            api_post(f"/units/{u['unit_id']}/events", {"event": "human_approved"})
            human_decisions.append(u["unit_id"])
    done = load_state()
    dispatched = []
    for u in units:
        # RETRY_WAIT units are (re)dispatched so the executor's retry
        # branch fires (F-G9-03 design); the done set only suppresses
        # duplicate dispatches of READY units.
        if u["state"] == "RETRY_WAIT":
            done.discard(u["unit_id"])
        if u["state"] not in ("READY", "RETRY_WAIT") or u["unit_id"] in done:
            continue
        payload = {"production_id": production_id, "unit_id": u["unit_id"],
                   "operation_id": u["operation_id"],
                   "station": station_for(u["operation_id"]),
                   "input_artifact_ids": (inputs_by_unit or {}).get(u["unit_id"], []),
                   "force_fail": u["unit_id"] in force_fail_units,
                   "idempotency_key": f"dispatch:{u['unit_id']}:1"}
        post_dispatch(payload)
        done.add(u["unit_id"])
        dispatched.append(u["unit_id"])
    save_state(done)
    return {"dispatched": dispatched, "human_decisions": human_decisions}


def redispatch(production_id, unit_id, operation_id, inputs=()):
    payload = {"production_id": production_id, "unit_id": unit_id,
               "operation_id": operation_id, "station": station_for(operation_id),
               "input_artifact_ids": list(inputs), "force_fail": False,
               "idempotency_key": f"dispatch:{unit_id}:1"}
    return post_dispatch(payload)


if __name__ == "__main__":
    pid = sys.argv[1]
    print(json.dumps(run_once(pid)))
