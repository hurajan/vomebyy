# G7 NOTE — placement of the `master_package → HG4` gate_requirements row (prepared 2026-10-28, proactive groundwork; NOT part of the G7 lock, amends nothing)

## The ambiguity in the G7 lock request as drafted

`G7_LOCK_REQUEST.md` describes the row's placement two different ways:

1. Scope section: the row is "added by the G7 build as data **through the same migration discipline**" as the G6 mechanism.
2. Out-of-scope section: the row is "seeded via the G7 tree's own setup SQL **against its scratch DBs** — note: the row lives in the coordinator's table; adding it to the *shared* seed in migration 003's successor is a G7-lock decision to record explicitly if Raj wants it permanent across all scratch DBs."

Those are not the same outcome, and the lock summary presented at G6 acceptance (2026-10-28 12:28 UTC) said only "one data row, no new coordinator code" — the placement choice was not surfaced. Confirming G7 without naming a placement leaves the builder a legitimate choice between them.

## How `script → HG2` was actually made permanent (the G6 precedent, verified from source)

- `~/workspace/video-factory-g2/database/migrations/003_g6_gate_requirements.sql` — creates `gate_requirements` and INSERTs `('script','HG2') ON CONFLICT DO NOTHING` (idempotent; the G6 verifier re-applied it by hand and got `INSERT 0 0`, still exactly 1 row).
- `~/workspace/video-factory-g2/tools/setup_db.py` applies 003 after 002 on **every** fresh scratch DB. That is what "permanent" mechanically means here: any DB built from the G2 setup chain enforces HG2, whether or not any station tree seeded it.

## The two placements for `master_package → HG4`

**A) Permanent — migration 004 in the G2 tree (data-only)**
- New file `004_*.sql`: `INSERT INTO gate_requirements VALUES ('master_package','HG4') ON CONFLICT DO NOTHING;` plus one line in `setup_db.py` applying it after 003.
- No coordinator code change: `claim()` / `_verify_input_gates` already read the table generically. No claim-logic, transition, budget, or cascade change.
- Consequence: every future DB (G7, G8, regressions) enforces HG4 by default. This IS a touch of the accepted G2 tree, so — exactly as with the G6 Part A amendment — it needs explicit authorization wording in the G7 lock confirmation; it cannot ride along under the lock's current "no coordinator change" out-of-scope line.
- Check performed: no G2 suite assertion counts gate_requirements rows (`test_gate_claim.py` asserts behaviour, not row count), so a second row does not break the 22/22 suite by construction. The G6 verifier's "exactly one row" was a point-in-time evidence statement, not a suite invariant.

**B) Scratch-only — G7 tree setup SQL**
- G7's own setup inserts the row only into G7-built scratch DBs. G2 tree untouched; lock stays exactly as drafted.
- Consequence: HG4 enforcement exists only where G7's setup ran. A DB rebuilt from the G2 chain alone (a regression run, a future G8 setup that forgets to re-seed) silently has **no** master gate — the failure mode is absence, not an error. G8+ would each need to remember to carry the row forward.

## Reply shape (one line, added to the G7 lock confirmation)

"G7 confirmed as scoped; HG4 row placement = [A: permanent, migration 004 authorized, data-only / B: scratch-only, G7 DBs]."

Either choice keeps the rest of the G7 lock unchanged — Station 5 scope, the gate battery at 14.12, prediction lock, PASS criteria, and regressions are identical. What differs is only whether HG4 survives a database rebuild without G7's setup.
