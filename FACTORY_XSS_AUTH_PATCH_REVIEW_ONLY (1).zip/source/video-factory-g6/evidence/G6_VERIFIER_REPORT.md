# G6 INDEPENDENT VERIFICATION REPORT

- **Verifier:** independent agent (not the builder). All behavioral evidence is my own: fresh scratch DBs (`g6_verifier_scratch`, `g6_verifier_sched`), my own coordinator probes, my own API/webhook dispatches (the builder's driver was not used for my probes), my own script fixture and reference checker.
- **Scope:** LOCK_G6 — Part A (coordinator gate-claim amendment in the G2 tree) + Part B (Station 4 in the G6 tree).
- **VERDICT: VERIFIED — defects NONE.**

## 1. Part A at the coordinator level (own probes, 11/11)

Fresh DBs created via the G2 setup chain (001+002+003 applied by `setup_db.py`).

- **(i) Seed + idempotence:** `gate_requirements` contains exactly one row, `script -> HG2`. Re-applying migration 003 with psql (ON_ERROR_STOP) succeeds (`INSERT 0 0`, still exactly 1 row).
- **(ii) Refusal:** unit planned against a CURRENT, never-approved script → `claim()` raises `GateNotSatisfied`; unit stays READY, `current_attempt` 0, zero rows in `action_attempts` and `budget_reservations`, `held_cents` 0. The `gate_claim_refused` audit row was read back through a **separate psycopg connection** (exactly 1 event; payload carries `gate_kind: HG2`, the script's artifact_id, artifact_type, worker_id).
- **(iii) Approval releases:** HG2 gate created + decided APPROVED → the same claim succeeds (`attempt_no` 1, unit CLAIMED).
- **(iv) Non-releasing gates:** an HG2 gate decided **REJECTED** → still `GateNotSatisfied`, 0 attempts. An **APPROVED** HG2 gate bound to a *different* artifact (a storyboard in the same production) → still `GateNotSatisfied`, 0 attempts.
- **(v) Requirement-free inputs:** a unit planned against a `canon_manifest` artifact claims at attempt 1 with no gate anywhere.
- **(vi) Scheduler:** on an isolated DB, `scheduler_claim()` with one gated-unapproved unit and one free unit in the same scan **did not raise**, claimed the free unit, left the gated unit READY, and the pass left a `gate_claim_refused` audit event for the gated unit.

## 2. Part A through the real path (API + n8n)

With the G6 environment up (API on `g6_station_scratch`): my own production (`0174a6a4…`) with a CURRENT script and **no** HG2 gate; a 09.12 unit dispatched via my own POST to `/webhook/dispatch-g6` → after the workflow ran, the unit was still **READY, current_attempt 0, spent 0, reserved 0**, with a `gate_claim_refused` event in the DB. After I approved HG2 via the API and redispatched, the unit went **ACCEPTED at attempt 1**.
Additionally, a **direct API claim** against an unapproved script returned **HTTP 409** with the error naming the requirement ("input script requires an APPROVED HG2 gate bound to artifact …") — the pre-existing G3 mapping (server.py mtime 2026-10-28 09:12 UTC, pre-lock) surfaces `GateNotSatisfied` correctly; no API change was needed, exactly as the lock allowed.

## 3. Part B — verifier's own premise (9/9 real-path probes incl. §2)

My own script fixture (own line texts; lines L1–L3; two clues) registered in my own production (`678dd569…`), HG2 approved:

- Chain **09.12 → 10.12 → 11.12 → 12.12 all ACCEPTED via n8n, exactly 1 attempt each**; `direction_package`, `shot_manifest`, `asset_registry`, `edit_timeline` all **CURRENT**.
- **Own reference checker** over the store contents, each first re-hashed against the API-reported sha256: direction and manifest `script_ref` == my script artifact id; directions cover exactly my fixture's line ids; every shot and voice-plan line ref ∈ fixture line ids; every registry asset's `shot_ref` ∈ manifest shot ids and each asset's payload hash recomputes to its recorded `sha256`; timeline segment shot set == manifest shot id set; Rule of Six dimensions exactly **{Emotion 51, Story 23, Rhythm 10, Eye Trace 7, 2D Plane 5, 3D Space 4}**, weights sum 100, `weighted_total` == my recomputation.
- **Tamper probes rejected:** (1) one shot's `line_ref` broken to `L99` → checker errors; (2) Emotion weight altered 51→50 → checker errors (dimension set, sum, and total all flagged).
- Budget on my premise: **spent 360 (4 × 90), reserved 0**.

## 4. Authority + scope

- **G6 workflows:** only webhook / executeWorkflowTrigger / executeWorkflow / httpRequest / code / if / noOp node types — **zero database nodes**, no `retryOnFail`; every URL is `127.0.0.1:8730` (API) or `127.0.0.1:8792/work` (own workers); no `decide` call anywhere (gate decisions remain human/API-side).
- **Part A diff confinement (G2 tree):** the only source files modified after the lock (2026-10-28 12:03 UTC) are exactly the authorized set — `coordinator/coordinator.py` (12:05), `database/migrations/003_g6_gate_requirements.sql` (12:04), `tools/setup_db.py` (12:04), `tests/test_gate_claim.py` (12:06). `mock_provider.py`, `tests/test_coordinator.py`, `tests/test_durability.py`, migration 002 all retain pre-lock mtimes. Code inspection of coordinator.py: the gate check (`_verify_input_gates`) sits inside `_claim_txn` after `verify_inputs_current` and before the production row lock / reservation writes; refusal converts to committed audit evidence in its own transaction before `GateNotSatisfied` propagates (the D2 durability pattern); `scheduler_claim`'s only change is the skip-on-refusal catch; budget, transition-table, completion, and cascade code show no behavioral edits.
- **G1:** `registry_tool.py validate` → PASS with `definition_hash` **ea4503f516fc4f7940f187f5cd9dac38c57f0d239726cac90e2d0a18a8bc9d73** (exact). No G1 file modified after the lock.
- **G3/G4/G5 sources:** all source/workflow/test files pre-date the lock (G3 ≤ 09:12 UTC; G4 ≤ 10:24 UTC; G5 ≤ 11:01 UTC, with only documentation — `G5_REPORT.md` 11:29 and `G6_LOCK_REQUEST.md` 12:02:25 — touched later, both still pre-lock). Post-lock touches in those trees are exclusively the excluded runtime classes (driver `dispatch-state.json` from suite runs — including my own — __pycache__, n8n-data, content stores).

## 5. Suites (all re-run by me, DB pointing handled explicitly)

| Suite | Result | Notes |
|---|---|---|
| G2 (incl. 5 new gate-claim tests) | **22/22 OK** | run with the G2 venv interpreter on its own scratch DB |
| G6 | **3/3 OK** | after my own `setup_env.py` bring-up (API on `g6_station_scratch`) |
| G3 | **5/5 OK** | own fixture servers/ports |
| G1 | **7/7 OK** | plus validate PASS, hash exact (above) |
| G4 | **2/2 OK** | G4's `setup_env.py` does **not** re-point an already-running API (it reports "api: up"), so I recreated `g4_station_scratch` through the G3→G2 setup chain (003 confirmed present: `script->HG2`) and restarted the API onto it manually before running |
| G5 | **1/1 OK** | G5's setup re-points the API onto `g5_station_scratch` itself |

No suite was skipped. The environment was left with the G6 setup applied (API on `g6_station_scratch`, all worker ports and n8n up); scratch DBs were recreated by the final setup per standing practice, so the probe production ids cited above refer to the pre-reset incarnation — all assertions were captured from live reads at probe time.

## Observations (not defects)

- O1: G4's `setup_env.py` "api: up" behavior means a naive G4-suite run while the shared API points at another tree's DB would silently test against the wrong database. The lock's criterion-5 requirement (explicit DB pointing per suite) exists precisely because of this; the builder's README scopes the note to G4/G5 setups generally, but only the G5/G6 setups actually force the re-point. Worth a one-line correction in the G4 README under a future lock; it does not affect any G6 evidence.
- O2: The G6 mock worker uses the fixed line set L1–L3 (the lock's stated fallback is the standing behavior, since the fixture and worker share the deterministic line set). References are nonetheless genuinely checked — my fixture had different texts and an extra clue, and tampered references were rejected — but a future station that must follow an arbitrary script's line ids will need the worker to read the actual input artifact; that is mock-scope, recorded in the lock.

**Bottom line:** Part A's gate-claim enforcement behaves exactly as locked at the coordinator level, through the API (409), and through real n8n dispatch; Part B's Station 4 chain, reference integrity, and Rule of Six arithmetic verify independently; the change footprint is confined to the authorized files; all six suites pass. **VERIFIED, defects NONE.**
