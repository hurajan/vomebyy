#!/usr/bin/env python3
"""Bring up the G6 environment (Gate G pattern, from G4):

  PG16 scratch DB g6_station_scratch -> G3 API :8730 (restarted onto this DB)
  -> Gate C worker service :8795 + Gate E evaluation service :8796
  -> n8n :5678 (G4 tree instance/data) with the workflows/ JSON synced
  in and activated. STATION binding seeded for station 4.

Gate G changes (LOCK_GATE_G Part B): the per-tree mock workers (:8790)
are RETIRED. The executor now calls the shared worker service (8795)
and evaluation service (8796); both are (re)started by this setup bound
to THIS suite's scratch DB (killed by port first, so a previous suite's
instance can never serve stale state). STATION provider bindings for
this tree's stations (1 and 2) are seeded through the API as OPERATOR:
provider 'deterministic-local', est 100, params.reported_actual_cents
90 (the measured actual the budget assertions encode). Role-token and
service-URL values are passed to the API and n8n processes through
their ENVIRONMENTS ONLY — workflow JSON carries $env expressions.

n8n 2.45 loading path (learned at build time, all observed):
- CLI `import:workflow` + `publish:workflow` leaves webhook triggers marked
  'activated' in n8n's tables but never registers them with the HTTP layer
  (every webhook probe 404s). The REST API path works: create the workflow
  (client-supplied ids are accepted), then POST /workflows/{id}/activate.
- So: this tool starts n8n, ensures a dev owner exists (local-only
  credentials, below), logs in, and syncs each workflow file by
  PATCH-or-create + activate (PUT 404s and DELETE 409s on this build —
  both observed).
- Dev owner: dev@local.invalid / Dev-owner-password-1 (LOCAL INSTANCE ONLY).
"""
import json
import os
import subprocess
import sys
import time
import urllib.request
import urllib.error
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
G3 = Path.home() / "workspace/video-factory-g3"
PROG = Path.home() / "workspace/video-factory-real-ai-programme"
DB = "g6_station_scratch"
DSN = f"host=127.0.0.1 dbname={DB} user=factory password=factory_dev_local"
N8N = "http://127.0.0.1:5678"
API_URL = "http://127.0.0.1:8730"
STATIONS = (4,)
# Local-dev role tokens + service URLs: values live in process
# environments only (API, worker/eval services, n8n), never in workflow
# JSON (generation self-check enforces this).
TOKENS = {"FACTORY_API_TOKEN": "dev-operator-token",
          "FACTORY_WORKER_TOKEN": "dev-worker-token",
          "FACTORY_SCHEDULER_TOKEN": "dev-scheduler-token",
          "FACTORY_VALIDATOR_TOKEN": "dev-validator-token",
          "FACTORY_CALLBACK_TOKEN": "dev-callback-token"}
SERVICE_URLS = {"FACTORY_API_URL": API_URL,
                "FACTORY_WORKER_SERVICE_URL": "http://127.0.0.1:8795",
                "FACTORY_EVALUATION_URL": "http://127.0.0.1:8796"}
OWNER = {"email": "dev@local.invalid", "firstName": "Dev", "lastName": "Owner",
         "password": "Dev-owner-password-1"}
FILES = ["error-handler.json", "call-worker.json", "unit-executor.json",
         "station-04.json", "dispatch-receiver.json"]


def up(url, timeout=2):
    try:
        with urllib.request.urlopen(url, timeout=timeout) as r:
            return r.status == 200
    except Exception:
        return False


def spawn(cmd, env=None, log=None):
    e = dict(os.environ)
    if env:
        e.update(env)
    out = open(log, "ab") if log else subprocess.DEVNULL
    return subprocess.Popen(cmd, env=e, stdout=out, stderr=out,
                            start_new_session=True)


def wait(url, seconds=60):
    for _ in range(seconds * 2):
        if up(url):
            return True
        time.sleep(0.5)
    return False


def kill_port(port):
    subprocess.run(["fuser", "-k", f"{port}/tcp"], capture_output=True)
    time.sleep(0.5)


def api_call(method, path, body=None):
    req = urllib.request.Request(API_URL + path, method=method,
                                 data=json.dumps(body).encode()
                                 if body is not None else None,
                                 headers={"Content-Type": "application/json",
                                          "X-Operator-Token": TOKENS["FACTORY_API_TOKEN"]})
    try:
        with urllib.request.urlopen(req, timeout=15) as r:
            return r.status, json.loads(r.read() or b"{}")
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read() or b"{}")


def seed_station_bindings():
    _, out = api_call("GET", "/configs")
    have = {(c["scope"], c.get("station")) for c in out.get("configs", [])
            if c.get("provider") == "deterministic-local" and c.get("active", True)}
    for station in STATIONS:
        if ("STATION", station) in have:
            continue
        s, out = api_call("POST", "/configs", {
            "scope": "STATION", "station": station, "environment": "test",
            "provider": "deterministic-local", "est_cost_cents": 100,
            "params": {"reported_actual_cents": 90}})
        if s not in (200, 201):
            raise SystemExit(f"STATION binding seed failed for {station}: {s} {out}")
    # Gate 03 Option B (LOCK_GATE_03B): the Gate G OPERATION-scope
    # binding workaround for 12.12 is REMOVED — step 12 is served by
    # the g7 tree (registry Station 5), whose STATION-5 binding resolves
    # it through normal STATION resolution. This tree serves steps
    # 09-11 only.
    print(f"bindings: STATION deterministic-local seeded for {STATIONS}")


VENV_PY = str(Path.home() / "workspace/video-factory-g2/.venv/bin/python")


def start_worker_service():
    kill_port(8795)
    spawn([VENV_PY, str(PROG / "gate-c/worker_service/service.py")],
          env={"WORKER_SERVICE_PORT": "8795", "WORKER_ENVIRONMENT": "test",
               # Gate 04: plan-pin verification (WORKER_DSN) + action
               # records posted to the coordinator API as plan actions
               # finish (FACTORY_API_URL + worker role token).
               "WORKER_DSN": DSN, "FACTORY_API_URL": API_URL,
               "FACTORY_WORKER_TOKEN": TOKENS["FACTORY_WORKER_TOKEN"]},
          log="/tmp/gate-g-worker-service.log")
    if not wait("http://127.0.0.1:8795/health"):
        raise SystemExit("worker service did not come up "
                         "(see /tmp/gate-g-worker-service.log)")
    print("worker service: up on 8795")


def start_evaluation_service():
    kill_port(8796)
    spawn([VENV_PY, str(PROG / "gate-e/evaluation_service/service.py")],
          env={"FACTORY_DSN": DSN, "FACTORY_API_URL": API_URL,
               "FACTORY_VALIDATOR_TOKEN": TOKENS["FACTORY_VALIDATOR_TOKEN"],
               "FACTORY_EVAL_PORT": "8796"},
          log="/tmp/gate-g-evaluation-service.log")
    if not wait("http://127.0.0.1:8796/health"):
        raise SystemExit("evaluation service did not come up "
                         "(see /tmp/gate-g-evaluation-service.log)")
    print("evaluation service: up on 8796")


def rest(method, path, body=None, cookie=None):
    r = urllib.request.Request(N8N + path, method=method,
                               data=json.dumps(body).encode() if body is not None else None,
                               headers={"Content-Type": "application/json",
                                        **({"Cookie": cookie} if cookie else {})})
    try:
        with urllib.request.urlopen(r, timeout=20) as resp:
            raw = resp.read()
            try:
                return resp.status, resp.headers, json.loads(raw or b"{}")
            except json.JSONDecodeError:
                return resp.status, resp.headers, {}
    except urllib.error.HTTPError as e:
        try:
            return e.code, e.headers, json.loads(e.read() or b"{}")
        except json.JSONDecodeError:
            return e.code, e.headers, {}


def sync_workflows():
    # /healthz answers before the REST layer does ("n8n is starting up"
    # placeholder page) — poll login until it returns a real response.
    cookie = None
    for _ in range(60):
        rest("POST", "/rest/owner/setup", OWNER)  # no-op error if owner exists
        s, h, _ = rest("POST", "/rest/login",
                       {"emailOrLdapLoginId": OWNER["email"], "password": OWNER["password"]})
        if h.get("Set-Cookie"):
            cookie = h.get("Set-Cookie").split(";")[0]
            break
        time.sleep(2)
    if not cookie:
        raise SystemExit("n8n REST login never became ready")
    created = []
    for fname in FILES:
        wf = json.loads((ROOT / "workflows" / fname).read_text())
        payload = {k: wf[k] for k in ("id", "name", "nodes", "connections", "settings")}
        s, _, _ = rest("GET", f"/rest/workflows/{wf['id']}", cookie=cookie)
        if s == 200:  # update in place: PATCH is the verb (PUT 404s, DELETE 409s)
            s, _, out = rest("PATCH", f"/rest/workflows/{wf['id']}", payload, cookie)
        else:
            s, _, out = rest("POST", "/rest/workflows", payload, cookie)
        if s != 200:
            raise SystemExit(f"workflow sync failed for {fname}: {s} {str(out)[:200]}")
        created.append((wf["id"], out["data"]["versionId"]))
    for wf_id, version_id in created:
        s, _, out = rest("POST", f"/rest/workflows/{wf_id}/activate",
                         {"versionId": version_id}, cookie)
        if s != 200 or not out.get("data", {}).get("active"):
            raise SystemExit(f"workflow activate failed for {wf_id}: {s} {str(out)[:200]}")
    print(f"n8n: {len(created)} G6 workflows synced + active")


def main():
    subprocess.run(["pg_ctlcluster", "16", "main", "start"], capture_output=True)
    r = subprocess.run(["python3", str(G3 / "tools/setup_db.py"), DB],
                       capture_output=True, text=True)
    if r.returncode != 0:
        raise SystemExit(f"scratch DB setup failed: {r.stderr[-300:]}")
    # (Re)start the shared G3 API onto THIS tree's scratch DB.
    subprocess.run(["fuser", "-k", "8730/tcp"], capture_output=True)
    time.sleep(1)
    spawn([str(G3 / ".venv/bin/python"), str(G3 / "api/server.py")],
          env={"FACTORY_DSN": DSN, "FACTORY_PORT": "8730", **TOKENS},
          log="/tmp/g6-api.log")
    if not wait("http://127.0.0.1:8730/health"):
        raise SystemExit("G3 API did not come up (see /tmp/g6-api.log)")
    print("api: up (g6_station_scratch)")
    seed_station_bindings()
    start_worker_service()
    start_evaluation_service()
    if not up(N8N + "/healthz"):
        G4T = Path.home() / "workspace/video-factory-g4"
        spawn([str(G4T / "node_modules/.bin/n8n"), "start"],
              env={"N8N_USER_FOLDER": str(G4T / "n8n-data"),
                   "N8N_PORT": "5678", "N8N_LISTEN_ADDRESS": "127.0.0.1",
                   "N8N_DIAGNOSTICS_ENABLED": "false",
                   "N8N_TEMPLATES_ENABLED": "false",
                   "N8N_BLOCK_ENV_ACCESS_IN_NODE": "false",
                   **TOKENS, **SERVICE_URLS},
              log="/tmp/g6-n8n.log")
        if not wait(N8N + "/healthz", seconds=90):
            raise SystemExit("n8n did not come up (see /tmp/g6-n8n.log)")
    print("n8n: up")
    sync_workflows()
    print("environment ready")


if __name__ == "__main__":
    main()
