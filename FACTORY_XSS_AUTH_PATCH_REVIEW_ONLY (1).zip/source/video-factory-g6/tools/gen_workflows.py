#!/usr/bin/env python3
"""Generate the G6 n8n workflow JSON files (LOCK_G6).

Topology (coordinator is the only authority; n8n is a client):
  dispatch-receiver-g6 (webhook /webhook/dispatch-g6) --> station-04
  station-04 --> unit-executor-g6 --> call-worker-g6 (worker service)
  failures --> error-handler-g6.

Gate G rework (Real AI programme, LOCK_GATE_G Part B):
  * No hardcoded hosts or token literals anywhere in the generated JSON.
    Base URLs are n8n env expressions ({{$env.FACTORY_API_URL}} etc.)
    resolved from the n8n PROCESS environment at run time; role tokens
    likewise ({{$env.FACTORY_WORKER_TOKEN}} / _SCHEDULER_TOKEN /
    FACTORY_API_TOKEN for the operator header). Token VALUES live only
    in the n8n process env, set by tools/setup_env.py.
  * Least privilege per the Gate C role matrix: claim/complete/reads =
    WORKER role; retry = SCHEDULER; event reports = WORKER (executor identity, Gate 05); gate
    creation (station workflows that act as the operator) = OPERATOR.
  * The executor claims with {worker_id} ONLY (the API enforces the
    resolved binding's estimate since Gate D), fetches the attempt
    snapshot for the pinned provider_binding, calls the Gate C worker
    service, completes with the returned content, then calls the Gate E
    evaluation service — the worker's own verdict is never submitted.
  * Generation self-check: the emitted JSON must not contain
    '127.0.0.1', 'localhost', or any token VALUE from the environment.
"""
import json
import os
import uuid
from pathlib import Path

OUT = Path(__file__).resolve().parent.parent / "workflows"
API = "{{$env.FACTORY_API_URL}}"
WORKER_SVC = "{{$env.FACTORY_WORKER_SERVICE_URL}}"
EVAL = "{{$env.FACTORY_EVALUATION_URL}}"
TOKEN_EXPR = {"OPERATOR": "={{$env.FACTORY_API_TOKEN}}",
              "WORKER": "={{$env.FACTORY_WORKER_TOKEN}}",
              "SCHEDULER": "={{$env.FACTORY_SCHEDULER_TOKEN}}"}

WF = {"receiver": "G6DispatchRecv01", "station4": "G6StationFour001",
      "executor": "G6UnitExecutor01", "callworker": "G6CallWorker0001",
      "errorhandler": "G6ErrorHandler01"}


# Fix D-H1 (design b, LOCK_FIX_DH1 section 1): this tree's executor worker
# identity - a CONSTANT, identical on the claim, resume and completion
# paths, never derived from trigger payload fields (the Gate F dispatcher
# payload carries no 'station'; deriving from it produced the literal
# 'n8n-station-undefined' - V-H1). The coordinator's scheduler pre-stages
# claims under exactly this identity for this tree's steps
# (EXECUTOR_WORKER_IDS in video-factory-g2/coordinator/coordinator.py;
# the pairing is asserted by g2 tests/test_fix_dh1.py).
EXECUTOR_WORKER_ID = "n8n-executor-g6"

# Gate 03 Option B (LOCK_GATE_03B): this tree serves REGISTRY Station 4
# = steps 09-11. Step 12 (registry Station 5) is served by the g7 tree;
# the executor refuses out-of-span dispatches (see the "Served by this
# tree?" guard in the unit-executor) so no Chapter 12 operation can be
# executed through this Station 4 worker.
SERVED_STEPS = (9, 10, 11)


def nid():
    return str(uuid.uuid4())


def node(name, type_, ver, params, x, y=300, on_error=None):
    n = {"parameters": params, "id": nid(), "name": name, "type": type_,
         "typeVersion": ver, "position": [x, y]}
    if on_error:
        n["onError"] = on_error
    return n


def http(name, method, url, body=None, x=0, on_error=None, role="WORKER",
         identity=None):
    headers = [{"name": "Content-Type", "value": "application/json"}]
    if role == "OPERATOR":
        headers.insert(0, {"name": "X-Operator-Token", "value": TOKEN_EXPR["OPERATOR"]})
    elif role in ("WORKER", "SCHEDULER"):
        headers = [{"name": "X-Role", "value": role},
                   {"name": "X-Role-Token", "value": TOKEN_EXPR[role]}] + headers
    elif role is not None:
        raise ValueError(f"unknown role {role}")
    if identity:
        headers.append({"name": "X-Identity", "value": identity})
    p = {"method": method, "url": f"={url}", "authentication": "none",
         "sendHeaders": True,
         "headerParameters": {"parameters": headers},
         "options": {"timeout": 15000}}
    if body is not None:
        p["sendBody"] = True
        p["specifyBody"] = "json"
        p["jsonBody"] = f"={{{{ JSON.stringify({body}) }}}}"
    return node(name, "n8n-nodes-base.httpRequest", 4.2, p, x, on_error=on_error)


def if_node(name, left, right, op_type, operation, x):
    cond = {"id": nid(), "leftValue": f"={{{{ {left} }}}}", "rightValue": right,
            "operator": {"type": op_type, "operation": operation}}
    if op_type == "boolean":
        cond["operator"] = {"type": "boolean", "operation": "true", "singleValue": True}
        cond["rightValue"] = True
    return node(name, "n8n-nodes-base.if", 2.2,
                {"conditions": {"options": {"caseSensitive": True, "leftValue": "",
                                             "typeValidation": "loose"},
                                "conditions": [cond], "combinator": "and"},
                 "options": {}}, x)


def exec_wf(name, wf_id, x):
    return node(name, "n8n-nodes-base.executeWorkflow", 1.2,
                {"source": "database",
                 "workflowId": {"value": wf_id, "type": "list"},
                 "mode": "once", "options": {"waitForSubWorkflow": True}}, x)


def trigger(name="Execute Workflow Trigger"):
    return node(name, "n8n-nodes-base.executeWorkflowTrigger", 1, {}, 240)


def code(name, js, x):
    return node(name, "n8n-nodes-base.code", 2,
                {"mode": "runOnceForAllItems", "jsCode": js}, x)


def noop(name, x):
    return node(name, "n8n-nodes-base.noOp", 1, {}, x)


def conn(*pairs):
    """pairs: (from, to) or (from, to, output_index)"""
    c = {}
    for p in pairs:
        src, dst = p[0], p[1]
        idx = p[2] if len(p) > 2 else 0
        outs = c.setdefault(src, {"main": []})["main"]
        while len(outs) <= idx:
            outs.append([])
        outs[idx].append({"node": dst, "type": "main", "index": 0})
    return c


def workflow(wf_id, name, nodes, connections):
    return {"id": wf_id, "name": name, "nodes": nodes, "connections": connections,
            "active": True, "settings": {"executionOrder": "v1"},
            "staticData": None, "pinData": {}}


# ------------------------------------------------------------ error-handler
# Gate 05 (G01-D07): the error handler reports transient_error - a
# WORKER-class event under the per-event matrix. It authenticates as
# WORKER with this tree's executor identity (X-Identity header + body
# worker_id, which the API binds to the attempt's claim identity).
# Before Gate 05 it used the SCHEDULER role, which may fire no events.
eh = workflow(WF["errorhandler"], "g6-error-handler", [
    trigger(),
    http("Report to coordinator", "POST",
         API + "/units/{{$json.unit_id}}/events",
         "{ event: $json.event, error_class: $json.error_class,"
         " worker_id: '" + EXECUTOR_WORKER_ID + "' }", 460,
         role="WORKER", identity=EXECUTOR_WORKER_ID),
], conn(("Execute Workflow Trigger", "Report to coordinator")))

# -------------------------------------------------------------- call-worker
# Gate G: repurposed as the worker-service caller. It receives the
# assembled §8 request (built by the executor's Assemble node) as its
# trigger input and POSTs it verbatim to the Gate C worker service.
cw = workflow(WF["callworker"], "g6-call-worker", [
    trigger(),
    http("HTTP worker call", "POST", WORKER_SVC + "/work",
         "$json", 460, on_error="continueErrorOutput", role=None),
    code("Prepare failure report",
         "const t = $('Execute Workflow Trigger').first().json;"
         " return [{ json: { unit_id: t.unit_id, event: 'transient_error',"
         " error_class: 'WORKER_ERROR' } }];", 680),
    exec_wf("Report failure", WF["errorhandler"], 900),
    code("Mark failed", "return [{ json: { worker_failed: true } }];", 1120),
], conn(
    ("Execute Workflow Trigger", "HTTP worker call"),
    ("HTTP worker call", "Prepare failure report", 1),
    ("Prepare failure report", "Report failure"),
    ("Report failure", "Mark failed"),
))

# ------------------------------------------------------------ unit-executor
assemble_js = """
const t = $('Execute Workflow Trigger').first().json;
const claim = $('Claim context').first().json;
if (!claim || !claim.fencing_token) return [];  // claim refused: stop cleanly
const attempts = ($('Fetch attempt snapshot').first().json.attempts || []);
const attempt = attempts.find(a => a.attempt_no === claim.attempt_no) || {};
const unitState = $('Unit state').first().json;
// F-P4P-01 fix: refs = the unit's PLANNED inputs (unchanged, first)
// PLUS - on the provider-generation path only - the CURRENT output
// artifacts of the unit's dependency units, as prompt context.
// Why the gate: the deterministic payload builders treat refs as
// their declared-input contract (e.g. 10.12 emits script_ref from
// whatever script ref it is fed, and the step-exit continuity layer
// requires declared == planned; the G9 full run proved the break:
// 10.12 is planned with NO inputs and went REPAIR_REQUIRED once fed
// the script). The frozen slice spec (S3.2/S3.3) sanctions context
// refs beyond planned ONLY for generation, whose worker-side
// shaping declares just the planned canon id. So the extras are
// added exactly when the attempt's pinned binding names a real
// provider - never for the payload providers (deterministic-local,
// mock) or an unbound attempt, where refs stay == planned, byte-for-
// byte the pre-fix behavior.
// Which artifacts: the API read surface exposes no unit_dependencies
// rows, so dependency outputs are identified from the two reads the
// executor already trusts: the production's artifacts (each carries
// produced_by_unit + state; fetched by 'Load production artifacts',
// whose output is this node's $input) joined to the production's
// units (from 'Load unit'). An artifact qualifies when its producer
// unit is ACCEPTED (a unit only becomes dispatchable once its
// dependencies are ACCEPTED) and in the SAME RUN as this unit
// (dependencies are planned in-run), it is CURRENT, and it is not
// this unit's own output. Planned inputs stay first.
const plannedRefs = (unitState.input_artifacts || []).map(a => ({
  artifact_id: a.artifact_id, artifact_type: a.artifact_type,
  sha256: a.sha256, storage_uri: a.storage_uri }));
const pinnedProvider = (attempt.resolved_config || {}).provider || null;
const generationPath = pinnedProvider !== null
  && pinnedProvider !== 'deterministic-local' && pinnedProvider !== 'mock';
const seenRefs = new Set(plannedRefs.map(r => r.artifact_id));
const unitsById = {};
for (const u of ($('Load unit').first().json.units || [])) unitsById[u.unit_id] = u;
const refs = plannedRefs.slice();
if (generationPath) {
  for (const a of ($input.first().json.artifacts || [])) {
    if (!a || a.state !== 'CURRENT') continue;
    if (!a.produced_by_unit || a.produced_by_unit === t.unit_id) continue;
    if (seenRefs.has(a.artifact_id)) continue;
    const producer = unitsById[a.produced_by_unit];
    if (!producer || producer.state !== 'ACCEPTED') continue;
    if (unitState.unit_run_id && producer.run_id !== unitState.unit_run_id) continue;
    seenRefs.add(a.artifact_id);
    refs.push({ artifact_id: a.artifact_id, artifact_type: a.artifact_type,
                sha256: a.sha256, storage_uri: a.storage_uri });
  }
}
const inputs = { ...(t.inputs || {}) };
if (t.premise && inputs.premise === undefined) inputs.premise = t.premise;
return [{ json: {
  unit_id: t.unit_id, attempt_id: attempt.attempt_id || claim.attempt_id,
  fencing_token: claim.fencing_token, operation_id: t.operation_id,
  production_id: t.production_id,
  idempotency_key: t.idempotency_key || ('dispatch:' + t.unit_id),
  provider_binding: attempt.resolved_config || null,
  config_hash: attempt.resolved_config_hash || null,
  input_artifact_refs: refs, inputs: inputs,
  worker_id: 'n8n-executor-g6', force_fail: t.force_fail || false } }];
""".strip()

resume_js = """
const t = $('Execute Workflow Trigger').first().json;
const state = $('Unit state').first().json;
const attempts = ($('Fetch attempts (resume check)').first().json.attempts || []);
// Gate 02 resume rule: the adoption CANDIDATE is the unit's current
// attempt - the one the attempts snapshot marks with a lease
// (lease_worker_id) - when the unit is CLAIMED, the attempt is this
// executor's own, and it looks unstarted (still RUNNING, nothing
// finished, no output). The Coordinator adoption endpoint re-validates
// all of this authoritatively (incl. provider jobs and lease expiry)
// and is the only path that issues the attempt's credentials; anything
// else falls through to the normal claim path (409-safe).
const cur = attempts.find(a => a.lease_worker_id !== null && a.lease_worker_id !== undefined) || null;
let resume = null;
if (state.unit_state === 'CLAIMED' && cur) {
  const started = cur.status !== 'RUNNING' || !!cur.finished_at
    || !!cur.output_artifact_id;
  if (cur.worker_id === 'n8n-executor-g6' && !started) resume = cur;
}
return [{ json: { ...t, resumable: !!resume, resume_attempt: resume } }];
""".strip()
claim_context_js = """
const item = $input.first().json;
// Two producers converge here: the claim response and the Gate 02
// adoption response. Both carry attempt_no / fencing_token /
// attempt_id / unit_id; the adoption response adds adopted: true.
const adopted = item.adopted === true;
return [{ json: { attempt_no: item.attempt_no, fencing_token: item.fencing_token,
                  attempt_id: item.attempt_id, unit_id: item.unit_id,
                  resumed: adopted, adopted: adopted } }];
""".strip()
prepare_adoption_js = """
const d = $input.first().json;
const t = $('Execute Workflow Trigger').first().json;
// One idempotency key per executor EXECUTION (Gate 02 task 5): a retry
// of this call inside the same execution replays the same adoption,
// while a duplicate dispatch (a different execution) presents a
// different key and is refused once the attempt is adopted.
let execId = '';
try { execId = ($execution && $execution.id) || ''; } catch (e) { execId = ''; }
if (!execId) execId = 'x-' + Date.now() + '-' + Math.random();
const attemptId = d.resume_attempt ? d.resume_attempt.attempt_id : null;
return [{ json: { unit_id: t.unit_id, attempt_id: attemptId,
                  worker_id: 'n8n-executor-g6',
                  idempotency_key: 'adopt:' + attemptId + ':' + execId } }];
""".strip()

ue = workflow(WF["executor"], "g6-unit-executor", [
    trigger(),
    http("Load unit", "GET",
         API + "/productions/{{$json.production_id}}/units", None, 300),
    code("Unit state",
         "const t = $('Execute Workflow Trigger').first().json;"
         " const u = ($input.first().json.units || []).find(x => x.unit_id === t.unit_id);"
         " const opId = (u && u.operation_id) || t.operation_id || '';"
         " const step = parseInt(String(opId).split('.')[0], 10);"
         " const served = " + json.dumps(list(SERVED_STEPS)) + ".includes(step);"
         " return [{ json: { ...t, unit_state: u ? u.state : 'UNKNOWN',"
         " unit_run_id: u ? (u.run_id || null) : null,"
         " in_span: served,"
         " input_artifacts: u ? (u.input_artifacts || []) : [] } }];", 350),
    if_node("Served by this tree?", "$json.in_span", None, "boolean", "true", 420),
    noop("Not served by this tree", 460),
    if_node("Is RETRY_WAIT?", "$json.unit_state", "RETRY_WAIT", "string", "equals", 400),
    http("Retry unit", "POST", API + "/units/{{$json.unit_id}}/retry",
         "{}", 430, on_error="continueErrorOutput", role="SCHEDULER"),
    http("Fetch attempts (resume check)", "GET",
         API + "/units/{{$json.unit_id}}/attempts", None, 460),
    code("Resume decision", resume_js, 540),
    code("Prepare adoption", prepare_adoption_js, 560),
    http("Adopt attempt", "POST", API + "/units/{{$json.unit_id}}/adopt",
         "$json", 570, on_error="continueErrorOutput"),
    if_node("Resumable?", "$json.resumable", None, "boolean", "true", 580),
    http("Claim unit", "POST", API + "/units/{{$json.unit_id}}/claim",
         "{ worker_id: '" + EXECUTOR_WORKER_ID + "' }",
         460, on_error="continueErrorOutput"),
    noop("Claim refused or duplicate dispatch", 680),
    code("Claim context", claim_context_js, 620),
    http("Fetch attempt snapshot", "GET",
         API + "/units/{{$json.unit_id}}/attempts", None, 660),
    http("Load production artifacts", "GET",
         API + "/productions/{{ $('Execute Workflow Trigger').item.json.production_id }}/artifacts",
         None, 670),
    code("Assemble worker payload", assemble_js, 680),
    exec_wf("Call worker", WF["callworker"], 900),
    if_node("Worker failed?", "$json.worker_failed", None, "boolean", "true", 1120),
    noop("End after failure report", 1340),
    # F-P4P-02 fix: forward the worker response's usage +
    # provider_request_id verbatim; absent fields are dropped by the
    # JSON.stringify body wrapper, so the deterministic path's body is
    # unchanged. MM-05 (D-MM05-01): also forward the executed `model`
    # (MM-04's /complete field) — without it a gateway fallback
    # completion is priced at the pinned primary model's rates.
    http("submit-candidate", "POST", API + "/units/{{ $('Execute Workflow Trigger').item.json.unit_id }}/complete",
         "{ worker_id: '" + EXECUTOR_WORKER_ID + "',"
         " fencing_token: $('Claim context').item.json.fencing_token,"
         " artifact_type: $json.artifact_type, content: $json.content,"
         " actual_cost_cents: $json.actual_cost_cents,"
         " usage: $json.usage, provider_request_id: $json.provider_request_id,"
         " model: $json.model }",
         1340, on_error="continueErrorOutput"),
    code("Prepare complete failure",
         "const t = $('Execute Workflow Trigger').first().json;"
         " return [{ json: { unit_id: t.unit_id, event: 'transient_error',"
         " error_class: 'COMPLETE_FAILED' } }];", 1560),
    exec_wf("Report complete failure", WF["errorhandler"], 1780),
    http("Evaluate unit", "POST", EVAL + "/evaluate",
         "{ unit_id: $('Execute Workflow Trigger').item.json.unit_id }", 1560,
         role=None),
], conn(
    ("Execute Workflow Trigger", "Load unit"),
    ("Load unit", "Unit state"),
    ("Unit state", "Served by this tree?"),
    ("Served by this tree?", "Is RETRY_WAIT?", 0),
    ("Served by this tree?", "Not served by this tree", 1),
    ("Is RETRY_WAIT?", "Retry unit", 0),
    ("Is RETRY_WAIT?", "Fetch attempts (resume check)", 1),
    ("Retry unit", "Fetch attempts (resume check)"),
    ("Fetch attempts (resume check)", "Resume decision"),
    ("Resume decision", "Resumable?"),
    ("Resumable?", "Prepare adoption", 0),
    ("Resumable?", "Claim unit", 1),
    ("Prepare adoption", "Adopt attempt"),
    ("Adopt attempt", "Claim context", 0),
    ("Adopt attempt", "Claim unit", 1),
    ("Claim unit", "Claim refused or duplicate dispatch", 1),
    ("Claim unit", "Claim context", 0),
    ("Claim context", "Fetch attempt snapshot"),
    ("Fetch attempt snapshot", "Load production artifacts"),
    ("Load production artifacts", "Assemble worker payload"),
    ("Assemble worker payload", "Call worker"),
    ("Call worker", "Worker failed?"),
    ("Worker failed?", "End after failure report", 0),
    ("Worker failed?", "submit-candidate", 1),
    ("submit-candidate", "Prepare complete failure", 1),
    ("Prepare complete failure", "Report complete failure"),
    ("submit-candidate", "Evaluate unit", 0),
))

# ---------------------------------------------------------------- station-04
s4 = workflow(WF["station4"], "g6-station-04", [
    trigger(),
    exec_wf("Run unit", WF["executor"], 460),
], conn(("Execute Workflow Trigger", "Run unit")))

# ---------------------------------------------------------- dispatch-receiver
norm_js = """
const b = $input.first().json.body || {};
return [{ json: { production_id: b.production_id, unit_id: b.unit_id,
  operation_id: b.operation_id, station: b.station,
  input_artifact_ids: b.input_artifact_ids || [],
  inputs: b.inputs || {},
  premise: b.premise || null,
  force_fail: b.force_fail || false,
  idempotency_key: b.idempotency_key || ('dispatch:' + b.unit_id) } }];
""".strip()
rcv = workflow(WF["receiver"], "g6-dispatch-receiver", [
    node("Webhook", "n8n-nodes-base.webhook", 2,
         {"httpMethod": "POST", "path": "dispatch-g6", "responseMode": "onReceived",
          "options": {}}, 240),
    code("Normalize dispatch", norm_js, 460),
    exec_wf("Run station-04", WF["station4"], 680),
], conn(
    ("Webhook", "Normalize dispatch"),
    ("Normalize dispatch", "Run station-04"),
))
# NOTE: no explicit webhookId (see the G4 generator's note — REST
# activation registers the production webhook; CLI import does not).

FILES = {"error-handler.json": eh, "call-worker.json": cw,
         "unit-executor.json": ue, "station-04.json": s4,
         "dispatch-receiver.json": rcv}

# Token VALUES that must never appear in generated JSON (generation-time
# environment); the literal dev operator token is checked unconditionally.
TOKEN_ENV_VARS = ("FACTORY_API_TOKEN", "FACTORY_WORKER_TOKEN",
                  "FACTORY_SCHEDULER_TOKEN", "FACTORY_VALIDATOR_TOKEN",
                  "FACTORY_CALLBACK_TOKEN")


def self_check(rendered):
    problems = []
    for fname, text in rendered.items():
        for needle in ("127.0.0.1", "localhost", "dev-operator-token",
                       "n8n-station-"):
            if needle in text:
                problems.append(f"{fname}: contains forbidden literal {needle!r}")
        for var in TOKEN_ENV_VARS:
            value = os.environ.get(var)
            if value and value in text:
                problems.append(f"{fname}: contains the VALUE of {var}")
    if EXECUTOR_WORKER_ID not in rendered.get("unit-executor.json", ""):
        problems.append("unit-executor.json: executor identity constant missing")
    _ue = rendered.get("unit-executor.json", "")
    if "/adopt" not in _ue or "Prepare adoption" not in _ue:
        problems.append("unit-executor.json: Gate 02 adoption branch missing")
    if "Served by this tree?" not in _ue:
        problems.append("unit-executor.json: Gate 03 span guard missing")
    if "resume check" in _ue and "provider-jobs" in _ue:
        problems.append("unit-executor.json: snapshot resume fetch remains")
    if problems:
        raise SystemExit("GENERATION SELF-CHECK FAILED:\n" + "\n".join(problems))


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    rendered = {fname: json.dumps(wf, indent=2) for fname, wf in FILES.items()}
    self_check(rendered)
    for fname, text in rendered.items():
        (OUT / fname).write_text(text)
        print(f"wrote workflows/{fname} ({len(FILES[fname]['nodes'])} nodes)")
    print("generation self-check: clean (no host literals, no token values)")


if __name__ == "__main__":
    main()
