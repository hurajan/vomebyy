# G6 REPORT — Station 4 (Steps 09–12) + coordinator gate-claim fix

- **Lock:** confirmed by Raj 2026-10-28 08:03 EDT (LOCK_G6.md). Entry condition: G5 accepted. The gate-claim amendment was added to this lock by Raj's ruling 2026-10-28 08:01 EDT, explicitly authorizing the scoped G2 amendment in Part A.
- **Status: ACCEPTED by Raj 2026-10-28 08:28 EDT — WITHOUT FREEZING.** (Was: COMPLETE + INDEPENDENTLY VERIFIED, defects NONE, submitted.) With this acceptance, the Part A amendment (migration 003 + the claim-path gate check) is part of the accepted coordinator baseline. No file was changed by the acceptance itself.

## Part A — Coordinator amendment (G2 tree, exactly the authorized set)

- **Migration 003** (`003_g6_gate_requirements.sql`): `gate_requirements (artifact_type → gate_kind)` as data, seeded `script → HG2`; the setup chain applies it, so every scratch DB carries it.
- **claim() gate check** (`_verify_input_gates`, inside the claim transaction, after the currency check, before the production lock and any reservation): each planned input whose type requires a gate must have an APPROVED gate bound to that exact artifact id + hash, else the claim raises the internal block, rolls back, commits a `gate_claim_refused` audit event in its own transaction (the G2 D2 durability pattern), and raises `GateNotSatisfied`. The G3 API already mapped that error to 409 (a direct API claim probe by the verifier returned 409 naming the requirement) — **no API change was made**.
- **scheduler_claim skip-on-refusal:** the scheduler passes through claim(); without a skip, one permanently unclaimable READY unit (which the gate rule now creates by design) would abort every scheduler pass. It now skips refused candidates (gate/budget/stale/state) and claims the rest; the refusal evidence is committed by claim() itself.
- **Tests:** `tests/test_gate_claim.py` — 5 tests (refusal + durable cross-connection evidence, approval releases, REJECTED/foreign gates don't release, requirement-free inputs unaffected, scheduler skip). G2 suite **22/22**.

## Part B — Station 4 (tree: ~/workspace/video-factory-g6/)

- `g6-station-04` workflow set in the shared n8n instance (webhook `/webhook/dispatch-g6`), mock workers :8792, own scratch DB. Exit chain against an HG2-approved script fixture: 09.12 direction package → 10.12 shot manifest + sound design → 11.12 asset registry → 12.12 edit timeline with the Rule of Six assessment block (weights 51/23/10/7/5/4 as data; deterministic mock scores; weighted total).

## Evidence

- **Builder:** G6 suite 3/3 (chain + mechanical reference check + Rule-of-Six arithmetic; battery (a) unapproved → READY/0 attempts/no budget/audit event, (b) approve → ACCEPTED at attempt 1, (c) foreign-artifact gate releases nothing). Regressions: G1 7/7, G2 22/22, G3 5/5, G4 2/2, G5 1/1.
- **Independent verification (evidence/G6_VERIFIER_REPORT.md): VERIFIED, defects NONE.** The verifier's own probes: Part A at the coordinator level 11/11 (including migration-003 idempotence — re-applying it is a no-op; refusal evidence read through a separate connection; scheduler probe on an isolated DB); Part A through the real path (own production, own dispatch → READY/0/reserved 0 with the refusal event, approve → ACCEPTED; direct API claim → 409); Part B with its own fixture (two clues) — chain ACCEPTED at 1 attempt each, own reference checker passed, **two tamper probes rejected** (broken shot ref; Emotion weight 51→50), budget 360/0. Diff confinement confirmed by mtime sweep + code inspection: in the G2 tree exactly the four authorized files changed; budget/transitions/completion/cascade code unaltered; G1 hash ea4503f5… exact (the seed's mtime moved from loader runs — bytes proven by the hash, the same qualifier prior verifiers recorded); G3/G4/G5 sources untouched. **All suites re-run by the verifier, none skipped:** G1 7/7, G2 22/22, G3 5/5, G4 2/2, G5 1/1, G6 3/3.
- Observation O1 (verifier, not a defect): G4's `setup_env.py` does not re-point an already-running API (it reports "api: up"), so a naive G4-suite run against a shared API pointed elsewhere would silently test the wrong DB. G5/G6 setups force the re-point. A one-line G4 README correction is worth doing under a future lock; no G6 evidence is affected.

## Infra note (recorded during the build)

A host/PostgreSQL restart mid-build killed the :8790/:8791 mock-worker processes and the g4 scratch DB had to be recreated before the G4 regression would run. Infrastructure, not product; the affected suites were re-run green afterward (builder and verifier both).

## NOT TESTED / out of scope (per lock)

Real AI/models and providers; Steps 13+ (G7+); queue mode/Redis (G0); Rule-of-Six editorial quality (mock scores — structure and arithmetic verified); evaluator arming (limitation carried: EXPERT < 50, advisory).

## Next (owner decisions)

- **G6 acceptance** — Raj's ruling (note: acceptance also settles the Part A amendment into the accepted G2 baseline).
- **G7 preparation** (in this tree, G7_LOCK_REQUEST.md): Station 5 (Step 13 Master + Step 14 Derive & Package) with the master gate — gate kind proposed as `HG4` under OD-F04=(c), for confirmation at lock time — plus the upload package and pre-release prediction lock.
