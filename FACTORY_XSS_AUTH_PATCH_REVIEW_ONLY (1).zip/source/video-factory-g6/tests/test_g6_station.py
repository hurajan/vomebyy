"""G6 end-to-end tests (LOCK_G6): Station 4 through n8n, the mechanical
reference check, and the gate-claim battery for the Part A amendment —
exercised through the real API + n8n dispatch path.

Gate 03 Option B (LOCK_GATE_03B): Station 4's chain is steps 09-11
(09.12 -> 10.12 -> 11.12). Step 12 (12.12, registry Station 5) is
served by the G7 tree; its chain coverage and the Rule-of-Six fixture
moved to the G7 suite (video-factory-g7/tests/test_g7_station.py).

Requires tools/setup_env.py: API on 8730 (g6_station_scratch, migrations
001+002+003), G6 mock workers on 8792, n8n with the G6 workflows active.
"""
import hashlib
import json
import sys
import time
import unittest
import urllib.request
import urllib.error
from pathlib import Path

import psycopg
from psycopg.rows import dict_row

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "driver"))
import dispatch as driver  # noqa: E402

API = "http://127.0.0.1:8730"
TOKEN = "dev-operator-token"
STORE = Path(__file__).resolve().parent.parent / "store"
# Gate G: produced contents live in the Gate D store, layered envelopes
GATE_D_STORE = (Path.home() / "workspace/video-factory-real-ai-programme"
                / "gate-d/storage_service/.store")
DSN = "host=127.0.0.1 dbname=g6_station_scratch user=factory password=factory_dev_local"

SCRIPT = {
    "kind": "script",
    "lines": [
        {"id": "L1", "scene_ref": "SC1", "beat_ref": "B1", "story_ref": "S1",
         "canon_refs": [], "text": "Mara finds the brass key behind the clock."},
        {"id": "L2", "scene_ref": "SC2", "beat_ref": "B2", "story_ref": "S2",
         "canon_refs": [], "text": "Tobin admits the archive door was locked from inside."},
        {"id": "L3", "scene_ref": "SC1", "beat_ref": "B1", "story_ref": "S1",
         "canon_refs": [], "text": "The brass key opens the archive; the ledger is gone."}],
    "trace": {"clues": [{"id": "CL1", "planted": "L1", "payoff": "L3"}],
              "knowledge": [{"character": "Mara", "learns": "CL1", "at": "L2"}],
              "payoffs": [{"id": "PO1", "clue": "CL1", "line": "L3"}]},
    "canon_refs": []}
LINE_IDS = {ln["id"] for ln in SCRIPT["lines"]}


def call(method, path, body=None, expect=(200, 201)):
    req = urllib.request.Request(API + path, method=method)
    req.add_header("X-Operator-Token", TOKEN)
    data = None
    if body is not None:
        data = json.dumps(body).encode()
        req.add_header("Content-Type", "application/json")
    try:
        with urllib.request.urlopen(req, data=data, timeout=15) as r:
            out = json.loads(r.read() or b"{}")
            status = r.status
    except urllib.error.HTTPError as e:
        status, out = e.code, json.loads(e.read() or b"{}")
    assert status in expect, f"{method} {path} -> {status}: {out}"
    return out


def unit_state(pid, unit_id):
    units = call("GET", f"/productions/{pid}/units")["units"]
    return [u for u in units if u["unit_id"] == unit_id][0]


def wait_state(pid, unit_id, target, timeout=120):
    deadline = time.time() + timeout
    last = None
    while time.time() < deadline:
        last = unit_state(pid, unit_id)
        if last["state"] == target:
            return last
        time.sleep(2)
    raise AssertionError(f"unit stuck at {last and last['state']}, wanted {target}")


def drive_until(pid, unit_id, target="ACCEPTED", timeout=240):
    """Gate G: acceptance now routes through evaluation + the driver's
    harness-as-human approval, so keep driving until the unit lands."""
    deadline = time.time() + timeout
    last = None
    while time.time() < deadline:
        driver.run_once(pid)
        last = unit_state(pid, unit_id)
        if last["state"] == target:
            return last
        time.sleep(2)
    raise AssertionError(f"unit stuck at {last and last['state']}, wanted {target}")


def refusals(unit_id):
    with psycopg.connect(DSN, row_factory=dict_row, autocommit=True) as conn:
        return conn.execute(
            "SELECT count(*) AS n FROM audit_events WHERE unit_id=%s"
            " AND event_type='gate_claim_refused'", (unit_id,)).fetchone()["n"]


class Base(unittest.TestCase):
    def make_production(self, title):
        p = call("POST", "/productions", {"title": title,
                                          "hard_ceiling_cents": 1000000,
                                          "soft_ceiling_cents": 900000})
        pid = p["production_id"]
        run = call("POST", f"/productions/{pid}/runs", {"kind": "FULL"})["run_id"]
        return pid, run

    def register_script(self, pid):
        content = json.dumps(SCRIPT, sort_keys=True)
        sha = hashlib.sha256(content.encode()).hexdigest()
        STORE.mkdir(parents=True, exist_ok=True)
        (STORE / f"{sha}.json").write_text(content)
        art = call("POST", f"/productions/{pid}/artifacts",
                   {"artifact_type": "script", "content": content,
                    "storage_uri": f"mock-store://{sha}"})
        return art["artifact_id"]

    def approve_hg2(self, pid, artifact_id):
        gate = call("POST", f"/productions/{pid}/gates",
                    {"gate_kind": "HG2", "artifact_id": artifact_id})
        call("POST", f"/gates/{gate['gate_id']}/decide",
             {"decision": "APPROVED", "decided_by": "operator"})
        return gate["gate_id"]

    def plan(self, pid, run, op, depends=(), inputs=()):
        return call("POST", f"/productions/{pid}/units",
                    {"operation_id": op, "run_id": run, "unit_key": "main",
                     "depends_on": list(depends), "input_artifact_ids": list(inputs)})

    def artifact_content(self, art):
        raw = (GATE_D_STORE / "objects" / art["sha256"]).read_bytes()
        assert hashlib.sha256(raw).hexdigest() == art["sha256"]
        doc = json.loads(raw)
        if isinstance(doc, dict) and doc.get("output_artifacts"):
            return doc["output_artifacts"][0]["content"]
        return doc


class TestStation4(Base):
    def test_chain_references(self):
        pid, run = self.make_production("G6 approved premise")
        script = self.register_script(pid)
        self.approve_hg2(pid, script)
        u09 = self.plan(pid, run, "09.12", inputs=[script])["unit_id"]
        u10 = self.plan(pid, run, "10.12", depends=[u09])["unit_id"]
        u11 = self.plan(pid, run, "11.12", depends=[u10])["unit_id"]
        deadline = time.time() + 240
        while time.time() < deadline:
            driver.run_once(pid, inputs_by_unit={u09: [script]})
            states = {u: unit_state(pid, u)["state"] for u in (u09, u10, u11)}
            if all(s == "ACCEPTED" for s in states.values()):
                break
            time.sleep(2)
        else:
            self.fail(f"chain timed out: {states}")

        arts = call("GET", f"/productions/{pid}/artifacts")["artifacts"]
        cur = {a["artifact_type"]: a for a in arts if a["state"] == "CURRENT"}
        for t in ("direction_package", "shot_manifest", "asset_registry"):
            self.assertIn(t, cur)
        # Gate 03 Option B: step 12 belongs to Station 5 — this tree
        # must produce NO edit_timeline.
        self.assertNotIn("edit_timeline", cur)

        direction = self.artifact_content(cur["direction_package"])
        self.assertEqual(direction["script_ref"], script)
        for d in direction["directions"]:
            self.assertIn(d["line_ref"], LINE_IDS)

        manifest = self.artifact_content(cur["shot_manifest"])
        shot_ids = {s["id"] for s in manifest["shots"]}
        self.assertEqual(len(shot_ids), 3)
        for s in manifest["shots"]:
            self.assertIn(s["line_ref"], LINE_IDS)
        for v in manifest["sound_design"]["voice_plan"]:
            self.assertIn(v["line_ref"], LINE_IDS)

        registry = self.artifact_content(cur["asset_registry"])
        for a in registry["assets"]:
            self.assertIn(a["shot_ref"], shot_ids)
            self.assertEqual(hashlib.sha256(a["payload"].encode()).hexdigest(),
                             a["sha256"])

        budget = call("GET", f"/productions/{pid}/budget")
        self.assertEqual(budget["spent_cents"], 3 * 90)
        self.assertEqual(budget["reserved_cents"], 0)


class TestGateClaimBattery(Base):
    def test_unapproved_refused_then_approved_releases(self):
        pid, run = self.make_production("G6 unapproved premise")
        script = self.register_script(pid)
        u = self.plan(pid, run, "09.12", inputs=[script])["unit_id"]
        driver.run_once(pid, inputs_by_unit={u: [script]})
        time.sleep(10)
        unit = unit_state(pid, u)
        self.assertEqual(unit["state"], "READY")          # (a) refused, unchanged
        self.assertEqual(unit["current_attempt"], 0)      # zero attempts
        budget = call("GET", f"/productions/{pid}/budget")
        self.assertEqual(budget["reserved_cents"], 0)     # no budget moved
        self.assertEqual(budget["spent_cents"], 0)
        self.assertGreaterEqual(refusals(u), 1)           # audit evidence exists

        self.approve_hg2(pid, script)                     # (b) approve -> releases
        driver.redispatch(pid, u, "09.12", inputs=[script])
        final = drive_until(pid, u, "ACCEPTED")
        self.assertEqual(final["current_attempt"], 1)

    def test_gate_on_other_artifact_does_not_release(self):
        pid, run = self.make_production("G6 foreign-gate premise")
        script = self.register_script(pid)
        canon = call("POST", f"/productions/{pid}/artifacts",
                     {"artifact_type": "canon_manifest", "content": "canon",
                      "storage_uri": "local://canon"})["artifact_id"]
        self.approve_hg2(pid, canon)  # HG2 approved — but bound to the canon
        u = self.plan(pid, run, "09.12", inputs=[script])["unit_id"]
        driver.run_once(pid, inputs_by_unit={u: [script]})
        time.sleep(10)
        unit = unit_state(pid, u)                          # (c) still refused
        self.assertEqual(unit["state"], "READY")
        self.assertEqual(unit["current_attempt"], 0)
        self.assertGreaterEqual(refusals(u), 1)


if __name__ == "__main__":
    unittest.main(verbosity=2)
