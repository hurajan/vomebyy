# G6 — Station 4 (Steps 09–12) + coordinator gate-claim fix

LOCK_G6.md is the scope. Two parts:

**Part A — coordinator amendment** (in the G2 tree, explicitly authorized
by the G6 lock): migration `003_g6_gate_requirements.sql` adds
`gate_requirements (artifact_type → gate_kind)`, seeded `script → HG2`.
`claim()` now checks, after the input-currency check and before any
budget movement, that every planned input whose type requires a gate
has an APPROVED gate bound to that exact artifact id + hash. Refusal =
typed `GateNotSatisfied` (the G3 API already maps it to 409), zero
attempts, zero budget movement, and a `gate_claim_refused` audit event
committed in its own transaction (the G2 durability pattern).
`scheduler_claim` skips refused candidates instead of aborting the pass.
Tests: `video-factory-g2/tests/test_gate_claim.py` (5 tests; full G2
suite 22/22). The setup chain applies 003 automatically
(`video-factory-g2/tools/setup_db.py`), so every scratch DB carries it.

**Part B — Station 4** (this tree): `g6-station-04` workflow set in the
shared n8n instance (webhook `/webhook/dispatch-g6`), mock workers on
:8792 for 09.12 direction package → 10.12 shot manifest + sound design
→ 11.12 asset registry → 12.12 edit timeline with the Rule of Six
assessment block (weights Emotion 51 / Story 23 / Rhythm 10 /
Eye Trace 7 / 2D Plane 5 / 3D Space 4 as data; deterministic mock
scores; the rubric never overrides a hard failure). Contents are
reference-bearing JSON in the content-addressed store
(`mock-store://<sha256>`), checkable against coordinator hashes, as G5.

## Run

```bash
python3 tools/gen_workflows.py    # if workflows changed
python3 tools/setup_env.py        # DB (001+002+003) + API :8730 + workers :8792 + n8n sync
~/workspace/video-factory-g2/.venv/bin/python -m unittest discover -s tests
```

(The suite uses the G2 venv interpreter — it needs psycopg for the
audit-evidence reads; G4/G5 suites run on system python3.)

## Tests

- `TestStation4` — chain through real n8n against an HG2-approved
  script fixture; mechanical reference check (directions/shots →
  fixture line ids, registry hashes re-hash, timeline → shot ids,
  Rule of Six weights sum to 100 and the total recomputes); budget
  exactly 4 × 90¢.
- `TestGateClaimBattery` — through the API + n8n dispatch path:
  (a) unapproved script → unit stays READY, 0 attempts, no budget
  movement, `gate_claim_refused` audit evidence; (b) approve HG2 →
  redispatch → ACCEPTED at attempt 1; (c) an HG2 gate bound to a
  *different* artifact does not release the claim.
