# LOCK G6 — Station 4 (Steps 09–12) + coordinator gate-claim fix

- **Confirmed by Raj:** 2026-10-28 08:03 EDT ("Confirm G6 lock as revised (Station 4 + gate-claim fix)"). The gate-claim amendment was added to this lock by Raj's ruling 2026-10-28 08:01 EDT, on the design recorded in the lock request.
- **Entry condition met:** G5 ACCEPTED (without freezing) 2026-10-28.
- **Baseline:** G1 (definition_hash ea4503f516fc4f7940f187f5cd9dac38c57f0d239726cac90e2d0a18a8bc9d73), G2, G3, G4, G5 — all ACCEPTED, none frozen. OD-F01=(b) and OD-F04=(c) carry. **This lock explicitly authorizes a scoped amendment to the G2 coordinator** (Part A below) and, only if needed for the refusal to surface as 409, the matching G3 API error mapping. No other change to G1–G5 artifacts is authorized.
- **Source spec:** A–Z Guide §17 (G6) + §9.3 Station 4 + §11 (Rule of Six as a Step-12 rubric that never overrides hard failures). Full scope text: ~/workspace/video-factory-g5/G6_LOCK_REQUEST.md (as confirmed).

## Part A — Coordinator amendment (gate-claim enforcement)

1. **Migration 003** (in the G2 tree's migrations, applied after 002): table `gate_requirements (artifact_type TEXT PRIMARY KEY, gate_kind TEXT NOT NULL)`, seeded with one row: `script → HG2`. Requirements are data.
2. **claim() gate check:** after the existing input-currency verification and before any reservation/attempt is written, for each planned input artifact whose type has a required gate, require an APPROVED human gate bound to that exact artifact id + sha256 (require_gate semantics). Unsatisfied → typed refusal `GateNotSatisfied` (a CoordinatorError subclass): zero attempts, zero budget movement, unit state unchanged.
3. **Refusal evidence:** the refusal writes an audit event (`gate_claim_refused`, with unit/artifact/gate_kind context) committed in its own transaction following the G2 durability pattern (the claim()/complete_attempt() evidence pattern from the D2 fix) — the evidence must be readable from a separate connection after the refusal.
4. **API surface:** the G3 API returns 409 for the refusal (checked at build; mapping added only if it does not already).
5. **Coordinator tests** (new, in the G2 suite): (a) unapproved CURRENT script input → GateNotSatisfied, no attempt row, audit event durable cross-connection; (b) approved → claim proceeds; (c) gate on a different artifact → refused; (d) requirement-free input types unaffected; (e) migration 003 applies cleanly after 001+002 and is idempotent-guarded like its predecessors (check 002's style at build).

## Part B — Station 4

1. New tree `~/workspace/video-factory-g6/`; own scratch DB `g6_station_scratch`; mock workers :8792; station-04 workflow set (webhook `/webhook/dispatch-g6`) generated like G4/G5, reusing the shared n8n instance and the G3 API service (setup restarts the API onto the G6 DB with migrations 001+002+003 applied).
2. Mock workers for the exit chain, planned against the premise's HG2-approved script: **09.12 direction package → 10.12 shot manifest + sound design → 11.12 asset registry → 12.12 edit timeline** with the **Rule of Six assessment block** (dimensions + weights Emotion 51 / Story 23 / Rhythm 10 / Eye Trace 7 / 2D Plane 5 / 3D Space 4 as data; deterministic mock scores; weighted total). Contents are trace/reference-bearing JSON persisted to the content-addressed store, as in G5. References: direction and shots reference the script fixture's line ids — the premise's script fixture content is a trace-bearing script (same shape as G5's worker output, lines L1–L3), registered by the test, gated HG2, approved; workers read it from the G6 store by its sha (they persist it identically) — if the fixture's sha is not in the store, the worker falls back to the same deterministic line set (L1–L3) the fixture uses; the checker validates against the fixture content itself.
3. Driver harness as before (no authority).

## PASS criteria

1. Station-4 walk through n8n: 09.12 → 10.12 → 11.12 → 12.12 ACCEPTED; direction_package, shot_manifest, asset_registry, edit_timeline CURRENT.
2. Mechanical reference check over the real contents: shots reference real script line ids; asset registry entries' hashes re-hash correctly; the edit timeline references real shot ids; Rule of Six block has all six dimensions, weights sum to 100, weighted total consistent with its scores.
3. **Gate-claim battery through the real API + n8n path:** (a) production with a CURRENT, never-approved script: Station-4 unit dispatched → stays READY, current_attempt 0, no budget reserved, `gate_claim_refused` audit evidence exists; (b) after HG2 approval the same unit claims and completes; (c) gate approved for a different artifact does not release the claim; (d) superseded-input refusal still fires on currency (T-DEP-01 unchanged); (e) G4-style ungated flows unaffected.
4. Budget on the happy-path premise: spent == 4 × 90¢, reserved 0.
5. Regressions: G1 7/7 (seed untouched — migration 003 is coordinator state, not registry data), G2 suite incl. the new amendment tests, G3 5/5, G4 2/2, G5 1/1 (shared-API DB pointing handled explicitly per suite; suites that run against scratch DBs must apply migration 003 — the setup tools chain is updated accordingly *within this lock's scope*: G2's setup_db applies 003, which the G3/G4/G5 setups inherit).
6. Independent verification by a separate verifier agent (own premise, own reference checker, tamper probe, own gate-claim probes). Defects reported, not smoothed over.

## Out of scope

Real AI/models, real providers/credentials; Steps 13+ (G7+); OVHcloud/queue mode (G0); any G1–G5 change beyond Part A and the setup-chain consequence in criterion 5.

## Recorded limitation (carried)

EXPERT golden cases < 50 → evaluators advisory; mock verdicts deterministic; the Rule of Six scores in G6 are mock scores — the assessment *structure and arithmetic* are what is verified, not editorial quality.
