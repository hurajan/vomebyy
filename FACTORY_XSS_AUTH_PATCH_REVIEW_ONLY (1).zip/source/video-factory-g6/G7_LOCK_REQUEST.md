# G7 LOCK REQUEST — Station 5 (Steps 13–14) + master gate — prepared, NOT confirmed

**Entry condition:** G6 acceptance — MET (Raj accepted G6 without freezing, 2026-10-28 08:28 EDT; the G6 Part A amendment is part of the accepted coordinator baseline).
**Baseline if confirmed:** G1–G6 as accepted (including the G6 Part A coordinator amendment: gate-claim enforcement is live, and `gate_requirements` is data). The established pattern carries over (n8n client, coordinator authority, generated workflows, deterministic mock workers, driver harness, content-addressed store). New tree `~/workspace/video-factory-g7/`, own scratch DB, workers on :8793, webhook `/webhook/dispatch-g7`.

## Scope sketch (A–Z §17 G7; step names from the G1 contracts)

Station 5: Step 13 (Master), Step 14 (Derive & Package).

- **13.12 → master package** ("Release approved master to derivative planning only after master approval"): a master_package artifact assembled from the edit timeline + asset registry references (hashes carried over, mechanically checkable), produced by the mock worker.
- **Master gate as the station's hinge:** under OD-F04 = (c) built-Studio numbering, the master-approval gate kind is proposed as **`HG4`** (the built Studio's publication/master approval numbering; v1.3's text differs — the divergence is on record via OD-F04). *For Raj's confirmation at lock time.* Enforcement needs **no new coordinator work**: one row in `gate_requirements` (`master_package → HG4`, added by the G7 build as data through the same migration discipline) makes the coordinator refuse any 14.x claim planned against an unapproved master — the G6 mechanism, reused.
- **14.12 → derivative package** ("Lock per-derivative hash"): per-derivative entries (e.g. vertical 9:16, square 1:1, thumbnail set) each with its own content hash locked in the artifact; plus the **upload package** (the derivative set + metadata manifest) as the station exit artifact.
- **Prediction lock (guide §17 G7):** a predictions artifact (expected performance ranges per derivative, recorded as data at package time) registered **before** any release metrics exist — G7's evidence shows the prediction artifact's creation precedes any Step-15/16 artifact in the production (there are none in scope), i.e. predictions are locked pre-release by construction.

## PASS evidence (guide §17 G7)

1. Master package READY: 13.12 ACCEPTED through n8n; master_package CURRENT, its references (timeline/registry ids + hashes) mechanically verified against the premise's Station-4 outputs (fixtures, as before).
2. Master gate: HG4 created on the master package (human decision via API); **the gate-claim battery re-run at this station** — a 14.12 unit planned against an unapproved master is refused by the coordinator (READY, 0 attempts, `gate_claim_refused` evidence) and proceeds after HG4 approval. This is the second production use of the G6 mechanism and its regression proof.
3. Derivative + upload package: 14.12 ACCEPTED after approval; derivative_package CURRENT with per-derivative hashes that re-hash correctly; upload_package manifest lists exactly the derivative set.
4. Predictions locked: predictions artifact exists, timestamped before any distribution artifact (none exist), content = the locked pre-release predictions.
5. Budget: spent == mock costs for the station's units, reserved 0.
6. Regressions: G1 7/7, G2 (incl. gate-claim tests), G3 5/5, G4 2/2, G5 1/1, G6 3/3 — shared-API DB pointing handled explicitly per suite.
7. Independent verification (own premise, own checker, tamper probe on a derivative hash, own gate battery probes).

## Out of scope

Real rendering/transcoding (derivatives are mock packages with real hash discipline, not real media), real AI/models/providers, Steps 15–16 (G8), OVHcloud/queue mode (G0), any code change to the coordinator (the gate_requirements row is data, seeded via the G7 tree's own setup SQL against its scratch DBs — note: the row lives in the coordinator's table; adding it to the *shared* seed in migration 003's successor is a G7-lock decision to record explicitly if Raj wants it permanent across all scratch DBs).
