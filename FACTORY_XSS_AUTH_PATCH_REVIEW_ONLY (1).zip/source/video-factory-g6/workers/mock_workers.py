#!/usr/bin/env python3
"""Deterministic mock workers for G6 Station 4 (LOCK_G6 Part B).

POST /work {operation_id, production_id, unit_id, force_fail?} -> one of
the Steps 09-12 exit operations. Contents are reference-bearing JSON
persisted to the content-addressed store (store/<sha256>.json) with
storage_uri mock-store://<sha256>, mechanically checkable against the
coordinator-recorded hashes, as in G5.

The premise's script is the G5-shaped trace-bearing script (lines
L1-L3); direction and shots reference those line ids, the timeline
references the manifest's shot ids, and the edit timeline carries the
Rule of Six assessment (weights from Raj's supplied source, recorded
as data: Emotion 51, Story 23, Rhythm 10, Eye Trace 7, 2D Plane 5,
3D Space 4). Scores are deterministic mock scores — the assessment
structure and arithmetic are what the tests verify.
"""
import hashlib
import json
import urllib.request
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path

API = "http://127.0.0.1:8730"
TOKEN = "dev-operator-token"
STORE = Path(__file__).resolve().parent.parent / "store"
COST = 90
LINES = ["L1", "L2", "L3"]
SHOTS = {"SH1": "L1", "SH2": "L2", "SH3": "L3"}
RULE_OF_SIX = [("Emotion", 51, 8.6), ("Story", 23, 8.2), ("Rhythm", 10, 7.4),
               ("Eye Trace", 7, 7.9), ("2D Plane", 5, 7.1), ("3D Space", 4, 6.8)]


def current_artifact_id(production_id, artifact_type):
    req = urllib.request.Request(
        f"{API}/productions/{production_id}/artifacts",
        headers={"X-Operator-Token": TOKEN})
    with urllib.request.urlopen(req, timeout=10) as r:
        arts = json.loads(r.read())["artifacts"]
    cur = [a for a in arts if a["artifact_type"] == artifact_type
           and a["state"] == "CURRENT"]
    return cur[0]["artifact_id"] if cur else None


def build(operation_id, production_id):
    script_id = current_artifact_id(production_id, "script")
    if operation_id == "09.12":
        return "direction_package", {
            "kind": "direction_package", "script_ref": script_id,
            "directions": [{"line_ref": ln, "direction": f"Direction for {ln}"}
                           for ln in LINES]}
    if operation_id == "10.12":
        return "shot_manifest", {
            "kind": "shot_manifest", "script_ref": script_id,
            "shots": [{"id": sh, "line_ref": ln, "framing": "MS"}
                      for sh, ln in SHOTS.items()],
            "sound_design": {
                "voice_plan": [{"line_ref": ln, "voice": "lead",
                                "delivery": "measured"} for ln in LINES],
                "music": "single piano motif"}}
    if operation_id == "11.12":
        assets = []
        for sh in SHOTS:
            payload = f"g6-asset-payload-{sh}"
            assets.append({"id": f"A-{sh}", "shot_ref": sh, "payload": payload,
                           "sha256": hashlib.sha256(payload.encode()).hexdigest()})
        return "asset_registry", {"kind": "asset_registry", "assets": assets}
    if operation_id == "12.12":
        dims = [{"name": n, "weight": w, "score": s} for n, w, s in RULE_OF_SIX]
        total = round(sum(w * s for _, w, s in RULE_OF_SIX) / 100.0, 3)
        return "edit_timeline", {
            "kind": "edit_timeline",
            "segments": [{"shot_ref": sh, "order": i + 1}
                         for i, sh in enumerate(SHOTS)],
            "rule_of_six": {"dimensions": dims, "weighted_total": total}}
    return "step_output", {"kind": "step_output", "operation_id": operation_id}


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _send(self, code, obj):
        body = json.dumps(obj).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        self._send(200, {"ok": True, "service": "g6-mock-workers"})

    def do_POST(self):
        n = int(self.headers.get("Content-Length") or 0)
        req = json.loads(self.rfile.read(n) or b"{}")
        if req.get("force_fail"):
            return self._send(500, {"error": "forced failure (test)"})
        artifact_type, content_obj = build(req.get("operation_id"),
                                           req.get("production_id"))
        content = json.dumps(content_obj, sort_keys=True)
        sha = hashlib.sha256(content.encode()).hexdigest()
        STORE.mkdir(parents=True, exist_ok=True)
        (STORE / f"{sha}.json").write_text(content)
        self._send(200, {"artifact_type": artifact_type, "content": content,
                         "storage_uri": f"mock-store://{sha}",
                         "actual_cost_cents": COST, "verdict": "PASS"})


if __name__ == "__main__":
    HTTPServer(("127.0.0.1", 8792), Handler).serve_forever()
