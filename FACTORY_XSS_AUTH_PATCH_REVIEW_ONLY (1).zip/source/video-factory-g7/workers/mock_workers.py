#!/usr/bin/env python3
"""Deterministic mock workers for G7 Station 5 (LOCK_G7).

POST /work {operation_id, production_id, unit_id, force_fail?} ->
13.12 master_package / 14.01 derivative_portfolio (with the locked
predictions block) / 14.12 derivative_package (per-derivative hashes +
upload_manifest). Contents are reference-bearing JSON persisted to the
content-addressed store (store/<sha256>.json), storage_uri
mock-store://<sha256>, checkable against coordinator-recorded hashes.

The master worker reads the production's CURRENT edit_timeline and
asset_registry artifacts through the API and carries their ids, hashes,
and the registry's asset hash list into the master package. Predictions
are deterministic mock records — what G7 verifies is that they are
locked, structured, and created at package time, before any release
metrics can exist (guide §17 G7).
"""
import hashlib
import json
import urllib.request
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path

API = "http://127.0.0.1:8730"
TOKEN = "dev-operator-token"
STORE = Path(__file__).resolve().parent.parent / "store"
COST = 90

DERIVATIVES = [
    {"id": "D-vertical", "format": "9:16", "platform": "shorts"},
    {"id": "D-square", "format": "1:1", "platform": "feed"},
    {"id": "D-thumb", "format": "16:9", "platform": "thumbnail"}]
PREDICTIONS = {d["id"]: {"view_range": [8000, 20000], "ctr_band": "3-5%",
                         "confidence": "LOW — mock prediction record"}
               for d in DERIVATIVES}


def artifacts(production_id):
    req = urllib.request.Request(
        f"{API}/productions/{production_id}/artifacts",
        headers={"X-Operator-Token": TOKEN})
    with urllib.request.urlopen(req, timeout=10) as r:
        return json.loads(r.read())["artifacts"]


def current(production_id, artifact_type):
    cur = [a for a in artifacts(production_id)
           if a["artifact_type"] == artifact_type and a["state"] == "CURRENT"]
    return cur[0] if cur else None


def store_content(sha):
    p = STORE / f"{sha}.json"
    return json.loads(p.read_text()) if p.exists() else None


def build(operation_id, production_id):
    if operation_id == "13.12":
        timeline = current(production_id, "edit_timeline")
        registry = current(production_id, "asset_registry")
        reg_doc = store_content(registry["sha256"]) if registry else None
        asset_hashes = [a["sha256"] for a in (reg_doc or {}).get("assets", [])]
        return "master_package", {
            "kind": "master_package",
            "timeline_ref": timeline["artifact_id"] if timeline else None,
            "timeline_sha256": timeline["sha256"] if timeline else None,
            "registry_ref": registry["artifact_id"] if registry else None,
            "registry_sha256": registry["sha256"] if registry else None,
            "asset_hashes": asset_hashes}
    if operation_id == "14.01":
        master = current(production_id, "master_package")
        return "derivative_portfolio", {
            "kind": "derivative_portfolio",
            "master_ref": master["artifact_id"] if master else None,
            "derivatives": DERIVATIVES,
            "predictions": PREDICTIONS,
            "predictions_locked": True}
    if operation_id == "14.12":
        master = current(production_id, "master_package")
        derivs = []
        for d in DERIVATIVES:
            payload = f"g7-derivative-payload-{d['id']}"
            derivs.append({**d, "payload": payload,
                           "sha256": hashlib.sha256(payload.encode()).hexdigest()})
        return "derivative_package", {
            "kind": "derivative_package",
            "master_ref": master["artifact_id"] if master else None,
            "derivatives": derivs,
            "upload_manifest": {
                "files": [d["id"] for d in DERIVATIVES],
                "master_ref": master["artifact_id"] if master else None,
                "metadata": {"title": "Mock upload package",
                             "visibility": "unlisted"}}}
    return "step_output", {"kind": "step_output", "operation_id": operation_id}


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _send(self, code, obj):
        body = json.dumps(obj).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        self._send(200, {"ok": True, "service": "g7-mock-workers"})

    def do_POST(self):
        n = int(self.headers.get("Content-Length") or 0)
        req = json.loads(self.rfile.read(n) or b"{}")
        if req.get("force_fail"):
            return self._send(500, {"error": "forced failure (test)"})
        artifact_type, content_obj = build(req.get("operation_id"),
                                           req.get("production_id"))
        content = json.dumps(content_obj, sort_keys=True)
        sha = hashlib.sha256(content.encode()).hexdigest()
        STORE.mkdir(parents=True, exist_ok=True)
        (STORE / f"{sha}.json").write_text(content)
        self._send(200, {"artifact_type": artifact_type, "content": content,
                         "storage_uri": f"mock-store://{sha}",
                         "actual_cost_cents": COST, "verdict": "PASS"})


if __name__ == "__main__":
    HTTPServer(("127.0.0.1", 8793), Handler).serve_forever()
