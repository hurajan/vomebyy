# G8 LOCK REQUEST — Station 6 (Steps 15–16): Distribute & Learn

**Status: PREPARED — NOT locked.** Entry condition met (G7 complete + independently verified + ACCEPTED by Raj 2026-10-28 without freezing). Starts only on Raj's lock confirmation. Guide §17 G8: "Steps 15–16 under n8n, final quality gate checks, publication." Guide acceptance: "the full 16 steps run end to end; post-publication learning records exist."

## Proposed scope

1. New tree `~/workspace/video-factory-g8/`; own scratch DB `g8_station_scratch`; mock workers :8794; station-06 workflow set (webhook `/webhook/dispatch-g8`) in the shared n8n instance, reusing the established pattern. G1–G7 trees unmodified — **unless** the gate question below is ruled to need a new `gate_requirements` row, which under placement (A)'s precedent would be a data-only migration 005 in the G2 tree, authorized explicitly by the lock.
2. Mock workers (deterministic, reference-bearing JSON in the content-addressed store):
   - **15.12 → distribution_record**: one publish record per derivative from the production's CURRENT derivative_package (derivative ids + hashes carried in), each with a mock platform id; idempotent by construction (re-dispatch produces no duplicate records — the record is one artifact whose contents enumerate the set).
   - **16.12 (or the Step-16 exit op) → learning_record**: mock actuals per derivative + a prediction-vs-actual comparison computed against the G7 derivative_portfolio's locked predictions (every prediction has exactly one actuals entry; deltas recorded as data).
3. Premise fixtures: derivative_package + derivative_portfolio artifacts (G7-shaped contents) registered by the test — the operator stand-in for Station 5's output.

## OPEN QUESTION for the lock (flagged, not silently resolved)

Does publication require its own human gate? Under OD-F04=(c), HG4 (master approval) already gates derivative *planning*; nothing currently gates the act of publishing itself — a 15.x unit planned against the derivative_package would claim freely. Options: **(i)** no new gate — HG4's approval is the release authority, Station 6 proceeds on it (publication is a mechanical consequence of the approved master + its derivatives); **(ii)** a publication gate — a `gate_requirements` row for `derivative_package` under a new gate kind (name to be ruled; the built Studio's numbering offers no obvious next kind, which is itself a reason this needs Raj's word), enforced by the same coordinator mechanism, with the gate battery re-run at this station. The assistant's recommendation: (ii) if publication to real platforms is ever to be more than a mock — a human should approve the exact derivative set that goes public, bound by hash, the same discipline as HG2/HG4; (i) is defensible only while distribution stays mock. Either way it is Raj's call at lock time.

## Proposed PASS criteria

1. Distribution through real n8n: 15.x exit ACCEPTED; distribution_record CURRENT; its derivative ids + hashes match the premise derivative_package exactly.
2. Duplicate dispatch of the distribution unit changes nothing (no duplicate publish records, no extra spend).
3. Learning: the Step-16 exit ACCEPTED; learning_record CURRENT; every locked prediction from the premise portfolio has exactly one actuals entry and a recorded delta.
4. If option (ii) is ruled: the publication gate battery (unapproved → refused with evidence; approved → proceeds).
5. Budget: spent == the station's unit count × 90¢, reserved 0.
6. Regressions: G1 7/7, G2 suite, G3 5/5, G4 2/2, G5 1/1, G6 3/3, G7 2/2 (shared-API DB pointing explicit per suite).
7. Independent verification (own premise, own checker, tamper probe, own probes).

## Out of scope

Real platform APIs/OAuth/posting (founder-side integrations), real metrics sources, Steps beyond 16 (none — Station 6 completes the 16), G9 full-system verification (its own lock), OVHcloud/queue mode (G0).

## After G8

G9 — full-system verification: all 16 steps / 192 operations end to end on one production, failure-injection battery, upgrade drill (§18). G0 remains BLOCKED on G0.6.
