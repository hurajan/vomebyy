# LOCK G7 — Station 5 (Steps 13–14) + master gate HG4

- **Confirmed by Raj:** 2026-10-28 10:10 EDT ("Confirm G7 lock as scoped (Station 5 + HG4)"). Master gate kind `HG4` confirmed with the lock (OD-F04 = (c)).
- **Entry condition met:** G6 ACCEPTED (without freezing) 2026-10-28; the G6 Part A amendment is part of the accepted coordinator baseline.
- **Baseline:** G1–G6 as accepted, unmodified except as this lock provides. Full scope text: ~/workspace/video-factory-g6/G7_LOCK_REQUEST.md (as confirmed).
- **SUB-DECISION RESOLVED:** placement of the `master_package → HG4` row — **Raj ruled (A) PERMANENT on 2026-10-28 10:33 EDT**: a data-only migration 004 in the G2 tree (+ one setup_db line after 003), no coordinator logic change; every future database enforces HG4 by default. (Option (B) scratch-only was rejected; its silent failure mode — a database rebuilt from the G2 chain alone having no master gate — is the recorded reason (A) was recommended.)

## In scope

1. New tree `~/workspace/video-factory-g7/`; own scratch DB `g7_station_scratch`; mock workers :8793; station-05 workflow set (webhook `/webhook/dispatch-g7`) in the shared n8n instance. After a 13.12 unit, station-05 creates the HG4 gate on the CURRENT master_package (decision stays human, via the API — the pattern from station-03/HG2).
2. Mock workers: **13.12 → master_package** (timeline + registry refs by id and sha, asset hash list carried from the registry); **14.01 → derivative_portfolio** (derivative definitions + the **locked predictions** block, recorded as data at package time); **14.12 → derivative_package** (per-derivative payload hashes + an `upload_manifest` block listing exactly the derivative set and the master ref). Contents are reference-bearing JSON in the content-addressed store, as G5/G6.
3. Premise fixtures: edit_timeline + asset_registry artifacts (G6-shaped contents) registered by the test — the operator stand-in for Station 4's output. The 13.12 unit takes both as planned inputs (neither type is gate-required).
4. Gate enforcement: the 14.x units take the master_package as a planned input, so the coordinator's gate-claim check (G6 mechanism) governs them once the `master_package → HG4` row exists (placement per the sub-decision above).

## PASS criteria

1. Master flow through n8n: 13.12 ACCEPTED; master_package CURRENT; its timeline/registry refs and asset hashes mechanically verified against the premise fixtures.
2. HG4 battery through the real path: HG4 gate created by the station flow (PENDING, exact master sha); a 14.01 unit dispatched before approval is refused (READY, 0 attempts, no budget movement, `gate_claim_refused` evidence); after the human APPROVED decision the chain proceeds.
3. 14.01 and 14.12 ACCEPTED after approval; derivative_portfolio CURRENT with the predictions block present (predictions locked at package time — no Step-15/16 artifact exists in the production); derivative_package CURRENT, per-derivative hashes re-hash correctly, upload_manifest lists exactly the derivative ids.
4. Budget: spent == 3 × 90¢ on the happy-path premise, reserved 0.
5. Regressions: G1 7/7, G2 suite (22 incl. gate-claim tests — and, under placement (A), still green with the second gate_requirements row present), G3 5/5, G4 2/2, G5 1/1, G6 3/3 (shared-API DB pointing explicit per suite).
6. Independent verification (own premise, own checker, tamper probe on a derivative hash, own gate battery).

## Out of scope

Real rendering/transcoding/media, real AI/models/providers, Steps 15–16 (G8), OVHcloud/queue mode (G0), coordinator logic changes of any kind (placement (A) is a data-only migration + setup line; placement (B) touches no G2 file).

## Recorded limitation (carried)

EXPERT golden cases < 50 → evaluators advisory; predictions in G7 are mock prediction *records* — what is verified is that they are locked, structured, and pre-release, not their accuracy.
