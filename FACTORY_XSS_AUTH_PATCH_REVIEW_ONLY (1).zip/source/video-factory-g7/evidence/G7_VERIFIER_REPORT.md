# G7 VERIFIER REPORT — Station 5 (Steps 13–14) + master gate HG4

- **Verifier:** independent agent (not the builder). All behavioral evidence is my own: my own premise (shots `VX7/KQ2/M9`, registry payloads `verifier-g7-asset-payload-<shot>-x1`), my own webhook dispatches (direct POSTs to `/webhook/dispatch-g7` — the builder's driver was not used), my own reference/hash checker, my own gate battery. Harness preserved at `evidence/g7_verifier_harness.py`.
- **Scope:** LOCK_G7 — Station 5 in `~/workspace/video-factory-g7/` + placement (A): permanent data-only migration 004 in the G2 tree.
- **Verdict: VERIFIED — defects NONE.**

## 1. Own station-5 premise through real n8n (harness 31/31)

- 13.12 dispatched via the webhook reached ACCEPTED. The resulting CURRENT `master_package` content (read from the content-addressed store; store bytes re-hash to the coordinator-recorded sha256) matches my fixtures **exactly**: `timeline_ref`/`timeline_sha256` = my edit_timeline artifact, `registry_ref`/`registry_sha256` = my asset_registry artifact, and `asset_hashes` == my three registry asset hashes, in order.
- The HG4 gate was created by the station flow (no manual creation): verdict `PENDING`, `artifact_id` == the master artifact id, `artifact_sha256` == the master's exact sha256. Static audit: no G7 workflow JSON contains a `decide` call — the flow creates the gate only; the decision stayed human (mine, via the API).

## 2. Gate battery (own)

- A 14.01 unit planned against the unapproved master was dispatched through n8n: after 12 s it remained **READY**, `current_attempt` **0**, budget **reserved 0 / spent 90** (master only), and `audit_events` in `g7_station_scratch` contains a `gate_claim_refused` event for the unit (count 1).
- A direct API claim (`POST /units/{id}/claim`, estimated_cents 100) returned **HTTP 409** with the coordinator's typed refusal: *"claim refused: input master_package requires an APPROVED HG4 gate bound to artifact …"*.
- After my APPROVED decision on the exact gate, redispatch carried 14.01 → ACCEPTED and a dependent 14.12 → ACCEPTED.

## 3. Packages under my own checker

- `derivative_portfolio` CURRENT: `master_ref` == master id; `predictions_locked` is `true`; predictions keys == the derivative id set {D-square, D-thumb, D-vertical} exactly (one structured record per derivative).
- `derivative_package` CURRENT: `master_ref` == master id; derivative id set == portfolio's; **every per-derivative sha256 recomputes from its payload** under my checker; `upload_manifest.files` == the derivative id set exactly (set and length), and its `master_ref` == master id.
- Budget: **spent 270, reserved 0** (3 units × 90¢).
- Artifact types present in the production: exactly {asset_registry, derivative_package, derivative_portfolio, edit_timeline, master_package} — **no distribution/learning artifact exists**, so the predictions were locked at package time, before any Step-15/16 artifact could exist (ordering by construction, as locked).

## 4. Tamper probe

A copy of the real derivative_package content with one derivative's `sha256` replaced by `00…0` (payload untouched) was run through my checker: it flagged exactly that derivative (`D-vertical: recorded sha256 does not recompute from payload`). The untampered package flags nothing. The hash discipline is tamper-evident as designed.

## 5. Placement (A) audit

- `database/migrations/004_g7_master_gate_requirement.sql` is **data-only** (a single `INSERT … ON CONFLICT DO NOTHING` inside BEGIN/COMMIT; no DDL, no logic) and **idempotent**: on a throwaway DB it re-applied twice with `INSERT 0 0` both times, leaving exactly one `master_package→HG4` row. Throwaway DB dropped afterwards.
- A database built from the **G2 setup chain alone** (no G7 setup involved) contains both rows: `script→HG2` and `master_package→HG4`. The live `g7_station_scratch` likewise carries both rows. The silent-failure mode of rejected option (B) is closed.
- **G2 tree confinement:** files modified in the G7 window (after 2026-10-28 13:00 UTC) are exactly two, both timestamped 14:33 UTC = 10:33 EDT (the owner's ruling): `database/migrations/004_g7_master_gate_requirement.sql` (new) and `tools/setup_db.py` (adds the single line applying 004 after 003 — read in full; nothing else changed). `coordinator/coordinator.py` is **untouched by G7**: mtime 2026-10-28 12:05 UTC, matching the G6-authorized amendment recorded in the G6 verifier report, and the `_verify_input_gates` mechanism is the G6 code. No coordinator logic change — as locked.
- G2 suite passes 22/22 with both gate rows present in its chain-built databases (see §6), confirming the builder's claim that the second row breaks no assertion.

## 6. Regressions — all re-run by me, none skipped

Each station suite ran immediately after its own setup (shared-API DB pointing explicit; G4 via the documented re-point to `g4_station_scratch` with a restarted API; G4 worker :8790 was already up):

| Suite | Command context | Result |
|---|---|---|
| G1 | `python3 -m unittest discover -s tests` | **7/7 OK** |
| G2 | G2 venv python | **22/22 OK** |
| G3 | G3 venv python (own fixture servers) | **5/5 OK** |
| G4 | API re-pointed to g4_station_scratch, dispatch state reset | **2/2 OK** |
| G5 | after G5 `setup_env.py` | **1/1 OK** |
| G6 | after G6 `setup_env.py`, G2 venv python | **3/3 OK** |
| G7 (builder's) | after G7 `setup_env.py`, G2 venv python — run twice (before my harness and again as the final regression) | **2/2 OK** both times |

The builder's claims (G7 suite 2/2, all regressions green, G2 22/22 with both gate rows) are confirmed in full.

## 7. What I did NOT test

- Real rendering/transcoding or media correctness — out of scope (mock packages with real hash discipline, as locked).
- Prediction accuracy — mock prediction *records*; only their locked, structured, pre-release character was verified (recorded limitation in LOCK_G7).
- Real-browser rendering of any UI (unchanged G0-host-dependent limitation).
- Steps 15–16 (G8), OVHcloud/queue mode (G0), real providers/models — all out of scope.
- n8n failure/restart behaviour of the G7 workflows beyond the happy path and the gate-refusal path exercised above.

## Defects

**NONE.**
