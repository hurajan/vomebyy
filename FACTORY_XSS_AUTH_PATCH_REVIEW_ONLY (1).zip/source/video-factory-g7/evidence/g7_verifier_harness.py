#!/usr/bin/env python3
"""G7 INDEPENDENT VERIFIER harness — own premise, own dispatch (direct
webhook POSTs, not the builder's driver), own checker. Run with the G2
venv python (psycopg) after G7 setup_env. Prints V-PASS/V-FAIL lines."""
import hashlib
import json
import sys
import time
import urllib.request
import urllib.error
from pathlib import Path

import psycopg
from psycopg.rows import dict_row

API = "http://127.0.0.1:8730"
WEBHOOK = "http://127.0.0.1:5678/webhook/dispatch-g7"
TOKEN = "dev-operator-token"
STORE = Path.home() / "workspace/video-factory-g7/store"
DSN = "host=127.0.0.1 dbname=g7_station_scratch user=factory password=factory_dev_local"

# --- verifier's OWN premise: shots and payloads unlike the builder's ---
SHOTS = ["VX7", "KQ2", "M9"]
ASSETS = [{"id": f"V-{sh}", "shot_ref": sh,
           "payload": f"verifier-g7-asset-payload-{sh}-x1",
           "sha256": hashlib.sha256(f"verifier-g7-asset-payload-{sh}-x1".encode()).hexdigest()}
          for sh in SHOTS]
TIMELINE = {"kind": "edit_timeline",
            "segments": [{"shot_ref": sh, "order": i + 1} for i, sh in enumerate(SHOTS)],
            "rule_of_six": {"note": "verifier premise — contents not under test here"}}
REGISTRY = {"kind": "asset_registry", "assets": ASSETS}

RESULTS = []


def check(name, cond, detail=""):
    RESULTS.append((name, bool(cond), detail))
    print(f"{'V-PASS' if cond else 'V-FAIL'}  {name}  {detail}")


def call(method, path, body=None, raw_status=False):
    req = urllib.request.Request(API + path, method=method)
    req.add_header("X-Operator-Token", TOKEN)
    data = None
    if body is not None:
        data = json.dumps(body).encode()
        req.add_header("Content-Type", "application/json")
    try:
        with urllib.request.urlopen(req, data=data, timeout=15) as r:
            out, status = json.loads(r.read() or b"{}"), r.status
    except urllib.error.HTTPError as e:
        out, status = json.loads(e.read() or b"{}"), e.code
    return (out, status) if raw_status else out


def dispatch(pid, unit_id, op, inputs):
    payload = {"production_id": pid, "unit_id": unit_id, "operation_id": op,
               "station": 5, "input_artifact_ids": list(inputs),
               "force_fail": False, "idempotency_key": f"verifier:{unit_id}:1"}
    req = urllib.request.Request(WEBHOOK, method="POST",
                                 data=json.dumps(payload).encode(),
                                 headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=15) as r:
        return r.status


def unit(pid, uid):
    return [u for u in call("GET", f"/productions/{pid}/units")["units"]
            if u["unit_id"] == uid][0]


def wait(pid, uid, target, timeout=120):
    end = time.time() + timeout
    while time.time() < end:
        u = unit(pid, uid)
        if u["state"] == target:
            return u
        time.sleep(2)
    raise AssertionError(f"unit {uid} stuck at {unit(pid, uid)['state']}")


def register(pid, atype, doc):
    content = json.dumps(doc, sort_keys=True)
    sha = hashlib.sha256(content.encode()).hexdigest()
    STORE.mkdir(parents=True, exist_ok=True)
    (STORE / f"{sha}.json").write_text(content)
    return call("POST", f"/productions/{pid}/artifacts",
                {"artifact_type": atype, "content": content,
                 "storage_uri": f"mock-store://{sha}"})


def content_of(art):
    raw = (STORE / f"{art['sha256']}.json").read_bytes()
    assert hashlib.sha256(raw).hexdigest() == art["sha256"], "store content hash mismatch"
    return json.loads(raw)


def check_derivative_hashes(doc):
    """Verifier's own checker: returns list of problems."""
    problems = []
    for d in doc.get("derivatives", []):
        if hashlib.sha256(d["payload"].encode()).hexdigest() != d["sha256"]:
            problems.append(f"{d['id']}: recorded sha256 does not recompute from payload")
    return problems


def main():
    p = call("POST", "/productions", {"title": "G7 VERIFIER premise",
                                      "hard_ceiling_cents": 1000000,
                                      "soft_ceiling_cents": 900000})
    pid = p["production_id"]
    run = call("POST", f"/productions/{pid}/runs", {"kind": "FULL"})["run_id"]
    timeline = register(pid, "edit_timeline", TIMELINE)
    registry = register(pid, "asset_registry", REGISTRY)

    # ---- 1. master flow through real n8n ----
    u13 = call("POST", f"/productions/{pid}/units",
               {"operation_id": "13.12", "run_id": run, "unit_key": "v-main",
                "input_artifact_ids": [timeline["artifact_id"], registry["artifact_id"]]})["unit_id"]
    dispatch(pid, u13, "13.12", [timeline["artifact_id"], registry["artifact_id"]])
    wait(pid, u13, "ACCEPTED")
    check("13.12 ACCEPTED via n8n", True)

    arts = call("GET", f"/productions/{pid}/artifacts")["artifacts"]
    master = [a for a in arts if a["artifact_type"] == "master_package"
              and a["state"] == "CURRENT"][0]
    mdoc = content_of(master)
    check("master timeline_ref == verifier fixture", mdoc["timeline_ref"] == timeline["artifact_id"])
    check("master timeline_sha256 == verifier fixture", mdoc["timeline_sha256"] == timeline["sha256"])
    check("master registry_ref == verifier fixture", mdoc["registry_ref"] == registry["artifact_id"])
    check("master registry_sha256 == verifier fixture", mdoc["registry_sha256"] == registry["sha256"])
    check("master asset_hashes == verifier asset hashes exactly",
          mdoc["asset_hashes"] == [a["sha256"] for a in ASSETS],
          f"got {mdoc['asset_hashes']}")

    # ---- HG4 gate created by the flow ----
    gate = None
    end = time.time() + 60
    while time.time() < end:
        hg4 = [g for g in call("GET", f"/productions/{pid}/gates")["gates"]
               if g["gate_kind"] == "HG4"]
        if hg4:
            gate = hg4[0]
            break
        time.sleep(2)
    check("HG4 gate created by station flow", gate is not None)
    check("HG4 gate PENDING", gate and gate["verdict"] == "PENDING", str(gate and gate["verdict"]))
    check("HG4 bound to exact master id", gate and gate["artifact_id"] == master["artifact_id"])
    check("HG4 bound to exact master sha256", gate and gate["artifact_sha256"] == master["sha256"])

    # ---- 2. gate battery: unapproved master ----
    u14a = call("POST", f"/productions/{pid}/units",
                {"operation_id": "14.01", "run_id": run, "unit_key": "v-derive",
                 "depends_on": [u13], "input_artifact_ids": [master["artifact_id"]]})["unit_id"]
    dispatch(pid, u14a, "14.01", [master["artifact_id"]])
    time.sleep(12)
    u = unit(pid, u14a)
    check("unapproved 14.01 stays READY", u["state"] == "READY", u["state"])
    check("unapproved 14.01 has 0 attempts", u["current_attempt"] == 0, str(u["current_attempt"]))
    budget = call("GET", f"/productions/{pid}/budget")
    check("reserved stays 0 while refused", budget["reserved_cents"] == 0, str(budget))
    check("spent is master only (90) while refused", budget["spent_cents"] == 90, str(budget["spent_cents"]))
    with psycopg.connect(DSN, row_factory=dict_row, autocommit=True) as conn:
        n = conn.execute("SELECT count(*) AS n FROM audit_events WHERE unit_id=%s"
                         " AND event_type='gate_claim_refused'", (u14a,)).fetchone()["n"]
    check("gate_claim_refused audit event present", n >= 1, f"count={n}")

    out, status = call("POST", f"/units/{u14a}/claim",
                       {"worker_id": "verifier-direct", "estimated_cents": 100}, raw_status=True)
    check("direct API claim on gated unit -> HTTP 409", status == 409, f"got {status}: {out}")

    # ---- approve, chain proceeds ----
    call("POST", f"/gates/{gate['gate_id']}/decide",
         {"decision": "APPROVED", "decided_by": "verifier-operator"})
    dispatch(pid, u14a, "14.01", [master["artifact_id"]])
    wait(pid, u14a, "ACCEPTED")
    check("14.01 ACCEPTED after HG4 approval", True)

    u14b = call("POST", f"/productions/{pid}/units",
                {"operation_id": "14.12", "run_id": run, "unit_key": "v-package",
                 "depends_on": [u14a], "input_artifact_ids": [master["artifact_id"]]})["unit_id"]
    dispatch(pid, u14b, "14.12", [master["artifact_id"]])
    wait(pid, u14b, "ACCEPTED")
    check("14.12 ACCEPTED after approval", True)

    # ---- 3. packages under the verifier's own checker ----
    arts = call("GET", f"/productions/{pid}/artifacts")["artifacts"]
    cur = {a["artifact_type"]: a for a in arts if a["state"] == "CURRENT"}
    portfolio = content_of(cur["derivative_portfolio"])
    check("portfolio master_ref == master", portfolio["master_ref"] == master["artifact_id"])
    check("predictions_locked is true", portfolio.get("predictions_locked") is True)
    deriv_ids = {d["id"] for d in portfolio["derivatives"]}
    check("one predictions entry per derivative",
          set(portfolio.get("predictions", {}).keys()) == deriv_ids,
          f"pred keys={sorted(portfolio.get('predictions', {}))} derivs={sorted(deriv_ids)}")
    check("predictions are structured records",
          all(isinstance(v, dict) and v for v in portfolio["predictions"].values()))

    package = content_of(cur["derivative_package"])
    check("package master_ref == master", package["master_ref"] == master["artifact_id"])
    check("package derivative ids == portfolio ids",
          {d["id"] for d in package["derivatives"]} == deriv_ids)
    problems = check_derivative_hashes(package)
    check("all derivative sha256 recompute from payloads", problems == [], "; ".join(problems))
    manifest = package["upload_manifest"]
    check("upload_manifest files == derivative id set exactly",
          set(manifest["files"]) == deriv_ids and len(manifest["files"]) == len(deriv_ids),
          f"files={manifest['files']}")
    check("upload_manifest master_ref == master", manifest["master_ref"] == master["artifact_id"])

    budget = call("GET", f"/productions/{pid}/budget")
    check("budget spent == 270", budget["spent_cents"] == 270, str(budget["spent_cents"]))
    check("budget reserved == 0", budget["reserved_cents"] == 0)

    types = {a["artifact_type"] for a in arts}
    forbidden = {"distribution_record", "release_metrics", "learning_record",
                 "publication_record", "distribution", "publication"}
    check("no distribution/learning artifact types exist",
          not (types & forbidden), f"types={sorted(types)}")

    # ---- 4. tamper probe ----
    tampered = json.loads(json.dumps(package))
    tampered["derivatives"][0]["sha256"] = "0" * 64
    tproblems = check_derivative_hashes(tampered)
    check("TAMPER PROBE: altered sha256 (payload unchanged) is flagged",
          len(tproblems) == 1 and tampered["derivatives"][0]["id"] in tproblems[0],
          "; ".join(tproblems))

    failed = [r for r in RESULTS if not r[1]]
    print(f"\n== verifier harness: {len(RESULTS) - len(failed)}/{len(RESULTS)} passed ==")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
