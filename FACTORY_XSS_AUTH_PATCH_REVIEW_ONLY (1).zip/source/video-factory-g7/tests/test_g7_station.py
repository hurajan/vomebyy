"""G7 end-to-end tests (LOCK_G7): Station 5 through n8n, the master
package reference check, the HG4 gate battery (second production use of
the G6 gate-claim mechanism), and the prediction lock.

Gate 03 Option B (LOCK_GATE_03B): Station 5's chain now starts at step
12 — 12.12 -> 13.12 -> 14.01 -> 14.12. 12.12 (registry Station 5) moved
here from the G6 tree, bringing its chain coverage and the Rule-of-Six
fixture assertions with it.

Requires tools/setup_env.py: API on 8730 (g7_station_scratch with the
master_package -> HG4 gate requirement in place), G7 mock workers on
8793, n8n with the G7 workflows active. Runs under the G2 venv
interpreter (psycopg for the audit-evidence reads), like the G6 suite.
"""
import hashlib
import json
import sys
import time
import unittest
import urllib.request
import urllib.error
from pathlib import Path

import psycopg
from psycopg.rows import dict_row

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "driver"))
import dispatch as driver  # noqa: E402

API = "http://127.0.0.1:8730"
TOKEN = "dev-operator-token"
STORE = Path(__file__).resolve().parent.parent / "store"
# Gate G: produced contents live in the Gate D store, layered envelopes
GATE_D_STORE = (Path.home() / "workspace/video-factory-real-ai-programme"
                / "gate-d/storage_service/.store")
DSN = "host=127.0.0.1 dbname=g7_station_scratch user=factory password=factory_dev_local"

SHOTS = ["SH1", "SH2", "SH3"]
TIMELINE = {"kind": "edit_timeline",
            "segments": [{"shot_ref": sh, "order": i + 1} for i, sh in enumerate(SHOTS)],
            "rule_of_six": {"dimensions": [
                {"name": "Emotion", "weight": 51, "score": 8.6},
                {"name": "Story", "weight": 23, "score": 8.2},
                {"name": "Rhythm", "weight": 10, "score": 7.4},
                {"name": "Eye Trace", "weight": 7, "score": 7.9},
                {"name": "2D Plane", "weight": 5, "score": 7.1},
                {"name": "3D Space", "weight": 4, "score": 6.8}],
                "weighted_total": 8.282}}
REGISTRY = {"kind": "asset_registry", "assets": [
    {"id": f"A-{sh}", "shot_ref": sh, "payload": f"g6-asset-payload-{sh}",
     "sha256": hashlib.sha256(f"g6-asset-payload-{sh}".encode()).hexdigest()}
    for sh in SHOTS]}


def call(method, path, body=None, expect=(200, 201)):
    req = urllib.request.Request(API + path, method=method)
    req.add_header("X-Operator-Token", TOKEN)
    data = None
    if body is not None:
        data = json.dumps(body).encode()
        req.add_header("Content-Type", "application/json")
    try:
        with urllib.request.urlopen(req, data=data, timeout=15) as r:
            out = json.loads(r.read() or b"{}")
            status = r.status
    except urllib.error.HTTPError as e:
        status, out = e.code, json.loads(e.read() or b"{}")
    assert status in expect, f"{method} {path} -> {status}: {out}"
    return out


def unit_state(pid, unit_id):
    units = call("GET", f"/productions/{pid}/units")["units"]
    return [u for u in units if u["unit_id"] == unit_id][0]


def wait_state(pid, unit_id, target, timeout=120):
    deadline = time.time() + timeout
    last = None
    while time.time() < deadline:
        last = unit_state(pid, unit_id)
        if last["state"] == target:
            return last
        time.sleep(2)
    raise AssertionError(f"unit stuck at {last and last['state']}, wanted {target}")


def drive_until(pid, unit_id, target="ACCEPTED", timeout=240):
    """Gate G: acceptance now routes through evaluation + the driver's
    harness-as-human approval, so keep driving until the unit lands."""
    deadline = time.time() + timeout
    last = None
    while time.time() < deadline:
        driver.run_once(pid)
        last = unit_state(pid, unit_id)
        if last["state"] == target:
            return last
        time.sleep(2)
    raise AssertionError(f"unit stuck at {last and last['state']}, wanted {target}")


def refusals(unit_id):
    with psycopg.connect(DSN, row_factory=dict_row, autocommit=True) as conn:
        return conn.execute(
            "SELECT count(*) AS n FROM audit_events WHERE unit_id=%s"
            " AND event_type='gate_claim_refused'", (unit_id,)).fetchone()["n"]


class Base(unittest.TestCase):
    def make_production(self, title):
        p = call("POST", "/productions", {"title": title,
                                          "hard_ceiling_cents": 1000000,
                                          "soft_ceiling_cents": 900000})
        pid = p["production_id"]
        run = call("POST", f"/productions/{pid}/runs", {"kind": "FULL"})["run_id"]
        return pid, run

    def register_doc(self, pid, artifact_type, doc):
        content = json.dumps(doc, sort_keys=True)
        sha = hashlib.sha256(content.encode()).hexdigest()
        STORE.mkdir(parents=True, exist_ok=True)
        (STORE / f"{sha}.json").write_text(content)
        art = call("POST", f"/productions/{pid}/artifacts",
                   {"artifact_type": artifact_type, "content": content,
                    "storage_uri": f"mock-store://{sha}"})
        return art

    def fixtures(self, pid):
        timeline = self.register_doc(pid, "edit_timeline", TIMELINE)
        registry = self.register_doc(pid, "asset_registry", REGISTRY)
        return timeline, registry

    def plan(self, pid, run, op, key="main", depends=(), inputs=()):
        return call("POST", f"/productions/{pid}/units",
                    {"operation_id": op, "run_id": run, "unit_key": key,
                     "depends_on": list(depends), "input_artifact_ids": list(inputs)})

    def drive_edit(self, pid, run, registry):
        """Gate 03 Option B: step 12 (12.12) is served by THIS tree
        (registry Station 5). The registry fixture registered by
        fixtures() stands in for 11.12's exit (the asset_registry, per
        the registry dependency chain 11.12 -> 12.01 -> ... -> 12.12)
        and remains 13.12's declared input below. The 12.12 unit
        itself is planned exactly as the G6 suite planned it —
        standalone here (no upstream unit exists in this tree) with NO
        input_artifact_ids: the step-12 deliverable declares shot
        references, not artifact references, and the evaluation
        continuity layer (correctly) rejects an output that does not
        declare its planned inputs, so a declared registry input
        lands the unit in REPAIR_REQUIRED. (First version of this test
        declared it and failed exactly that way — see Gate 03
        GATE03B_CHANGED_ASSERTIONS.md.)"""
        u12 = self.plan(pid, run, "12.12")["unit_id"]
        driver.run_once(pid, inputs_by_unit={u12: [registry["artifact_id"]]})
        drive_until(pid, u12, "ACCEPTED")
        with psycopg.connect(DSN, row_factory=dict_row, autocommit=True) as conn:
            row = conn.execute(
                "SELECT worker_id FROM action_attempts WHERE unit_id=%s"
                " ORDER BY attempt_no DESC LIMIT 1", (u12,)).fetchone()
        self.assertEqual(row["worker_id"], "n8n-executor-g7")
        arts = call("GET", f"/productions/{pid}/artifacts")["artifacts"]
        timeline = [a for a in arts if a["artifact_type"] == "edit_timeline"
                    and a["state"] == "CURRENT"][0]
        return timeline

    def drive_master(self, pid, run, timeline, registry):
        u13 = self.plan(pid, run, "13.12",
                        inputs=[timeline["artifact_id"], registry["artifact_id"]])["unit_id"]
        driver.run_once(pid, inputs_by_unit={
            u13: [timeline["artifact_id"], registry["artifact_id"]]})
        drive_until(pid, u13, "ACCEPTED")
        arts = call("GET", f"/productions/{pid}/artifacts")["artifacts"]
        master = [a for a in arts if a["artifact_type"] == "master_package"
                  and a["state"] == "CURRENT"][0]
        return u13, master

    def hg4_gate(self, pid, timeout=60):
        deadline = time.time() + timeout
        while time.time() < deadline:
            gates = call("GET", f"/productions/{pid}/gates")["gates"]
            hg4 = [g for g in gates if g["gate_kind"] == "HG4"]
            if hg4:
                return hg4[0]
            time.sleep(2)
        raise AssertionError("station-05 never created the HG4 gate")

    def approve(self, gate_id):
        call("POST", f"/gates/{gate_id}/decide",
             {"decision": "APPROVED", "decided_by": "operator"})

    def content_of(self, art):
        raw = (GATE_D_STORE / "objects" / art["sha256"]).read_bytes()
        assert hashlib.sha256(raw).hexdigest() == art["sha256"]
        doc = json.loads(raw)
        if isinstance(doc, dict) and doc.get("output_artifacts"):
            return doc["output_artifacts"][0]["content"]
        return doc


class TestStation5(Base):
    def test_master_packages_predictions_and_derivatives(self):
        pid, run = self.make_production("G7 approved premise")
        _fixture_timeline, registry = self.fixtures(pid)
        # Gate 03 Option B: the chain enters at 12.12, executed by this
        # tree, and 13.12 consumes the REAL produced edit_timeline.
        timeline = self.drive_edit(pid, run, registry)

        timeline_doc = self.content_of(timeline)
        self.assertEqual({s["shot_ref"] for s in timeline_doc["segments"]},
                         set(SHOTS))
        ros = timeline_doc["rule_of_six"]
        expected = {"Emotion": 51, "Story": 23, "Rhythm": 10,
                    "Eye Trace": 7, "2D Plane": 5, "3D Space": 4}
        self.assertEqual({d["name"]: d["weight"] for d in ros["dimensions"]}, expected)
        self.assertEqual(sum(d["weight"] for d in ros["dimensions"]), 100)
        total = round(sum(d["weight"] * d["score"] for d in ros["dimensions"]) / 100.0, 3)
        self.assertEqual(ros["weighted_total"], total)

        u13, master = self.drive_master(pid, run, timeline, registry)

        master_doc = self.content_of(master)
        self.assertEqual(master_doc["timeline_ref"], timeline["artifact_id"])
        self.assertEqual(master_doc["timeline_sha256"], timeline["sha256"])
        self.assertEqual(master_doc["registry_ref"], registry["artifact_id"])
        self.assertEqual(master_doc["asset_hashes"],
                         [a["sha256"] for a in REGISTRY["assets"]])

        gate = self.hg4_gate(pid)
        self.assertEqual(gate["artifact_id"], master["artifact_id"])
        self.assertEqual(gate["artifact_sha256"], master["sha256"])
        self.assertEqual(gate["verdict"], "PENDING")
        self.approve(gate["gate_id"])

        u14a = self.plan(pid, run, "14.01", depends=[u13],
                         inputs=[master["artifact_id"]])["unit_id"]
        u14b = self.plan(pid, run, "14.12", depends=[u14a],
                         inputs=[master["artifact_id"]])["unit_id"]
        deadline = time.time() + 240
        while time.time() < deadline:
            driver.run_once(pid, inputs_by_unit={
                u14a: [master["artifact_id"]], u14b: [master["artifact_id"]]})
            if (unit_state(pid, u14a)["state"] == "ACCEPTED"
                    and unit_state(pid, u14b)["state"] == "ACCEPTED"):
                break
            time.sleep(2)
        else:
            self.fail("derivative chain timed out")

        arts = call("GET", f"/productions/{pid}/artifacts")["artifacts"]
        cur = {a["artifact_type"]: a for a in arts if a["state"] == "CURRENT"}
        portfolio = self.content_of(cur["derivative_portfolio"])
        self.assertEqual(portfolio["master_ref"], master["artifact_id"])
        self.assertTrue(portfolio["predictions_locked"])
        deriv_ids = {d["id"] for d in portfolio["derivatives"]}
        self.assertEqual(set(portfolio["predictions"].keys()), deriv_ids)

        package = self.content_of(cur["derivative_package"])
        self.assertEqual(package["master_ref"], master["artifact_id"])
        self.assertEqual({d["id"] for d in package["derivatives"]}, deriv_ids)
        for d in package["derivatives"]:
            self.assertEqual(hashlib.sha256(d["payload"].encode()).hexdigest(),
                             d["sha256"])
        self.assertEqual(set(package["upload_manifest"]["files"]), deriv_ids)

        # prediction lock: predictions exist at package time and no
        # distribution/learning artifact exists in this production at all
        types = {a["artifact_type"] for a in arts}
        self.assertFalse(types & {"distribution_record", "release_metrics",
                                  "learning_record"})

        budget = call("GET", f"/productions/{pid}/budget")
        self.assertEqual(budget["spent_cents"], 4 * 90)
        self.assertEqual(budget["reserved_cents"], 0)


class TestMasterGateBattery(Base):
    def test_unapproved_master_refused_then_released(self):
        pid, run = self.make_production("G7 unapproved premise")
        timeline, registry = self.fixtures(pid)
        u13, master = self.drive_master(pid, run, timeline, registry)
        gate = self.hg4_gate(pid)
        self.assertEqual(gate["verdict"], "PENDING")

        u = self.plan(pid, run, "14.01", depends=[u13],
                      inputs=[master["artifact_id"]])["unit_id"]
        driver.run_once(pid, inputs_by_unit={u: [master["artifact_id"]]})
        time.sleep(10)
        unit = unit_state(pid, u)
        self.assertEqual(unit["state"], "READY")
        self.assertEqual(unit["current_attempt"], 0)
        budget = call("GET", f"/productions/{pid}/budget")
        self.assertEqual(budget["reserved_cents"], 0)
        self.assertGreaterEqual(refusals(u), 1)

        self.approve(gate["gate_id"])
        driver.redispatch(pid, u, "14.01", inputs=[master["artifact_id"]])
        final = drive_until(pid, u, "ACCEPTED")
        self.assertEqual(final["current_attempt"], 1)


if __name__ == "__main__":
    unittest.main(verbosity=2)
