"""Source-only release gate. Produces machine-readable blockers; never deploys."""
import argparse,json,re,hashlib
from pathlib import Path

def inspect(root):
    issues=[]
    files=list(root.rglob('*'))
    target=root/'source/video-factory-g3/dashboard/index.html'
    if target.exists() and 'innerHTML' in target.read_text(errors='replace'):
        issues.append({'id':'SEC-XSS-01','severity':'CRITICAL','status':'BLOCK','reason':'Dashboard includes dynamic innerHTML; DOM XSS remediation and browser test required'})
    for path in files:
        if not path.is_file() or path.suffix not in ('.py','.sh','.js','.html','.json','.md'):continue
        rel=str(path.relative_to(root))
        if '/evidence/' in rel or '/tests/' in rel:continue
        if path.stat().st_size>2000000:continue
        s=path.read_text(errors='replace')
        if path.name=='setup_db.py' and re.search(r'DROP DATABASE|drop database',s,re.I):
            issues.append({'id':'DB-DESTRUCTIVE','severity':'CRITICAL','status':'BLOCK','file':rel})
    for id,description in [('DEP-IMAGE','Service images and supported dependency lockfiles not verified'),('DEP-N8N','Existing live n8n compatibility not verified'),('SEC-AUTH','Role-bound identity and negative authorization testing not independently passed'),('RUN-E2E','Complete 16-step live end-to-end execution not verified'),('RUN-PROVIDERS','Credentials and real AI/media/publishing providers not verified'),('RUN-RECOVERY','Off-host restore and five-production concurrency not verified'),('OP-COUNT','194-operation claim lacks approved source definitions')]:
        issues.append({'id':id,'severity':'HIGH','status':'BLOCK','reason':description})
    return {'deployment_authorized':False,'blocker_count':len(issues),'blockers':issues}
if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('source');a.add_argument('--out'); args=a.parse_args()
    result=inspect(Path(args.source)); content=json.dumps(result,indent=2)
    if args.out:Path(args.out).write_text(content+'\n')
    print(content)
    raise SystemExit(2 if result['blocker_count'] else 0)
