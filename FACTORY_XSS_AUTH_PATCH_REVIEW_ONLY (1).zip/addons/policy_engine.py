"""Standalone, fail-closed P4 configuration drafting and validation.

This package does NOT grant Coordinator promotion authority. Immutable drafts
are exported for review and integration with the existing OPERATOR-only API.
"""
from __future__ import annotations
import hashlib, json, re
from dataclasses import dataclass
from typing import Any

CAPABILITIES = {
    'hook_rule': {'steps': {'05','06','08'}, 'kind':'rule'},
    'shot_policy': {'steps': {'09','10'}, 'kind':'rule'},
    'translation': {'steps': {'08','11','14'}, 'kind':'localization'},
    'voice_locale': {'steps': {'11'}, 'kind':'localization'},
    'distribution_metadata': {'steps': {'14','15'}, 'kind':'packaging'},
}
LOCALES = re.compile(r'^[a-z]{2,3}(?:-[A-Za-z0-9]{2,8}){0,3}$')
KEY = re.compile(r'^[a-z][a-z0-9_]{0,63}$')
FORBIDDEN = ('ignore previous instructions', 'disable validation', 'bypass approval', 'skip safety checks')
MAX_RULE = 4000

class ValidationError(ValueError): pass

def canonical(value: Any) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False, allow_nan=False).encode()

def validate(d: dict, registry: dict) -> dict:
    if not isinstance(d, dict): raise ValidationError('expected object')
    permitted={'capability','step','name','rules','parameters','version','target_locales','source_locale','approval_required'}
    if set(d)-permitted: raise ValidationError('unknown fields')
    capability=d.get('capability'); config=CAPABILITIES.get(capability)
    if not config: raise ValidationError('unknown capability (requires implementation review)')
    step=d.get('step')
    if step not in config['steps']: raise ValidationError('capability not authorized for this step')
    if step not in {s['step_id'] for s in registry['steps']}: raise ValidationError('missing step')
    name=d.get('name'); rules=d.get('rules'); params=d.get('parameters',{})
    if not isinstance(name,str) or not (1<=len(name)<=120): raise ValidationError('invalid name')
    if not isinstance(rules,str) or not (1<=len(rules)<=MAX_RULE): raise ValidationError('invalid rules')
    if any(flag in rules.casefold() for flag in FORBIDDEN): raise ValidationError('unsafe policy override wording')
    if not isinstance(params,dict) or len(params)>32 or any(not KEY.fullmatch(k) for k in params): raise ValidationError('invalid parameters')
    if any(not isinstance(v,(str,int,float,bool)) or (isinstance(v,str) and len(v)>512) for v in params.values()): raise ValidationError('invalid parameter value')
    locales=d.get('target_locales',[])
    if not isinstance(locales,list) or len(locales)>20 or len(locales)!=len(set(locales)) or any(not isinstance(x,str) or not LOCALES.fullmatch(x) for x in locales): raise ValidationError('invalid locale list')
    source=d.get('source_locale','en')
    if not isinstance(source,str) or not LOCALES.fullmatch(source): raise ValidationError('invalid source locale')
    if capability in {'translation','voice_locale'} and not locales: raise ValidationError('translation requires target locales')
    if source in locales: raise ValidationError('source cannot be in target locales')
    if d.get('approval_required',True) is not True: raise ValidationError('approval cannot be disabled')
    if d.get('version') not in (None,'draft'): raise ValidationError('direct active version not allowed')
    value={k:d[k] for k in sorted(d) if k!='version'}
    value['status']='DRAFT_REQUIRES_OPERATOR_REVIEW'
    value['approval_required']=True
    value['workflow_version']=registry['workflow_version']
    value['sha256']='sha256:'+hashlib.sha256(canonical(value)).hexdigest()
    return value

def rollback_request(active_hash: str, prior_hash: str) -> dict:
    pat=re.compile(r'^sha256:[a-f0-9]{64}$')
    if not pat.fullmatch(active_hash) or not pat.fullmatch(prior_hash): raise ValidationError('invalid immutable revision')
    if active_hash==prior_hash: raise ValidationError('same revision')
    return {'action':'REQUEST_ROLLBACK','active_hash':active_hash,'prior_hash':prior_hash,'status':'REQUIRES_OPERATOR_AUTHORIZATION'}

def packaging_draft(*, story_title: str, synopsis: str, platforms: list[str], locales: list[str]) -> dict:
    allowed={'youtube','youtube_shorts','tiktok','instagram_reels','facebook'}
    if not isinstance(story_title,str) or not (1<=len(story_title)<=100): raise ValidationError('invalid title')
    if not isinstance(synopsis,str) or not (1<=len(synopsis)<=4000): raise ValidationError('invalid synopsis')
    if not isinstance(platforms,list) or not set(platforms)<=allowed or not platforms: raise ValidationError('invalid platforms')
    if not isinstance(locales,list) or not locales or any(not isinstance(l,str) or not LOCALES.fullmatch(l) for l in locales): raise ValidationError('invalid locales')
    return {'status':'DRAFT_NEEDS_GENERATION_EVALUATION_RIGHTS_REVIEW_AND_APPROVAL','source':{'title':story_title,'synopsis':synopsis},'variants':[
        {'platform':p,'locale':l,'title':None,'description':None,'tags':[], 'thumbnail_artifact_id':None,'social_posts':[], 'evaluation':None,'approved':False, 'published':False}
        for p in sorted(set(platforms)) for l in sorted(set(locales))]}
