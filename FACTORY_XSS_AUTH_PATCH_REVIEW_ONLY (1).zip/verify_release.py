import json,pathlib,hashlib,sys
root=pathlib.Path(__file__).resolve().parent
manifest=json.loads((root/'MANIFEST.json').read_text())
errors=[]
for f,d in manifest.items():
 p=root/f
 if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=d:errors.append(f)
for p in (root/'source').rglob('setup_db.py'):
 if 'DROP DATABASE' in p.read_text():errors.append('unsafe setup: '+str(p))
print('PASS' if not errors else 'FAIL',len(manifest),'files',len(errors),'errors')
if errors: print(*errors,sep='\n');sys.exit(1)
